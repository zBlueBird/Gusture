/**
*****************************************************************************************
*     Copyright(c) 2017, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
  * @file    bblite_wrapper.h
  * @brief   This file provides api wrapper for bbpro compatibility..
  * @author  sandy_jiang
  * @date    2018-11-29
  * @version v1.0
  * *************************************************************************************
   * @attention
   * <h2><center>&copy; COPYRIGHT 2017 Realtek Semiconductor Corporation</center></h2>
   * *************************************************************************************
  */

/*============================================================================*
 *               Define to prevent recursive inclusion
 *============================================================================*/
#ifndef __WDG_H_
#define __WDG_H_



/*============================================================================*
 *                               Header Files
*============================================================================*/
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*
 *                         Types
 *============================================================================*/


/** @defgroup WATCH_DOG_Types Watch Dog Exported Types
  * @{
  */

/**
  * @brief   Watch Dog Mode structure definition
  */

typedef enum _WDG_MODE
{
    RESET_ALL = 0,               /**< Reset all */
    RESET_ALL_EXCEPT_AON = 1,    /**< Reset all except RTC and some AON register */
    INTERRUPT_KM4_and_KR0 = 2,   /**< Interrupt KM4 and KR0 */
    INTERRUPT_KM4 = 3            /**< Interrupt KM4 only */
} T_WDG_MODE;

/**
   * @brief  Watch Dog Reset System
   * @param  type @ref T_WDG_TYPE
   */
extern void chip_reset(T_WDG_MODE wdg_mode);

/** @} */ /* End of group WATCH_DOG */

#ifdef __cplusplus
}
#endif

#endif
