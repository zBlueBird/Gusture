/**
*****************************************************************************************
*     Copyright(c) 2016, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
  * @file    app_sys_cfg.h
  * @brief
  * @details
  * @author
  * @date    3. March 2022
  * @version v1.0
  * *************************************************************************************
   * @attention
   * <h2><center>&copy; COPYRIGHT 2016 Realtek Semiconductor Corporation</center></h2>
   * ************************************************************************************
   */

/*============================================================================*
 *                      Define to prevent recursive inclusion
 *============================================================================*/
#ifndef APP_SYS_CFG_H
#define APP_SYS_CFG_H


/*============================================================================*
 *                      Headers
 *============================================================================*/
#include <stdint.h>
#include <stdbool.h>

/** @defgroup SYSTEM_RTL876X_API  System Rtl876x
  * @brief CMSIS API sets for RTL876x Device Series
  * @{
  */

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*
 *                      Types
 *============================================================================*/
/** @defgroup SYSTEM_RTL876X_Exported_types SYSTEM RTL876X Exported types
  * @{
  */
typedef struct t_efuse_os_cfg
{
    uint16_t getStackHighWaterMark : 1;         /* 0 for release version, 1 for debug version */
    uint16_t checkForStackOverflow : 1;         /* 0 for release version, 1 for debug version */
    uint16_t dumpMemoryUsage : 1;               /* 0 for release version, 1 for debug version */
    uint16_t enableASSERT: 1;                   /* 0 for release version, 1 for debug version */
    uint16_t rsvd: 12;
    uint8_t  timerMaxNumber;                   /* default = 0x20 */
    uint8_t  timerQueueLength;                 /* default = 0x20 */

    uint32_t appDataAddr;
    uint32_t appDataSize;
    uint32_t heapDataONSize;
    uint32_t heapBufferONSize;
    uint32_t globalExtDataSRAMSize;

    uint16_t idle_task_stack_size;             /* measured in bytes, default 256 * 4 bytes */
    uint16_t timer_task_stack_size;            /* measured in bytes, default 256 * 4 bytes */
} __attribute__((packed)) T_OS_CFG;

typedef struct
{
    uint32_t nvic_non_secure_mask[4];

} __attribute__((packed)) T_PLATFORM_CFG;

typedef struct app_sys_cfg_struct
{
    T_OS_CFG os_cfg __attribute__((aligned(4)));
    T_PLATFORM_CFG platform_cfg __attribute__((aligned(4)));
} __attribute__((packed)) APP_SYS_CFG_STRUCT;

typedef bool (*BOOL_APP_PATCH_FUNC)();

/** @} */ /* End of group SYSTEM_RTL876X_Exported_types */

/*============================================================================*
 *                      Variables
 *============================================================================*/
/** @defgroup SYSTEM_RTL876X_Exported_Variables SYSTEM RTL876X Exported Variables
  * @{
  */
extern APP_SYS_CFG_STRUCT app_sys_cfg;


/** @} */ /* End of group SYSTEM_RTL876X_Exported_Variables */



/*============================================================================*
 *                      Functions
 *============================================================================*/
/** @defgroup SYSTEM_RTL876X_Exported_Functions SYSTEM RTL876X Sets Exported Functions
    * @brief
    * @{
    */


/** @} */ /* End of group SYSTEM_RTL876X_Exported_Functions */
#ifdef __cplusplus
}
#endif


/** @} */ /* End of group SYSTEM_RTL876X_API */



#endif /* SYSTEM_RTL876X_H */

