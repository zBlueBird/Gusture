#ifndef OS_CFG_H
#define OS_CFG_H

/**
 * @struct OS_NONSECURE_CFG
 * @brief FreeRTOS EFuse settings.
 *
 * Refer to EFUSE[0x].
 */
#include <stdint.h>
typedef union _HEAP_TYPE_MASK
{
    struct
    {
        uint8_t heap_data_on_mask : 1;
        uint8_t heap_data_off_mask : 1;
        uint8_t heap_buffer_on_mask : 1;
        uint8_t heap_buffer_off_mask : 1;
        uint8_t heap_dtcm0_mask : 1;
        uint8_t heap_itcm1_mask : 1;
        uint8_t heap_dsp_share_mask : 1;
        uint8_t reserved : 1;
    };
    uint8_t heap_type_mask;
} HEAP_TYPE_MASK;

typedef struct
{
    uint32_t wdgTimeoutMs : 23;               /* seconds, default = 4s */
    //uint32_t wdgMode : 2;                     /* 0: interrupt CPU,     1: reset all but aon
    //                                             2: reset core domain, 3: reset all */
    //uint32_t wdgEnableInRom : 1;  /* 1 for release version, 0 for debug version. default = 0 */
    uint32_t wdgResetInCS: 1;       /* 0 for release version, 1 for debug version. default = 0 */
    uint32_t wdgResetInIdle: 1;     /* 1 for release version, 0 for debug version. default = 0 */
    //uint32_t wdgAonBackup : 1;
    uint32_t cpu_sleep_en: 1;                   /* default = 0 */
    uint32_t checkForStackOverflow : 1;         /* 0 for release version, 1 for debug version */
    uint32_t printAllLogBeforeEnterLowpower : 1;/* 0 for release version, 1 for debug version */
    uint32_t rsvd0: 4;

    uint8_t dumpMemoryWhenHardFault : 1;        /* 0 for release version, 1 for debug version */
    uint8_t dumpMemoryUsage : 1;                /* 0 for release version, 1 for debug version */
    uint8_t enableASSERT: 1;                    /* 0 for release version, 1 for debug version */
    uint8_t mallocFailAssert : 1;
    uint8_t stack_ram_type: 3;
    uint8_t ram_always_on : 1;                  /* config all ram always on */

    uint8_t heap_contiguousy : 1;
    uint8_t enable_malloc_track: 1;
    uint8_t reserved : 6;


    uint8_t  timerMaxNumber;                    /* default = 0x30 */
    uint8_t  timerQueueLength;                  /* default = 0x20 */

//    uint32_t heapDataONAddr;
//    uint32_t heapDataONSize;
//    uint32_t heapBufferONSize;
//    uint32_t heapITCM1Addr;
    HEAP_TYPE_MASK heap_mask;

    uint8_t bufferBlockDSPShared;

    uint16_t idle_task_stack_size;             /* measured in bytes, default 256 * 4 bytes */
    uint16_t timer_task_stack_size;            /* measured in bytes, default 256 * 4 bytes */
    uint16_t lower_task_stack_size;            /* measured in bytes, default 768 * 4 bytes */
} OS_NONSECURE_CFG;

extern OS_NONSECURE_CFG os_cfg_ns;
extern uint16_t (*get_lower_task_stack_size)(void);
#endif // OS_CFG_H
