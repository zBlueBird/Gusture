/**
 *****************************************************************************************
 *     Copyright(c) 2018, Realtek Semiconductor Corporation. All rights reserved.
 *****************************************************************************************
 * @file    fmc_platform.h
 * @brief   Flexible memory controller (SPIC & PSRAMC) platform dependent implementation header file
 * @author  Yao-Yu
 * @date    2020-10-20
 * @version v0.1
 * ***************************************************************************************
 */

#ifndef _FMC_PLATFORM_H
#define _FMC_PLATFORM_H


/****************************************************************************************
 * Flexible Memory Controller Compiling Flags
 ****************************************************************************************/
#define FMC_SUPPORT_CPU_CACHE                               1
#define FMC_SUPPORT_MAIN0_CACHE                             0
#define FMC_SUPPORT_FIFO_SIZE_8                             0

/****************************************************************************************
 * Flexible Memory Controller Address Map
 ****************************************************************************************/
// if there is no cache, then UNCACHEABLE_ADDR should equal to MAIN_ADDR
#define FMC_MAIN0_ADDR                                      (SPIC0_ADDR)
#define FMC_MAIN1_ADDR                                      (SPIC1_ADDR)
#define FMC_MAIN2_ADDR                                      (SPIC2_ADDR)
#define FMC_MAIN3_ADDR                                      (SPIC3_ADDR)
#define FMC_MAIN0_UNCACHEABLE_ADDR                          (SPIC0_ADDR)
#define FMC_MAIN0_SIZE                                      ( 64 * 1024 * 1024)
#define FMC_MAIN0_NON_CACHE_ADDR(cache_addr)                ((cache_addr) & ~(FMC_MAIN0_ADDR) | (FMC_MAIN0_UNCACHEABLE_ADDR))

/****************************************************************************************
 * Flexible Memory Controller Address Map Checking
 ****************************************************************************************/
#define FMC_IS_SPIC0_CACHEABLE_ADDR(addr)                   ((addr >= FMC_MAIN0_ADDR) && (addr < FMC_MAIN0_ADDR + FMC_MAIN0_SIZE))
#define FMC_IS_SPIC0_UNCACHEABLE_ADDR(addr)                 ((addr >= FMC_MAIN0_UNCACHEABLE_ADDR) && (addr < FMC_MAIN0_UNCACHEABLE_ADDR + FMC_MAIN0_SIZE))
#define FMC_IS_SPIC0_ADDR(addr)                             (FMC_IS_SPIC0_CACHEABLE_ADDR(addr) || FMC_IS_SPIC0_UNCACHEABLE_ADDR(addr))

/****************************************************************************************
 * Flexible Memory Controller Calibration Definition
 ****************************************************************************************/
#define FMC_CAL_PATTERN                                     (0x5A5A12A5)

/****************************************************************************************
 * SPIC Description
 ****************************************************************************************/
#define SPIC_NUM                                            (4)
#define SPIC_RX_FIFO_NUM                                    (128)
#define SPIC_TX_FIFO_NUM                                    (64)
#define SPIC1_RX_FIFO_NUM                                   (128)
#define SPIC1_TX_FIFO_NUM                                   (128)
#define SPIC2_RX_FIFO_NUM                                   (128)
#define SPIC2_TX_FIFO_NUM                                   (128)
#define SPIC3_RX_FIFO_NUM                                   (128)
#define SPIC3_TX_FIFO_NUM                                   (128)

/****************************************************************************************
 * FMC Auto Write Settings
 ****************************************************************************************/
#define SPIC_AUTO_WR_ENABLE(idx, enable)                                            \
    (HAL_UPDATE32(0x40006024, 1 << (24 + (idx)), (enable) << (24 + (idx))))

typedef enum
{
    /* For SPIC1 PSRAM */
    PSRAM_QPI_TYPE,
    PSRAM_OPI_TYPE,
    PSRAM_16IO_TYPE,
} PSRAM_INTERFACE_TYPE;

#endif
