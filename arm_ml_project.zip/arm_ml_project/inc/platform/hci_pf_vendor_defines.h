/***************************************************************************
 Copyright (C) Realtek Semiconductor Corp.
 This module is a confidential and proprietary property of Realtek and
 a possession or use of this module requires written permission of Realtek.
 ***************************************************************************/

/**
 * @file
 * HCI vendor command/event definition.
 */

/**
 * @addtogroup HCIVendor
 * @{
 */
#ifndef __HCI_PF_VENDOR_DEFINES_H__
#define __HCI_PF_VENDOR_DEFINES_H__

#include <stdint.h>

#define HCI_MAX_CMD_PARAM_LEN               255
#define HCI_MAX_EVENT_PARAM_LEN             255
#define COMPILE_HCI_EXT_PF_VENDOR           0

/*============================= Error Codes =============================*/
#define HCI_COMMAND_SUCCEEDED                                 0x00
#define HARDWARE_FAILURE_ERROR                                0x03
#define COMMAND_DISALLOWED_ERROR                              0x0C
#define INVALID_HCI_COMMAND_PARAMETERS_ERROR                  0x12
#define UNSPECIFIED_ERROR                                     0x1F

/** @brief The upper 8 bits of a 16 bit value */
#ifndef MSB
#define MSB(a) (((a) & 0xFF00) >> 8)
#endif

/** @brief The lower 8 bits of a 16 bit value */
#ifndef LSB
#define LSB(a) ((a) & 0xFF)
#endif

#ifndef MAX
#define MAX(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifndef MIN
#define MIN(a,b)            (((a) < (b)) ? (a) : (b))
#endif

/**
 * Command packet
 */
typedef struct
{
    uint16_t cmd_opcode;
    /* Length of parameter not the number of paramenters */
    unsigned char param_total_length;
    unsigned char cmd_parameter[HCI_MAX_CMD_PARAM_LEN];
} BT_HCI_CMD_PKT;

/**
 * Event packet
 */
typedef struct
{
    unsigned char event_opcode;
    unsigned char param_total_length;
    unsigned char event_parameter[HCI_MAX_EVENT_PARAM_LEN];
} BT_HCI_EVENT_PKT;

/* ========== ROM Platform Vendor Command ========== */
#define HCI_VENDOR_POWER_MANAGER_CMD                        0xFC7D
enum
{
    HCI_VENDOR_PM_SUBCMD_SET_SUSPEND                        = 0,

    HCI_VENDOR_PM_SUBCMD_FEATURE_CFG                        = 2,
};

#define HCI_VENDOR_PM_UNIT_PF_CMD                           0xFC7E
enum
{
    HCI_VENDOR_PM_UNIT_PF_SUBCMD_SET_MODE                   = 0,

    HCI_VENDOR_PM_UNIT_PF_SUBCMD_FEATURE_CFG                = 2,
    HCI_VENDOR_PM_UNIT_PF_SUBCMD_STATISTICS_CLEAR           = 3,

    HCI_VENDOR_PM_UNIT_PF_SUBCMD_SET_MODE_WITH_LIMIT_TIMES  = 6,
};

#define HCI_READ_LOCAL_VERSION_INFORMATION_OPCODE            0x1001

#define HCI_VENDOR_DOWNLOAD                                  0xFC20

#define FLASH_NOR_HCI_FUNC_ENABLE
#define HCI_VENDOR_FLASH_NOR_READ                            0xFC29
#define HCI_VENDOR_FLASH_NOR_WRITE                           0xFC2A
#define HCI_VENDOR_FLASH_NOR_ERASE                           0xFC2B
#define HCI_VENDOR_FLASH_NOR_IOCTL                           0xFC2C
#define HCI_VENDOR_FLASH_NOR_READ_BUFFER                     0xFC2D
#define HCI_VENDOR_FTL_IOCTL                                 0xFC3D

#define HCI_VENDOR_READ                                      0xFC61
#define HCI_VENDOR_WRITE                                     0xFC62
#define HCI_VENDOR_WRITE_OTP_DATA                            0xFC6B
#define HCI_VENDOR_READ_OTP_DATA                             0xFC6C
#define HCI_VENDOR_READ_OTP_ON_RAM                           0xFD62

#define HCI_VENDOR_READ_RTK_ROM_VERSION                      0xFC6D
#define HCI_VENDOR_READ_RTK_RTK_CHIP_ID                      0xFC6F

#define HCI_VENDOR_SET_FT_MODE_CMD                           0xFC8C
#define HCI_VENDOR_SET_MONITOR_MODE_CMD                      0xFC8D
#define HCI_VENDOR_ENABLE_WDG_RESET_CMD                      0xFC8E

#define HCI_VENDOR_ENTER_DEBUG_PASSWORD_CMD                  0xFD60
#define HCI_VENDOR_GET_APP_EUID_CMD                          0xFD61
#define HCI_VENDOR_USB_LOOPBACK_TEST                         0xFD92

#define HCI_VENDOR_SWITCH_HCI_PIN                            0xFE00

void hci_vendor_handle_enter_debug_password_cmd(BT_HCI_CMD_PKT *hci_cmd_ptr);

uint8_t hci_platform_vendor_cmd_rom(void *vhci_cmd_ptr, unsigned char *send_cmd_comp_event_flag,
                                    unsigned char *status,
                                    void **return_value);
uint8_t hci_platform_vendor_generate_command_complete_event_rom(void *vhci_event_pkt_ptr,
                                                                unsigned char *param_length_ptr,
                                                                void *return_value);

uint8_t hci_phy_power_vendor_cmd_rom(void *vhci_cmd_ptr, unsigned char *send_cmd_comp_event_flag,
                                     unsigned char *status,
                                     void **return_value);

uint8_t hci_phy_power_vendor_generate_command_complete_event_rom(void *vhci_event_pkt_ptr,
                                                                 unsigned char *param_length_ptr,
                                                                 void *return_value);

extern uint8_t (*hci_platform_vendor_cmd)(void *vhci_cmd_ptr,
                                          unsigned char *send_cmd_comp_event_flag,
                                          unsigned char *status,
                                          void **return_value);
extern uint8_t (* hci_platform_vendor_generate_command_complete_event)(
    void *vhci_event_pkt_ptr,
    unsigned char *param_length_ptr,
    void *return_value);

extern uint8_t (* hci_phy_power_vendor_cmd)(void *vhci_cmd_ptr,
                                            unsigned char *send_cmd_comp_event_flag,
                                            unsigned char *status,
                                            void **return_value);

extern uint8_t (* hci_phy_power_vendor_generate_command_complete_event)(
    void *vhci_event_pkt_ptr,
    unsigned char *param_length_ptr,
    void *return_value);

#endif /* __HCI_PF_VENDOR_DEFINES_H__ */
/**@}*/
