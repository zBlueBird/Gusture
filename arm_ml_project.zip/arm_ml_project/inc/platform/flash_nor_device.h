/**
 *****************************************************************************************
 *     Copyright(c) 2018, Realtek Semiconductor Corporation. All rights reserved.
 *****************************************************************************************
 * @file    flash_nor_device.h
 * @brief   Nor flash external API header file
 * @author  Yao-Yu
 * @date    2020-08-31
 * @version v0.1
 * ***************************************************************************************
 */

#ifndef _FLASH_NOR_DEVICE_H
#define _FLASH_NOR_DEVICE_H

#include "flash_nor_basic.h"
#include "flash_nor_device_nsc.h"

/****************************************************************************************
 * Nor Flash Enumeration
 ****************************************************************************************/
typedef enum _FLASH_NOR_IOCTL_TYPE
{
    FLASH_NOR_GET_BASE                          = 0x0000,
    FLASH_NOR_GET_ADDR_BASE,
    FLASH_NOR_GET_RDID,
    FLASH_NOR_GET_SIZE,
    FLASH_NOR_GET_BP,
    FLASH_NOR_GET_BP_TOP_BOTTOM,
    FLASH_NOR_GET_WAIT_BUSY_CTR,
    FLASH_NOR_GET_BIT_MODE,

    FLASH_NOR_SET_BASE                          = 0x1000,
    FLASH_NOR_SET_BP,
    FLASH_NOR_SET_BP_TOP_BOTTOM,
    FLASH_NOR_SET_BP_UNLOCK_BY_ADDR,
    FLASH_NOR_SET_WAIT_BUSY_CTR,
    FLASH_NOR_SET_SPIC_BAUD,
    FLASH_NOR_SET_LOG_BITMAP,

    FLASH_NOR_EXEC_BASE                         = 0x2000,
    FLASH_NOR_EXEC_FLASH_INIT,
    FLASH_NOR_EXEC_DP,
    FLASH_NOR_EXEC_FLASH_SW_RESET,
    FLASH_NOR_EXEC_QUERY_INFO_LOADING,
    FLASH_NOR_EXEC_HIGH_SPEED_MODE,
    FLASH_NOR_EXEC_FLASH_CAL,
    FLASH_NOR_EXEC_FLASH_READ,
    FLASH_NOR_EXEC_FLASH_WRITE,
    FLASH_NOR_EXEC_FLASH_ERASE,

    FLASH_NOR_BASE_MASK                         = 0xF000,
} FLASH_NOR_IOCTL_TYPE;

//typedef enum
//{
//    FLASH_OCCD,
//    FLASH_BOOT_PATCH,
//    FLASH_OTA_BANK_0,
//    FLASH_OTA_BANK_1,
//    FLASH_RO_DATA1,
//    FLASH_RO_DATA2,
//    FLASH_RO_DATA3,
//    FLASH_RO_DATA4,
//    FLASH_RO_DATA5,
//    FLASH_RO_DATA6,
//    FLASH_BKP_DATA1,
//    FLASH_BKP_DATA2,
//    FLASH_OTA_TMP,
//    FLASH_FTL,
//} FLASH_LAYOUT_NAME;

/* *INDENT-OFF* */

/****************************************************************************************
 * Nor Flash Callback Definition
 ****************************************************************************************/
typedef void (*FLASH_NOR_ASYNC_CB)(void);

/****************************************************************************************
 * Nor Flash Function Prototype
 ****************************************************************************************/
/**
 * @brief           dump spic & nor flash 0 info
 * @return          none
 */
void flash_nor_dump_main_info(void);

/**
 * @brief           get nor flash 0 layout member start address
 * @param name      specify address of nor flash 0 layout member
 * @return          specific address of nor flash 0 layout member
 */
//uint32_t flash_nor_get_bank_addr(FLASH_LAYOUT_NAME name);

/**
 * @brief           get nor flash 0 layout member size
 * @param name      specify size of nor flash 0 layout member
 * @return          specific size of nor flash 0 layout member
 */
//uint32_t flash_nor_get_bank_size(FLASH_LAYOUT_NAME name);

/**
 * @brief           get specific nor flash commands and query info
 * @param idx       specific nor flash
 * @return          @ref FLASH_NOR_RET_TYPE result
 */
FLASH_NOR_RET_TYPE flash_nor_set_all_info(FLASH_NOR_IDX_TYPE idx);

/**
 * @brief           check whether requested operation is available without waiting
 * @param req       @ref FLASH_NOR_REQ_TYPE type
 * @param addr      start address of operation
 * @param len       length of operation
 * @return          true if request will be blocked, false if the request can be executed
 */
bool flash_nor_is_request_blocking(FLASH_NOR_REQ_TYPE req, uint32_t addr, uint32_t len);

/**
 * @brief           prepare calibration value in cal_addr
 * @param idx       specific nor flash
 * @param cal_addr  calibration address
 * @return          @ref FLASH_NOR_RET_TYPE result
 */
//FLASH_NOR_RET_TYPE flash_nor_set_cal_addr(FLASH_NOR_IDX_TYPE idx, uint32_t cal_addr);

/**
 * @brief           nor flash IO control get method
 * @param cmd       @ref FLASH_NOR_IOCTL_TYPE cmd
 * @param idx       specific nor flash
 * @param p1        parameter 1 based on different @ref FLASH_NOR_IOCTL_TYPE cmd
 * @param p2        parameter 2 based on different @ref FLASH_NOR_IOCTL_TYPE cmd
 * @param p3        parameter 3 based on different @ref FLASH_NOR_IOCTL_TYPE cmd
 * @return          @ref FLASH_NOR_RET_TYPE result
 */
FLASH_NOR_RET_TYPE flash_nor_ioctl_get_method(uint16_t cmd, uint16_t idx, uint32_t p1, uint32_t p2, uint32_t p3);

/**
 * @brief           nor flash IO control set method
 * @param cmd       @ref FLASH_NOR_IOCTL_TYPE cmd
 * @param idx       specific nor flash
 * @param p1        parameter 1 based on different @ref FLASH_NOR_IOCTL_TYPE cmd
 * @param p2        parameter 2 based on different @ref FLASH_NOR_IOCTL_TYPE cmd
 * @param p3        parameter 3 based on different @ref FLASH_NOR_IOCTL_TYPE cmd
 * @return          @ref FLASH_NOR_RET_TYPE result
 */
FLASH_NOR_RET_TYPE flash_nor_ioctl_set_method(uint16_t cmd, uint16_t idx, uint32_t p1, uint32_t p2, uint32_t p3);

/**
 * @brief           nor flash IO control execution method
 * @param cmd       @ref FLASH_NOR_IOCTL_TYPE cmd
 * @param idx       specific nor flash
 * @param p1        parameter 1 based on different @ref FLASH_NOR_IOCTL_TYPE cmd
 * @param p2        parameter 2 based on different @ref FLASH_NOR_IOCTL_TYPE cmd
 * @param p3        parameter 3 based on different @ref FLASH_NOR_IOCTL_TYPE cmd
 * @return          @ref FLASH_NOR_RET_TYPE result
 */
FLASH_NOR_RET_TYPE flash_nor_ioctl_exec_method(uint16_t cmd, uint16_t idx, uint32_t p1, uint32_t p2, uint32_t p3);
/****************************************************************************************
 * Nor Flash Extern Variables
 ****************************************************************************************/
extern uint8_t *flash_nor_ioctl_buf;
extern uint32_t flash_nor_ioctl_buf_len;

/**
 * @brief           task-safe of @ref flash_nor_read
 * @param addr      the ram address mapping of nor flash going to be read
 * @param data      data buffer to be read into
 * @param len       read data length
 * @return          @ref FLASH_NOR_RET_TYPE result
 */
extern FLASH_NOR_RET_TYPE(*flash_nor_read_locked)(uint32_t addr, uint8_t *data, uint32_t len);

/**
 * @brief           task-safe of @ref flash_nor_write with small data chunk slicing of each write operation inside the critical section
 * @param addr      the ram address mapping of nor flash going to be written
 * @param data      data buffer to be write into
 * @param len       write data length
 * @param slice_len write data slice length
 * @return          @ref FLASH_NOR_RET_TYPE result
 */
extern FLASH_NOR_RET_TYPE(*flash_nor_write_locked_slice)(uint32_t addr, uint8_t *data, uint32_t len, uint32_t slice_len);

/**
 * @brief           task-safe of @ref flash_nor_write
 * @param addr      the ram address mapping of nor flash going to be written
 * @param data      data buffer to be write into
 * @param len       write data length
 * @return          @ref FLASH_NOR_RET_TYPE result
 */
extern FLASH_NOR_RET_TYPE(*flash_nor_write_locked)(uint32_t addr, uint8_t *data, uint32_t len);

/**
 * @brief           task-safe of @ref flash_nor_erase
 * @param addr      the ram address mapping of nor flash going to be erased
 * @param mode      erase mode defined as @ref FLASH_NOR_ERASE_MODE
 * @return          @ref FLASH_NOR_RET_TYPE result
 */
extern FLASH_NOR_RET_TYPE(*flash_nor_erase_locked)(uint32_t addr, FLASH_NOR_ERASE_MODE mode);

/**
 * @brief           task-safe nor flash auto dma read
 * @param src       the ram address mapping of nor flash going to be read from
 * @param dst       the ram address going to be written to
 * @param len       dma data length
 * @param cb        call back function which is to be executed when dma finishing
 * @return          @ref FLASH_NOR_RET_TYPE result
 */
extern FLASH_NOR_RET_TYPE(*flash_nor_auto_dma_read_locked)(uint32_t src, uint32_t dst, uint32_t len, FLASH_NOR_ASYNC_CB cb);

///**
// * @brief           task-safe nor flash auto dma write
// * @param src       the ram address going to be read from
// * @param dst       the ram address mapping of nor flash going to be written to
// * @param len       dma data length
// * @param cb        call back function which is to be executed when dma finishing
// * @return          @ref FLASH_NOR_RET_TYPE result
// */
//extern FLASH_NOR_RET_TYPE(*flash_nor_auto_dma_write_locked)(uint32_t src, uint32_t dst, uint32_t len, FLASH_NOR_ASYNC_CB cb);

///**
// * @brief           task-safe nor flash auto dma read with sequential transaction enabled
// * @param src       the ram address mapping of nor flash going to be read from
// * @param dst       the ram address going to be written to
// * @param len       dma data length
// * @param cb        call back function which is to be executed when dma finishing
// * @return          @ref FLASH_NOR_RET_TYPE result
// */
//extern FLASH_NOR_RET_TYPE(*flash_nor_auto_seq_trans_dma_read_locked)(uint32_t src, uint32_t dst, uint32_t len, FLASH_NOR_ASYNC_CB cb);

/**
 * @brief           algorithm of finding cycles of delay to get correct data content in nor flash
 * @param cal_addr  the ram address mapping of nor flash going to be read from as calibration reference
 * @param is_cal_rd_dummy_len   boolean variable representing is to calibrate RD_DUMMY_LENGTH; if not, then calibrate IN_PHYSICAL_CYC
 * @param cfg_max   maximum configuration of cycle delay in SPIC register field
 * @param cfg_func  configuration function of cycles of delay
 * @return          @ref FLASH_NOR_RET_TYPE result
 */
//extern FLASH_NOR_RET_TYPE(*flash_nor_find_cyc_cnt)(FLASH_NOR_IDX_TYPE idx, uint32_t cal_addr, bool is_cal_rd_dummy_len, uint32_t cfg_max);

/**
 * @brief           algorithm of finding cycles of path delay of nor flash
 * @param idx       specific nor flash
 * @param cal_addr  the ram address mapping of nor flash going to be read from as calibration reference
 * @return          @ref FLASH_NOR_RET_TYPE result
 */
//extern FLASH_NOR_RET_TYPE(*flash_nor_cal_dly_cyc)(FLASH_NOR_IDX_TYPE idx, uint32_t cal_addr);

/**
 * @brief           algorithm of finding dummy cycles of nor flash
 * @param idx       specific nor flash
 * @param cal_addr  the ram address mapping of nor flash going to be read from as calibration reference
 * @param mode      the nor flash calibration bit mode
 * @return          @ref FLASH_NOR_RET_TYPE result
 */
//extern FLASH_NOR_RET_TYPE(*flash_nor_cal_dummy_cyc)(FLASH_NOR_IDX_TYPE idx, uint32_t cal_addr, FLASH_NOR_BIT_MODE mode);

/**
 * @brief           nor flash calibration in different bit mode
 * @param idx       specific nor flash
 * @param mode      nor flash bit mode
 * @return          @ref FLASH_NOR_RET_TYPE result
 */
//extern FLASH_NOR_RET_TYPE(*flash_nor_calibration)(FLASH_NOR_IDX_TYPE idx, FLASH_NOR_BIT_MODE mode);

/**
 * @brief           nor flash try high speed mode with bit mode configuration
 * @param idx       specific nor flash
 * @param bit_mode  nor flash bit mode
 * @return          @ref FLASH_NOR_RET_TYPE result
 */
extern FLASH_NOR_RET_TYPE(*flash_nor_try_high_speed_mode)(FLASH_NOR_IDX_TYPE idx, FLASH_NOR_BIT_MODE bit_mode);

/**
 * @brief               to finish busy and suspended nor flash operation in work list
 */
extern void(*flash_nor_finish_busy_and_suspended_operations)(void);

/**
 * @brief           nor flash IO control entry
 * @param cmd       @ref FLASH_NOR_IOCTL_TYPE cmd
 * @param idx       specific nor flash
 * @param p1        parameter 1 based on different @ref FLASH_NOR_IOCTL_TYPE cmd
 * @param p2        parameter 2 based on different @ref FLASH_NOR_IOCTL_TYPE cmd
 * @param p3        parameter 3 based on different @ref FLASH_NOR_IOCTL_TYPE cmd
 * @return          @ref FLASH_NOR_RET_TYPE result
 */
extern FLASH_NOR_RET_TYPE(*flash_nor_ioctl)(uint16_t cmd, uint16_t idx, uint32_t p1, uint32_t p2, uint32_t p3);

#endif
