/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     vector_table_ns_ext.h
* @brief    Non-secure Vector table extend implementaion header file
* @details
* @author   Grace
* @date     2021-9-02
* @version  v1.0
*********************************************************************************************************
*/

#include <stdbool.h>
#include "vector_table_ns.h"

bool RamVectorTableUpdate_ns_ext(VECTORn_Type v_num, IRQ_Fun isr_handler);

