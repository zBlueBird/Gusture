/**
 *****************************************************************************************
 *     Copyright(c) 2018, Realtek Semiconductor Corporation. All rights reserved.
 *****************************************************************************************
 * @file    flash_nor_device.h
 * @brief   Nor flash external API header file
 * @author  Yao-Yu
 * @date    2020-08-31
 * @version v0.1
 * ***************************************************************************************
 */

#ifndef _FLASH_NOR_DEVICE_NSC_H
#define _FLASH_NOR_DEVICE_NSC_H
#include <stdint.h>

/****************************************************************************************
 * Nor Flash Enumeration
 ****************************************************************************************/
typedef enum
{
    FLASH_OCCD,
    FLASH_BOOT_PATCH,
    FLASH_OTA_BANK_0,
    FLASH_OTA_BANK_1,
    FLASH_RO_DATA1,
    FLASH_RO_DATA2,
    FLASH_RO_DATA3,
    FLASH_RO_DATA4,
    FLASH_RO_DATA5,
    FLASH_RO_DATA6,
    FLASH_BKP_DATA1,
    FLASH_BKP_DATA2,
    FLASH_OTA_TMP,
    FLASH_FTL,

#ifndef _IS_ASIC_
    FLASH_FAKE_DSP_ROM,
#endif

    FLASH_TOTAL,
} FLASH_LAYOUT_NAME;

typedef enum
{
    FLASH_NOR_REQ_NONE          = 0x00,
    FLASH_NOR_REQ_READ          = 0x01,
    FLASH_NOR_REQ_WRITE         = 0x02,
    FLASH_NOR_REQ_RW_MASK       = 0x03,

    FLASH_NOR_REQ_ERASE_SECTOR  = 0x04,
    FLASH_NOR_REQ_ERASE_BLOCK   = 0x08,
    FLASH_NOR_REQ_ERASE_CHIP    = 0x10,
    FLASH_NOR_REQ_ERASE_MASK    = 0x1C,

    FLASH_NOR_REQ_DMA_READ      = 0x20,
    FLASH_NOR_REQ_DMA_WRITE     = 0x40,
    FLASH_NOR_REQ_DMA_MASK      = 0x60,
} FLASH_NOR_REQ_TYPE;

/* *INDENT-OFF* */

/****************************************************************************************
 * Nor Flash Function Prototype
 ****************************************************************************************/
/**
 * @brief           get nor flash 0 layout member start address
 * @param name      specify address of nor flash 0 layout member
 * @return          specific address of nor flash 0 layout member
 */
uint32_t flash_nor_get_bank_addr(FLASH_LAYOUT_NAME name);

/**
 * @brief           get nor flash 0 layout member size
 * @param name      specify size of nor flash 0 layout member
 * @return          specific size of nor flash 0 layout member
 */
uint32_t flash_nor_get_bank_size(FLASH_LAYOUT_NAME name);



#endif
