#ifndef __MBEDTLS_INTERFACE_H__
#define __MBEDTLS_INTERFACE_H__

#include "mbedtls_aes_wrapper_nsc.h"
#include "mbedtls_sha_wrapper_nsc.h"
#include "mbedtls_ecp_wrapper_nsc.h"
#include "mbedtls_bignum_wrapper_nsc.h"
#include "mbedtls_md_wrapper_nsc.h"

/* ---------------------------------------------------AES--------------------------------------------------- */
void mbedtls_aes_init(mbedtls_aes_context *ctx);

void mbedtls_aes_free(mbedtls_aes_context *ctx);

int mbedtls_aes_setkey_enc(mbedtls_aes_context *ctx, const unsigned char *key,
                           unsigned int keybits);

int mbedtls_aes_setkey_dec(mbedtls_aes_context *ctx, const unsigned char *key,
                           unsigned int keybits);

int mbedtls_aes_crypt_ecb(mbedtls_aes_context *ctx, int mode, const unsigned char input[16],
                          unsigned char output[16]);

int mbedtls_aes_crypt_cbc(mbedtls_aes_context *ctx,
                          int mode,
                          size_t length,
                          unsigned char iv[16],
                          const unsigned char *input,
                          unsigned char *output);
/* --------------------------------------------------------------------------------------------------------- */

/* ---------------------------------------------------SHA--------------------------------------------------- */
int mbedtls_sha1(const unsigned char *input, size_t ilen, unsigned char output[20]);

void mbedtls_sha1_free(mbedtls_sha1_context *ctx);

int mbedtls_sha1_starts(mbedtls_sha1_context *ctx);

int mbedtls_sha1_update(mbedtls_sha1_context *ctx, const unsigned char *input, size_t ilen);

int mbedtls_sha1_finish(mbedtls_sha1_context *ctx, unsigned char output[20]);

int mbedtls_sha256(const unsigned char *input, size_t ilen, unsigned char *output, int is224);

void mbedtls_sha256_free(mbedtls_sha256_context *ctx);

int mbedtls_sha256_starts(mbedtls_sha256_context *ctx, int is224);

int mbedtls_sha256_update(mbedtls_sha256_context *ctx, const unsigned char *input, size_t ilen);

int mbedtls_sha256_finish(mbedtls_sha256_context *ctx, unsigned char *output);
/* --------------------------------------------------------------------------------------------------------- */

/* ---------------------------------------------------ECP--------------------------------------------------- */
void mbedtls_ecp_keypair_init(mbedtls_ecp_keypair *key);

int mbedtls_ecp_group_load(mbedtls_ecp_group *grp, mbedtls_ecp_group_id id);

int mbedtls_ecp_gen_keypair(mbedtls_ecp_group *grp, mbedtls_mpi *d,
                            mbedtls_ecp_point *Q,
                            int (*f_rng)(void *, unsigned char *, size_t),
                            void *p_rng);

int mbedtls_ecdh_compute_shared(mbedtls_ecp_group *grp, mbedtls_mpi *z,
                                const mbedtls_ecp_point *Q, const mbedtls_mpi *d,
                                int (*f_rng)(void *, unsigned char *, size_t),
                                void *p_rng);
/* --------------------------------------------------------------------------------------------------------- */

/* -------------------------------------------------bignum-------------------------------------------------- */
void mbedtls_mpi_init(mbedtls_mpi *X);

int mbedtls_mpi_cmp_mpi(const mbedtls_mpi *X, const mbedtls_mpi *Y);
/* --------------------------------------------------------------------------------------------------------- */

/* ---------------------------------------------------MD---------------------------------------------------- */
void mbedtls_md5_init(mbedtls_md5_context *ctx);

int mbedtls_md5_starts(mbedtls_md5_context *ctx);

int mbedtls_md5_update(mbedtls_md5_context *ctx, const unsigned char *input, size_t ilen);

int mbedtls_md5_finish(mbedtls_md5_context *ctx, unsigned char output[16]);

void mbedtls_md5_free(mbedtls_md5_context *ctx);
/* --------------------------------------------------------------------------------------------------------- */

#endif /* __MBEDTLS_INTERFACE_H__*/
