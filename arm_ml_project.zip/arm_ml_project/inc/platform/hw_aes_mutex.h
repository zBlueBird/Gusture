#ifndef __HW_AES_MUTEX_H__
#define __HW_AES_MUTEX_H__

bool hw_aes_create_mutex(void);
void hw_aes_take_sem(void);
void hw_aes_give_sem(void);
void hw_aes_mutex_init(void);

#endif /* __HW_AES_MUTEX_H__ */
