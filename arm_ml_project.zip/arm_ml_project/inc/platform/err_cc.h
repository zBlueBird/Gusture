#ifndef _ERR_CC_H
#define _ERR_CC_H

#include "stdint.h"
#include "string.h"
#include "rtl876x.h"

#define ECC_FUNC_BASE          0x400E2240

//ECC_CTRL
#define   BIT_MANUAL_EN             0x00010000
#define   BIT_ECC_START             0x00000100
#define   BIT_DECODE_AUTO           0x00000004
#define   BIT_BCH_MODE              0x00000002
#define   BIT_ENCODE                0x00000001

//ECC_SW_CTRL
#define SW_SHIFT_PARITY_START       0x00000001
#define SW_CORRECT_START            0x00000100
#define SW_SHIFT_ERR_LOC_START      0x00010000

//ECC_STATUS
#define ECC_FSM                     0x00000007
#define ERR_NUM                     0x00007F00
#define DECODE_BLK_CNT              0x00070000
#define SHIFT_IN_FDI                0xffC00000

//ECC_ENC_DEC_STATUS
#define SHIFT_OUT_PARITY_READY      0x00000001
#define SHIFT_OUT_PARITY_DONE       0x00000002
#define SYNDROME_READY              0x00000100
#define SYNDROME_ERROR              0x00000200
#define UNCORRECT                   0x00000400
#define CORRECT_DONE_LOC_READY      0x00000800
#define SHIFT_OUT_ERR_LOC_DONE      0x00001000

//ECC_INT
#define ENC_DONE_INT_EN             0x00000001 //Encode process done; interrupt enable
#define DEC_DONE_OK_INT_EN          0x00000010 //Decode process done and there are precisely correct; interrupt enable
#define DEC_DONE_NG_INT_EN          0x00000020 //Decode process done and there are greater than ECC correct capability (Uncorrectable); interrupt enable
#define DEC_DONE_FIX_INT_EN         0x00000040
#define ENC_DONE_INTC               0x00000100
#define DEC_DONE_OK_INTC            0x00001000
#define DEC_DONE_NG_INTC            0x00002000
#define DEC_DONE_FIX_INTC           0x00004000
#define ENC_DONE_INT                0x00010000
#define DEC_DONE_OK_INT             0x00100000
#define DEC_DONE_NG_INT             0x00200000
#define DEC_DONE_FIX_INT            0x00400000
#define ENC_DONE_INTR               0x01000000
#define DEC_DONE_OK_INTR            0x10000000
#define DEC_DONE_NG_INTR            0x20000000
#define DEC_DONE_FIX_INTR           0x40000000

#define ecc_in_fdi_rd()         (ECC->STATUS & SHIFT_IN_FDI) >> 22
#define ecc_get_reg(reg, x)     (ECC->reg & x)
#define ecc_set_reg(reg, x)     (ECC->reg |= x)
#define ecc_data_reg_in(x)      (ECC->SW_FDI = x)

#define DUMMY_LENGTH            6
#define PARITY_LEN_6BIT_MODE    10
#define PARITY_LEN_12BIT_MODE   20
#define SOURCE_DATA_LEN         512

#define ECC_TEST                1
#define ECC_TEST_SW_ENC         1
#define ECC_TEST_SW_DEC         1
#define PARITY_LEN              20     //set 10 or 20

typedef enum
{
    MODE_DECODE = 0,
    MODE_ENCODE = 1,
} T_ENC_DEC_MODE;

typedef enum
{
    MODE_6BIT = 0,
    MODE_12BIT = 1,
} T_BCH_MODE;

typedef enum
{
    MODE_HW = 0,
    MODE_MANUAL = 1,
} T_MANUAL_MODE;

typedef enum
{
    ECC_DECODE_NO_ERROR,
    ECC_DECODE_DATA_IN_FAIL,
    ECC_DECODE_NOT_READY,
    ECC_DECODE_CORRECT_NOT_READY,
    ECC_DECODE_CORRECT_FAIL,
    ECC_DECODE_SHIFT_NOT_DONE,
    ECC_DECODE_CORRECT_SUCCESS,
    ECC_DECODE_DATA_LEN_INVALID,
} T_DECODE_RET;

typedef enum
{
    ECC_ENCODE_SUCCESS,
    ECC_ENCODE_DATA_IN_FAIL,
    ECC_ENCODE_NOT_READY,
    ECC_ENCODE_SHIFT_NOT_DONE,
} T_ENCODE_RET;

typedef struct
{
    uint16_t bit_num: 3;
    uint16_t byte_num: 11;
    uint16_t rsvd: 2;
} ERR_LOC_IND;

typedef struct
{
    __IO uint32_t CTRL;                       //0x00
    __IO uint32_t SW_FDI;                     //0x04
    __IO uint32_t SW_CTRL;                    //0x08
    __IO uint32_t STATUS;                     //0x0C
    __IO uint32_t ENC_DEC_STATUS;             //0x10
    __IO uint32_t DMA_FDI;                    //0x14
    __IO uint32_t RSVD[2];
    __IO uint32_t INT;                        //0x20
    __IO uint32_t ENC_PARITY1;                //0x24
    __IO uint32_t ENC_PARITY2;                //0x28
    __IO uint32_t ENC_PARITY3;                //0x2C
    __IO uint32_t ENC_PARITY4;                //0x30
    __IO uint32_t ENC_PARITY5;                //0x34
    __IO uint32_t ECO_INF[2];                 //0x38 ~ 0x3C
    __IO uint32_t DEC_SYND_1;                 //0x40 ~ 0x6C
    __IO uint32_t DEC_SYND_2;
    __IO uint32_t DEC_SYND_3;
    __IO uint32_t DEC_SYND_4;
    __IO uint32_t DEC_SYND_5;
    __IO uint32_t DEC_SYND_6;
    __IO uint32_t DEC_SYND_7;
    __IO uint32_t DEC_SYND_8;
    __IO uint32_t DEC_SYND_9;
    __IO uint32_t DEC_SYND_10;
    __IO uint32_t DEC_SYND_11;
    __IO uint32_t DEC_SYND_12;
    __IO uint32_t ERR_LOC_1;                 //0x70 ~ 0x84
    __IO uint32_t ERR_LOC_2;
    __IO uint32_t ERR_LOC_3;
    __IO uint32_t ERR_LOC_4;
    __IO uint32_t ERR_LOC_5;
    __IO uint32_t ERR_LOC_6;
    __IO uint32_t COMP_VERSION;             //0x88
} ECC_Typedef;

typedef void (* ECC_HANDLER_CALLBACK)(uint8_t error_flag);

void ecc_hw_encode_handle(uint8_t *enc_data, uint16_t data_len, T_BCH_MODE bit_mode);
void ecc_hw_decode_handle(uint8_t *dec_data, uint16_t data_len, T_BCH_MODE bit_mode);
void ecc_get_err_loc(ERR_LOC_IND *err_loc, uint8_t err_num);
void ecc_sw_encode_get_parity(uint32_t *parity, T_BCH_MODE bit_mode);
uint8_t ecc_hw_get_ret_flag(void);
void ecc_hw_reset_ret_flag(void);
void ecc_callback_reg(ECC_HANDLER_CALLBACK callback);
T_ENCODE_RET  ecc_sw_6bit_mode_encode(uint8_t *enc_data, uint32_t data_len, uint32_t *parity,
                                      uint32_t wait_cycle);
T_ENCODE_RET ecc_sw_12bit_mode_encode(uint8_t *enc_data, uint32_t data_len, uint32_t *parity,
                                      uint32_t wait_cycle);
T_DECODE_RET ecc_sw_12bit_mode_decode(uint8_t *dec_data, uint32_t data_len, uint8_t *err_num,
                                      ERR_LOC_IND *err_loc, uint32_t wait_cycle);
T_DECODE_RET ecc_sw_6bit_mode_decode(uint8_t *dec_data, uint32_t data_len, uint8_t *err_num,
                                     ERR_LOC_IND *err_loc, uint32_t wait_cycle);

#endif
