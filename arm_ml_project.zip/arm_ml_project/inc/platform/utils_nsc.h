/**
************************************************************************************************************
*               Copyright(c) 2017, Realtek Semiconductor Corporation. All rights reserved.
************************************************************************************************************
* @file     utils_nsc.h
* @brief    utility helper function for user application
* @author   lory_xu
* @date     2017-02
* @version  v1.0
*************************************************************************************************************
*/

#ifndef _UTILS_NSC_H_
#define _UTILS_NSC_H_

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*
 *                               Header Files
*============================================================================*/
#include <stdbool.h>
#if defined (__ARMCC_VERSION) && (__ARMCC_VERSION >= 6010050)
#include "cmsis_armclang.h"
#endif

#define PLATFORM_STATIC_ASSERT(condition, identifier) typedef char PALStaticAssert_##identifier[(condition) ? 1 : -1]

#define DIVIDE_AND_ROUND(dividend, divisor)     (((dividend) + ((divisor) >> 1)) / (divisor))

#define DIVIDE_AND_ROUNDUP(dividend, divisor)   (((dividend) + ((divisor) - 1)) / (divisor))

/*============================================================================*
 *                              Variables
 *============================================================================*/


/*============================================================================*
 *                              Functions
 *============================================================================*/
/** @defgroup UTILS_Exported_Functions Platform Utils Exported Functions
    * @brief
    * @{
    */

/**
 * @brief Generate random number given max number allowed
 * @param max   to specify max number that allowed
 * @return random number
 */

void NSC_dump_raw_memory_all_in_KR0(void);

void NSC_dump_raw_memory_all_in_KM0(void);

uint32_t platform_random(uint32_t max);

bool is_pmc_platform_enable(void);

bool is_bt_platform_enable(void);

bool is_lowerstack_init_ready(void);

void log_uart_hw_deinit(void);

void deinit_swd_pinmux(void);

bool get_disable_hci_flash_access(void);

bool get_disable_hci_system_access(void);

bool get_disable_hci_otp_access(void);

bool get_disable_hci_read_chip_info(void);

/** @} */ /* End of group UTILS_Exported_Functions */


/** @} */ /* End of group UTILS */

#ifdef __cplusplus
}
#endif

#endif

