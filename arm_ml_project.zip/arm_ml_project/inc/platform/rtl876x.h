
/**
 ******************************************************************************************
 *       Copyright(c) 2021, Realtek Semiconductor Corporation. All rights reserved.
 ******************************************************************************************
 * @file    rtl876x.h
 * @brief   CMSIS Cortex-M4 Peripheral Access Layer Header File for
 *          RTL876X from Realtek Semiconductor.
 * @date    2021.10.25
 * @version v1.0
 * @date    25. Oct. 2021
 * @note    Generated with SVDConv Vx.xxp
 *          from CMSIS SVD File 'RTL876X.xml' Version x.xC.
 * @par     Copyright (c) 2021 Realtek Semiconductor. All Rights Reserved.
 *          The information contained herein is property of Realtek Semiconductor.
 *          Terms and conditions of usage are described in detail in Realtek
 *          EMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *          Licensees are granted free, non-transferable use of the information. NO
 *          WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 *          the file.
 ******************************************************************************************
 * @attention
 * <h2><center>&copy; COPYRIGHT 2021 Realtek Semiconductor Corporation</center></h2>
 ******************************************************************************************
 */

#ifndef RTL876X_H
#define RTL876X_H

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup RTL876X Rtl876x
  * @brief    CMSIS Cortex-M4 peripheral access layer header file for
  *           RTL876X from Realtek Semiconductor.
  * @{
  */


/* ================================================================================ */
/* ================      Processor and Core Peripheral Section     ================ */
/* ================================================================================ */
/** @defgroup Configuration_of_CMSIS Configuration of CMSIS
  * @brief   Configuration of the armv8m mainline Processor and Core Peripherals
  * @{
  */
/* --------  Configuration of Core Peripherals  ----------------------------------- */
#define __ARMv8MML_REV            0x0001U   /* Core revision r0p1 */
#define __SAUREGION_PRESENT       1U        /* SAU regions present */
#define __MPU_PRESENT             1U        /* MPU present */
#define __VTOR_PRESENT            1U        /* VTOR present */
#define __NVIC_PRIO_BITS          3U        /* Number of Bits used for Priority Levels */
#define __Vendor_SysTickConfig    0U        /* Set to 1 if different SysTick Config is used */
#define __FPU_PRESENT             1U        /* FPU present */
#define __FPU_DP                  0U        /* single precision FPU */
#define __DSP_PRESENT             1U        /* DSP extension present */
#define __ICACHE_PRESENT          1U
#define __DCACHE_PRESENT          1U
/** @} */ /* End of group Configuration_of_CMSIS */

/* ================================================================================ */
/*                                       Types                                      */
/* ================================================================================ */
/** @defgroup RTL876x_Exported_types RTL876X Exported types
 * @{
 */
//compatible define
#define UART                            UART0

/** Brief Interrupt Number Definition */
typedef enum IRQn
{
    /* -------------------  Cortex-M4 Processor Exceptions Numbers  ------------------- */
    NonMaskableInt_IRQn           = -14,      /**< 2 Non Maskable Interrupt */
    HardFault_IRQn                = -13,      /**< 3 HardFault Interrupt */
    MemoryManagement_IRQn         = -12,      /**< 4 Memory Management Interrupt */
    BusFault_IRQn                 = -11,      /**< 5 Bus Fault Interrupt */
    UsageFault_IRQn               = -10,      /**< 6 Usage Fault Interrupt */
    SecureFault_IRQn              =  -9,      /**< 7 Secure Fault Interrupt */
    SVCall_IRQn                   =  -5,      /**< 11 SV Call Interrupt */
    DebugMonitor_IRQn             =  -4,      /**< 12 Debug Monitor Interrupt */
    PendSV_IRQn                   =  -2,      /**< 14 Pend SV Interrupt */
    SysTick_IRQn                  =  -1,      /**< 15 System Tick Interrupt */

    /* INT_NUMBER = 128 + 16 */
    System_IRQn = 0,
    KM4_WDT_IRQn,
    KM0_WDT_IRQn,
    KR0_WDT_IRQn,
    RXI300_IRQn,
    RXI300_SEC_IRQn,
    DSP_IRQn,
    D2H_IRQn,
    Peripheral_IRQn,
    GPIO_A0_IRQn,
    GPIO_A1_IRQn,
    GPIO_A_2_7_IRQn,
    GPIO_A_8_15_IRQn,
    GPIO_A_16_23_IRQn,
    GPIO_A_24_31_IRQn,
    GPIO_B_0_7_IRQn,
    GPIO_B_8_15_IRQn,
    GPIO_B_16_23_IRQn,
    GPIO_B_24_31_IRQn,
    GPIO_C_0_7_IRQn,
    GPIO_C_8_15_IRQn,
    GPIO_C_16_23_IRQn,
    GPIO_C_24_31_IRQn,
    GPIO_D_0_7_IRQn,
    GPIO_D_8_15_IRQn,
    GPIO_D_16_23_IRQn,
    GPIO_D_24_31_IRQn,
    GDMA1_Channel0_IRQn,
    GDMA1_Channel1_IRQn,
    GDMA1_Channel2_IRQn,
    GDMA1_Channel3_IRQn,
    GDMA1_Channel4_IRQn,
    GDMA1_Channel5_IRQn,
    GDMA1_Channel6_IRQn,
    GDMA1_Channel7_IRQn,
    GDMA2_Channel0_IRQn,
    GDMA2_Channel1_IRQn,
    GDMA2_Channel2_IRQn,
    GDMA2_Channel3_IRQn,
    GDMA2_Channel4_IRQn,
    GDMA2_Channel5_IRQn,
    GDMA2_Channel6_IRQn,
    GDMA2_Channel7_IRQn,
    GDMA2_Channel8_IRQn,
    GDMA2_Channel9_IRQn,
    GDMA2_Channel10_IRQn,
    GDMA2_Channel11_IRQn,
    GDMA2_Channel12_IRQn,
    GDMA2_Channel13_IRQn,
    GDMA2_Channel14_IRQn,
    GDMA2_Channel15_IRQn,
    SPI0_IRQn,
    SPI1_IRQn,
    SPI2_IRQn,
    SPI3_IRQn,
    I2C0_IRQn,
    I2C1_IRQn,
    I2C2_IRQn,
    I2C3_IRQn,
    UART2_IRQn,
    UART3_IRQn,
    UART4_IRQn,
    UART5_IRQn,
    UART6_IRQn,
    Timer_B0_IRQn,
    Timer_B1_IRQn,
    Timer_B2_IRQn,
    Timer_B3_IRQn,
    Timer_C0_IRQn,
    Timer_C1_IRQn,
    Timer_C2_IRQn,
    Timer_C3_IRQn,
    Timer_C4_IRQn,
    Timer_C5_IRQn,
    Enhanced_Timer0_IRQn,
    Enhanced_Timer1_IRQn,
    Enhanced_Timer2_IRQn,
    Enhanced_Timer3_IRQn,
    Enhanced_Timer4_IRQn,
    Enhanced_Timer5_IRQn,
    Enhanced_Timer6_IRQn,
    Enhanced_Timer7_IRQn,
    ADC_IRQn,
    KEYSCAN_IRQn,
    QDECODE_IRQn,
    ISO7816_IRQn,
    IR_IRQn,
    Public_Key_Engine_IRQn,
    Flash_SEC0_IRQn,
    Flash_SEC1_IRQn,
    SHA2_IRQn,
    SHA3_IRQn,
    SPORT0_RX_IRQn,
    SPORT0_TX_IRQn,
    SPORT1_RX_IRQn,
    SPORT1_TX_IRQn,
    SPORT2_RX_IRQn,
    SPORT2_TX_IRQn,
    SPORT3_RX_IRQn,
    SPORT3_TX_IRQn,
    ASRC0_IRQn,
    ASRC1_IRQn,
    VADBUF_IRQn,
    VAD_IRQn,
    COMP_CLK4_IRQn,
    COMP_CLK5_IRQn,
    COMP_CLK9_IRQn,
    COMP_CLK10_IRQn,
    USB_IRQn,
    USB_ISO_IRQn,
    USB_UTMI_SUSPEND_N_IRQn,
    SDIO0_IRQn,
    SDIO1_IRQn,
    GPU_IRQn,
    RTC_IRQn,
    MIPI_IRQn,
    Display_IRQn,
    IPC_KR0_IRQn,
    IPC_KM0_IRQn,
    ECC_IRQn,
    Slave_Port_Monitor_IRQn,
    SPI_Slave_IRQn,
    LOG_KR0_IRQn,
    LOG_KM0_IRQn,
    AON_QDEC_IRQn,
    GDMA0_Channel0_IRQn,
    GDMA0_Channel1_IRQn,
    GDMA0_Channel2_IRQn,

    /* second level interrupt (Peripheral_IRQn) */
    SPIC0_IRQn,
    SPIC1_IRQn,
    SPIC2_IRQn,
    SPIC3_IRQn,
    TRNG_IRQn,
    MAE_IRQn,
    LPCOMP_IRQn,
    SPI_PHY0_IRQn,
    SPI_PHY12_IRQn,
    SPI_PHY3_IRQn,

    /* second level interrupt (DSP_IRQn), not directly connect to NVIC */
    DSP_Report_IRQn,
    DSP_RX_REQ_IRQn,
    DSP_TX_ACK_IRQn,
    DSP_WDT_IRQn,
    BT_SYNC_CLK_IRQn,
    DSP_TO_HOST_FAST_IRQn,
    DSP_TO_HOST_IRQn,
    DSP_Event_1_IRQn,
    DSP_Event_2_IRQn,

    /* second level interrupt (D2H_IRQn), not directly connect to NVIC */
    D2H_INT0_IRQn,
    D2H_INT1_IRQn,
    D2H_INT2_IRQn,
    D2H_INT3_IRQn,
    D2H_INT4_IRQn,
    D2H_INT5_IRQn,
    D2H_INT6_IRQn,
    D2H_INT7_IRQn,
} IRQn_Type, *PIRQn_Type;

#define Peripheral_First_IRQn    SPIC0_IRQn
#define Peripheral_Last_IRQn     SPI_PHY3_IRQn

#define DSP_First_IRQn           DSP_Report_IRQn
#define DSP_Last_IRQn            DSP_Event_2_IRQn

#define D2H_First_IRQn           D2H_INT0_IRQn
#define D2H_Last_IRQn            D2H_INT7_IRQn

#define GPIOA0_IRQn              GPIO_A0_IRQn
#define GPIOA1_IRQn              GPIO_A1_IRQn
#define GPIOA2_IRQn              GPIO_A_2_7_IRQn
#define GPIOA3_IRQn              GPIO_A_2_7_IRQn
#define GPIOA4_IRQn              GPIO_A_2_7_IRQn
#define GPIOA5_IRQn              GPIO_A_2_7_IRQn
#define GPIOA6_IRQn              GPIO_A_2_7_IRQn
#define GPIOA7_IRQn              GPIO_A_2_7_IRQn
#define GPIOA8_IRQn              GPIO_A_8_15_IRQn
#define GPIOA9_IRQn              GPIO_A_8_15_IRQn
#define GPIOA10_IRQn             GPIO_A_8_15_IRQn
#define GPIOA11_IRQn             GPIO_A_8_15_IRQn
#define GPIOA12_IRQn             GPIO_A_8_15_IRQn
#define GPIOA13_IRQn             GPIO_A_8_15_IRQn
#define GPIOA14_IRQn             GPIO_A_8_15_IRQn
#define GPIOA15_IRQn             GPIO_A_8_15_IRQn
#define GPIOA16_IRQn             GPIO_A_16_23_IRQn
#define GPIOA17_IRQn             GPIO_A_16_23_IRQn
#define GPIOA18_IRQn             GPIO_A_16_23_IRQn
#define GPIOA19_IRQn             GPIO_A_16_23_IRQn
#define GPIOA20_IRQn             GPIO_A_16_23_IRQn
#define GPIOA21_IRQn             GPIO_A_16_23_IRQn
#define GPIOA22_IRQn             GPIO_A_16_23_IRQn
#define GPIOA23_IRQn             GPIO_A_16_23_IRQn
#define GPIOA24_IRQn             GPIO_A_24_31_IRQn
#define GPIOA25_IRQn             GPIO_A_24_31_IRQn
#define GPIOA26_IRQn             GPIO_A_24_31_IRQn
#define GPIOA27_IRQn             GPIO_A_24_31_IRQn
#define GPIOA28_IRQn             GPIO_A_24_31_IRQn
#define GPIOA29_IRQn             GPIO_A_24_31_IRQn
#define GPIOA30_IRQn             GPIO_A_24_31_IRQn
#define GPIOA31_IRQn             GPIO_A_24_31_IRQn

#define GPIOB0_IRQn              GPIO_B_0_7_IRQn
#define GPIOB1_IRQn              GPIO_B_0_7_IRQn
#define GPIOB2_IRQn              GPIO_B_0_7_IRQn
#define GPIOB3_IRQn              GPIO_B_0_7_IRQn
#define GPIOB4_IRQn              GPIO_B_0_7_IRQn
#define GPIOB5_IRQn              GPIO_B_0_7_IRQn
#define GPIOB6_IRQn              GPIO_B_0_7_IRQn
#define GPIOB7_IRQn              GPIO_B_0_7_IRQn
#define GPIOB8_IRQn              GPIO_B_8_15_IRQn
#define GPIOB9_IRQn              GPIO_B_8_15_IRQn
#define GPIOB10_IRQn             GPIO_B_8_15_IRQn
#define GPIOB11_IRQn             GPIO_B_8_15_IRQn
#define GPIOB12_IRQn             GPIO_B_8_15_IRQn
#define GPIOB13_IRQn             GPIO_B_8_15_IRQn
#define GPIOB14_IRQn             GPIO_B_8_15_IRQn
#define GPIOB15_IRQn             GPIO_B_8_15_IRQn
#define GPIOB16_IRQn             GPIO_B_16_23_IRQn
#define GPIOB17_IRQn             GPIO_B_16_23_IRQn
#define GPIOB18_IRQn             GPIO_B_16_23_IRQn
#define GPIOB19_IRQn             GPIO_B_16_23_IRQn
#define GPIOB20_IRQn             GPIO_B_16_23_IRQn
#define GPIOB21_IRQn             GPIO_B_16_23_IRQn
#define GPIOB22_IRQn             GPIO_B_16_23_IRQn
#define GPIOB23_IRQn             GPIO_B_16_23_IRQn
#define GPIOB24_IRQn             GPIO_B_24_31_IRQn
#define GPIOB25_IRQn             GPIO_B_24_31_IRQn
#define GPIOB26_IRQn             GPIO_B_24_31_IRQn
#define GPIOB27_IRQn             GPIO_B_24_31_IRQn
#define GPIOB28_IRQn             GPIO_B_24_31_IRQn
#define GPIOB29_IRQn             GPIO_B_24_31_IRQn
#define GPIOB30_IRQn             GPIO_B_24_31_IRQn
#define GPIOB31_IRQn             GPIO_B_24_31_IRQn

#define GPIOC0_IRQn              GPIO_C_0_7_IRQn
#define GPIOC1_IRQn              GPIO_C_0_7_IRQn
#define GPIOC2_IRQn              GPIO_C_0_7_IRQn
#define GPIOC3_IRQn              GPIO_C_0_7_IRQn
#define GPIOC4_IRQn              GPIO_C_0_7_IRQn
#define GPIOC5_IRQn              GPIO_C_0_7_IRQn
#define GPIOC6_IRQn              GPIO_C_0_7_IRQn
#define GPIOC7_IRQn              GPIO_C_0_7_IRQn
#define GPIOC8_IRQn              GPIO_C_8_15_IRQn
#define GPIOC9_IRQn              GPIO_C_8_15_IRQn
#define GPIOC10_IRQn             GPIO_C_8_15_IRQn
#define GPIOC11_IRQn             GPIO_C_8_15_IRQn
#define GPIOC12_IRQn             GPIO_C_8_15_IRQn
#define GPIOC13_IRQn             GPIO_C_8_15_IRQn
#define GPIOC14_IRQn             GPIO_C_8_15_IRQn
#define GPIOC15_IRQn             GPIO_C_8_15_IRQn
#define GPIOC16_IRQn             GPIO_C_16_23_IRQn
#define GPIOC17_IRQn             GPIO_C_16_23_IRQn
#define GPIOC18_IRQn             GPIO_C_16_23_IRQn
#define GPIOC19_IRQn             GPIO_C_16_23_IRQn
#define GPIOC20_IRQn             GPIO_C_16_23_IRQn
#define GPIOC21_IRQn             GPIO_C_16_23_IRQn
#define GPIOC22_IRQn             GPIO_C_16_23_IRQn
#define GPIOC23_IRQn             GPIO_C_16_23_IRQn
#define GPIOC24_IRQn             GPIO_C_24_31_IRQn
#define GPIOC25_IRQn             GPIO_C_24_31_IRQn
#define GPIOC26_IRQn             GPIO_C_24_31_IRQn
#define GPIOC27_IRQn             GPIO_C_24_31_IRQn
#define GPIOC28_IRQn             GPIO_C_24_31_IRQn
#define GPIOC29_IRQn             GPIO_C_24_31_IRQn
#define GPIOC30_IRQn             GPIO_C_24_31_IRQn
#define GPIOC31_IRQn             GPIO_C_24_31_IRQn

#define GPIOD0_IRQn              GPIO_D_0_7_IRQn
#define GPIOD1_IRQn              GPIO_D_0_7_IRQn
#define GPIOD2_IRQn              GPIO_D_0_7_IRQn
#define GPIOD3_IRQn              GPIO_D_0_7_IRQn
#define GPIOD4_IRQn              GPIO_D_0_7_IRQn
#define GPIOD5_IRQn              GPIO_D_0_7_IRQn
#define GPIOD6_IRQn              GPIO_D_0_7_IRQn
#define GPIOD7_IRQn              GPIO_D_0_7_IRQn
#define GPIOD8_IRQn              GPIO_D_8_15_IRQn
#define GPIOD9_IRQn              GPIO_D_8_15_IRQn
#define GPIOD10_IRQn             GPIO_D_8_15_IRQn
#define GPIOD11_IRQn             GPIO_D_8_15_IRQn
#define GPIOD12_IRQn             GPIO_D_8_15_IRQn
#define GPIOD13_IRQn             GPIO_D_8_15_IRQn
#define GPIOD14_IRQn             GPIO_D_8_15_IRQn
#define GPIOD15_IRQn             GPIO_D_8_15_IRQn
#define GPIOD16_IRQn             GPIO_D_16_23_IRQn
#define GPIOD17_IRQn             GPIO_D_16_23_IRQn
#define GPIOD18_IRQn             GPIO_D_16_23_IRQn
#define GPIOD19_IRQn             GPIO_D_16_23_IRQn
#define GPIOD20_IRQn             GPIO_D_16_23_IRQn
#define GPIOD21_IRQn             GPIO_D_16_23_IRQn
#define GPIOD22_IRQn             GPIO_D_16_23_IRQn
#define GPIOD23_IRQn             GPIO_D_16_23_IRQn
#define GPIOD24_IRQn             GPIO_D_24_31_IRQn
#define GPIOD25_IRQn             GPIO_D_24_31_IRQn
#define GPIOD26_IRQn             GPIO_D_24_31_IRQn
#define GPIOD27_IRQn             GPIO_D_24_31_IRQn
#define GPIOD28_IRQn             GPIO_D_24_31_IRQn
#define GPIOD29_IRQn             GPIO_D_24_31_IRQn
#define GPIOD30_IRQn             GPIO_D_24_31_IRQn
#define GPIOD31_IRQn             GPIO_D_24_31_IRQn

/** @} */ /* End of group RTL876x_Exported_types */

/*============================================================================*
 *                               Header Files
*============================================================================*/
#include "core_armv81mml.h"                       /* Processor and core peripherals */

/* ================================================================================ */
/* ================                      Types                     ================ */
/* ================================================================================ */
/** @addtogroup RTL876x_Exported_types RTL876X Exported types
  * @{
  */

typedef enum
{
    RESET = 0,
    SET = !RESET
} FlagStatus, ITStatus;

typedef enum
{
    DISABLE = 0,
    ENABLE = !DISABLE
} FunctionalState;

#define IS_FUNCTIONAL_STATE(STATE) (((STATE) == DISABLE) || ((STATE) == ENABLE))
//typedef enum {ERROR = 0, SUCCESS = !ERROR} ErrorStatus;

/** @} */ /* End of group RTL876x_Exported_types */

/* ================================================================================ */
/* ================               RTL876X Pin Number               ================ */
/* ================================================================================ */
/** @defgroup RTL876X_Pin_Number RTL876X Pin Number
  * @{
  */
/* reference: Bee3Pro_RLE1155_pin-mux_table_v6_20211213.xls
 *            Bee3pro_PERI-ON_20211214_draft.xlsx
 */
#define TOTAL_PIN_NUM       186
#define MAX_PIN_NUM         187

#define P0_0        0       /*!< GPIOA0  DSP_GPIO0  */
#define P0_1        1       /*!< GPIOA1  DSP_GPIO1  */
#define P0_2        2       /*!< GPIOA2  DSP_GPIO2  */
#define P0_3        3       /*!< GPIOA3  DSP_GPIO3  */
#define P0_4        4       /*!< GPIOA4  DSP_GPIO4  */
#define P0_5        5       /*!< GPIOA5  DSP_GPIO5  */
#define P0_6        6       /*!< GPIOA6  DSP_GPIO6  */
#define P0_7        7       /*!< GPIOA7  DSP_GPIO7  */

#define P1_0        8       /*!< GPIOA8  DSP_GPIO8  */
#define P1_1        9       /*!< GPIOA9  DSP_GPIO9  */
#define P1_2        10      /*!< GPIOA10 DSP_GPIO10 */
#define P1_3        11      /*!< GPIOA11 DSP_GPIO11 */
#define P1_4        12      /*!< GPIOA12 DSP_GPIO12 */
#define P1_5        13      /*!< GPIOA13 DSP_GPIO13 */
#define P1_6        14      /*!< GPIOA14 DSP_GPIO14 */
#define P1_7        15      /*!< GPIOA15 DSP_GPIO15 */

#define P2_0        16      /*!< GPIOC0 DSP_TIE_GPIO16 */
#define P2_1        17      /*!< GPIOC1 DSP_TIE_GPIO17 */
#define P2_2        18      /*!< GPIOC2 DSP_TIE_GPIO18 */
#define P2_3        19      /*!< GPIOC3 DSP_TIE_GPIO19 */
#define P2_4        20      /*!< GPIOC4 DSP_TIE_GPIO20 */
#define P2_5        21      /*!< GPIOC5 DSP_TIE_GPIO21 */
#define P2_6        22      /*!< GPIOC6 DSP_TIE_GPIO22 */
#define P2_7        23      /*!< GPIOC7 DSP_TIE_GPIO23 */

#define P3_0        24      /*!< GPIOC8 DSP_TIE_GPIO24 */
#define P3_1        25      /*!< GPIOC9 DSP_TIE_GPIO25 */
#define P3_2        26      /*!< GPIOC10 DSP_TIE_GPIO26 */
#define P3_3        27      /*!< GPIOC11 DSP_TIE_GPIO27 */
#define P3_4        28      /*!< GPIOC12 DSP_TIE_GPIO28 */
#define P3_5        29      /*!< GPIOC13 DSP_TIE_GPIO29 */
#define P3_6        30      /*!< GPIOC14 DSP_TIE_GPIO30 */
#define P3_7        31      /*!< GPIOC15 DSP_TIE_GPIO31 */

#define P4_0        32      /*!< GPIOC16  DSP_GPIO0  */
#define P4_1        33      /*!< GPIOC17  DSP_GPIO1  */
#define P4_2        34      /*!< GPIOC18  DSP_GPIO2  */
#define P4_3        35      /*!< GPIOC19  DSP_GPIO3  */
#define P4_4        36      /*!< GPIOC20  DSP_GPIO4  */
#define P4_5        37      /*!< GPIOC21  DSP_GPIO5  */
#define P4_6        38      /*!< GPIOC22  DSP_GPIO6  */
#define P4_7        39      /*!< GPIOC23  DSP_GPIO7  */

#define P5_0        40      /*!< GPIOB16  DSP_GPIO16  */
#define P5_1        41      /*!< GPIOB17  DSP_GPIO17  */
#define P5_2        42      /*!< GPIOB18  DSP_GPIO18 */
#define P5_3        43      /*!< GPIOB19  DSP_GPIO19 */
#define P5_4        44      /*!< GPIOB20  DSP_GPIO20 */
#define P5_5        45      /*!< GPIOB21  DSP_GPIO21 */
#define P5_6        46      /*!< GPIOB22  DSP_GPIO22 */
#define P5_7        47      /*!< GPIOB23  DSP_GPIO23 */

#define P6_0        48      /*!< GPIOA24 DSP_GPIO24 */
#define P6_1        49      /*!< GPIOA25 DSP_GPIO25 */
#define P6_2        50      /*!< GPIOA26 DSP_GPIO26 */
#define P6_3        51      /*!< GPIOA27 DSP_GPIO27 */
#define P6_4        52      /*!< GPIOA28 DSP_GPIO28 */
#define P6_5        53      /*!< GPIOA29 DSP_GPIO29 */
#define P6_6        54      /*!< GPIOA30 DSP_GPIO30 */
#define P6_7        55      /*!< GPIOA31 DSP_GPIO31 */

#define P7_0        56      /*!< GPIOB0 DSP_GPIO0 */
#define P7_1        57      /*!< GPIOB1 DSP_GPIO1 */
#define P7_2        58      /*!< GPIOB2 DSP_GPIO2 */
#define P7_3        59      /*!< GPIOB3 DSP_GPIO3 */
#define P7_4        60      /*!< GPIOB4 DSP_GPIO4 */
#define P7_5        61      /*!< GPIOB5 DSP_GPIO5 */
#define P7_6        62      /*!< GPIOB6 DSP_GPIO6 */
#define P7_7        63      /*!< GPIOB7 DSP_GPIO7 */

#define P8_0        64      /*!< GPIOB8   DSP_GPIO8  */
#define P8_1        65      /*!< GPIOB9   DSP_GPIO9  */
#define P8_2        66      /*!< GPIOB10  DSP_GPIO10 */
#define P8_3        67      /*!< GPIOB11  DSP_GPIO11 */
#define P8_4        68      /*!< GPIOB12  DSP_GPIO12 */
#define P8_5        69      /*!< GPIOB13  DSP_GPIO13 */
#define P8_6        70      /*!< GPIOB14  DSP_GPIO14 */
#define P8_7        71      /*!< GPIOB15  DSP_GPIO15 */

#define P9_0        72      /*!< GPIOC0  DSP_GPIO8  */
#define P9_1        73      /*!< GPIOC1  DSP_GPIO9  */
#define P9_2        74      /*!< GPIOC2 DSP_GPIO10 */
#define P9_3        75      /*!< GPIOC3 DSP_GPIO11 */
#define P9_4        76      /*!< GPIOC4 DSP_GPIO12 */
#define P9_5        77      /*!< GPIOC5 DSP_GPIO13 */
#define P9_6        78      /*!< GPIOC6 DSP_GPIO14 */
#define P9_7        79      /*!< GPIOC7 DSP_GPIO15 */

#define P10_0       80      /*!< GPIOC8 DSP_GPIO16 */
#define P10_1       81      /*!< GPIOC9 DSP_GPIO17 */
#define P10_2       82      /*!< GPIOC10 DSP_GPIO18 */
#define P10_3       83      /*!< GPIOC11 DSP_GPIO19 */
#define P10_4       84      /*!< GPIOC12 DSP_GPIO20 */
#define P10_5       85      /*!< GPIOC13 DSP_GPIO21 */
#define P10_6       86      /*!< GPIOC14 DSP_GPIO22 */
#define P10_7       87      /*!< GPIOC15 DSP_GPIO23 */

#define P11_0       88      /*!< GPIOC16 DSP_GPIO24 */
#define P11_1       89      /*!< GPIOC17 DSP_GPIO25 */
#define P11_2       90      /*!< GPIOC18 DSP_GPIO26 */
#define P11_3       91      /*!< GPIOC19 DSP_GPIO27 */
#define P11_4       92      /*!< GPIOC20 DSP_GPIO28 */
#define P11_5       93      /*!< GPIOC21 DSP_GPIO29 */
#define P11_6       94      /*!< GPIOC22 DSP_GPIO30 */
#define P11_7       95      /*!< GPIOC23 DSP_GPIO31 */

#define P12_0       96      /*!< GPIOC24 DSP_TIE_GPIO0  */
#define P12_1       97      /*!< GPIOC25 DSP_TIE_GPIO1  */
#define P12_2       98      /*!< GPIOC26 DSP_TIE_GPIO2  */
#define P12_3       99      /*!< GPIOC27 DSP_TIE_GPIO3  */
#define P12_4       100     /*!< GPIOC28 DSP_TIE_GPIO4  */
#define P12_5       101     /*!< GPIOC29 DSP_TIE_GPIO5  */
#define P12_6       102     /*!< GPIOC30 DSP_TIE_GPIO6  */
#define P12_7       103     /*!< GPIOC31 DSP_TIE_GPIO7  */

#define P13_0       104     /*!< GPIOD0  DSP_TIE_GPIO8   */
#define P13_1       105     /*!< GPIOD1  DSP_TIE_GPIO9   */
#define P13_2       106     /*!< GPIOD2  DSP_TIE_GPIO10  */
#define P13_3       107     /*!< GPIOD3  DSP_TIE_GPIO11  */
#define P13_4       108     /*!< GPIOD4  DSP_TIE_GPIO12  */
#define P13_5       109     /*!< GPIOD5  DSP_TIE_GPIO13  */
#define P13_6       110     /*!< GPIOD6  DSP_TIE_GPIO14  */
#define P13_7       111     /*!< GPIOD7  DSP_TIE_GPIO15  */

#define P14_0       112     /*!< GPIOD8  DSP_TIE_GPIO16 */
#define P14_1       113     /*!< GPIOD9  DSP_TIE_GPIO17 */
#define P14_2       114     /*!< GPIOD10 DSP_TIE_GPIO18 */
#define P14_3       115     /*!< GPIOD11 DSP_TIE_GPIO19 */
#define P14_4       116     /*!< GPIOD12 DSP_TIE_GPIO20 */
#define P14_5       117     /*!< GPIOD13 DSP_TIE_GPIO21 */
#define P14_6       118     /*!< GPIOD14 DSP_TIE_GPIO22 */
#define P14_7       119     /*!< GPIOD15 DSP_TIE_GPIO23 */

#define P15_0       120     /*!< GPIOD16 DSP_TIE_GPIO24 */
#define P15_1       121     /*!< GPIOD17 DSP_TIE_GPIO25 */
#define P15_2       122     /*!< GPIOD18 DSP_TIE_GPIO26 */
#define P15_3       123     /*!< GPIOD19 DSP_TIE_GPIO27 */
#define P15_4       124     /*!< GPIOD20 DSP_TIE_GPIO28 */
#define P15_5       125     /*!< GPIOD21 DSP_TIE_GPIO29 */
#define P15_6       126     /*!< GPIOD22 DSP_TIE_GPIO30 */
#define P15_7       127     /*!< GPIOD23 DSP_TIE_GPIO31 */

#define P16_0       128     /*!< GPIOD24 DSP_TIE_GPIO0 */
#define P16_1       129     /*!< GPIOD25 DSP_TIE_GPIO1 */
#define P16_2       130     /*!< GPIOD26 DSP_TIE_GPIO3 */
#define P16_3       131     /*!< GPIOD27 DSP_TIE_GPIO3 */
#define P16_4       132     /*!< GPIOD28 DSP_TIE_GPIO4 */
#define P16_5       133     /*!< GPIOD29 DSP_TIE_GPIO5 */
#define P16_6       134     /*!< GPIOD30 DSP_TIE_GPIO6 */
#define P16_7       135     /*!< GPIOD31 DSP_TIE_GPIO7 */

#define DAC1_P      136     /*!< DAC1_P GPIOB4  */
#define DAC1_N      137     /*!< DAC1_N GPIOB5  */
#define DAC2_P      138     /*!< DAC2_P GPIOB6  */
#define DAC2_N      139     /*!< DAC2_N GPIOB7  */

#define MIC1_P      140     /*!< MIC1_P GPIOA0  */
#define MIC1_N      141     /*!< MIC1_N GPIOA1  */
#define MIC2_P      142     /*!< MIC2_P GPIOB0  */
#define MIC2_N      143     /*!< MIC2_N GPIOB1  */
#define MIC3_P      144     /*!< MIC3_P GPIOB2  */
#define MIC3_N      145     /*!< MIC3_N GPIOB3  */

#define P17_0       148     /*!< GPIOD24 DSP_TIE_GPIO7  */
#define P17_1       149     /*!< GPIOD25 DSP_TIE_GPIO8  */
#define P17_2       150     /*!< GPIOD26 DSP_TIE_GPIO9  */
#define P17_3       151     /*!< GPIOD27 DSP_TIE_GPIO10 */
#define P17_4       152     /*!< GPIOD28 DSP_TIE_GPIO11 */
#define P17_5       153     /*!< GPIOD29 DSP_TIE_GPIO12 */
#define P17_6       154     /*!< GPIOD30 DSP_TIE_GPIO13 */
#define P17_7       155     /*!< GPIOD31 DSP_TIE_GPIO14 */

#define P18_0       156     /*!< GPIOA16 DSP_GPIO16 */
#define P18_1       157     /*!< GPIOA17 DSP_GPIO17 */
#define P18_2       158     /*!< GPIOA18 DSP_GPIO18 */
#define P18_3       159     /*!< GPIOA19 DSP_GPIO19 */
#define P18_4       160     /*!< GPIOA20 DSP_GPIO20 */
#define P18_5       161     /*!< GPIOA21 DSP_GPIO21 */
#define P18_6       162     /*!< GPIOA22 DSP_GPIO22 */
#define P18_7       163     /*!< GPIOA23 DSP_GPIO23 */

#define P19_0       164     /*!< GPIOB24 DSP_GPIO24 */
#define P19_1       165     /*!< GPIOB25 DSP_GPIO25 */
#define P19_2       166     /*!< GPIOB26 DSP_GPIO26 */
#define P19_3       167     /*!< GPIOB27 DSP_GPIO27 */
#define P19_4       168     /*!< GPIOB28 DSP_GPIO28 */
#define P19_5       169     /*!< GPIOB29 DSP_GPIO29 */
#define P19_6       170     /*!< GPIOB30 DSP_GPIO30 */
#define P19_7       171     /*!< GPIOB31 DSP_GPIO31 */

#define P20_0       172     /*!< GPIOC24 DSP_GPIO24 */
#define P20_1       173     /*!< GPIOC25 DSP_GPIO25 */
#define P20_2       174     /*!< GPIOC26 DSP_GPIO26 */
#define P20_3       175     /*!< GPIOC27 DSP_GPIO27 */
#define P20_4       176     /*!< GPIOC28 DSP_GPIO28 */
#define P20_5       177     /*!< GPIOC29 DSP_GPIO29 */
#define P20_6       178     /*!< GPIOC30 DSP_GPIO30 */
#define P20_7       179     /*!< GPIOC31 DSP_GPIO31 */
#define SPIC0_CSN   180
#define SPIC0_CLK   181
#define SPIC0_SIO0  182
#define SPIC0_SIO1  183
#define SPIC0_SIO2  184
#define SPIC0_SIO3  185
#define BOOT_SEL_PAD 186

#define ADC_0       P0_0    /*!< GPIOA0  DSP_GPIO0  */
#define ADC_1       P0_1    /*!< GPIOA1  DSP_GPIO1  */
#define ADC_2       P0_2    /*!< GPIOA2  DSP_GPIO2  */
#define ADC_3       P0_3    /*!< GPIOA3  DSP_GPIO3  */
#define ADC_4       P0_4    /*!< GPIOA4  DSP_GPIO4  */
#define ADC_5       P0_5    /*!< GPIOA5  DSP_GPIO5  */
#define ADC_6       P0_6    /*!< GPIOA6  DSP_GPIO6  */
#define ADC_7       P0_7    /*!< GPIOA7  DSP_GPIO7  */
#define ADC_8       P1_0    /*!< GPIOA8  DSP_GPIO8  */
#define ADC_9       P1_1    /*!< GPIOA9  DSP_GPIO9  */
#define ADC_10      P1_2    /*!< GPIOA10 DSP_GPIO10 */
#define ADC_11      P1_3    /*!< GPIOA11 DSP_GPIO11 */
#define ADC_12      P1_4    /*!< GPIOA12 DSP_GPIO12 */
#define ADC_13      P1_5    /*!< GPIOA13 DSP_GPIO13 */
#define ADC_14      P1_6    /*!< GPIOA14 DSP_GPIO14 */
#define ADC_15      P1_7    /*!< GPIOA15 DSP_GPIO15 */
/** @} */ /* End of group RTL876X_Pin_Number */

/* ================================================================================ */
/* ================     Peripheral Registers Structures Section    ================ */
/* ================================================================================ */
/** @defgroup RTL876X_Peripheral_Registers_Structures RTL876X Peripheral Register Structure
  * @{
  */
typedef enum
{
    LOG_CHANNEL_UART2,
    LOG_CHANNEL_UART3,
    LOG_CHANNEL_UART4
} LogChannel_TypeDef;

/* ================================================================================ */
/* ================    Peripheral Block Control Peripheral Clock   ================ */
/* ================================================================================ */

/**
  * @brief Peripheral Block Control Peripheral Clock. (PERI_BLKCTRL_PERI_CLK), PERIBLKCTRL_PERICLK_REG_BASE
  */
/* reference: Bee3pro_PERI-ON_20220705_draft_v1.xlsx */
typedef struct
{
    union
    {
        __IO uint32_t REG_PERI_SPIC0_CTL;
        struct
        {
            __IO uint32_t r_spic0_div_sel: 4;
            __IO uint32_t r_spic0_div_en: 1;
            __IO uint32_t r_SPIC0_CLK_SRC_EN: 1;
            __IO uint32_t RESERVED_2: 1;
            __IO uint32_t r_spic0_clk_src_sel_0: 1;
            __IO uint32_t r_spic0_mux_1_clk_cg_en: 1;
            __IO uint32_t r_spic0_pll_src_sel_0: 1;
            __IO uint32_t r_spic0_pll_src_sel_1: 1;
            __IO uint32_t RESERVED_1: 5;
            __IO uint32_t r_flash0_phy_clk_sel: 2;
            __IO uint32_t r_flash0_clk_inv_en: 1;
            __IO uint32_t r_PON_DLYSEL_SPIC0: 8;
            __IO uint32_t spic0_phy_func_en: 1;
            __IO uint32_t spic0_phy_str_en: 1;
            __IO uint32_t RESERVED_0: 1;
            __IO uint32_t spic0_ck_en: 1;
            __IO uint32_t spic0_func_en: 1;
        } BITS_100;
    } u_100;

    __IO uint32_t REG_SPIC0_PHY_CTRL0;

    __IO uint32_t REG_SPIC0_PHY_CTRL1;

    __IO uint32_t REG_SPIC0_PHY_CTRL2;

    __IO uint32_t REG_SPIC0_PHY_CTRL3;

    union
    {
        __IO uint32_t REG_PERI_SPIC1_CTL;
        struct
        {
            __IO uint32_t r_spic1_div_sel: 4;
            __IO uint32_t r_spic1_div_en: 1;
            __IO uint32_t r_SPIC1_CLK_SRC_EN: 1;
            __IO uint32_t RESERVED_2: 1;
            __IO uint32_t r_spic1_clk_src_sel_0: 1;
            __IO uint32_t r_spic1_mux_1_clk_cg_en: 1;
            __IO uint32_t r_spic1_pll_src_sel_0: 1;
            __IO uint32_t r_spic1_pll_src_sel_1: 1;
            __IO uint32_t RESERVED_1: 5;
            __IO uint32_t r_spic1_phy_clk_sel: 2;
            __IO uint32_t r_spic1_clk_inv_en: 1;
            __IO uint32_t r_PON_DLYSEL_SPIC1: 8;
            __IO uint32_t spic1_phy_func_en: 1;
            __IO uint32_t spic1_phy_str_en: 1;
            __IO uint32_t RESERVED_0: 1;
            __IO uint32_t spic1_ck_en: 1;
            __IO uint32_t spic1_func_en: 1;
        } BITS_114;
    } u_114;

    __IO uint32_t REG_SPIC1_PHY_CTRL0;

    __IO uint32_t REG_SPIC1_PHY_CTRL1;

    __IO uint32_t REG_SPIC1_PHY_CTRL2;

    __IO uint32_t REG_SPIC1_PHY_CTRL3;

    union
    {
        __IO uint32_t REG_PERI_SPIC2_CTL;
        struct
        {
            __IO uint32_t r_spic2_div_sel: 4;
            __IO uint32_t r_spic2_div_en: 1;
            __IO uint32_t r_SPIC2_CLK_SRC_EN: 1;
            __IO uint32_t RESERVED_2: 1;
            __IO uint32_t r_spic2_clk_src_sel_0: 1;
            __IO uint32_t r_spic2_mux_1_clk_cg_en: 1;
            __IO uint32_t r_spic2_pll_src_sel_0: 1;
            __IO uint32_t r_spic2_pll_src_sel_1: 1;
            __IO uint32_t RESERVED_1: 5;
            __IO uint32_t r_spic2_phy_clk_sel: 2;
            __IO uint32_t r_spic2_clk_inv_en: 1;
            __IO uint32_t r_PON_DLYSEL_SPIC2: 8;
            __IO uint32_t spic2_phy_func_en: 1;
            __IO uint32_t spic2_phy_str_en: 1;
            __IO uint32_t RESERVED_0: 1;
            __IO uint32_t spic2_ck_en: 1;
            __IO uint32_t spic2_func_en: 1;
        } BITS_128;
    } u_128;

    __IO uint32_t REG_SPIC2_PHY_CTRL0;

    __IO uint32_t REG_SPIC2_PHY_CTRL1;

    __IO uint32_t REG_SPIC2_PHY_CTRL2;

    __IO uint32_t REG_SPIC2_PHY_CTRL3;

    union
    {
        __IO uint32_t REG_PERI_SPIC3_CTL;
        struct
        {
            __IO uint32_t r_spic3_div_sel: 4;
            __IO uint32_t r_spic3_div_en: 1;
            __IO uint32_t r_SPIC3_CLK_SRC_EN: 1;
            __IO uint32_t RESERVED_2: 1;
            __IO uint32_t r_spic3_clk_src_sel_0: 1;
            __IO uint32_t r_spic3_mux_1_clk_cg_en: 1;
            __IO uint32_t r_spic3_pll_src_sel_0: 1;
            __IO uint32_t r_spic3_pll_src_sel_1: 1;
            __IO uint32_t RESERVED_1: 5;
            __IO uint32_t r_spic3_phy_clk_sel: 2;
            __IO uint32_t r_spic3_clk_inv_en: 1;
            __IO uint32_t r_PON_DLYSEL_SPIC3: 8;
            __IO uint32_t spic3_phy_func_en: 1;
            __IO uint32_t spic3_phy_str_en: 1;
            __IO uint32_t RESERVED_0: 1;
            __IO uint32_t spic3_ck_en: 1;
            __IO uint32_t spic3_func_en: 1;
        } BITS_13C;
    } u_13C;

    __IO uint32_t REG_SPIC3_PHY_CTRL0;

    __IO uint32_t REG_SPIC3_PHY_CTRL1;

    __IO uint32_t REG_SPIC3_PHY_CTRL2;

    __IO uint32_t REG_SPIC3_PHY_CTRL3;

    union
    {
        __IO uint32_t REG_DMA_HS_CTRL;
        struct
        {
            __IO uint32_t gdma1_func_en: 1;
            __IO uint32_t gdma1_ck_en: 1;
            __IO uint32_t gdma2_func_en: 1;
            __IO uint32_t gdma2_ck_en: 1;
            __IO uint32_t RESERVED_11: 1;
            __IO uint32_t RESERVED_10: 1;
            __IO uint32_t RESERVED_9: 1;
            __IO uint32_t RESERVED_8: 1;
            __IO uint32_t RESERVED_7: 1;
            __IO uint32_t RESERVED_6: 1;
            __IO uint32_t RESERVED_5: 1;
            __IO uint32_t RESERVED_4: 1;
            __IO uint32_t rtk_uart6_tx_dma0_en: 1;
            __IO uint32_t rtk_uart6_rx_dma0_en: 1;
            __IO uint32_t spic0_dma0_tx_en: 1;
            __IO uint32_t spic0_dma0_rx_en: 1;
            __IO uint32_t spic1_dma0_tx_en: 1;
            __IO uint32_t spic1_dma0_rx_en: 1;
            __IO uint32_t spic2_dma0_tx_en: 1;
            __IO uint32_t spic2_dma0_rx_en: 1;
            __IO uint32_t spic3_dma0_tx_en: 1;
            __IO uint32_t spic3_dma0_rx_en: 1;
            __IO uint32_t aes_tx_dma0_en: 1;
            __IO uint32_t aes_rx_dma0_en: 1;
            __IO uint32_t ecc_tx_dma0_en: 1;
            __IO uint32_t RESERVED_3: 1;
            __IO uint32_t RESERVED_2: 1;
            __IO uint32_t RESERVED_1: 1;
            __IO uint32_t RESERVED_0: 4;
        } BITS_150;
    } u_150;

    union
    {
        __IO uint32_t REG_APB5_PERI_CTL0;
        struct
        {
            __IO uint32_t i2c0_func_en: 1;
            __IO uint32_t i2c0_ck_en: 1;
            __IO uint32_t i2c0_div_en: 1;
            __IO uint32_t i2c0_div_sel: 3;
            __IO uint32_t i2c1_func_en: 1;
            __IO uint32_t i2c1_ck_en: 1;
            __IO uint32_t i2c1_div_en: 1;
            __IO uint32_t i2c1_div_sel: 3;
            __IO uint32_t i2c2_func_en: 1;
            __IO uint32_t i2c2_ck_en: 1;
            __IO uint32_t i2c2_div_en: 1;
            __IO uint32_t i2c2_div_sel: 3;
            __IO uint32_t spi0_s_func_en: 1;
            __IO uint32_t spi0_s_ck_en: 1;
            __IO uint32_t RESERVED_4: 1;
            __IO uint32_t RESERVED_3: 1;
            __IO uint32_t spi1_brg_en: 1;
            __IO uint32_t spi1_func_en: 1;
            __IO uint32_t spi1_ck_en: 1;
            __IO uint32_t spi1_div_en: 1;
            __IO uint32_t spi1_div_sel: 3;
            __IO uint32_t RESERVED_2: 1;
            __IO uint32_t RESERVED_1: 1;
            __IO uint32_t RESERVED_0: 1;
        } BITS_154;
    } u_154;

    union
    {
        __IO uint32_t REG_APB5_PERI_CTL1;
        struct
        {
            __IO uint32_t auxadc_func_en: 1;
            __IO uint32_t auxadc_ck_en: 1;
            __IO uint32_t RESERVED_2: 1;
            __IO uint32_t RESERVED_1: 5;
            __IO uint32_t spi0_func_en: 1;
            __IO uint32_t spi0_ck_en: 1;
            __IO uint32_t spi0_div_en: 1;
            __IO uint32_t spi0_div_sel: 3;
            __IO uint32_t spi0_brg_en: 1;
            __IO uint32_t RESERVED_0: 17;
        } BITS_158;
    } u_158;

    union
    {
        __IO uint32_t REG_APB5_PERI_CTL2;
        struct
        {
            __IO uint32_t r_PMUX_1_WIRE_UART2_EN: 1;
            __IO uint32_t rtk_uart2_func_en: 1;
            __IO uint32_t rtk_uart2_ck_en: 1;
            __IO uint32_t rtk_uart2_div_en: 1;
            __IO uint32_t rtk_uart2_div_sel: 3;
            __IO uint32_t r_PMUX_1_WIRE_UART3_EN: 1;
            __IO uint32_t rtk_uart3_func_en: 1;
            __IO uint32_t rtk_uart3_ck_en: 1;
            __IO uint32_t rtk_uart3_div_en: 1;
            __IO uint32_t rtk_uart3_div_sel: 3;
            __IO uint32_t r_PMUX_1_WIRE_UART4_EN: 1;
            __IO uint32_t rtk_uart4_func_en: 1;
            __IO uint32_t rtk_uart4_ck_en: 1;
            __IO uint32_t rtk_uart4_div_en: 1;
            __IO uint32_t rtk_uart4_div_sel: 3;
            __IO uint32_t r_PMUX_1_WIRE_UART5_EN: 1;
            __IO uint32_t rtk_uart5_func_en: 1;
            __IO uint32_t rtk_uart5_ck_en: 1;
            __IO uint32_t rtk_uart5_div_en: 1;
            __IO uint32_t rtk_uart5_div_sel: 3;
            __IO uint32_t RESERVED_0: 4;
        } BITS_15C;
    } u_15C;

    union
    {
        __IO uint32_t REG_TIMERB_0_CLOCK_CTRL;
        struct
        {
            __IO uint32_t r_timerb_1_div_sel: 3;
            __IO uint32_t r_timerb_1_div_en: 1;
            __IO uint32_t r_timerb_1_clk_sel: 1;
            __IO uint32_t RESERVED_2: 2;
            __IO uint32_t r_timerb_pwm_wrap1_div_sel: 3;
            __IO uint32_t r_timerb_pwm_wrap1_div_en: 1;
            __IO uint32_t r_timerb_pwm_wrap1_clk_sel: 1;
            __IO uint32_t r_timerb_pwm_wrap1_func_en: 1;
            __IO uint32_t r_timerb_pwm_wrap1_ck_en: 1;
            __IO uint32_t RESERVED_1: 2;
            __IO uint32_t RESERVED_0: 12;
            __IO uint32_t slv_clk_timerc_apb_g: 1;
            __IO uint32_t slv_clk_timerb_apb_g: 1;
            __IO uint32_t r_timerb_func_en: 1;
            __IO uint32_t r_timerb_ck_en: 1;
        } BITS_160;
    } u_160;

    union
    {
        __IO uint32_t REG_TIMERB_1_CLOCK_CTRL;
        struct
        {
            __IO uint32_t r_timerb_2_div_sel: 3;
            __IO uint32_t r_timerb_2_div_en: 1;
            __IO uint32_t r_timerb_2_clk_sel: 1;
            __IO uint32_t RESERVED_2: 2;
            __IO uint32_t r_timerb_pwm_wrap2_div_sel: 3;
            __IO uint32_t r_timerb_pwm_wrap2_div_en: 1;
            __IO uint32_t r_timerb_pwm_wrap2_clk_sel: 1;
            __IO uint32_t r_timerb_pwm_wrap2_func_en: 1;
            __IO uint32_t r_timerb_pwm_wrap2_ck_en: 1;
            __IO uint32_t RESERVED_1: 2;
            __IO uint32_t RESERVED_0: 16;
        } BITS_164;
    } u_164;

    union
    {
        __IO uint32_t REG_TIMERB_2_CLOCK_CTRL;
        struct
        {
            __IO uint32_t r_timerb_3_div_sel: 3;
            __IO uint32_t r_timerb_3_div_en: 1;
            __IO uint32_t r_timerb_3_clk_sel: 1;
            __IO uint32_t RESERVED_2: 2;
            __IO uint32_t r_timerb_pwm_wrap3_div_sel: 3;
            __IO uint32_t r_timerb_pwm_wrap3_div_en: 1;
            __IO uint32_t r_timerb_pwm_wrap3_clk_sel: 1;
            __IO uint32_t r_timerb_pwm_wrap3_func_en: 1;
            __IO uint32_t r_timerb_pwm_wrap3_ck_en: 1;
            __IO uint32_t RESERVED_1: 2;
            __IO uint32_t RESERVED_0: 16;
        } BITS_168;
    } u_168;

    union
    {
        __IO uint32_t REG_TIMERB_3_CLOCK_CTRL;
        struct
        {
            __IO uint32_t r_timerb_4_div_sel: 3;
            __IO uint32_t r_timerb_4_div_en: 1;
            __IO uint32_t r_timerb_4_clk_sel: 1;
            __IO uint32_t RESERVED_2: 2;
            __IO uint32_t r_timerb_pwm_wrap4_div_sel: 3;
            __IO uint32_t r_timerb_pwm_wrap4_div_en: 1;
            __IO uint32_t r_timerb_pwm_wrap4_clk_sel: 1;
            __IO uint32_t r_timerb_pwm_wrap4_func_en: 1;
            __IO uint32_t r_timerb_pwm_wrap4_ck_en: 1;
            __IO uint32_t RESERVED_1: 2;
            __IO uint32_t RESERVED_0: 16;
        } BITS_16C;
    } u_16C;

    union
    {
        __IO uint32_t REG_TIMER_B_TOGGLE_STATE;
        struct
        {
            __I uint32_t timerb_toggle_state_3_0: 4;
            __I uint32_t RESERVED_0: 28;
        } BITS_170;
    } u_170;

    union
    {
        __IO uint32_t REG_ENHTIMER_1_0_CLOCK_CTRL;
        struct
        {
            __IO uint32_t r_etimer_0_div_sel: 3;
            __IO uint32_t r_etimer_0_div_en: 1;
            __IO uint32_t r_etimer_0_clk_src_sel2: 1;
            __IO uint32_t r_etimer_0_clk_src_sel1: 1;
            __IO uint32_t r_etimer_0_clk_src_sel0: 1;
            __IO uint32_t r_etimer_pwm_0_div_sel: 3;
            __IO uint32_t r_etimer_pwm_0_div_en: 1;
            __IO uint32_t r_etimer_pwm_0_clk_src_sel: 1;
            __IO uint32_t r_etimer_pwm_0_func_en: 1;
            __IO uint32_t r_etimer_pwm_0_ck_en: 1;
            __IO uint32_t RESERVED_0: 2;
            __IO uint32_t r_etimer_1_div_sel: 3;
            __IO uint32_t r_etimer_1_div_en: 1;
            __IO uint32_t r_etimer_1_clk_src_sel2: 1;
            __IO uint32_t r_etimer_1_clk_src_sel1: 1;
            __IO uint32_t r_etimer_1_clk_src_sel0: 1;
            __IO uint32_t r_etimer_pwm_1_div_sel: 3;
            __IO uint32_t r_etimer_pwm_1_div_en: 1;
            __IO uint32_t r_etimer_pwm_1_clk_src_sel: 1;
            __IO uint32_t r_etimer_pwm_1_func_en: 1;
            __IO uint32_t r_etimer_pwm_1_ck_en: 1;
            __IO uint32_t r_etimer_func_en: 1;
            __IO uint32_t r_etimer_ck_en: 1;
        } BITS_174;
    } u_174;

    union
    {
        __IO uint32_t REG_ENHTIMER_3_2_CLOCK_CTRL;
        struct
        {
            __IO uint32_t r_etimer_2_div_sel: 3;
            __IO uint32_t r_etimer_2_div_en: 1;
            __IO uint32_t r_etimer_2_clk_src_sel2: 1;
            __IO uint32_t r_etimer_2_clk_src_sel1: 1;
            __IO uint32_t r_etimer_2_clk_src_sel0: 1;
            __IO uint32_t r_etimer_pwm_2_div_sel: 3;
            __IO uint32_t r_etimer_pwm_2_div_en: 1;
            __IO uint32_t r_etimer_pwm_2_clk_src_sel: 1;
            __IO uint32_t r_etimer_pwm_2_func_en: 1;
            __IO uint32_t r_etimer_pwm_2_ck_en: 1;
            __IO uint32_t RESERVED_1: 2;
            __IO uint32_t r_etimer_3_div_sel: 3;
            __IO uint32_t r_etimer_3_div_en: 1;
            __IO uint32_t r_etimer_3_clk_src_sel2: 1;
            __IO uint32_t r_etimer_3_clk_src_sel1: 1;
            __IO uint32_t r_etimer_3_clk_src_sel0: 1;
            __IO uint32_t r_etimer_pwm_3_div_sel: 3;
            __IO uint32_t r_etimer_pwm_3_div_en: 1;
            __IO uint32_t r_etimer_pwm_3_clk_src_sel: 1;
            __IO uint32_t r_etimer_pwm_3_func_en: 1;
            __IO uint32_t r_etimer_pwm_3_ck_en: 1;
            __IO uint32_t RESERVED_0: 2;
        } BITS_178;
    } u_178;

    union
    {
        __IO uint32_t REG_ENHTIMER_5_4_CLOCK_CTRL;
        struct
        {
            __IO uint32_t r_etimer_4_div_sel: 3;
            __IO uint32_t r_etimer_4_div_en: 1;
            __IO uint32_t r_etimer_4_clk_src_sel2: 1;
            __IO uint32_t r_etimer_4_clk_src_sel1: 1;
            __IO uint32_t r_etimer_4_clk_src_sel0: 1;
            __IO uint32_t r_etimer_pwm_4_div_sel: 3;
            __IO uint32_t r_etimer_pwm_4_div_en: 1;
            __IO uint32_t r_etimer_pwm_4_clk_src_sel: 1;
            __IO uint32_t r_etimer_pwm_4_func_en: 1;
            __IO uint32_t r_etimer_pwm_4_ck_en: 1;
            __IO uint32_t RESERVED_1: 2;
            __IO uint32_t r_etimer_5_div_sel: 3;
            __IO uint32_t r_etimer_5_div_en: 1;
            __IO uint32_t r_etimer_5_clk_src_sel2: 1;
            __IO uint32_t r_etimer_5_clk_src_sel1: 1;
            __IO uint32_t r_etimer_5_clk_src_sel0: 1;
            __IO uint32_t r_etimer_pwm_5_div_sel: 3;
            __IO uint32_t r_etimer_pwm_5_div_en: 1;
            __IO uint32_t r_etimer_pwm_5_clk_src_sel: 1;
            __IO uint32_t r_etimer_pwm_5_func_en: 1;
            __IO uint32_t r_etimer_pwm_5_ck_en: 1;
            __IO uint32_t RESERVED_0: 2;
        } BITS_17C;
    } u_17C;

    union
    {
        __IO uint32_t REG_ENHTIMER_7_6_CLOCK_CTRL;
        struct
        {
            __IO uint32_t r_etimer_6_div_sel: 3;
            __IO uint32_t r_etimer_6_div_en: 1;
            __IO uint32_t r_etimer_6_clk_src_sel2: 1;
            __IO uint32_t r_etimer_6_clk_src_sel1: 1;
            __IO uint32_t r_etimer_6_clk_src_sel0: 1;
            __IO uint32_t r_etimer_pwm_6_div_sel: 3;
            __IO uint32_t r_etimer_pwm_6_div_en: 1;
            __IO uint32_t r_etimer_pwm_6_clk_src_sel: 1;
            __IO uint32_t r_etimer_pwm_6_func_en: 1;
            __IO uint32_t r_etimer_pwm_6_ck_en: 1;
            __IO uint32_t RESERVED_1: 2;
            __IO uint32_t r_etimer_7_div_sel: 3;
            __IO uint32_t r_etimer_7_div_en: 1;
            __IO uint32_t r_etimer_7_clk_src_sel2: 1;
            __IO uint32_t r_etimer_7_clk_src_sel1: 1;
            __IO uint32_t r_etimer_7_clk_src_sel0: 1;
            __IO uint32_t r_etimer_pwm_7_div_sel: 3;
            __IO uint32_t r_etimer_pwm_7_div_en: 1;
            __IO uint32_t r_etimer_pwm_7_clk_src_sel: 1;
            __IO uint32_t r_etimer_pwm_7_func_en: 1;
            __IO uint32_t r_etimer_pwm_7_ck_en: 1;
            __IO uint32_t RESERVED_0: 2;
        } BITS_180;
    } u_180;

    union
    {
        __IO uint32_t REG_APB10_PERI_CTL0;
        struct
        {
            __IO uint32_t qdec_func_en: 1;
            __IO uint32_t qdec_ck_en: 1;
            __IO uint32_t keyscan_func_en: 1;
            __IO uint32_t keyscan_ck_en: 1;
            __IO uint32_t gpio_a_func_en: 1;
            __IO uint32_t gpio_a_ck_en: 1;
            __IO uint32_t gpio_b_func_en: 1;
            __IO uint32_t gpio_b_ck_en: 1;
            __IO uint32_t gpio_c_func_en: 1;
            __IO uint32_t gpio_c_ck_en: 1;
            __IO uint32_t gpio_d_func_en: 1;
            __IO uint32_t gpio_d_ck_en: 1;
            __IO uint32_t gpio_a_deb_ck_en: 1;
            __IO uint32_t gpio_b_deb_ck_en: 1;
            __IO uint32_t gpio_c_deb_ck_en: 1;
            __IO uint32_t gpio_d_deb_ck_en: 1;
            __IO uint32_t RESERVED_0: 16;
        } BITS_184;
    } u_184;

    union
    {
        __IO uint32_t GPIOA_DEB_CLK_CTL_0;
        struct
        {
            __IO uint32_t GPIOA_G0_CNT_LIMIT: 8;
            __IO uint32_t GPIOA_G0_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOA_G0_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOA_G0_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_1: 3;
            __IO uint32_t GPIOA_G1_CNT_LIMIT: 8;
            __IO uint32_t GPIOA_G1_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOA_G1_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOA_G1_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_0: 3;
        } BITS_188;
    } u_188;

    union
    {
        __IO uint32_t GPIOA_DEB_CLK_CTL_1;
        struct
        {
            __IO uint32_t GPIOA_G2_CNT_LIMIT: 8;
            __IO uint32_t GPIOA_G2_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOA_G2_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOA_G2_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_1: 3;
            __IO uint32_t GPIOA_G3_CNT_LIMIT: 8;
            __IO uint32_t GPIOA_G3_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOA_G3_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOA_G3_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_0: 3;
        } BITS_18C;
    } u_18C;

    union
    {
        __IO uint32_t GPIOA_DEB_CLK_CTL_2;
        struct
        {
            __IO uint32_t GPIOA_G4_CNT_LIMIT: 8;
            __IO uint32_t GPIOA_G4_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOA_G4_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOA_G4_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_1: 3;
            __IO uint32_t GPIOA_G5_CNT_LIMIT: 8;
            __IO uint32_t GPIOA_G5_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOA_G5_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOA_G5_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_0: 3;
        } BITS_190;
    } u_190;

    union
    {
        __IO uint32_t GPIOA_DEB_CLK_CTL_3;
        struct
        {
            __IO uint32_t GPIOA_G6_CNT_LIMIT: 8;
            __IO uint32_t GPIOA_G6_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOA_G6_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOA_G6_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_1: 3;
            __IO uint32_t GPIOA_G7_CNT_LIMIT: 8;
            __IO uint32_t GPIOA_G7_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOA_G7_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOA_G7_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_0: 3;
        } BITS_194;
    } u_194;

    union
    {
        __IO uint32_t GPIOA_DEB_FUN_CTL;
        struct
        {
            __IO uint32_t GPIOA_x_DEB_FUNC_EN: 32;
        } BITS_198;
    } u_198;

    union
    {
        __IO uint32_t GPIOB_DEB_CLK_CTL_0;
        struct
        {
            __IO uint32_t GPIOB_G0_CNT_LIMIT: 8;
            __IO uint32_t GPIOB_G0_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOB_G0_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOB_G0_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_1: 3;
            __IO uint32_t GPIOB_G1_CNT_LIMIT: 8;
            __IO uint32_t GPIOB_G1_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOB_G1_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOB_G1_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_0: 3;
        } BITS_19C;
    } u_19C;

    union
    {
        __IO uint32_t GPIOB_DEB_CLK_CTL_1;
        struct
        {
            __IO uint32_t GPIOB_G2_CNT_LIMIT: 8;
            __IO uint32_t GPIOB_G2_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOB_G2_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOB_G2_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_1: 3;
            __IO uint32_t GPIOB_G3_CNT_LIMIT: 8;
            __IO uint32_t GPIOB_G3_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOB_G3_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOB_G3_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_0: 3;
        } BITS_1A0;
    } u_1A0;

    union
    {
        __IO uint32_t GPIOB_DEB_CLK_CTL_2;
        struct
        {
            __IO uint32_t GPIOB_G4_CNT_LIMIT: 8;
            __IO uint32_t GPIOB_G4_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOB_G4_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOB_G4_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_1: 3;
            __IO uint32_t GPIOB_G5_CNT_LIMIT: 8;
            __IO uint32_t GPIOB_G5_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOB_G5_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOB_G5_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_0: 3;
        } BITS_1A4;
    } u_1A4;

    union
    {
        __IO uint32_t GPIOB_DEB_CLK_CTL_3;
        struct
        {
            __IO uint32_t GPIOB_G6_CNT_LIMIT: 8;
            __IO uint32_t GPIOB_G6_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOB_G6_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOB_G6_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_1: 3;
            __IO uint32_t GPIOB_G7_CNT_LIMIT: 8;
            __IO uint32_t GPIOB_G7_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOB_G7_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOB_G7_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_0: 3;
        } BITS_1A8;
    } u_1A8;

    union
    {
        __IO uint32_t GPIOB_DEB_FUN_CTL;
        struct
        {
            __IO uint32_t GPIOB_x_DEB_FUNC_EN: 32;
        } BITS_1AC;
    } u_1AC;

    union
    {
        __IO uint32_t GPIOC_DEB_CLK_CTL_0;
        struct
        {
            __IO uint32_t GPIOC_G0_CNT_LIMIT: 8;
            __IO uint32_t GPIOC_G0_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOC_G0_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOC_G0_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_1: 3;
            __IO uint32_t GPIOC_G1_CNT_LIMIT: 8;
            __IO uint32_t GPIOC_G1_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOC_G1_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOC_G1_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_0: 3;
        } BITS_1B0;
    } u_1B0;

    union
    {
        __IO uint32_t GPIOC_DEB_CLK_CTL_1;
        struct
        {
            __IO uint32_t GPIOC_G2_CNT_LIMIT: 8;
            __IO uint32_t GPIOC_G2_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOC_G2_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOC_G2_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_1: 3;
            __IO uint32_t GPIOC_G3_CNT_LIMIT: 8;
            __IO uint32_t GPIOC_G3_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOC_G3_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOC_G3_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_0: 3;
        } BITS_1B4;
    } u_1B4;

    union
    {
        __IO uint32_t GPIOC_DEB_CLK_CTL_2;
        struct
        {
            __IO uint32_t GPIOC_G4_CNT_LIMIT: 8;
            __IO uint32_t GPIOC_G4_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOC_G4_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOC_G4_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_1: 3;
            __IO uint32_t GPIOC_G5_CNT_LIMIT: 8;
            __IO uint32_t GPIOC_G5_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOC_G5_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOC_G5_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_0: 3;
        } BITS_1B8;
    } u_1B8;

    union
    {
        __IO uint32_t GPIOC_DEB_CLK_CTL_3;
        struct
        {
            __IO uint32_t GPIOC_G6_CNT_LIMIT: 8;
            __IO uint32_t GPIOC_G6_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOC_G6_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOC_G6_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_1: 3;
            __IO uint32_t GPIOC_G7_CNT_LIMIT: 8;
            __IO uint32_t GPIOC_G7_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOC_G7_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOC_G7_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_0: 3;
        } BITS_1BC;
    } u_1BC;

    union
    {
        __IO uint32_t GPIOC_DEB_FUN_CTL;
        struct
        {
            __IO uint32_t GPIOC_x_DEB_FUNC_EN: 32;
        } BITS_1C0;
    } u_1C0;

    union
    {
        __IO uint32_t GPIOD_DEB_CLK_CTL_0;
        struct
        {
            __IO uint32_t GPIOD_G0_CNT_LIMIT: 8;
            __IO uint32_t GPIOD_G0_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOD_G0_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOD_G0_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_1: 3;
            __IO uint32_t GPIOD_G1_CNT_LIMIT: 8;
            __IO uint32_t GPIOD_G1_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOD_G1_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOD_G1_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_0: 3;
        } BITS_1C4;
    } u_1C4;

    union
    {
        __IO uint32_t GPIOD_DEB_CLK_CTL_1;
        struct
        {
            __IO uint32_t GPIOD_G2_CNT_LIMIT: 8;
            __IO uint32_t GPIOD_G2_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOD_G2_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOD_G2_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_1: 3;
            __IO uint32_t GPIOD_G3_CNT_LIMIT: 8;
            __IO uint32_t GPIOD_G3_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOD_G3_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOD_G3_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_0: 3;
        } BITS_1C8;
    } u_1C8;

    union
    {
        __IO uint32_t GPIOD_DEB_CLK_CTL_2;
        struct
        {
            __IO uint32_t GPIOD_G4_CNT_LIMIT: 8;
            __IO uint32_t GPIOD_G4_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOD_G4_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOD_G4_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_1: 3;
            __IO uint32_t GPIOD_G5_CNT_LIMIT: 8;
            __IO uint32_t GPIOD_G5_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOD_G5_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOD_G5_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_0: 3;
        } BITS_1CC;
    } u_1CC;

    union
    {
        __IO uint32_t GPIOD_DEB_CLK_CTL_3;
        struct
        {
            __IO uint32_t GPIOD_G6_CNT_LIMIT: 8;
            __IO uint32_t GPIOD_G6_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOD_G6_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOD_G6_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_1: 3;
            __IO uint32_t GPIOD_G7_CNT_LIMIT: 8;
            __IO uint32_t GPIOD_G7_DEB_CLK_SEL: 1;
            __IO uint32_t GPIOD_G7_DEB_CLK_DIV: 3;
            __IO uint32_t GPIOD_G7_DEB_CNT_EN: 1;
            __IO uint32_t RESERVED_0: 3;
        } BITS_1D0;
    } u_1D0;

    union
    {
        __IO uint32_t GPIOD_DEB_FUN_CTL;
        struct
        {
            __IO uint32_t GPIOD_x_DEB_FUNC_EN: 32;
        } BITS_1D4;
    } u_1D4;

    union
    {
        __IO uint32_t REG_PERI_RSVD0;
        struct
        {
            __IO uint32_t rtk_uart6_div_sel: 3;
            __IO uint32_t rtk_uart6_div_en: 1;
            __IO uint32_t rtk_uart6_ck_en: 1;
            __IO uint32_t rtk_uart6_func_en: 1;
            __IO uint32_t r_PMUX_1_WIRE_UART6_EN: 1;
            __IO uint32_t RESERVED_4: 1;
            __IO uint32_t RESERVED_3: 1;
            __IO uint32_t simc_ck_en: 1;
            __IO uint32_t simc_func_en: 1;
            __IO uint32_t RESERVED_2: 1;
            __IO uint32_t i2c3_clk_sel0: 1;
            __IO uint32_t i2c3_clk_sel1: 1;
            __IO uint32_t i2c3_ck_en: 1;
            __IO uint32_t i2c3_func_en: 1;
            __IO uint32_t RESERVED_1: 1;
            __IO uint32_t ir_clk_sel0: 1;
            __IO uint32_t ir_clk_sel1: 1;
            __IO uint32_t ir_ck_en: 1;
            __IO uint32_t ir_func_en: 1;
            __IO uint32_t mae_ck_en: 1;
            __IO uint32_t mae_func_en: 1;
            __IO uint32_t RESERVED_0: 9;
        } BITS_1D8;
    } u_1D8;

    union
    {
        __IO uint32_t REG_PERI_RSVD1;
        struct
        {
            __IO uint32_t spi3_ck_en: 1;
            __IO uint32_t spi3_func_en: 1;
            __IO uint32_t r_spi3_div_sel: 3;
            __IO uint32_t r_spi3_div_en: 1;
            __IO uint32_t r_spi3_mux_clk_cg_en: 1;
            __IO uint32_t spi3_brg_en: 1;
            __IO uint32_t spi3_hs_ck_en: 1;
            __IO uint32_t spi3_h2s_brg_en: 1;
            __IO uint32_t RESERVED_1: 2;
            __IO uint32_t spi2_ck_en: 1;
            __IO uint32_t spi2_func_en: 1;
            __IO uint32_t r_spi2_div_sel: 3;
            __IO uint32_t r_spi2_div_en: 1;
            __IO uint32_t r_spi2_mux_clk_cg_en: 1;
            __IO uint32_t spi2_brg_en: 1;
            __IO uint32_t spi2_hs_ck_en: 1;
            __IO uint32_t spi2_h2s_brg_en: 1;
            __IO uint32_t r_spi23_clk_src_sel1: 1;
            __IO uint32_t r_spi23_clk_src_sel0: 1;
            __IO uint32_t RESERVED_0: 8;
        } BITS_1DC;
    } u_1DC;

    union
    {
        __IO uint32_t REG_TIMERC_CLOCK_CTRL;
        struct
        {
            __IO uint32_t r_timerc_1_div_sel: 3;
            __IO uint32_t r_timerc_1_div_en: 1;
            __IO uint32_t r_timerc_1_clk_sel: 1;
            __IO uint32_t r_timerc_2_div_sel: 3;
            __IO uint32_t r_timerc_2_div_en: 1;
            __IO uint32_t r_timerc_2_clk_sel: 1;
            __IO uint32_t r_timerc_3_div_sel: 3;
            __IO uint32_t r_timerc_3_div_en: 1;
            __IO uint32_t r_timerc_3_clk_sel: 1;
            __IO uint32_t r_timerc_4_div_sel: 3;
            __IO uint32_t r_timerc_4_div_en: 1;
            __IO uint32_t r_timerc_4_clk_sel: 1;
            __IO uint32_t r_timerc_5_div_sel: 3;
            __IO uint32_t r_timerc_5_div_en: 1;
            __IO uint32_t r_timerc_5_clk_sel: 1;
            __IO uint32_t r_timerc_6_div_sel: 3;
            __IO uint32_t r_timerc_6_div_en: 1;
            __IO uint32_t r_timerc_6_clk_sel: 1;
            __IO uint32_t r_timerc_func_en: 1;
            __IO uint32_t r_timerc_ck_en: 1;
        } BITS_1E0;
    } u_1E0;

    union
    {
        __IO uint32_t REG_PERI_RSVD3;
        struct
        {
            __IO uint32_t gpu_ck_en: 1;
            __IO uint32_t gpu_func_en: 1;
            __IO uint32_t r_gpu_slow_en: 1;
            __IO uint32_t r_gpu_div_sel_slow: 3;
            __IO uint32_t RESERVED_2: 1;
            __IO uint32_t RESERVED_1: 1;
            __IO uint32_t mipi_host_ck_en: 1;
            __IO uint32_t mipi_host_func_en: 1;
            __IO uint32_t r_mipi_rx_div_sel: 3;
            __IO uint32_t r_mipi_rx_div_en: 1;
            __IO uint32_t r_mipi_rx_mux_clk_cg_en: 1;
            __IO uint32_t r_mipi_rx_clk_src_sel: 1;
            __IO uint32_t r_display_div_sel: 3;
            __IO uint32_t r_display_div_en: 1;
            __IO uint32_t r_display_mux_clk_cg_en: 1;
            __IO uint32_t r_display_clk_src_sel1: 1;
            __IO uint32_t r_display_clk_src_sel0: 1;
            __IO uint32_t disp_ck_en: 1;
            __IO uint32_t disp_func_en: 1;
            __IO uint32_t RESERVED_0: 7;
        } BITS_1E4;
    } u_1E4;

    union
    {
        __IO uint32_t REG_SDIO_CTRL;
        struct
        {
            __IO uint32_t sdio1_ck_en: 1;
            __IO uint32_t sdio1_func_en: 1;
            __IO uint32_t r_sdio1_clk_src_en: 1;
            __IO uint32_t r_sdio1_div_sel: 4;
            __IO uint32_t r_sdio1_div_en: 1;
            __IO uint32_t r_sdio1_mux_clk_cg_en: 1;
            __IO uint32_t r_sdio1_clk_src_sel: 1;
            __IO uint32_t RESERVED_1: 6;
            __IO uint32_t sdio0_ck_en: 1;
            __IO uint32_t sdio0_func_en: 1;
            __IO uint32_t r_sdio0_clk_src_en: 1;
            __IO uint32_t r_sdio0_div_sel: 4;
            __IO uint32_t r_sdio0_div_en: 1;
            __IO uint32_t r_sdio0_mux_clk_cg_en: 1;
            __IO uint32_t r_sdio0_clk_src_sel: 1;
            __IO uint32_t RESERVED_0: 6;
        } BITS_1E8;
    } u_1E8;

    union
    {
        __IO uint32_t REG_SDH0_PHY0;
        struct
        {
            __IO uint32_t r_sdh0_drv_dly_sel: 8;
            __IO uint32_t r_sdh0_sample_dly_sel: 8;
            __IO uint32_t r_sdh0_clk_sel_drv: 2;
            __IO uint32_t r_sdh0_clk_sel_sample: 2;
            __IO uint32_t r_sdh0_bypass_shift_drv: 1;
            __IO uint32_t r_sdh0_bypass_shift_sample: 1;
            __IO uint32_t r_sdh0_bypass_delay_drv: 1;
            __IO uint32_t r_sdh0_bypass_delay_sample: 1;
            __IO uint32_t r_sdh0_clk_out_dly_sel: 8;
        } BITS_1EC;
    } u_1EC;

    union
    {
        __IO uint32_t REG_SDH0_PHY1;
        struct
        {
            __IO uint32_t r_sdh0_cmd_out_dly_sel: 8;
            __IO uint32_t r_sdh0_dat0_dly_sel: 8;
            __IO uint32_t r_sdh0_dat1_dly_sel: 8;
            __IO uint32_t r_sdh0_dat2_dly_sel: 8;
        } BITS_1F0;
    } u_1F0;

    union
    {
        __IO uint32_t REG_SDIO0_PHY2;
        struct
        {
            __IO uint32_t r_sdh0_dat3_dly_sel: 8;
            __IO uint32_t r_sdh0_dat4_dly_sel: 8;
            __IO uint32_t r_sdh0_dat5_dly_sel: 8;
            __IO uint32_t r_sdh0_dat6_dly_sel: 8;
        } BITS_1F4;
    } u_1F4;

    union
    {
        __IO uint32_t REG_SDH0_PHY3;
        struct
        {
            __IO uint32_t r_sdh0_dat7_dly_sel: 8;
            __IO uint32_t r_sdh0_dbg_sel: 12;
            __IO uint32_t r_sdh0_dbg_en_i: 2;
            __IO uint32_t r_sdh0_cclk_in_drv: 1;
            __IO uint32_t r_sdh0_cclk_sample_drv: 1;
            __IO uint32_t r_sdh0_cclk_in_div_enable: 1;
            __IO uint32_t RESERVED_0: 7;
        } BITS_1F8;
    } u_1F8;

    union
    {
        __IO uint32_t REG_SDH1_PHY0;
        struct
        {
            __IO uint32_t r_sdh1_drv_dly_sel: 8;
            __IO uint32_t r_sdh1_sample_dly_sel: 8;
            __IO uint32_t r_sdh1_clk_sel_drv: 2;
            __IO uint32_t r_sdh1_clk_sel_sample: 2;
            __IO uint32_t r_sdh1_bypass_shift_drv: 1;
            __IO uint32_t r_sdh1_bypass_shift_sample: 1;
            __IO uint32_t r_sdh1_bypass_delay_drv: 1;
            __IO uint32_t r_sdh1_bypass_delay_sample: 1;
            __IO uint32_t r_sdh1_clk_out_dly_sel: 8;
        } BITS_1FC;
    } u_1FC;

    union
    {
        __IO uint32_t REG_SDH1_PHY1;
        struct
        {
            __IO uint32_t r_sdh1_cmd_out_dly_sel: 8;
            __IO uint32_t r_sdh1_dat0_dly_sel: 8;
            __IO uint32_t r_sdh1_dat1_dly_sel: 8;
            __IO uint32_t r_sdh1_dat2_dly_sel: 8;
        } BITS_200;
    } u_200;

    union
    {
        __IO uint32_t REG_SDIO1_PHY2;
        struct
        {
            __IO uint32_t r_sdh1_dat3_dly_sel: 8;
            __IO uint32_t r_sdh1_dat4_dly_sel: 8;
            __IO uint32_t r_sdh1_dat5_dly_sel: 8;
            __IO uint32_t r_sdh1_dat6_dly_sel: 8;
        } BITS_204;
    } u_204;

    union
    {
        __IO uint32_t REG_SDH1_PHY3;
        struct
        {
            __IO uint32_t r_sdh1_dat7_dly_sel: 8;
            __IO uint32_t r_sdh1_dbg_sel: 12;
            __IO uint32_t r_sdh1_dbg_en_i: 2;
            __IO uint32_t r_sdh1_cclk_in_drv: 1;
            __IO uint32_t r_sdh1_cclk_sample_drv: 1;
            __IO uint32_t r_sdh1_cclk_in_div_enable: 1;
            __IO uint32_t RESERVED_0: 7;
        } BITS_208;
    } u_208;

    union
    {
        __IO uint32_t REG_SDH0_DBG0;
        struct
        {
            __IO uint32_t r_sdh0_phy_dbg: 32;
        } BITS_20C;
    } u_20C;

    union
    {
        __IO uint32_t REG_SDH0_DBG1;
        struct
        {
            __IO uint32_t r_sdh0_dbg: 32;
        } BITS_210;
    } u_210;

    union
    {
        __IO uint32_t REG_SDH1_DBG0;
        struct
        {
            __IO uint32_t r_sdh1_phy_dbg: 32;
        } BITS_214;
    } u_214;

    union
    {
        __IO uint32_t REG_SDH1_DBG1;
        struct
        {
            __IO uint32_t r_sdh1_dbg: 32;
        } BITS_218;
    } u_218;

    union
    {
        __IO uint32_t REG_SDH0_PHY4;
        struct
        {
            __IO uint32_t r_sdh0_cmd_out_oe_dly_sel: 8;
            __IO uint32_t r_sdh0_dat0_oe_dly_sel: 8;
            __IO uint32_t r_sdh0_dat1_oe_dly_sel: 8;
            __IO uint32_t r_sdh0_dat2_oe_dly_sel: 8;
        } BITS_21C;
    } u_21C;

    union
    {
        __IO uint32_t REG_SDIO0_PHY5;
        struct
        {
            __IO uint32_t r_sdh0_dat3_oe_dly_sel: 8;
            __IO uint32_t r_sdh0_dat4_oe_dly_sel: 8;
            __IO uint32_t r_sdh0_dat5_oe_dly_sel: 8;
            __IO uint32_t r_sdh0_dat6_oe_dly_sel: 8;
        } BITS_220;
    } u_220;

    union
    {
        __IO uint32_t REG_SDH0_PHY6;
        struct
        {
            __IO uint32_t r_sdh1_cmd_out_oe_dly_sel: 8;
            __IO uint32_t r_sdh1_dat0_oe_dly_sel: 8;
            __IO uint32_t r_sdh1_dat1_oe_dly_sel: 8;
            __IO uint32_t r_sdh1_dat2_oe_dly_sel: 8;
        } BITS_224;
    } u_224;

    union
    {
        __IO uint32_t REG_SDIO0_PHY7;
        struct
        {
            __IO uint32_t r_sdh1_dat3_oe_dly_sel: 8;
            __IO uint32_t r_sdh1_dat4_oe_dly_sel: 8;
            __IO uint32_t r_sdh1_dat5_oe_dly_sel: 8;
            __IO uint32_t r_sdh1_dat6_oe_dly_sel: 8;
        } BITS_228;
    } u_228;

    union
    {
        __IO uint32_t REG_SDH0_PHY8;
        struct
        {
            __IO uint32_t r_sdh0_dat7_oe_dly_sel: 8;
            __IO uint32_t r_sdh1_dat7_oe_dly_sel: 8;
            __IO uint32_t RESERVED_1: 8;
            __IO uint32_t RESERVED_0: 8;
        } BITS_22C;
    } u_22C;

    __IO uint32_t RSVD_0x230[4];

    union
    {
        __IO uint32_t REG_SEC_CTRL0;
        struct
        {
            __IO uint32_t rng_func_en: 1;
            __IO uint32_t rng_ck_en: 1;
            __IO uint32_t rng_sfosc_sel: 1;
            __IO uint32_t rng_sfosc_div_sel: 3;
            __IO uint32_t RESERVED_3: 8;
            __IO uint32_t sha3_ck_en: 1;
            __IO uint32_t sha3_func_en: 1;
            __IO uint32_t RESERVED_2: 1;
            __IO uint32_t RESERVED_1: 1;
            __IO uint32_t ecc_ck_en: 1;
            __IO uint32_t ecc_func_en: 1;
            __IO uint32_t sha2_ck_en: 1;
            __IO uint32_t sha2_func_en: 1;
            __IO uint32_t aes_ck_en: 1;
            __IO uint32_t aes_func_en: 1;
            __IO uint32_t pke_ck_en: 1;
            __IO uint32_t pke_func_en: 1;
            __IO uint32_t pke_clk_always_enable: 1;
            __IO uint32_t pke_clk_always_disable: 1;
            __IO uint32_t sha2_dma_clk_always_enable: 1;
            __IO uint32_t sha2_dma_clk_always_disable: 1;
            __IO uint32_t RESERVED_0: 2;
        } BITS_240;
    } u_240;

    __IO uint32_t REG_SEC_CTRL1;

    __IO uint32_t REG_SEC_CTRL2;

    __IO uint32_t REG_SEC_CTRL3;

    __IO uint32_t REG_SEC_CTRL4;

    __IO uint32_t REG_SEC_CTRL5;

    __IO uint32_t REG_SEC_CTRL6;

    __IO uint32_t REG_SEC_CTRL7;

    union
    {
        __IO uint32_t REG_TIMER_B_PWM_WRAP_0_CFG;
        struct
        {
            __IO uint32_t timer_b_pwm_0_dead_zone_size: 8;
            __IO uint32_t timer_b_pwm_0_emg_stop: 1;
            __IO uint32_t timer_b_pwm_0_stop_state_0: 1;
            __IO uint32_t timer_b_pwm_0_stop_state_1: 1;
            __IO uint32_t timer_b_pwm_0_dummy_b11: 1;
            __IO uint32_t timer_b_pwm_0_dead_zone_en: 1;
            __IO uint32_t timer_b_pwm_0_pwm_pn_invserse_sel: 1;
            __IO uint32_t timer_b_pwm_0_dummy_b14: 1;
            __IO uint32_t timer_b_pwm_0_dummy_b15: 1;
            __I uint32_t RESERVED_0: 16;
        } BITS_260;
    } u_260;

    union
    {
        __IO uint32_t REG_TIMER_B_PWM_WRAP_1_CFG;
        struct
        {
            __IO uint32_t timer_b_pwm_1_dead_zone_size: 8;
            __IO uint32_t timer_b_pwm_1_emg_stop: 1;
            __IO uint32_t timer_b_pwm_1_stop_state_0: 1;
            __IO uint32_t timer_b_pwm_1_stop_state_1: 1;
            __IO uint32_t timer_b_pwm_1_dummy_b11: 1;
            __IO uint32_t timer_b_pwm_1_dead_zone_en: 1;
            __IO uint32_t timer_b_pwm_1_pwm_pn_invserse_sel: 1;
            __IO uint32_t timer_b_pwm_1_dummy_b14: 1;
            __IO uint32_t timer_b_pwm_1_dummy_b15: 1;
            __I uint32_t RESERVED_0: 16;
        } BITS_264;
    } u_264;

    union
    {
        __IO uint32_t REG_TIMER_B_PWM_WRAP_2_CFG;
        struct
        {
            __IO uint32_t timer_b_pwm_2_dead_zone_size: 8;
            __IO uint32_t timer_b_pwm_2_emg_stop: 1;
            __IO uint32_t timer_b_pwm_2_stop_state_0: 1;
            __IO uint32_t timer_b_pwm_2_stop_state_1: 1;
            __IO uint32_t timer_b_pwm_2_dummy_b11: 1;
            __IO uint32_t timer_b_pwm_2_dead_zone_en: 1;
            __IO uint32_t timer_b_pwm_2_pwm_pn_invserse_sel: 1;
            __IO uint32_t timer_b_pwm_2_dummy_b14: 1;
            __IO uint32_t timer_b_pwm_2_dummy_b15: 1;
            __I uint32_t RESERVED_0: 16;
        } BITS_268;
    } u_268;

    union
    {
        __IO uint32_t REG_TIMER_B_PWM_WRAP_3_CFG;
        struct
        {
            __IO uint32_t timer_b_pwm_3_dead_zone_size: 8;
            __IO uint32_t timer_b_pwm_3_emg_stop: 1;
            __IO uint32_t timer_b_pwm_3_stop_state_0: 1;
            __IO uint32_t timer_b_pwm_3_stop_state_1: 1;
            __IO uint32_t timer_b_pwm_3_dummy_b11: 1;
            __IO uint32_t timer_b_pwm_3_dead_zone_en: 1;
            __IO uint32_t timer_b_pwm_3_pwm_pn_invserse_sel: 1;
            __IO uint32_t timer_b_pwm_3_dummy_b14: 1;
            __IO uint32_t timer_b_pwm_3_dummy_b15: 1;
            __I uint32_t RESERVED_0: 16;
        } BITS_26C;
    } u_26C;

    union
    {
        __IO uint32_t REG_ENHTIMER_PWM_WRAP_0_CFG;
        struct
        {
            __IO uint32_t enhtimer_pwm_0_dead_zone_size: 8;
            __IO uint32_t enhtimer_pwm_0_emg_stop: 1;
            __IO uint32_t enhtimer_pwm_0_stop_state_0: 1;
            __IO uint32_t enhtimer_pwm_0_stop_state_1: 1;
            __IO uint32_t enhtimer_pwm_0_dummy_b11: 1;
            __IO uint32_t enhtimer_pwm_0_dead_zone_en: 1;
            __IO uint32_t enhtimer_pwm_0_pwm_pn_invserse_sel: 1;
            __IO uint32_t enhtimer_pwm_0_dummy_b14: 1;
            __IO uint32_t enhtimer_pwm_0_dummy_b15: 1;
            __I uint32_t RESERVED_0: 16;
        } BITS_270;
    } u_270;

    union
    {
        __IO uint32_t REG_ENHTIMER_PWM_WRAP_1_CFG;
        struct
        {
            __IO uint32_t enhtimer_pwm_1_dead_zone_size: 8;
            __IO uint32_t enhtimer_pwm_1_emg_stop: 1;
            __IO uint32_t enhtimer_pwm_1_stop_state_0: 1;
            __IO uint32_t enhtimer_pwm_1_stop_state_1: 1;
            __IO uint32_t enhtimer_pwm_1_dummy_b11: 1;
            __IO uint32_t enhtimer_pwm_1_dead_zone_en: 1;
            __IO uint32_t enhtimer_pwm_1_pwm_pn_invserse_sel: 1;
            __IO uint32_t enhtimer_pwm_1_dummy_b14: 1;
            __IO uint32_t enhtimer_pwm_1_dummy_b15: 1;
            __I uint32_t RESERVED_0: 16;
        } BITS_274;
    } u_274;

    union
    {
        __IO uint32_t REG_ENHTIMER_PWM_WRAP_2_CFG;
        struct
        {
            __IO uint32_t enhtimer_pwm_2_dead_zone_size: 8;
            __IO uint32_t enhtimer_pwm_2_emg_stop: 1;
            __IO uint32_t enhtimer_pwm_2_stop_state_0: 1;
            __IO uint32_t enhtimer_pwm_2_stop_state_1: 1;
            __IO uint32_t enhtimer_pwm_2_dummy_b11: 1;
            __IO uint32_t enhtimer_pwm_2_dead_zone_en: 1;
            __IO uint32_t enhtimer_pwm_2_pwm_pn_invserse_sel: 1;
            __IO uint32_t enhtimer_pwm_2_dummy_b14: 1;
            __IO uint32_t enhtimer_pwm_2_dummy_b15: 1;
            __I uint32_t RESERVED_0: 16;
        } BITS_278;
    } u_278;

    union
    {
        __IO uint32_t REG_ENHTIMER_PWM_WRAP_3_CFG;
        struct
        {
            __IO uint32_t enhtimer_pwm_3_dead_zone_size: 8;
            __IO uint32_t enhtimer_pwm_3_emg_stop: 1;
            __IO uint32_t enhtimer_pwm_3_stop_state_0: 1;
            __IO uint32_t enhtimer_pwm_3_stop_state_1: 1;
            __IO uint32_t enhtimer_pwm_3_dummy_b11: 1;
            __IO uint32_t enhtimer_pwm_3_dead_zone_en: 1;
            __IO uint32_t enhtimer_pwm_3_pwm_pn_invserse_sel: 1;
            __IO uint32_t enhtimer_pwm_3_dummy_b14: 1;
            __IO uint32_t enhtimer_pwm_3_dummy_b15: 1;
            __I uint32_t RESERVED_0: 16;
        } BITS_27C;
    } u_27C;

    union
    {
        __IO uint32_t REG_ENHTIMER_PWM_WRAP_4_CFG;
        struct
        {
            __IO uint32_t enhtimer_pwm_4_dead_zone_size: 8;
            __IO uint32_t enhtimer_pwm_4_emg_stop: 1;
            __IO uint32_t enhtimer_pwm_4_stop_state_0: 1;
            __IO uint32_t enhtimer_pwm_4_stop_state_1: 1;
            __IO uint32_t enhtimer_pwm_4_dummy_b11: 1;
            __IO uint32_t enhtimer_pwm_4_dead_zone_en: 1;
            __IO uint32_t enhtimer_pwm_4_pwm_pn_invserse_sel: 1;
            __IO uint32_t enhtimer_pwm_4_dummy_b14: 1;
            __IO uint32_t enhtimer_pwm_4_dummy_b15: 1;
            __I uint32_t RESERVED_0: 16;
        } BITS_280;
    } u_280;

    union
    {
        __IO uint32_t REG_ENHTIMER_PWM_WRAP_5_CFG;
        struct
        {
            __IO uint32_t enhtimer_pwm_5_dead_zone_size: 8;
            __IO uint32_t enhtimer_pwm_5_emg_stop: 1;
            __IO uint32_t enhtimer_pwm_5_stop_state_0: 1;
            __IO uint32_t enhtimer_pwm_5_stop_state_1: 1;
            __IO uint32_t enhtimer_pwm_5_dummy_b11: 1;
            __IO uint32_t enhtimer_pwm_5_dead_zone_en: 1;
            __IO uint32_t enhtimer_pwm_5_pwm_pn_invserse_sel: 1;
            __IO uint32_t enhtimer_pwm_5_dummy_b14: 1;
            __IO uint32_t enhtimer_pwm_5_dummy_b15: 1;
            __I uint32_t RESERVED_0: 16;
        } BITS_284;
    } u_284;

    union
    {
        __IO uint32_t REG_ENHTIMER_PWM_WRAP_6_CFG;
        struct
        {
            __IO uint32_t enhtimer_pwm_6_dead_zone_size: 8;
            __IO uint32_t enhtimer_pwm_6_emg_stop: 1;
            __IO uint32_t enhtimer_pwm_6_stop_state_0: 1;
            __IO uint32_t enhtimer_pwm_6_stop_state_1: 1;
            __IO uint32_t enhtimer_pwm_6_dummy_b11: 1;
            __IO uint32_t enhtimer_pwm_6_dead_zone_en: 1;
            __IO uint32_t enhtimer_pwm_6_pwm_pn_invserse_sel: 1;
            __IO uint32_t enhtimer_pwm_6_dummy_b14: 1;
            __IO uint32_t enhtimer_pwm_6_dummy_b15: 1;
            __I uint32_t RESERVED_0: 16;
        } BITS_288;
    } u_288;

    union
    {
        __IO uint32_t REG_ENHTIMER_PWM_WRAP_7_CFG;
        struct
        {
            __IO uint32_t enhtimer_pwm_7_dead_zone_size: 8;
            __IO uint32_t enhtimer_pwm_7_emg_stop: 1;
            __IO uint32_t enhtimer_pwm_7_stop_state_0: 1;
            __IO uint32_t enhtimer_pwm_7_stop_state_1: 1;
            __IO uint32_t enhtimer_pwm_7_dummy_b11: 1;
            __IO uint32_t enhtimer_pwm_7_dead_zone_en: 1;
            __IO uint32_t enhtimer_pwm_7_pwm_pn_invserse_sel: 1;
            __IO uint32_t enhtimer_pwm_7_dummy_b14: 1;
            __IO uint32_t enhtimer_pwm_7_dummy_b15: 1;
            __I uint32_t RESERVED_0: 16;
        } BITS_28C;
    } u_28C;

} PERI_BLKCTRL_PERI_CLK_TypeDef;

/* reference: Bee3pro_PERI-ON_VCORE3_20220217_draft_v1.xlsx */
typedef struct
{
    union
    {
        __IO uint32_t REG_SOC_AUDIO_IF_EN;//0x00
        struct
        {
            __IO uint32_t sport0_func_en: 1;//bit0
            __IO uint32_t sport0_ck_en: 1;
            __IO uint32_t sport1_func_en: 1;
            __IO uint32_t sport1_ck_en: 1;
            __IO uint32_t sport2_func_en: 1;
            __IO uint32_t sport2_ck_en: 1;
            __IO uint32_t sport3_func_en: 1;
            __IO uint32_t sport3_ck_en: 1;
            __IO uint32_t audio_func_en: 1;
            __IO uint32_t audio_ck_en: 1;
            __IO uint32_t r_CLK_EN_SPORT_40M: 1;
            __IO uint32_t sp0_dsp_clk_sel: 3;
            __IO uint32_t RSVD0: 1;
            __IO uint32_t sp1_dsp_clk_sel: 3;
            __IO uint32_t RSVD1: 1;
            __IO uint32_t sp2_dsp_clk_sel: 3;
            __IO uint32_t RSVD2: 1;
            __IO uint32_t sp3_dsp_clk_sel: 3;
            __IO uint32_t RSVD3: 1;
            __IO uint32_t RSVD4: 1;
            __IO uint32_t RSVD5: 1;
            __IO uint32_t RSVD6: 3;//bit31
        } BITS_900;
    } u_900;

    union
    {
        __IO uint32_t REG_AUDIO_PERI_CTL0;
        struct
        {
            __IO uint32_t r_PLL_DIV0_SETTING: 8;
            __IO uint32_t r_PLL_DIV1_SETTING: 8;
            __IO uint32_t r_PLL_DIV2_SETTING: 8;
            __IO uint32_t r_PLL_DIV3_SETTING: 8;
        } BITS_904;
    } u_904;

    union
    {
        __IO uint32_t REG_AUDIO_PERI_CTL1;
        struct
        {
            __IO uint32_t r_CODEC_i2s0_master_sel: 1;
            __IO uint32_t r_CODEC_i2s1_master_sel: 1;
            __IO uint32_t r_CODEC_i2s2_master_sel: 1;
            __IO uint32_t RSVD0: 1;
            __IO uint32_t r_SPORT0_EXT_CODEC: 1;
            __IO uint32_t r_SPORT1_EXT_CODEC: 1;
            __IO uint32_t r_SPORT2_EXT_CODEC: 1;
            __IO uint32_t RSVD1: 1;
            __IO uint32_t r_SPORT0_MCLK_OUT: 1;
            __IO uint32_t r_SPORT1_MCLK_OUT: 1;
            __IO uint32_t r_SPORT2_MCLK_OUT: 1;
            __IO uint32_t r_SPORT3_MCLK_OUT: 1;
            __IO uint32_t RSVD2: 20;
        } BITS_908;
    } u_908;

    union
    {
        __IO uint32_t REG_USB_CLK_CTL;
        struct
        {
            __IO uint32_t r_usb_clk_src_en: 1;
            __IO uint32_t r_usb_div_sel: 4;
            __IO uint32_t r_usb_div_en: 1;
            __IO uint32_t r_usb_mux_clk_cg_en: 1;
            __IO uint32_t r_usb_clk_src_sel: 1;
            __IO uint32_t iso_int_out_en: 12;
            __IO uint32_t RSVD0: 7;
            __IO uint32_t usb_func_en: 1;
            __IO uint32_t usb_ck_en: 1;
            __IO uint32_t RSVD1: 3;
        } BITS_90C;
    } u_90C;

} PERI_BLKCTRL_PERI_CLK1_TypeDef;

/* ================================================================================ */
/* ================                     Watch Dog                     ================ */
/* ================================================================================ */

/**
  * @brief Watch Dog. (WDG)
  */

typedef struct                              /*!< WDG Structure */
{
    __IO uint32_t WDG_WP : 16;                  /*!< 0x00 */
    __IO uint32_t RSVD0 : 16;
    __IO uint32_t WDG_CLK_DIV_FACTOR : 16;      /*!< 0x04 */
    __IO uint32_t WDG_CNT_LIMIT : 12;
    __IO uint32_t WDG_MODE : 2;
    __IO uint32_t WDG_TIMEOUT_FLG : 1;
    __IO uint32_t WDG_ENABLE : 1;
    __IO uint32_t WDG_CNT_RESET : 16;           /*!< 0x08 */
    __IO uint32_t RSVD1 : 16;
    __IO uint32_t WDG_WP_SEC : 1;               /*!< 0x0C */
    __IO uint32_t WDG_CONFIG_SEC : 1;
    __IO uint32_t WDG_RESET_SEC : 1;
    __IO uint32_t RSVD2 : 29;
    __IO uint32_t RSVD3[6];                     /*!< 0x10 */
    __IO uint32_t WDG_TIMEOUT_FROM_KR0 : 1;     /*!< 0x28 */
    __IO uint32_t WDG_TIMEOUT_FROM_KM0 : 1;
    __IO uint32_t WDG_TIMEOUT_FROM_DSP : 1;
    __IO uint32_t RSVD4 : 29;
    __IO uint32_t RSVD5[3];                     /*!< 0x2C */
    __I uint32_t m4m7_to_bluetooth_idle : 1;    /*!< 0x38 */
    __I uint32_t m4m5m7_to_bluetooth_idle : 1;
    __I uint32_t m4m5m7_to_pmc_idle : 1;
    __I uint32_t m7_to_application_idle : 1;
    __I uint32_t m5_to_application_idle : 1;
    __I uint32_t m4_to_application_idle : 1;
    __IO uint32_t RSVD6 : 26;
}   KM4_WDG_TypeDef;

/**
  * @brief AON Watchdog
  */
typedef struct
{
    /*!< 0x00 0xA5A5: disable AON_WDG_CONFIG write protect; other: enable AON_WDG_CONFIG write protect */
    __IO uint32_t aon_wdg_wp : 16;
    __IO uint32_t aon_wdg_rscd0 : 16;
    /*!< Dividing factor. Watch dog timer is count with /(divfactor+1). Minimum dividing factor is 1. */
    __IO uint32_t aon_wdg_clk_div_factor : 16; /*!< 0x04 */
    /*!< when AON_WDG_CNT>=AON_WDG_CNT_LIMIT then WDG timeout  */
    __IO uint32_t aon_wdg_cnt_limit : 12;
    /*!< "01:Level 1:whole reset chip except xxx; 00:Level 0:whole chip reset(include LV1)" */
    __IO uint32_t aon_wdg_mode : 1;
    /*!< "1:WDG countine count in DLPS 0:WDG stop count in DLPS" */
    __IO uint32_t aon_wdg_cnt_ctl : 1;
    /*!< "when  reg_aon_wdt_cnt_ctl ==0 1:relaod counter when exit DLPS 0:not reload counter when exit DLPS" */
    __IO uint32_t aon_wdg_cnt_reload : 1;
    /*!< "0:stop & reset AON_WDG_CNT; 1:enable AON_WDG_CNT run" */
    __IO uint32_t aon_wdg_en : 1;
    /*!< 0x08 0x5A5A: reset watch dog counter(not stop counter) other: no effect */
    __IO uint32_t aon_wdg_cnt_reset : 16;
    __IO uint32_t aon_wdg_rscd1 : 16;
    /*!< 0x0c "0: AON_WDG_WP register can be accessed by Secure accesses
               1: AON_WDG_WP register can be accessed by Non-secure accesses" */
    __IO uint32_t aon_wdg_wp_sec : 1;
    /*!< "0: AON_WDG_CONFIG register can be accessed by Secure accesses
          1: AON_WDG_CONFIG register can be accessed by Non-secure accesses" */
    __IO uint32_t aon_wdg_config_sec : 1;
    /*!< "0: AON_WDG_RESET_SEC register can be accessed by Secure accesses
          1: AON_WDG_RESET_SEC register can be accessed by Non-secure accesses" */
    __IO uint32_t aon_wdg_reset_sec : 1;
    __IO uint32_t aon_wdg_rscd2 : 29;

} AON_WDG_TypeDef;

/* ================================================================================ */
/* ================                     random generator           ================ */
/* ================================================================================ */

/**
  * @brief random generator. (RAN_GEN)
  */

typedef struct                              /*!< RAN_GEN Structure */
{
    union
    {
        __IO uint32_t CTL;                  /*!< 0x00              */
        struct
        {
            __IO uint32_t rand_gen_en: 1;
            __IO uint32_t seed_upd: 1;
            __IO uint32_t random_req: 1;
            __IO uint32_t opt_rand_upd: 1;
            __IO uint32_t soft_rst: 1;
            __IO uint32_t rsvd: 27;
        } CTL_BITS;
    } u_00;
    __IO uint32_t POLYNOMIAL;               /*!< 0x04              */
    __IO uint32_t SEED;                     /*!< 0x08              */
    __IO uint32_t RAN_NUM;                  /*!< 0x0C              */
} RAN_GEN_TypeDef;


/* ================================================================================ */
/* ================    Peripheral Block Control Platform Clock    ================ */
/* ================================================================================ */

/**
  * @brief Peripheral Block Control Platform Clock. (PERI_BLKCTRL_PF_CLK), PERIBLKCTRL_PF_CLK_REG_BASE
  */
/* reference: Bee3pro_PERI-ON_20220705_draft_v1.xlsx */
typedef struct
{
    union
    {
        __IO uint32_t REG_CPU_CLK_SEL;
        struct
        {
            __IO uint32_t r_cpu_div_sel: 4;
            __IO uint32_t r_cpu_div_en: 1;
            __IO uint32_t RESERVED_3: 11;
            __IO uint32_t r_clk_cpu_f1m_en: 1;
            __IO uint32_t r_clk_cpu_32k_en: 1;
            __IO uint32_t r_clk_cpu_tick_div_sel: 3;
            __IO uint32_t RESERVED_2: 4;
            __IO uint32_t BIT_PERI_CLK_BUS_RAM_SLP: 1;
            __IO uint32_t r_CPU_CLK_SRC_EN: 1;
            __IO uint32_t RESERVED_1: 1;
            __IO uint32_t r_cpu_40m_clk_cg_en: 1;
            __IO uint32_t RESERVED_0: 1;
            __IO uint32_t r_cpu_pll_clk_cg_en: 1;
            __IO uint32_t r_cpu_pll_clk_src_sel: 1;
        } BITS_000;
    } u_000;

    union
    {
        __IO uint32_t REG_CPU_AUTO_SLOW_CTL;
        struct
        {
            __IO uint32_t r_cpu_slow_en: 1;
            __IO uint32_t r_cpu_slow_opt_wfi: 1;
            __IO uint32_t r_cpu_slow_opt_dsp: 1;
            __IO uint32_t r_cpu_auto_slow_filter_en: 1;
            __IO uint32_t r_cpu_div_sel_slow: 4;
            __IO uint32_t RESERVED_1: 1;
            __IO uint32_t r_cpu_low_rate_valid_num1: 4;
            __IO uint32_t r_cpu_div_en_slow: 1;
            __IO uint32_t r_cpu_auto_slow_filter1_en: 1;
            __IO uint32_t r_cpu_slow_opt_dspram_wbuf: 1;
            __IO uint32_t r_cpu_auto_slow_force_update: 1;
            __IO uint32_t RESERVED_0: 11;
            __IO uint32_t r_cpu_low_rate_valid_num: 4;
        } BITS_004;
    } u_004;

    union
    {
        __IO uint32_t REG_DSP_CLK_SEL_1;
        struct
        {
            __IO uint32_t r_dsp_div_sel: 4;
            __IO uint32_t r_dsp_div_sel_slow: 4;
            __IO uint32_t r_dsp_div_en: 1;
            __IO uint32_t r_DSP_CLK_SRC_EN: 1;
            __IO uint32_t r_dsp_auto_slow_filter1_en: 1;
            __IO uint32_t r_dsp_slow_en: 1;
            __IO uint32_t r_dsp_slow_opt_dsp: 1;
            __IO uint32_t r_bus2dspram_fast_clk_en: 1;
            __IO uint32_t r_dsp_low_rate_valid_num1: 4;
            __IO uint32_t r_dsp_auto_slow_filter_en: 1;
            __IO uint32_t r_bus2dspram_ext_num: 4;
            __IO uint32_t r_dsp_slow_opt_dspram_wbuf: 1;
            __IO uint32_t r_dsp_low_rate_valid_num: 4;
            __IO uint32_t r_dsp_clk_src_sel_0: 1;
            __IO uint32_t r_dsp_pll_clk_cg_en: 1;
            __IO uint32_t r_dsp_cko2_clk_cg_en: 1;
            __IO uint32_t r_dsp_div_en_slow: 1;
        } BITS_008;
    } u_008;

    union
    {
        __IO uint32_t REG_APB_CLK_CTL;
        struct
        {
            __IO uint32_t clk_s5_div_sel: 3;
            __IO uint32_t clk_s5_div_en: 1;
            __IO uint32_t clk_s11_div_sel: 3;
            __IO uint32_t clk_s11_div_en: 1;
            __IO uint32_t clk_s7_div_sel: 3;
            __IO uint32_t clk_s7_div_en: 1;
            __IO uint32_t clk_low_div_sel: 3;
            __IO uint32_t clk_low_div_en: 1;
            __IO uint32_t bus_clk_div_sel: 3;
            __IO uint32_t bus_clk_div_en: 1;
            __IO uint32_t r_bus_clk_vcore2_en: 1;
            __IO uint32_t r_bus_clk_vcore4_en: 1;
            __IO uint32_t r_bus_clk_vcore3_en: 1;
            __IO uint32_t r_force_clk_s11_bt_en: 1;
            __IO uint32_t r_force_km4_clk_bt_en: 1;
            __IO uint32_t RESERVED_0: 7;
        } BITS_00C;
    } u_00C;

    union
    {
        __IO uint32_t REG_DUMMY_10_CTRL;
        struct
        {
            __IO uint32_t DUMMY_010_31_0: 32;
        } BITS_010;
    } u_010;

    union
    {
        __IO uint32_t REG_DUMMY_14_CTRL;
        struct
        {
            __IO uint32_t DUMMY_014_31_0: 32;
        } BITS_014;
    } u_014;

    union
    {
        __IO uint32_t REG_PLATFORM_CTRL0;
        struct
        {
            __IO uint32_t WDG_CLK_VCORE2_EN: 1;
            __IO uint32_t otp_ck_en: 1;
            __IO uint32_t otp_func_en: 1;
            __IO uint32_t data_ram_ck_en: 1;
            __IO uint32_t data_ram_func_en: 1;
            __IO uint32_t soc_vendor2_ck_en: 1;
            __IO uint32_t ctrlap_ck_en: 1;
            __IO uint32_t data_ram_dsp_ck_en: 1;
            __IO uint32_t data_ram_dsp_sys_ram_ck_en: 1;
            __IO uint32_t RESERVED_0: 23;
        } BITS_018;
    } u_018;

    __IO uint32_t RSVD_0x1c[1];

    union
    {
        __IO uint32_t REG_DSP_CLK_CTRL0;
        struct
        {
            __IO uint32_t asrc_ck_en: 1;
            __IO uint32_t asrc_func_en: 1;
            __IO uint32_t h2d_ck_en: 1;
            __IO uint32_t h2d_func_en: 1;
            __IO uint32_t dsp_mem_ck_en: 1;
            __IO uint32_t dsp_mem_func_en: 1;
            __IO uint32_t dsp_core_ck_en: 1;
            __IO uint32_t dsp_core_func_en: 1;
            __IO uint32_t dsp_peri_ck_en: 1;
            __IO uint32_t dsp_peri_func_en: 1;
            __IO uint32_t dsp_fft_ck_en: 1;
            __IO uint32_t dsp_fft_func_en: 1;
            __IO uint32_t dsp_sys_ram_ck_en: 1;
            __IO uint32_t dsp_sys_ram_func_en: 1;
            __IO uint32_t RESERVED_0: 18;
        } BITS_020;
    } u_020;

    union
    {
        __IO uint32_t REG_AUTO_SLOW_CTRL0;
        struct
        {
            __IO uint32_t r_cpu_slow_opt_gdma1: 1;
            __IO uint32_t r_cpu_slow_opt_gdma2: 1;
            __IO uint32_t r_cpu_auto_slow_opt2: 1;
            __IO uint32_t r_cpu_slow_opt_sdio0: 1;
            __IO uint32_t r_cpu_slow_opt_sdio1: 1;
            __IO uint32_t r_cpu_slow_opt_usb: 1;
            __IO uint32_t r_cpu_slow_opt_gpu: 1;
            __IO uint32_t r_cpu_slow_opt_display: 1;
            __IO uint32_t r_cpu_slow_opt_sha2: 1;
            __IO uint32_t r_cpu_slow_opt_sha3: 1;
            __IO uint32_t r_cpu_auto_slow_opt3: 1;
            __IO uint32_t r_cpu_auto_slow_new0: 1;
            __IO uint32_t r_cpu_auto_slow_new1: 1;
            __IO uint32_t r_cpu_auto_slow_new2: 1;
            __IO uint32_t r_cpu_auto_slow_new3: 1;
            __IO uint32_t r_cpu_auto_slow_new4: 1;
            __IO uint32_t r_cpu_auto_slow_new5: 1;
            __IO uint32_t r_cpu_auto_slow_new6: 1;
            __IO uint32_t r_cpu_auto_slow_new7: 1;
            __IO uint32_t r_cpu_auto_slow_new8: 1;
            __IO uint32_t r_cpu_auto_slow_new9: 1;
            __IO uint32_t r_cpu_auto_slow_new10: 1;
            __IO uint32_t r_cpu_auto_slow_new11: 1;
            __IO uint32_t r_cpu_auto_slow_new12: 1;
            __IO uint32_t r_cpu_auto_slow_new13: 1;
            __IO uint32_t r_cpu_auto_slow_new14: 1;
            __IO uint32_t r_cpu_auto_slow_new15: 1;
            __IO uint32_t r_cpu_auto_slow_new16: 1;
            __IO uint32_t r_cpu_auto_slow_new17: 1;
            __IO uint32_t r_cpu_auto_slow_new18: 1;
            __IO uint32_t r_cpu_auto_slow_new19: 1;
            __IO uint32_t r_cpu_auto_slow_new20: 1;
        } BITS_024;
    } u_024;

    union
    {
        __IO uint32_t REG_AUTO_SLOW_CTRL1;
        struct
        {
            __IO uint32_t r_dsp_auto_slow_new0: 1;
            __IO uint32_t r_dsp_auto_slow_new1: 1;
            __IO uint32_t r_dsp_auto_slow_new2: 1;
            __IO uint32_t r_dsp_auto_slow_new3: 1;
            __IO uint32_t r_dsp_auto_slow_new4: 1;
            __IO uint32_t r_dsp_auto_slow_new5: 1;
            __IO uint32_t r_dsp_auto_slow_new6: 1;
            __IO uint32_t r_dsp_auto_slow_new7: 1;
            __IO uint32_t r_dsp_auto_slow_new8: 1;
            __IO uint32_t r_dsp_auto_slow_new9: 1;
            __IO uint32_t r_dsp_auto_slow_new10: 1;
            __IO uint32_t r_dsp_auto_slow_new11: 1;
            __IO uint32_t r_dsp_auto_slow_new12: 1;
            __IO uint32_t r_dsp_auto_slow_new13: 1;
            __IO uint32_t r_dsp_auto_slow_new14: 1;
            __IO uint32_t r_dsp_auto_slow_new15: 1;
            __IO uint32_t RESERVED_0: 16;
        } BITS_028;
    } u_028;

    __IO uint32_t RSVD_0x2c[21];

    union
    {
        __IO uint32_t REG_DSP_TOP_CTRL;
        struct
        {
            __IO uint32_t DSP_RUN_STALL: 1;
            __IO uint32_t DSP_STAT_VECTOR_SEL: 1;
            __IO uint32_t reg_bypass_pipe: 1;
            __IO uint32_t RESERVED_0: 29;
        } BITS_080;
    } u_080;

} PERI_BLKCTRL_PF_CLK_TypeDef;

/* ================================================================================ */
/* ================       Peripheral Block Control Internal       ================ */
/* ================================================================================ */

/**
  * @brief Peripheral Block Control Internal. (PERI_BLKCTRL_INTERNAL), PERIBLKCTRL_INTERNAL_REG_BASE
  */
/* reference: Bee3pro_PERI-ON_20220705_draft_v1.xlsx */
typedef struct
{
    __IO uint32_t REG_MISC0;

    union
    {
        __IO uint32_t REG_MISC1;
        struct
        {
            __I uint32_t RL_ID: 4;
            __I uint32_t RTL_ID: 4;
            __IO uint32_t RESERVED_0: 24;
        } BITS_E04;
    } u_E04;

    __IO uint32_t REG_MISC2;

    __IO uint32_t REG_MISC3;

    __IO uint32_t REG_MISC4;

    __IO uint32_t REG_MISC5;

    __IO uint32_t REG_MISC6;

    __IO uint32_t REG_MISC7;

    __IO uint32_t REG_MISC8;

    __IO uint32_t REG_MISC9;

    __IO uint32_t REG_MISC10;

    __IO uint32_t REG_MISC11;

    union
    {
        __IO uint32_t REG_MISC12;
        struct
        {
            __IO uint32_t pke_irom_wr_en_fpga: 1;
            __IO uint32_t sdio_cclk_in_sel_fpga: 2;
            __IO uint32_t flash_clk_sel_fpga: 2;
            __IO uint32_t debug_port_sel_fpga: 2;
            __IO uint32_t RESERVED_0: 25;
        } BITS_E30;
    } u_E30;

    __IO uint32_t RSVD_0xe34[2];

    union
    {
        __IO uint32_t REG_XTAL_PDCK;
        struct
        {
            __IO uint32_t pdck_reset_n: 1;
            __IO uint32_t EN_XTAL_PDCK_DIGI: 1;
            __IO uint32_t PDCK_SEARCH_MODE: 1;
            __IO uint32_t PDCK_WAIT_CYC: 2;
            __IO uint32_t VREF_MANUAL: 5;
            __IO uint32_t VREF_INIT: 5;
            __IO uint32_t XTAL_PDCK_UNIT: 2;
            __IO uint32_t XPDCK_VREF_SEL: 5;
            __IO uint32_t PDCK_LPOW: 1;
            __IO uint32_t RESERVED_0: 5;
            __I uint32_t pdck_state: 4;
        } BITS_E3C;
    } u_E3C;

    __IO uint32_t RSVD_0xe40[8];

    union
    {
        __IO uint32_t REG_AAC_CTRL0;
        struct
        {
            __IO uint32_t rst_n_aac: 1;
            __IO uint32_t offset_plus: 1;
            __IO uint32_t XAAC_GM_offset: 6;
            __IO uint32_t GM_STEP: 1;
            __IO uint32_t GM_INIT: 6;
            __IO uint32_t XTAL_CLK_SET: 3;
            __IO uint32_t GM_STUP: 6;
            __IO uint32_t GM_MANUAL: 6;
            __IO uint32_t r_EN_XTAL_AAC_DIGI: 1;
            __IO uint32_t r_EN_XTAL_AAC_TRIG: 1;
        } BITS_E60;
    } u_E60;

    union
    {
        __IO uint32_t REG_AAC_CTRL1;
        struct
        {
            __I uint32_t XAAC_BUSY: 1;
            __I uint32_t XAAC_READY: 1;
            __I uint32_t XTAL_GM_OUT: 6;
            __I uint32_t xaac_curr_state: 4;
            __IO uint32_t EN_XTAL_AAC_GM: 1;
            __IO uint32_t EN_XTAL_AAC_PKDET: 1;
            __I uint32_t XTAL_PKDET_OUT: 1;
            __IO uint32_t RESERVED_1: 1;
            __IO uint32_t RESERVED_0: 16;
        } BITS_E64;
    } u_E64;

    union
    {
        __IO uint32_t REG_Tmeter_CTRL1;
        struct
        {
            __IO uint32_t trig_tc: 1;
            __IO uint32_t BB_TIMER_BBTRIGGER_RFC: 1;
            __IO uint32_t RESERVED_2: 2;
            __IO uint32_t TMETER_OFFSETVAL: 3;
            __IO uint32_t TMETER_OFFSETIND: 1;
            __IO uint32_t RESERVED_1: 8;
            __I uint32_t TC_STATE_4_0: 5;
            __I uint32_t VLD_TMETER: 1;
            __I uint32_t TC_BUSY: 1;
            __I uint32_t RESERVED_0: 1;
            __I uint32_t TC_TMETER_LATCH_7_0: 8;
        } BITS_E68;
    } u_E68;

    union
    {
        __IO uint32_t REG_Tmeter_CTRL2;
        struct
        {
            __I uint32_t TC_TMETER_LATCH_0: 10;
            __I uint32_t RESERVED_1: 6;
            __I uint32_t TC_TMETER_LATCH_1: 10;
            __I uint32_t RESERVED_0: 6;
        } BITS_E6C;
    } u_E6C;

    __IO uint32_t RSVD_0xe70[28];

    union
    {
        __IO uint32_t REG_BC12_CTRL1;
        struct
        {
            __IO uint32_t det_enable: 1;
            __IO uint32_t vbus_det: 1;
            __IO uint32_t skip_sec_det: 1;
            __IO uint32_t RESERVED_2: 1;
            __IO uint32_t RESERVED_1: 4;
            __I uint32_t sdp_op5a: 1;
            __I uint32_t dcp_cdp_1p5a: 1;
            __I uint32_t cdp_det: 1;
            __I uint32_t dcp_det: 1;
            __I uint32_t others_op5a: 1;
            __I uint32_t apple_1p0a: 1;
            __I uint32_t apple_2p1a: 1;
            __I uint32_t apple_2p4a: 1;
            __I uint32_t det_is_done: 1;
            __I uint32_t note_2p0a: 1;
            __I uint32_t sony_charger: 1;
            __IO uint32_t RESERVED_0: 10;
            __IO uint32_t dcp_option: 1;
            __IO uint32_t bypass_non_std_det: 1;
            __IO uint32_t bypass_dcd_dbnc: 1;
        } BITS_EE0;
    } u_EE0;

    union
    {
        __IO uint32_t REG_BC12_CTRL2;
        struct
        {
            __IO uint32_t fw_write_bus: 7;
            __IO uint32_t RESERVED_2: 1;
            __IO uint32_t fw_ctrl_mode: 1;
            __IO uint32_t RESERVED_1: 7;
            __I uint32_t fw_read_bus: 10;
            __IO uint32_t RESERVED_0: 6;
        } BITS_EE4;
    } u_EE4;

    union
    {
        __IO uint32_t REG_BC12_CTRL3;
        struct
        {
            __IO uint32_t DCD_A_MIN_TIME: 16;
            __IO uint32_t DCD_B_MIN_TIME: 16;
        } BITS_EE8;
    } u_EE8;

    union
    {
        __IO uint32_t REG_BC12_CTRL4;
        struct
        {
            __IO uint32_t PRI_DET_MIN_TIME: 16;
            __IO uint32_t NOTE_DET_MIN_TIME: 16;
        } BITS_EEC;
    } u_EEC;

    union
    {
        __IO uint32_t REG_BC12_CTRL5;
        struct
        {
            __IO uint32_t WAIT_A_MIN_TIME: 16;
            __IO uint32_t SECOND_DET_MIN_TIME: 16;
        } BITS_EF0;
    } u_EF0;

    union
    {
        __IO uint32_t REG_BC12_CTRL6;
        struct
        {
            __IO uint32_t APPLE_DET_MIN_TIME: 16;
            __IO uint32_t RESERVED_0: 16;
        } BITS_EF4;
    } u_EF4;

} PERI_BLKCTRL_INTERNAL_TypeDef;



/**
  * @brief Peripheral. (Peripheral)
  */
/* ================================================================================ */
/* ================                   PERI_ON     0x40000200              ================ */
/* ================================================================================ */
typedef struct                                      /*!< Peripheral Structure */
{
    __IO uint32_t    SYS_CLK_SEL;       /*!< 0x200 */
    __IO uint32_t    SYS_CLK_SEL_2;     /*!< 0x204 */
    __IO uint32_t    SYS_CLK_SEL_3;     /*!< 0x208 */
    __IO uint32_t    r_PON_FUN0_EN;     /*!< 0x210 */
    __IO uint32_t    RSVD0;             /*!< 0x214 */
} PHERION_TypeDef;

/* ================================================================================ */
/* ================              Peripheral Interrupt              ================ */
/* ================================================================================ */
#define PERI_IRQ_BIT_MBIAS_MFB_DET_L     BIT0
#define PERI_IRQ_BIT_mailbox_int         BIT1
#define PERI_IRQ_BIT_utmi_suspend_n      BIT2
#define PERI_IRQ_BIT_dig_trda_int_r      BIT3
#define PERI_IRQ_BIT_rng_int             BIT4
#define PERI_IRQ_BIT_psram_intr          BIT5
#define PERI_IRQ_BIT_dig_lpcomp_int_r    BIT6
#define PERI_IRQ_BIT_timer_intr_5        BIT7
#define PERI_IRQ_BIT_timer_intr_6        BIT8
#define PERI_IRQ_BIT_timer_intr_7        BIT9
#define PERI_IRQ_BIT_dig_lpcomp_int      BIT11
#define PERI_IRQ_BIT_MBIAS_VBAT_DET_L    BIT12
#define PERI_IRQ_BIT_MBIAS_ADP_DET_L     BIT13
#define PERI_IRQ_BIT_HW_ASRC_ISR1        BIT14
#define PERI_IRQ_BIT_HW_ASRC_ISR2        BIT15
#define PERI_IRQ_BIT_gpio_intr_31_6      BIT16
#define PERI_IRQ_BIT_dsp_wdt_to_mcu_intr BIT18
#define PERI_IRQ_BIT_flash_pwr_intr      BIT19
#define PERI_IRQ_BIT_sp0_intr_tx         BIT25
#define PERI_IRQ_BIT_sp0_intr_rx         BIT26
#define PERI_IRQ_BIT_sp1_intr_tx         BIT27
#define PERI_IRQ_BIT_sp1_intr_rx         BIT28

typedef enum
{
    TRIGGER_MODE_HGIH_LEVEL,
    TRIGGER_MODE_EDGE,
} TRIGGER_MODE;

typedef enum
{
    EDGE_MODE_RISING,
    EDGE_MODE_BOTH,
} EDGE_MODE;



/**
  * @brief KM4 SoC Vendor, SOC_VENDOR2_REG_BASE
  */
/* reference: Bee3Pro_SoC_Vender_Reg_20220609.xlsx */
typedef struct
{
    /* 0x000        0x400e_0000
        15:0    R/W    KM4F_WDG_WP                                     16'h0
        31:16   R/W    RSVD                                            16'h0
    */
    union
    {
        __IO uint32_t REG_KM4F_WDG_WP;
        struct
        {
            __IO uint32_t KM4F_WDG_WP: 16;
            __IO uint32_t RESERVED_0: 16;
        } BITS_00;
    } u_00;

    /* 0x004        0x400e_0004
        15:0    R/W    KM4F_WDG_CLK_DIV_FACTOR                         16'hC80
        27:16   R/W    KM4F_WDG_CNT_LIMIT                              12'h64
        29:28   R/W    KM4F_WDG_MODE                                   2'h3
        30      R/W1C  KM4F_WDG_TIMEOUT_FLG                            1'h0
        31      R/W    KM4F_WDG_ENABLE                                 1'h0
    */
    union
    {
        __IO uint32_t REG_KM4F_WDG_CONFIG;
        struct
        {
            __IO uint32_t KM4F_WDG_CLK_DIV_FACTOR: 16;
            __IO uint32_t KM4F_WDG_CNT_LIMIT: 12;
            __IO uint32_t KM4F_WDG_MODE: 2;
            __IO uint32_t KM4F_WDG_TIMEOUT_FLG: 1;
            __IO uint32_t KM4F_WDG_ENABLE: 1;
        } BITS_04;
    } u_04;

    /* 0x008        0x400e_0008
        15:0    R/WAC  KM4F_WDG_CNT_RESET                              16'h0
        31:16   R/WAC  RSVD                                            16'h0
    */
    union
    {
        __IO uint32_t REG_KM4F_WDG_CNT_RESET;
        struct
        {
            __IO uint32_t KM4F_WDG_CNT_RESET: 16;
            __IO uint32_t RESERVED_0: 16;
        } BITS_08;
    } u_08;

    /* 0x00C        0x400e_000c
        0       R/W    KM4F_WDG_WP_SEC                                 1'h0
        1       R/W    KM4F_WDG_CONFIG_SEC                             1'h0
        2       R/W    KM4F_WDG_RESET_SEC                              1'h0
        31:3    R/W    RSVD                                            29'h0
    */
    union
    {
        __IO uint32_t REG_KM4F_WDG_SEC_CTL;
        struct
        {
            __IO uint32_t KM4F_WDG_WP_SEC: 1;
            __IO uint32_t KM4F_WDG_CONFIG_SEC: 1;
            __IO uint32_t KM4F_WDG_RESET_SEC: 1;
            __IO uint32_t RESERVED_0: 29;
        } BITS_0C;
    } u_0C;

    /* 0x0010       0x400e_0010
        0       R/W1C  SPIC0_intr_r                                    1'h0
        1       R/W1C  SPIC1_intr_r                                    1'h0
        2       R/W1C  SPIC2_intr_r                                    1'h0
        3       R/W1C  SPIC3_intr_r                                    1'h0
        4       R/W1C  TRNG_intr_r                                     1'h0
        5       R/W1C  mae_intr_r                                      1'h0
        6       R/W1C  lpcomp_int_r                                    1'h0
        7       R/W1C  spi_phy0_intr_r                                 1'h0
        8       R/W1C  spi_phy12_intr_r                                1'h0
        9       R/W1C  spi_phy3_intr_r                                 1'h0
        30:10   R      RSVD                                            21'h0
        31      R/W1C  utmi_suspend_n_r                                1'h0
    */
    union
    {
        __IO uint32_t REG_LOW_PRI_INT_STATUS;
        struct
        {
            __IO uint32_t SPIC0_intr_r: 1;
            __IO uint32_t SPIC1_intr_r: 1;
            __IO uint32_t SPIC2_intr_r: 1;
            __IO uint32_t SPIC3_intr_r: 1;
            __IO uint32_t TRNG_intr_r: 1;
            __IO uint32_t mae_intr_r: 1;
            __IO uint32_t lpcomp_int_r: 1;
            __IO uint32_t spi_phy0_intr_r: 1;
            __IO uint32_t spi_phy12_intr_r: 1;
            __IO uint32_t spi_phy3_intr_r: 1;
            __I uint32_t RESERVED_0: 21;
            __IO uint32_t utmi_suspend_n_r: 1;
        } BITS_010;
    } u_010;

    __IO uint32_t RSVD_0x14[1];

    /* 0x0018       0x400e_0018
        31:0    R/W    int_mode                                        32'hffffffff
    */
    union
    {
        __IO uint32_t REG_LOW_PRI_INT_MODE;
        struct
        {
            __IO uint32_t int_mode: 32;
        } BITS_018;
    } u_018;

    /* 0x001C       0x400e_001c
        31:0    R/W    int_en                                          32'h0
    */
    union
    {
        __IO uint32_t REG_LOW_PRI_INT_EN;
        struct
        {
            __IO uint32_t int_en: 32;
        } BITS_01C;
    } u_01C;

    /* 0x0020       0x400e_0020
        31:0    RW     int_pol                                         32'h0
    */
    union
    {
        __IO uint32_t REG_INT_EDGE_TRIG_OPT;
        struct
        {
            __IO uint32_t int_pol: 32;
        } BITS_020;
    } u_020;

    /* 0x0024       0x400e_0024
        3:0     R      RSVD                                            4'h0
        4       R/W    display_spi_speed_up_sim                        1'h0
        5       R/W    display_dmac_clk_always_disable                 1'b0
        6       R/W    display_dmac_clk_always_enable                  1'b0
        7       R/W    dmac2_clk_always_disable                        1'b0
        8       R/W    dmac2_clk_always_enable                         1'b0
        9       R/W    dmac_dsp_clk_always_disable                     1'b0
        10      R/W    dmac_dsp_clk_always_enable                      1'b0
        11      R/W    spic_icg_disable                                1'b0
        12      R/W    ic_icg_disable                                  1'b0
        13      R/W    dmac1_clk_always_disable                        1'b0
        14      R/W    dmac1_clk_always_enable                         1'b0
        15      R/W    rxi300_auto_icg_en                              1'h1
        16      R/W    spic0_frqc_ack                                  1'h0
        17      R      spic0_frqc_req                                  1'h0
        18      R/W    spic1_frqc_ack                                  1'h0
        19      R      spic1_frqc_req                                  1'h0
        20      R/W    spic2_frqc_ack                                  1'h0
        21      R      spic2_frqc_req                                  1'h0
        22      R/W    spic3_frqc_ack                                  1'h0
        23      R      spic3_frqc_req                                  1'h0
        28:24   R      RSVD                                            5'h0
        30:29   R/W    uart_force_cg_en                                2'h3
        31      R/W    dsp_dma_int_mask_n                              1'h1
    */
    union
    {
        __IO uint32_t REG_MISC_CTRL;
        struct
        {
            __I uint32_t RESERVED_1: 4;
            __IO uint32_t display_spi_speed_up_sim: 1;
            __IO uint32_t display_dmac_clk_always_disable: 1;
            __IO uint32_t display_dmac_clk_always_enable: 1;
            __IO uint32_t dmac2_clk_always_disable: 1;
            __IO uint32_t dmac2_clk_always_enable: 1;
            __IO uint32_t dmac_dsp_clk_always_disable: 1;
            __IO uint32_t dmac_dsp_clk_always_enable: 1;
            __IO uint32_t spic_icg_disable: 1;
            __IO uint32_t ic_icg_disable: 1;
            __IO uint32_t dmac1_clk_always_disable: 1;
            __IO uint32_t dmac1_clk_always_enable: 1;
            __IO uint32_t rxi300_auto_icg_en: 1;
            __IO uint32_t spic0_frqc_ack: 1;
            __I uint32_t spic0_frqc_req: 1;
            __IO uint32_t spic1_frqc_ack: 1;
            __I uint32_t spic1_frqc_req: 1;
            __IO uint32_t spic2_frqc_ack: 1;
            __I uint32_t spic2_frqc_req: 1;
            __IO uint32_t spic3_frqc_ack: 1;
            __I uint32_t spic3_frqc_req: 1;
            __I uint32_t RESERVED_0: 5;
            __IO uint32_t uart_force_cg_en: 2;
            __IO uint32_t dsp_dma_int_mask_n: 1;
        } BITS_024;
    } u_024;

    /* 0x0028       0x400e_0028
        0       R/W1C  WDG_TIMEOUT_FROM_KR0                            1'h0
        1       R/W1C  WDG_TIMEOUT_FROM_KM0                            1'h0
        2       R/W1C  WDG_TIMEOUT_FROM_DSP                            1'h0
        31:3    R/WAC  RSVD                                            29'h0
    */
    union
    {
        __IO uint32_t REG_KM4_WDG_TIMEOUT_FLAG;
        struct
        {
            __IO uint32_t WDG_TIMEOUT_FROM_KR0: 1;
            __IO uint32_t WDG_TIMEOUT_FROM_KM0: 1;
            __IO uint32_t WDG_TIMEOUT_FROM_DSP: 1;
            __IO uint32_t RESERVED_0: 29;
        } BITS_028;
    } u_028;

    /* 0x002C       0x400e_002c
        0       R/W    gpu_spic0_mem_wr_en                             1'h0
        1       R/W    gpu_spic1_mem_wr_en                             1'h0
        2       R/W    gpu_spic2_mem_wr_en                             1'h0
        3       R/W    gpu_spic3_mem_wr_en                             1'h0
        4       R/W    usbotg_spic0_mem_wr_en                          1'h0
        5       R/W    usbotg_spic1_mem_wr_en                          1'h0
        6       R/W    usbotg_spic2_mem_wr_en                          1'h0
        7       R/W    usbotg_spic3_mem_wr_en                          1'h0
        8       R/W    sha_m_spic0_mem_wr_en                           1'h0
        9       R/W    sha_m_spic1_mem_wr_en                           1'h0
        10      R/W    sha_m_spic2_mem_wr_en                           1'h0
        11      R/W    sha_m_spic3_mem_wr_en                           1'h0
        12      R/W    sdio_host0_spic0_mem_wr_en                      1'h0
        13      R/W    sdio_host0_spic1_mem_wr_en                      1'h0
        14      R/W    sdio_host0_spic2_mem_wr_en                      1'h0
        15      R/W    sdio_host0_spic3_mem_wr_en                      1'h0
        16      R/W    sdio_host1_spic0_mem_wr_en                      1'h0
        17      R/W    sdio_host1_spic1_mem_wr_en                      1'h0
        18      R/W    sdio_host1_spic2_mem_wr_en                      1'h0
        19      R/W    sdio_host1_spic3_mem_wr_en                      1'h0
        20      R/W    dmac2_spic0_mem_wr_en                           1'h0
        21      R/W    dmac2_spic1_mem_wr_en                           1'h0
        22      R/W    dmac2_spic2_mem_wr_en                           1'h0
        23      R/W    dmac2_spic3_mem_wr_en                           1'h0
        24      R/W    display_spic0_mem_wr_en                         1'h0
        25      R/W    display_spic1_mem_wr_en                         1'h0
        26      R/W    display_spic2_mem_wr_en                         1'h0
        27      R/W    display_spic3_mem_wr_en                         1'h0
        31:28   R/W    RSVD                                            4'h0
    */
    union
    {
        __IO uint32_t REG_APP_PLATFORM_SPIC_MEM_WR_EN;
        struct
        {
            __IO uint32_t gpu_spic0_mem_wr_en: 1;
            __IO uint32_t gpu_spic1_mem_wr_en: 1;
            __IO uint32_t gpu_spic2_mem_wr_en: 1;
            __IO uint32_t gpu_spic3_mem_wr_en: 1;
            __IO uint32_t usbotg_spic0_mem_wr_en: 1;
            __IO uint32_t usbotg_spic1_mem_wr_en: 1;
            __IO uint32_t usbotg_spic2_mem_wr_en: 1;
            __IO uint32_t usbotg_spic3_mem_wr_en: 1;
            __IO uint32_t sha_m_spic0_mem_wr_en: 1;
            __IO uint32_t sha_m_spic1_mem_wr_en: 1;
            __IO uint32_t sha_m_spic2_mem_wr_en: 1;
            __IO uint32_t sha_m_spic3_mem_wr_en: 1;
            __IO uint32_t sdio_host0_spic0_mem_wr_en: 1;
            __IO uint32_t sdio_host0_spic1_mem_wr_en: 1;
            __IO uint32_t sdio_host0_spic2_mem_wr_en: 1;
            __IO uint32_t sdio_host0_spic3_mem_wr_en: 1;
            __IO uint32_t sdio_host1_spic0_mem_wr_en: 1;
            __IO uint32_t sdio_host1_spic1_mem_wr_en: 1;
            __IO uint32_t sdio_host1_spic2_mem_wr_en: 1;
            __IO uint32_t sdio_host1_spic3_mem_wr_en: 1;
            __IO uint32_t dmac2_spic0_mem_wr_en: 1;
            __IO uint32_t dmac2_spic1_mem_wr_en: 1;
            __IO uint32_t dmac2_spic2_mem_wr_en: 1;
            __IO uint32_t dmac2_spic3_mem_wr_en: 1;
            __IO uint32_t display_spic0_mem_wr_en: 1;
            __IO uint32_t display_spic1_mem_wr_en: 1;
            __IO uint32_t display_spic2_mem_wr_en: 1;
            __IO uint32_t display_spic3_mem_wr_en: 1;
            __IO uint32_t RESERVED_0: 4;
        } BITS_02C;
    } u_02C;

    /* 0x0030       0x400e_0030
        0       R/W    km4_spic0_mem_wr_en                             1'h0
        1       R/W    km4_spic1_mem_wr_en                             1'h0
        2       R/W    km4_spic2_mem_wr_en                             1'h0
        3       R/W    km4_spic3_mem_wr_en                             1'h0
        4       R/W    dmac1_spic0_mem_wr_en                           1'h0
        5       R/W    dmac1_spic1_mem_wr_en                           1'h0
        6       R/W    dmac1_spic2_mem_wr_en                           1'h0
        7       R/W    dmac1_spic3_mem_wr_en                           1'h0
        31:8    R/W    RSVD                                            24'h0
    */
    union
    {
        __IO uint32_t REG_SENSOR_PLATFORM_SPIC_MEM_WR_EN;
        struct
        {
            __IO uint32_t km4_spic0_mem_wr_en: 1;
            __IO uint32_t km4_spic1_mem_wr_en: 1;
            __IO uint32_t km4_spic2_mem_wr_en: 1;
            __IO uint32_t km4_spic3_mem_wr_en: 1;
            __IO uint32_t dmac1_spic0_mem_wr_en: 1;
            __IO uint32_t dmac1_spic1_mem_wr_en: 1;
            __IO uint32_t dmac1_spic2_mem_wr_en: 1;
            __IO uint32_t dmac1_spic3_mem_wr_en: 1;
            __IO uint32_t RESERVED_0: 24;
        } BITS_030;
    } u_030;

    /* 0x0034       0x400e_0034
        0       W1O    sensor_platform_spic_mem_wr_lock                1'h0
        1       W1O    app_platform_spic_mem_wr_lock                   1'h0
        31:2    R/W    RSVD                                            30'h0
    */
    union
    {
        __IO uint32_t REG_KM4_SPIC_MEM_WR_EN_LOCK;
        struct
        {
            __IO uint32_t sensor_platform_spic_mem_wr_lock: 1;
            __IO uint32_t app_platform_spic_mem_wr_lock: 1;
            __IO uint32_t RESERVED_0: 30;
        } BITS_034;
    } u_034;

    /* 0x0038       0x400e_0038
        0       R      m4m7_to_bluetooth_idle                          1'h1
        1       R      m4m5m7_to_bluetooth_idle                        1'h1
        2       R      m4m5m7_to_pmc_idle                              1'h1
        3       R      m7_to_application_idle                          1'h1
        4       R      m5_to_application_idle                          1'h1
        5       R      m4_to_application_idle                          1'h1
        6       R      RSVD                                            1'h0
        7       R      m8m15_to_bluetooth_idle                         1'h1
        8       R      m8m15_to_sensor_idle                            1'h1
        9       R      m8m14_to_sensor_idle                            1'h1
        10      R      m8m14m15m16_to_pmc_idle                         1'h1
        11      R      RSVD                                            1'h0
        12      R      m2m6_to_sensor_idle                             1'h1
        13      R      m2m6_to_application_idle                        1'h1
        14      R      m2m3m6_to_pmc_idle                              1'h1
        15      R      m3_to_sensor_idle                               1'h1
        16      R      m6_to_application_idle                          1'h1
        17      R      m3_to_application_idle                          1'h1
        18      R      m2_to_application_idle                          1'h1
        19      R      RSVD                                            1'h0
        20      R      m1_to_application_idle                          1'h1
        21      R      RSVD                                            1'h0
        22      R      RSVD                                            1'h0
        23      R      RSVD                                            1'h0
        31:24   R      RSVD                                            8'h0
    */
    union
    {
        __IO uint32_t REG_MASTER_TO_PLATFORM_BUS_IDLE_FLAG;
        struct
        {
            __I uint32_t m4m7_to_bluetooth_idle: 1;
            __I uint32_t m4m5m7_to_bluetooth_idle: 1;
            __I uint32_t m4m5m7_to_pmc_idle: 1;
            __I uint32_t m7_to_application_idle: 1;
            __I uint32_t m5_to_application_idle: 1;
            __I uint32_t m4_to_application_idle: 1;
            __I uint32_t RESERVED_6: 1;
            __I uint32_t m8m15_to_bluetooth_idle: 1;
            __I uint32_t m8m15_to_sensor_idle: 1;
            __I uint32_t m8m14_to_sensor_idle: 1;
            __I uint32_t m8m14m15m16_to_pmc_idle: 1;
            __I uint32_t RESERVED_5: 1;
            __I uint32_t m2m6_to_sensor_idle: 1;
            __I uint32_t m2m6_to_application_idle: 1;
            __I uint32_t m2m3m6_to_pmc_idle: 1;
            __I uint32_t m3_to_sensor_idle: 1;
            __I uint32_t m6_to_application_idle: 1;
            __I uint32_t m3_to_application_idle: 1;
            __I uint32_t m2_to_application_idle: 1;
            __I uint32_t RESERVED_4: 1;
            __I uint32_t m1_to_application_idle: 1;
            __I uint32_t RESERVED_3: 1;
            __I uint32_t RESERVED_2: 1;
            __I uint32_t RESERVED_1: 1;
            __I uint32_t RESERVED_0: 8;
        } BITS_038;
    } u_038;

    /* 0x003C       0x400e_003c
        0       R/W1C  log_req_from_kr0                                1'h0
        1       R/W1C  log_req_from_km0                                1'h0
        31:2    R/W    RSVD                                            30'h0
    */
    union
    {
        __IO uint32_t REG_KM4_CLEAR_LOG_INTR;
        struct
        {
            __IO uint32_t log_req_from_kr0: 1;
            __IO uint32_t log_req_from_km0: 1;
            __IO uint32_t RESERVED_0: 30;
        } BITS_03C;
    } u_03C;

    /* 0x0040       0x400e_0040
        7:0     R/WAC  dmac1_resume                                    8'h0
        15:8    R      RSVD                                            8'h0
        23:16   R/WAC  dmac1_suspend                                   8'h0
        31:24   R      RSVD                                            8'h0
    */
    union
    {
        __IO uint32_t REG_DMAC1_SUSPEND_RESUME;
        struct
        {
            __IO uint32_t dmac1_resume: 8;
            __I uint32_t RESERVED_1: 8;
            __IO uint32_t dmac1_suspend: 8;
            __I uint32_t RESERVED_0: 8;
        } BITS_040;
    } u_040;

    /* 0x0044       0x400e_0044
        15:0    R/WAC  dmac2_resume                                    16'h0
        31:16   R/WAC  dmac2_suspend                                   16'h0
    */
    union
    {
        __IO uint32_t REG_DMAC2_SUSPEND_RESUME;
        struct
        {
            __IO uint32_t dmac2_resume: 16;
            __IO uint32_t dmac2_suspend: 16;
        } BITS_044;
    } u_044;

    /* 0x0048       0x400e_0048
        0       R/WAC  display_dmac_resume                             1'h0
        15:1    R      RSVD                                            15'h0
        16      R/WAC  display_dmac_suspend                            1'h0
        31:17   R      RSVD                                            15'h0
    */
    union
    {
        __IO uint32_t REG_DISPLAYCTRL_CTRL_DMAC_SUSPEND_RESUME;
        struct
        {
            __IO uint32_t display_dmac_resume: 1;
            __I uint32_t RESERVED_1: 15;
            __IO uint32_t display_dmac_suspend: 1;
            __I uint32_t RESERVED_0: 15;
        } BITS_048;
    } u_048;

    __IO uint32_t RSVD_0x4c[1];

    /* 0x0050       0x400e_0050
        0       R/W    data_ram_err_flag_en                            1'h0
        1       R/W    data_ram_err_int_en                             1'h0
        2       R/W    data_ram_rd_flag_clr                            1'h0
        3       R/W    data_ram_err_int_clr                            1'h0
        31:4    R      RSVD                                            18'h0
    */
    union
    {
        __IO uint32_t REG_DATA_RAM_ERR_0;
        struct
        {
            __IO uint32_t data_ram_err_flag_en: 1;
            __IO uint32_t data_ram_err_int_en: 1;
            __IO uint32_t data_ram_rd_flag_clr: 1;
            __IO uint32_t data_ram_err_int_clr: 1;
            __I uint32_t RESERVED_0: 28;
        } BITS_050;
    } u_050;

    /* 0x0054       0x400e_0054
        17:0    R      data_ram_err_flag                               18'h0
        18      R      data_ram_err_int                                1'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_DATA_RAM_ERR_1;
        struct
        {
            __I uint32_t data_ram_err_flag: 18;
            __I uint32_t data_ram_err_int: 1;
            __I uint32_t RESERVED_0: 13;
        } BITS_054;
    } u_054;

    /* 0x0058       0x400e_0058
        0       R/W1C  aon_gpio_wkup_int                               1'h0
        1       R/W1C  aon_lpcomp0_wkup_int                            1'h0
        2       R/W1C  aon_lpcomp1_wkup_int                            1'h0
        3       R/W1C  aon_qdec_wkup_int                               1'h0
        4       R/W1C  aon_vadbuf_wkup_int                             1'h0
        5       R/W1C  aon_vad_wkup_int                                1'h0
        6       R/W1C  aon_usb_wkup_int                                1'h0
        7       R/W1C  aon_rtc_wkup_int                                1'h0
        8       R/W1C  aon_pf_rtc_wkup_int                             1'h0
        31:9    R      RSVD                                            23h0
    */
    union
    {
        __IO uint32_t reg_aon_wkup_int;
        struct
        {
            __IO uint32_t aon_gpio_wkup_int: 1;
            __IO uint32_t aon_lpcomp0_wkup_int: 1;
            __IO uint32_t aon_lpcomp1_wkup_int: 1;
            __IO uint32_t aon_qdec_wkup_int: 1;
            __IO uint32_t aon_vadbuf_wkup_int: 1;
            __IO uint32_t aon_vad_wkup_int: 1;
            __IO uint32_t aon_usb_wkup_int: 1;
            __IO uint32_t aon_rtc_wkup_int: 1;
            __IO uint32_t aon_pf_rtc_wkup_int: 1;
            __I uint32_t RESERVED_0: 23;
        } BITS_058;
    } u_058;

    /* 0x005C       0x400e_005c
        0       R/W    aon_gpio_wkup_int_mask                          1'h1
        1       R/W    aon_lpcomp0_wkup_int_mask                       1'h1
        2       R/W    aon_lpcomp1_wkup_int_mask                       1'h1
        3       R/W    aon_qdec_wkup_int_mask                          1'h1
        4       R/W    aon_vadbuf_wkup_int_mask                        1'h1
        5       R/W    aon_vad_wkup_int_mask                           1'h1
        6       R/W    aon_usb_wkup_int_mask                           1'h1
        7       R/W    aon_rtc_wkup_int_mask                           1'h1
        8       R/W    aon_pf_rtc_wkup_int_mask                        1'h1
        31:9    R      RSVD                                            23h0
    */
    union
    {
        __IO uint32_t reg_aon_wkup_int_mask;
        struct
        {
            __IO uint32_t aon_gpio_wkup_int_mask: 1;
            __IO uint32_t aon_lpcomp0_wkup_int_mask: 1;
            __IO uint32_t aon_lpcomp1_wkup_int_mask: 1;
            __IO uint32_t aon_qdec_wkup_int_mask: 1;
            __IO uint32_t aon_vadbuf_wkup_int_mask: 1;
            __IO uint32_t aon_vad_wkup_int_mask: 1;
            __IO uint32_t aon_usb_wkup_int_mask: 1;
            __IO uint32_t aon_rtc_wkup_int_mask: 1;
            __IO uint32_t aon_pf_rtc_wkup_int_mask: 1;
            __I uint32_t RESERVED_0: 23;
        } BITS_05C;
    } u_05C;

    /* 0x0060       0x400e_0060
        31:0    R/W    soc_vendor2_dummy_reg_0                         32'h0
    */
    union
    {
        __IO uint32_t REG_DUMMY_0;
        struct
        {
            __IO uint32_t soc_vendor2_dummy_reg_0: 32;
        } BITS_060;
    } u_060;

    /* 0x0064       0x400e_0064
        31:0    R/W    soc_vendor2_dummy_reg_1                         32'h0
    */
    union
    {
        __IO uint32_t REG_DUMMY_1;
        struct
        {
            __IO uint32_t soc_vendor2_dummy_reg_1: 32;
        } BITS_064;
    } u_064;

    /* 0x0068       0x400e_0068
        31:0    R/W    soc_vendor2_dummy_reg_2                         32'h0
    */
    union
    {
        __IO uint32_t REG_DUMMY_2;
        struct
        {
            __IO uint32_t soc_vendor2_dummy_reg_2: 32;
        } BITS_068;
    } u_068;

    /* 0x006C       0x400e_006c
        31:0    R/W    soc_vendor2_dummy_reg_3                         32'h0
    */
    union
    {
        __IO uint32_t REG_DUMMY_3;
        struct
        {
            __IO uint32_t soc_vendor2_dummy_reg_3: 32;
        } BITS_06C;
    } u_06C;

    __IO uint32_t RSVD_0x70[36];

    /* 0x0100       0x400e_0100
        3:0     R      s0_pm_m_s0_nmi_if_action                        4'h0
        7:4     R      s0_pm_m_s0_nmi_if_unit_id                       4'h0
        30:8    R      s0_pm_m_s0_nmi_if_dummy_0                       23'h0
        31      R/W1C  s0_pm_m_s0_nmi_if_info_valid                    1'h0
    */
    union
    {
        __IO uint32_t reg0x_s0_pm_m_s0_nmi_if;
        struct
        {
            __I uint32_t s0_pm_m_s0_nmi_if_action: 4;
            __I uint32_t s0_pm_m_s0_nmi_if_unit_id: 4;
            __I uint32_t s0_pm_m_s0_nmi_if_dummy_0: 23;
            __IO uint32_t s0_pm_m_s0_nmi_if_info_valid: 1;
        } BITS_100;
    } u_100;

    /* 0x0104       0x400e_0104
        31:0    R      s0_pm_m_s0_nmi_if_dummy_1                       32'h0
    */
    union
    {
        __IO uint32_t reg1x_s0_pm_m_s0_nmi_if;
        struct
        {
            __I uint32_t s0_pm_m_s0_nmi_if_dummy_1: 32;
        } BITS_104;
    } u_104;

    /* 0x0108       0x400e_0108
        31:0    R      s0_pm_m_s0_nmi_if_dummy_2                       32'h0
    */
    union
    {
        __IO uint32_t reg2x_s0_pm_m_s0_nmi_if;
        struct
        {
            __I uint32_t s0_pm_m_s0_nmi_if_dummy_2: 32;
        } BITS_108;
    } u_108;

    /* 0x010C       0x400e_010c
        31:0    R      s0_pm_m_s0_nmi_if_dummy_3                       32'h0
    */
    union
    {
        __IO uint32_t reg3x_s0_pm_m_s0_nmi_if;
        struct
        {
            __I uint32_t s0_pm_m_s0_nmi_if_dummy_3: 32;
        } BITS_10C;
    } u_10C;

    /* 0x0110       0x400e_0110
        3:0     R      s0_pm_m_s0_if_action                            4'h0
        7:4     R      s0_pm_m_s0_if_unit_id                           4'h0
        8       R      s0_pm_m_s0_if_enable_irq                        1'h0
        9       R      s0_pm_m_s0_if_enter_wfi                         1'h0
        30:10   R      s0_pm_m_s0_if_dummy_0                           21'h0
        31      R/W1C  s0_pm_m_s0_if_info_valid                        1'h0
    */
    union
    {
        __IO uint32_t reg0x_s0_pm_m_s0_if;
        struct
        {
            __I uint32_t s0_pm_m_s0_if_action: 4;
            __I uint32_t s0_pm_m_s0_if_unit_id: 4;
            __I uint32_t s0_pm_m_s0_if_enable_irq: 1;
            __I uint32_t s0_pm_m_s0_if_enter_wfi: 1;
            __I uint32_t s0_pm_m_s0_if_dummy_0: 21;
            __IO uint32_t s0_pm_m_s0_if_info_valid: 1;
        } BITS_110;
    } u_110;

    /* 0x0114       0x400e_0114
        31:0    R      s0_pm_m_s0_if_check_clk                         32'h0
    */
    union
    {
        __IO uint32_t reg1x_s0_pm_m_s0_if;
        struct
        {
            __I uint32_t s0_pm_m_s0_if_check_clk: 32;
        } BITS_114;
    } u_114;

    /* 0x0118       0x400e_0118
        31:0    R      s0_pm_m_s0_if_pre_sys_lv_wakeup_time_diff       32'h0
    */
    union
    {
        __IO uint32_t reg2x_s0_pm_m_s0_if;
        struct
        {
            __I uint32_t s0_pm_m_s0_if_pre_sys_lv_wakeup_time_diff: 32;
        } BITS_118;
    } u_118;

    /* 0x011C       0x400e_011c
        31:0    R      s0_pm_m_s0_if_unit_pf_occupied_start_time_diff  32'h0
    */
    union
    {
        __IO uint32_t reg3x_s0_pm_m_s0_if;
        struct
        {
            __I uint32_t s0_pm_m_s0_if_unit_pf_occupied_start_time_diff: 32;
        } BITS_11C;
    } u_11C;

    /* 0x0120       0x400e_0120
        31:0    R      s0_pm_m_s0_if_unit_pf_occupied_end_time_diff    32'h0
    */
    union
    {
        __IO uint32_t reg4x_s0_pm_m_s0_if;
        struct
        {
            __I uint32_t s0_pm_m_s0_if_unit_pf_occupied_end_time_diff: 32;
        } BITS_120;
    } u_120;

    /* 0x0124       0x400e_0124
        31:0    R      s0_pm_m_s0_if_unit_0_occupied_time_diff         32'h0
    */
    union
    {
        __IO uint32_t reg5x_s0_pm_m_s0_if;
        struct
        {
            __I uint32_t s0_pm_m_s0_if_unit_0_occupied_time_diff: 32;
        } BITS_124;
    } u_124;

    /* 0x0128       0x400e_0128
        31:0    R      s0_pm_m_s0_if_unit_1_occupied_time_diff         32'h0
    */
    union
    {
        __IO uint32_t reg6x_s0_pm_m_s0_if;
        struct
        {
            __I uint32_t s0_pm_m_s0_if_unit_1_occupied_time_diff: 32;
        } BITS_128;
    } u_128;

    /* 0x012C       0x400e_012c
        31:0    R      s0_pm_m_s0_if_unit_2_occupied_time_diff         32'h0
    */
    union
    {
        __IO uint32_t reg7x_s0_pm_m_s0_if;
        struct
        {
            __I uint32_t s0_pm_m_s0_if_unit_2_occupied_time_diff: 32;
        } BITS_12C;
    } u_12C;

    /* 0x0130       0x400e_0130
        3:0     R/W    s0_pm_s0_m_if_action                            4'h0
        7:4     R/W    s0_pm_s0_m_if_unit_id                           4'h0
        9:8     R/W    s0_pm_s0_m_if_check_result                      2'h0
        30:10   R/W    s0_pm_s0_m_if_dummy_0                           21'h0
        31      R/WAC  s0_pm_s0_m_if_info_valid                        1'h0
    */
    union
    {
        __IO uint32_t reg0x_s0_pm_s0_m_if;
        struct
        {
            __IO uint32_t s0_pm_s0_m_if_action: 4;
            __IO uint32_t s0_pm_s0_m_if_unit_id: 4;
            __IO uint32_t s0_pm_s0_m_if_check_result: 2;
            __IO uint32_t s0_pm_s0_m_if_dummy_0: 21;
            __IO uint32_t s0_pm_s0_m_if_info_valid: 1;
        } BITS_130;
    } u_130;

    /* 0x0134       0x400e_0134
        31:0    R/W    s0_pm_s0_m_if_wakeup_time_diff                  32'h0
    */
    union
    {
        __IO uint32_t reg1x_s0_pm_s0_m_if;
        struct
        {
            __IO uint32_t s0_pm_s0_m_if_wakeup_time_diff: 32;
        } BITS_134;
    } u_134;

    /* 0x0138       0x400e_0138
        31:0    R/W    s0_pm_s0_m_if_dummy_2                           32'h0
    */
    union
    {
        __IO uint32_t reg2x_s0_pm_s0_m_if;
        struct
        {
            __IO uint32_t s0_pm_s0_m_if_dummy_2: 32;
        } BITS_138;
    } u_138;

    /* 0x013C       0x400e_013c
        31:0    R/W    s0_pm_s0_m_if_dummy_3                           32'h0
    */
    union
    {
        __IO uint32_t reg3x_s0_pm_s0_m_if;
        struct
        {
            __IO uint32_t s0_pm_s0_m_if_dummy_3: 32;
        } BITS_13C;
    } u_13C;

    __IO uint32_t RSVD_0x140[16];

    /* 0x0180       0x400e_0180
        0       R/W    s0_nmi_ctrl_enable                              1'h0
        31:1    R/W    s0_nmi_ctrl_dummy_0                             31'h0
    */
    union
    {
        __IO uint32_t reg0x_s0_nmi_ctrl;
        struct
        {
            __IO uint32_t s0_nmi_ctrl_enable: 1;
            __IO uint32_t s0_nmi_ctrl_dummy_0: 31;
        } BITS_180;
    } u_180;

    __IO uint32_t RSVD_0x184[95];

    /* 0x0300       0x400e_0300
        15:0    R/W    km4_keep_0                                      16'h0
        31:16   R/W    km4_keep_1                                      16'hFFFF
    */
    union
    {
        __IO uint32_t REG_KM4_KEEP_BOUNDARY;
        struct
        {
            __IO uint32_t km4_keep_0: 16;
            __IO uint32_t km4_keep_1: 16;
        } BITS_300;
    } u_300;

    /* 0x0304       0x400e_0304
        31:0    R/W    km4_initpbusrange                               32'h4000E000
    */
    union
    {
        __IO uint32_t REG_KM4_INITPBUSRANGE;
        struct
        {
            __IO uint32_t km4_initpbusrange: 32;
        } BITS_304;
    } u_304;

    /* 0x0308       0x400e_0308
        31:0    R/W    km4_initzwfrange                                32'h0
    */
    union
    {
        __IO uint32_t REG_KM4_INITZWFRANGE;
        struct
        {
            __IO uint32_t km4_initzwfrange: 32;
        } BITS_308;
    } u_308;

    /* 0x030C       0x400e_030c
        26:0    R/W    km4_init_xo_range_top                           27'h00000ff
        27      R/W    km4_init_xo_range_en                            1'h1
        28      W1O    km4_xo_range_lock                               1'h0
        31:29   R      RSVD                                            3'h0
    */
    union
    {
        __IO uint32_t REG_KM4_XO_CFG_0;
        struct
        {
            __IO uint32_t km4_init_xo_range_top: 27;
            __IO uint32_t km4_init_xo_range_en: 1;
            __IO uint32_t km4_xo_range_lock: 1;
            __I uint32_t RESERVED_0: 3;
        } BITS_30C;
    } u_30C;

    /* 0x0310       0x400e_0310
        26:0    R/W    km4_init_xo_range_base                          27'h0
        31:27   R      RSVD                                            5'h0
    */
    union
    {
        __IO uint32_t REG_KM4_XO_CFG_1;
        struct
        {
            __IO uint32_t km4_init_xo_range_base: 27;
            __I uint32_t RESERVED_0: 5;
        } BITS_310;
    } u_310;

    /* 0x0314       0x400e_0314
        0       R/W    r_km4_dvfs_en                                   1'h0
        3:1     R/W    r_km4_dvfs_dmac0_chn_en                         3'h0
        11:4    R/W    r_km4_dvfs_dmac1_chn_en                         8'h0
        27:12   R/W    r_km4_dvfs_dmac2_chn_en                         18'h0
        28      R/W    r_km4_dvfs_disp_chn_en                          1'h0
        31:29   R      RSVD                                            3'h0
    */
    union
    {
        __IO uint32_t REG_KM4_DVFS_CTRL;
        struct
        {
            __IO uint32_t r_km4_dvfs_en: 1;
            __IO uint32_t r_km4_dvfs_dmac0_chn_en: 3;
            __IO uint32_t r_km4_dvfs_dmac1_chn_en: 8;
            __IO uint32_t r_km4_dvfs_dmac2_chn_en: 16;
            __IO uint32_t r_km4_dvfs_disp_chn_en: 1;
            __I uint32_t RESERVED_0: 3;
        } BITS_314;
    } u_314;

    /* 0x0318       0x400e_0318
        0       R/W    km4_retention_mode                              1'h0
        31:1    R      RSVD                                            31'h0
    */
    union
    {
        __IO uint32_t REG_KM4_RET_CFG_0;
        struct
        {
            __IO uint32_t km4_retention_mode: 1;
            __I uint32_t RESERVED_0: 31;
        } BITS_318;
    } u_318;

    __IO uint32_t RSVD_0x31c[57];

    /* 0x0400       0x400e_0400
        31:0    R/W    reg_enhtimer_0_latch_trig_0_sel                 32'h0
    */
    union
    {
        __IO uint32_t REG_ENHTIMER_0_LATCH_TRIG_0_CFG;
        struct
        {
            __IO uint32_t reg_enhtimer_0_latch_trig_0_sel: 32;
        } BITS_400;
    } u_400;

    /* 0x0404       0x400e_0404
        31:0    R/W    reg_enhtimer_1_latch_trig_0_sel                 32'h0
    */
    union
    {
        __IO uint32_t REG_ENHTIMER_1_LATCH_TRIG_0_CFG;
        struct
        {
            __IO uint32_t reg_enhtimer_1_latch_trig_0_sel: 32;
        } BITS_404;
    } u_404;

    /* 0x0408       0x400e_0408
        31:0    R/W    reg_enhtimer_2_latch_trig_0_sel                 32'h0
    */
    union
    {
        __IO uint32_t REG_ENHTIMER_2_LATCH_TRIG_0_CFG;
        struct
        {
            __IO uint32_t reg_enhtimer_2_latch_trig_0_sel: 32;
        } BITS_408;
    } u_408;

    /* 0x040C       0x400e_040c
        31:0    R/W    reg_enhtimer_3_latch_trig_0_sel                 32'h0
    */
    union
    {
        __IO uint32_t REG_ENHTIMER_3_LATCH_TRIG_0_CFG;
        struct
        {
            __IO uint32_t reg_enhtimer_3_latch_trig_0_sel: 32;
        } BITS_40C;
    } u_40C;

    /* 0x0410       0x400e_0410
        31:0    R/W    reg_enhtimer_4_latch_trig_0_sel                 32'h0
    */
    union
    {
        __IO uint32_t REG_ENHTIMER_4_LATCH_TRIG_0_CFG;
        struct
        {
            __IO uint32_t reg_enhtimer_4_latch_trig_0_sel: 32;
        } BITS_410;
    } u_410;

    /* 0x0414       0x400e_0414
        31:0    R/W    reg_enhtimer_5_latch_trig_0_sel                 32'h0
    */
    union
    {
        __IO uint32_t REG_ENHTIMER_5_LATCH_TRIG_0_CFG;
        struct
        {
            __IO uint32_t reg_enhtimer_5_latch_trig_0_sel: 32;
        } BITS_414;
    } u_414;

    /* 0x0418       0x400e_0418
        31:0    R/W    reg_enhtimer_6_latch_trig_0_sel                 32'h0
    */
    union
    {
        __IO uint32_t REG_ENHTIMER_6_LATCH_TRIG_0_CFG;
        struct
        {
            __IO uint32_t reg_enhtimer_6_latch_trig_0_sel: 32;
        } BITS_418;
    } u_418;

    /* 0x041C       0x400e_041c
        31:0    R/W    reg_enhtimer_7_latch_trig_0_sel                 32'h0
    */
    union
    {
        __IO uint32_t REG_ENHTIMER_7_LATCH_TRIG_0_CFG;
        struct
        {
            __IO uint32_t reg_enhtimer_7_latch_trig_0_sel: 32;
        } BITS_41C;
    } u_41C;

    /* 0x0420       0x400e_0420
        11:0    R/W    debug_sel_sensor                                12'h0
        15:12   R      RSVD                                            4'h0
        27:16   R/W    debug_sel_app                                   12'h0
        31:28   R      RSVD                                            4'h0
    */
    union
    {
        __IO uint32_t REG_DEBUG_CFG;
        struct
        {
            __IO uint32_t debug_sel_sensor: 12;
            __I uint32_t RESERVED_1: 4;
            __IO uint32_t debug_sel_app: 12;
            __I uint32_t RESERVED_0: 4;
        } BITS_420;
    } u_420;

    __IO uint32_t RSVD_0x424[120];

    /* 0x0604       0x400e_0604
        31:0    R      cpu_sys_timer_cnt                               32'h0
    */
    union
    {
        __IO uint32_t REG_CPU_SYS_TIMER_CNT;
        struct
        {
            __I uint32_t cpu_sys_timer_cnt: 32;
        } BITS_604;
    } u_604;

    __IO uint32_t RSVD_0x608[126];

    /* 0x0800       0x400e_0800
        31:0    R      misr_dataout_rom_0_0_31                         32'h0
    */
    union
    {
        __IO uint32_t REG_KM4_ROM0_MISR0;
        struct
        {
            __I uint32_t misr_dataout_rom_0_0_31: 32;
        } BITS_800;
    } u_800;

    /* 0x0804       0x400e_0804
        31:0    R      misr_dataout_rom_0_32_63                        32'h0
    */
    union
    {
        __IO uint32_t REG_KM4_ROM0_MISR1;
        struct
        {
            __I uint32_t misr_dataout_rom_0_32_63: 32;
        } BITS_804;
    } u_804;

    /* 0x0808       0x400e_0808
        31:0    R      misr_dataout_rom_1_0_31                         32'h0
    */
    union
    {
        __IO uint32_t REG_KM4_ROM1_MISR0;
        struct
        {
            __I uint32_t misr_dataout_rom_1_0_31: 32;
        } BITS_808;
    } u_808;

    /* 0x080C       0x400e_080c
        31:0    R      misr_dataout_rom_1_32_63                        32'h0
    */
    union
    {
        __IO uint32_t REG_KM4_ROM1_MISR1;
        struct
        {
            __I uint32_t misr_dataout_rom_1_32_63: 32;
        } BITS_80C;
    } u_80C;

    /* 0x0810       0x400e_0810
        31:0    R      misr_dataout_rom_2_0_31                         32'h0
    */
    union
    {
        __IO uint32_t REG_KM4_ROM2_MISR0;
        struct
        {
            __I uint32_t misr_dataout_rom_2_0_31: 32;
        } BITS_810;
    } u_810;

    /* 0x0814       0x400e_0814
        31:0    R      misr_dataout_rom_2_32_63                        32'h0
    */
    union
    {
        __IO uint32_t REG_KM4_ROM2_MISR1;
        struct
        {
            __I uint32_t misr_dataout_rom_2_32_63: 32;
        } BITS_814;
    } u_814;

    /* 0x0818       0x400e_0818
        31:0    R      misr_dataout_rom_3_0_31                         32'h0
    */
    union
    {
        __IO uint32_t REG_KM4_ROM3_MISR0;
        struct
        {
            __I uint32_t misr_dataout_rom_3_0_31: 32;
        } BITS_818;
    } u_818;

    /* 0x081C       0x400e_081c
        31:0    R      misr_dataout_rom_3_32_63                        32'h0
    */
    union
    {
        __IO uint32_t REG_KM4_ROM3_MISR1;
        struct
        {
            __I uint32_t misr_dataout_rom_3_32_63: 32;
        } BITS_81C;
    } u_81C;

    /* 0x0820       0x400e_0820
        31:0    R      misr_dataout_rom_4_0_31                         32'h0
    */
    union
    {
        __IO uint32_t REG_KM4_ROM4_MISR0;
        struct
        {
            __I uint32_t misr_dataout_rom_4_0_31: 32;
        } BITS_820;
    } u_820;

    /* 0x0824       0x400e_0824
        31:0    R      misr_dataout_rom_4_32_63                        32'h0
    */
    union
    {
        __IO uint32_t REG_KM4_ROM4_MISR1;
        struct
        {
            __I uint32_t misr_dataout_rom_4_32_63: 32;
        } BITS_824;
    } u_824;

    /* 0x0828       0x400e_0828
        31:0    R      misr_dataout_rom_5_0_31                         32'h0
    */
    union
    {
        __IO uint32_t REG_KM4_ROM5_MISR0;
        struct
        {
            __I uint32_t misr_dataout_rom_5_0_31: 32;
        } BITS_828;
    } u_828;

    /* 0x082C       0x400e_082c
        31:0    R      misr_dataout_rom_5_32_63                        32'h0
    */
    union
    {
        __IO uint32_t REG_KM4_ROM5_MISR1;
        struct
        {
            __I uint32_t misr_dataout_rom_5_32_63: 32;
        } BITS_82C;
    } u_82C;

    /* 0x0830       0x400e_0830
        31:0    R      misr_dataout_rom_6_0_31                         32'h0
    */
    union
    {
        __IO uint32_t REG_KM4_ROM6_MISR0;
        struct
        {
            __I uint32_t misr_dataout_rom_6_0_31: 32;
        } BITS_830;
    } u_830;

    /* 0x0834       0x400e_0834
        31:0    R      misr_dataout_rom_6_32_63                        32'h0
    */
    union
    {
        __IO uint32_t REG_KM4_ROM6_MISR1;
        struct
        {
            __I uint32_t misr_dataout_rom_6_32_63: 32;
        } BITS_834;
    } u_834;

    /* 0x0838       0x400e_0838
        31:0    R      misr_dataout_rom_7_0_31                         32'h0
    */
    union
    {
        __IO uint32_t REG_KM4_ROM7_MISR0;
        struct
        {
            __I uint32_t misr_dataout_rom_7_0_31: 32;
        } BITS_838;
    } u_838;

    /* 0x083C       0x400e_083c
        31:0    R      misr_dataout_rom_7_32_63                        32'h0
    */
    union
    {
        __IO uint32_t REG_KM4_ROM7_MISR1;
        struct
        {
            __I uint32_t misr_dataout_rom_7_32_63: 32;
        } BITS_83C;
    } u_83C;

    /* 0x0840       0x400e_0840
        31:0    R      misr_dataout_0_dsp_rom_0_31                     32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM0_MISR0;
        struct
        {
            __I uint32_t misr_dataout_0_dsp_rom_0_31: 32;
        } BITS_840;
    } u_840;

    /* 0x0844       0x400e_0844
        31:0    R      misr_dataout_0_dsp_rom_32_63                    32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM0_MISR1;
        struct
        {
            __I uint32_t misr_dataout_0_dsp_rom_32_63: 32;
        } BITS_844;
    } u_844;

    /* 0x0848       0x400e_0848
        31:0    R      misr_dataout_1_dsp_rom_0_31                     32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM1_MISR0;
        struct
        {
            __I uint32_t misr_dataout_1_dsp_rom_0_31: 32;
        } BITS_848;
    } u_848;

    /* 0x084C       0x400e_084c
        31:0    R      misr_dataout_1_dsp_rom_32_63                    32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM1_MISR1;
        struct
        {
            __I uint32_t misr_dataout_1_dsp_rom_32_63: 32;
        } BITS_84C;
    } u_84C;

    /* 0x0850       0x400e_0850
        31:0    R      misr_dataout_2_dsp_rom_0_31                     32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM2_MISR0;
        struct
        {
            __I uint32_t misr_dataout_2_dsp_rom_0_31: 32;
        } BITS_850;
    } u_850;

    /* 0x0854       0x400e_0854
        31:0    R      misr_dataout_2_dsp_rom_32_63                    32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM2_MISR1;
        struct
        {
            __I uint32_t misr_dataout_2_dsp_rom_32_63: 32;
        } BITS_854;
    } u_854;

    /* 0x0858       0x400e_0858
        31:0    R      misr_dataout_3_dsp_rom_0_31                     32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM3_MISR0;
        struct
        {
            __I uint32_t misr_dataout_3_dsp_rom_0_31: 32;
        } BITS_858;
    } u_858;

    /* 0x085C       0x400e_085c
        31:0    R      misr_dataout_3_dsp_rom_32_63                    32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM3_MISR1;
        struct
        {
            __I uint32_t misr_dataout_3_dsp_rom_32_63: 32;
        } BITS_85C;
    } u_85C;

    /* 0x0860       0x400e_0860
        31:0    R      misr_dataout_4_dsp_rom_0_31                     32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM4_MISR0;
        struct
        {
            __I uint32_t misr_dataout_4_dsp_rom_0_31: 32;
        } BITS_860;
    } u_860;

    /* 0x0864       0x400e_0864
        31:0    R      misr_dataout_4_dsp_rom_32_63                    32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM4_MISR1;
        struct
        {
            __I uint32_t misr_dataout_4_dsp_rom_32_63: 32;
        } BITS_864;
    } u_864;

    /* 0x0868       0x400e_0868
        31:0    R      misr_dataout_5_dsp_rom_0_31                     32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM5_MISR0;
        struct
        {
            __I uint32_t misr_dataout_5_dsp_rom_0_31: 32;
        } BITS_868;
    } u_868;

    /* 0x086C       0x400e_086c
        31:0    R      misr_dataout_5_dsp_rom_32_63                    32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM5_MISR1;
        struct
        {
            __I uint32_t misr_dataout_5_dsp_rom_32_63: 32;
        } BITS_86C;
    } u_86C;

    /* 0x0870       0x400e_0870
        31:0    R      misr_dataout_6_dsp_rom_0_31                     32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM6_MISR0;
        struct
        {
            __I uint32_t misr_dataout_6_dsp_rom_0_31: 32;
        } BITS_870;
    } u_870;

    /* 0x0874       0x400e_0874
        31:0    R      misr_dataout_6_dsp_rom_32_63                    32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM6_MISR1;
        struct
        {
            __I uint32_t misr_dataout_6_dsp_rom_32_63: 32;
        } BITS_874;
    } u_874;

    /* 0x0878       0x400e_0878
        31:0    R      misr_dataout_7_dsp_rom_0_31                     32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM7_MISR0;
        struct
        {
            __I uint32_t misr_dataout_7_dsp_rom_0_31: 32;
        } BITS_878;
    } u_878;

    /* 0x087C       0x400e_087c
        31:0    R      misr_dataout_7_dsp_rom_32_63                    32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM7_MISR1;
        struct
        {
            __I uint32_t misr_dataout_7_dsp_rom_32_63: 32;
        } BITS_87C;
    } u_87C;

    /* 0x0880       0x400e_0880
        31:0    R      misr_dataout_8_dsp_rom_0_31                     32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM8_MISR0;
        struct
        {
            __I uint32_t misr_dataout_8_dsp_rom_0_31: 32;
        } BITS_880;
    } u_880;

    /* 0x0884       0x400e_0884
        31:0    R      misr_dataout_8_dsp_rom_32_63                    32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM8_MISR1;
        struct
        {
            __I uint32_t misr_dataout_8_dsp_rom_32_63: 32;
        } BITS_884;
    } u_884;

    /* 0x0888       0x400e_0888
        31:0    R      misr_dataout_9_dsp_rom_0_31                     32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM9_MISR0;
        struct
        {
            __I uint32_t misr_dataout_9_dsp_rom_0_31: 32;
        } BITS_888;
    } u_888;

    /* 0x088C       0x400e_088c
        31:0    R      misr_dataout_9_dsp_rom_32_63                    32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM9_MISR1;
        struct
        {
            __I uint32_t misr_dataout_9_dsp_rom_32_63: 32;
        } BITS_88C;
    } u_88C;

    /* 0x0890       0x400e_0890
        31:0    R      misr_dataout_10_dsp_rom_0_31                    32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM10_MISR0;
        struct
        {
            __I uint32_t misr_dataout_10_dsp_rom_0_31: 32;
        } BITS_890;
    } u_890;

    /* 0x0894       0x400e_0894
        31:0    R      misr_dataout_10_dsp_rom_32_63                   32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM10_MISR1;
        struct
        {
            __I uint32_t misr_dataout_10_dsp_rom_32_63: 32;
        } BITS_894;
    } u_894;

    /* 0x0898       0x400e_0898
        31:0    R      misr_dataout_11_dsp_rom_0_31                    32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM11_MISR0;
        struct
        {
            __I uint32_t misr_dataout_11_dsp_rom_0_31: 32;
        } BITS_898;
    } u_898;

    /* 0x089C       0x400e_089c
        31:0    R      misr_dataout_11_dsp_rom_32_63                   32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM11_MISR1;
        struct
        {
            __I uint32_t misr_dataout_11_dsp_rom_32_63: 32;
        } BITS_89C;
    } u_89C;

    /* 0x08A0       0x400e_08a0
        31:0    R      misr_dataout_12_dsp_rom_0_31                    32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM12_MISR0;
        struct
        {
            __I uint32_t misr_dataout_12_dsp_rom_0_31: 32;
        } BITS_8A0;
    } u_8A0;

    /* 0x08A4       0x400e_08a4
        31:0    R      misr_dataout_12_dsp_rom_32_63                   32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM12_MISR1;
        struct
        {
            __I uint32_t misr_dataout_12_dsp_rom_32_63: 32;
        } BITS_8A4;
    } u_8A4;

    /* 0x08A8       0x400e_08a8
        31:0    R      misr_dataout_13_dsp_rom_0_31                    32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM13_MISR0;
        struct
        {
            __I uint32_t misr_dataout_13_dsp_rom_0_31: 32;
        } BITS_8A8;
    } u_8A8;

    /* 0x08AC       0x400e_08ac
        31:0    R      misr_dataout_13_dsp_rom_32_63                   32'h0
    */
    union
    {
        __IO uint32_t REG_DSP_ROM13_MISR1;
        struct
        {
            __I uint32_t misr_dataout_13_dsp_rom_32_63: 32;
        } BITS_8AC;
    } u_8AC;

    /* 0x08B0       0x400e_08b0
        31:0    R      misr_dataout_0_pke_rom_0_31                     32'h0
    */
    union
    {
        __IO uint32_t REG_PKE_ROM0_MISR0;
        struct
        {
            __I uint32_t misr_dataout_0_pke_rom_0_31: 32;
        } BITS_8B0;
    } u_8B0;

    /* 0x08B4       0x400e_08b4
        31:0    R      misr_dataout_0_pke_rom_32_63                    32'h0
    */
    union
    {
        __IO uint32_t REG_PKE_ROM0_MISR1;
        struct
        {
            __I uint32_t misr_dataout_0_pke_rom_32_63: 32;
        } BITS_8B4;
    } u_8B4;

    /* 0x08B8       0x400e_08b8
        13:0    R/W    bist_rstn_dsp_rom                               14'h0
        15:14   R      RSVD                                            2'h0
        16      R/W    bist_rstn_pke_rom                               1'h0
        23:17   R      RSVD                                            7'h0
        31:24   R/W    bist_rstn_km4_rom                               8'h0
    */
    union
    {
        __IO uint32_t REG_ROM_BIST_RSTN;
        struct
        {
            __IO uint32_t bist_rstn_dsp_rom: 14;
            __I uint32_t RESERVED_1: 2;
            __IO uint32_t bist_rstn_pke_rom: 1;
            __I uint32_t RESERVED_0: 7;
            __IO uint32_t bist_rstn_km4_rom: 8;
        } BITS_8B8;
    } u_8B8;

    /* 0x08BC       0x400e_08bc
        13:0    R/W    bist_mode_dsp_rom                               14'h0
        15:14   R      RSVD                                            2'h0
        16      R/W    bist_mode_pke_rom                               1'h0
        23:17   R      RSVD                                            7'h0
        31:24   R/W    bist_mode_km4_rom                               8'h0
    */
    union
    {
        __IO uint32_t REG_ROM_BIST_MODE;
        struct
        {
            __IO uint32_t bist_mode_dsp_rom: 14;
            __I uint32_t RESERVED_1: 2;
            __IO uint32_t bist_mode_pke_rom: 1;
            __I uint32_t RESERVED_0: 7;
            __IO uint32_t bist_mode_km4_rom: 8;
        } BITS_8BC;
    } u_8BC;

    /* 0x08C0       0x400e_08c0
        13:0    R      bist_done_dsp_rom                               14'h0
        15:14   R      RSVD                                            2'h0
        16      R      bist_done_pke_rom                               1'h0
        23:17   R      RSVD                                            7'h0
        31:24   R      bist_done_km4_rom                               8'h0
    */
    union
    {
        __IO uint32_t REG_ROM_BIST_DONE;
        struct
        {
            __I uint32_t bist_done_dsp_rom: 14;
            __I uint32_t RESERVED_1: 2;
            __I uint32_t bist_done_pke_rom: 1;
            __I uint32_t RESERVED_0: 7;
            __I uint32_t bist_done_km4_rom: 8;
        } BITS_8C0;
    } u_8C0;

    /* 0x08C4       0x400e_08c4
        0       R/W    bist_mem_speed_mode_dsp_rom                     1'h0
        15:1    R      RSVD                                            15'h0
        16      R/W    bist_mem_speed_mode_pke_rom                     1'h0
        30:17   R      RSVD                                            14'h0
        31      R/W    bist_mem_speed_mode_km4_rom                     1'h0
    */
    union
    {
        __IO uint32_t REG_ROM_BIST_MEM_SPEED_MODE;
        struct
        {
            __IO uint32_t bist_mem_speed_mode_dsp_rom: 1;
            __I uint32_t RESERVED_1: 15;
            __IO uint32_t bist_mem_speed_mode_pke_rom: 1;
            __I uint32_t RESERVED_0: 14;
            __IO uint32_t bist_mem_speed_mode_km4_rom: 1;
        } BITS_8C4;
    } u_8C4;

    /* 0x08C8       0x400e_08c8
        0       R/W    bist_vddr_en                                    0
        1       R/W    bist_loop_mode                                  0
        31:2    R      RSVD                                            30'h0
    */
    union
    {
        __IO uint32_t REG_SRAM_CTRL;
        struct
        {
            __IO uint32_t bist_vddr_en: 1;
            __IO uint32_t bist_loop_mode: 1;
            __I uint32_t RESERVED_0: 30;
        } BITS_8C8;
    } u_8C8;

    __IO uint32_t RSVD_0x8cc[13];

    /* 0x0900       0x400e_0900
        2:0     R/W    bist_rstn_pke                                   3'h0
        5:3     R      RSVD                                            3'h0
        7:6     R/W    bist_rstn_vadbuf                                2'h0
        8       R      RSVD                                            1'h0
        10:9    R/W    bist_rstn_display                               2'h0
        13:11   R/W    bist_rstn_mipi                                  3'h0
        15:14   R/W    bist_rstn_sd                                    2'h0
        17:16   R      RSVD                                            2'h0
        18      R/W    bist_rstn_usb                                   1'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_OTHER_BIST_RSTN;
        struct
        {
            __IO uint32_t bist_rstn_pke: 3;
            __I uint32_t RESERVED_3: 3;
            __IO uint32_t bist_rstn_vadbuf: 2;
            __I uint32_t RESERVED_2: 1;
            __IO uint32_t bist_rstn_display: 2;
            __IO uint32_t bist_rstn_mipi: 3;
            __IO uint32_t bist_rstn_sd: 2;
            __I uint32_t RESERVED_1: 2;
            __IO uint32_t bist_rstn_usb: 1;
            __I uint32_t RESERVED_0: 13;
        } BITS_900;
    } u_900;

    /* 0x0904       0x400e_0904
        2:0     R/W    bist_mode_pke                                   3'h0
        5:3     R      RSVD                                            3'h0
        7:6     R/W    bist_mode_vadbuf                                2'h0
        8       R      RSVD                                            1'h0
        10:9    R/W    bist_mode_display                               2'h0
        13:11   R/W    bist_mode_mipi                                  3'h0
        15:14   R/W    bist_mode_sd                                    2'h0
        17:16   R      RSVD                                            2'h0
        18      R/W    bist_mode_usb                                   1'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_OTHER_BIST_MODE;
        struct
        {
            __IO uint32_t bist_mode_pke: 3;
            __I uint32_t RESERVED_3: 3;
            __IO uint32_t bist_mode_vadbuf: 2;
            __I uint32_t RESERVED_2: 1;
            __IO uint32_t bist_mode_display: 2;
            __IO uint32_t bist_mode_mipi: 3;
            __IO uint32_t bist_mode_sd: 2;
            __I uint32_t RESERVED_1: 2;
            __IO uint32_t bist_mode_usb: 1;
            __I uint32_t RESERVED_0: 13;
        } BITS_904;
    } u_904;

    /* 0x0908       0x400e_0908
        2:0     R/W    bist_mode_drf_pke                               3'h0
        5:3     R      RSVD                                            3'h0
        7:6     R/W    bist_mode_drf_vadbuf                            2'h0
        8       R      RSVD                                            1'h0
        10:9    R/W    bist_mode_drf_display                           2'h0
        13:11   R/W    bist_mode_drf_mipi                              3'h0
        15:14   R/W    bist_mode_drf_sd                                2'h0
        17:16   R      RSVD                                            2'h0
        18      R/W    bist_mode_drf_usb                               1'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_OTHER_DRF_BIST_MODE;
        struct
        {
            __IO uint32_t bist_mode_drf_pke: 3;
            __I uint32_t RESERVED_3: 3;
            __IO uint32_t bist_mode_drf_vadbuf: 2;
            __I uint32_t RESERVED_2: 1;
            __IO uint32_t bist_mode_drf_display: 2;
            __IO uint32_t bist_mode_drf_mipi: 3;
            __IO uint32_t bist_mode_drf_sd: 2;
            __I uint32_t RESERVED_1: 2;
            __IO uint32_t bist_mode_drf_usb: 1;
            __I uint32_t RESERVED_0: 13;
        } BITS_908;
    } u_908;

    /* 0x090C       0x400e_090c
        2:0     R/W    bist_test_resume_pke                            3'h0
        5:3     R      RSVD                                            3'h0
        7:6     R/W    bist_test_resume_vadbuf                         2'h0
        8       R      RSVD                                            1'h0
        10:9    R/W    bist_test_resume_display                        2'h0
        13:11   R/W    bist_test_resume_mipi                           3'h0
        15:14   R/W    bist_test_resume_sd                             2'h0
        17:16   R      RSVD                                            2'h0
        18      R/W    bist_test_resume_usb                            1'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_OTHER_BIST_TEST_RESUME;
        struct
        {
            __IO uint32_t bist_test_resume_pke: 3;
            __I uint32_t RESERVED_3: 3;
            __IO uint32_t bist_test_resume_vadbuf: 2;
            __I uint32_t RESERVED_2: 1;
            __IO uint32_t bist_test_resume_display: 2;
            __IO uint32_t bist_test_resume_mipi: 3;
            __IO uint32_t bist_test_resume_sd: 2;
            __I uint32_t RESERVED_1: 2;
            __IO uint32_t bist_test_resume_usb: 1;
            __I uint32_t RESERVED_0: 13;
        } BITS_90C;
    } u_90C;

    /* 0x0910       0x400e_0910
        2:0     R      RSVD                                            3'h0
        4:3     R      RSVD                                            2'h0
        6:5     R      RSVD                                            2'h0
        8:7     R      RSVD                                            2'h0
        11:9    R      RSVD                                            3'h0
        13:12   R      RSVD                                            2'h0
        15:14   R      RSVD                                            2'h0
        17:16   R      RSVD                                            2'h0
        18      R      RSVD                                            1'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_OTHER_BIST_LOOP_MODE;
        struct
        {
            __I uint32_t RESERVED_9: 3;
            __I uint32_t RESERVED_8: 2;
            __I uint32_t RESERVED_7: 2;
            __I uint32_t RESERVED_6: 2;
            __I uint32_t RESERVED_5: 3;
            __I uint32_t RESERVED_4: 2;
            __I uint32_t RESERVED_3: 2;
            __I uint32_t RESERVED_2: 2;
            __I uint32_t RESERVED_1: 1;
            __I uint32_t RESERVED_0: 13;
        } BITS_910;
    } u_910;

    /* 0x0914       0x400e_0914
        2:0     R/W    bist_mem_speed_mode_pke                         3'h0
        5:3     R      RSVD                                            3'h0
        6       R/W    bist_mem_speed_mode_vadbuf                      1'h0
        8:7     R      RSVD                                            2'h0
        10:9    R/W    bist_mem_speed_mode_display                     2'h0
        13:11   R/W    bist_mem_speed_mode_mipi                        3'h0
        15:14   R/W    bist_mem_speed_mode_sd                          2'h0
        17:16   R      RSVD                                            2'h0
        18      R/W    bist_mem_speed_mode_usb                         1'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_OTHER_BIST_MEM_SPEED_MODE;
        struct
        {
            __IO uint32_t bist_mem_speed_mode_pke: 3;
            __I uint32_t RESERVED_3: 3;
            __IO uint32_t bist_mem_speed_mode_vadbuf: 1;
            __I uint32_t RESERVED_2: 2;
            __IO uint32_t bist_mem_speed_mode_display: 2;
            __IO uint32_t bist_mem_speed_mode_mipi: 3;
            __IO uint32_t bist_mem_speed_mode_sd: 2;
            __I uint32_t RESERVED_1: 2;
            __IO uint32_t bist_mem_speed_mode_usb: 1;
            __I uint32_t RESERVED_0: 13;
        } BITS_914;
    } u_914;

    /* 0x0918       0x400e_0918
        2:0     R      bist_start_pause_pke                            3'h0
        5:3     R      RSVD                                            3'h0
        7:6     R      bist_start_pause_vadbuf                         2'h0
        8       R      RSVD                                            1'h0
        10:9    R      bist_start_pause_display                        2'h0
        13:11   R      bist_start_pause_mipi                           3'h0
        15:14   R      bist_start_pause_sd                             2'h0
        17:16   R      RSVD                                            2'h0
        18      R      bist_start_pause_usb                            1'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_OTHER_BIST_START_PAUSE;
        struct
        {
            __I uint32_t bist_start_pause_pke: 3;
            __I uint32_t RESERVED_3: 3;
            __I uint32_t bist_start_pause_vadbuf: 2;
            __I uint32_t RESERVED_2: 1;
            __I uint32_t bist_start_pause_display: 2;
            __I uint32_t bist_start_pause_mipi: 3;
            __I uint32_t bist_start_pause_sd: 2;
            __I uint32_t RESERVED_1: 2;
            __I uint32_t bist_start_pause_usb: 1;
            __I uint32_t RESERVED_0: 13;
        } BITS_918;
    } u_918;

    /* 0x091C       0x400e_091c
        2:0     R      bist_done_pke                                   3'h0
        5:3     R      RSVD                                            3'h0
        7:6     R      bist_done_vadbuf                                2'h0
        8       R      RSVD                                            1'h0
        10:9    R      bist_done_display                               2'h0
        13:11   R      bist_done_mipi                                  3'h0
        15:14   R      bist_done_sd                                    2'h0
        17:16   R      RSVD                                            2'h0
        18      R      bist_done_usb                                   1'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_OTHER_BIST_DONE;
        struct
        {
            __I uint32_t bist_done_pke: 3;
            __I uint32_t RESERVED_3: 3;
            __I uint32_t bist_done_vadbuf: 2;
            __I uint32_t RESERVED_2: 1;
            __I uint32_t bist_done_display: 2;
            __I uint32_t bist_done_mipi: 3;
            __I uint32_t bist_done_sd: 2;
            __I uint32_t RESERVED_1: 2;
            __I uint32_t bist_done_usb: 1;
            __I uint32_t RESERVED_0: 13;
        } BITS_91C;
    } u_91C;

    /* 0x0920       0x400e_0920
        2:0     R      bist_fail_pke                                   3'h0
        5:3     R      RSVD                                            3'h0
        7:6     R      bist_fail_vadbuf                                2'h0
        8       R      RSVD                                            1'h0
        10:9    R      bist_fail_display                               2'h0
        13:11   R      bist_fail_mipi                                  3'h0
        15:14   R      bist_fail_sd                                    2'h0
        17:16   R      RSVD                                            2'h0
        18      R      bist_fail_usb                                   1'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_OTHER_BIST_FAIL;
        struct
        {
            __I uint32_t bist_fail_pke: 3;
            __I uint32_t RESERVED_3: 3;
            __I uint32_t bist_fail_vadbuf: 2;
            __I uint32_t RESERVED_2: 1;
            __I uint32_t bist_fail_display: 2;
            __I uint32_t bist_fail_mipi: 3;
            __I uint32_t bist_fail_sd: 2;
            __I uint32_t RESERVED_1: 2;
            __I uint32_t bist_fail_usb: 1;
            __I uint32_t RESERVED_0: 13;
        } BITS_920;
    } u_920;

    /* 0x0924       0x400e_0924
        2:0     R      bist_done_drf_pke                               3'h0
        5:3     R      RSVD                                            3'h0
        7:6     R      bist_done_drf_vadbuf                            2'h0
        8       R      RSVD                                            1'h0
        10:9    R      bist_done_drf_display                           2'h0
        13:11   R      bist_done_drf_mipi                              3'h0
        15:14   R      bist_done_drf_sd                                2'h0
        17:16   R      RSVD                                            2'h0
        18      R      bist_done_drf_usb                               1'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_OTHER_DRF_BIST_DONE;
        struct
        {
            __I uint32_t bist_done_drf_pke: 3;
            __I uint32_t RESERVED_3: 3;
            __I uint32_t bist_done_drf_vadbuf: 2;
            __I uint32_t RESERVED_2: 1;
            __I uint32_t bist_done_drf_display: 2;
            __I uint32_t bist_done_drf_mipi: 3;
            __I uint32_t bist_done_drf_sd: 2;
            __I uint32_t RESERVED_1: 2;
            __I uint32_t bist_done_drf_usb: 1;
            __I uint32_t RESERVED_0: 13;
        } BITS_924;
    } u_924;

    /* 0x0928       0x400e_0928
        2:0     R      bist_fail_drf_pke                               3'h0
        5:3     R      RSVD                                            3'h0
        7:6     R      bist_fail_drf_vadbuf                            2'h0
        8       R      RSVD                                            1'h0
        10:9    R      bist_fail_drf_display                           2'h0
        13:11   R      bist_fail_drf_mipi                              3'h0
        15:14   R      bist_fail_drf_sd                                2'h0
        17:16   R      RSVD                                            2'h0
        18      R      bist_fail_drf_usb                               1'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_OTHER_DRF_BIST_FAIL;
        struct
        {
            __I uint32_t bist_fail_drf_pke: 3;
            __I uint32_t RESERVED_3: 3;
            __I uint32_t bist_fail_drf_vadbuf: 2;
            __I uint32_t RESERVED_2: 1;
            __I uint32_t bist_fail_drf_display: 2;
            __I uint32_t bist_fail_drf_mipi: 3;
            __I uint32_t bist_fail_drf_sd: 2;
            __I uint32_t RESERVED_1: 2;
            __I uint32_t bist_fail_drf_usb: 1;
            __I uint32_t RESERVED_0: 13;
        } BITS_928;
    } u_928;

    /* 0x092C       0x400e_092c
        15:0    R/W    bist_rstn_km4_itcm1_ram                         16'h0
        23:16   R/W    bist_rstn_km4_dtcm0_ram                         8'h0
        31:24   R/W    bist_rstn_km4_dtcm1_ram                         8'h0
    */
    union
    {
        __IO uint32_t REG_KM4_BIST_RSTN;
        struct
        {
            __IO uint32_t bist_rstn_km4_itcm1_ram: 16;
            __IO uint32_t bist_rstn_km4_dtcm0_ram: 8;
            __IO uint32_t bist_rstn_km4_dtcm1_ram: 8;
        } BITS_92C;
    } u_92C;

    /* 0x0930       0x400e_0930
        15:0    R/W    bist_mode_km4_itcm1_ram                         16'h0
        23:16   R/W    bist_mode_km4_dtcm0_ram                         8'h0
        31:24   R/W    bist_mode_km4_dtcm1_ram                         8'h0
    */
    union
    {
        __IO uint32_t REG_KM4_BIST_MODE;
        struct
        {
            __IO uint32_t bist_mode_km4_itcm1_ram: 16;
            __IO uint32_t bist_mode_km4_dtcm0_ram: 8;
            __IO uint32_t bist_mode_km4_dtcm1_ram: 8;
        } BITS_930;
    } u_930;

    /* 0x0934       0x400e_0934
        15:0    R/W    bist_mode_drf_km4_itcm1_ram                     16'h0
        23:16   R/W    bist_mode_drf_km4_dtcm0_ram                     8'h0
        31:24   R/W    bist_mode_drf_km4_dtcm1_ram                     8'h0
    */
    union
    {
        __IO uint32_t REG_KM4_DRF_BIST_MODE;
        struct
        {
            __IO uint32_t bist_mode_drf_km4_itcm1_ram: 16;
            __IO uint32_t bist_mode_drf_km4_dtcm0_ram: 8;
            __IO uint32_t bist_mode_drf_km4_dtcm1_ram: 8;
        } BITS_934;
    } u_934;

    /* 0x0938       0x400e_0938
        15:0    R/W    bist_test_resume_km4_itcm1_ram                  16'h0
        23:16   R/W    bist_test_resume_km4_dtcm0_ram                  8'h0
        31:24   R/W    bist_test_resume_km4_dtcm1_ram                  8'h0
    */
    union
    {
        __IO uint32_t REG_KM4_BIST_TEST_RESUME;
        struct
        {
            __IO uint32_t bist_test_resume_km4_itcm1_ram: 16;
            __IO uint32_t bist_test_resume_km4_dtcm0_ram: 8;
            __IO uint32_t bist_test_resume_km4_dtcm1_ram: 8;
        } BITS_938;
    } u_938;

    /* 0x093C       0x400e_093c
        15:0    R      RSVD                                            16'h0
        23:16   R      RSVD                                            8'h0
        31:24   R      RSVD                                            8'h0
    */
    union
    {
        __IO uint32_t REG_KM4_BIST_LOOP_MODE;
        struct
        {
            __I uint32_t RESERVED_2: 16;
            __I uint32_t RESERVED_1: 8;
            __I uint32_t RESERVED_0: 8;
        } BITS_93C;
    } u_93C;

    /* 0x0940       0x400e_0940
        0       R/W    bist_mem_speed_mode_km4_itcm1_ram               1'h0
        15:1    R      RSVD                                            15'h0
        16      R/W    bist_mem_speed_mode_km4_dtcm0_ram               1'h0
        23:17   R      RSVD                                            7'h0
        24      R/W    bist_mem_speed_mode_km4_dtcm1_ram               1'h0
        31:25   R      RSVD                                            7'h0
    */
    union
    {
        __IO uint32_t REG_KM4_BIST_MEM_SPEED_MODE;
        struct
        {
            __IO uint32_t bist_mem_speed_mode_km4_itcm1_ram: 1;
            __I uint32_t RESERVED_2: 15;
            __IO uint32_t bist_mem_speed_mode_km4_dtcm0_ram: 1;
            __I uint32_t RESERVED_1: 7;
            __IO uint32_t bist_mem_speed_mode_km4_dtcm1_ram: 1;
            __I uint32_t RESERVED_0: 7;
        } BITS_940;
    } u_940;

    /* 0x0944       0x400e_0944
        15:0    R      bist_start_pause_km4_itcm1_ram                  16'h0
        23:16   R      bist_start_pause_km4_dtcm0_ram                  8'h0
        31:24   R      bist_start_pause_km4_dtcm1_ram                  8'h0
    */
    union
    {
        __IO uint32_t REG_KM4_BIST_START_PAUSE;
        struct
        {
            __I uint32_t bist_start_pause_km4_itcm1_ram: 16;
            __I uint32_t bist_start_pause_km4_dtcm0_ram: 8;
            __I uint32_t bist_start_pause_km4_dtcm1_ram: 8;
        } BITS_944;
    } u_944;

    /* 0x0948       0x400e_0948
        15:0    R      bist_done_km4_itcm1_ram                         16'h0
        23:16   R      bist_done_km4_dtcm0_ram                         8'h0
        31:24   R      bist_done_km4_dtcm1_ram                         8'h0
    */
    union
    {
        __IO uint32_t REG_KM4_BIST_DONE;
        struct
        {
            __I uint32_t bist_done_km4_itcm1_ram: 16;
            __I uint32_t bist_done_km4_dtcm0_ram: 8;
            __I uint32_t bist_done_km4_dtcm1_ram: 8;
        } BITS_948;
    } u_948;

    /* 0x094C       0x400e_094c
        15:0    R      bist_fail_km4_itcm1_ram                         16'h0
        23:16   R      bist_fail_km4_dtcm0_ram                         8'h0
        31:24   R      bist_fail_km4_dtcm1_ram                         8'h0
    */
    union
    {
        __IO uint32_t REG_KM4_BIST_FAIL;
        struct
        {
            __I uint32_t bist_fail_km4_itcm1_ram: 16;
            __I uint32_t bist_fail_km4_dtcm0_ram: 8;
            __I uint32_t bist_fail_km4_dtcm1_ram: 8;
        } BITS_94C;
    } u_94C;

    /* 0x0950       0x400e_0950
        15:0    R      bist_done_drf_km4_itcm1_ram                     16'h0
        23:16   R      bist_done_drf_km4_dtcm0_ram                     8'h0
        31:24   R      bist_done_drf_km4_dtcm1_ram                     8'h0
    */
    union
    {
        __IO uint32_t REG_KM4_DRF_BIST_DONE;
        struct
        {
            __I uint32_t bist_done_drf_km4_itcm1_ram: 16;
            __I uint32_t bist_done_drf_km4_dtcm0_ram: 8;
            __I uint32_t bist_done_drf_km4_dtcm1_ram: 8;
        } BITS_950;
    } u_950;

    /* 0x0954       0x400e_0954
        15:0    R      bist_fail_drf_km4_itcm1_ram                     16'h0
        23:16   R      bist_fail_drf_km4_dtcm0_ram                     8'h0
        31:24   R      bist_fail_drf_km4_dtcm1_ram                     8'h0
    */
    union
    {
        __IO uint32_t REG_KM4_DRF_BIST_FAIL;
        struct
        {
            __I uint32_t bist_fail_drf_km4_itcm1_ram: 16;
            __I uint32_t bist_fail_drf_km4_dtcm0_ram: 8;
            __I uint32_t bist_fail_drf_km4_dtcm1_ram: 8;
        } BITS_954;
    } u_954;

    /* 0x0958       0x400e_0958
        7:0     R/W    bist_rstn_km4_cache_ram                         8'h0
        31:8    R      RSVD                                            24'h0
    */
    union
    {
        __IO uint32_t REG_KM4_CACHE_BIST_RSTN;
        struct
        {
            __IO uint32_t bist_rstn_km4_cache_ram: 8;
            __I uint32_t RESERVED_0: 24;
        } BITS_958;
    } u_958;

    /* 0x095C       0x400e_095c
        7:0     R/W    bist_mode_km4_cache_ram                         8'h0
        31:8    R      RSVD                                            24'h0
    */
    union
    {
        __IO uint32_t REG_KM4_CACHE_BIST_MODE;
        struct
        {
            __IO uint32_t bist_mode_km4_cache_ram: 8;
            __I uint32_t RESERVED_0: 24;
        } BITS_95C;
    } u_95C;

    /* 0x0960       0x400e_0960
        7:0     R/W    bist_mode_drf_km4_cache_ram                     8'h0
        31:8    R      RSVD                                            24'h0
    */
    union
    {
        __IO uint32_t REG_KM4_CACHE_DRF_BIST_MODE;
        struct
        {
            __IO uint32_t bist_mode_drf_km4_cache_ram: 8;
            __I uint32_t RESERVED_0: 24;
        } BITS_960;
    } u_960;

    /* 0x0964       0x400e_0964
        7:0     R/W    bist_test_resume_km4_cache_ram                  8'h0
        31:8    R      RSVD                                            24'h0
    */
    union
    {
        __IO uint32_t REG_KM4_CACHE_BIST_TEST_RESUME;
        struct
        {
            __IO uint32_t bist_test_resume_km4_cache_ram: 8;
            __I uint32_t RESERVED_0: 24;
        } BITS_964;
    } u_964;

    /* 0x0968       0x400e_0968
        4:0     R      RSVD                                            5'h0
        28:5    R      RSVD                                            24'h0
        31:29   R      RSVD                                            3'h0
    */
    union
    {
        __IO uint32_t REG_KM4_CACHE_BIST_LOOP_MODE;
        struct
        {
            __I uint32_t RESERVED_2: 5;
            __I uint32_t RESERVED_1: 24;
            __I uint32_t RESERVED_0: 3;
        } BITS_968;
    } u_968;

    /* 0x096C       0x400e_096c
        0       R/W    bist_mem_speed_mode_km4_cache_ram               1'h0
        31:1    R      RSVD                                            31'h0
    */
    union
    {
        __IO uint32_t REG_KM4_CACHE_BIST_MEM_SPEED_MODE;
        struct
        {
            __IO uint32_t bist_mem_speed_mode_km4_cache_ram: 1;
            __I uint32_t RESERVED_0: 31;
        } BITS_96C;
    } u_96C;

    /* 0x0970       0x400e_0970
        7:0     R      bist_start_pause_km4_cache_ram                  8'h0
        31:8    R      RSVD                                            24'h0
    */
    union
    {
        __IO uint32_t REG_KM4_CACHE_BIST_START_PAUSE;
        struct
        {
            __I uint32_t bist_start_pause_km4_cache_ram: 8;
            __I uint32_t RESERVED_0: 24;
        } BITS_970;
    } u_970;

    /* 0x0974       0x400e_0974
        7:0     R      bist_done_km4_cache_ram                         8'h0
        31:8    R      RSVD                                            24'h0
    */
    union
    {
        __IO uint32_t REG_KM4_CACHE_BIST_DONE;
        struct
        {
            __I uint32_t bist_done_km4_cache_ram: 8;
            __I uint32_t RESERVED_0: 24;
        } BITS_974;
    } u_974;

    /* 0x0978       0x400e_0978
        7:0     R      bist_fail_km4_cache_ram                         8'h0
        31:8    R      RSVD                                            24'h0
    */
    union
    {
        __IO uint32_t REG_KM4_CACHE_BIST_FAIL;
        struct
        {
            __I uint32_t bist_fail_km4_cache_ram: 8;
            __I uint32_t RESERVED_0: 24;
        } BITS_978;
    } u_978;

    /* 0x097C       0x400e_097c
        7:0     R      bist_done_drf_km4_cache_ram                     8'h0
        31:8    R      RSVD                                            24'h0
    */
    union
    {
        __IO uint32_t REG_KM4_CACHE_DRF_BIST_DONE;
        struct
        {
            __I uint32_t bist_done_drf_km4_cache_ram: 8;
            __I uint32_t RESERVED_0: 24;
        } BITS_97C;
    } u_97C;

    /* 0x0980       0x400e_0980
        7:0     R      bist_fail_drf_km4_cache_ram                     8'h0
        31:8    R      RSVD                                            24'h0
    */
    union
    {
        __IO uint32_t REG_KM4_CACHE_DRF_BIST_FAIL;
        struct
        {
            __I uint32_t bist_fail_drf_km4_cache_ram: 8;
            __I uint32_t RESERVED_0: 24;
        } BITS_980;
    } u_980;

    /* 0x0984       0x400e_0984
        4:0     R/W    bist_rstn_dsp_ram_g0                            5'h0
        9:5     R/W    bist_rstn_dsp_ram_g1                            5'h0
        14:10   R/W    bist_rstn_dsp_ram_g2                            5'h0
        19:15   R/W    bist_rstn_dsp_ram_g3                            5'h0
        24:20   R/W    bist_rstn_dsp_ram_g4                            5'h0
        31:25   R      RSVD                                            7'h0
    */
    union
    {
        __IO uint32_t REG_DSP_BIST_RSTN;
        struct
        {
            __IO uint32_t bist_rstn_dsp_ram_g0: 5;
            __IO uint32_t bist_rstn_dsp_ram_g1: 5;
            __IO uint32_t bist_rstn_dsp_ram_g2: 5;
            __IO uint32_t bist_rstn_dsp_ram_g3: 5;
            __IO uint32_t bist_rstn_dsp_ram_g4: 5;
            __I uint32_t RESERVED_0: 7;
        } BITS_984;
    } u_984;

    /* 0x0988       0x400e_0988
        4:0     R/W    bist_mode_dsp_ram_g0                            5'h0
        9:5     R/W    bist_mode_dsp_ram_g1                            5'h0
        14:10   R/W    bist_mode_dsp_ram_g2                            5'h0
        19:15   R/W    bist_mode_dsp_ram_g3                            5'h0
        24:20   R/W    bist_mode_dsp_ram_g4                            5'h0
        31:25   R      RSVD                                            7'h0
    */
    union
    {
        __IO uint32_t REG_DSP_BIST_MODE;
        struct
        {
            __IO uint32_t bist_mode_dsp_ram_g0: 5;
            __IO uint32_t bist_mode_dsp_ram_g1: 5;
            __IO uint32_t bist_mode_dsp_ram_g2: 5;
            __IO uint32_t bist_mode_dsp_ram_g3: 5;
            __IO uint32_t bist_mode_dsp_ram_g4: 5;
            __I uint32_t RESERVED_0: 7;
        } BITS_988;
    } u_988;

    /* 0x098C       0x400e_098c
        4:0     R/W    bist_mode_drf_dsp_ram_g0                        5'h0
        9:5     R/W    bist_mode_drf_dsp_ram_g1                        5'h0
        14:10   R/W    bist_mode_drf_dsp_ram_g2                        5'h0
        19:15   R/W    bist_mode_drf_dsp_ram_g3                        5'h0
        24:20   R/W    bist_mode_drf_dsp_ram_g4                        5'h0
        31:25   R      RSVD                                            7'h0
    */
    union
    {
        __IO uint32_t REG_DSP_DRF_BIST_MODE;
        struct
        {
            __IO uint32_t bist_mode_drf_dsp_ram_g0: 5;
            __IO uint32_t bist_mode_drf_dsp_ram_g1: 5;
            __IO uint32_t bist_mode_drf_dsp_ram_g2: 5;
            __IO uint32_t bist_mode_drf_dsp_ram_g3: 5;
            __IO uint32_t bist_mode_drf_dsp_ram_g4: 5;
            __I uint32_t RESERVED_0: 7;
        } BITS_98C;
    } u_98C;

    /* 0x0990       0x400e_0990
        4:0     R/W    bist_test_resume_dsp_ram_g0                     5'h0
        9:5     R/W    bist_test_resume_dsp_ram_g1                     5'h0
        14:10   R/W    bist_test_resume_dsp_ram_g2                     5'h0
        19:15   R/W    bist_test_resume_dsp_ram_g3                     5'h0
        24:20   R/W    bist_test_resume_dsp_ram_g4                     5'h0
        31:25   R      RSVD                                            7'h0
    */
    union
    {
        __IO uint32_t REG_DSP_BIST_TEST_RESUME;
        struct
        {
            __IO uint32_t bist_test_resume_dsp_ram_g0: 5;
            __IO uint32_t bist_test_resume_dsp_ram_g1: 5;
            __IO uint32_t bist_test_resume_dsp_ram_g2: 5;
            __IO uint32_t bist_test_resume_dsp_ram_g3: 5;
            __IO uint32_t bist_test_resume_dsp_ram_g4: 5;
            __I uint32_t RESERVED_0: 7;
        } BITS_990;
    } u_990;

    /* 0x0994       0x400e_0994
        4:0     R      RSVD                                            5'h0
        9:5     R      RSVD                                            5'h0
        14:10   R      RSVD                                            5'h0
        19:15   R      RSVD                                            5'h0
        24:20   R      RSVD                                            5'h0
        31:25   R      RSVD                                            7'h0
    */
    union
    {
        __IO uint32_t REG_DSP_BIST_LOOP_MODE;
        struct
        {
            __I uint32_t RESERVED_5: 5;
            __I uint32_t RESERVED_4: 5;
            __I uint32_t RESERVED_3: 5;
            __I uint32_t RESERVED_2: 5;
            __I uint32_t RESERVED_1: 5;
            __I uint32_t RESERVED_0: 7;
        } BITS_994;
    } u_994;

    /* 0x0998       0x400e_0998
        0       R/W    bist_mem_speed_mode_dsp_ram_g0                  1'h0
        4:1     R      RSVD                                            4'h0
        5       R/W    bist_mem_speed_mode_dsp_ram_g1                  1'h0
        9:6     R      RSVD                                            4'h0
        10      R/W    bist_mem_speed_mode_dsp_ram_g2                  1'h0
        14:11   R      RSVD                                            4'h0
        15      R/W    bist_mem_speed_mode_dsp_ram_g3                  1'h0
        19:16   R      RSVD                                            4'h0
        20      R/W    bist_mem_speed_mode_dsp_ram_g4                  1'h0
        31:21   R      RSVD                                            11'h0
    */
    union
    {
        __IO uint32_t REG_DSP_BIST_MEM_SPEED_MODE;
        struct
        {
            __IO uint32_t bist_mem_speed_mode_dsp_ram_g0: 1;
            __I uint32_t RESERVED_4: 4;
            __IO uint32_t bist_mem_speed_mode_dsp_ram_g1: 1;
            __I uint32_t RESERVED_3: 4;
            __IO uint32_t bist_mem_speed_mode_dsp_ram_g2: 1;
            __I uint32_t RESERVED_2: 4;
            __IO uint32_t bist_mem_speed_mode_dsp_ram_g3: 1;
            __I uint32_t RESERVED_1: 4;
            __IO uint32_t bist_mem_speed_mode_dsp_ram_g4: 1;
            __I uint32_t RESERVED_0: 11;
        } BITS_998;
    } u_998;

    /* 0x099C       0x400e_099c
        4:0     R      bist_start_pause_dsp_ram_g0                     5'h0
        9:5     R      bist_start_pause_dsp_ram_g1                     5'h0
        14:10   R      bist_start_pause_dsp_ram_g2                     5'h0
        19:15   R      bist_start_pause_dsp_ram_g3                     5'h0
        24:20   R      bist_start_pause_dsp_ram_g4                     5'h0
        31:25   R      RSVD                                            7'h0
    */
    union
    {
        __IO uint32_t REG_DSP_BIST_START_PAUSE;
        struct
        {
            __I uint32_t bist_start_pause_dsp_ram_g0: 5;
            __I uint32_t bist_start_pause_dsp_ram_g1: 5;
            __I uint32_t bist_start_pause_dsp_ram_g2: 5;
            __I uint32_t bist_start_pause_dsp_ram_g3: 5;
            __I uint32_t bist_start_pause_dsp_ram_g4: 5;
            __I uint32_t RESERVED_0: 7;
        } BITS_99C;
    } u_99C;

    /* 0x09A0       0x400e_09a0
        4:0     R      bist_done_dsp_ram_g0                            5'h0
        9:5     R      bist_done_dsp_ram_g1                            5'h0
        14:10   R      bist_done_dsp_ram_g2                            5'h0
        19:15   R      bist_done_dsp_ram_g3                            5'h0
        24:20   R      bist_done_dsp_ram_g4                            5'h0
        31:25   R      RSVD                                            7'h0
    */
    union
    {
        __IO uint32_t REG_DSP_BIST_DONE;
        struct
        {
            __I uint32_t bist_done_dsp_ram_g0: 5;
            __I uint32_t bist_done_dsp_ram_g1: 5;
            __I uint32_t bist_done_dsp_ram_g2: 5;
            __I uint32_t bist_done_dsp_ram_g3: 5;
            __I uint32_t bist_done_dsp_ram_g4: 5;
            __I uint32_t RESERVED_0: 7;
        } BITS_9A0;
    } u_9A0;

    /* 0x09A4       0x400e_09a4
        4:0     R      bist_fail_dsp_ram_g0                            5'h0
        9:5     R      bist_fail_dsp_ram_g1                            5'h0
        14:10   R      bist_fail_dsp_ram_g2                            5'h0
        19:15   R      bist_fail_dsp_ram_g3                            5'h0
        24:20   R      bist_fail_dsp_ram_g4                            5'h0
        31:25   R      RSVD                                            7'h0
    */
    union
    {
        __IO uint32_t REG_DSP_BIST_FAIL;
        struct
        {
            __I uint32_t bist_fail_dsp_ram_g0: 5;
            __I uint32_t bist_fail_dsp_ram_g1: 5;
            __I uint32_t bist_fail_dsp_ram_g2: 5;
            __I uint32_t bist_fail_dsp_ram_g3: 5;
            __I uint32_t bist_fail_dsp_ram_g4: 5;
            __I uint32_t RESERVED_0: 7;
        } BITS_9A4;
    } u_9A4;

    /* 0x09A8       0x400e_09a8
        4:0     R      bist_done_drf_dsp_ram_g0                        5'h0
        9:5     R      bist_done_drf_dsp_ram_g1                        5'h0
        14:10   R      bist_done_drf_dsp_ram_g2                        5'h0
        19:15   R      bist_done_drf_dsp_ram_g3                        5'h0
        24:20   R      bist_done_drf_dsp_ram_g4                        5'h0
        31:25   R      RSVD                                            7'h0
    */
    union
    {
        __IO uint32_t REG_DSP_DRF_BIST_DONE;
        struct
        {
            __I uint32_t bist_done_drf_dsp_ram_g0: 5;
            __I uint32_t bist_done_drf_dsp_ram_g1: 5;
            __I uint32_t bist_done_drf_dsp_ram_g2: 5;
            __I uint32_t bist_done_drf_dsp_ram_g3: 5;
            __I uint32_t bist_done_drf_dsp_ram_g4: 5;
            __I uint32_t RESERVED_0: 7;
        } BITS_9A8;
    } u_9A8;

    /* 0x09AC       0x400e_09ac
        4:0     R      bist_fail_drf_dsp_ram_g0                        5'h0
        9:5     R      bist_fail_drf_dsp_ram_g1                        5'h0
        14:10   R      bist_fail_drf_dsp_ram_g2                        5'h0
        19:15   R      bist_fail_drf_dsp_ram_g3                        5'h0
        24:20   R      bist_fail_drf_dsp_ram_g4                        5'h0
        31:25   R      RSVD                                            7'h0
    */
    union
    {
        __IO uint32_t REG_DSP_DRF_BIST_FAIL;
        struct
        {
            __I uint32_t bist_fail_drf_dsp_ram_g0: 5;
            __I uint32_t bist_fail_drf_dsp_ram_g1: 5;
            __I uint32_t bist_fail_drf_dsp_ram_g2: 5;
            __I uint32_t bist_fail_drf_dsp_ram_g3: 5;
            __I uint32_t bist_fail_drf_dsp_ram_g4: 5;
            __I uint32_t RESERVED_0: 7;
        } BITS_9AC;
    } u_9AC;

    /* 0x09B0       0x400e_09b0
        5:0     R/W    bist_rstn_dsp_icache_ram                        6'h0
        12:6    R/W    bist_rstn_dsp_dcache_ram                        7'h0
        18:13   R/W    bist_rstn_dsp_fft_ram                           6'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_DSP_CACHE_FFT_BIST_RSTN;
        struct
        {
            __IO uint32_t bist_rstn_dsp_icache_ram: 6;
            __IO uint32_t bist_rstn_dsp_dcache_ram: 7;
            __IO uint32_t bist_rstn_dsp_fft_ram: 6;
            __I uint32_t RESERVED_0: 13;
        } BITS_9B0;
    } u_9B0;

    /* 0x09B4       0x400e_09b4
        5:0     R/W    bist_mode_dsp_icache_ram                        6'h0
        12:6    R/W    bist_mode_dsp_dcache_ram                        7'h0
        18:13   R/W    bist_mode_dsp_fft_ram                           6'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_DSP_CACHE_FFT_BIST_MODE;
        struct
        {
            __IO uint32_t bist_mode_dsp_icache_ram: 6;
            __IO uint32_t bist_mode_dsp_dcache_ram: 7;
            __IO uint32_t bist_mode_dsp_fft_ram: 6;
            __I uint32_t RESERVED_0: 13;
        } BITS_9B4;
    } u_9B4;

    /* 0x09B8       0x400e_09b8
        5:0     R/W    bist_mode_drf_dsp_icache_ram                    6'h0
        12:6    R/W    bist_mode_drf_dsp_dcache_ram                    7'h0
        18:13   R/W    bist_mode_drf_dsp_fft_ram                       6'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_DSP_CACHE_FFT_DRF_BIST_MODE;
        struct
        {
            __IO uint32_t bist_mode_drf_dsp_icache_ram: 6;
            __IO uint32_t bist_mode_drf_dsp_dcache_ram: 7;
            __IO uint32_t bist_mode_drf_dsp_fft_ram: 6;
            __I uint32_t RESERVED_0: 13;
        } BITS_9B8;
    } u_9B8;

    /* 0x09BC       0x400e_09bc
        5:0     R/W    bist_test_resume_dsp_icache_ram                 6'h0
        12:6    R/W    bist_test_resume_dsp_dcache_ram                 7'h0
        18:13   R/W    bist_test_resume_dsp_fft_ram                    6'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_DSP_CACHE_FFT_BIST_TEST_RESUME;
        struct
        {
            __IO uint32_t bist_test_resume_dsp_icache_ram: 6;
            __IO uint32_t bist_test_resume_dsp_dcache_ram: 7;
            __IO uint32_t bist_test_resume_dsp_fft_ram: 6;
            __I uint32_t RESERVED_0: 13;
        } BITS_9BC;
    } u_9BC;

    /* 0x09C0       0x400e_09c0
        5:0     R      RSVD                                            6'h0
        12:6    R      RSVD                                            7'h0
        18:13   R      RSVD                                            6'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_DSP_CACHE_FFT_BIST_LOOP_MODE;
        struct
        {
            __I uint32_t RESERVED_3: 6;
            __I uint32_t RESERVED_2: 7;
            __I uint32_t RESERVED_1: 6;
            __I uint32_t RESERVED_0: 13;
        } BITS_9C0;
    } u_9C0;

    /* 0x09C4       0x400e_09c4
        0       R/W    bist_mem_speed_mode_dsp_icache_ram              1'h0
        5:1     R      RSVD                                            5'h0
        6       R/W    bist_mem_speed_mode_dsp_dcache_ram              1'h0
        12:7    R      RSVD                                            6'h0
        13      R/W    bist_mem_speed_mode_dsp_fft_ram                 1'h0
        31:14   R      RSVD                                            18'h0
    */
    union
    {
        __IO uint32_t REG_DSP_CACHE_FFT_BIST_MEM_SPEED_MODE;
        struct
        {
            __IO uint32_t bist_mem_speed_mode_dsp_icache_ram: 1;
            __I uint32_t RESERVED_2: 5;
            __IO uint32_t bist_mem_speed_mode_dsp_dcache_ram: 1;
            __I uint32_t RESERVED_1: 6;
            __IO uint32_t bist_mem_speed_mode_dsp_fft_ram: 1;
            __I uint32_t RESERVED_0: 18;
        } BITS_9C4;
    } u_9C4;

    /* 0x09C8       0x400e_09c8
        5:0     R      bist_start_pause_dsp_icache_ram                 6'h0
        12:6    R      bist_start_pause_dsp_dcache_ram                 7'h0
        18:13   R      bist_start_pause_dsp_fft_ram                    6'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_DSP_CACHE_FFT_BIST_START_PAUSE;
        struct
        {
            __I uint32_t bist_start_pause_dsp_icache_ram: 6;
            __I uint32_t bist_start_pause_dsp_dcache_ram: 7;
            __I uint32_t bist_start_pause_dsp_fft_ram: 6;
            __I uint32_t RESERVED_0: 13;
        } BITS_9C8;
    } u_9C8;

    /* 0x09CC       0x400e_09cc
        5:0     R      bist_done_dsp_icache_ram                        6'h0
        12:6    R      bist_done_dsp_dcache_ram                        7'h0
        18:13   R      bist_done_dsp_fft_ram                           6'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_DSP_CACHE_FFT_BIST_DONE;
        struct
        {
            __I uint32_t bist_done_dsp_icache_ram: 6;
            __I uint32_t bist_done_dsp_dcache_ram: 7;
            __I uint32_t bist_done_dsp_fft_ram: 6;
            __I uint32_t RESERVED_0: 13;
        } BITS_9CC;
    } u_9CC;

    /* 0x09D0       0x400e_09d0
        5:0     R      bist_fail_dsp_icache_ram                        6'h0
        12:6    R      bist_fail_dsp_dcache_ram                        7'h0
        18:13   R      bist_fail_dsp_fft_ram                           6'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_DSP_CACHE_FFT_BIST_FAIL;
        struct
        {
            __I uint32_t bist_fail_dsp_icache_ram: 6;
            __I uint32_t bist_fail_dsp_dcache_ram: 7;
            __I uint32_t bist_fail_dsp_fft_ram: 6;
            __I uint32_t RESERVED_0: 13;
        } BITS_9D0;
    } u_9D0;

    /* 0x09D4       0x400e_09d4
        5:0     R      bist_done_drf_dsp_icache_ram                    6'h0
        12:6    R      bist_done_drf_dsp_dcache_ram                    7'h0
        18:13   R      bist_done_drf_dsp_fft_ram                       6'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_DSP_CACHE_FFT_DRF_BIST_DONE;
        struct
        {
            __I uint32_t bist_done_drf_dsp_icache_ram: 6;
            __I uint32_t bist_done_drf_dsp_dcache_ram: 7;
            __I uint32_t bist_done_drf_dsp_fft_ram: 6;
            __I uint32_t RESERVED_0: 13;
        } BITS_9D4;
    } u_9D4;

    /* 0x09D8       0x400e_09d8
        5:0     R      bist_fail_drf_dsp_icache_ram                    6'h0
        12:6    R      bist_fail_drf_dsp_dcache_ram                    7'h0
        18:13   R      bist_fail_drf_dsp_fft_ram                       6'h0
        31:19   R      RSVD                                            13'h0
    */
    union
    {
        __IO uint32_t REG_DSP_CACHE_FFT_DRF_BIST_FAIL;
        struct
        {
            __I uint32_t bist_fail_drf_dsp_icache_ram: 6;
            __I uint32_t bist_fail_drf_dsp_dcache_ram: 7;
            __I uint32_t bist_fail_drf_dsp_fft_ram: 6;
            __I uint32_t RESERVED_0: 13;
        } BITS_9D8;
    } u_9D8;

    /* 0x09DC       0x400e_09dc
        4:0     R/W    bist_rstn_gpu_ram                               5'h0
        31:5    R      RSVD                                            27'h0
    */
    union
    {
        __IO uint32_t REG_GPU_BIST_RSTN;
        struct
        {
            __IO uint32_t bist_rstn_gpu_ram: 5;
            __I uint32_t RESERVED_0: 27;
        } BITS_9DC;
    } u_9DC;

    /* 0x09E0       0x400e_09e0
        4:0     R/W    bist_mode_gpu_ram                               5'h0
        31:5    R      RSVD                                            27'h0
    */
    union
    {
        __IO uint32_t REG_GPU_BIST_MODE;
        struct
        {
            __IO uint32_t bist_mode_gpu_ram: 5;
            __I uint32_t RESERVED_0: 27;
        } BITS_9E0;
    } u_9E0;

    /* 0x09E4       0x400e_09e4
        4:0     R/W    bist_mode_drf_gpu_ram                           5'h0
        31:5    R      RSVD                                            27'h0
    */
    union
    {
        __IO uint32_t REG_GPU_DRF_BIST_MODE;
        struct
        {
            __IO uint32_t bist_mode_drf_gpu_ram: 5;
            __I uint32_t RESERVED_0: 27;
        } BITS_9E4;
    } u_9E4;

    /* 0x09E8       0x400e_09e8
        4:0     R/W    bist_test_resume_gpu_ram                        5'h0
        31:5    R      RSVD                                            27'h0
    */
    union
    {
        __IO uint32_t REG_GPU_BIST_TEST_RESUME;
        struct
        {
            __IO uint32_t bist_test_resume_gpu_ram: 5;
            __I uint32_t RESERVED_0: 27;
        } BITS_9E8;
    } u_9E8;

    /* 0x09EC       0x400e_09ec
        4:0     R      RSVD                                            5'h0
        31:5    R      RSVD                                            27'h0
    */
    union
    {
        __IO uint32_t REG_GPU_BIST_LOOP_MODE;
        struct
        {
            __I uint32_t RESERVED_1: 5;
            __I uint32_t RESERVED_0: 27;
        } BITS_9EC;
    } u_9EC;

    /* 0x09F0       0x400e_09f0
        4:0     R/W    bist_mem_speed_mode_gpu_ram                     5'h0
        31:5    R      RSVD                                            27'h0
    */
    union
    {
        __IO uint32_t REG_GPU_BIST_MEM_SPEED_MODE;
        struct
        {
            __IO uint32_t bist_mem_speed_mode_gpu_ram: 5;
            __I uint32_t RESERVED_0: 27;
        } BITS_9F0;
    } u_9F0;

    /* 0x09F4       0x400e_09f4
        4:0     R      bist_start_pause_gpu_ram                        5'h0
        31:5    R      RSVD                                            27'h0
    */
    union
    {
        __IO uint32_t REG_GPU_BIST_START_PAUSE;
        struct
        {
            __I uint32_t bist_start_pause_gpu_ram: 5;
            __I uint32_t RESERVED_0: 27;
        } BITS_9F4;
    } u_9F4;

    /* 0x09F8       0x400e_09f8
        4:0     R      bist_done_gpu_ram                               5'h0
        31:5    R      RSVD                                            27'h0
    */
    union
    {
        __IO uint32_t REG_GPU_BIST_DONE;
        struct
        {
            __I uint32_t bist_done_gpu_ram: 5;
            __I uint32_t RESERVED_0: 27;
        } BITS_9F8;
    } u_9F8;

    /* 0x09FC       0x400e_09fc
        4:0     R      bist_fail_gpu_ram                               5'h0
        31:5    R      RSVD                                            27'h0
    */
    union
    {
        __IO uint32_t REG_GPU_BIST_FAIL;
        struct
        {
            __I uint32_t bist_fail_gpu_ram: 5;
            __I uint32_t RESERVED_0: 27;
        } BITS_9FC;
    } u_9FC;

    /* 0x0A00       0x400e_0a00
        4:0     R      bist_done_drf_gpu_ram                           5'h0
        31:5    R      RSVD                                            27'h0
    */
    union
    {
        __IO uint32_t REG_GPU_DRF_BIST_DONE;
        struct
        {
            __I uint32_t bist_done_drf_gpu_ram: 5;
            __I uint32_t RESERVED_0: 27;
        } BITS_A00;
    } u_A00;

    /* 0x0A04       0x400e_0a04
        4:0     R      bist_fail_drf_gpu_ram                           5'h0
        31:5    R      RSVD                                            27'h0
    */
    union
    {
        __IO uint32_t REG_GPU_DRF_BIST_FAIL;
        struct
        {
            __I uint32_t bist_fail_drf_gpu_ram: 5;
            __I uint32_t RESERVED_0: 27;
        } BITS_A04;
    } u_A04;

    /* 0x0A08       0x400e_0a08
        0       R/W    bisr_rstn_data_ram_g0                           1'h0
        1       R/W    bisr_rstn_data_ram_g1                           1'h0
        2       R/W    bisr_rstn_data_ram_g2                           1'h0
        3       R/W    bisr_rstn_data_ram_g3                           1'h0
        4       R/W    bisr_rstn_data_ram_g4                           1'h0
        5       R/W    bisr_rstn_data_ram_g5                           1'h0
        6       R/W    bisr_rstn_data_ram_g6                           1'h0
        7       R/W    bisr_rstn_data_ram_g7                           1'h0
        8       R/W    bisr_rstn_data_ram_g8                           1'h0
        9       R/W    bisr_rstn_data_ram_g9                           1'h0
        10      R/W    bisr_rstn_data_ram_g10                          1'h0
        11      R/W    bisr_rstn_data_ram_g11                          1'h0
        15:12   R/W    bisr_rstn_dsp_ram_g0                            4'h0
        19:16   R/W    bisr_rstn_dsp_ram_g1                            4'h0
        23:20   R/W    bisr_rstn_dsp_ram_g2                            4'h0
        27:24   R/W    bisr_rstn_dsp_ram_g3                            4'h0
        28      R/W    bisr_rstn_dsp_sys_ram_g0                        1'h0
        29      R/W    bisr_rstn_dsp_sys_ram_g1                        1'h0
        30      R/W    bisr_rstn_dsp_sys_ram_g2                        1'h0
        31      R/W    bisr_rstn_dsp_sys_ram_g3                        1'h0
    */
    union
    {
        __IO uint32_t REG_DATA_BISR_RSTN;
        struct
        {
            __IO uint32_t bisr_rstn_data_ram_g0: 1;
            __IO uint32_t bisr_rstn_data_ram_g1: 1;
            __IO uint32_t bisr_rstn_data_ram_g2: 1;
            __IO uint32_t bisr_rstn_data_ram_g3: 1;
            __IO uint32_t bisr_rstn_data_ram_g4: 1;
            __IO uint32_t bisr_rstn_data_ram_g5: 1;
            __IO uint32_t bisr_rstn_data_ram_g6: 1;
            __IO uint32_t bisr_rstn_data_ram_g7: 1;
            __IO uint32_t bisr_rstn_data_ram_g8: 1;
            __IO uint32_t bisr_rstn_data_ram_g9: 1;
            __IO uint32_t bisr_rstn_data_ram_g10: 1;
            __IO uint32_t bisr_rstn_data_ram_g11: 1;
            __IO uint32_t bisr_rstn_dsp_ram_g0: 4;
            __IO uint32_t bisr_rstn_dsp_ram_g1: 4;
            __IO uint32_t bisr_rstn_dsp_ram_g2: 4;
            __IO uint32_t bisr_rstn_dsp_ram_g3: 4;
            __IO uint32_t bisr_rstn_dsp_sys_ram_g0: 1;
            __IO uint32_t bisr_rstn_dsp_sys_ram_g1: 1;
            __IO uint32_t bisr_rstn_dsp_sys_ram_g2: 1;
            __IO uint32_t bisr_rstn_dsp_sys_ram_g3: 1;
        } BITS_A08;
    } u_A08;

    /* 0x0A0C       0x400e_0a0c
        0       R/W    bisr_mode_data_ram_g0                           1'h0
        1       R/W    bisr_mode_data_ram_g1                           1'h0
        2       R/W    bisr_mode_data_ram_g2                           1'h0
        3       R/W    bisr_mode_data_ram_g3                           1'h0
        4       R/W    bisr_mode_data_ram_g4                           1'h0
        5       R/W    bisr_mode_data_ram_g5                           1'h0
        6       R/W    bisr_mode_data_ram_g6                           1'h0
        7       R/W    bisr_mode_data_ram_g7                           1'h0
        8       R/W    bisr_mode_data_ram_g8                           1'h0
        9       R/W    bisr_mode_data_ram_g9                           1'h0
        10      R/W    bisr_mode_data_ram_g10                          1'h0
        11      R/W    bisr_mode_data_ram_g11                          1'h0
        15:12   R/W    bisr_mode_dsp_ram_g0                            4'h0
        19:16   R/W    bisr_mode_dsp_ram_g1                            4'h0
        23:20   R/W    bisr_mode_dsp_ram_g2                            4'h0
        27:24   R/W    bisr_mode_dsp_ram_g3                            4'h0
        28      R/W    bisr_mode_dsp_sys_ram_g0                        1'h0
        29      R/W    bisr_mode_dsp_sys_ram_g1                        1'h0
        30      R/W    bisr_mode_dsp_sys_ram_g2                        1'h0
        31      R/W    bisr_mode_dsp_sys_ram_g3                        1'h0
    */
    union
    {
        __IO uint32_t REG_DATA_BISR_MODE;
        struct
        {
            __IO uint32_t bisr_mode_data_ram_g0: 1;
            __IO uint32_t bisr_mode_data_ram_g1: 1;
            __IO uint32_t bisr_mode_data_ram_g2: 1;
            __IO uint32_t bisr_mode_data_ram_g3: 1;
            __IO uint32_t bisr_mode_data_ram_g4: 1;
            __IO uint32_t bisr_mode_data_ram_g5: 1;
            __IO uint32_t bisr_mode_data_ram_g6: 1;
            __IO uint32_t bisr_mode_data_ram_g7: 1;
            __IO uint32_t bisr_mode_data_ram_g8: 1;
            __IO uint32_t bisr_mode_data_ram_g9: 1;
            __IO uint32_t bisr_mode_data_ram_g10: 1;
            __IO uint32_t bisr_mode_data_ram_g11: 1;
            __IO uint32_t bisr_mode_dsp_ram_g0: 4;
            __IO uint32_t bisr_mode_dsp_ram_g1: 4;
            __IO uint32_t bisr_mode_dsp_ram_g2: 4;
            __IO uint32_t bisr_mode_dsp_ram_g3: 4;
            __IO uint32_t bisr_mode_dsp_sys_ram_g0: 1;
            __IO uint32_t bisr_mode_dsp_sys_ram_g1: 1;
            __IO uint32_t bisr_mode_dsp_sys_ram_g2: 1;
            __IO uint32_t bisr_mode_dsp_sys_ram_g3: 1;
        } BITS_A0C;
    } u_A0C;

    /* 0x0A10       0x400e_0a10
        0       R/W    bisr_mode_drf_data_ram_g0                       1'h0
        1       R/W    bisr_mode_drf_data_ram_g1                       1'h0
        2       R/W    bisr_mode_drf_data_ram_g2                       1'h0
        3       R/W    bisr_mode_drf_data_ram_g3                       1'h0
        4       R/W    bisr_mode_drf_data_ram_g4                       1'h0
        5       R/W    bisr_mode_drf_data_ram_g5                       1'h0
        6       R/W    bisr_mode_drf_data_ram_g6                       1'h0
        7       R/W    bisr_mode_drf_data_ram_g7                       1'h0
        8       R/W    bisr_mode_drf_data_ram_g8                       1'h0
        9       R/W    bisr_mode_drf_data_ram_g9                       1'h0
        10      R/W    bisr_mode_drf_data_ram_g10                      1'h0
        11      R/W    bisr_mode_drf_data_ram_g11                      1'h0
        15:12   R/W    bisr_mode_drf_dsp_ram_g0                        4'h0
        19:16   R/W    bisr_mode_drf_dsp_ram_g1                        4'h0
        23:20   R/W    bisr_mode_drf_dsp_ram_g2                        4'h0
        27:24   R/W    bisr_mode_drf_dsp_ram_g3                        4'h0
        28      R/W    bisr_mode_drf_dsp_sys_ram_g0                    1'h0
        29      R/W    bisr_mode_drf_dsp_sys_ram_g1                    1'h0
        30      R/W    bisr_mode_drf_dsp_sys_ram_g2                    1'h0
        31      R/W    bisr_mode_drf_dsp_sys_ram_g3                    1'h0
    */
    union
    {
        __IO uint32_t REG_DATA_DRF_BISR_MODE;
        struct
        {
            __IO uint32_t bisr_mode_drf_data_ram_g0: 1;
            __IO uint32_t bisr_mode_drf_data_ram_g1: 1;
            __IO uint32_t bisr_mode_drf_data_ram_g2: 1;
            __IO uint32_t bisr_mode_drf_data_ram_g3: 1;
            __IO uint32_t bisr_mode_drf_data_ram_g4: 1;
            __IO uint32_t bisr_mode_drf_data_ram_g5: 1;
            __IO uint32_t bisr_mode_drf_data_ram_g6: 1;
            __IO uint32_t bisr_mode_drf_data_ram_g7: 1;
            __IO uint32_t bisr_mode_drf_data_ram_g8: 1;
            __IO uint32_t bisr_mode_drf_data_ram_g9: 1;
            __IO uint32_t bisr_mode_drf_data_ram_g10: 1;
            __IO uint32_t bisr_mode_drf_data_ram_g11: 1;
            __IO uint32_t bisr_mode_drf_dsp_ram_g0: 4;
            __IO uint32_t bisr_mode_drf_dsp_ram_g1: 4;
            __IO uint32_t bisr_mode_drf_dsp_ram_g2: 4;
            __IO uint32_t bisr_mode_drf_dsp_ram_g3: 4;
            __IO uint32_t bisr_mode_drf_dsp_sys_ram_g0: 1;
            __IO uint32_t bisr_mode_drf_dsp_sys_ram_g1: 1;
            __IO uint32_t bisr_mode_drf_dsp_sys_ram_g2: 1;
            __IO uint32_t bisr_mode_drf_dsp_sys_ram_g3: 1;
        } BITS_A10;
    } u_A10;

    /* 0x0A14       0x400e_0a14
        0       R/W    bisr_test_resume_data_ram_g0                    1'h0
        1       R/W    bisr_test_resume_data_ram_g1                    1'h0
        2       R/W    bisr_test_resume_data_ram_g2                    1'h0
        3       R/W    bisr_test_resume_data_ram_g3                    1'h0
        4       R/W    bisr_test_resume_data_ram_g4                    1'h0
        5       R/W    bisr_test_resume_data_ram_g5                    1'h0
        6       R/W    bisr_test_resume_data_ram_g6                    1'h0
        7       R/W    bisr_test_resume_data_ram_g7                    1'h0
        8       R/W    bisr_test_resume_data_ram_g8                    1'h0
        9       R/W    bisr_test_resume_data_ram_g9                    1'h0
        10      R/W    bisr_test_resume_data_ram_g10                   1'h0
        11      R/W    bisr_test_resume_data_ram_g11                   1'h0
        15:12   R/W    bisr_test_resume_dsp_ram_g0                     4'h0
        19:16   R/W    bisr_test_resume_dsp_ram_g1                     4'h0
        23:20   R/W    bisr_test_resume_dsp_ram_g2                     4'h0
        27:24   R/W    bisr_test_resume_dsp_ram_g3                     4'h0
        28      R/W    bisr_test_resume_dsp_sys_ram_g0                 1'h0
        29      R/W    bisr_test_resume_dsp_sys_ram_g1                 1'h0
        30      R/W    bisr_test_resume_dsp_sys_ram_g2                 1'h0
        31      R/W    bisr_test_resume_dsp_sys_ram_g3                 1'h0
    */
    union
    {
        __IO uint32_t REG_DATA_BISR_TEST_RESUME;
        struct
        {
            __IO uint32_t bisr_test_resume_data_ram_g0: 1;
            __IO uint32_t bisr_test_resume_data_ram_g1: 1;
            __IO uint32_t bisr_test_resume_data_ram_g2: 1;
            __IO uint32_t bisr_test_resume_data_ram_g3: 1;
            __IO uint32_t bisr_test_resume_data_ram_g4: 1;
            __IO uint32_t bisr_test_resume_data_ram_g5: 1;
            __IO uint32_t bisr_test_resume_data_ram_g6: 1;
            __IO uint32_t bisr_test_resume_data_ram_g7: 1;
            __IO uint32_t bisr_test_resume_data_ram_g8: 1;
            __IO uint32_t bisr_test_resume_data_ram_g9: 1;
            __IO uint32_t bisr_test_resume_data_ram_g10: 1;
            __IO uint32_t bisr_test_resume_data_ram_g11: 1;
            __IO uint32_t bisr_test_resume_dsp_ram_g0: 4;
            __IO uint32_t bisr_test_resume_dsp_ram_g1: 4;
            __IO uint32_t bisr_test_resume_dsp_ram_g2: 4;
            __IO uint32_t bisr_test_resume_dsp_ram_g3: 4;
            __IO uint32_t bisr_test_resume_dsp_sys_ram_g0: 1;
            __IO uint32_t bisr_test_resume_dsp_sys_ram_g1: 1;
            __IO uint32_t bisr_test_resume_dsp_sys_ram_g2: 1;
            __IO uint32_t bisr_test_resume_dsp_sys_ram_g3: 1;
        } BITS_A14;
    } u_A14;

    /* 0x0A18       0x400e_0a18
        0       R      RSVD                                            1'h0
        1       R      RSVD                                            1'h0
        2       R      RSVD                                            1'h0
        3       R      RSVD                                            1'h0
        4       R      RSVD                                            1'h0
        5       R      RSVD                                            1'h0
        6       R      RSVD                                            1'h0
        7       R      RSVD                                            1'h0
        31:8    R      RSVD                                            24'h0
    */
    union
    {
        __IO uint32_t REG_DATA_BISR_LOOP_MODE;
        struct
        {
            __I uint32_t RESERVED_8: 1;
            __I uint32_t RESERVED_7: 1;
            __I uint32_t RESERVED_6: 1;
            __I uint32_t RESERVED_5: 1;
            __I uint32_t RESERVED_4: 1;
            __I uint32_t RESERVED_3: 1;
            __I uint32_t RESERVED_2: 1;
            __I uint32_t RESERVED_1: 1;
            __I uint32_t RESERVED_0: 24;
        } BITS_A18;
    } u_A18;

    /* 0x0A1C       0x400e_0a1c
        0       R/W    bisr_mem_speed_mode_data_ram_g0                 1'h0
        1       R/W    bisr_mem_speed_mode_data_ram_g1                 1'h0
        2       R/W    bisr_mem_speed_mode_data_ram_g2                 1'h0
        3       R/W    bisr_mem_speed_mode_data_ram_g3                 1'h0
        4       R/W    bisr_mem_speed_mode_data_ram_g4                 1'h0
        5       R/W    bisr_mem_speed_mode_data_ram_g5                 1'h0
        6       R/W    bisr_mem_speed_mode_data_ram_g6                 1'h0
        7       R/W    bisr_mem_speed_mode_data_ram_g7                 1'h0
        8       R/W    bisr_mem_speed_mode_data_ram_g8                 1'h0
        9       R/W    bisr_mem_speed_mode_data_ram_g9                 1'h0
        10      R/W    bisr_mem_speed_mode_data_ram_g10                1'h0
        11      R/W    bisr_mem_speed_mode_data_ram_g11                1'h0
        23:12   R      RSVD                                            12'h0
        24      R/W    bisr_mem_speed_mode_dsp_ram_g0                  1'h0
        25      R/W    bisr_mem_speed_mode_dsp_ram_g1                  1'h0
        26      R/W    bisr_mem_speed_mode_dsp_ram_g2                  1'h0
        27      R/W    bisr_mem_speed_mode_dsp_ram_g3                  1'h0
        28      R/W    bisr_mem_speed_mode_dsp_sys_ram_g0              1'h0
        29      R/W    bisr_mem_speed_mode_dsp_sys_ram_g1              1'h0
        30      R/W    bisr_mem_speed_mode_dsp_sys_ram_g2              1'h0
        31      R/W    bisr_mem_speed_mode_dsp_sys_ram_g3              1'h0
    */
    union
    {
        __IO uint32_t REG_DATA_BISR_MEM_SPEED_MODE;
        struct
        {
            __IO uint32_t bisr_mem_speed_mode_data_ram_g0: 1;
            __IO uint32_t bisr_mem_speed_mode_data_ram_g1: 1;
            __IO uint32_t bisr_mem_speed_mode_data_ram_g2: 1;
            __IO uint32_t bisr_mem_speed_mode_data_ram_g3: 1;
            __IO uint32_t bisr_mem_speed_mode_data_ram_g4: 1;
            __IO uint32_t bisr_mem_speed_mode_data_ram_g5: 1;
            __IO uint32_t bisr_mem_speed_mode_data_ram_g6: 1;
            __IO uint32_t bisr_mem_speed_mode_data_ram_g7: 1;
            __IO uint32_t bisr_mem_speed_mode_data_ram_g8: 1;
            __IO uint32_t bisr_mem_speed_mode_data_ram_g9: 1;
            __IO uint32_t bisr_mem_speed_mode_data_ram_g10: 1;
            __IO uint32_t bisr_mem_speed_mode_data_ram_g11: 1;
            __I uint32_t RESERVED_0: 12;
            __IO uint32_t bisr_mem_speed_mode_dsp_ram_g0: 1;
            __IO uint32_t bisr_mem_speed_mode_dsp_ram_g1: 1;
            __IO uint32_t bisr_mem_speed_mode_dsp_ram_g2: 1;
            __IO uint32_t bisr_mem_speed_mode_dsp_ram_g3: 1;
            __IO uint32_t bisr_mem_speed_mode_dsp_sys_ram_g0: 1;
            __IO uint32_t bisr_mem_speed_mode_dsp_sys_ram_g1: 1;
            __IO uint32_t bisr_mem_speed_mode_dsp_sys_ram_g2: 1;
            __IO uint32_t bisr_mem_speed_mode_dsp_sys_ram_g3: 1;
        } BITS_A1C;
    } u_A1C;

    /* 0x0A20       0x400e_0a20
        0       R      bisr_start_pause_data_ram_g0                    1'h0
        1       R      bisr_start_pause_data_ram_g1                    1'h0
        2       R      bisr_start_pause_data_ram_g2                    1'h0
        3       R      bisr_start_pause_data_ram_g3                    1'h0
        4       R      bisr_start_pause_data_ram_g4                    1'h0
        5       R      bisr_start_pause_data_ram_g5                    1'h0
        6       R      bisr_start_pause_data_ram_g6                    1'h0
        7       R      bisr_start_pause_data_ram_g7                    1'h0
        8       R      bisr_start_pause_data_ram_g8                    1'h0
        9       R      bisr_start_pause_data_ram_g9                    1'h0
        10      R      bisr_start_pause_data_ram_g10                   1'h0
        11      R      bisr_start_pause_data_ram_g11                   1'h0
        15:12   R      bisr_start_pause_dsp_ram_g0                     4'h0
        19:16   R      bisr_start_pause_dsp_ram_g1                     4'h0
        23:20   R      bisr_start_pause_dsp_ram_g2                     4'h0
        27:24   R      bisr_start_pause_dsp_ram_g3                     4'h0
        28      R      bisr_start_pause_dsp_sys_ram_g0                 1'h0
        29      R      bisr_start_pause_dsp_sys_ram_g1                 1'h0
        30      R      bisr_start_pause_dsp_sys_ram_g2                 1'h0
        31      R      bisr_start_pause_dsp_sys_ram_g3                 1'h0
    */
    union
    {
        __IO uint32_t REG_DATA_BISR_START_PAUSE;
        struct
        {
            __I uint32_t bisr_start_pause_data_ram_g0: 1;
            __I uint32_t bisr_start_pause_data_ram_g1: 1;
            __I uint32_t bisr_start_pause_data_ram_g2: 1;
            __I uint32_t bisr_start_pause_data_ram_g3: 1;
            __I uint32_t bisr_start_pause_data_ram_g4: 1;
            __I uint32_t bisr_start_pause_data_ram_g5: 1;
            __I uint32_t bisr_start_pause_data_ram_g6: 1;
            __I uint32_t bisr_start_pause_data_ram_g7: 1;
            __I uint32_t bisr_start_pause_data_ram_g8: 1;
            __I uint32_t bisr_start_pause_data_ram_g9: 1;
            __I uint32_t bisr_start_pause_data_ram_g10: 1;
            __I uint32_t bisr_start_pause_data_ram_g11: 1;
            __I uint32_t bisr_start_pause_dsp_ram_g0: 4;
            __I uint32_t bisr_start_pause_dsp_ram_g1: 4;
            __I uint32_t bisr_start_pause_dsp_ram_g2: 4;
            __I uint32_t bisr_start_pause_dsp_ram_g3: 4;
            __I uint32_t bisr_start_pause_dsp_sys_ram_g0: 1;
            __I uint32_t bisr_start_pause_dsp_sys_ram_g1: 1;
            __I uint32_t bisr_start_pause_dsp_sys_ram_g2: 1;
            __I uint32_t bisr_start_pause_dsp_sys_ram_g3: 1;
        } BITS_A20;
    } u_A20;

    /* 0x0A24       0x400e_0a24
        0       R      bisr_done_data_ram_g0                           1'h0
        1       R      bisr_done_data_ram_g1                           1'h0
        2       R      bisr_done_data_ram_g2                           1'h0
        3       R      bisr_done_data_ram_g3                           1'h0
        4       R      bisr_done_data_ram_g4                           1'h0
        5       R      bisr_done_data_ram_g5                           1'h0
        6       R      bisr_done_data_ram_g6                           1'h0
        7       R      bisr_done_data_ram_g7                           1'h0
        8       R      bisr_done_data_ram_g8                           1'h0
        9       R      bisr_done_data_ram_g9                           1'h0
        10      R      bisr_done_data_ram_g10                          1'h0
        11      R      bisr_done_data_ram_g11                          1'h0
        15:12   R      bisr_done_dsp_ram_g0                            4'h0
        19:16   R      bisr_done_dsp_ram_g1                            4'h0
        23:20   R      bisr_done_dsp_ram_g2                            4'h0
        27:24   R      bisr_done_dsp_ram_g3                            4'h0
        28      R      bisr_done_dsp_sys_ram_g0                        1'h0
        29      R      bisr_done_dsp_sys_ram_g1                        1'h0
        30      R      bisr_done_dsp_sys_ram_g2                        1'h0
        31      R      bisr_done_dsp_sys_ram_g3                        1'h0
    */
    union
    {
        __IO uint32_t REG_DATA_BISR_DONE;
        struct
        {
            __I uint32_t bisr_done_data_ram_g0: 1;
            __I uint32_t bisr_done_data_ram_g1: 1;
            __I uint32_t bisr_done_data_ram_g2: 1;
            __I uint32_t bisr_done_data_ram_g3: 1;
            __I uint32_t bisr_done_data_ram_g4: 1;
            __I uint32_t bisr_done_data_ram_g5: 1;
            __I uint32_t bisr_done_data_ram_g6: 1;
            __I uint32_t bisr_done_data_ram_g7: 1;
            __I uint32_t bisr_done_data_ram_g8: 1;
            __I uint32_t bisr_done_data_ram_g9: 1;
            __I uint32_t bisr_done_data_ram_g10: 1;
            __I uint32_t bisr_done_data_ram_g11: 1;
            __I uint32_t bisr_done_dsp_ram_g0: 4;
            __I uint32_t bisr_done_dsp_ram_g1: 4;
            __I uint32_t bisr_done_dsp_ram_g2: 4;
            __I uint32_t bisr_done_dsp_ram_g3: 4;
            __I uint32_t bisr_done_dsp_sys_ram_g0: 1;
            __I uint32_t bisr_done_dsp_sys_ram_g1: 1;
            __I uint32_t bisr_done_dsp_sys_ram_g2: 1;
            __I uint32_t bisr_done_dsp_sys_ram_g3: 1;
        } BITS_A24;
    } u_A24;

    /* 0x0A28       0x400e_0a28
        0       R      bisr_fail_data_ram_g0                           1'h0
        1       R      bisr_fail_data_ram_g1                           1'h0
        2       R      bisr_fail_data_ram_g2                           1'h0
        3       R      bisr_fail_data_ram_g3                           1'h0
        4       R      bisr_fail_data_ram_g4                           1'h0
        5       R      bisr_fail_data_ram_g5                           1'h0
        6       R      bisr_fail_data_ram_g6                           1'h0
        7       R      bisr_fail_data_ram_g7                           1'h0
        8       R      bisr_fail_data_ram_g8                           1'h0
        9       R      bisr_fail_data_ram_g9                           1'h0
        10      R      bisr_fail_data_ram_g10                          1'h0
        11      R      bisr_fail_data_ram_g11                          1'h0
        15:12   R      bisr_fail_dsp_ram_g0                            4'h0
        19:16   R      bisr_fail_dsp_ram_g1                            4'h0
        23:20   R      bisr_fail_dsp_ram_g2                            4'h0
        27:24   R      bisr_fail_dsp_ram_g3                            4'h0
        28      R      bisr_fail_dsp_sys_ram_g0                        1'h0
        29      R      bisr_fail_dsp_sys_ram_g1                        1'h0
        30      R      bisr_fail_dsp_sys_ram_g2                        1'h0
        31      R      bisr_fail_dsp_sys_ram_g3                        1'h0
    */
    union
    {
        __IO uint32_t REG_DATA_BISR_FAIL;
        struct
        {
            __I uint32_t bisr_fail_data_ram_g0: 1;
            __I uint32_t bisr_fail_data_ram_g1: 1;
            __I uint32_t bisr_fail_data_ram_g2: 1;
            __I uint32_t bisr_fail_data_ram_g3: 1;
            __I uint32_t bisr_fail_data_ram_g4: 1;
            __I uint32_t bisr_fail_data_ram_g5: 1;
            __I uint32_t bisr_fail_data_ram_g6: 1;
            __I uint32_t bisr_fail_data_ram_g7: 1;
            __I uint32_t bisr_fail_data_ram_g8: 1;
            __I uint32_t bisr_fail_data_ram_g9: 1;
            __I uint32_t bisr_fail_data_ram_g10: 1;
            __I uint32_t bisr_fail_data_ram_g11: 1;
            __I uint32_t bisr_fail_dsp_ram_g0: 4;
            __I uint32_t bisr_fail_dsp_ram_g1: 4;
            __I uint32_t bisr_fail_dsp_ram_g2: 4;
            __I uint32_t bisr_fail_dsp_ram_g3: 4;
            __I uint32_t bisr_fail_dsp_sys_ram_g0: 1;
            __I uint32_t bisr_fail_dsp_sys_ram_g1: 1;
            __I uint32_t bisr_fail_dsp_sys_ram_g2: 1;
            __I uint32_t bisr_fail_dsp_sys_ram_g3: 1;
        } BITS_A28;
    } u_A28;

    /* 0x0A2C       0x400e_0a2c
        0       R      bisr_done_drf_data_ram_g0                       1'h0
        1       R      bisr_done_drf_data_ram_g1                       1'h0
        2       R      bisr_done_drf_data_ram_g2                       1'h0
        3       R      bisr_done_drf_data_ram_g3                       1'h0
        4       R      bisr_done_drf_data_ram_g4                       1'h0
        5       R      bisr_done_drf_data_ram_g5                       1'h0
        6       R      bisr_done_drf_data_ram_g6                       1'h0
        7       R      bisr_done_drf_data_ram_g7                       1'h0
        8       R      bisr_done_drf_data_ram_g8                       1'h0
        9       R      bisr_done_drf_data_ram_g9                       1'h0
        10      R      bisr_done_drf_data_ram_g10                      1'h0
        11      R      bisr_done_drf_data_ram_g11                      1'h0
        15:12   R      bisr_done_drf_dsp_ram_g0                        4'h0
        19:16   R      bisr_done_drf_dsp_ram_g1                        4'h0
        23:20   R      bisr_done_drf_dsp_ram_g2                        4'h0
        27:24   R      bisr_done_drf_dsp_ram_g3                        4'h0
        28      R      bisr_done_drf_dsp_sys_ram_g0                    1'h0
        29      R      bisr_done_drf_dsp_sys_ram_g1                    1'h0
        30      R      bisr_done_drf_dsp_sys_ram_g2                    1'h0
        31      R      bisr_done_drf_dsp_sys_ram_g3                    1'h0
    */
    union
    {
        __IO uint32_t REG_DATA_DRF_BISR_DONE;
        struct
        {
            __I uint32_t bisr_done_drf_data_ram_g0: 1;
            __I uint32_t bisr_done_drf_data_ram_g1: 1;
            __I uint32_t bisr_done_drf_data_ram_g2: 1;
            __I uint32_t bisr_done_drf_data_ram_g3: 1;
            __I uint32_t bisr_done_drf_data_ram_g4: 1;
            __I uint32_t bisr_done_drf_data_ram_g5: 1;
            __I uint32_t bisr_done_drf_data_ram_g6: 1;
            __I uint32_t bisr_done_drf_data_ram_g7: 1;
            __I uint32_t bisr_done_drf_data_ram_g8: 1;
            __I uint32_t bisr_done_drf_data_ram_g9: 1;
            __I uint32_t bisr_done_drf_data_ram_g10: 1;
            __I uint32_t bisr_done_drf_data_ram_g11: 1;
            __I uint32_t bisr_done_drf_dsp_ram_g0: 4;
            __I uint32_t bisr_done_drf_dsp_ram_g1: 4;
            __I uint32_t bisr_done_drf_dsp_ram_g2: 4;
            __I uint32_t bisr_done_drf_dsp_ram_g3: 4;
            __I uint32_t bisr_done_drf_dsp_sys_ram_g0: 1;
            __I uint32_t bisr_done_drf_dsp_sys_ram_g1: 1;
            __I uint32_t bisr_done_drf_dsp_sys_ram_g2: 1;
            __I uint32_t bisr_done_drf_dsp_sys_ram_g3: 1;
        } BITS_A2C;
    } u_A2C;

    /* 0x0A30       0x400e_0a30
        0       R      bisr_fail_drf_data_ram_g0                       1'h0
        1       R      bisr_fail_drf_data_ram_g1                       1'h0
        2       R      bisr_fail_drf_data_ram_g2                       1'h0
        3       R      bisr_fail_drf_data_ram_g3                       1'h0
        4       R      bisr_fail_drf_data_ram_g4                       1'h0
        5       R      bisr_fail_drf_data_ram_g5                       1'h0
        6       R      bisr_fail_drf_data_ram_g6                       1'h0
        7       R      bisr_fail_drf_data_ram_g7                       1'h0
        8       R      bisr_fail_drf_data_ram_g8                       1'h0
        9       R      bisr_fail_drf_data_ram_g9                       1'h0
        10      R      bisr_fail_drf_data_ram_g10                      1'h0
        11      R      bisr_fail_drf_data_ram_g11                      1'h0
        15:12   R      bisr_fail_drf_dsp_ram_g0                        4'h0
        19:16   R      bisr_fail_drf_dsp_ram_g1                        4'h0
        23:20   R      bisr_fail_drf_dsp_ram_g2                        4'h0
        27:24   R      bisr_fail_drf_dsp_ram_g3                        4'h0
        28      R      bisr_fail_drf_dsp_sys_ram_g0                    1'h0
        29      R      bisr_fail_drf_dsp_sys_ram_g1                    1'h0
        30      R      bisr_fail_drf_dsp_sys_ram_g2                    1'h0
        31      R      bisr_fail_drf_dsp_sys_ram_g3                    1'h0
    */
    union
    {
        __IO uint32_t REG_DATA_DRF_BISR_FAIL;
        struct
        {
            __I uint32_t bisr_fail_drf_data_ram_g0: 1;
            __I uint32_t bisr_fail_drf_data_ram_g1: 1;
            __I uint32_t bisr_fail_drf_data_ram_g2: 1;
            __I uint32_t bisr_fail_drf_data_ram_g3: 1;
            __I uint32_t bisr_fail_drf_data_ram_g4: 1;
            __I uint32_t bisr_fail_drf_data_ram_g5: 1;
            __I uint32_t bisr_fail_drf_data_ram_g6: 1;
            __I uint32_t bisr_fail_drf_data_ram_g7: 1;
            __I uint32_t bisr_fail_drf_data_ram_g8: 1;
            __I uint32_t bisr_fail_drf_data_ram_g9: 1;
            __I uint32_t bisr_fail_drf_data_ram_g10: 1;
            __I uint32_t bisr_fail_drf_data_ram_g11: 1;
            __I uint32_t bisr_fail_drf_dsp_ram_g0: 4;
            __I uint32_t bisr_fail_drf_dsp_ram_g1: 4;
            __I uint32_t bisr_fail_drf_dsp_ram_g2: 4;
            __I uint32_t bisr_fail_drf_dsp_ram_g3: 4;
            __I uint32_t bisr_fail_drf_dsp_sys_ram_g0: 1;
            __I uint32_t bisr_fail_drf_dsp_sys_ram_g1: 1;
            __I uint32_t bisr_fail_drf_dsp_sys_ram_g2: 1;
            __I uint32_t bisr_fail_drf_dsp_sys_ram_g3: 1;
        } BITS_A30;
    } u_A30;

    /* 0x0A34       0x400e_0a34
        0       R      bisr_repaired_data_ram_g0                       1'h0
        1       R      bisr_repaired_data_ram_g1                       1'h0
        2       R      bisr_repaired_data_ram_g2                       1'h0
        3       R      bisr_repaired_data_ram_g3                       1'h0
        4       R      bisr_repaired_data_ram_g4                       1'h0
        5       R      bisr_repaired_data_ram_g5                       1'h0
        6       R      bisr_repaired_data_ram_g6                       1'h0
        7       R      bisr_repaired_data_ram_g7                       1'h0
        8       R      bisr_repaired_data_ram_g8                       1'h0
        9       R      bisr_repaired_data_ram_g9                       1'h0
        10      R      bisr_repaired_data_ram_g10                      1'h0
        11      R      bisr_repaired_data_ram_g11                      1'h0
        23:12   R      RSVD                                            12'h0
        24      R      bisr_repaired_dsp_ram_g0                        1'h0
        25      R      bisr_repaired_dsp_ram_g1                        1'h0
        26      R      bisr_repaired_dsp_ram_g2                        1'h0
        27      R      bisr_repaired_dsp_ram_g3                        1'h0
        28      R      bisr_repaired_dsp_sys_ram_g0                    1'h0
        29      R      bisr_repaired_dsp_sys_ram_g1                    1'h0
        30      R      bisr_repaired_dsp_sys_ram_g2                    1'h0
        31      R      bisr_repaired_dsp_sys_ram_g3                    1'h0
    */
    union
    {
        __IO uint32_t REG_DATA_BISR_REPAIRED;
        struct
        {
            __I uint32_t bisr_repaired_data_ram_g0: 1;
            __I uint32_t bisr_repaired_data_ram_g1: 1;
            __I uint32_t bisr_repaired_data_ram_g2: 1;
            __I uint32_t bisr_repaired_data_ram_g3: 1;
            __I uint32_t bisr_repaired_data_ram_g4: 1;
            __I uint32_t bisr_repaired_data_ram_g5: 1;
            __I uint32_t bisr_repaired_data_ram_g6: 1;
            __I uint32_t bisr_repaired_data_ram_g7: 1;
            __I uint32_t bisr_repaired_data_ram_g8: 1;
            __I uint32_t bisr_repaired_data_ram_g9: 1;
            __I uint32_t bisr_repaired_data_ram_g10: 1;
            __I uint32_t bisr_repaired_data_ram_g11: 1;
            __I uint32_t RESERVED_0: 12;
            __I uint32_t bisr_repaired_dsp_ram_g0: 1;
            __I uint32_t bisr_repaired_dsp_ram_g1: 1;
            __I uint32_t bisr_repaired_dsp_ram_g2: 1;
            __I uint32_t bisr_repaired_dsp_ram_g3: 1;
            __I uint32_t bisr_repaired_dsp_sys_ram_g0: 1;
            __I uint32_t bisr_repaired_dsp_sys_ram_g1: 1;
            __I uint32_t bisr_repaired_dsp_sys_ram_g2: 1;
            __I uint32_t bisr_repaired_dsp_sys_ram_g3: 1;
        } BITS_A34;
    } u_A34;

    /* 0x0A38       0x400e_0a38
        0       R/W    bisr_second_run_en_data_ram_g0                  1'h0
        1       R/W    bisr_second_run_en_data_ram_g1                  1'h0
        2       R/W    bisr_second_run_en_data_ram_g2                  1'h0
        3       R/W    bisr_second_run_en_data_ram_g3                  1'h0
        4       R/W    bisr_second_run_en_data_ram_g4                  1'h0
        5       R/W    bisr_second_run_en_data_ram_g5                  1'h0
        6       R/W    bisr_second_run_en_data_ram_g6                  1'h0
        7       R/W    bisr_second_run_en_data_ram_g7                  1'h0
        8       R/W    bisr_second_run_en_data_ram_g8                  1'h0
        9       R/W    bisr_second_run_en_data_ram_g9                  1'h0
        10      R/W    bisr_second_run_en_data_ram_g10                 1'h0
        11      R/W    bisr_second_run_en_data_ram_g11                 1'h0
        23:12   R      RSVD                                            12'h0
        24      R/W    bisr_second_run_en_dsp_ram_g0                   1'h0
        25      R/W    bisr_second_run_en_dsp_ram_g1                   1'h0
        26      R/W    bisr_second_run_en_dsp_ram_g2                   1'h0
        27      R/W    bisr_second_run_en_dsp_ram_g3                   1'h0
        28      R/W    bisr_second_run_en_dsp_sys_ram_g0               1'h0
        29      R/W    bisr_second_run_en_dsp_sys_ram_g1               1'h0
        30      R/W    bisr_second_run_en_dsp_sys_ram_g2               1'h0
        31      R/W    bisr_second_run_en_dsp_sys_ram_g3               1'h0
    */
    union
    {
        __IO uint32_t REG_DATA_BISR_CTRL;
        struct
        {
            __IO uint32_t bisr_second_run_en_data_ram_g0: 1;
            __IO uint32_t bisr_second_run_en_data_ram_g1: 1;
            __IO uint32_t bisr_second_run_en_data_ram_g2: 1;
            __IO uint32_t bisr_second_run_en_data_ram_g3: 1;
            __IO uint32_t bisr_second_run_en_data_ram_g4: 1;
            __IO uint32_t bisr_second_run_en_data_ram_g5: 1;
            __IO uint32_t bisr_second_run_en_data_ram_g6: 1;
            __IO uint32_t bisr_second_run_en_data_ram_g7: 1;
            __IO uint32_t bisr_second_run_en_data_ram_g8: 1;
            __IO uint32_t bisr_second_run_en_data_ram_g9: 1;
            __IO uint32_t bisr_second_run_en_data_ram_g10: 1;
            __IO uint32_t bisr_second_run_en_data_ram_g11: 1;
            __I uint32_t RESERVED_0: 12;
            __IO uint32_t bisr_second_run_en_dsp_ram_g0: 1;
            __IO uint32_t bisr_second_run_en_dsp_ram_g1: 1;
            __IO uint32_t bisr_second_run_en_dsp_ram_g2: 1;
            __IO uint32_t bisr_second_run_en_dsp_ram_g3: 1;
            __IO uint32_t bisr_second_run_en_dsp_sys_ram_g0: 1;
            __IO uint32_t bisr_second_run_en_dsp_sys_ram_g1: 1;
            __IO uint32_t bisr_second_run_en_dsp_sys_ram_g2: 1;
            __IO uint32_t bisr_second_run_en_dsp_sys_ram_g3: 1;
        } BITS_A38;
    } u_A38;

    /* 0x0A3C       0x400e_0a3c
        6:0     R      bisr_out_data_ram_g0                            7'h0
        13:7    R      bisr_out_data_ram_g1                            7'h0
        20:14   R      bisr_out_data_ram_g2                            7'h0
        27:21   R      bisr_out_data_ram_g3                            7'h0
        31:28   R      RSVD                                            4'h0
    */
    union
    {
        __IO uint32_t REG_DATA_BISR_OUT_0;
        struct
        {
            __I uint32_t bisr_out_data_ram_g0: 7;
            __I uint32_t bisr_out_data_ram_g1: 7;
            __I uint32_t bisr_out_data_ram_g2: 7;
            __I uint32_t bisr_out_data_ram_g3: 7;
            __I uint32_t RESERVED_0: 4;
        } BITS_A3C;
    } u_A3C;

    /* 0x0A40       0x400e_0a40
        6:0     R      bisr_out_data_ram_g4                            7'h0
        13:7    R      bisr_out_data_ram_g5                            7'h0
        20:14   R      bisr_out_data_ram_g6                            7'h0
        27:21   R      bisr_out_data_ram_g7                            7'h0
        31:28   R      RSVD                                            4'h0
    */
    union
    {
        __IO uint32_t REG_DATA_BISR_OUT_1;
        struct
        {
            __I uint32_t bisr_out_data_ram_g4: 7;
            __I uint32_t bisr_out_data_ram_g5: 7;
            __I uint32_t bisr_out_data_ram_g6: 7;
            __I uint32_t bisr_out_data_ram_g7: 7;
            __I uint32_t RESERVED_0: 4;
        } BITS_A40;
    } u_A40;

    /* 0x0A44       0x400e_0a44
        6:0     R      bisr_out_data_ram_g8                            7'h0
        13:7    R      bisr_out_data_ram_g9                            7'h0
        20:14   R      bisr_out_data_ram_g10                           7'h0
        27:21   R      bisr_out_data_ram_g11                           7'h0
        31:28   R      RSVD                                            4'h0
    */
    union
    {
        __IO uint32_t REG_DATA_BISR_OUT_2;
        struct
        {
            __I uint32_t bisr_out_data_ram_g8: 7;
            __I uint32_t bisr_out_data_ram_g9: 7;
            __I uint32_t bisr_out_data_ram_g10: 7;
            __I uint32_t bisr_out_data_ram_g11: 7;
            __I uint32_t RESERVED_0: 4;
        } BITS_A44;
    } u_A44;

    /* 0x0A48       0x400e_0a48
        6:0     R/W    bisr_remap_sig_data_ram_g0                      7'h0
        7       R/W    bisr_load_fuse_data_ram_g0                      1'h0
        14:8    R/W    bisr_remap_sig_data_ram_g1                      7'h0
        15      R/W    bisr_load_fuse_data_ram_g1                      1'h0
        22:16   R/W    bisr_remap_sig_data_ram_g2                      7'h0
        23      R/W    bisr_load_fuse_data_ram_g2                      1'h0
        30:24   R/W    bisr_remap_sig_data_ram_g3                      7'h0
        31      R/W    bisr_load_fuse_data_ram_g3                      1'h0
    */
    union
    {
        __IO uint32_t REG_DATA_RAM_BISR_REMAP_0;
        struct
        {
            __IO uint32_t bisr_remap_sig_data_ram_g0: 7;
            __IO uint32_t bisr_load_fuse_data_ram_g0: 1;
            __IO uint32_t bisr_remap_sig_data_ram_g1: 7;
            __IO uint32_t bisr_load_fuse_data_ram_g1: 1;
            __IO uint32_t bisr_remap_sig_data_ram_g2: 7;
            __IO uint32_t bisr_load_fuse_data_ram_g2: 1;
            __IO uint32_t bisr_remap_sig_data_ram_g3: 7;
            __IO uint32_t bisr_load_fuse_data_ram_g3: 1;
        } BITS_A48;
    } u_A48;

    /* 0x0A4C       0x400e_0a4c
        6:0     R/W    bisr_remap_sig_data_ram_g4                      7'h0
        7       R/W    bisr_load_fuse_data_ram_g4                      1'h0
        14:8    R/W    bisr_remap_sig_data_ram_g5                      7'h0
        15      R/W    bisr_load_fuse_data_ram_g5                      1'h0
        22:16   R/W    bisr_remap_sig_data_ram_g6                      7'h0
        23      R/W    bisr_load_fuse_data_ram_g6                      1'h0
        30:24   R/W    bisr_remap_sig_data_ram_g7                      7'h0
        31      R/W    bisr_load_fuse_data_ram_g7                      1'h0
    */
    union
    {
        __IO uint32_t REG_DATA_RAM_BISR_REMAP_1;
        struct
        {
            __IO uint32_t bisr_remap_sig_data_ram_g4: 7;
            __IO uint32_t bisr_load_fuse_data_ram_g4: 1;
            __IO uint32_t bisr_remap_sig_data_ram_g5: 7;
            __IO uint32_t bisr_load_fuse_data_ram_g5: 1;
            __IO uint32_t bisr_remap_sig_data_ram_g6: 7;
            __IO uint32_t bisr_load_fuse_data_ram_g6: 1;
            __IO uint32_t bisr_remap_sig_data_ram_g7: 7;
            __IO uint32_t bisr_load_fuse_data_ram_g7: 1;
        } BITS_A4C;
    } u_A4C;

    /* 0x0A50       0x400e_0a50
        6:0     R/W    bisr_remap_sig_data_ram_g8                      7'h0
        7       R/W    bisr_load_fuse_data_ram_g8                      1'h0
        14:8    R/W    bisr_remap_sig_data_ram_g9                      7'h0
        15      R/W    bisr_load_fuse_data_ram_g9                      1'h0
        22:16   R/W    bisr_remap_sig_data_ram_g10                     7'h0
        23      R/W    bisr_load_fuse_data_ram_g10                     1'h0
        30:24   R/W    bisr_remap_sig_data_ram_g11                     7'h0
        31      R/W    bisr_load_fuse_data_ram_g11                     1'h0
    */
    union
    {
        __IO uint32_t REG_DATA_RAM_BISR_REMAP_2;
        struct
        {
            __IO uint32_t bisr_remap_sig_data_ram_g8: 7;
            __IO uint32_t bisr_load_fuse_data_ram_g8: 1;
            __IO uint32_t bisr_remap_sig_data_ram_g9: 7;
            __IO uint32_t bisr_load_fuse_data_ram_g9: 1;
            __IO uint32_t bisr_remap_sig_data_ram_g10: 7;
            __IO uint32_t bisr_load_fuse_data_ram_g10: 1;
            __IO uint32_t bisr_remap_sig_data_ram_g11: 7;
            __IO uint32_t bisr_load_fuse_data_ram_g11: 1;
        } BITS_A50;
    } u_A50;

    /* 0x0A54       0x400e_0a54
        0       R/W    bisr_hold_remap_data_ram_g0                     1'h1
        1       R/W    bisr_hold_remap_data_ram_g1                     1'h1
        2       R/W    bisr_hold_remap_data_ram_g2                     1'h1
        3       R/W    bisr_hold_remap_data_ram_g3                     1'h1
        4       R/W    bisr_hold_remap_data_ram_g4                     1'h1
        5       R/W    bisr_hold_remap_data_ram_g5                     1'h1
        6       R/W    bisr_hold_remap_data_ram_g6                     1'h1
        7       R/W    bisr_hold_remap_data_ram_g7                     1'h1
        8       R/W    bisr_hold_remap_data_ram_g8                     1'h1
        9       R/W    bisr_hold_remap_data_ram_g9                     1'h1
        10      R/W    bisr_hold_remap_data_ram_g10                    1'h1
        11      R/W    bisr_hold_remap_data_ram_g11                    1'h1
        23:12   R      RSVD                                            12'h0
        24      R/W    bisr_hold_remap_dsp_ram_g0                      1'h1
        25      R/W    bisr_hold_remap_dsp_ram_g1                      1'h1
        26      R/W    bisr_hold_remap_dsp_ram_g2                      1'h1
        27      R/W    bisr_hold_remap_dsp_ram_g3                      1'h1
        28      R/W    bisr_hold_remap_dsp_sys_ram_g0                  1'h1
        29      R/W    bisr_hold_remap_dsp_sys_ram_g1                  1'h1
        30      R/W    bisr_hold_remap_dsp_sys_ram_g2                  1'h1
        31      R/W    bisr_hold_remap_dsp_sys_ram_g3                  1'h1
    */
    union
    {
        __IO uint32_t REG_DATA_RAM_BISR_HOLD_REMAP;
        struct
        {
            __IO uint32_t bisr_hold_remap_data_ram_g0: 1;
            __IO uint32_t bisr_hold_remap_data_ram_g1: 1;
            __IO uint32_t bisr_hold_remap_data_ram_g2: 1;
            __IO uint32_t bisr_hold_remap_data_ram_g3: 1;
            __IO uint32_t bisr_hold_remap_data_ram_g4: 1;
            __IO uint32_t bisr_hold_remap_data_ram_g5: 1;
            __IO uint32_t bisr_hold_remap_data_ram_g6: 1;
            __IO uint32_t bisr_hold_remap_data_ram_g7: 1;
            __IO uint32_t bisr_hold_remap_data_ram_g8: 1;
            __IO uint32_t bisr_hold_remap_data_ram_g9: 1;
            __IO uint32_t bisr_hold_remap_data_ram_g10: 1;
            __IO uint32_t bisr_hold_remap_data_ram_g11: 1;
            __I uint32_t RESERVED_0: 12;
            __IO uint32_t bisr_hold_remap_dsp_ram_g0: 1;
            __IO uint32_t bisr_hold_remap_dsp_ram_g1: 1;
            __IO uint32_t bisr_hold_remap_dsp_ram_g2: 1;
            __IO uint32_t bisr_hold_remap_dsp_ram_g3: 1;
            __IO uint32_t bisr_hold_remap_dsp_sys_ram_g0: 1;
            __IO uint32_t bisr_hold_remap_dsp_sys_ram_g1: 1;
            __IO uint32_t bisr_hold_remap_dsp_sys_ram_g2: 1;
            __IO uint32_t bisr_hold_remap_dsp_sys_ram_g3: 1;
        } BITS_A54;
    } u_A54;

    /* 0x0A58       0x400e_0a58
        0       R      RSVD                                            1'h0
        1       R      RSVD                                            1'h0
        2       R      RSVD                                            1'h0
        3       R      RSVD                                            1'h0
        4       R      RSVD                                            1'h0
        5       R      RSVD                                            1'h0
        6       R      RSVD                                            1'h0
        7       R      RSVD                                            1'h0
        8       R      RSVD                                            1'h0
        9       R      RSVD                                            1'h0
        10      R      RSVD                                            1'h0
        11      R      RSVD                                            1'h0
        15:12   R      RSVD                                            4'h0
        19:16   R      RSVD                                            4'h0
        23:20   R      RSVD                                            4'h0
        27:24   R      RSVD                                            4'h0
        28      R      RSVD                                            1'h0
        29      R      RSVD                                            1'h0
        30      R      RSVD                                            1'h0
        31      R      RSVD                                            1'h0
    */
    union
    {
        __IO uint32_t REG_REMAP_RSTN_DATA_RAM;
        struct
        {
            __I uint32_t RESERVED_19: 1;
            __I uint32_t RESERVED_18: 1;
            __I uint32_t RESERVED_17: 1;
            __I uint32_t RESERVED_16: 1;
            __I uint32_t RESERVED_15: 1;
            __I uint32_t RESERVED_14: 1;
            __I uint32_t RESERVED_13: 1;
            __I uint32_t RESERVED_12: 1;
            __I uint32_t RESERVED_11: 1;
            __I uint32_t RESERVED_10: 1;
            __I uint32_t RESERVED_9: 1;
            __I uint32_t RESERVED_8: 1;
            __I uint32_t RESERVED_7: 4;
            __I uint32_t RESERVED_6: 4;
            __I uint32_t RESERVED_5: 4;
            __I uint32_t RESERVED_4: 4;
            __I uint32_t RESERVED_3: 1;
            __I uint32_t RESERVED_2: 1;
            __I uint32_t RESERVED_1: 1;
            __I uint32_t RESERVED_0: 1;
        } BITS_A58;
    } u_A58;

    /* 0x0A5C       0x400e_0a5c
        31:0    R/W    spic0_pgm_fifo_init_0                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC0_PGM_FIFO_INIT_0;
        struct
        {
            __IO uint32_t spic0_pgm_fifo_init_0: 32;
        } BITS_A5C;
    } u_A5C;

    /* 0x0A60       0x400e_0a60
        31:0    R/W    spic0_pgm_fifo_init_1                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC0_PGM_FIFO_INIT_1;
        struct
        {
            __IO uint32_t spic0_pgm_fifo_init_1: 32;
        } BITS_A60;
    } u_A60;

    /* 0x0A64       0x400e_0a64
        31:0    R/W    spic0_pgm_fifo_init_2                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC0_PGM_FIFO_INIT_2;
        struct
        {
            __IO uint32_t spic0_pgm_fifo_init_2: 32;
        } BITS_A64;
    } u_A64;

    /* 0x0A68       0x400e_0a68
        31:0    R/W    spic0_pgm_fifo_init_3                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC0_PGM_FIFO_INIT_3;
        struct
        {
            __IO uint32_t spic0_pgm_fifo_init_3: 32;
        } BITS_A68;
    } u_A68;

    /* 0x0A6C       0x400e_0a6c
        31:0    R/W    spic0_pgm_fifo_init_4                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC0_PGM_FIFO_INIT_4;
        struct
        {
            __IO uint32_t spic0_pgm_fifo_init_4: 32;
        } BITS_A6C;
    } u_A6C;

    /* 0x0A70       0x400e_0a70
        31:0    R/W    spic0_pgm_fifo_init_5                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC0_PGM_FIFO_INIT_5;
        struct
        {
            __IO uint32_t spic0_pgm_fifo_init_5: 32;
        } BITS_A70;
    } u_A70;

    /* 0x0A74       0x400e_0a74
        31:0    R/W    spic0_pgm_fifo_init_6                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC0_PGM_FIFO_INIT_6;
        struct
        {
            __IO uint32_t spic0_pgm_fifo_init_6: 32;
        } BITS_A74;
    } u_A74;

    /* 0x0A78       0x400e_0a78
        31:0    R/W    spic0_pgm_fifo_init_7                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC0_PGM_FIFO_INIT_7;
        struct
        {
            __IO uint32_t spic0_pgm_fifo_init_7: 32;
        } BITS_A78;
    } u_A78;

    /* 0x0A7C       0x400e_0a7c
        4:0     R/W    spic0_pgm_fifo_wptr_init                        5'h0
        31:5    R      RSVD                                            27'h0
    */
    union
    {
        __IO uint32_t REG_SPIC0_PGM_FIFO_WPTR_INIT;
        struct
        {
            __IO uint32_t spic0_pgm_fifo_wptr_init: 5;
            __I uint32_t RESERVED_0: 27;
        } BITS_A7C;
    } u_A7C;

    /* 0x0A80       0x400e_0a80
        31:0    R/W    spic1_pgm_fifo_init_0                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC1_PGM_FIFO_INIT_0;
        struct
        {
            __IO uint32_t spic1_pgm_fifo_init_0: 32;
        } BITS_A80;
    } u_A80;

    /* 0x0A84       0x400e_0a84
        31:0    R/W    spic1_pgm_fifo_init_1                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC1_PGM_FIFO_INIT_1;
        struct
        {
            __IO uint32_t spic1_pgm_fifo_init_1: 32;
        } BITS_A84;
    } u_A84;

    /* 0x0A88       0x400e_0a88
        31:0    R/W    spic1_pgm_fifo_init_2                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC1_PGM_FIFO_INIT_2;
        struct
        {
            __IO uint32_t spic1_pgm_fifo_init_2: 32;
        } BITS_A88;
    } u_A88;

    /* 0x0A8C       0x400e_0a8c
        31:0    R/W    spic1_pgm_fifo_init_3                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC1_PGM_FIFO_INIT_3;
        struct
        {
            __IO uint32_t spic1_pgm_fifo_init_3: 32;
        } BITS_A8C;
    } u_A8C;

    /* 0x0A90       0x400e_0a90
        31:0    R/W    spic1_pgm_fifo_init_4                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC1_PGM_FIFO_INIT_4;
        struct
        {
            __IO uint32_t spic1_pgm_fifo_init_4: 32;
        } BITS_A90;
    } u_A90;

    /* 0x0A94       0x400e_0a94
        31:0    R/W    spic1_pgm_fifo_init_5                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC1_PGM_FIFO_INIT_5;
        struct
        {
            __IO uint32_t spic1_pgm_fifo_init_5: 32;
        } BITS_A94;
    } u_A94;

    /* 0x0A98       0x400e_0a98
        31:0    R/W    spic1_pgm_fifo_init_6                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC1_PGM_FIFO_INIT_6;
        struct
        {
            __IO uint32_t spic1_pgm_fifo_init_6: 32;
        } BITS_A98;
    } u_A98;

    /* 0x0A9C       0x400e_0a9c
        31:0    R/W    spic1_pgm_fifo_init_7                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC1_PGM_FIFO_INIT_7;
        struct
        {
            __IO uint32_t spic1_pgm_fifo_init_7: 32;
        } BITS_A9C;
    } u_A9C;

    /* 0x0AA0       0x400e_0aa0
        4:0     R/W    spic1_pgm_fifo_wptr_init                        5'h0
        31:5    R      RSVD                                            27'h0
    */
    union
    {
        __IO uint32_t REG_SPIC1_PGM_FIFO_WPTR_INIT;
        struct
        {
            __IO uint32_t spic1_pgm_fifo_wptr_init: 5;
            __I uint32_t RESERVED_0: 27;
        } BITS_AA0;
    } u_AA0;

    /* 0x0AA4       0x400e_0aa4
        31:0    R/W    spic3_pgm_fifo_init_0                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC3_PGM_FIFO_INIT_0;
        struct
        {
            __IO uint32_t spic3_pgm_fifo_init_0: 32;
        } BITS_AA4;
    } u_AA4;

    /* 0x0AA8       0x400e_0aa8
        31:0    R/W    spic3_pgm_fifo_init_1                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC3_PGM_FIFO_INIT_1;
        struct
        {
            __IO uint32_t spic3_pgm_fifo_init_1: 32;
        } BITS_AA8;
    } u_AA8;

    /* 0x0AAC       0x400e_0aac
        31:0    R/W    spic3_pgm_fifo_init_2                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC3_PGM_FIFO_INIT_2;
        struct
        {
            __IO uint32_t spic3_pgm_fifo_init_2: 32;
        } BITS_AAC;
    } u_AAC;

    /* 0x0AB0       0x400e_0ab0
        31:0    R/W    spic3_pgm_fifo_init_3                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC3_PGM_FIFO_INIT_3;
        struct
        {
            __IO uint32_t spic3_pgm_fifo_init_3: 32;
        } BITS_AB0;
    } u_AB0;

    /* 0x0AB4       0x400e_0ab4
        31:0    R/W    spic3_pgm_fifo_init_4                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC3_PGM_FIFO_INIT_4;
        struct
        {
            __IO uint32_t spic3_pgm_fifo_init_4: 32;
        } BITS_AB4;
    } u_AB4;

    /* 0x0AB8       0x400e_0ab8
        31:0    R/W    spic3_pgm_fifo_init_5                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC3_PGM_FIFO_INIT_5;
        struct
        {
            __IO uint32_t spic3_pgm_fifo_init_5: 32;
        } BITS_AB8;
    } u_AB8;

    /* 0x0ABC       0x400e_0abc
        31:0    R/W    spic3_pgm_fifo_init_6                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC3_PGM_FIFO_INIT_6;
        struct
        {
            __IO uint32_t spic3_pgm_fifo_init_6: 32;
        } BITS_ABC;
    } u_ABC;

    /* 0x0AC0       0x400e_0ac0
        31:0    R/W    spic3_pgm_fifo_init_7                           32'h0
    */
    union
    {
        __IO uint32_t REG_SPIC3_PGM_FIFO_INIT_7;
        struct
        {
            __IO uint32_t spic3_pgm_fifo_init_7: 32;
        } BITS_AC0;
    } u_AC0;

    /* 0x0AC4       0x400e_0ac4
        4:0     R/W    spic3_pgm_fifo_wptr_init                        5'h0
        31:5    R      RSVD                                            27'h0
    */
    union
    {
        __IO uint32_t REG_SPIC3_PGM_FIFO_WPTR_INIT;
        struct
        {
            __IO uint32_t spic3_pgm_fifo_wptr_init: 5;
            __I uint32_t RESERVED_0: 27;
        } BITS_AC4;
    } u_AC4;

    /* 0x0AC8       0x400e_0ac8
        6:0     R      bisr_out_dsp_sys_ram_g0                         7'h0
        13:7    R      bisr_out_dsp_sys_ram_g1                         7'h0
        20:14   R      bisr_out_dsp_sys_ram_g2                         7'h0
        27:21   R      bisr_out_dsp_sys_ram_g3                         7'h0
        31:28   R      RSVD                                            4'h0
    */
    union
    {
        __IO uint32_t REG_DSP_SYS_BISR_OUT_0;
        struct
        {
            __I uint32_t bisr_out_dsp_sys_ram_g0: 7;
            __I uint32_t bisr_out_dsp_sys_ram_g1: 7;
            __I uint32_t bisr_out_dsp_sys_ram_g2: 7;
            __I uint32_t bisr_out_dsp_sys_ram_g3: 7;
            __I uint32_t RESERVED_0: 4;
        } BITS_AC8;
    } u_AC8;

    /* 0x0ACC       0x400e_0acc
        6:0     R/W    bisr_remap_sig_dsp_sys_ram_g0                   7'h0
        7       R/W    bisr_load_fuse_dsp_sys_ram_g0                   1'h0
        14:8    R/W    bisr_remap_sig_dsp_sys_ram_g1                   7'h0
        15      R/W    bisr_load_fuse_dsp_sys_ram_g1                   1'h0
        22:16   R/W    bisr_remap_sig_dsp_sys_ram_g2                   7'h0
        23      R/W    bisr_load_fuse_dsp_sys_ram_g2                   1'h0
        30:24   R/W    bisr_remap_sig_dsp_sys_ram_g3                   7'h0
        31      R/W    bisr_load_fuse_dsp_sys_ram_g3                   1'h0
    */
    union
    {
        __IO uint32_t REG_DSP_SYS_RAM_BISR_REMAP_0;
        struct
        {
            __IO uint32_t bisr_remap_sig_dsp_sys_ram_g0: 7;
            __IO uint32_t bisr_load_fuse_dsp_sys_ram_g0: 1;
            __IO uint32_t bisr_remap_sig_dsp_sys_ram_g1: 7;
            __IO uint32_t bisr_load_fuse_dsp_sys_ram_g1: 1;
            __IO uint32_t bisr_remap_sig_dsp_sys_ram_g2: 7;
            __IO uint32_t bisr_load_fuse_dsp_sys_ram_g2: 1;
            __IO uint32_t bisr_remap_sig_dsp_sys_ram_g3: 7;
            __IO uint32_t bisr_load_fuse_dsp_sys_ram_g3: 1;
        } BITS_ACC;
    } u_ACC;

    /* 0x0AD0       0x400e_0ad0
        27:0    R      bisr_out_dsp_ram_g0                             28'h0
        31:28   R      RSVD                                            4'h0
    */
    union
    {
        __IO uint32_t REG_DSP_BISR_OUT_0;
        struct
        {
            __I uint32_t bisr_out_dsp_ram_g0: 28;
            __I uint32_t RESERVED_0: 4;
        } BITS_AD0;
    } u_AD0;

    /* 0x0AD4       0x400e_0ad4
        27:0    R      bisr_out_dsp_ram_g1                             28'h0
        31:28   R      RSVD                                            4'h0
    */
    union
    {
        __IO uint32_t REG_DSP_BISR_OUT_1;
        struct
        {
            __I uint32_t bisr_out_dsp_ram_g1: 28;
            __I uint32_t RESERVED_0: 4;
        } BITS_AD4;
    } u_AD4;

    /* 0x0AD8       0x400e_0ad8
        27:0    R      bisr_out_dsp_ram_g2                             28'h0
        31:28   R      RSVD                                            4'h0
    */
    union
    {
        __IO uint32_t REG_DSP_BISR_OUT_2;
        struct
        {
            __I uint32_t bisr_out_dsp_ram_g2: 28;
            __I uint32_t RESERVED_0: 4;
        } BITS_AD8;
    } u_AD8;

    /* 0x0ADC       0x400e_0adc
        27:0    R      bisr_out_dsp_ram_g3                             28'h0
        31:28   R      RSVD                                            4'h0
    */
    union
    {
        __IO uint32_t REG_DSP_BISR_OUT_3;
        struct
        {
            __I uint32_t bisr_out_dsp_ram_g3: 28;
            __I uint32_t RESERVED_0: 4;
        } BITS_ADC;
    } u_ADC;

    /* 0x0AE0       0x400e_0ae0
        27:0    R/W    bisr_remap_sig_dsp_ram_g0                       7'h0
        28      R/W    bisr_load_fuse_dsp_ram_g0                       1'h0
        31:29   R      RSVD                                            3'h0
    */
    union
    {
        __IO uint32_t REG_DSP_RAM_BISR_REMAP_0;
        struct
        {
            __IO uint32_t bisr_remap_sig_dsp_ram_g0: 28;
            __IO uint32_t bisr_load_fuse_dsp_ram_g0: 1;
            __I uint32_t RESERVED_0: 3;
        } BITS_AE0;
    } u_AE0;

    /* 0x0AE4       0x400e_0ae4
        27:0    R/W    bisr_remap_sig_dsp_ram_g1                       7'h0
        28      R/W    bisr_load_fuse_dsp_ram_g1                       1'h0
        31:29   R      RSVD                                            3'h0
    */
    union
    {
        __IO uint32_t REG_DSP_RAM_BISR_REMAP_1;
        struct
        {
            __IO uint32_t bisr_remap_sig_dsp_ram_g1: 28;
            __IO uint32_t bisr_load_fuse_dsp_ram_g1: 1;
            __I uint32_t RESERVED_0: 3;
        } BITS_AE4;
    } u_AE4;

    /* 0x0AE8       0x400e_0ae8
        27:0    R/W    bisr_remap_sig_dsp_ram_g2                       7'h0
        28      R/W    bisr_load_fuse_dsp_ram_g2                       1'h0
        31:29   R      RSVD                                            3'h0
    */
    union
    {
        __IO uint32_t REG_DSP_RAM_BISR_REMAP_2;
        struct
        {
            __IO uint32_t bisr_remap_sig_dsp_ram_g2: 28;
            __IO uint32_t bisr_load_fuse_dsp_ram_g2: 1;
            __I uint32_t RESERVED_0: 3;
        } BITS_AE8;
    } u_AE8;

    /* 0x0AEC       0x400e_0aec
        27:0    R/W    bisr_remap_sig_dsp_ram_g3                       7'h0
        28      R/W    bisr_load_fuse_dsp_ram_g3                       1'h0
        31:29   R      RSVD                                            3'h0
    */
    union
    {
        __IO uint32_t REG_DSP_RAM_BISR_REMAP_3;
        struct
        {
            __IO uint32_t bisr_remap_sig_dsp_ram_g3: 28;
            __IO uint32_t bisr_load_fuse_dsp_ram_g3: 1;
            __I uint32_t RESERVED_0: 3;
        } BITS_AEC;
    } u_AEC;

} KM4_SoC_VENDOR_REG_TypeDef;

/* ======================================================= */
/* ================                      ICG                     ================ */
/* ======================================================= */

/**
  * @brief cache for flash
  */
typedef struct
{
    __IO uint32_t CTRL0;            /*!< ICG cells control address register0, Address Offset: 0x00*/
    __IO uint32_t CTRL1;            /*!< ICG cells control address register1, Address Offset: 0x04*/
    __IO uint32_t CACHE_RAM_CTRL;   /*!< icache twoway control, Address Offset: 0x08*/
} ICG_TypeDef;

/* ======================================================= */
/* ================                      CACHE                     ================ */
/* ======================================================= */

/**
  * @brief cache for flash
  */
typedef struct
{
    __IO uint32_t CACHE_ENABLE;          /*!< SPIC cache Enable Register, Address Offset: 0x00*/
    __IO uint32_t FLUSH;                 /*!< Cache Flush register, Address Offset: 0x04*/
    __IO uint32_t INTR;                  /*!< Cache Interrupt register, Address Offset: 0x08*/
    __IO uint32_t RST_CNT;           /*!< Cache Reset Counter register, Address Offset: 0x0C*/
    __IO uint32_t RD_EVT_CNT;        /*!< Cache Read Event Counter register, Address Offset: 0x10*/
    __IO uint32_t HIT_EVT_CNT;       /*!< Cache HIT Event Counter register, Address Offset: 0x14*/
    __IO uint32_t HIT_LSTW_EVT_CNT;  /*!< Cache Hit lastway event counter register, Offset: 0x18*/
    __IO uint32_t RD_PND_CNT;        /*!< Cache Read pending counter register, Offset: 0x1c*/
} CACHE_TypeDef;

/* ================================================================================ */
/* ================                      SPIC                      ================ */
/* ================================================================================ */
typedef struct
{
    __IO uint32_t CTRLR0;               /*!< Control reg 0,                         offset: 0x000 */
    __IO uint32_t RX_NDF;               /*!< User mode rx data data frame counter,  offset: 0x004 */
    __IO uint32_t SSIENR;               /*!< Enable reg,                            offset: 0x008 */
    __IO uint32_t MWCR;                 /*!< N/A,                                   offset: 0x00C */
    __IO uint32_t SER;                  /*!< Slave enable reg,                      offset: 0x010 */
    __IO uint32_t BAUDR;                /*!< Baudrate select reg,                   offset: 0x014 */
    __IO uint32_t TXFTLR;               /*!< Tx FIFO threshold level,               offset: 0x018 */
    __IO uint32_t RXFTLR;               /*!< Rx FIFO threshold level,               offset: 0x01C */
    __IO uint32_t TXFLR;                /*!< Tx FIFO level reg,                     offset: 0x020 */
    __IO uint32_t RXFLR;                /*!< Rx FIFO level reg,                     offset: 0x024 */
    __IO uint32_t SR;                   /*!< Status reg,                            offset: 0x028 */
    __IO uint32_t IMR;                  /*!< Interrupt mask reg,                    offset: 0x02C */
    __IO uint32_t ISR;                  /*!< Interrupt status reg,                  offset: 0x030 */
    __IO uint32_t RISR;                 /*!< Raw interrupt status reg,              offset: 0x034 */
    __IO uint32_t TXOICR;               /*!< Tx FIFO overflow interrupt clear reg,  offset: 0x038 */
    __IO uint32_t RXOICR;               /*!< Rx FIFO overflow interrupt clear reg,  offset: 0x03C */
    __IO uint32_t RXUICR;               /*!< Rx FIFO underflow interrupt clear reg, offset: 0x040 */
    __IO uint32_t MSTICR;               /*!< Master error interrupt clear reg,      offset: 0x044 */
    __IO uint32_t ICR;                  /*!< Interrupt clear reg,                   offset: 0x048 */
    __IO uint32_t DMACR;                /*!< DMA control reg,                       offset: 0x04C */
    __IO uint32_t DMATDLR;              /*!< DMA transimit data level reg,          offset: 0x050 */
    __IO uint32_t DMARDLR;              /*!< DMA revceive data level reg,           offset: 0x054 */
    __IO uint32_t IDR;                  /*!< Identiation reg,                       offset: 0x058 */
    __IO uint32_t SPIC_VERSION;         /*!< Version ID reg,                        offset: 0x05C */
    union
    {
        __IO uint8_t  BYTE;
        __IO uint16_t HALF;
        __IO uint32_t WORD;
    } DR[16];                           /*!< Data reg,                              offset: 0x060 */
    __IO uint32_t DM_DR[16];            /*!< Data mask data register,               offset: 0x0A0 */
    __IO uint32_t READ_FAST_SINGLE;     /*!< Fast read data cmd of flash,           offset: 0x0E0 */
    __IO uint32_t READ_DUAL_DATA;       /*!< Dual output read cmd of flash,         offset: 0x0E4 */
    __IO uint32_t READ_DUAL_ADDR_DATA;  /*!< Dual I/O read cmd of flash,            offset: 0x0E8 */
    __IO uint32_t READ_QUAD_DATA;       /*!< Quad output read cmd of flash,         offset: 0x0EC */
    __IO uint32_t READ_QUAD_ADDR_DATA;  /*!< Quad I/O read cmd of flash,            offset: 0x0F0 */
    __IO uint32_t WRITE_SINGLE;         /*!< Page program cmd of flash,             offset: 0x0F4 */
    __IO uint32_t WRITE_DUAL_DATA;      /*!< Dual data input program cmd of flash,  offset: 0x0F8 */
    __IO uint32_t WRITE_DUAL_ADDR_DATA; /*!< Dual addr & data program cmd of flash, offset: 0x0FC */
    __IO uint32_t WRITE_QUAD_DATA;      /*!< Quad data input program cmd of flash,  offset: 0x100 */
    __IO uint32_t WRITE_QUAD_ADDR_DATA; /*!< Quad addr & data program cmd of flash, offset: 0x104 */
    __IO uint32_t WRITE_ENABLE;         /*!< Write enabe cmd of flash,              offset: 0x108 */
    __IO uint32_t READ_STATUS;          /*!< Read status cmd of flash,              offset: 0x10C */
    __IO uint32_t CTRLR2;               /*!< Control reg 2,                         offset: 0x110 */
    __IO uint32_t FBAUDR;               /*!< Fast baudrate select,                  offset: 0x114 */
    __IO uint32_t USER_LENGTH;          /*!< Addr length reg,                       offset: 0x118 */
    __IO uint32_t AUTO_LENGTH;          /*!< Auto addr length reg,                  offset: 0x11C */
    __IO uint32_t VALID_CMD;            /*!< Valid cmd reg,                         offset: 0x120 */
    __IO uint32_t FLASH_SIZE;           /*!< Flash size reg,                        offset: 0x124 */
    __IO uint32_t FLUSH_FIFO;           /*!< Flush FIFO reg,                        offset: 0x128 */
    __IO uint32_t DUM_BYTE;             /*!< Dummy byte value,                      offset: 0x12C */
    __IO uint32_t TX_NDF;               /*!< Tx NDF,                                offset: 0x130 */
    __IO uint32_t DEVICE_INFO;          /*!< Device info,                           offset: 0x134 */
    __IO uint32_t TPR0;                 /*!< Timing parameters,                     offset: 0x138 */
    __IO uint32_t AUTO_LENGTH2;         /*!< Auto addr length reg 2,                offset: 0x13C */
} SPIC_TypeDef;

/* ================================================================================ */
/* ================                      PSRAM                     ================ */
/* ================================================================================ */
typedef struct
{
    __IO uint32_t CCR;           /*!< Configuration control register,          Address offset: 0x000 */
    __IO uint32_t DCR;           /*!< Device configuration control register,   Address offset: 0x004 */
    __IO uint32_t IOCR0;         /*!< I/O configuration control regsiter0,     Address offset: 0x008 */
    __IO uint32_t CSR;           /*!< Controller status register,              Address offset: 0x00c */
    __IO uint32_t DRR;           /*!< Device refresh/power-up register,        Address offset: 0x010 */
    __IO uint32_t RSVD0[4];      /*!< Reserved 0,                              Address offset: 0x014 */
    __IO uint32_t CMD_DPIN_NDGE; /*!< Device cmd/addr pin register (NEDGE),    Address offset: 0x024 */
    __IO uint32_t CMD_DPIN;      /*!< Device cmd/addr pin regsiter (PEDGE),    Address offset: 0x028 */
    __IO uint32_t CR_TDPIN;      /*!< Tie DPIN register (sw ctrl dfi_reset_n), Address offset: 0x02c */
    __IO uint32_t MR_INFO;       /*!< Mode latency information regster,        Address offset: 0x030 */
    __IO uint32_t MR0;           /*!< Device CR0 register,                     Address offset: 0x034 */
    __IO uint32_t MR1;           /*!< Device CR1 register,                     Address offset: 0x038 */
    __IO uint32_t RSVD1[9];      /*!< Reserved 1,                              Address offset: 0x03c */
    __IO uint32_t DPDRI;         /*!< DPIN data index register,                Address offset: 0x060 */
    __IO uint32_t DPDR;          /*!< DPIN data register,                      Address offset: 0x064 */
    __IO uint32_t RSVD2[35];     /*!< Reserved 2,                              Address offset: 0x068 */
    __IO uint32_t PCTL_SVN_ID;   /*!< PSRAM_LPC_CTRL version number,           Address offset: 0x0f4 */
    __IO uint32_t PCTL_IDR;      /*!< PSRAM_LPC_CTRL identification register,  Address offset: 0x0f8 */
    __IO uint32_t RSVD3[193];    /*!< Reserved 3,                              Address offset: 0x0fc */
    __IO uint32_t USER0_INDEX;   /*!< User extended index,                     Address offset: 0x400 */
    __IO uint32_t USER0_DATA;    /*!< User extended data,                      Address offset: 0x404 */
} PSRAMC_TypeDef;

/** @} */ /* End of group RTL876X_Peripheral_Registers_Structures */

/*============================================================================*
 *                              Macros
 *============================================================================*/

/** @defgroup RTL876X_Exported_Macros RTL876X  Exported Macros
  * @brief
  * @{
  */
/* ================================================================================ */
/* ================              Peripheral memory map             ================ */
/* ================================================================================ */
#define SYSTEM_REG_BASE                 0x40000000UL
#define PERIBLKCTRL_PF_CLK_REG_BASE     0x400E2000UL
#define PERIBLKCTRL_PERICLK_REG_BASE0   0x400E2100UL
#define PERIBLKCTRL_PERICLK_REG_BASE1   0x400E2900UL
#define PERIBLKCTRL_INTERNAL_REG_BASE   0x400E2E00UL
#define PINMUX_REG_BASE                 0x400E2400UL
#define PINMUX_M0_REG_BASE              0x40010400UL
#define PINMUX_CODEC_REG_BASE           0x400E2A00UL

/*****************************  AON Register table    ****************************/
/*********** Reference: RLE1155_AON_Autogen_table_2021_1208_CFCHIN_2.xlsx FY******/
/* non-secure aon */
#define RTC_REG_BASE                    0x40001800UL
#define LPC_REG_BASE                    0x40001850UL
#define LPC0_REG_BASE                   0x40001850UL
#define LPC1_REG_BASE                   0x40001858UL
#define WDT_REG_BASE                    0x40001880UL
#define PAD_REG_BASE                    0x40001900UL
#define QUAD_DECODER_REG_BASE           0x40001BD0UL
#define PAD_STS_REG_BASE                0x40001AA0UL
#define M4_APP_REG_BASE                 0x40001AE0UL
#define AON_WDG_REG_BASE                0x40001B60UL
#define AUXADC_REG_BASE                 0x40001B90UL
/* ================================================================================ */
/* ========= Refence: Bee3Pro_AddrMap_IRQs_DmaPorts_20220413v0.xlsx   ============ */
/* ================================================================================ */
//#define AON_REG_BASE                    0x40000000UL
#define AON_CODEC_BASE                  0x40001D40UL
#define RXI300_REG_BASE                 0x40002000UL
#define IPC0_REG_BASE                   0x40004000UL
#define IPC1_REG_BASE                   0x40004400UL
#define IPC2_REG_BASE                   0x40004800UL
#define IPC3_REG_BASE                   0x40004C00UL
#define IPC4_REG_BASE                   0x40005000UL
#define IPC5_REG_BASE                   0x40005400UL
#define HW_MUTEX_REG_BASE               0x40005800UL
#define UART7_REG_BASE                  0x40005C00UL
#define SOC_VENDOR0_REG_BASE            0x40006000UL
#define SOC_VENDOR1_REG_BASE            0x40010000UL
#define UART0_REG_BASE                  0x40011000UL
#define UART1_REG_BASE                  0x40011400UL
#define TIMER_A_REG_BASE                0x40012000UL
#define RXI350_DMAC0_CFG_REG_BASE       0x40016000UL
#define AUX_ADC0_REG_BASE               0x40020000UL
#define SPI0_REG_BASE                   0x40021000UL
#define SPI1_REG_BASE                   0x40021400UL
#define SPI0_SLAVE_REG_BASE             0x40021800UL
#define I2C0_REG_BASE                   0x40021C00UL
#define I2C1_REG_BASE                   0x40022000UL
#define I2C2_REG_BASE                   0x40022400UL
#define UART2_REG_BASE                  0x40022800UL
#define UART3_REG_BASE                  0x40022C00UL
#define UART4_REG_BASE                  0x40023000UL
#define UART5_REG_BASE                  0x40023400UL
#define ENHANCED_TIMER_REG_BASE         0x40023800UL
#define TIMER_B_REG_BASE                0x40024000UL
#define RXI350_DMAC1_CFG_REG_BASE       0x40025000UL
#define AUX_ADC1_REG_BASE               0x40026000UL
#define BLUEWIZ_REG_BASE                0x40050000UL
#define BT_VENDOR_REG_BASE              0x40058000UL
#define IR_REG_BASE                     0x40060000UL
#define I2C3_REG_BASE                   0x40061000UL
#define ISO7816_REG_BASE                0x40061400UL
#define RXI350_DMAC2_CFG_REG_BASE       0x40062000UL
#define MAE_REG_BASE                    0x40063000UL
#define PUBLIC_KEY_ENGINE_REG_BASE      0x40080000UL
#define FLASH_SEC0_REG_BASE             0x400C0000UL
#define FLASH_SEC1_REG_BASE             0x400C0800UL
#define AES_REG_BASE                    0x400C1000UL
#define SHA3_REG_BASE                   0x400C2000UL
#define TRNG_REG_BASE                   0x400C2400UL
#define OTP_CONTROLLER_REG_BASE         0x400C2800UL
#define SHA2_CTRL_REG_BASE              0x400C3000UL
#define SHA2_DMA_REG_BASE               0x400C4000UL
#define GPIOA_REG_BASE                  0x400D0000UL
#define GPIOB_REG_BASE                  0x400D1000UL
#define GPIOC_REG_BASE                  0x400D2000UL
#define GPIOD_REG_BASE                  0x400D3000UL
#define SOC_VENDOR2_REG_BASE            0x400E0000UL

#define QDEC_REG_BASE                   0x400E1000UL
#define KEYSCAN_REG_BASE                0x400E1800UL
#define PERI_ON_REG_BASE                0x400E2000UL
#define GPIOA_DEB_REG_BASE              0x400E2188UL
#define GPIOB_DEB_REG_BASE              0x400E219CUL
#define GPIOC_DEB_REG_BASE              0x400E21B0UL
#define GPIOD_DEB_REG_BASE              0x400E21C4UL
#define TIMER_B_PWM_CR_REG_BASE         0x400E2260UL
#define ENHANCED_TIMER_PWM_REG_BASE     0x400E2270UL
#define SPIC0_REG_BASE                  0x400F0000UL
#define SPIC1_REG_BASE                  0x400F4000UL
#define SPIC2_REG_BASE                  0x400F8000UL
#define SPIC3_REG_BASE                  0x400FC000UL
#define USB_OTG_CFG_REG_REG_BASE        0x40100000UL
#define GPU_CFG_REG_BASE                0x40140000UL
#define SDIO_HOST0_CFG_REG_BASE         0x40180000UL
#define SDIO_HOST1_CFG_REG_BASE         0x40182000UL
#define SPI2_HS_REG_BASE                0x40200000UL
#define SPI3_HS_REG_BASE                0x40201000UL
#define I2S0_REG_BASE                   0x40300000UL
#define I2S1_REG_BASE                   0x40304000UL
#define I2S2_REG_BASE                   0x40308000UL
#define I2S3_REG_BASE                   0x4030C000UL
#define SPI_CODEC_REG_BASE              0x40400000UL
#define H2D_D2H_REG_BASE                0x40404000UL
#define TIMER_C_REG_BASE                0x40405000UL
#define UART6_REG_BASE                  0x40406000UL
#define DSP_PERIPHERAL_BASE             0x40407000UL
#define PLIC_REG_BASE                   0x40500000UL
#define SPI2_REG_BASE                   0x40600000UL
#define SPI3_REG_BASE                   0x40601000UL
#define MIPI_REG_BASE                   0x40602000UL
#define DISPLAY_CTRL_REG_BASE           0x40603000UL
#define ERR_CORR_CODE_REG_BASE          0x40604000UL
#define VADBUF_REG_BASE                 0x40700000UL

#define GDMA0_CHANNEL_REG_BASE          RXI350_DMAC0_CFG_REG_BASE
#define GDMA0_REG_BASE                  (GDMA0_CHANNEL_REG_BASE + 0x02c0)
#define GDMA0_Channel0_BASE             (GDMA0_CHANNEL_REG_BASE + 0x0000)
#define GDMA0_Channel1_BASE             (GDMA0_CHANNEL_REG_BASE + 0x0058)
#define GDMA0_Channel2_BASE             (GDMA0_CHANNEL_REG_BASE + 0x00b0)

#define GDMA1_CHANNEL_REG_BASE          RXI350_DMAC1_CFG_REG_BASE
#define GDMA1_REG_BASE                  (GDMA1_CHANNEL_REG_BASE + 0x02c0)
#define GDMA1_Channel0_BASE             (GDMA1_CHANNEL_REG_BASE + 0x0000)
#define GDMA1_Channel1_BASE             (GDMA1_CHANNEL_REG_BASE + 0x0058)
#define GDMA1_Channel2_BASE             (GDMA1_CHANNEL_REG_BASE + 0x00b0)
#define GDMA1_Channel3_BASE             (GDMA1_CHANNEL_REG_BASE + 0x0108)
#define GDMA1_Channel4_BASE             (GDMA1_CHANNEL_REG_BASE + 0x0160)
#define GDMA1_Channel5_BASE             (GDMA1_CHANNEL_REG_BASE + 0x01b8)
#define GDMA1_Channel6_BASE             (GDMA1_CHANNEL_REG_BASE + 0x0210)
#define GDMA1_Channel7_BASE             (GDMA1_CHANNEL_REG_BASE + 0x0268)

#define GDMA2_CHANNEL_REG_BASE          RXI350_DMAC2_CFG_REG_BASE
#define GDMA2_REG_BASE                  (GDMA2_CHANNEL_REG_BASE + 0x02c0)
#define GDMA2_Channel0_BASE             (GDMA2_CHANNEL_REG_BASE + 0x0000)
#define GDMA2_Channel1_BASE             (GDMA2_CHANNEL_REG_BASE + 0x0058)
#define GDMA2_Channel2_BASE             (GDMA2_CHANNEL_REG_BASE + 0x00b0)
#define GDMA2_Channel3_BASE             (GDMA2_CHANNEL_REG_BASE + 0x0108)
#define GDMA2_Channel4_BASE             (GDMA2_CHANNEL_REG_BASE + 0x0160)
#define GDMA2_Channel5_BASE             (GDMA2_CHANNEL_REG_BASE + 0x01b8)
#define GDMA2_Channel6_BASE             (GDMA2_CHANNEL_REG_BASE + 0x0210)
#define GDMA2_Channel7_BASE             (GDMA2_CHANNEL_REG_BASE + 0x0268)
#define GDMA2_Channel8_BASE             (GDMA2_CHANNEL_REG_BASE + 0x0400)
#define GDMA2_Channel9_BASE             (GDMA2_CHANNEL_REG_BASE + 0x0458)
#define GDMA2_Channel10_BASE            (GDMA2_CHANNEL_REG_BASE + 0x04b0)
#define GDMA2_Channel11_BASE            (GDMA2_CHANNEL_REG_BASE + 0x0508)
#define GDMA2_Channel12_BASE            (GDMA2_CHANNEL_REG_BASE + 0x0560)
#define GDMA2_Channel13_BASE            (GDMA2_CHANNEL_REG_BASE + 0x05b8)
#define GDMA2_Channel14_BASE            (GDMA2_CHANNEL_REG_BASE + 0x0610)
#define GDMA2_Channel15_BASE            (GDMA2_CHANNEL_REG_BASE + 0x0668)

#define TIMER_B0_REG_BASE               (TIMER_B_REG_BASE + 0x0000)
#define TIMER_B1_REG_BASE               (TIMER_B_REG_BASE + 0x0014)
#define TIMER_B2_REG_BASE               (TIMER_B_REG_BASE + 0x0028)
#define TIMER_B3_REG_BASE               (TIMER_B_REG_BASE + 0x003c)

#define TIMER_B0_PWM_REG_BASE           (TIMER_B_PWM_CR_REG_BASE + 0x0000)
#define TIMER_B1_PWM_REG_BASE           (TIMER_B_PWM_CR_REG_BASE + 0x0004)
#define TIMER_B2_PWM_REG_BASE           (TIMER_B_PWM_CR_REG_BASE + 0x0008)
#define TIMER_B3_PWM_REG_BASE           (TIMER_B_PWM_CR_REG_BASE + 0x000c)

#define TIMER_C0_REG_BASE               (TIMER_C_REG_BASE + 0x0000)
#define TIMER_C1_REG_BASE               (TIMER_C_REG_BASE + 0x0014)
#define TIMER_C2_REG_BASE               (TIMER_C_REG_BASE + 0x0028)
#define TIMER_C3_REG_BASE               (TIMER_C_REG_BASE + 0x003c)
#define TIMER_C4_REG_BASE               (TIMER_C_REG_BASE + 0x0050)
#define TIMER_C5_REG_BASE               (TIMER_C_REG_BASE + 0x0064)

#define ENHANCED_TIMER0_REG_BASE        (ENHANCED_TIMER_REG_BASE + 0x0000)
#define ENHANCED_TIMER1_REG_BASE        (ENHANCED_TIMER_REG_BASE + 0x0024)
#define ENHANCED_TIMER2_REG_BASE        (ENHANCED_TIMER_REG_BASE + 0x0048)
#define ENHANCED_TIMER3_REG_BASE        (ENHANCED_TIMER_REG_BASE + 0x006c)
#define ENHANCED_TIMER4_REG_BASE        (ENHANCED_TIMER_REG_BASE + 0x0090)
#define ENHANCED_TIMER5_REG_BASE        (ENHANCED_TIMER_REG_BASE + 0x00b4)
#define ENHANCED_TIMER6_REG_BASE        (ENHANCED_TIMER_REG_BASE + 0x00d8)
#define ENHANCED_TIMER7_REG_BASE        (ENHANCED_TIMER_REG_BASE + 0x00fc)
#define ENHTIM_SHARE_REG_BASE           (ENHANCED_TIMER_REG_BASE + 0x0120) //0x40023920UL
#define ENHTIM0_PWM_REG_BASE               (ENHANCED_TIMER_PWM_REG_BASE + 0x0000)
#define ENHTIM1_PWM_REG_BASE               (ENHANCED_TIMER_PWM_REG_BASE + 0x0004)
#define ENHTIM2_PWM_REG_BASE               (ENHANCED_TIMER_PWM_REG_BASE + 0x0008)
#define ENHTIM3_PWM_REG_BASE               (ENHANCED_TIMER_PWM_REG_BASE + 0x000C)
#define ENHTIM4_PWM_REG_BASE               (ENHANCED_TIMER_PWM_REG_BASE + 0x0010)
#define ENHTIM5_PWM_REG_BASE               (ENHANCED_TIMER_PWM_REG_BASE + 0x0014)
#define ENHTIM6_PWM_REG_BASE               (ENHANCED_TIMER_PWM_REG_BASE + 0x0018)
#define ENHTIM7_PWM_REG_BASE               (ENHANCED_TIMER_PWM_REG_BASE + 0x001C)

#define KM4_WDG_REG_BASE                SOC_VENDOR2_REG_BASE

#define BT_BB_REG_BASE                  0x40050000UL // actually used: #define BB_BASE_ADDR 0x40050000
#define BT_LE_REG_BASE                  0x40051000UL

/****************************End of Secure register base*****************************/

/* ================================================================================ */
/* ================       Non-Secure Peripheral declaration        ================ */
/* ================================================================================ */
/** @brief System */
#define KM4_SoC_VENDOR                  ((KM4_SoC_VENDOR_REG_TypeDef    *) SOC_VENDOR2_REG_BASE)
#define PERIBLKCTRL_PF_CLK              ((PERI_BLKCTRL_PF_CLK_TypeDef   *) PERIBLKCTRL_PF_CLK_REG_BASE)
#define PERIBLKCTRL_PERI_CLK            ((PERI_BLKCTRL_PERI_CLK_TypeDef *) PERIBLKCTRL_PERICLK_REG_BASE0)
#define PERIBLKCTRL_PERI_CLK1           ((PERI_BLKCTRL_PERI_CLK1_TypeDef *) PERIBLKCTRL_PERICLK_REG_BASE1)
#define PERIBLKCTRL_INTERNAL            ((PERI_BLKCTRL_INTERNAL_TypeDef *) PERIBLKCTRL_INTERNAL_REG_BASE)
#define AON_QDEC                        ((AON_QDEC_TypeDef        *)  QUAD_DECODER_REG_BASE)

/** @brief IO */
#define WDG                             ((KM4_WDG_TypeDef          *) KM4_WDG_REG_BASE)
#define AON_WDG                         ((AON_WDG_TypeDef          *) AON_WDG_REG_BASE)
#define HWAES                           ((HW_AES_TypeDef           *) AES_REG_BASE)
#define HWSHA2                          ((HW_SHA256_TypeDef        *) SHA2_REG_BASE)
#define HWSHA3                          ((HW_SHA3_TypeDef          *) SHA3_REG_BASE)
//#define ICG                             ((ICG_TypeDef              *) ICG_REG_BASE)
//#define RAN_GEN                         ((RAN_GEN_TypeDef          *) RANDOM_GEN_REG_BASE)
#define SPIC0                           ((SPIC_TypeDef             *) SPIC0_REG_BASE)
#define SPIC1                           ((SPIC_TypeDef             *) SPIC1_REG_BASE)
#define SPIC2                           ((SPIC_TypeDef             *) SPIC2_REG_BASE)
#define SPIC3                           ((SPIC_TypeDef             *) SPIC3_REG_BASE)
#define PSRAMC                          ((PSRAMC_TypeDef           *) PSRAM_REG_BASE)
#define ERR_CC                          ((ECC_Typedef              *) ERR_CORR_CODE_REG_BASE)
/***********************************End of Non-Secure************************************/

#define PERI_REG_ADDR_TO_SECURE(addr)        ((uint32_t)addr | BIT28)
#define PERI_REG_ADDR_TO_NONSECURE(addr)     ((uint32_t)addr & ~BIT28)

/* ================================================================================ */
/* ================                   Vendor macros                ================ */
/* ================================================================================ */
#define LITTLE_ENDIAN                        0
#define BIG_ENDIAN                           1
#define SYSTEM_ENDIAN                        LITTLE_ENDIAN

#define SWAP32(x) ((uint32_t)(                         \
                                                       (((uint32_t)(x) & (uint32_t)0x000000ff) << 24) |            \
                                                       (((uint32_t)(x) & (uint32_t)0x0000ff00) <<  8) |            \
                                                       (((uint32_t)(x) & (uint32_t)0x00ff0000) >>  8) |            \
                                                       (((uint32_t)(x) & (uint32_t)0xff000000) >> 24)))

#define WAP16(x) ((uint16_t)(                         \
                                                      (((uint16_t)(x) & (uint16_t)0x00ff) <<  8) |            \
                                                      (((uint16_t)(x) & (uint16_t)0xff00) >>  8)))

#if SYSTEM_ENDIAN == LITTLE_ENDIAN
#ifndef rtk_le16_to_cpu
#define rtk_cpu_to_le32(x)      ((uint32_t)(x))
#define rtk_le32_to_cpu(x)      ((uint32_t)(x))
#define rtk_cpu_to_le16(x)      ((uint16_t)(x))
#define rtk_le16_to_cpu(x)      ((uint16_t)(x))
#define rtk_cpu_to_be32(x)      SWAP32((x))
#define rtk_be32_to_cpu(x)      SWAP32((x))
#define rtk_cpu_to_be16(x)      WAP16((x))
#define rtk_be16_to_cpu(x)      WAP16((x))
#endif

#elif SYSTEM_ENDIAN == BIG_ENDIAN
#ifndef rtk_le16_to_cpu
#define rtk_cpu_to_le32(x)      SWAP32((x))
#define rtk_le32_to_cpu(x)      SWAP32((x))
#define rtk_cpu_to_le16(x)      WAP16((x))
#define rtk_le16_to_cpu(x)      WAP16((x))
#define rtk_cpu_to_be32(x)      ((uint32_t)(x))
#define rtk_be32_to_cpu(x)      ((uint32_t)(x))
#define rtk_cpu_to_be16(x)      ((uint16_t)(x))
#define rtk_be16_to_cpu(x)      ((uint16_t)(x))
#endif
#endif

#define HAL_READ32(base, addr)            \
    rtk_le32_to_cpu(*((volatile uint32_t *)(base + addr)))

#define HAL_WRITE32(base, addr, value32)  \
    ((*((volatile uint32_t *)(base + addr))) = rtk_cpu_to_le32(value32))

#define HAL_UPDATE32(addr, mask, value32)  \
    HAL_WRITE32(0, addr, (HAL_READ32(0, addr) & ~(mask)) | ((value32) & (mask)))

#define HAL_READ16(base, addr)            \
    rtk_le16_to_cpu(*((volatile uint16_t *)(base + addr)))

#define HAL_WRITE16(base, addr, value)  \
    ((*((volatile uint16_t *)(base + addr))) = rtk_cpu_to_le16(value))

#define HAL_UPDATE16(addr, mask, value16)  \
    HAL_WRITE16(0, addr, (HAL_READ16(0, addr) & ~(mask)) | ((value16) & (mask)))

#define HAL_READ8(base, addr)            \
    (*((volatile uint8_t *)(base + addr)))

#define HAL_WRITE8(base, addr, value)  \
    ((*((volatile uint8_t *)(base + addr))) = value)

#define HAL_UPDATE8(addr, mask, value8)  \
    HAL_WRITE8(0, addr, (HAL_READ8(0, addr) & ~(mask)) | ((value8) & (mask)))

#define BIT0        0x00000001
#define BIT1        0x00000002
#define BIT2        0x00000004
#define BIT3        0x00000008
#define BIT4        0x00000010
#define BIT5        0x00000020
#define BIT6        0x00000040
#define BIT7        0x00000080
#define BIT8        0x00000100
#define BIT9        0x00000200
#define BIT10       0x00000400
#define BIT11       0x00000800
#define BIT12       0x00001000
#define BIT13       0x00002000
#define BIT14       0x00004000
#define BIT15       0x00008000
#define BIT16       0x00010000
#define BIT17       0x00020000
#define BIT18       0x00040000
#define BIT19       0x00080000
#define BIT20       0x00100000
#define BIT21       0x00200000
#define BIT22       0x00400000
#define BIT23       0x00800000
#define BIT24       0x01000000
#define BIT25       0x02000000
#define BIT26       0x04000000
#define BIT27       0x08000000
#define BIT28       0x10000000
#define BIT29       0x20000000
#define BIT30       0x40000000
#define BIT31       0x80000000

#define BIT(_n)     (uint32_t)(1U << (_n))
#define BIT64(_n)   (1ULL << (_n))

/* Uncomment the line below to expanse the "assert_param" macro in the
   Standard Peripheral Library drivers code */
//#define USE_FULL_ASSERT


/** @} */ /* End of group RTL876X_Exported_Macros */


/*============================================================================*
 *                                Functions
 *============================================================================*/
/** @defgroup RTL876X_Exported_Functions RTL876X Sets Exported Functions
    * @brief
    * @{
    */
#ifdef  USE_FULL_ASSERT
/**
  * @brief  The assert_param macro is used for function's parameters check.
  * @param  expr: If expr is false, it calls assert_failed function which reports
  *         the name of the source file and the source line number of the call
  *         that failed. If expr is true, it returns no value.
  * @retval None
  */
#define assert_param(expr) ((expr) ? (void)0 : io_assert_failed((uint8_t *)__FILE__, __LINE__))
void io_assert_failed(uint8_t *file, uint32_t line);
#else
#define assert_param(expr) ((void)0)
#endif /* USE_FULL_ASSERT */


/** @} */ /* End of RTL876X_Exported_Functions */


/** @} */ /* End of group RTL876X */

#ifdef __cplusplus
}
#endif
#endif  /* RTL876X_H */

