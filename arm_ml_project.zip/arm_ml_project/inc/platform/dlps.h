/**
*****************************************************************************************
*     Copyright(c) 2017, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
  * @file    dlps.h
  * @brief   DLPS implementation head file.
  * @author  lory_xu
  * @date    2014-08-05
  * @version v1.0
  * *************************************************************************************
   * @attention
   * <h2><center>&copy; COPYRIGHT 2017 Realtek Semiconductor Corporation</center></h2>
   * *************************************************************************************
  */

/*============================================================================*
 *               Define to prevent recursive inclusion
 *============================================================================*/
#ifndef __DLPS_H
#define __DLPS_H


/*============================================================================*
 *                               Header Files
*============================================================================*/
#include <stdint.h>
#include <stdbool.h>
#include "os_queue.h"
#include "system_rtl876x.h"
#include "rtl876x_aon_reg.h"

#ifdef __cplusplus
extern "C" {
#endif

#define PM_INVALID_WAKEUP_TIME_DIFF 0xffffffff

/** @defgroup DLPS_PLATFORM DLPS Platform
  * @brief Deep low power state support
  * @{
  */

/*============================================================================*
 *                              Types
*============================================================================*/
/** @defgroup DLPS_PLATFORM_Exported_Types DLPS Platform Exported Types
  * @{
  */
typedef enum PMCheckResult
{
    PM_CHECK_PEND               = 0,
    PM_CHECK_FAIL               = 1,
    PM_CHECK_PASS               = 2,
} PMCheckResult;

/** @brief This CB is used for any module which needs to be checked before entering DLPS */
typedef PMCheckResult(*DLPSEnterCheckFunc)();

/** @brief This CB is used for any module which needs to control the hw before entering or after exiting from DLPS */
typedef void (*DLPSHWControlFunc)();

typedef void (*PMFuncToReturn)(void);

typedef void (*PlatformPMScheduleBottomHalfFunc)(void (*)(void));

/*============================================================================*
 *                              Power Manager
*============================================================================*/
typedef enum PMSlave
{
    PM_SLAVE_KM4                = 0,
    PM_SLAVE_KM0                = 1,
    PM_SLAVE_DEF_MAX,
} PMSlave;

typedef enum PMUnitStatus
{
    PM_UNIT_UNKNOWN             = 0,
    PM_UNIT_PEND                = 1,
    PM_UNIT_INACTIVE            = 2,
    PM_UNIT_ACTIVE              = 3,
} PMUnitStatus;

typedef enum PMSystemLevel
{
    PM_SYSTEM_LEVEL_0           = 0,
    PM_SYSTEM_LEVEL_PF          = 1,
    PM_SYSTEM_LEVEL_DEF_MAX,
} PMSystemLevel;

typedef enum
{
    PM_UNIT_BTMAC               = (PM_SYSTEM_LEVEL_0 << 2 | 0),
    PM_UNIT_PLATFORM            = (PM_SYSTEM_LEVEL_PF << 2 | 0),
} PMUnitID;

/*============================================================================*
 *                              Platform Unit
*============================================================================*/

typedef enum
{
    PLATFORM_POWEROFF                       = 0,   /**< Power off */
    PLATFORM_POWERDOWN                      = 1,   /**< Power down */
    PLATFORM_DLPS                           = 2,   /**< DLPS       */
    PLATFORM_ACTIVE                         = 3,   /**< Active     */
    PLATFORM_POWER_MODE_MAX                 = 4
} PlatformPowerMode;

typedef enum
{
    PLATFORM_PM_CHECK                       = 0,
    PLATFORM_PM_STORE                       = 1,
    PLATFORM_PM_ENTER                       = 2,
    PLATFORM_PM_EXIT                        = 3,
    PLATFORM_PM_RESTORE                     = 4,
    PLATFORM_PM_PEND                        = 5,
    PLATFORM_PM_STAGE_MAX                   = 6,
} PlatformPMStage;

typedef enum
{
    PLATFORM_PM_WAKEUP_UNKNOWN              = 0x00000000,
    PLATFORM_PM_WAKEUP_PRE_SYSTEM_LEVEL     = 0x00000001,

    PLATFORM_PM_WAKEUP_DEF_MAX              = 0xFFFFFFFF,
} PlatformWakeupReason;

typedef enum
{
    PLATFORM_PM_ERROR_UNKNOWN               = 0x0,
    PLATFORM_PM_ERROR_POWER_MODE            = 0x1,
    PLATFORM_PM_ERROR_DISABLE_DLPS_TIME     = 0x2,
    PLATFORM_PM_ERROR_32K_CHECK_LOCK        = 0x3,
    PLATFORM_PM_ERROR_LOG_DMA_NOT_IDLE      = 0x4,
    PLATFORM_PM_ERROR_LOG_BUFFER_NOT_EMPTY  = 0x5,
    PLATFORM_PM_ERROR_CALLBACK_CHECK        = 0x6,
    PLATFORM_PM_ERROR_INTERRUPT_OCCURRED    = 0x7,
    PLATFORM_PM_ERROR_WAKEUP_TIME           = 0x8,
    PLATFORM_PM_ERROR_OCCUPIED_TIME         = 0x9,
    PLATFORM_PM_ERROR_MAILBOX               = 0xA,
} PlatformPowerModeErrorCode;

typedef struct _PlatformPMSystem
{
    PlatformPowerMode power_mode;

    PlatformWakeupReason wakeup_reason;
    PlatformPowerModeErrorCode error_code;
    uint32_t *refuse_reason;

    uint32_t wakeup_count;
    uint32_t allow_sleep_count;
    uint32_t last_wakeup_clk;
    uint32_t last_sleep_clk;
    uint32_t total_wakeup_time;
    uint32_t total_sleep_time;

    uint32_t stage_time[PLATFORM_PM_STAGE_MAX];
    uint32_t minimum_sleep_time;
    uint32_t learning_guard_time;

    T_OS_QUEUE callback_func_queue[PLATFORM_PM_STAGE_MAX];

    PlatformPMScheduleBottomHalfFunc schedule_bottom_half_callback;
} PlatformPMSystem;

typedef union _PlatformPMFeatureConfig
{
    uint8_t value[1];
    struct
    {
        uint8_t platform_check_dbg:                 1;
        uint8_t platform_enter_dbg:                 1;
        uint8_t platform_exit_dbg:                  1;
        uint8_t platform_stage_time:                1;
        uint8_t platform_statistics:                1;
        uint8_t rsvd1:                              3;
    };
} PlatformPMFeatureConfig;

/*============================================================================*
 *                             KM0 Unit
*============================================================================*/

typedef enum PlatformPowerMode_KM0
{
    PLATFORM_SHUTDOWN_KM0                       = 0,
    PLATFORM_POWERDOWN_KM0                      = 1,
    PLATFORM_DLPS_KM0                           = 2,
    PLATFORM_ACTIVE_KM0                         = 3,
    PLATFORM_POWER_MODE_MAX_KM0                 = 4,
} PlatformPowerMode_KM0;

typedef enum
{
    PLATFORM_PM_CHECK_KM0                       = 0,
    PLATFORM_PM_STORE_KM0                       = 1,
    PLATFORM_PM_ENTER_KM0                       = 2,
    PLATFORM_PM_EXIT_KM0                        = 3,
    PLATFORM_PM_RESTORE_KM0                     = 4,
    PLATFORM_PM_PEND_KM0                        = 5,
    PLATFORM_PM_STAGE_MAX_KM0                   = 6,
} PlatformPMStage_KM0;

typedef enum
{
    PLATFORM_PM_WAKEUP_UNKNOWN_KM0              = 0x00000000,
    PLATFORM_PM_WAKEUP_PRE_SYSTEM_LEVEL_KM0     = 0x00000001,

    PLATFORM_PM_WAKEUP_DEF_MAX_KM0              = 0xFFFFFFFF,
} PlatformWakeupReason_KM0;

typedef enum
{
    PLATFORM_PM_ERROR_UNKNOWN_KM0               = 0x0,
    PLATFORM_PM_ERROR_POWER_MODE_KM0            = 0x1,
    PLATFORM_PM_ERROR_DISABLE_DLPS_TIME_KM0     = 0x2,
    PLATFORM_PM_ERROR_32K_CHECK_LOCK_KM0        = 0x3,
    PLATFORM_PM_ERROR_LOG_DMA_NOT_IDLE_KM0      = 0x4,
    PLATFORM_PM_ERROR_LOG_BUFFER_NOT_EMPTY_KM0  = 0x5,
    PLATFORM_PM_ERROR_CALLBACK_CHECK_KM0        = 0x6,
    PLATFORM_PM_ERROR_INTERRUPT_OCCURRED_KM0    = 0x7,
    PLATFORM_PM_ERROR_WAKEUP_TIME_KM0           = 0x8,
    PLATFORM_PM_ERROR_OCCUPIED_TIME_KM0         = 0x9,
    PLATFORM_PM_ERROR_MAILBOX_KM0               = 0xA,
} PlatformPowerModeErrorCode_KM0;

typedef struct _PlatformPMSystem_KM0
{
    PlatformPowerMode_KM0 power_mode;

    PlatformWakeupReason_KM0 wakeup_reason;
    PlatformPowerModeErrorCode_KM0 error_code;
    uint32_t *refuse_reason;

    uint32_t wakeup_count;
    uint32_t allow_sleep_count;
    uint32_t last_wakeup_clk;
    uint32_t last_sleep_clk;
    uint32_t total_wakeup_time;
    uint32_t total_sleep_time;

    uint32_t stage_time[PLATFORM_PM_STAGE_MAX_KM0];
    uint32_t minimum_sleep_time;
    uint32_t learning_guard_time;

    T_OS_QUEUE callback_func_queue[PLATFORM_PM_STAGE_MAX_KM0];

    PlatformPMScheduleBottomHalfFunc schedule_bottom_half_callback;
} PlatformPMSystem_KM0;

typedef union _PlatformPMFeatureConfig_KM0
{
    uint8_t value[1];
    struct
    {
        uint8_t platform_check_dbg:                 1;
        uint8_t platform_enter_dbg:                 1;
        uint8_t platform_exit_dbg:                  1;
        uint8_t platform_stage_time:                1;
        uint8_t platform_statistics:                1;
        uint8_t rsvd:                               3;
    };
} PlatformPMFeatureConfig_KM0;

typedef enum
{
    BTMAC_DEEP_SLEEP        = 0,   /**< Deep sleep */
    BTMAC_ACTIVE            = 1,   /**< Active     */
} BtmacPowerMode;

typedef enum
{
    BTMAC_PM_CHECK          = 0,
    BTMAC_PM_STORE          = 1,
    BTMAC_PM_ENTER          = 2,
    BTMAC_PM_EXIT           = 3,
    BTMAC_PM_RESTORE        = 4,
    BTMAC_PM_STAGE_MAX      = 5
} BtmacPMStage;

typedef enum
{
    BTMAC_PM_WAKEUP_UNKNOWN                 = 0x0,
    BTMAC_PM_WAKEUP_LEGACY                  = 0x1,
    BTMAC_PM_WAKEUP_LE                      = 0x2,
    BTMAC_PM_WAKEUP_PRE_SYSTEM_LEVEL        = 0x3,
} BtmacWakeupReason;

typedef enum
{
    BTMAC_PM_ERROR_UNKNOWN                  = 0x0,
    BTMAC_PM_ERROR_POWER_MODE               = 0x1,
    BTMAC_PM_ERROR_LEGACY_SCAN              = 0x2,
    BTMAC_PM_ERROR_ROLE_SWITCH              = 0x3,
    BTMAC_PM_ERROE_BQB                      = 0x4,
    BTMAC_PM_ERROR_PSD                      = 0x5,
    BTMAC_PM_ERROR_CSB_ENABLE               = 0x6,
    BTMAC_PM_ERROR_NOT_EMPTY_QUEUE_OF_LOWER = 0x7,
    BTMAC_PM_ERROR_CONTROLLER_TO_HOST_BUSY  = 0x8,
    BTMAC_PM_ERROR_TX_BUSY                  = 0x9,
    BTMAC_PM_ERROR_LEGACY_NOT_IDLE          = 0xA,
    BTMAC_PM_ERROR_LE_REG_S_INST            = 0xB,
    BTMAC_PM_ERROR_ADV_STATE_NOT_IDLE       = 0xC,
    BTMAC_PM_ERROR_SCAN_STATE_NOT_IDLE      = 0xD,
    BTMAC_PM_ERROR_INITIATOR_UNIT_ENABLE    = 0xE,
    BTMAC_PM_ERROR_CHANNEL_MAP_UPDATE       = 0xF,
    BTMAC_PM_ERROR_CONNECTION_UPDATE        = 0x10,
    BTMAC_PM_ERROR_PHY_UPDATE               = 0x11,
    BTMAC_PM_ERROR_CONN_STATE_NOT_IDLE      = 0x12,
    BTMAC_PM_ERROR_LE_SCHE_NOT_READY        = 0x13,
    BTMAC_PM_ERROR_INTERRUPT_PENDING        = 0x14,
    BTMAC_PM_ERROR_WAKEUP_TIME              = 0x15,
    BTMAC_PM_ERROR_32K_CHECK_LOCK           = 0x16,
    BTMAC_PM_ERROR_HW_TIMER_RUNNING         = 0x17,
    BTMAC_PM_ERROR_LE_ISO_ACTIVE            = 0x18,
    BTMAC_PM_ERROR_OCCUPIED_TIME            = 0x19,
} BtmacPowerModeErrorCode;

typedef struct _BtmacPMSystem
{
    BtmacPowerMode power_mode;

    BtmacWakeupReason wakeup_reason;
    BtmacPowerModeErrorCode error_code;

    bool register_valid;

    bool adv_instance_mode;
    bool scan_instance_mode;

    uint32_t wakeup_count;
    uint32_t last_wakeup_clk;
    uint32_t last_sleep_clk;
    uint32_t last_sleep_cnt;
    uint32_t total_wakeup_time;
    uint32_t total_sleep_time;

    uint32_t sync_32k_start;
    uint32_t sync_32k_end;
    uint32_t sync_32k_time;

    uint32_t stage_time[BTMAC_PM_STAGE_MAX];
    uint32_t minimum_sleep_time;
    uint32_t learning_guard_time;
} BtmacPMSystem;

typedef union _BtmacPMFeatureConfig
{
    uint8_t value[1];
    struct
    {
        uint8_t btmac_check_dbg: 1;
        uint8_t btmac_enter_dbg: 1;
        uint8_t btmac_exit_dbg: 1;
        uint8_t btmac_stage_time: 1;
        uint8_t btmac_statistics: 1;
        uint8_t btmac_check_fail_dbg: 1;
        uint8_t rsvd: 2;
    };
} BtmacPMFeatureConfig;

/*============================================================================*
 *                             KR0 Unit
*============================================================================*/

typedef enum PlatformPowerMode_KR0
{
    PLATFORM_POWEROFF_KR0                       = 0,   /**< Power Off  */
    PLATFORM_POWERDOWN_KR0                      = 1,   /**< Power Down */
    PLATFORM_ACTIVE_KR0                         = 3,   /**< Active     */
    PLATFORM_POWER_MODE_MAX_KR0,
} PlatformPowerMode_KR0;

typedef enum PlatformCheckResult_KR0
{
    PLATFORM_CHECK_PEND_KR0                     = 0,
    PLATFORM_CHECK_FAIL_KR0                     = 1,
    PLATFORM_CHECK_PASS_KR0                     = 2,
} PlatformCheckResult_KR0;

typedef enum PlatformWakeupReason_KR0
{
    PLATFORM_WAKEUP_REASON_UNKNOWN_KR0          = 0x0000,
    PLATFORM_WAKEUP_REASON_LPCOMP1_KR0          = 0x0001,
    PLATFORM_WAKEUP_REASON_LPCOMP0_KR0          = 0x0002,
    PLATFORM_WAKEUP_REASON_AON_QUAD_DEC_KR0     = 0x0004,
    PLATFORM_WAKEUP_REASON_VADBUF_KR0           = 0x0008,
    PLATFORM_WAKEUP_REASON_VAD_KR0              = 0x0010,
    PLATFORM_WAKEUP_REASON_RTC_PF_KR0           = 0x0020,
    PLATFORM_WAKEUP_REASON_RTC_KR0              = 0x0040,
    PLATFORM_WAKEUP_REASON_RFSYSCLK_REG_INT_KR0 = 0x0080,
    PLATFORM_WAKEUP_REASON_GPIO_KR0             = 0x0100,
    PLATFORM_WAKEUP_REASON_USB_RESUME_KR0       = 0x0200,
    PLATFORM_WAKEUP_REASON_KM4_KR0              = 0x0400,
    PLATFORM_WAKEUP_REASON_KM0_KR0              = 0x0800,
    PLATFORM_WAKEUP_REASON_KR0_KR0              = 0x1000,
    PLATFORM_WAKEUP_REASON_MAX_KR0
} PlatformWakeupReason_KR0;

typedef enum PlatformPMErrorCode_KR0
{
    PLATFORM_ERROR_UNKNOWN_KR0              = 0x0,
    PLATFORM_ERROR_BASE_POWER_MODE_KR0      = 0x1,
    PLATFORM_ERROR_USER_POWER_MODE_KR0      = 0x2,
    PLATFORM_ERROR_CLOCK_CHECK_KR0          = 0x3,
    PLATFORM_ERROR_WAKEUP_TIME_KR0          = 0x4,
} PlatformPMErrorCode_KR0;

typedef enum PlatformPMStage_KR0
{
    PLATFORM_PM_CHECK_KR0                   = 0,
    PLATFORM_PM_ENTER_KR0                   = 1,
    PLATFORM_PM_EXIT_KR0                    = 2,
    PLATFORM_PM_STAGE_MAX_KR0
} PlatformPMStage_KR0;

typedef struct PlatformPMSystem_KR0
{
    PlatformPowerMode_KR0 power_mode;

    PlatformWakeupReason_KR0 wakeup_reason;
    PlatformPMErrorCode_KR0 error_code;

    uint32_t wakeup_count;
    uint32_t last_wakeup_clk;
    uint32_t last_sleep_clk;
    uint32_t total_wakeup_time;
    uint32_t total_sleep_time;

    uint32_t stage_time[PLATFORM_PM_STAGE_MAX_KR0];
    uint32_t minimum_sleep_time;
} PlatformPMSystem_KR0;

/** @} */ /* End of group DLPS_PLATFORM_Exported_Types */

/*============================================================================*
 *                              Variables
*============================================================================*/
/** @defgroup DLPS_PLATFORM_Exported_Variables DLPS Platform Exported Variables
  * @{
  */

extern PlatformPMFeatureConfig platform_pm_feature_cfg;
extern PlatformPMSystem platform_pm_system;

extern void (*platform_pm_register_callback_func_with_priority)(void *, PlatformPMStage, int8_t);
extern void (*platform_pm_register_callback_func)(void *, PlatformPMStage);

/** @} */ /* End of group DLPS_PLATFORM_Exported_Variables */

/*============================================================================*
 *                              Functions
*============================================================================*/
/*power manager api*/
void power_manager_slave_register_function_to_return(PMFuncToReturn func);
//void power_manager_slave_register_unit(PMUnitID unit_id, PowerManagerSlaveUnit *p_unit);
//PowerManagerSlaveUnit *power_manager_slave_get_unit(PMUnitID unit_id);
void power_manager_slave_suspend_unit(PMUnitID unit_id);
void power_manager_slave_resume_unit(PMUnitID unit_id);
void power_manager_slave_suspend_all(void);
void power_manager_slave_resume_all(void);

/*platform unit api*/
void platform_pm_set_power_mode(PlatformPowerMode pf_power_mode_user);
PlatformPowerMode platform_pm_get_power_mode(void);
PlatformPowerModeErrorCode platform_pm_get_error_code(void);
uint32_t *platform_pm_get_refuse_reason(void);
void platform_pm_get_statistics(uint32_t *wakeup_count, uint32_t *last_wakeup_clk,
                                uint32_t *last_sleep_clk);
PlatformWakeupReason platform_pm_get_wakeup_reason(void);
void platform_pm_register_schedule_bottom_half_callback_func(PlatformPMScheduleBottomHalfFunc
                                                             cb_func);

bool power_manager_interface_check_unit_active(PMSlave slave, PMUnitID unit_id);
void shutdown_bt_platform(void);


/*============================================================================*
 *                             Exported API Functions
*============================================================================*/

/** @defgroup DLPS_PLATFORM_Exported_Functions DLPS Platform Exported Functions
  * @{
  */

PlatformWakeupReason_KR0 platform_pm_get_hw_wakeup_reason_app(void);
PlatformWakeupReason_KR0 platform_pm_get_wakeup_reason_app(void);

/**
 * @brief Register Check CB to DlpsPlatform which will call it before entering Dlps.
 * @param  func DLPSEnterCheckFunc
 * @return  Status of Operation.
 * @retval true success
 * @retval false fail
*/
static inline bool dlps_check_cb_reg(DLPSEnterCheckFunc func)
{
    platform_pm_register_callback_func(func, PLATFORM_PM_CHECK);
    return true;
}

/**
 * @brief Register HW Control CB to DlpsPlatform which will call it before entering Dlps or after exiting from Dlps (according to dlpsState) .
 * @param  func DLPSHWControlFunc
 * @param  dlpsState tell the DlpsPlatform the CB should be called when DLPS_ENTER or DLPS_EXITx_XXX.
 * @return  Status of Operation.
 * @retval true success
 * @retval false fail
*/
static inline bool dlps_hw_control_cb_reg(DLPSHWControlFunc func, PlatformPMStage dlpsState)
{
    platform_pm_register_callback_func(func, dlpsState);
    return true;
}

/**
 * @brief Keep platform in @ref LPM_ACTIVE_MODE which means will stop platform enter any lower power mode.
 * @param  none
 * @return  none
*/
static inline void lps_mode_pause(void)
{
    power_manager_slave_suspend_all();
}

/**
 * @brief Restore to original LPSMode.
 * @param  none
 * @return  none
*/
static inline void lps_mode_resume(void)
{
    power_manager_slave_resume_all();
}

/**
 * @brief Set active time after boot before entering into dlps
 * @param  active_time_ms  time to keep active, unit ms
 * @return  none
*/
void set_boot_active_time(uint32_t active_time_ms);

/**
 * @brief  LPSMode Set .
 * @param  mode LPSMode
 * @return  none
*/
static inline void lps_mode_set(PlatformPowerMode mode)
{
//    btmac_pm_set_power_mode(BTMAC_DEEP_SLEEP);
    platform_pm_set_power_mode(mode);
}

/**
 * @brief  LPSMode Get .
 * @param  none
 * @return  @ref LPSMode
*/
static inline PlatformPowerMode lps_mode_get(void)
{
    return platform_pm_get_power_mode();
}

/**
 * @brief  Return Pause LPSMode stack, only 0 can enter any low power mode.
 * @param  none
 * @return  stack num
*/
extern int8_t lps_mode_stack_get(void);

/**
 * @brief  Return dlps wakeup counts .
 * @param  none
 * @return  count value
*/
static inline  uint32_t lps_wakeup_count_get(void)
{
    uint32_t wakeup_count, last_wakeup_clk, last_sleep_clk;
    platform_pm_get_statistics(&wakeup_count, &last_wakeup_clk, &last_sleep_clk);
    return wakeup_count;
}

/**
 * @brief  Return dlps remain time.
 * @param  none
 * @return  dlps remain time with unit of us
*/
extern uint32_t last_lps_remain_us_get(void);


/** @} */ /* End of group DLPS_PLATFORM_Exported_Functions */

/** @} */ /* End of group DLPS_PLATFORM */


#ifdef __cplusplus
}
#endif

#endif  /* __DLPS_PLATFORM_H */
