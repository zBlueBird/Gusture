/**
 *****************************************************************************************
 *     Copyright(c) 2018, Realtek Semiconductor Corporation. All rights reserved.
 *****************************************************************************************
 * @file    flash_nor_basic.h
 * @brief   Nor flash basic implementation header file
 * @author  Yao-Yu
 * @date    2020-07-08
 * @version v0.1
 * ***************************************************************************************
 */

#ifndef _FLASH_NOR_BASIC_NSC_H
#define _FLASH_NOR_BASIC_NSC_H

#include <stdint.h>
#include "spic.h"

#define _PACKED_                __attribute__((packed))
/****************************************************************************************
 * Nor Flash Device Definition
 ****************************************************************************************/
#define FLASH_NOR_PAGE_SIZE                     (256)
#define FLASH_NOR_SECTOR_SIZE                   (0x1000)
#define FLASH_NOR_BLOCK_SIZE                    (0x10000)

/****************************************************************************************
 * Nor Flash Macro
 ****************************************************************************************/
#define FLASH_NOR_TABLE_MAGIC_PATTERN                   FMC_CAL_PATTERN
#define IS_FLASH_SIZE_LARGER_THAN_16MB(size)            (size > (1 << 24))
#define IS_SAME_FLASH_NOR_PAGE(addr0, addr1)            (((addr0) & 0xFFFFFF00) == ((addr1) & 0xFFFFFF00))

/****************************************************************************************
 * Nor Flash Device Definition
 ****************************************************************************************/
#define FLASH_NOR_BP_FIELDS_OFFSET              (0x02)
#define FLASH_NOR_STATUS_WIP_BIT                (0x01)
#define FLASH_NOR_STATUS_WEL_BIT                (0x02)

/****************************************************************************************
 * Nor Flash Enumeration
 ****************************************************************************************/
typedef enum
{
    FLASH_NOR_WREN_REG,
    FLASH_NOR_WREN_DATA,
} FLASH_NOR_WREN_MODE;

typedef enum
{
    FLASH_NOR_IDX_SPIC0,            /* Nor flash controlled by SPIC0 */
    FLASH_NOR_IDX_SPIC1,
    FLASH_NOR_IDX_SPIC2,
    FLASH_NOR_IDX_SPIC3,
    FLASH_NOR_IDX_MAX
} FLASH_NOR_IDX_TYPE;

typedef enum
{
    FLASH_NOR_EXIST_NONE        = 0,
    FLASH_NOR_EXIST_BASIC_CMD   = 1,
    FLASH_NOR_EXIST_ADV_CMD     = 2,
    FLASH_NOR_EXIST_QUERY_INFO  = 4,
    FLASH_NOR_EXIST_ALL         = 7,
} FLASH_NOR_EXIST_LV;

typedef enum
{
    FLASH_NOR_1_BIT_MODE,
    FLASH_NOR_2_BIT_MODE,
    FLASH_NOR_4_BIT_MODE,
    FLASH_NOR_8_BIT_MODE,
} FLASH_NOR_BIT_MODE;

typedef enum
{
    FLASH_NOR_XTAL_10MHZ,
    FLASH_NOR_XTAL_20MHZ,
    FLASH_NOR_PLL_30MHZ,
    FLASH_NOR_PLL_40MHZ,
    FLASH_NOR_PLL_60MHZ,
    FLASH_NOR_PLL_80MHZ,
    FLASH_NOR_CLK_MAX
} FLASH_NOR_CLK_FREQ;

typedef enum
{
    FLASH_NOR_ERASE_SECTOR  = 1,
    FLASH_NOR_ERASE_BLOCK   = 2,
    FLASH_NOR_ERASE_CHIP    = 4,
} FLASH_NOR_ERASE_MODE;

typedef enum
{
    FLASH_NOR_RET_UNKNOWN,
    FLASH_NOR_RET_NOT_EXIST_BASIC_CMD,
    FLASH_NOR_RET_NOT_EXIST_ADV_CMD,
    FLASH_NOR_RET_NOT_EXIST_QUERY_INFO,
    FLASH_NOR_RET_CMD_NOT_SUPPORT,
    FLASH_NOR_RET_DEV_NOT_SUPPORT,
    FLASH_NOR_RET_VENDOR_NOT_SUPPORT,
    FLASH_NOR_RET_LOCK_FAILED,
    FLASH_NOR_RET_UNLOCK_FAILED,
    FLASH_NOR_RET_BIT_MODE_SET_FAILED,
    FLASH_NOR_RET_BIT_MODE_NOT_SUPPORT,
    FLASH_NOR_RET_ILLEGAL_OPERATION,
    FLASH_NOR_RET_PARAM_INVALID,
    FLASH_NOR_RET_WAIT_BUSY_FAILED,
    FLASH_NOR_RET_IDX_OUT_OF_RANGE,
    FLASH_NOR_RET_ADDR_OUT_OF_RANGE,
    FLASH_NOR_RET_ADDR_LARGER_THAN_FLASH_SIZE,
    FLASH_NOR_RET_CAL_IN_PHYSICAL_CYC_NOT_FOUND,
    FLASH_NOR_RET_CAL_RD_DUMMY_LENGTH_NOT_FOUND,
    FLASH_NOR_RET_CAL_FAILED,
    FLASH_NOR_RET_MALLOC_FAILED,
    FLASH_NOR_RET_HOOK_FUNC,
    FLASH_NOR_RET_SUSPEND_UNNECCESSARY,
    FLASH_NOR_RET_SET_4_BYTE_ADDRESS_MODE_FAILED,
    FLASH_NOR_RET_SUCCESS
} FLASH_NOR_RET_TYPE;


typedef struct _PACKED_ _FLASH_NOR_QUERY_INFO_STRUCT
{
    /* If tbbo equals to 0x7F means BP supports lock all, lock half, lock none,
       and if tbbo equals to 0xFF means BP only supports lock all, lock none */
    /* If adsbo equals to 0xFF means flash size is smaller than 16MB, so only
       needs 3 bytes address */
    uint32_t flash_size;                /* Nor flash size in byte */
    uint8_t qebo;                       /* QE bit offset in status register */
    uint8_t wsbo;                       /* Write suspend flag bit offset in status register */
    uint8_t esbo;                       /* Erase suspend flag bit offset in status register */
    uint8_t tbbo;                       /* Top-bottom bit offset in status register */
    uint8_t cmpbo;                      /* Complement bit offset in status register */
    uint8_t adsbo;                      /* Current address mode bit offset in status register */
    uint8_t bp_all;                     /* Block protect all level in status register */
    uint8_t bp_mask;                    /* Block protect configurable bit mask in status register */
    uint32_t resume_to_suspend_delay_us;/* Delay time for a resume command to next suspend command */
} FLASH_NOR_QUERY_INFO_STRUCT;


typedef struct _PACKED_ _FLASH_NOR_QUERY_INFO_TABLE_STRUCT
{
    uint8_t manu_id;
    uint16_t device_id;
    FLASH_NOR_QUERY_INFO_STRUCT query;
} FLASH_NOR_QUERY_INFO_TABLE_STRUCT;


/****************************************************************************************
 * Nor Flash Structure
 ****************************************************************************************/
typedef struct _PACKED_ _FLASH_NOR_BASIC_CMD_STRUCT
{
    uint8_t cmd_rd_id;              /* Read nor flash ID cmd */
    uint8_t cmd_rd_sr;              /* Read status register */
    uint8_t cmd_wr_sr;              /* Write status register */
    uint8_t cmd_rd_data;            /* Single read cmd */
    uint8_t cmd_pp;                 /* Single page program cmd */
    uint8_t cmd_sector_e;           /* Erase cmd for nor flash sector (4kB) */
    uint8_t cmd_block_e;            /* Erase cmd for nor flash block (64KB) */
    uint8_t cmd_chip_e;             /* Erase cmd for whole nor flash */
    uint8_t cmd_wr_en;              /* Write enable cmd */
    uint8_t cmd_wr_en_vol;          /* Write enable for volatile status register cmd */
    uint8_t cmd_wr_di;              /* Write disable cmd */
    uint8_t cmd_dp;                 /* Enter deep power down mode cmd */
    uint8_t cmd_dp_release;         /* Release from deep power down mode cmd */
    uint8_t cmd_en_reset;           /* Enable software reset cmd */
    uint8_t cmd_reset;              /* Software reset cmd */
} FLASH_NOR_BASIC_CMD_STRUCT;

typedef struct _PACKED_ _FLASH_NOR_ADV_CMD_STRUCT
{
    uint8_t cmd_rd_dual_o;          /* Dual data read cmd */
    uint8_t cmd_rd_dual_io;         /* Dual data/addr read cmd */
    uint8_t cmd_rd_quad_o;          /* Quad data read cmd */
    uint8_t cmd_rd_quad_io;         /* Quad data/addr read cmd */
    uint8_t cmd_pp_quad_i;          /* Quad page program cmd (1-1-4) */
    uint8_t cmd_pp_quad_ii;         /* Quad page program cmd (1-4-4) */
    uint8_t cmd_rd_sr2;             /* Read status register 2 */
    uint8_t cmd_rd_sr3;             /* Read status register 3 */
    uint8_t cmd_rd_scur;            /* Read secure register */
    uint8_t cmd_wr_sr2;             /* Write status register 2 */
    uint8_t cmd_wr_sr3;             /* Write status register 3 */
    uint8_t cmd_wr_scur;            /* Write secure register */
    uint8_t cmd_rd_cr;              /* Read config cmd */
    uint8_t cmd_hpm;                /* High-performance or continuous read cmd */
    uint8_t cmd_suspend;            /* Suspend cmd */
    uint8_t cmd_resume;             /* Resume cmd */
    uint8_t cmd_enter_4byte_mode;       /* Enter 4 byte address mode cmd */
    uint8_t cmd_exit_4byte_mode;        /* Exit 4 byte address mode cmd */
} FLASH_NOR_ADV_CMD_STRUCT;

typedef struct _PACKED_ _FLASH_NOR_ACCESS_CH
{
    SPIC_CFG_CH cmd;
    SPIC_CFG_CH addr;
    SPIC_CFG_CH data;
} FLASH_NOR_ACCESS_CH;

typedef struct _PACKED_ _FLASH_NOR_DELAY_INFO_STRUCT
{
    uint16_t path_len: 4;           /* Path delay from pad to internal SPI controller */
    uint16_t dummy_len: 12;         /* Delay cycles for data read, not include path delay */
} FLASH_NOR_DELAY_INFO_STRUCT;

typedef struct _PACKED_ _FLASH_NOR_INFO_STRUCT
{
    uint8_t manu_id;
    uint16_t device_id;

    uint8_t rd_cmd;                 /* Specify the read cmd for current bit mode */
    uint8_t wr_cmd;                 /* Specify the write cmd for current bit mode */

    FLASH_NOR_BASIC_CMD_STRUCT basic;
    FLASH_NOR_ADV_CMD_STRUCT adv;
    FLASH_NOR_QUERY_INFO_STRUCT query;

    FLASH_NOR_ACCESS_CH rd_ch;
    FLASH_NOR_ACCESS_CH wr_ch;
    FLASH_NOR_DELAY_INFO_STRUCT delay;
} FLASH_NOR_INFO_STRUCT;

/****************************************************************************************
* Nor Flash Inter-Function Patch Prototype
****************************************************************************************/
typedef FLASH_NOR_RET_TYPE(*FLASH_NOR_PATCH_FUNC)();

/****************************************************************************************
 * Nor Flash NSC Function
 ****************************************************************************************/
FLASH_NOR_EXIST_LV flash_nor_get_exist(FLASH_NOR_IDX_TYPE idx);
//uint32_t flash_nor_get_flash_size(FLASH_NOR_IDX_TYPE idx);
void flash_nor_get_info(FLASH_NOR_INFO_STRUCT *p_ns_flash_nor_info,
                        uint32_t flash_nor_info_len);
extern FLASH_NOR_RET_TYPE flash_nor_cmd_rx(FLASH_NOR_IDX_TYPE idx, SPIC_ACCESS_INFO *info,
                                           uint8_t *buf, uint8_t len);
extern FLASH_NOR_RET_TYPE flash_nor_cmd_tx(FLASH_NOR_IDX_TYPE idx, SPIC_ACCESS_INFO *info,
                                           uint8_t *buf, uint8_t len);
extern FLASH_NOR_RET_TYPE flash_nor_wait_busy(FLASH_NOR_IDX_TYPE idx);
extern FLASH_NOR_RET_TYPE flash_nor_get_status_wip(FLASH_NOR_IDX_TYPE idx, bool *is_wip);
extern FLASH_NOR_RET_TYPE flash_nor_load_query_info(FLASH_NOR_IDX_TYPE idx);
extern FLASH_NOR_RET_TYPE flash_nor_set_seq_trans(FLASH_NOR_IDX_TYPE idx, bool enable);
extern FLASH_NOR_RET_TYPE flash_nor_get_bit_mode(FLASH_NOR_IDX_TYPE idx, FLASH_NOR_BIT_MODE *mode);
extern FLASH_NOR_RET_TYPE flash_nor_set_bit_mode(FLASH_NOR_IDX_TYPE idx, FLASH_NOR_BIT_MODE mode);
extern FLASH_NOR_RET_TYPE flash_nor_set_auto_mode(FLASH_NOR_IDX_TYPE idx, FLASH_NOR_BIT_MODE mode);
extern FLASH_NOR_RET_TYPE flash_nor_set_4_byte_addr_mode(FLASH_NOR_IDX_TYPE idx, bool enable);
extern FLASH_NOR_RET_TYPE flash_nor_load_query_info(FLASH_NOR_IDX_TYPE idx);




#endif
