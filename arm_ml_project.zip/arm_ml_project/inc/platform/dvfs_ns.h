/**
*********************************************************************************************************
*               Copyright(c) 2020, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file         dvfs_ns.h
* @brief        Dynamic Voltage Frequency Scaling Fucntcions implementation Header File.
* @details
* @author       Kellan Ho
* @date         2020-09-18
* @version      v0.1
*********************************************************************************************************
*/

/*============================================================================*
 *               Define to prevent recursive inclusion
 *============================================================================*/
#ifndef __DVFS_NS_H
#define __DVFS_NS_H


/*============================================================================*
 *                               Header Files
*============================================================================*/
#include <stdint.h>
#include <stdbool.h>
#include "dvfs_nsc.h"
#include "os_queue.h"

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*
 *                              Types
*============================================================================*/

#define DVFS_VDD_TYPE_NUM           1
#define DVFS_NORMAL_VDD_MODE_NUM    2

typedef enum
{
    DVFS_NORMAL_VDD                 = 0,
} DVFSVDDType;

typedef enum
{
    DVFS_VDD_0V9                    = 0,
    DVFS_VDD_0V8                    = 1,
} DVFSVDDMode;

typedef enum
{
    DVFS_SUSPEND_SRAM               = 0x0,
    DVFS_RESUME_SRAM                = 0x1,
} DVFSControlSRAM;

typedef enum
{
    DVFS_STATE_IDLE                 = 0,
    DVFS_STATE_BUSY                 = 1,
} DVFSState;

typedef enum
{
    DVFS_SUCCESS                    = 0x0,
    DVFS_BUSY                       = 0x1,
    DVFS_VOLTAGE_FAIL               = 0x2,
    DVFS_CONDITION_FAIL             = 0x4,
    DVFS_SRAM_FAIL                  = 0x8,
    DVFS_NOT_SUPPORT                = 0x10,
} DVFSErrorCode;

typedef enum
{
    PROFILING_DVFS_CHECK_CONDITION  = 0,
    PROFILING_DVFS_CHANGE_VOLTAGE   = 1,
    PROFILING_DVFS_CHANGE_PARAMETER = 2,
    PROFILING_DVFS_STAGE_MAX        = 3
} ProfilingDVFSStage;

typedef bool (*DVFSCheckFunc)(void);
typedef bool (*DVFSVoltageFunc)(DVFSVDDMode);

typedef struct DVFSCheckFuncQueueElem
{
    struct DVFSCheckFuncQueueElem *pNext;
    void *check_func;
} DVFSCheckFuncQueueElem;

typedef struct ProfilingDVFSData
{
    uint32_t stage_start;
    uint32_t stage_end;
    uint32_t stage_time[PROFILING_DVFS_STAGE_MAX];
} ProfilingDVFSData;

typedef struct DVFSSystem
{
    DVFSState state;

    DVFSNormalVDDPara normal_vdd[DVFS_NORMAL_VDD_MODE_NUM];

    T_OS_QUEUE check_func_queue[DVFS_VDD_TYPE_NUM];

    DVFSVoltageFunc voltage_func[DVFS_VDD_TYPE_NUM];

    ProfilingDVFSData *profiling_data;
} DVFSSystem;

typedef union DVFSFeatureConfig
{
    uint8_t value;
    struct
    {
        uint8_t enable: 1;
        uint8_t profiling_mode: 1;
        uint8_t rsvd: 6;
    };
} DVFSFeatureConfig;

/*============================================================================*
 *                              Variables
*============================================================================*/

extern DVFSFeatureConfig dvfs_feature_cfg;
extern DVFSSystem dvfs_manager_system;

extern bool (*dvfs_check_condition)(DVFSVDDType, DVFSVDDMode);
extern bool (*dvfs_change_voltage)(DVFSVDDType, DVFSVDDMode);
extern void (*dvfs_pre_set_vsel_rom_sram_para_ns)(void);
extern void (*dvfs_set_non_vsel_rom_sram_para_ns)(DVFSVDDType, DVFSVDDMode, DVFSControlType);
extern void (*dvfs_set_vsel_rom_sram_para)(DVFSVDDType, DVFSVDDMode, DVFSControlType);
extern bool (*dvfs_control_sram_access)(DVFSVDDType, DVFSControlType, DVFSControlSRAM);
extern bool (*dvfs_change_rom_sram_paras)(DVFSVDDType, DVFSVDDMode);

extern DVFSVDDMode(*dvfs_get_mode)(DVFSVDDType);
extern DVFSErrorCode(*dvfs_set_mode)(DVFSVDDType, DVFSVDDMode);

extern void (*dvfs_init)(void);

extern bool (*dvfs_voltage_func_normal_vdd)(DVFSVDDMode);

/*============================================================================*
 *                              Functions
*============================================================================*/

void dvfs_register_check_func(DVFSVDDType vdd_type, DVFSCheckFunc check_func);
void dvfs_register_voltage_func(DVFSVDDType vdd_type, DVFSVoltageFunc voltage_func);
CLK_FREQ_TYPE dvfs_get_clock_freq_limit(DVFSVDDMode vdd_mode, KM4_ACTIVE_CLK_TYPE active_clk_type);
uint16_t dvfs_get_voltage(DVFSVDDMode vdd_mode);

#ifdef __cplusplus
}
#endif

#endif  /* __DVFS_NS_H */
