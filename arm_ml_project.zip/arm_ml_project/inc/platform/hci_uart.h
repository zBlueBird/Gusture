/**
*********************************************************************************************************
*               Copyright(c) 2021, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* \file     hci_uart.h
* \brief    The header file of hci uart function.
* \details
* \author   Lory
* \date     2021-12-29
* \version  v0.0.1
* *********************************************************************************************************
*/


#ifndef _HCI_UART_H_
#define _HCI_UART_H_

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*
 *                         Includes
 *============================================================================*/
#include "rtl876x.h"

#define HCI_VENDOR_READ                                      0xFC61
#define HCI_VENDOR_WRITE                                     0xFC62


/* CMD PARAM Maximum and Minimum Length */
#define HCI_MAX_CMD_PARAM_LEN                255
#define HCI_MIN_CMD_PARAM_LEN                  0

/* MAX and MIN EVENT PARAM LEN */
#define HCI_MAX_EVENT_PARAM_LEN              255
#define HCI_MIN_EVENT_PARAM_LEN               02

#define HCI_COMMAND_STATUS_EVENT_LEN                        0x04

#define HCI_COMMAND_COMPLETE_EVENT                          0x0E

/*============================= Error Codes =============================*/
#define HCI_COMMAND_SUCCEEDED                                 0x00
#define UNKNOWN_HCI_COMMAND_ERROR                             0x01
#define INVALID_HCI_COMMAND_PARAMETERS_ERROR                  0x12

/** @brief The upper 8 bits of a 16 bit value */
#ifndef MSB
#define MSB(a) (((a) & 0xFF00) >> 8)
#endif

/** @brief The lower 8 bits of a 16 bit value */
#ifndef LSB
#define LSB(a) ((a) & 0xFF)
#endif

#define RD_32BIT_IO(base, offset) \
    (*(volatile uint32_t*)((base) + (offset)))
#define RD_16BIT_IO(base, offset) \
    (*((volatile uint16_t*)((base) + (offset))))
#define RD_8BIT_IO(base, offset) \
    (*((volatile uint8_t*)((base) + (offset))))
#define WR_32BIT_IO(base, offset, val) \
    (*((volatile uint32_t*)((base) + (offset))) = (val))
#define WR_16BIT_IO(base, offset, val) \
    (*((volatile uint16_t*)((base) + (offset))) = (val))
#define WR_8BIT_IO(base, offset, val) \
    (*((volatile uint8_t*)((base) + (offset))) = (val))

#pragma pack(push)
#pragma pack(1)
typedef struct
{
    uint8_t pkt_type;
    uint16_t cmd_opcode;
    uint8_t param_total_length;
    uint8_t cmd_parameter[HCI_MAX_CMD_PARAM_LEN];
} /* __attribute__((packed)) */ HCI_CMD_PKT;

#define HCI_MAX_CMD_LEN                                       (HCI_MAX_CMD_PARAM_LEN + 4)

typedef struct
{
    uint8_t pkt_type;
    uint8_t event_opcode;
    uint8_t param_total_length;
    uint8_t event_parameter[HCI_MAX_EVENT_PARAM_LEN];
} /* __attribute__((packed)) */ HCI_EVENT_PKT;
#pragma pack(pop)

extern void (*hci_mode_enable)(void);
extern void (*switch_hci_uart_pin)(uint8_t core);

#ifdef __cplusplus
}
#endif

#endif /* _HCI_UART_H_ */

/******************* (C) COPYRIGHT 2021 Realtek Semiconductor *****END OF FILE****/