/**
************************************************************************************************************
*               Copyright(c) 2017, Realtek Semiconductor Corporation. All rights reserved.
************************************************************************************************************
* @file     platform_utils.h
* @brief    utility helper function for user application
* @author   lory_xu
* @date     2017-02
* @version  v1.0
*************************************************************************************************************
*/

#ifndef _PLATFORM_UTILS_H_
#define _PLATFORM_UTILS_H_

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*
 *                               Header Files
*============================================================================*/
#include <stdint.h>
#include <stdbool.h>
#include "occd_parser_nsc.h"

/** @defgroup  PLATFORM_UTILS Platform Utilities
    * @brief Utility helper functions
    * @{
    */

/*============================================================================*
 *                              Functions
 *============================================================================*/
/** @defgroup PLATFORM_UTILS_Exported_Functions Platform Utils Exported Functions
    * @brief
    * @{
    */

/**
 * @brief Generate random number given max number allowed
 * @param max   to specify max number that allowed
 * @return random number
 */

uint32_t platform_random(uint32_t max);

/**
 * @brief for occd parsing
 *
 * @param parse_info  Signature: must match the signature in occd
 *                    max_size: the occd parsing range (must bigger than header size(8 bytes))
 *                    sys_cfg: the first header address(= OCCD_ADDRESS + DEFAULT_HEADER_SIZE)
 * @param id          indicates which module needs to be parsed
 * @param mem         the memory address is the destination that applies the config data to
 * @param size        the memory size (must bigger than entry offset + entry length)
 * @return            0: parsing success, 1: id mismatch, 2: no config, 3: entry size mismatch, 4: header length mismatch, 5: mem offset exceed
 */
uint32_t parse_sys_cfg_to_mem(PARSING_PARAMETER_FORMAT *p_parse_info, uint16_t id,
                              uint8_t *mem, uint32_t size);


/** @} */ /* End of group PLATFORM_UTILS_Exported_Functions */

/** @} */ /* End of group PLATFORM_UTILS */

#ifdef __cplusplus
}
#endif

#endif

