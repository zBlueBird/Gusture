/**
*********************************************************************************************************
*               Copyright(c) 2021, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* \file     rtl876x_nvic.h
* \brief    The header file of NVIC  driver.
* \details  This file provides all NVIC firmware functions.
* @author   Yuan Feng
* @date     2021-12-15
* @version  v2.0
* *********************************************************************************************************
*/

#ifndef _RTL876X_NVIC_NSC_H_
#define _RTL876X_NVIC_NSC_H_

#ifdef __cplusplus
extern "C" {
#endif

/**
 * \addtogroup  IO          Peripheral Drivers
 * \defgroup    NVIC        NVIC
 * \brief       Manage the NVIC peripheral functions.
 * \ingroup     IO
 */

/* Includes ------------------------------------------------------------------*/
#include <stdbool.h>
#include "rtl876x.h"

/*============================================================================*
 *                         Types
 *============================================================================*/

/**
 * \defgroup    NVIC_Exported_Types Init Params Struct
 * \ingroup     NVIC
 */

/**
 * \brief       NVIC init structure definition
 * \ingroup     NVIC_Exported_Types
 */




/*============================================================================*
 *                         Functions
 *============================================================================*/

/**
 * \defgroup    NVIC_Exported_Functions Peripheral APIs
 * \ingroup     NVIC
 * \{
 */


bool NVIC_SetIRQNonSecure(IRQn_Type IRQn);

/** \} */ /* End of group NVIC_Exported_Functions */

#ifdef __cplusplus
}
#endif

#endif /* _RTL876X_NVIC_NSC_H_ */

/******************* (C) COPYRIGHT 2021 Realtek Semiconductor Corporation *****END OF FILE****/