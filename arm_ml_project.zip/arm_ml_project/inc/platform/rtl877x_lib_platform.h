/**
************************************************************************************************************
*               Copyright(c) 2016, Realtek Semiconductor Corporation. All rights reserved.
************************************************************************************************************
* @file     rtl876x_lib_platform.h
* @brief
* @details
* @author
* @date
* @version
*************************************************************************************************************
*/

#ifndef _RTL876X_LIB_PLATFORM_H_
#define _RTL876X_LIB_PLATFORM_H_

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include "mem_types.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
  * @brief  another log buffer API, the fmt string will occupy flash space
  */
void log_buffer_retarget(uint32_t info, const char *fmt, ...);

#define DBG_BUFFER_RETARGET(...)     do {\
        log_buffer_retarget(COMBINE_TRACE_INFO(TYPE_BEE2, SUBTYPE_DIRECT, 0, 0), __VA_ARGS__);\
    } while (0)

/*============================================================================*
 *                         Log Retarget Sample Usage
 *============================================================================*/
/**
 * @brief   retarget other library code log to bee2 buffer log print.
 * @note    If enable, increase code size because more log will occupy flash space
 *
* <b>Example usage</b>
 * \code{.c}

//enable retarget other library code log to bee2 buffer log print or not
#define ENABLE_RETARGET_LOG     1

#if ENABLE_RETARGET_LOG
#define LogDebug(...) DBG_BUFFER_RETARGET(__VA_ARGS__)
#else
#define LogDebug(...)
#endif

void test_log_retarget(void)
{
    char str[] = {'a','b','c', '\0'};
    float data1 = 3.14125;
    uint32_t data2 = 1024;
    LogDebug("test");
    LogDebug("string:%s", str);
    LogDebug("float:%f", data1);
    LogDebug("uint:%d", data2);
}
 * \endcode
 */
/*============================================================================*/

void patch_func_ptr_init(void);

void print_sdk_lib_version(void);

bool update_dsp_share_ram_cfg(uint32_t dsp_share_ram_size);


#ifdef __cplusplus
}
#endif

#endif /* _RTL876X_LIB_PLATFORM_H_ */
