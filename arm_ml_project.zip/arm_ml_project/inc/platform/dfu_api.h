/**
************************************************************************************************************
*               Copyright(c) 2022, Realtek Semiconductor Corporation. All rights reserved.
************************************************************************************************************
* @file     dfu_api.h
* @brief    APIs to implement device firmware update .
* @author   Grace
* @date     2022-06-29
* @version  v1.0
*************************************************************************************************************
*/

#ifndef _DFU_API_H_
#define  _DFU_API_H_

/*============================================================================*
 *                               Header Files
*============================================================================*/
#include <stdint.h>
#include <stdbool.h>


/** @defgroup DFU_API DFU API Sets
  * @brief API sets for device firmware update implementation
  * @{
  */

/*============================================================================*
 *                              Constants
 *============================================================================*/
/** @defgroup DFU_API_Exported_Constants DFU API Sets Exported Constants
    * @brief
    * @{
    */



/** End of DFU_API_Exported_Constants
    * @}
    */


/*============================================================================*
  *                                   Macros
  *============================================================================*/
/** @defgroup DFU_API_Exported_Macros DFU API Sets Exported Macros
  * @{
  */

/** @brief  dfu image header size*/
#define DFU_HEADER_SIZE  12


/** @} */ /* End of group DFU_API_Exported_Macros */


/*============================================================================*
  *                                   Types
  *============================================================================*/
/** @defgroup DFU_API_Exported_Types DFU API Sets Exported Types
  * @{
  */


/** @} */ /* End of group DFU_API_Exported_Types */
/*============================================================================*
  *                                Functions
  *============================================================================*/
/** @defgroup DFU_API_Exported_Functions DFU API Sets Exported Functions
    * @{
    */

#endif //_DFU_API_H_

