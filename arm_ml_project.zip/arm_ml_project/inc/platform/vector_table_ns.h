#ifndef VECTOR_TABLE_H
#define VECTOR_TABLE_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"
#include "stdbool.h"
#if defined (__ARMCC_VERSION) && (__ARMCC_VERSION >= 6010050)
#include "cmsis_armclang.h"   // replace with cmsis_compiler.h ?
#endif


typedef void (*IRQ_Fun)(void);       /**< ISR Handler Prototype */

typedef enum
{
    InitialSP_VECTORn = 0,
    Reset_VECTORn,
    NMI_VECTORn,
    HardFault_VECTORn,
    MemMang_VECTORn,
    BusFault_VECTORn,
    UsageFault_VECTORn,
    RSVD0_VECTORn,
    RSVD1_VECTORn,
    RSVD2_VECTORn,
    RSVD3_VECTORn,
    SVC_VECTORn,
    DebugMonitor_VECTORn,
    RSVD4_VECTORn,
    PendSV_VECTORn,
    SysTick_VECTORn,

    System_VECTORn = 16,
    KM4_WDG_VECTORn,
    KM0_WDG_VECTORn,
    KR0_WDG_VECTORn,
    RXI300_VECTORn,
    RXI300_SEC_VECTORn,
    DSP_VECTORn,
    D2H_VECTORn,
    Peripheral_VECTORn,
    GPIO_A0_VECTORn,
    GPIO_A1_VECTORn,
    GPIO_A_2_7_VECTORn,
    GPIO_A_8_15_VECTORn,
    GPIO_A_16_23_VECTORn,
    GPIO_A_24_31_VECTORn,
    GPIO_B_0_7_VECTORn,
    GPIO_B_8_15_VECTORn,
    GPIO_B_16_23_VECTORn,
    GPIO_B_24_31_VECTORn,
    GPIO_C_0_7_VECTORn,
    GPIO_C_8_15_VECTORn,
    GPIO_C_16_23_VECTORn,
    GPIO_C_24_31_VECTORn,
    GPIO_D_0_7_VECTORn,
    GPIO_D_8_15_VECTORn,
    GPIO_D_16_23_VECTORn,
    GPIO_D_24_31_VECTORn,
    GDMA1_Channel0_VECTORn,
    GDMA1_Channel1_VECTORn,
    GDMA1_Channel2_VECTORn,
    GDMA1_Channel3_VECTORn,
    GDMA1_Channel4_VECTORn,
    GDMA1_Channel5_VECTORn,
    GDMA1_Channel6_VECTORn,
    GDMA1_Channel7_VECTORn,
    GDMA2_Channel0_VECTORn,
    GDMA2_Channel1_VECTORn,
    GDMA2_Channel2_VECTORn,
    GDMA2_Channel3_VECTORn,
    GDMA2_Channel4_VECTORn,
    GDMA2_Channel5_VECTORn,
    GDMA2_Channel6_VECTORn,
    GDMA2_Channel7_VECTORn,
    GDMA2_Channel8_VECTORn,
    GDMA2_Channel9_VECTORn,
    GDMA2_Channel10_VECTORn,
    GDMA2_Channel11_VECTORn,
    GDMA2_Channel12_VECTORn,
    GDMA2_Channel13_VECTORn,
    GDMA2_Channel14_VECTORn,
    GDMA2_Channel15_VECTORn,
    SPI0_VECTORn,
    SPI1_VECTORn,
    SPI2_VECTORn,
    SPI3_VECTORn,
    I2C0_VECTORn,
    I2C1_VECTORn,
    I2C2_VECTORn,
    I2C3_VECTORn,
    UART2_VECTORn,
    UART3_VECTORn,
    UART4_VECTORn,
    UART5_VECTORn,
    UART6_VECTORn,
    Timer_B0_VECTORn,
    Timer_B1_VECTORn,
    Timer_B2_VECTORn,
    Timer_B3_VECTORn,
    Timer_C0_VECTORn,
    Timer_C1_VECTORn,
    Timer_C2_VECTORn,
    Timer_C3_VECTORn,
    Timer_C4_VECTORn,
    Timer_C5_VECTORn,
    Enhanced_Timer0_VECTORn,
    Enhanced_Timer1_VECTORn,
    Enhanced_Timer2_VECTORn,
    Enhanced_Timer3_VECTORn,
    Enhanced_Timer4_VECTORn,
    Enhanced_Timer5_VECTORn,
    Enhanced_Timer6_VECTORn,
    Enhanced_Timer7_VECTORn,
    ADC_VECTORn,
    KEYSCAN_VECTORn,
    QDECODE_VECTORn,
    ISO7816_VECTORn,
    IR_VECTORn,
    Public_Key_Engine_VECTORn,
    Flash_SEC0_VECTORn,
    Flash_SEC1_VECTORn,
    SHA2_VECTORn,
    SHA3_VECTORn,
    SPORT0_RX_VECTORn,
    SPORT0_TX_VECTORn,
    SPORT1_RX_VECTORn,
    SPORT1_TX_VECTORn,
    SPORT2_RX_VECTORn,
    SPORT2_TX_VECTORn,
    SPORT3_RX_VECTORn,
    SPORT3_TX_VECTORn,
    ASRC0_VECTORn,
    ASRC1_VECTORn,
    VADBUF_VECTORn,
    VAD_VECTORn,
    COMP_CLK4_VECTORn,
    COMP_CLK5_VECTORn,
    COMP_CLK9_VECTORn,
    COMP_CLK10_VECTORn,
    USB_VECTORn,
    USB_ISO_VECTORn,
    USB_UTMI_SUSPEND_N_VECTORn,
    SDIO0_VECTORn,
    SDIO1_VECTORn,
    GPU_VECTORn,
    RTC_VECTORn,
    MIPI_VECTORn,
    Display_VECTORn,
    IPC_KR0_VECTORn,
    IPC_KM0_VECTORn,
    ECC_VECTORn,
    Slave_Port_Monitor_VECTORn,
    SPI_Slave_VECTORn,
    LOG_KR0_VECTORn,
    LOG_KM0_VECTORn,
    AON_QDEC_VECTORn,
    GDMA0_Channel0_VECTORn,
    GDMA0_Channel1_VECTORn,
    GDMA0_Channel2_VECTORn,

    /* second level interrupt (Peripheral_VECTORn) */
    SPIC0_VECTORn,
    SPIC1_VECTORn,
    SPIC2_VECTORn,
    SPIC3_VECTORn,
    TRNG_VECTORn,
    MAE_VECTORn,
    LPCOMP_VECTORn,
    SPI_PHY0_VECTORn,
    SPI_PHY12_VECTORn,
    SPI_PHY3_VECTORn,

    /* second level interrupt (DSP_IRQn), not directly connect to NVIC */
    DSP_Report_VECTORn,
    DSP_RX_REQ_VECTORn,
    DSP_TX_ACK_VECTORn,
    DSP_WDT_VECTORn,
    BT_SYNC_CLK_VECTORn,
    DSP_TO_HOST_FAST_VECTORn,
    DSP_TO_HOST_VECTORn,
    DSP_Event1_VECTORn,
    DSP_Event2_VECTORn,

    /* second level interrupt (D2H_IRQn), not directly connect to NVIC */
    D2H_INT0_VECTORn,
    D2H_INT1_VECTORn,
    D2H_INT2_VECTORn,
    D2H_INT3_VECTORn,
    D2H_INT4_VECTORn,
    D2H_INT5_VECTORn,
    D2H_INT6_VECTORn,
    D2H_INT7_VECTORn,

    /* gpio sub interrupt */
    GPIOA2_VECTORn,
    GPIOA3_VECTORn,
    GPIOA4_VECTORn,
    GPIOA5_VECTORn,
    GPIOA6_VECTORn,
    GPIOA7_VECTORn,
    GPIOA8_VECTORn,
    GPIOA9_VECTORn,
    GPIOA10_VECTORn,
    GPIOA11_VECTORn,
    GPIOA12_VECTORn,
    GPIOA13_VECTORn,
    GPIOA14_VECTORn,
    GPIOA15_VECTORn,
    GPIOA16_VECTORn,
    GPIOA17_VECTORn,
    GPIOA18_VECTORn,
    GPIOA19_VECTORn,
    GPIOA20_VECTORn,
    GPIOA21_VECTORn,
    GPIOA22_VECTORn,
    GPIOA23_VECTORn,
    GPIOA24_VECTORn,
    GPIOA25_VECTORn,
    GPIOA26_VECTORn,
    GPIOA27_VECTORn,
    GPIOA28_VECTORn,
    GPIOA29_VECTORn,
    GPIOA30_VECTORn,
    GPIOA31_VECTORn,

    GPIOB0_VECTORn,
    GPIOB1_VECTORn,
    GPIOB2_VECTORn,
    GPIOB3_VECTORn,
    GPIOB4_VECTORn,
    GPIOB5_VECTORn,
    GPIOB6_VECTORn,
    GPIOB7_VECTORn,
    GPIOB8_VECTORn,
    GPIOB9_VECTORn,
    GPIOB10_VECTORn,
    GPIOB11_VECTORn,
    GPIOB12_VECTORn,
    GPIOB13_VECTORn,
    GPIOB14_VECTORn,
    GPIOB15_VECTORn,
    GPIOB16_VECTORn,
    GPIOB17_VECTORn,
    GPIOB18_VECTORn,
    GPIOB19_VECTORn,
    GPIOB20_VECTORn,
    GPIOB21_VECTORn,
    GPIOB22_VECTORn,
    GPIOB23_VECTORn,
    GPIOB24_VECTORn,
    GPIOB25_VECTORn,
    GPIOB26_VECTORn,
    GPIOB27_VECTORn,
    GPIOB28_VECTORn,
    GPIOB29_VECTORn,
    GPIOB30_VECTORn,
    GPIOB31_VECTORn,

    GPIOC0_VECTORn,
    GPIOC1_VECTORn,
    GPIOC2_VECTORn,
    GPIOC3_VECTORn,
    GPIOC4_VECTORn,
    GPIOC5_VECTORn,
    GPIOC6_VECTORn,
    GPIOC7_VECTORn,
    GPIOC8_VECTORn,
    GPIOC9_VECTORn,
    GPIOC10_VECTORn,
    GPIOC11_VECTORn,
    GPIOC12_VECTORn,
    GPIOC13_VECTORn,
    GPIOC14_VECTORn,
    GPIOC15_VECTORn,
    GPIOC16_VECTORn,
    GPIOC17_VECTORn,
    GPIOC18_VECTORn,
    GPIOC19_VECTORn,
    GPIOC20_VECTORn,
    GPIOC21_VECTORn,
    GPIOC22_VECTORn,
    GPIOC23_VECTORn,
    GPIOC24_VECTORn,
    GPIOC25_VECTORn,
    GPIOC26_VECTORn,
    GPIOC27_VECTORn,
    GPIOC28_VECTORn,
    GPIOC29_VECTORn,
    GPIOC30_VECTORn,
    GPIOC31_VECTORn,

    GPIOD0_VECTORn,
    GPIOD1_VECTORn,
    GPIOD2_VECTORn,
    GPIOD3_VECTORn,
    GPIOD4_VECTORn,
    GPIOD5_VECTORn,
    GPIOD6_VECTORn,
    GPIOD7_VECTORn,
    GPIOD8_VECTORn,
    GPIOD9_VECTORn,
    GPIOD10_VECTORn,
    GPIOD11_VECTORn,
    GPIOD12_VECTORn,
    GPIOD13_VECTORn,
    GPIOD14_VECTORn,
    GPIOD15_VECTORn,
    GPIOD16_VECTORn,
    GPIOD17_VECTORn,
    GPIOD18_VECTORn,
    GPIOD19_VECTORn,
    GPIOD20_VECTORn,
    GPIOD21_VECTORn,
    GPIOD22_VECTORn,
    GPIOD23_VECTORn,
    GPIOD24_VECTORn,
    GPIOD25_VECTORn,
    GPIOD26_VECTORn,
    GPIOD27_VECTORn,
    GPIOD28_VECTORn,
    GPIOD29_VECTORn,
    GPIOD30_VECTORn,
    GPIOD31_VECTORn,

    MAX_VECTORn,
} VECTORn_Type;

#define Peripheral_First_VECTORn    SPIC0_VECTORn
#define Peripheral_Last_VECTORn     SPI_PHY3_VECTORn

#define DSP_First_VECTORn           DSP_TX_ACK_VECTORn
#define DSP_Last_VECTORn            DSP_TO_HOST_FAST_VECTORn

#define D2H_First_VECTORn           D2H_INT0_VECTORn
#define D2H_Last_VECTORn            D2H_INT7_VECTORn

#define GPIOA_First_VECTORn         GPIOA2_VECTORn
#define GPIOA_Last_VECTORn          GPIOA31_VECTORn
#define GPIOB_First_VECTORn         GPIOB0_VECTORn
#define GPIOB_Last_VECTORn          GPIOB31_VECTORn
#define GPIOC_First_VECTORn         GPIOC0_VECTORn
#define GPIOC_Last_VECTORn          GPIOC31_VECTORn
#define GPIOD_First_VECTORn         GPIOD0_VECTORn
#define GPIOD_Last_VECTORn          GPIOD31_VECTORn

// extern void *RomVectorTable_NS[];
extern void *RamVectorTable_NS[];

extern void Default_Handler_rom(void);

/**
 * @brief  Initialize RAM vector table to a given RAM address.
 * @param  ram_vector_addr: RAM Vector Address.
 * @retval true: Success
 *         false: Fail
 * @note   When using vector table relocation, the base address of the new vector
 *         table must be aligned to the size of the vector table extended to the
 *         next larger power of 2. In RTL8763, the base address is aligned at 0x100.
 */
bool RamVectorTableInit_ns(uint32_t ram_vector_addr);

/**
 * @brief  Update ISR Handler in RAM Vector Table.
 * @param  v_num: Vector number(index)
 * @param  isr_handler: User defined ISR Handler.
 * @retval true: Success
 *         false: Fail
 */
bool RamVectorTableUpdate_ns(VECTORn_Type v_num, IRQ_Fun isr_handler);

// void HardFault_Handler(void);

/************************************************************************** used for vector table */
#if   defined ( __CC_ARM )
//__weak void Reset_Handler(void);
__weak void NMI_Handler(void);
__weak void MemManage_Handler(void);
//__weak void Default_Handler_rom(void);
__weak void BusFault_Handler(void);
__weak void UsageFault_Handler(void);
//__weak void SecureFault_Handler(void);
__weak void SVC_Handler(void);
//__weak void DebugMon_Handler(void);
__weak void PendSV_Handler(void);
__weak void SysTick_Handler(void);

#if 0
__weak void System_Handler(void);
__weak void DSP_Handler(void);
__weak void RXI300_Handler(void);
__weak void SPI0_Handler(void);
__weak void I2C0_Handler(void);
__weak void ADC_Handler(void);
__weak void SPORT0_TX_Handler(void);
__weak void SPORT0_RX_Handler(void);
__weak void TIM_B0_Handler(void);
__weak void TIM_B1_Handler(void);
__weak void TIM_B2_Handler(void);
__weak void TIM_B3_Handler(void);
__weak void TIM_C0_Handler(void);
__weak void TIM_C1_Handler(void);
__weak void TIM_C2_Handler(void);
__weak void TIM_C3_Handler(void);
__weak void TIM_C4_Handler(void);
__weak void TIM_C5_Handler(void);
__weak void Enhanced_Timer0_Handler(void);
__weak void Enhanced_Timer1_Handler(void);
__weak void Enhanced_Timer2_Handler(void);
__weak void Enhanced_Timer3_Handler(void);
__weak void Enhanced_Timer4_Handler(void);
__weak void Enhanced_Timer5_Handler(void);
__weak void Enhanced_Timer6_Handler(void);
__weak void Enhanced_Timer7_Handler(void);
__weak void RTC_Handler(void);
__weak void UART2_Handler(void);
__weak void UART3_Handler(void);
__weak void UART4_Handler(void);
__weak void UART5_Handler(void);
__weak void UART6_Handler(void);
__weak void Peri_Handler(void);
__weak void GPIO_A0_Handler(void);
__weak void GPIO_A1_Handler(void);
__weak void GPIO_A_2_7_Handler(void);
__weak void GPIO_A_8_15_Handler(void);
__weak void GPIO_A_16_23_Handler(void);
__weak void GPIO_A_24_31_Handler(void);
__weak void GPIO_B_0_7_Handler(void);
__weak void GPIO_B_8_15_Handler(void);
__weak void GPIO_B_16_23_Handler(void);
__weak void GPIO_B_24_31_Handler(void);
__weak void GPIO_C_0_7_Handler(void);
__weak void GPIO_C_8_15_Handler(void);
__weak void GPIO_C_16_23_Handler(void);
__weak void GPIO_C_24_31_Handler(void);
__weak void GPIO_D_0_7_Handler(void);
__weak void GPIO_D_8_15_Handler(void);
__weak void GPIO_D_16_23_Handler(void);
__weak void GPIO_D_24_31_Handler(void);
__weak void GDMA0_Channel0_Handler(void);
__weak void GDMA0_Channel1_Handler(void);
__weak void GDMA0_Channel2_Handler(void);
__weak void GDMA1_Channel0_Handler(void);
__weak void GDMA1_Channel1_Handler(void);
__weak void GDMA1_Channel2_Handler(void);
__weak void GDMA1_Channel3_Handler(void);
__weak void GDMA1_Channel4_Handler(void);
__weak void GDMA1_Channel5_Handler(void);
__weak void GDMA1_Channel6_Handler(void);
__weak void GDMA1_Channel7_Handler(void);
__weak void GDMA2_Channel0_Handler(void);
__weak void GDMA2_Channel1_Handler(void);
__weak void GDMA2_Channel2_Handler(void);
__weak void GDMA2_Channel3_Handler(void);
__weak void GDMA2_Channel4_Handler(void);
__weak void GDMA2_Channel5_Handler(void);
__weak void GDMA2_Channel6_Handler(void);
__weak void GDMA2_Channel7_Handler(void);
__weak void GDMA2_Channel8_Handler(void);
__weak void GDMA2_Channel9_Handler(void);
__weak void GDMA2_Channel10_Handler(void);
__weak void GDMA2_Channel11_Handler(void);
__weak void GDMA2_Channel12_Handler(void);
__weak void GDMA2_Channel13_Handler(void);
__weak void GDMA2_Channel14_Handler(void);
__weak void GDMA2_Channel15_Handler(void);
__weak void SPORT1_RX_Handler(void);
__weak void SPORT1_TX_Handler(void);
__weak void SPORT2_RX_Handler(void);
__weak void SPORT2_TX_Handler(void);
__weak void SPORT3_RX_Handler(void);
__weak void SPORT3_TX_Handler(void);
__weak void SPI1_Handler(void);
__weak void SPI2_Handler(void);
__weak void SPI3_Handler(void);
__weak void I2C1_Handler(void);
__weak void I2C2_Handler(void);
__weak void I2C3_Handler(void);
__weak void IR_Handler(void);
__weak void KEYSCAN_Handler(void);
__weak void QDEC_Handler(void);
__weak void USB_Handler(void);
__weak void USB_ISO_Handler(void);
__weak void Utmi_Suspend_N_Handler(void);
__weak void SPIC0_Handler(void);
__weak void SPIC1_Handler(void);
__weak void SPIC2_Handler(void);
__weak void SPIC3_Handler(void);
__weak void PSRAMC_Handler(void);
__weak void LPCOMP_Handler(void);
__weak void SPDIF_TX_Handler(void);
__weak void ASRC0_Handler(void);
__weak void ASRC1_Handler(void);
__weak void I8080_Handler(void);
__weak void ISO7816_Handler(void);
__weak void SDIO0_Handler(void);
__weak void SDIO1_Handler(void);
__weak void ANC_Handler(void);
__weak void TOUCH_Handler(void);
__weak void MFB_DET_L_Handler(void);
__weak void VBAT_DET_Handler(void);
__weak void ADP_DET_Handler(void);
__weak void PTA_Mailbox_Handler(void);
__weak void TRNG_Handler(void);
__weak void ADP_IN_DET_Handler(void);
__weak void ADP_OUT_DET_Handler(void);
__weak void GPIOA0_Handler(void);
__weak void GPIOA1_Handler(void);
__weak void GPIOA2_Handler(void);
__weak void GPIOA3_Handler(void);
__weak void GPIOA4_Handler(void);
__weak void GPIOA5_Handler(void);
__weak void GPIOA6_Handler(void);
__weak void GPIOA7_Handler(void);
__weak void GPIOA8_Handler(void);
__weak void GPIOA9_Handler(void);
__weak void GPIOA10_Handler(void);
__weak void GPIOA11_Handler(void);
__weak void GPIOA12_Handler(void);
__weak void GPIOA13_Handler(void);
__weak void GPIOA14_Handler(void);
__weak void GPIOA15_Handler(void);
__weak void GPIOA16_Handler(void);
__weak void GPIOA17_Handler(void);
__weak void GPIOA18_Handler(void);
__weak void GPIOA19_Handler(void);
__weak void GPIOA20_Handler(void);
__weak void GPIOA21_Handler(void);
__weak void GPIOA22_Handler(void);
__weak void GPIOA23_Handler(void);
__weak void GPIOA24_Handler(void);
__weak void GPIOA25_Handler(void);
__weak void GPIOA26_Handler(void);
__weak void GPIOA27_Handler(void);
__weak void GPIOA28_Handler(void);
__weak void GPIOA29_Handler(void);
__weak void GPIOA30_Handler(void);
__weak void GPIOA31_Handler(void);
__weak void GPIOB0_Handler(void);
__weak void GPIOB1_Handler(void);
__weak void GPIOB2_Handler(void);
__weak void GPIOB3_Handler(void);
__weak void GPIOB4_Handler(void);
__weak void GPIOB5_Handler(void);
__weak void GPIOB6_Handler(void);
__weak void GPIOB7_Handler(void);
__weak void GPIOB8_Handler(void);
__weak void GPIOB9_Handler(void);
__weak void GPIOB10_Handler(void);
__weak void GPIOB11_Handler(void);
__weak void GPIOB12_Handler(void);
__weak void GPIOB13_Handler(void);
__weak void GPIOB14_Handler(void);
__weak void GPIOB15_Handler(void);
__weak void GPIOB16_Handler(void);
__weak void GPIOB17_Handler(void);
__weak void GPIOB18_Handler(void);
__weak void GPIOB19_Handler(void);
__weak void GPIOB20_Handler(void);
__weak void GPIOB21_Handler(void);
__weak void GPIOB22_Handler(void);
__weak void GPIOB23_Handler(void);
__weak void GPIOB24_Handler(void);
__weak void GPIOB25_Handler(void);
__weak void GPIOB26_Handler(void);
__weak void GPIOB27_Handler(void);
__weak void GPIOB28_Handler(void);
__weak void GPIOB29_Handler(void);
__weak void GPIOB30_Handler(void);
__weak void GPIOB31_Handler(void);
__weak void GPIOC0_Handler(void);
__weak void GPIOC1_Handler(void);
__weak void GPIOC2_Handler(void);
__weak void GPIOC3_Handler(void);
__weak void GPIOC4_Handler(void);
__weak void GPIOC5_Handler(void);
__weak void GPIOC6_Handler(void);
__weak void GPIOC7_Handler(void);
__weak void GPIOC8_Handler(void);
__weak void GPIOC9_Handler(void);
__weak void GPIOC10_Handler(void);
__weak void GPIOC11_Handler(void);
__weak void GPIOC12_Handler(void);
__weak void GPIOC13_Handler(void);
__weak void GPIOC14_Handler(void);
__weak void GPIOC15_Handler(void);
__weak void GPIOC16_Handler(void);
__weak void GPIOC17_Handler(void);
__weak void GPIOC18_Handler(void);
__weak void GPIOC19_Handler(void);
__weak void GPIOC20_Handler(void);
__weak void GPIOC21_Handler(void);
__weak void GPIOC22_Handler(void);
__weak void GPIOC23_Handler(void);
__weak void GPIOC24_Handler(void);
__weak void GPIOC25_Handler(void);
__weak void GPIOC26_Handler(void);
__weak void GPIOC27_Handler(void);
__weak void GPIOC28_Handler(void);
__weak void GPIOC29_Handler(void);
__weak void GPIOC30_Handler(void);
__weak void GPIOC31_Handler(void);
__weak void GPIOD0_Handler(void);
__weak void GPIOD1_Handler(void);
__weak void GPIOD2_Handler(void);
__weak void GPIOD3_Handler(void);
__weak void GPIOD4_Handler(void);
__weak void GPIOD5_Handler(void);
__weak void GPIOD6_Handler(void);
__weak void GPIOD7_Handler(void);
__weak void GPIOD8_Handler(void);
__weak void GPIOD9_Handler(void);
__weak void GPIOD10_Handler(void);
__weak void GPIOD11_Handler(void);
__weak void GPIOD12_Handler(void);
__weak void GPIOD13_Handler(void);
__weak void GPIOD14_Handler(void);
__weak void GPIOD15_Handler(void);
__weak void GPIOD16_Handler(void);
__weak void GPIOD17_Handler(void);
__weak void GPIOD18_Handler(void);
__weak void GPIOD19_Handler(void);
__weak void GPIOD20_Handler(void);
__weak void GPIOD21_Handler(void);
__weak void GPIOD22_Handler(void);
__weak void GPIOD23_Handler(void);
__weak void GPIOD24_Handler(void);
__weak void GPIOD25_Handler(void);
__weak void GPIOD26_Handler(void);
__weak void GPIOD27_Handler(void);
__weak void GPIOD28_Handler(void);
__weak void GPIOD29_Handler(void);
__weak void GPIOD30_Handler(void);
__weak void GPIOD31_Handler(void);
__weak void GPIO_A_6_31_Handler(void);
__weak void DSP_WDG_Handler(void);
__weak void D2H_Handler(void);
__weak void BTMAC_WRAP_AROUND_Handler(void);
__weak void Public_Key_Engine_Handler(void);
__weak void Flash_SEC0_Handler(void);
__weak void Flash_SEC1_Handler(void);
__weak void SHA2_Handler(void);
__weak void SHA3_Handler(void);
__weak void VADBUF_Handler(void);
__weak void VAD_Handler(void);
__weak void GPU_Handler(void);
__weak void MIPI_Handler(void);
__weak void Display_Handler(void);
__weak void IPC_KR0_Handler(void);
__weak void IPC_KM0_Handler(void);
__weak void ECC_Handler(void);
__weak void Slave_Port_Monitor_Handler(void);
__weak void SPI_Slave_Handler(void);
__weak void DSP_TX_ACK_Handler(void);
__weak void DSP_RX_REQ_Handler(void);
__weak void DSP_Report_Handler(void);
__weak void DSP_WDT_Handler(void);
__weak void BT_SYNC_CLK_Handler(void);
__weak void H2D_Handler(void);
__weak void D2H_INT1_Handler(void);
__weak void D2H_INT2_Handler(void);
__weak void D2H_INT3_Handler(void);
__weak void D2H_INT4_Handler(void);
__weak void D2H_INT5_Handler(void);
__weak void D2H_INT6_Handler(void);
__weak void D2H_INT7_Handler(void);
__weak void D2H_INT8_Handler(void);
__weak void SPI_PHY0_Handler(void);
__weak void SPI_PHY12_Handler(void);
__weak void SPI_PHY3_Handler(void);
#endif
#elif defined (__ARMCC_VERSION) && (__ARMCC_VERSION >= 6010050)
//__WEAK void Reset_Handler(void);
__WEAK void NMI_Handler(void);
//__WEAK void HardFault_Handler(void);
__WEAK void MemManage_Handler(void);
__WEAK void BusFault_Handler(void);
__WEAK void UsageFault_Handler(void);
__WEAK void SVC_Handler(void);
// __WEAK void DebugMon_Handler(void);
__WEAK void PendSV_Handler(void);
__WEAK void SysTick_Handler(void);
//__WEAK void Default_Handler_rom(void);

#if 0
__WEAK void System_Handler(void);
__WEAK void DSP_Handler(void);
__WEAK void RXI300_Handler(void);
__WEAK void SPI0_Handler(void);
__WEAK void I2C0_Handler(void);
__WEAK void ADC_Handler(void);
__WEAK void SPORT0_TX_Handler(void);
__WEAK void SPORT0_RX_Handler(void);
__WEAK void TIM_B0_Handler(void);
__WEAK void TIM_B1_Handler(void);
__WEAK void TIM_B2_Handler(void);
__WEAK void TIM_B3_Handler(void);
__WEAK void TIM_C0_Handler(void);
__WEAK void TIM_C1_Handler(void);
__WEAK void TIM_C2_Handler(void);
__WEAK void TIM_C3_Handler(void);
__WEAK void TIM_C4_Handler(void);
__WEAK void TIM_C5_Handler(void);
__WEAK void Enhanced_Timer0_Handler(void);
__WEAK void Enhanced_Timer1_Handler(void);
__WEAK void Enhanced_Timer2_Handler(void);
__WEAK void Enhanced_Timer3_Handler(void);
__WEAK void Enhanced_Timer4_Handler(void);
__WEAK void Enhanced_Timer5_Handler(void);
__WEAK void Enhanced_Timer6_Handler(void);
__WEAK void Enhanced_Timer7_Handler(void);
__WEAK void RTC_Handler(void);
__WEAK void UART2_Handler(void);
__WEAK void UART3_Handler(void);
__WEAK void UART4_Handler(void);
__WEAK void UART5_Handler(void);
__WEAK void UART6_Handler(void);
__WEAK void Peri_Handler(void);
__WEAK void GPIO_A0_Handler(void);
__WEAK void GPIO_A1_Handler(void);
__WEAK void GPIO_A_2_7_Handler(void);
__WEAK void GPIO_A_8_15_Handler(void);
__WEAK void GPIO_A_16_23_Handler(void);
__WEAK void GPIO_A_24_31_Handler(void);
__WEAK void GPIO_B_0_7_Handler(void);
__WEAK void GPIO_B_8_15_Handler(void);
__WEAK void GPIO_B_16_23_Handler(void);
__WEAK void GPIO_B_24_31_Handler(void);
__WEAK void GPIO_C_0_7_Handler(void);
__WEAK void GPIO_C_8_15_Handler(void);
__WEAK void GPIO_C_16_23_Handler(void);
__WEAK void GPIO_C_24_31_Handler(void);
__WEAK void GPIO_D_0_7_Handler(void);
__WEAK void GPIO_D_8_15_Handler(void);
__WEAK void GPIO_D_16_23_Handler(void);
__WEAK void GPIO_D_24_31_Handler(void);
__WEAK void GDMA0_Channel0_Handler(void);
__WEAK void GDMA0_Channel1_Handler(void);
__WEAK void GDMA0_Channel2_Handler(void);
__WEAK void GDMA1_Channel0_Handler(void);
__WEAK void GDMA1_Channel1_Handler(void);
__WEAK void GDMA1_Channel2_Handler(void);
__WEAK void GDMA1_Channel3_Handler(void);
__WEAK void GDMA1_Channel4_Handler(void);
__WEAK void GDMA1_Channel5_Handler(void);
__WEAK void GDMA1_Channel6_Handler(void);
__WEAK void GDMA1_Channel7_Handler(void);
__WEAK void GDMA2_Channel0_Handler(void);
__WEAK void GDMA2_Channel1_Handler(void);
__WEAK void GDMA2_Channel2_Handler(void);
__WEAK void GDMA2_Channel3_Handler(void);
__WEAK void GDMA2_Channel4_Handler(void);
__WEAK void GDMA2_Channel5_Handler(void);
__WEAK void GDMA2_Channel6_Handler(void);
__WEAK void GDMA2_Channel7_Handler(void);
__WEAK void GDMA2_Channel8_Handler(void);
__WEAK void GDMA2_Channel9_Handler(void);
__WEAK void GDMA2_Channel10_Handler(void);
__WEAK void GDMA2_Channel11_Handler(void);
__WEAK void GDMA2_Channel12_Handler(void);
__WEAK void GDMA2_Channel13_Handler(void);
__WEAK void GDMA2_Channel14_Handler(void);
__WEAK void GDMA2_Channel15_Handler(void);
__WEAK void SPORT1_RX_Handler(void);
__WEAK void SPORT1_TX_Handler(void);
__WEAK void SPORT2_RX_Handler(void);
__WEAK void SPORT2_TX_Handler(void);
__WEAK void SPORT3_RX_Handler(void);
__WEAK void SPORT3_TX_Handler(void);
__WEAK void SPI1_Handler(void);
__WEAK void SPI2_Handler(void);
__WEAK void SPI3_Handler(void);
__WEAK void I2C1_Handler(void);
__WEAK void I2C2_Handler(void);
__WEAK void I2C3_Handler(void);
__WEAK void IR_Handler(void);
__WEAK void KEYSCAN_Handler(void);
__WEAK void QDEC_Handler(void);
__WEAK void USB_Handler(void);
__WEAK void USB_ISO_Handler(void);
__WEAK void USB_Utmi_Suspend_N_Handler(void);

__WEAK void SPDIF_TX_Handler(void);
__WEAK void ASRC0_Handler(void);
__WEAK void ASRC1_Handler(void);
__WEAK void I8080_Handler(void);
__WEAK void ISO7816_Handler(void);
__WEAK void SDIO0_Handler(void);
__WEAK void SDIO1_Handler(void);
__WEAK void ANC_Handler(void);
__WEAK void TOUCH_Handler(void);
__WEAK void MFB_DET_L_Handler(void);
__WEAK void VBAT_DET_Handler(void);
__WEAK void ADP_DET_Handler(void);
__WEAK void PTA_Mailbox_Handler(void);
__WEAK void TRNG_Handler(void);
__WEAK void ADP_IN_DET_Handler(void);
__WEAK void ADP_OUT_DET_Handler(void);
__WEAK void GPIOA0_Handler(void);
__WEAK void GPIOA1_Handler(void);
__WEAK void GPIOA2_Handler(void);
__WEAK void GPIOA3_Handler(void);
__WEAK void GPIOA4_Handler(void);
__WEAK void GPIOA5_Handler(void);
__WEAK void GPIOA6_Handler(void);
__WEAK void GPIOA7_Handler(void);
__WEAK void GPIOA8_Handler(void);
__WEAK void GPIOA9_Handler(void);
__WEAK void GPIOA10_Handler(void);
__WEAK void GPIOA11_Handler(void);
__WEAK void GPIOA12_Handler(void);
__WEAK void GPIOA13_Handler(void);
__WEAK void GPIOA14_Handler(void);
__WEAK void GPIOA15_Handler(void);
__WEAK void GPIOA16_Handler(void);
__WEAK void GPIOA17_Handler(void);
__WEAK void GPIOA18_Handler(void);
__WEAK void GPIOA19_Handler(void);
__WEAK void GPIOA20_Handler(void);
__WEAK void GPIOA21_Handler(void);
__WEAK void GPIOA22_Handler(void);
__WEAK void GPIOA23_Handler(void);
__WEAK void GPIOA24_Handler(void);
__WEAK void GPIOA25_Handler(void);
__WEAK void GPIOA26_Handler(void);
__WEAK void GPIOA27_Handler(void);
__WEAK void GPIOA28_Handler(void);
__WEAK void GPIOA29_Handler(void);
__WEAK void GPIOA30_Handler(void);
__WEAK void GPIOA31_Handler(void);
__WEAK void GPIOB0_Handler(void);
__WEAK void GPIOB1_Handler(void);
__WEAK void GPIOB2_Handler(void);
__WEAK void GPIOB3_Handler(void);
__WEAK void GPIOB4_Handler(void);
__WEAK void GPIOB5_Handler(void);
__WEAK void GPIOB6_Handler(void);
__WEAK void GPIOB7_Handler(void);
__WEAK void GPIOB8_Handler(void);
__WEAK void GPIOB9_Handler(void);
__WEAK void GPIOB10_Handler(void);
__WEAK void GPIOB11_Handler(void);
__WEAK void GPIOB12_Handler(void);
__WEAK void GPIOB13_Handler(void);
__WEAK void GPIOB14_Handler(void);
__WEAK void GPIOB15_Handler(void);
__WEAK void GPIOB16_Handler(void);
__WEAK void GPIOB17_Handler(void);
__WEAK void GPIOB18_Handler(void);
__WEAK void GPIOB19_Handler(void);
__WEAK void GPIOB20_Handler(void);
__WEAK void GPIOB21_Handler(void);
__WEAK void GPIOB22_Handler(void);
__WEAK void GPIOB23_Handler(void);
__WEAK void GPIOB24_Handler(void);
__WEAK void GPIOB25_Handler(void);
__WEAK void GPIOB26_Handler(void);
__WEAK void GPIOB27_Handler(void);
__WEAK void GPIOB28_Handler(void);
__WEAK void GPIOB29_Handler(void);
__WEAK void GPIOB30_Handler(void);
__WEAK void GPIOB31_Handler(void);
__WEAK void GPIOC0_Handler(void);
__WEAK void GPIOC1_Handler(void);
__WEAK void GPIOC2_Handler(void);
__WEAK void GPIOC3_Handler(void);
__WEAK void GPIOC4_Handler(void);
__WEAK void GPIOC5_Handler(void);
__WEAK void GPIOC6_Handler(void);
__WEAK void GPIOC7_Handler(void);
__WEAK void GPIOC8_Handler(void);
__WEAK void GPIOC9_Handler(void);
__WEAK void GPIOC10_Handler(void);
__WEAK void GPIOC11_Handler(void);
__WEAK void GPIOC12_Handler(void);
__WEAK void GPIOC13_Handler(void);
__WEAK void GPIOC14_Handler(void);
__WEAK void GPIOC15_Handler(void);
__WEAK void GPIOC16_Handler(void);
__WEAK void GPIOC17_Handler(void);
__WEAK void GPIOC18_Handler(void);
__WEAK void GPIOC19_Handler(void);
__WEAK void GPIOC20_Handler(void);
__WEAK void GPIOC21_Handler(void);
__WEAK void GPIOC22_Handler(void);
__WEAK void GPIOC23_Handler(void);
__WEAK void GPIOC24_Handler(void);
__WEAK void GPIOC25_Handler(void);
__WEAK void GPIOC26_Handler(void);
__WEAK void GPIOC27_Handler(void);
__WEAK void GPIOC28_Handler(void);
__WEAK void GPIOC29_Handler(void);
__WEAK void GPIOC30_Handler(void);
__WEAK void GPIOC31_Handler(void);
__WEAK void GPIOD0_Handler(void);
__WEAK void GPIOD1_Handler(void);
__WEAK void GPIOD2_Handler(void);
__WEAK void GPIOD3_Handler(void);
__WEAK void GPIOD4_Handler(void);
__WEAK void GPIOD5_Handler(void);
__WEAK void GPIOD6_Handler(void);
__WEAK void GPIOD7_Handler(void);
__WEAK void GPIOD8_Handler(void);
__WEAK void GPIOD9_Handler(void);
__WEAK void GPIOD10_Handler(void);
__WEAK void GPIOD11_Handler(void);
__WEAK void GPIOD12_Handler(void);
__WEAK void GPIOD13_Handler(void);
__WEAK void GPIOD14_Handler(void);
__WEAK void GPIOD15_Handler(void);
__WEAK void GPIOD16_Handler(void);
__WEAK void GPIOD17_Handler(void);
__WEAK void GPIOD18_Handler(void);
__WEAK void GPIOD19_Handler(void);
__WEAK void GPIOD20_Handler(void);
__WEAK void GPIOD21_Handler(void);
__WEAK void GPIOD22_Handler(void);
__WEAK void GPIOD23_Handler(void);
__WEAK void GPIOD24_Handler(void);
__WEAK void GPIOD25_Handler(void);
__WEAK void GPIOD26_Handler(void);
__WEAK void GPIOD27_Handler(void);
__WEAK void GPIOD28_Handler(void);
__WEAK void GPIOD29_Handler(void);
__WEAK void GPIOD30_Handler(void);
__WEAK void GPIOD31_Handler(void);
__WEAK void GPIO_A_6_31_Handler(void);
__WEAK void DSP_WDG_Handler(void);
__WEAK void D2H_Handler(void);
__WEAK void BTMAC_WRAP_AROUND_Handler(void);
__WEAK void Public_Key_Engine_Handler(void);
__WEAK void Flash_SEC0_Handler(void);
__WEAK void Flash_SEC1_Handler(void);
__WEAK void SHA2_Handler(void);
__WEAK void SHA3_Handler(void);
__WEAK void VADBUF_Handler(void);
__WEAK void VAD_Handler(void);
__WEAK void COMP_Clk4_Handler(void);
__WEAK void COMP_Clk5_Handler(void);
__WEAK void COMP_Clk9_Handler(void);
__WEAK void COMP_Clk10_Handler(void);
__WEAK void GPU_Handler(void);
__WEAK void MIPI_Handler(void);
__WEAK void Display_Handler(void);
__WEAK void IPC_KR0_Handler(void);
__WEAK void IPC_KM0_Handler(void);
__WEAK void ECC_Handler(void);
__WEAK void Slave_Port_Monitor_Handler(void);
__WEAK void SPI_Slave_Handler(void);
__WEAK void LOG_KR0_Handler(void);
__WEAK void LOG_KM0_Handler(void);
__WEAK void AON_QDEC_Handler(void);

__WEAK void DSP_TX_ACK_Handler(void);
__WEAK void DSP_RX_REQ_Handler(void);
__WEAK void DSP_Report_Handler(void);
__WEAK void DSP_WDT_Handler(void);
__WEAK void BT_SYNC_CLK_Handler(void);
__WEAK void DSP_Event1_Handler(void);
__WEAK void DSP_Event2_Handler(void);
__WEAK void DSP_TO_HOST_Handler(void);
__WEAK void DSP_TO_HOST_FAST_Handler(void);

__WEAK void D2H_INT1_Handler(void);
__WEAK void D2H_INT2_Handler(void);
__WEAK void D2H_INT3_Handler(void);
__WEAK void D2H_INT4_Handler(void);
__WEAK void D2H_INT5_Handler(void);
__WEAK void D2H_INT6_Handler(void);
__WEAK void D2H_INT7_Handler(void);
__WEAK void D2H_INT8_Handler(void);

__WEAK void SPIC0_Handler(void);
__WEAK void SPIC1_Handler(void);
__WEAK void SPIC2_Handler(void);
__WEAK void SPIC3_Handler(void);
__WEAK void LPCOMP_Handler(void);
__WEAK void SPI_PHY0_Handler(void);
__WEAK void SPI_PHY12_Handler(void);
__WEAK void SPI_PHY3_Handler(void);
#endif
#endif

/**************************************************************************************************/

#ifdef __cplusplus
}
#endif

#endif // VECTOR_TABLE_H
