#ifndef _PLATFORM_CFG_H
#define _PLATFORM_CFG_H

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>


/*============================================================================*
 *                              Part2: Platform Config
*============================================================================*/
typedef enum
{
    TIMESTAMP_HW_TIMB_0 = 1,
    TIMESTAMP_MAX = 2
} T_TIMESTAMP_TYPE;

typedef struct RAM_CONFIG_
{
    uint32_t dtcm1: 8;
    uint32_t dtcm0: 8;
    uint32_t itcm1: 16;

    uint32_t cache: 8;
    uint32_t data_ram: 12;
    uint32_t reserved0: 12;

    uint32_t dsp_ram: 25;
    uint32_t dsp_dcache: 7;

    uint32_t dsp_icache: 6;
    uint32_t dsp_repair_ram: 16;
    uint32_t dsp_sys_ram: 3;
    uint32_t reserved1: 7;

} __attribute__((packed)) RAM_CONFIG;

enum
{
    MEMCFG_ACTIVE,
    MEMCFG_ACTIVE_SD,
    MEMCFG_LOWPOWER_LS,
    MEMCFG_LOWPOWER_DS,
    MEMCFG_LOWPOWER_SD,
    MEMCFG_MAX
};

/**
 * @struct SYS_INIT_CONFIG
 * @brief Platform EFuse settings.
 *
 * Refer to EFUSE[0x].
 */
typedef struct EFUSE_PLATFORM_CONFIG_
{
    uint32_t stack_en : 1;
    uint32_t cpu_sleep_en: 1;                      /* default = 0 */
    uint32_t systick_clk_src : 1; /* SYSTICK_EXTERNAL_CLOCK, SYSTICK_PROCESSOR_CLOCK */
    uint32_t printAllLogBeforeEnterLowpower: 1;    /* 0 for release version, 1 for debug version */
    uint32_t log_encode : 3;    /* 0: raw (default), 1: base64, 2~7: RSVD */
    uint32_t log_ram_size : 3;  /* actual size = 256 * (1 + log_ram_size) */
    uint32_t log_ram_type : 3;
    uint32_t log_output_if : 3;      /* bit0: uart (default), bit1: flash, bit2: usb, bit3~7: RSVD */
    uint32_t log_ram_num : 3;
    uint32_t timestamp_src : 2; /* 0: Use OS Tick, not sync, 1: Use HW Timer 7, 2: RSVD */
    uint32_t timestamp_div : 3;   /* HW Timer 7 divider when it is used as log timestamp */
    uint32_t share_dsp_ram_reg: 5;
    uint32_t os_max_syscall_interrupt_priority: 3;

    uint32_t systick_ext_clk_freq; /* External systick timer clock frequency */

    uint32_t adp_det_timeout : 8; /* ADP Det software debouncing timeout, 10ms per bit */
    uint32_t adc_mgr_queue : 4;
    uint32_t adc_channel : 10;    /* internal channel and differential channel. */
    uint32_t adc_ext_channel : 8; /* adc external channel load calibration data config */
    uint32_t ftl_use_mapping_table : 1;
    uint32_t ftl_init_in_rom : 1;

    uint16_t ftl_app_start_addr;
    uint16_t rsvd0;

    uint32_t reboot_record_address; /* start address of reboot record */

    uint32_t aes_iv[4];
    uint32_t aes_key[8];

    uint32_t config_file_key[4];   /* key from config file */
    RAM_CONFIG ram_cfg[MEMCFG_MAX];

    uint64_t trace_mask[4];

    uint64_t sys_init_param[16]; //EFUSE[150~1CF]

} __attribute__((packed)) SYS_INIT_CONFIG;

typedef enum
{
    SYSTICK_EXT_32K = 32000,
    SYSTICK_EXT_32K768 = 32768,
    SYSTICK_EXT_1M = 1000000,
} SYSTICK_EXT_CLK_FREQ_TYPE;

extern SYS_INIT_CONFIG sys_init_cfg;

#endif
