#ifndef EXT_MP_H
#define EXT_MP_H

/*============================================================================*
 *                               Header Files
 *============================================================================*/
#include "stdint.h"
#include "hci_uart.h"

/*============================================================================*
 *                              Definitions
 *============================================================================*/
#ifndef NULL
#define NULL (void *)0
#endif

/*============================================================================*
 *                              HCI cmds
 *============================================================================*/
#define HCI_VENDOR_MP                               0xFCEB
#define HCI_VENDOR_WDG_RESET                        0xFD10
#define HCI_VENDOR_READ_SAR_ADC                     0xFD12
#define HCI_VENDOR_CHARGER_TEST                     0xFC79
#define HCI_VENDOR_GPIO_CTRL                        0xFD13
#define HCI_VENDOR_MP_CONTROL_TX_POWER              0xFCE7
#define HCI_VENDOR_MP_ENABLE_TX_POWER_TRACKING      0xFCE8
#define HCI_VENDOR_MP_READ_TX_POWER_INFO            0xFCED
#define HCI_VENDOR_MP_K_POWER_SETTING               0xFD14
#define HCI_VENDOR_SINGLE_TONE_CONT_TX              0xFC78
#define HCI_VENDOR_MP_CONT_TX_BEGIN                 0xFCF1
#define HCI_VENDOR_MP_CONT_TX_STOP                  0xFCF2
#define HCI_VENDOR_MP_PACKET_TX_ENABLE_CONFIG       0xFCE0
#define HCI_VENDOR_MP_PACKET_TX_STOP                0xFCE1
#define HCI_VENDOR_MP_PACKET_RX_ENABLE_CONFIG       0xFCE2
#define HCI_VENDOR_MP_PACKET_RX_STOP                0xFCE3
#define HCI_VENDOR_MP_PACKET_TX_REPORT              0xFCE4
#define HCI_VENDOR_MP_PACKET_RX_REPORT              0xFCE5
#define HCI_VENDOR_DFT                              0xFD11
#define HCI_VENDOR_MP_GET_XTAL_VALUE                0xFCE9
#define HCI_VENDOR_MP_SET_XTAL_VALUE                0xFCEA
#define HCI_VENDOR_MP_CODEC_TEST                    0xFD8E
#define HCI_VENDOR_RF_HOPPING_TX_ENABLE             0xFD45
#define HCI_VENDOR_RF_HOPPING_TX_ENABLE_FOR_ADB     0xFC70
#define HCI_VENDOR_MP_VERSION_INFO                  0xFD9A

/*============================================================================*
 *                              Types
 *============================================================================*/
// PLATFORM_MP_MODULE_ID: 0x00 ~ 0x7F
// LOWERSTACK_MP_MODULE_ID: 0x80 ~ 0xFF
/*typedef enum
{
    LOWERSTACK_MP_MODULE_START = 0x80,
    LOWERSTACK_MP_MODULE_MAC = LOWERSTACK_MP_MODULE_START,
    LOWERSTACK_MP_MODULE_LEGACY,
    LOWERSTACK_MP_MODULE_LE,

    LOWERSTACK_MP_MODULE_NUM,
    LOWERSTACK_MP_MODULE_MAX = 0x100,
} LOWERSTACK_MP_MODULE_ID;*/

/*typedef enum
{
    LOWERSTACK_MP_MAC_CMD_MP_RESET,
    LOWERSTACK_MP_MAC_CMD_HW_VERSION,
    LOWERSTACK_MP_MAC_CMD_CAL_FW_VERSION,
    LOWERSTACK_MP_MAC_CMD_SYNC_WORD_TRANS,

    LOWERSTACK_MP_MAC_CMD_MAX,
} LOWERSTACK_MP_MAC_CMD;

typedef enum
{
    LOWERSTACK_MP_LEGACY_CMD_HOPPING_TX,
    LOWERSTACK_MP_LEGACY_CMD_HOPPING_RX,

    LOWERSTACK_MP_LEGACY_CMD_MAX,
} LOWERSTACK_MP_LEGACY_CMD;

typedef enum
{
    LOWERSTACK_MP_LE_CMD_HOPPING_TX,

    LOWERSTACK_MP_LE_CMD_MAX,
} LOWERSTACK_MP_LE_CMD;

typedef enum
{
    HOPPING_STOP,
    HOPPING_START,
} MP_HOPPING_CMD_TYPE;

typedef struct
{
    void *hopping_timer;
    void *hopping_start_timer;
    BOOLEAN ptt_en;
    UINT8 pkt_type;
    UINT16 pkt_length;
    BOOLEAN fix_channel;
    UINT8 start_channel;
    UINT8 channel_num;
    UINT8 channel_cnt;
    BOOLEAN whitening_en;

    MP_HOPPING_CMD_TYPE le_hopping_status;
} MP_HOPPING_PARAMETER;

typedef enum
{
    MP_VER_GET_HW_VERSION,
    MP_VER_GET_CAL_FW_VERSION,
    MP_VER_SET_HW_VERSION,
    MP_VER_SET_CAL_FW_VERSION,
    MP_VER_GET_PHY_VERSION,
} MP_VERSION_SUBCMD;*/

typedef union
{
    uint8_t value;
    struct
    {
        uint8_t use_mp_new_cmd: 1;
        uint8_t rsvd: 7;
    };
} MP_OPTION_STATUS;

/*============================================================================*
 *                              Status
 *============================================================================*/

/*============================================================================*
 *                              Variables
 *============================================================================*/
extern MP_OPTION_STATUS mp_option_status;

extern uint8_t (*platform_mp_handle_cmd_wrapper)(uint8_t module_id, uint8_t subcmd, uint8_t *param,
                                                 uint8_t *send_cmd_comp_event_flag);
extern uint8_t (*platform_mp_handle_event_wrapper)(uint8_t module_id, uint8_t subcmd,
                                                   uint8_t *param,
                                                   uint8_t *event_parameter);

extern uint8_t (*hci_ext_mp_cmd_func)(void *vhci_cmd_ptr, unsigned char *send_cmd_comp_event_flag,
                                      unsigned char *status, void **return_value);
extern uint8_t (*hci_ext_mp_generate_cmd_complete_func)(void *vhci_event_pkt_ptr,
                                                        unsigned char *param_length_ptr, void *return_value);
extern void (*mp_parameter_reset)(void);

/*============================================================================*
 *                              Functions
 *============================================================================*/

#endif /* EXT_MP_H */
