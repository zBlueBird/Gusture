#ifndef OCCD_PARSER
#define OCCD_PARSER

#include <stdint.h>

typedef struct ConfigHeaderSection
{
    uint32_t Signature_Field;
    uint16_t Data_Length;
    uint16_t Module_ID;
} __attribute__((packed)) ConfigHeaderSection_T;

typedef struct ConfigEntry
{
    uint16_t Offset;
    uint8_t  Length;
    uint8_t  *pData;
    uint8_t  *pMask;
} __attribute__((packed)) ConfigEntry_T;

typedef struct
{
    uint32_t *base;
    uint32_t size;
} MODULE_INFO;

typedef struct
{
    uint32_t Signature;
    uint32_t max_size;
    void *sys_cfg;
} PARSING_PARAMETER_FORMAT;

enum
{
    // Boot ROM
    MODULE_ID_BOOT_CFG = 0,
    MODULE_ID_CLOCK_TREE,
    MODULE_ID_BOOT_ROM_MAX,
    // Platform
    MODULE_ID_NS_BOOT_CFG = MODULE_ID_BOOT_ROM_MAX,
    MODULE_ID_SYS_INIT,
    MODULE_ID_PMU,
    MODULE_ID_OPERATION_MODE,
    MODULE_ID_SYS_ROM_MAX,
    // lowerstack
    MODULE_ID_LOWERSTACK = MODULE_ID_SYS_ROM_MAX,
    MODULE_ID_STACK_ROM_MAX,
    // upperstack
    MODULE_ID_UPPERSTACK = MODULE_ID_STACK_ROM_MAX,
    MODULE_ID_MAX,
};

enum
{
    PARSE_SUCCESS = 0,
    PARSE_ERROR_ID_MISMATCH,
    PARSE_ERROR_NO_CONFIG,               /*did not do the parsing operation*/
    PARSE_ERROR_ENTRY_SIZE_MISMATCH,     /*entry size do not match header legnth*/
    PARSE_ERROR_HEADER_LENGTH_MISMATCH,  /*header length > occd max size */
    PARSE_ERROR_MEM_OFFSET_EXCEED,       /*memory offset > memory size*/
};

uint32_t parse_sys_cfg_to_mem(PARSING_PARAMETER_FORMAT *p_parse_info, uint16_t id, uint8_t *mem,
                              uint32_t size);

#endif // OCCD_PARSER