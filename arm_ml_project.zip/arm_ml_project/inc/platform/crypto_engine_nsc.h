#ifndef _CRYPTO_ENGINE_NSC_H_
#define _CRYPTO_ENGINE_NSC_H_

#include <stdint.h>
#include <stdbool.h>

/* public key engine */
typedef enum
{
    ERR_NONE            = 0x0,
    ERR_PRIME           = 0x1,
    ERR_R2_MOD_N        = 0x2,
    ERR_ECC_ODD_POINT   = 0x4,
    ERR_ECC_Z           = 0x8,
    ERR_MODULAR_INV     = 0x10,
    ERR_N_ST_INPUT      = 0x20,
    ERR_NO_VALID_EXP    = 0x40,
    ERR_INVALID_INPUT   = 0x80,
} ERR_CODE;

typedef enum
{
    ECC_PRIME_MODE       = 0,   // 3'b000
    ECC_BINARY_MODE      = 1,   // 3'b001
    RSA_MODE             = 2,   // 3'b010
    ECC_EDWARDS_CURVE    = 3,   // 3'b011
    ECC_MONTGOMERY_CURVE = 7,   // 3'b111
} PKE_MODE;

typedef struct
{
    uint32_t x[16];
    uint32_t y[16];
    uint32_t z[16];
} ECC_POINT;

typedef struct
{
    uint32_t *N;    // modular, also called p
    uint32_t *A;    // curve parameter a
    uint32_t *B;    // curve parameter b
    uint32_t *n;    // order of G
    ECC_POINT G;    // base point

    uint32_t key_bits;
    PKE_MODE mode;

} ECC_GROUP;

void hw_pke_clock(bool enable);
void hw_pke_init(bool byte_swap_en, bool word_swap_en, uint32_t word_swap_base);

bool get_mbedtls_rsa_private_key_blinding_en();
void hw_rsa_init(uint32_t key_bits);
void hw_rsa_set_sub_operand(uint32_t operand_addr, uint32_t *operands, uint32_t byte_len);
bool hw_rsa_set_all_operands(uint32_t *M, uint32_t *e, uint32_t *N, uint32_t exp_byte_size);
ERR_CODE hw_rsa_compute(uint32_t *result, uint32_t output_addr, uint16_t func_id);

void hw_ecc_init(uint32_t key_bits, PKE_MODE mode, bool go_to_end_loop, bool RR_mod_n_ready);
void hw_ecc_set_sub_operand(uint32_t operand_addr, uint32_t *operands, uint32_t byte_len);
bool hw_ecc_set_all_operands(ECC_GROUP *grp, uint32_t *e, uint32_t e_byte_size);
ERR_CODE hw_ecc_compute(void *result, uint32_t output_addr, uint16_t func_id);

/* SHA2 */
typedef enum
{
    SHA2_224 = 28,
    SHA2_256 = 32,
    SHA2_384 = 48,
    SHA2_512 = 64
} HW_SHA2_ALGO;

typedef enum
{
    HW_SHA2_DMA_RO_MODE = 0,
    HW_SHA2_DMA_RW_MODE = 1,
    HW_SHA2_SLAVE_MODE  = 2
} HW_SHA2_ACCESS_MODE;

typedef struct
{
    uint64_t total[2];          /*!< The number of Bytes processed.  */
    uint8_t buffer[128];        /*!< The data block being processed. */
    uint32_t block_byte_size;   /*!< The block size of SHA2 (64 or 128). */
    HW_SHA2_ALGO algo;          /*!< SHA2 algorithm (SHA2 224/256/384/512) */
} SHA2_CTX;

typedef struct
{
    uint8_t *input;
    uint32_t byte_len;
    HW_SHA2_ALGO algo;
    HW_SHA2_ACCESS_MODE access_mode;
} SHA2_CFG;

bool hw_sha2(SHA2_CFG *sha2_config, uint32_t *result, uint8_t *dest_addr);
void hw_sha2_init(SHA2_CTX *ctx, HW_SHA2_ALGO algo, uint32_t *iv);
void hw_sha2_cpu_init();
bool hw_sha2_cpu_update(SHA2_CTX *ctx, const uint8_t *input, uint32_t byte_len);
bool hw_sha2_cpu_finish(SHA2_CTX *ctx, uint32_t *result);

/* OTP */
#define OTP_TOTAL_SIZE      8192 // 32bits*2048
typedef enum
{
    OTP_OPERATION_BYTE_READ = 0,
    OTP_OPERATION_BYTE_WRITE = 1,
    OTP_OPERATION_WORD_READ = 2,
    OTP_OPERATION_WORD_WRITE = 3,
} OTP_OPERATION_TYPE;

bool otp_access(OTP_OPERATION_TYPE type, uint16_t addr, uint8_t *data, uint16_t byte_size);
void otp_set_protect(void);
void otp_get_otp_ram_data(uint8_t *output, uint16_t address, uint16_t byte_len);

#endif
