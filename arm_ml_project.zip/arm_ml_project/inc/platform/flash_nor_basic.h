/**
 *****************************************************************************************
 *     Copyright(c) 2018, Realtek Semiconductor Corporation. All rights reserved.
 *****************************************************************************************
 * @file    flash_nor_basic.h
 * @brief   Nor flash basic implementation header file
 * @author  Yao-Yu
 * @date    2020-07-08
 * @version v0.1
 * ***************************************************************************************
 */

#ifndef _FLASH_NOR_BASIC_H
#define _FLASH_NOR_BASIC_H

#include <stdint.h>
#include "flash_nor_basic_nsc.h"

extern FLASH_NOR_INFO_STRUCT flash_nor_info[FLASH_NOR_IDX_MAX];

/****************************************************************************************
 * Nor Flash non secure Function
 ****************************************************************************************/
FLASH_NOR_RET_TYPE flash_nor_hook_func(void);
uint32_t flash_nor_get_flash_size(FLASH_NOR_IDX_TYPE idx);
uint32_t flash_nor_get_resume_to_suspend_delay_time(FLASH_NOR_IDX_TYPE idx);
FLASH_NOR_RET_TYPE flash_nor_get_tb_bit(FLASH_NOR_IDX_TYPE idx, bool *from_bottom);
FLASH_NOR_RET_TYPE flash_nor_set_tb_bit(FLASH_NOR_IDX_TYPE idx, bool from_bottom);
FLASH_NOR_RET_TYPE flash_nor_get_bp_all_lv(FLASH_NOR_IDX_TYPE idx, uint8_t *bp_lv);
FLASH_NOR_IDX_TYPE flash_nor_get_idx_by_addr(uint32_t addr);
FLASH_NOR_RET_TYPE flash_nor_get_offset_by_idx(FLASH_NOR_IDX_TYPE idx, uint32_t *addr);
uint32_t flash_nor_get_noncache_addr(FLASH_NOR_IDX_TYPE idx, uint32_t addr);


/****************************************************************************************
 * Nor Flash Extern Variables
 ****************************************************************************************/
extern FLASH_NOR_RET_TYPE(*flash_nor_write_enable)(FLASH_NOR_IDX_TYPE idx,
                                                   FLASH_NOR_WREN_MODE mode);
extern FLASH_NOR_RET_TYPE(*flash_nor_get_regs_bits)(FLASH_NOR_IDX_TYPE idx, uint32_t *reg_bits,
                                                    uint32_t reg_mask);
extern FLASH_NOR_RET_TYPE(*flash_nor_set_regs_bits)(FLASH_NOR_IDX_TYPE idx, uint32_t reg_bits,
                                                    uint32_t reg_mask);

extern FLASH_NOR_RET_TYPE(*flash_nor_get_bp_lv)(FLASH_NOR_IDX_TYPE idx, uint8_t *bp_lv);
extern FLASH_NOR_RET_TYPE(*flash_nor_set_bp_lv)(FLASH_NOR_IDX_TYPE idx, uint8_t bp_lv);
extern FLASH_NOR_RET_TYPE(*flash_nor_read)(uint32_t addr, uint8_t *data, uint32_t byte_len);
extern FLASH_NOR_RET_TYPE(*flash_nor_write)(uint32_t addr, uint8_t *data, uint32_t byte_len);
extern FLASH_NOR_RET_TYPE(*flash_nor_erase)(uint32_t addr, FLASH_NOR_ERASE_MODE mode);
extern FLASH_NOR_RET_TYPE(*flash_nor_unlock_bp_by_addr)(uint32_t addr, uint8_t *old_bp_lv);
extern FLASH_NOR_RET_TYPE(*flash_nor_unlock_write)(uint32_t addr, uint8_t *data, uint32_t byte_len);
extern FLASH_NOR_RET_TYPE(*flash_nor_unlock_erase)(uint32_t addr, FLASH_NOR_ERASE_MODE mode);
extern FLASH_NOR_RET_TYPE(*flash_nor_set_dum_byte)(FLASH_NOR_IDX_TYPE idx);

#endif
