/*============================================================================*
 *               Define to prevent recursive inclusion
 *============================================================================*/
#ifndef __THERMAL_H
#define __THERMAL_H

/*============================================================================*
 *                               Header Files
 *============================================================================*/
#include <stdint.h>
#include "os_queue.h"

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*
 *                              Types
 *============================================================================*/
typedef union
{
    uint8_t value;
    struct
    {
        uint8_t thermal_tracking_enable: 1;
        uint8_t rsvd: 7;
    };
} ThermalFeatureCfg;

typedef struct
{
    uint8_t thermal_now;
    uint8_t thermal_interval_us;
    T_OS_QUEUE thermal_tracking_callback_func_queue;
} ThermalManager;

typedef void (*ThermalTrackingCbFunc)(void);

typedef struct
{
    struct ThermalTrackingCbFuncQueueElem *pNext;
    void *cb_func;
} ThermalTrackingCbFuncQueueElem;

/*============================================================================*
 *                              Variables
 *============================================================================*/
extern uint8_t (*get_thermal_meter)(void);
extern int16_t (*get_thermal_meter_celsius)(void);
extern int16_t (*get_thermal_meter_celsius_delta)(uint8_t, uint8_t);
extern void (*thermal_meter_trigger)(void);
extern void (*thermal_meter_read)(void);
extern void (*thermal_meter_update)(void);
extern bool (*thermal_tracking_register_callback_func)(void *);
extern void (*thermal_tracking)(void);

/*============================================================================*
 *                              Functions
 *============================================================================*/

#ifdef __cplusplus
}
#endif

#endif  /* __THERMAL_H */

