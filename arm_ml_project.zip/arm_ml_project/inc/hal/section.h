/**
*****************************************************************************************
*     Copyright(c) 2017, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
  * @file    section.h
  * @brief
  * @author
  * @date    2022.4.27
  * @version v1.0
   **************************************************************************************
   * @attention
   * <h2><center>&copy; COPYRIGHT 2017 Realtek Semiconductor Corporation</center></h2>
   * *************************************************************************************
  */

/*============================================================================*
 *                      Define to prevent recursive inclusion
 *============================================================================*/
#ifndef _SECTION_H
#define _SECTION_H

#include "app_section.h"

/** @defgroup APP_SECTION APP Section
  * @brief memory section definition for user application.
  * @{
  */

/*============================================================================*
 *                              Macro
*============================================================================*/
/** @defgroup APP_SECTION_Exported_Macros APP Section Sets Exported Macros
    * @{
    */
/** @defgroup APP_FLASH_SECTION APP Flash Section
    *@brief  const data or flash function
    * @{
    */

/** @} */

/** @defgroup APP_RAM_SECTION RAM Data Section
    *@brief  global variable or ram function,  data on (default)
    * @{
    */

/** @} */

/** @} */

/** @defgroup APP_FUNCTION_SECTION RAM Function Section Sets
    *@brief  ram code
    * @{
    */



/** @} */



/** @} */ /* End of group APP_SECTION */



#endif // _SECTION_H
