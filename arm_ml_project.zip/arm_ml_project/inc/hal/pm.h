/**
*****************************************************************************************
*     Copyright(c) 2017, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
  * @file    pm.h
  * @brief   This file provides apis for power manager.
  * @author  Grace
  * @date    2022-04-27
  * @version v1.0
  * *************************************************************************************
   * @attention
   * <h2><center>&copy; COPYRIGHT 2017 Realtek Semiconductor Corporation</center></h2>
   * *************************************************************************************
  */

/*============================================================================*
 *               Define to prevent recursive inclusion
 *============================================================================*/
#ifndef __PM_H_
#define __PM_H_


/*============================================================================*
 *                               Header Files
*============================================================================*/
#include <stdint.h>
#include <stdbool.h>
#include "errno.h"
#include "clock.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @addtogroup HAL_87x3e_PM
  * @brief
  * @{
  */

/*============================================================================*
 *                              Variables
*============================================================================*/
/** @defgroup PM_Exported_Variables PM Exported Variables
  * @{
  */
typedef enum POWER_CheckResult
{
    POWER_CHECK_PEND               = 0,
    POWER_CHECK_FAIL               = 1,
    POWER_CHECK_PASS               = 2,
} POWER_CheckResult;

typedef enum
{
    BTPOWER_DEEP_SLEEP        = 0,   /**< Deep sleep */
    BTPOWER_ACTIVE            = 1,   /**< Active     */
} BtPowerMode;


/** @brief POWER STAGE struct */
typedef enum
{
    POWER_STAGE_STORE           = 0,
    POWER_STAGE_RESTORE         = 1,
} POWERStage;

/** @brief LPSMode struct */
typedef enum
{
    POWER_POWEROFF_MODE    = 0,
    POWER_POWERDOWN_MODE   = 1,   /**< Power down */
    POWER_DLPS_MODE        = 2,   /**< DLPS       */
    POWER_ACTIVE_MODE      = 3,    /**< Active     */
    POWER_MODE_MAX         = 4
} POWERMode;

typedef enum
{
    PM_EXCLUDED_TIMER,
    PM_EXCLUDED_TASK,
    PM_EXCLUDED_TYPE_MAX,
} PowerModeExcludedHandleType;


typedef enum
{
    POWER_SCENARIO_OPERATION_MODE,
    POWER_SCENARIO_VAD_MODE,
    POWER_SCENARIO_USB_SUSPEND_MODE,
    POWER_SCENARIO_MAX,
} POWERScenarioMode;

typedef enum
{
    SCENARIO_OPERATION_HP_MODE               = 0,
    SCENARIO_OPERATION_SENSOR_MODE           = 1,
} ScenarioOperationMode;

typedef enum
{
    SCENARIO_VAD_DISABLE_MODE                = 0,
    SCENARIO_VAD_ENABLE_MODE                 = 1,
} ScenarioVADMode;

typedef enum
{
    SCENARIO_USB_SUSPEND_DISABLE_MODE        = 0,
    SCENARIO_USB_SUSPEND_ENABLE_MODE         = 1,
} ScenarioUSBSuspendMode;

/* for Operation mode callback */
/* POWER_SCENARIO_OPERATION_STAGE_CHECK:
 *     for APP to check operation mode can be changed or not, callback prototype as OperationModeSystemCheckFunc
 *         parameter: operation mode to be changed into
 *         return value: check pass or not
 * POWER_SCENARIO_OPERATION_STAGE_ENTER:
 *     for APP to do necessary instruction before operation mode changed, callback prototype as OperationModeSystemEnterFunc
 *         parameter: operation mode to be changed into
 */
typedef enum
{
    POWER_SCENARIO_OPERATION_STAGE_CHECK     = 1,
    POWER_SCENARIO_OPERATION_STAGE_ENTER     = 2,
} POWERScenarioOperationModeStage;

typedef enum
{
    POWER_IO_ALWAYS_ENABLE,
    POWER_IO_ENABLE_EXCEPT_POWEROFF,
    POWER_IO_ENABLE_WHEN_DLPS,
    POWER_IO_ENABLE_ONLY_ACTIVE,
} PowerIOMode;

typedef enum
{
    PM_SUCCESS                         = 0x0,
    PM_DVFS_BUSY                       = -0x1,
    PM_DVFS_VOLTAGE_FAIL               = -0x2,
    PM_DVFS_CONDITION_FAIL             = -0x4,
    PM_DVFS_SRAM_FAIL                  = -0x8,
    PM_DVFS_NOT_SUPPORT                = -0x10,
} PMErrorCode;

typedef enum PMVSRAM
{
    PM_VSRAM4_2  = 0x0001, //640KB: DSP RAM: 0xCA_4000 - 0xD4_4000; SHARE RAM: 0x80_0000 - 0x8A_0000
    PM_VSRAM4_1  = 0x0002, //256KB: DSP RAM: 0xC6_0000 - 0xCA_0000; SHARE RAM: 0x8A_0000 - 0x8E_0000
    PM_VSRAM4_0  = 0x0004, //400KB: DSP RAM: 0xC0_0000 - 0xC6_0000, 0xCA_0000 - 0xCA_40000; SHARE RAM: 0x8E_0000 - 0x94_4000
    PM_VSRAM3_3  = 0x0008, //2048KB: DATA RAM: 0x60_0000 - 0x80_0000
    PM_VSRAM3_2  = 0x0010, // 512KB: DATA RAM: 0x58_0000 - 0x60_0000
    PM_VSRAM3_1  = 0x0020, // 256KB: DATA RAM: 0x54_0000 - 0x58_0000
    PM_VSRAM3_0  = 0x0040, // 256KB: DATA RAM: 0x50_0000 - 0x54_0000
//    PM_VSRAM2_2  = 0x0080, // 64KB: DTCM1: 0x46_0000 - 0x47_0000; 192KB: ITCM1: 0x41_0000 - 0x44_0000
//    PM_VSRAM2_1  = 0x0100, // 64KB: DTCM0: 0x45_0000 - 0x46_0000;  64KB: ITCM1: 0x40_0000 - 0x41_0000
//    PM_VSRAM2_0  = 0x0200, // 64KB: DTCM0: 0x44_0000 - 0x45_0000;  64KB: DTCM1: 0x47_0000 - 0x48_0000
//    PM_VSRAM1    = 0x0400,
} PMVSRAM;


#define PM_SENSOR_SUCCESS              0x0
#define PM_SENSOR_CLK_KM4              0x1
#define PM_SENSOR_CLK_DSP              0x2
#define PM_SENSOR_CLK_SPIC0            0x4
#define PM_SENSOR_CLK_SPIC1            0x8
#define PM_SENSOR_CLK_SPIC2            0x10
#define PM_SENSOR_CLK_SPIC3            0x20
#define PM_SENSOR_CLK_RTK_TIMER        0x40
#define PM_SENSOR_CLK_SDIO0            0x80
#define PM_SENSOR_CLK_SDIO1            0x100
#define PM_SENSOR_CLK_DISPLAY_CTRL     0x200
#define PM_SENSOR_CLK_USB              0x400
#define PM_SENSOR_CLK_LOW              0x800
#define PM_SENSOR_CLK_S5               0x1000
#define PM_SENSOR_CLK_S7               0x2000
#define PM_SENSOR_CLK_S11              0x4000

/** @brief This CB is used for any module which needs to be checked before entering DLPS */
typedef POWER_CheckResult(*POWERCheckFunc)();

/** @brief This CB is used for any module which needs to control the hw before entering or after exiting from DLPS */
typedef void (*POWERStageFunc)();

/** @} */ /* End of group DLPS_PLATFORM_Exported_Variables */

/*============================================================================*
 *                              Functions
*============================================================================*/
/** @defgroup DLPS_PLATFORM_Exported_Functions DLPS Platform Exported Functions
  * @{
  */

/**
 * @brief Register Check CB to Power module which will call it before entering Dlps.
 * @param  func  DLPSEnterCheckFunc.
 * @return  Status of Operation.
*/
int32_t power_check_cb_register(POWERCheckFunc func);


/**
 * @brief Register HW Control CB to Power module which will call it before entering power mode or after exiting from power mode (according to POWERStage) .
 * @param  func  POWERStageFunc.
 * @param  stage  tell the Power module the CB should be called when @ref POWER_STAGE_ENTER or POWER_STAGE_EXIT.
 * @return  Status of Operation.
*/
int32_t power_stage_cb_register(POWERStageFunc func, POWERStage stage);

/**
 * @brief  POWERMode Set .
 * @param  mode   POWERMode.
 * @return  none
*/
int32_t power_mode_set(POWERMode mode);

/**
 * @brief  POWERMode Get .
 * @param  none
 * @return  POWERMode
*/
POWERMode power_mode_get(void);

/**
 * @brief  POWERMode Pause .
 * @param  none
 * @return  void
*/
int32_t power_mode_pause(void);

/**
 * @brief  POWERMode Resume .
 * @param  none
 * @return  void
*/
int32_t power_mode_resume(void);

/**
 * @brief Register HW Control CB to Power module which will call it before entering power mode or after exiting from power mode (according to POWERStage) .
 * @param  func  POWERStageFunc.
 * @param  stage  tell the Power module the CB should be called when @ref POWER_STAGE_ENTER or POWER_STAGE_EXIT.
 * @return  Status of Operation.
*/
int32_t power_scenario_stage_cb_register(POWERStageFunc func,
                                         POWERScenarioOperationModeStage stage);

/**
 * @brief  POWERScenarioMode Get .
 * @param  mode  specificed mode
  * @param  mode_value  specificed mode value @ref ScenarioOperationMode, ScenarioVADMode or ScenarioUSBSuspendMode
 * @return  Status of Operation.
*/
int32_t power_scenario_mode_set(POWERScenarioMode mode, uint8_t mode_value);

/**
 * @brief  POWERScenarioMode Get .
 * @param  mode  specificed mode
 * @return scenario Mode value @ref ScenarioOperationMode, ScenarioVADMode or ScenarioUSBSuspendMode
*/
uint8_t power_scenario_mode_get(POWERScenarioMode mode);

/**
 * @brief  PowerIOMode Set .
 * @param  mode  specificed mode
 * @return Status of Operation.
*/
int32_t io_power_mode_set(PowerIOMode mode);

/**
 * @brief  check if clock allow to enter sensor mode.
 * @return Status of check result.
*/
uint32_t pm_sensor_mode_clock_check(void);

/**
 * @brief  set_vsram_retention_in_sensor_mode
 * @param  vsram block to be set
 * @param  whether retention in sensor mode
*/
void sensor_mode_set_vsram_retention(PMVSRAM vsram, bool enable);

#ifdef __cplusplus
}
#endif

#endif
