/**
*****************************************************************************************
*     Copyright(c) 2017, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
* @file    fmc_api.h
* @brief   This file provides fmc api wrapper for sdk customer.
* @author  yuhungweng
* @date    2020-11-26
* @version v1.0
* *************************************************************************************
*/

#ifndef __FMC_API_H_
#define __FMC_API_H_
#include <stdbool.h>
#include <stdint.h>

#define FMC_SEC_SECTION_LEN     0x1000
#define FLASH_IMG_VPDATA        FLASH_IMG_MCUAPPDATA1

typedef enum
{
    FMC_FLASH_NOR_IDX0,
    FMC_FLASH_NOR_IDX1,
    FMC_FLASH_NOR_IDX2,
    FMC_FLASH_NOR_IDX3
} FMC_FLASH_NOR_IDX_TYPE;

typedef enum
{
    FMC_FLASH_NOR_ERASE_CHIP   = 1,
    FMC_FLASH_NOR_ERASE_SECTOR = 2,
    FMC_FLASH_NOR_ERASE_BLOCK  = 4,
} FMC_FLASH_NOR_ERASE_MODE;

typedef enum
{
    PARTITION_FLASH_OCCD,
    PARTITION_FLASH_BOOT_PATCH,
    PARTITION_FLASH_OTA_BANK_0,
    PARTITION_FLASH_OTA_BANK_1,
    PARTITION_FLASH_RO_DATA1,
    PARTITION_FLASH_RO_DATA2,
    PARTITION_FLASH_RO_DATA3,
    PARTITION_FLASH_RO_DATA4,
    PARTITION_FLASH_RO_DATA5,
    PARTITION_FLASH_RO_DATA6,
    PARTITION_FLASH_BKP_DATA1,
    PARTITION_FLASH_BKP_DATA2,
    PARTITION_FLASH_OTA_TMP,
    PARTITION_FLASH_FTL,

} T_FLASH_PARTITION_NAME;

typedef enum _FLASH_IMG_ID
{
    FLASH_IMG_OTA                  = 0, /* OTA header */
    FLASH_IMG_SECURE_PATCH         = 1,
    FLASH_IMG_MCUPATCH             = 2,
    FLASH_IMG_MCUAPP               = 3,
    FLASH_IMG_DSPSYSTEM            = 4,
    FLASH_IMG_DSPAPP               = 5,
    FLASH_IMG_MCUCONFIG            = 6,
    FLASH_IMG_DSPCONFIG            = 7,
    FLASH_IMG_MCUAPPDATA1          = 8,
    FLASH_IMG_MCUAPPDATA2          = 9,
    FLASH_IMG_MCUAPPDATA3          = 10,
    FLASH_IMG_MCUAPPDATA4          = 11,
    FLASH_IMG_MCUAPPDATA5          = 12,
    FLASH_IMG_MCUAPPDATA6          = 13,
    FLASH_IMG_UPPERSTACK           = 14,
    FLASH_IMG_MAX,
} FLASH_IMG_ID;

typedef void (*FMC_FLASH_NOR_ASYNC_CB)(void);

/**
 * @brief           task-safe of @ref flash_nor_read
 * @param addr      the ram address mapping of nor flash going to be read
 * @param data      data buffer to be read into
 * @param len       read data length
 * @return          true if read successful, otherwise false
 */
bool fmc_flash_nor_read(uint32_t addr, void *data, uint32_t len);

/**
 * @brief           task-safe of @ref flash_nor_write
 * @param addr      the ram address mapping of nor flash going to be written
 * @param data      data buffer to be write into
 * @param len       write data length
 * @return          true if write successful, otherwise false
 */
bool fmc_flash_nor_write(uint32_t addr, void *data, uint32_t len);

/**
 * @brief           task-safe of @ref flash_nor_erase
 * @param addr      the ram address mapping of nor flash going to be erased
 * @param mode      erase mode defined as @ref FMC_FLASH_NOR_ERASE_MODE
 * @return          true if erase successful, otherwise false
 */
bool fmc_flash_nor_erase(uint32_t addr, FMC_FLASH_NOR_ERASE_MODE mode);

bool fmc_flash_nor_auto_dma_read(uint32_t src, uint32_t dst, uint32_t len,
                                 FMC_FLASH_NOR_ASYNC_CB cb);

bool fmc_flash_nor_set_bp_lv(uint32_t addr, uint8_t bp_lv);

bool fmc_flash_nor_get_bp_lv(uint32_t addr, uint8_t *bp_lv);

uint32_t flash_partition_addr_get(T_FLASH_PARTITION_NAME name);

uint32_t flash_partition_size_get(T_FLASH_PARTITION_NAME name);

uint32_t flash_cur_bank_img_payload_addr_get(FLASH_IMG_ID id);

uint32_t flash_cur_bank_img_header_addr_get(FLASH_IMG_ID id);

bool fmc_flash_nor_clock_switch(FMC_FLASH_NOR_IDX_TYPE idx, uint32_t required_mhz,
                                uint32_t *actual_mhz);



//bool fmc_psram_clock_switch(CLK_FREQ_TYPE clk);

#endif

