/*
 * Copyright (c) 2018, Realsil Semiconductor Corporation. All rights reserved.
 */

#ifndef _AUDIO_HAL_CFG_H_
#define _AUDIO_HAL_CFG_H_

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define DATA_SYNC_WORD              0xAA55AA55
#define DATA_SYNC_WORD_LEN          4

#define APP_CONFIG_OFFSET           (0)
#define APP_CONFIG_SIZE             1024
#define APP_LED_OFFSET              (APP_CONFIG_OFFSET + APP_CONFIG_SIZE)
#define APP_LED_SIZE                512

#define AUDIO_ROUTE_CFG_OFFSET      (APP_LED_OFFSET + APP_LED_SIZE)
#define AUDIO_ROUTE_CONFIG_SIZE     (512 - 64)

#define AUDIO_HAL_CONFIG_OFFSET     (AUDIO_ROUTE_CFG_OFFSET + AUDIO_ROUTE_CONFIG_SIZE)
#define AUDIO_HAL_CONFIG_SIZE       64

typedef struct
{
    // Header: 4 bytes
    uint32_t sync_word;

    uint8_t sport0_lrc_pinmux;
    uint8_t sport0_bclk_pinmux;
    uint8_t sport0_adc_dat_pinmux;
    uint8_t sport0_dac_dat_pinmux;

    uint8_t sport1_lrc_pinmux;
    uint8_t sport1_bclk_pinmux;
    uint8_t sport1_adc_dat_pinmux;
    uint8_t sport1_dac_dat_pinmux;

    uint8_t sport2_lrc_pinmux;
    uint8_t sport2_bclk_pinmux;
    uint8_t sport2_adc_dat_pinmux;
    uint8_t sport2_dac_dat_pinmux;

    uint8_t sport3_lrc_pinmux;
    uint8_t sport3_bclk_pinmux;
    uint8_t sport3_adc_dat_pinmux;
    uint8_t sport3_dac_dat_pinmux;

    uint8_t sport_ext_mclk_pinmux;
    uint8_t rsvd0[3];

    uint8_t spdif0_tx_pinmux;
    uint8_t spdif0_rx_pinmux;
    uint8_t rsvd1[2];

    uint8_t dmic1_clk_pinmux;
    uint8_t dmic1_dat_pinmux;
    uint8_t dmic2_clk_pinmux;
    uint8_t dmic2_dat_pinmux;
    uint8_t dmic3_clk_pinmux;
    uint8_t dmic3_dat_pinmux;
    uint8_t dmic4_clk_pinmux;
    uint8_t dmic4_dat_pinmux;

    uint8_t rsvd3;
    uint8_t micbias_gpio_pinmux;
    uint8_t rsvd4[2];

    uint8_t sport0_tx_bridge: 1;
    uint8_t sport0_rx_bridge: 1;
    uint8_t sport1_tx_bridge: 1;
    uint8_t sport1_rx_bridge: 1;
    uint8_t sport2_tx_bridge: 1;
    uint8_t sport2_rx_bridge: 1;
    uint8_t sport3_tx_bridge: 1;
    uint8_t sport3_rx_bridge: 1;

    uint8_t dsp_log_output_select: 2;
    uint8_t mic2_aux_co_pad: 1;
    uint8_t rsvd5: 5;

    uint8_t rsvd6[2];

    // Audio SPK class type and Power Mode
    uint32_t spk1_class: 1;  // 0: class D, 1: class AB
    uint32_t spk2_class: 1;  // 0: class D, 1: class AB
    uint32_t amic1_class: 2; // 0: normal mode 1: low power mode, for AMIC1 & 2
    uint32_t amic2_class: 2; // 0: normal mode 1: low power mode, for AMIC1 & 2
    uint32_t amic3_class: 2; // 0: normal mode 1: HSNR mode, for AMIC3,& 4
    uint32_t amic4_class: 2; // 0: normal mode 1: HSNR mode, for AMIC3 & 4
    uint32_t aux_l_class: 2; // 0: normal mode 1: low power mode, for AUX_L & R
    uint32_t aux_r_class: 2; // 0: normal mode 1: low power mode, for AUX_L & R
    uint32_t dac0_filter_type: 1; // 0: linear phase, 1: minimum phase
    uint32_t dac1_filter_type: 1; // 0: linear phase, 1: minimum phase
    uint32_t dac2_filter_type: 1; // 0: linear phase, 1: minimum phase
    uint32_t rsvd7: 15;

    uint32_t dmic1_clock: 3;
    uint32_t dmic2_clock: 3;
    uint32_t dmic3_clock: 3;
    uint32_t micbias_voltage_sel: 3;
    uint32_t micbias_ext_ldo_ctrl: 1;
    uint32_t avcc_drv_voltage_sel: 2;
    uint32_t dmic4_clock: 3;
    uint32_t rsvd8: 14;

    // Condition of use of the audio pad
    uint32_t aout_l_p: 1;
    uint32_t aout_l_n: 1;
    uint32_t aout_r_p: 1;
    uint32_t aout_r_n: 1;
    uint32_t mic1_p:   1;
    uint32_t mic1_n:   1;
    uint32_t mic2_p:   1;
    uint32_t mic2_n:   1;
    uint32_t mic3_p:   1;
    uint32_t mic3_n:   1;
    uint32_t mic4_p:   1;
    uint32_t mic4_n:   1;
    uint32_t aux_l:    1;
    uint32_t aux_r:    1;
    uint32_t rsvd9:    18;
} T_AUDIO_HAL_CFG;

extern T_AUDIO_HAL_CFG audio_hal_cfg;

void audio_hal_cfg_load(void);

#ifdef __cplusplus
}
#endif

#endif /*_AUDIO_HAL_CFG_H_*/
