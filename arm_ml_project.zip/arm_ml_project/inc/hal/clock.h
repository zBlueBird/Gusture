/**
*****************************************************************************************
*     Copyright(c) 2017, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
  * @file    pm.h
  * @brief   This file provides apis for power manager.
  * @author  Grace
  * @date    2022-04-27
  * @version v1.0
  * *************************************************************************************
   * @attention
   * <h2><center>&copy; COPYRIGHT 2017 Realtek Semiconductor Corporation</center></h2>
   * *************************************************************************************
  */

/*============================================================================*
 *               Define to prevent recursive inclusion
 *============================================================================*/
#ifndef __CLOCK_H_
#define __CLOCK_H_


/*============================================================================*
 *                               Header Files
*============================================================================*/
#include <stdint.h>
#include <stdbool.h>
#include "errno.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @addtogroup HAL_87x3e_PM
  * @brief
  * @{
  */

/*============================================================================*
 *                              Variables
*============================================================================*/
/** @defgroup PM_Exported_Variables PM Exported Variables
  * @{
  */
typedef enum
{
    CLK_PLL1_SRC,
    CLK_PLL2_SRC,
    CLK_PLL4_SRC,
    CLK_PLL_SRC_MAX,
} PLL_CLK_SRC_TYPE;

/** @} */ /* End of group DLPS_PLATFORM_Exported_Variables */

/*============================================================================*
 *                              Functions
*============================================================================*/
/** @defgroup DLPS_PLATFORM_Exported_Functions DLPS Platform Exported Functions
  * @{
  */
/**
 * @brief PLLx clock request handle.
 * @param  clk_src  PLLx .
 * @param  p_handle  store requested handle .
*/
void pll_clk_request_handle(PLL_CLK_SRC_TYPE clk_src, void **pp_handle);

/**
 * @brief PLLx clock enable.
 * @param  clk_src  PLLx .
 * @param  p_handle  enable which handle .
*/
void pll_clk_enable(PLL_CLK_SRC_TYPE clk_src, void *p_handle);

/**
 * @brief PLLx clock disable.
 * @param  clk_src  PLLx .
 * @param  p_handle  disable which handle.
*/
void pll_clk_disable(PLL_CLK_SRC_TYPE clk_src, void *p_handle);

/**
 * @brief Config cpu clock freq.
 * @param  require_mhz  require cpu freqency .
 * @param  real_mhz  the freqency of current cpu.
 * @return  Status of Operation.
*/
int32_t pm_cpu_freq_set(uint32_t required_mhz, uint32_t *actual_mhz);

/**
 * @brief Config cpu clock freq.
 * @param  require_mhz  require cpu slow freqency .
 * @return  Status of Operation.
*/
int32_t pm_cpu_slow_freq_set(uint32_t required_mhz);

/**
 * @brief Config dsp clock freq.
 * @param  require_mhz  require cpu freqency .
 * @param  real_mhz  the freqency of current dsp.
 * @return  Status of Operation.
*/
int32_t pm_dsp1_freq_set(uint32_t required_mhz, uint32_t *actual_mhz);

/**
 * @brief Config SPIC1 clock freq.
 * @param  require_mhz  require SPIC1 freqency .
 * @param  real_mhz  the freqency of current SPIC1.
 * @return  Status of Operation.
*/
int32_t pm_spic1_freq_set(uint32_t required_mhz, uint32_t *actual_mhz);

/**
 * @brief Config SPIC2 clock freq.
 * @param  require_mhz  require SPIC2 freqency .
 * @param  real_mhz  the freqency of current SPIC2.
 * @return  Status of Operation.
*/
int32_t pm_spic2_freq_set(uint32_t required_mhz, uint32_t *actual_mhz);

/**
 * @brief Config SPIC3 clock freq.
 * @param  require_mhz  require SPIC3 freqency .
 * @param  real_mhz  the freqency of current SPIC3.
 * @return  Status of Operation.
*/
int32_t pm_spic3_freq_set(uint32_t required_mhz, uint32_t *actual_mhz);

/**
 * @brief Config SDIO0 clock freq.
  * @param  clk_src  switch SDIO to PLLx clock .
 * @param  require_mhz  require SDIO0 freqency .
 * @param  real_mhz  the freqency of current SDIO0.
 * @return  Status of Operation.
*/
int32_t pm_sdio0_freq_set(PLL_CLK_SRC_TYPE clk_src, uint32_t required_mhz, uint32_t *actual_mhz);

/**
 * @brief Config SDIO1 clock freq.
 * @param  clk_src  switch SDIO to PLLx clock .
 * @param  require_mhz  require SDIO1 freqency .
 * @param  real_mhz  the freqency of current SDIO1.
 * @return  Status of Operation.
*/
int32_t pm_sdio1_freq_set(PLL_CLK_SRC_TYPE clk_src, uint32_t required_mhz, uint32_t *actual_mhz);


#ifdef __cplusplus
}
#endif

#endif
