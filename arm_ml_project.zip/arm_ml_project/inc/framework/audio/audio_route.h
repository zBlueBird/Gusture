/*
 * Copyright (c) 2018, Realsil Semiconductor Corporation. All rights reserved.
 */

#ifndef _AUDIO_ROUTE_H_
#define _AUDIO_ROUTE_H_

#include <stdint.h>
#include <stdbool.h>
#include "audio_type.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/**
 * \defgroup    AUDIO_ROUTE Audio Route
 *
 * \brief   Customize the audio path route configurations.
 */

/**
 * audio_route.h
 *
 * \brief Define Audio route gateway index.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_gateway_idx
{
    AUDIO_ROUTE_GATEWAY_0,
    AUDIO_ROUTE_GATEWAY_1,
    AUDIO_ROUTE_GATEWAY_2,
    AUDIO_ROUTE_GATEWAY_3,
    AUDIO_ROUTE_GATEWAY_NUM,
} T_AUDIO_ROUTE_GATEWAY_IDX;

/**
 * audio_route.h
 *
 * \brief Define Audio route gateway role.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_gateway_role
{
    AUDIO_ROUTE_GATEWAY_ROLE_MASTER,
    AUDIO_ROUTE_GATEWAY_ROLE_SLAVE,
    AUDIO_ROUTE_GATEWAY_ROLE_NUM,
} T_AUDIO_ROUTE_GATEWAY_ROLE;

/**
 * audio_route.h
 *
 * \brief Define Audio route gateway direction.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_gateway_dir
{
    AUDIO_ROUTE_GATEWAY_DIR_RX,
    AUDIO_ROUTE_GATEWAY_DIR_TX,
} T_AUDIO_ROUTE_GATEWAY_DIR;

/**
 * audio_route.h
 *
 * \brief Define Audio route gateway fifo mode.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_gateway_fifo_mode
{
    AUDIO_ROUTE_GATEWAY_FIFO_MODE_NON_INTERLACED,
    AUDIO_ROUTE_GATEWAY_FIFO_MODE_INTERLACED,
    AUDIO_ROUTE_GATEWAY_FIFO_MODE_NUM,
} T_AUDIO_ROUTE_GATEWAY_FIFO_MODE;

/**
 * audio_route.h
 *
 * \brief Define Audio route gateway channel mode.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_gateway_chann_mode
{
    AUDIO_ROUTE_GATEWAY_CHANN_MODE_TDM2,
    AUDIO_ROUTE_GATEWAY_CHANN_MODE_TDM4,
    AUDIO_ROUTE_GATEWAY_CHANN_MODE_TDM6,
    AUDIO_ROUTE_GATEWAY_CHANN_MODE_TDM8,
    AUDIO_ROUTE_GATEWAY_CHANN_MODE_NUM,
} T_AUDIO_ROUTE_GATEWAY_CHANN_MODE;

/**
 * audio_route.h
 *
 * \brief Define Audio route gateway format.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_gateway_format
{
    AUDIO_ROUTE_GATEWAY_FORMAT_I2S_STANDARD,
    AUDIO_ROUTE_GATEWAY_FORMAT_I2S_LEFT_JUSTIFIED,
    AUDIO_ROUTE_GATEWAY_FORMAT_I2S_PCM_A,
    AUDIO_ROUTE_GATEWAY_FORMAT_I2S_PCM_B,
    AUDIO_ROUTE_GATEWAY_FORMAT_NUM,
} T_AUDIO_ROUTE_GATEWAY_FORMAT;

/**
 * audio_route.h
 *
 * \brief Define Audio route gateway data length.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_gateway_data_len
{
    AUDIO_ROUTE_GATEWAY_DATA_LEN_8BIT,
    AUDIO_ROUTE_GATEWAY_DATA_LEN_16BIT,
    AUDIO_ROUTE_GATEWAY_DATA_LEN_20BIT,
    AUDIO_ROUTE_GATEWAY_DATA_LEN_24BIT,
    AUDIO_ROUTE_GATEWAY_DATA_LEN_32BIT,
} T_AUDIO_ROUTE_GATEWAY_DATA_LEN;

/**
 * audio_route.h
 *
 * \brief Define Audio route gateway channel length.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_gateway_chann_len
{
    AUDIO_ROUTE_GATEWAY_CHANN_LEN_8BIT,
    AUDIO_ROUTE_GATEWAY_CHANN_LEN_16BIT,
    AUDIO_ROUTE_GATEWAY_CHANN_LEN_20BIT,
    AUDIO_ROUTE_GATEWAY_CHANN_LEN_24BIT,
    AUDIO_ROUTE_GATEWAY_CHANN_LEN_32BIT,
} T_AUDIO_ROUTE_GATEWAY_CHANN_LEN;

/**
 * audio_route.h
 *
 * \brief Define Audio route gateway channel index.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_gateway_chann
{
    AUDIO_ROUTE_GATEWAY_CHANN0,
    AUDIO_ROUTE_GATEWAY_CHANN1,
    AUDIO_ROUTE_GATEWAY_CHANN2,
    AUDIO_ROUTE_GATEWAY_CHANN3,
    AUDIO_ROUTE_GATEWAY_CHANN4,
    AUDIO_ROUTE_GATEWAY_CHANN5,
    AUDIO_ROUTE_GATEWAY_CHANN6,
    AUDIO_ROUTE_GATEWAY_CHANN7,
} T_AUDIO_ROUTE_GATEWAY_CHANN;

/**
 * audio_route.h
 *
 * \brief Define Audio route gateway sample rate.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_gateway_sample_rate
{
    AUDIO_ROUTE_GATEWAY_SR_DYNAMIC   = 0x0F,
    AUDIO_ROUTE_GATEWAY_SR_8KHZ      = 0x00,
    AUDIO_ROUTE_GATEWAY_SR_16KHZ     = 0x01,
    AUDIO_ROUTE_GATEWAY_SR_32KHZ     = 0x02,
    AUDIO_ROUTE_GATEWAY_SR_44P1KHZ   = 0x03,
    AUDIO_ROUTE_GATEWAY_SR_48KHZ     = 0x04,
    AUDIO_ROUTE_GATEWAY_SR_88P2KHZ   = 0x05,
    AUDIO_ROUTE_GATEWAY_SR_96KHZ     = 0x06,
    AUDIO_ROUTE_GATEWAY_SR_192KHZ    = 0x07,
    AUDIO_ROUTE_GATEWAY_SR_12KHZ     = 0x08,
    AUDIO_ROUTE_GATEWAY_SR_24KHZ     = 0x09,
    AUDIO_ROUTE_GATEWAY_SR_11P025KHZ = 0x0a,
    AUDIO_ROUTE_GATEWAY_SR_22P05KHZ  = 0x0b,
    AUDIO_ROUTE_GATEWAY_SR_64KHZ     = 0x0c,
    AUDIO_ROUTE_GATEWAY_SR_NUM,
} T_AUDIO_ROUTE_GATEWAY_SAMPLE_RATE;

/**
 * audio_route.h
 *
 * \brief Define Audio route mclk rate.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_mclk_rate
{
    AUDIO_ROUTE_MCLK_RATE_1P024MHZ,
    AUDIO_ROUTE_MCLK_RATE_1P4112MHZ,
    AUDIO_ROUTE_MCLK_RATE_2P048MHZ,
    AUDIO_ROUTE_MCLK_RATE_2P8224MHZ,
    AUDIO_ROUTE_MCLK_RATE_3P072MHZ,
    AUDIO_ROUTE_MCLK_RATE_4P096MHZ,
    AUDIO_ROUTE_MCLK_RATE_5P6448MHZ,
    AUDIO_ROUTE_MCLK_RATE_6P144MHZ,
    AUDIO_ROUTE_MCLK_RATE_8P192MHZ,
    AUDIO_ROUTE_MCLK_RATE_11P2896MHZ,
    AUDIO_ROUTE_MCLK_RATE_12P288MHZ,
    AUDIO_ROUTE_MCLK_RATE_16P384MHZ,
    AUDIO_ROUTE_MCLK_RATE_22P5792MHZ,
    AUDIO_ROUTE_MCLK_RATE_24P576MHZ,
    AUDIO_ROUTE_MCLK_RATE_32P768MHZ,
    AUDIO_ROUTE_MCLK_RATE_NUM,
} T_AUDIO_ROUTE_MCLK_RATE;

/**
 * audio_route.h
 *
 * \brief Define Audio route logical IO type.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_io_type
{
    AUDIO_ROUTE_IO_AUDIO_PRIMARY_OUT              = 0x00,
    AUDIO_ROUTE_IO_AUDIO_SECONDARY_OUT            = 0x01,
    AUDIO_ROUTE_IO_AUDIO_PRIMARY_REF_OUT          = 0x02,
    AUDIO_ROUTE_IO_AUDIO_SECONDARY_REF_OUT        = 0x03,

    AUDIO_ROUTE_IO_VOICE_PRIMARY_OUT              = 0x10,
    AUDIO_ROUTE_IO_VOICE_SECONDARY_OUT            = 0x11,
    AUDIO_ROUTE_IO_VOICE_PRIMARY_REF_OUT          = 0x12,
    AUDIO_ROUTE_IO_VOICE_SECONDARY_REF_OUT        = 0x13,
    AUDIO_ROUTE_IO_VOICE_PRIMARY_REF_IN           = 0x14,
    AUDIO_ROUTE_IO_VOICE_SECONDARY_REF_IN         = 0x15,
    AUDIO_ROUTE_IO_VOICE_PRIMARY_IN               = 0x16,
    AUDIO_ROUTE_IO_VOICE_SECONDARY_IN             = 0x17,
    AUDIO_ROUTE_IO_VOICE_FUSION_IN                = 0x18,
    AUDIO_ROUTE_IO_VOICE_BONE_IN                  = 0x19,

    AUDIO_ROUTE_IO_RECORD_PRIMARY_REF_IN          = 0x20,
    AUDIO_ROUTE_IO_RECORD_SECONDARY_REF_IN        = 0x21,
    AUDIO_ROUTE_IO_RECORD_PRIMARY_IN              = 0x22,
    AUDIO_ROUTE_IO_RECORD_SECONDARY_IN            = 0x23,
    AUDIO_ROUTE_IO_RECORD_FUSION_IN               = 0x24,
    AUDIO_ROUTE_IO_RECORD_BONE_IN                 = 0x25,

    AUDIO_ROUTE_IO_LINE_PRIMARY_OUT               = 0x30,
    AUDIO_ROUTE_IO_LINE_SECONDARY_OUT             = 0x31,
    AUDIO_ROUTE_IO_LINE_PRIMARY_REF_OUT           = 0x32,
    AUDIO_ROUTE_IO_LINE_SECONDARY_REF_OUT         = 0x33,
    AUDIO_ROUTE_IO_LINE_PRIMARY_REF_IN            = 0x34,
    AUDIO_ROUTE_IO_LINE_SECONDARY_REF_IN          = 0x35,
    AUDIO_ROUTE_IO_LINE_LEFT_IN                   = 0x36,
    AUDIO_ROUTE_IO_LINE_RIGHT_IN                  = 0x37,

    AUDIO_ROUTE_IO_RINGTONE_PRIMARY_OUT           = 0x40,
    AUDIO_ROUTE_IO_RINGTONE_SECONDARY_OUT         = 0x41,
    AUDIO_ROUTE_IO_RINGTONE_PRIMARY_REF_OUT       = 0x42,
    AUDIO_ROUTE_IO_RINGTONE_SECONDARY_REF_OUT     = 0x43,

    AUDIO_ROUTE_IO_VOICE_PROMPT_PRIMARY_OUT       = 0x50,
    AUDIO_ROUTE_IO_VOICE_PROMPT_SECONDARY_OUT     = 0x51,
    AUDIO_ROUTE_IO_VOICE_PROMPT_PRIMARY_REF_OUT   = 0x52,
    AUDIO_ROUTE_IO_VOICE_PROMPT_SECONDARY_REF_OUT = 0x53,

    AUDIO_ROUTE_IO_APT_PRIMARY_OUT                = 0x60,
    AUDIO_ROUTE_IO_APT_SECONDARY_OUT              = 0x61,
    AUDIO_ROUTE_IO_APT_PRIMARY_REF_OUT            = 0x62,
    AUDIO_ROUTE_IO_APT_SECONDARY_REF_OUT          = 0x63,
    AUDIO_ROUTE_IO_APT_PRIMARY_REF_IN             = 0x64,
    AUDIO_ROUTE_IO_APT_SECONDARY_REF_IN           = 0x65,
    AUDIO_ROUTE_IO_APT_PRIMARY_LEFT_IN            = 0x66,
    AUDIO_ROUTE_IO_APT_PRIMARY_RIGHT_IN           = 0x67,
    AUDIO_ROUTE_IO_APT_SECONDARY_LEFT_IN          = 0x68,
    AUDIO_ROUTE_IO_APT_SECONDARY_RIGHT_IN         = 0x69,

    AUDIO_ROUTE_IO_LLAPT_PRIMARY_OUT              = 0x70,
    AUDIO_ROUTE_IO_LLAPT_SECONDARY_OUT            = 0x71,
    AUDIO_ROUTE_IO_LLAPT_PRIMARY_REF_OUT          = 0x72,
    AUDIO_ROUTE_IO_LLAPT_SECONDARY_REF_OUT        = 0x73,
    AUDIO_ROUTE_IO_LLAPT_PRIMARY_REF_IN           = 0x74,
    AUDIO_ROUTE_IO_LLAPT_SECONDARY_REF_IN         = 0x75,
    AUDIO_ROUTE_IO_LLAPT_LEFT_IN                  = 0x76,
    AUDIO_ROUTE_IO_LLAPT_RIGHT_IN                 = 0x77,

    AUDIO_ROUTE_IO_ANC_PRIMARY_OUT                = 0x80,
    AUDIO_ROUTE_IO_ANC_SECONDARY_OUT              = 0x81,
    AUDIO_ROUTE_IO_ANC_PRIMARY_REF_OUT            = 0x82,
    AUDIO_ROUTE_IO_ANC_SECONDARY_REF_OUT          = 0x83,
    AUDIO_ROUTE_IO_ANC_PRIMARY_REF_IN             = 0x84,
    AUDIO_ROUTE_IO_ANC_SECONDARY_REF_IN           = 0x85,
    AUDIO_ROUTE_IO_ANC_FF_LEFT_IN                 = 0x86,
    AUDIO_ROUTE_IO_ANC_FF_RIGHT_IN                = 0x87,
    AUDIO_ROUTE_IO_ANC_FB_LEFT_IN                 = 0x88,
    AUDIO_ROUTE_IO_ANC_FB_RIGHT_IN                = 0x89,

    AUDIO_ROUTE_IO_VAD_PRIMARY_REF_IN             = 0x90,
    AUDIO_ROUTE_IO_VAD_SECONDARY_REF_IN           = 0x91,
    AUDIO_ROUTE_IO_VAD_PRIMARY_IN                 = 0x92,
    AUDIO_ROUTE_IO_VAD_SECONDARY_IN               = 0x93,
} T_AUDIO_ROUTE_IO_TYPE;

/**
 * audio_route.h
 *
 * \brief Define Audio route endpoint_type.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_endpoint_type
{
    AUDIO_ROUTE_ENDPOINT_MIC     = 0x00,
    AUDIO_ROUTE_ENDPOINT_SPK     = 0x01,
    AUDIO_ROUTE_ENDPOINT_AUX     = 0x02,
    AUDIO_ROUTE_ENDPOINT_SPDIF   = 0x03,
} T_AUDIO_ROUTE_ENDPOINT_TYPE;

/**
 * audio_route.h
 *
 * \brief Define Audio route ADC channel.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_adc_chann
{
    AUDIO_ROUTE_ADC_CHANN0,
    AUDIO_ROUTE_ADC_CHANN1,
    AUDIO_ROUTE_ADC_CHANN2,
    AUDIO_ROUTE_ADC_CHANN3,
    AUDIO_ROUTE_ADC_CHANN4,
    AUDIO_ROUTE_ADC_CHANN5,
    AUDIO_ROUTE_ADC_CHANN6,
    AUDIO_ROUTE_ADC_CHANN_NUM,
} T_AUDIO_ROUTE_ADC_CHANN;

/**
 * audio_route.h
 *
 * \brief Define Audio route DAC channel.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_dac_chann
{
    AUDIO_ROUTE_DAC_CHANN0,
    AUDIO_ROUTE_DAC_CHANN1,
    AUDIO_ROUTE_DAC_CHANN2,
    AUDIO_ROUTE_DAC_CHANN3,
    AUDIO_ROUTE_DAC_CHANN_NUM,
} T_AUDIO_ROUTE_DAC_CHANN;

/**
 * audio_route.h
 *
 * \brief Define Audio route DAC mix point.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_dac_mix_point
{
    AUDIO_ROUTE_DAC_MIX_POINT0,
    AUDIO_ROUTE_DAC_MIX_POINT1,
    AUDIO_ROUTE_DAC_MIX_POINT2,
    AUDIO_ROUTE_DAC_MIX_POINT3,
    AUDIO_ROUTE_DAC_MIX_POINT4,
    AUDIO_ROUTE_DAC_MIX_POINT5,
    AUDIO_ROUTE_DAC_MIX_POINT6,
    AUDIO_ROUTE_DAC_MIX_POINT7,
    AUDIO_ROUTE_DAC_MIX_POINT_NUM,
} T_AUDIO_ROUTE_DAC_MIX_POINT;

/**
 * audio_route.h
 *
 * \brief Define Audio route MIC.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_mic_id
{
    AUDIO_ROUTE_MIC1    = 0x00,           /**< microphone 1 */
    AUDIO_ROUTE_MIC2    = 0x01,           /**< microphone 2 */
    AUDIO_ROUTE_MIC3    = 0x02,           /**< microphone 3 */
    AUDIO_ROUTE_MIC4    = 0x03,           /**< microphone 4 */
    AUDIO_ROUTE_MIC5    = 0x04,           /**< microphone 5 */
    AUDIO_ROUTE_MIC6    = 0x05,           /**< microphone 6 */
    AUDIO_ROUTE_REF_MIC = 0x0E,           /**< Internal microphone for reference signal in */
    AUDIO_ROUTE_EXT_MIC = 0x0F,           /**< External microphone */
} T_AUDIO_ROUTE_MIC_ID;

/**
 * audio_route.h
 *
 * \brief Define Audio route MIC type.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_mic_type
{
    AUDIO_ROUTE_MIC_SINGLE_END   = 0x00,
    AUDIO_ROUTE_MIC_DIFFERENTIAL = 0x01,
    AUDIO_ROUTE_MIC_FALLING      = 0x02,
    AUDIO_ROUTE_MIC_RAISING      = 0x03,
} T_AUDIO_ROUTE_MIC_TYPE;

/**
 * audio_route.h
 *
 * \brief Define Audio route MIC class.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_mic_class
{
    AUDIO_ROUTE_MIC_NORMAL = 0x00,
    AUDIO_ROUTE_MIC_LP     = 0x01,
    AUDIO_ROUTE_MIC_SNR    = 0x02,
} T_AUDIO_ROUTE_MIC_CLASS;

/**
 * audio_route.h
 *
 * \brief Define Audio route device MIC.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef struct t_audio_route_device_mic
{
    T_AUDIO_ROUTE_MIC_ID      id;
    T_AUDIO_ROUTE_MIC_TYPE    type;
    T_AUDIO_ROUTE_MIC_CLASS   class;
    T_AUDIO_ROUTE_ADC_CHANN   adc_ch;
    uint8_t                   ana_gain;
    uint8_t                   dig_gain;
    uint8_t                   dig_boost_gain;
} T_AUDIO_ROUTE_DEVICE_MIC;

/**
 * audio_route.h
 *
 * \brief Define Audio route SPK id.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_spk_id
{
    AUDIO_ROUTE_SPK1    = 0x00, /**< Physical speaker 1 */
    AUDIO_ROUTE_SPK2    = 0x01, /**< Physical speaker 2 */
    AUDIO_ROUTE_REF_SPK = 0x06, /**< Internal speaker for reference signal out  */
    AUDIO_ROUTE_EXT_SPK = 0x07, /**< External speaker */
} T_AUDIO_ROUTE_SPK_ID;

/**
 * audio_route.h
 *
 * \brief Define Audio route SPK type.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_spk_type
{
    AUDIO_ROUTE_SPK_SINGLE_END   = 0x00,
    AUDIO_ROUTE_SPK_DIFFERENTIAL = 0x01,
    AUDIO_ROUTE_SPK_CAPLESS      = 0x02,
} T_AUDIO_ROUTE_SPK_TYPE;

/**
 * audio_route.h
 *
 * \brief Define Audio route SPK Class.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_spk_class
{
    AUDIO_ROUTE_SPK_CLASS_D  = 0x00,
    AUDIO_ROUTE_SPK_CLASS_AB = 0x01,
} T_AUDIO_ROUTE_SPK_CLASS;

/**
 * audio_route.h
 *
 * \brief Define Audio route SPDIF.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_spdif_id
{
    AUDIO_ROUTE_SPDIF_0 = 0,           /**< Physical endpoint: spdif 0 */
} T_AUDIO_ROUTE_SPDIF_ID;

/**
 * audio_route.h
 *
 * \brief Define Audio route SPDIF type.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_spdif_type
{
    AUDIO_ROUTE_SPDIF_DEFAULT = 0,
} T_AUDIO_ROUTE_SPDIF_TYPE;

/**
 * audio_route.h
 *
 * \brief Define Audio route Gateway Type.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_gateway_type
{
    AUDIO_ROUTE_GATEWAY_SPORT = 0,
    AUDIO_ROUTE_GATEWAY_SPDIF = 1,
} T_AUDIO_ROUTE_GATEWAY_TYPE;

/**
 * audio_route.h
 *
 * \brief Define Audio route device SPK.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef struct t_audio_route_device_spk
{
    T_AUDIO_ROUTE_SPK_ID        id;
    T_AUDIO_ROUTE_SPK_TYPE      type;
    T_AUDIO_ROUTE_SPK_CLASS     class;
    T_AUDIO_ROUTE_DAC_CHANN     dac_ch;
    uint8_t                     ana_gain;
    uint8_t                     dig_gain;
    uint8_t                     mix_en;
} T_AUDIO_ROUTE_DEVICE_SPK;

/**
 * audio_route.h
 *
 * \brief Define Audio route AUX.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_aux_id
{
    AUDIO_ROUTE_AUX_L = 0x00,        /**< AUX-IN L */
    AUDIO_ROUTE_AUX_R = 0x01,        /**< AUX-IN R */
} T_AUDIO_ROUTE_AUX_ID;

/**
 * audio_route.h
 *
 * \brief Define Audio route MIC class.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_aux_class
{
    AUDIO_ROUTE_AUX_NORMAL = 0x00,
    AUDIO_ROUTE_AUX_LP     = 0x01,
} T_AUDIO_ROUTE_AUX_CLASS;

/**
 * audio_route.h
 *
 * \brief Define Audio route device AUX in.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef struct  t_audio_route_device_aux_in
{
    T_AUDIO_ROUTE_AUX_ID      id;
    T_AUDIO_ROUTE_AUX_CLASS   class;
    T_AUDIO_ROUTE_ADC_CHANN   adc_ch;
    bool                      equalizer_en;
    uint8_t                   ana_gain;
    uint8_t                   dig_gain;
    uint8_t                   dig_boost_gain;
} T_AUDIO_ROUTE_DEVICE_AUX_IN;

/**
 * audio_route.h
 *
 * \brief Define Audio route device SPDIF in.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef struct  t_audio_route_device_spdif_in
{
    T_AUDIO_ROUTE_SPDIF_ID      id;
    T_AUDIO_ROUTE_SPDIF_TYPE    type;
} T_AUDIO_ROUTE_DEVICE_SPDIF_IN;

/**
 * audio_route.h
 *
 * \brief Define Audio route device SPDIF out.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef struct  t_audio_route_device_spdif_out
{
    T_AUDIO_ROUTE_SPDIF_ID      id;
    T_AUDIO_ROUTE_SPDIF_TYPE    type;
} T_AUDIO_ROUTE_DEVICE_SPDIF_OUT;

/**
 * audio_route.h
 *
 * \brief Define Audio Route ADC digital gain.
 *
 * \details ADC digital gain in (dB * 128) step unit is defined as adc_gain = gain_db * 128,
 *          where the gain_db ranges from -128.0 dB to + 127.0 dB.
 *
 * \note    As some platforms do not support floating point arithmetic, Audio Route inputs
 *          the converted dB in signed integer for the underlying modules.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef struct t_audio_route_adc_gain
{
    int16_t left_gain;
    int16_t right_gain;
} T_AUDIO_ROUTE_ADC_GAIN;

/**
 * audio_route.h
 *
 * \brief Define Audio Route DAC digital gain.
 *
 * \details DAC digital gain in (dB * 128) step unit is defined as dac_gain = gain_db * 128,
 *          where the gain_db ranges from -128.0 dB to + 127.0 dB.
 *
 * \note    As some platforms do not support floating point arithmetic, Audio Route inputs
 *          the converted dB in signed integer for the underlying modules.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef struct t_audio_route_dac_gain
{
    int16_t left_gain;
    int16_t right_gain;
} T_AUDIO_ROUTE_DAC_GAIN;

/**
 * audio_route.h
 *
 * \brief Define Audio route IO polarity.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef enum t_audio_route_io_polarity
{
    AUDIO_ROUTE_IO_POLARITY_FORWARD = 0x00,
    AUDIO_ROUTE_IO_POLARITY_REVERSE = 0x01,
} T_AUDIO_ROUTE_IO_POLARITY;

/**
 * audio_route.h
 *
 * \brief Define Audio route gateway rtx database.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef struct t_audio_route_gateway_db
{
    T_AUDIO_ROUTE_GATEWAY_FIFO_MODE   fifo_mode;
    T_AUDIO_ROUTE_GATEWAY_CHANN_MODE  chann_mode;
    T_AUDIO_ROUTE_GATEWAY_FORMAT      format;
    T_AUDIO_ROUTE_GATEWAY_DATA_LEN    data_len;
    T_AUDIO_ROUTE_GATEWAY_CHANN_LEN   chann_len;
    uint32_t                          sample_rate;
} T_AUDIO_ROUTE_GATEWAY_DB;

/**
 * audio_route.h
 *
 * \brief Define Audio route endpoint attribute.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef union t_audio_route_endpoint_attr
{
    T_AUDIO_ROUTE_DEVICE_MIC       mic;
    T_AUDIO_ROUTE_DEVICE_SPK       spk;
    T_AUDIO_ROUTE_DEVICE_AUX_IN    aux_in;
    T_AUDIO_ROUTE_DEVICE_SPDIF_IN  spdif_in;
    T_AUDIO_ROUTE_DEVICE_SPDIF_OUT spdif_out;
} T_AUDIO_ROUTE_ENDPOINT_ATTR;

/**
 * audio_route.h
 *
 * \brief Define Audio route gateway attribute.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef struct t_audio_route_gateway_attr
{
    T_AUDIO_ROUTE_GATEWAY_TYPE        type;
    T_AUDIO_ROUTE_GATEWAY_IDX         idx;
    T_AUDIO_ROUTE_GATEWAY_DIR         dir;
    T_AUDIO_ROUTE_GATEWAY_CHANN       chann;
} T_AUDIO_ROUTE_GATEWAY_ATTR;

/**
 * audio_route.h
 *
 * \brief Define Audio route path.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef struct t_audio_route_path
{
    T_AUDIO_ROUTE_IO_TYPE           io_type;
    T_AUDIO_ROUTE_IO_POLARITY       io_polarity;
    T_AUDIO_ROUTE_ENDPOINT_TYPE     endpoint_type;
    T_AUDIO_ROUTE_ENDPOINT_ATTR     endpoint_attr;
    T_AUDIO_ROUTE_GATEWAY_ATTR      gateway_attr;
} T_AUDIO_ROUTE_PATH;

/**
 * audio_route.h
 *
 * \brief Define Audio route path group.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef struct t_audio_route_path_group
{
    uint8_t                      path_num;
    T_AUDIO_ROUTE_PATH          *path;
} T_AUDIO_ROUTE_PATH_GROUP;

/**
 * audio_route.h
 *
 * \brief Define Audio Route DAC digital gain callback prototype.
 *
 * \details Applications use \ref audio_route_gain_register to register the DAC digital
 *          gain adjustment callback. Audio Route will request the DAC digital gain value
 *          at the specified level actively at runtime.
 *
 * \param[in]     category  Audio category \ref T_AUDIO_CATEGORY.
 * \param[in]     level     Requested DAC digital gain level.
 * \param[out]    gain      Corresponding DAC digital gain value \ref T_AUDIO_ROUTE_DAC_GAIN.
 *
 * \return  The status of getting the DAC digital gain value.
 * \retval  true    DAC digital gain value was got successfully.
 * \retval  false   DAC digital gain value was failed to get.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef bool (*P_AUDIO_ROUTE_DAC_GAIN_CBACK)(T_AUDIO_CATEGORY        category,
                                             uint32_t                level,
                                             T_AUDIO_ROUTE_DAC_GAIN *gain);

/**
 * audio_route.h
 *
 * \brief Define Audio Route ADC digital gain callback prototype.
 *
 * \details Applications use \ref audio_route_gain_register to register the ADC digital
 *          gain adjustment callback. Audio Route will request the ADC digital gain value
 *          at the specified level actively at runtime.
 *
 * \param[in]     category  Audio category \ref T_AUDIO_CATEGORY.
 * \param[in]     level     Requested ADC digital gain level.
 * \param[out]    gain      Corresponding ADC digital gain value \ref T_AUDIO_ROUTE_ADC_GAIN.
 *
 * \return  The status of getting the ADC digital gain value.
 * \retval  true    ADC digital gain value was got successfully.
 * \retval  false   ADC digital gain value was failed to get.
 *
 * \ingroup AUDIO_ROUTE
 */
typedef bool (*P_AUDIO_ROUTE_ADC_GAIN_CBACK)(T_AUDIO_CATEGORY        category,
                                             uint32_t                level,
                                             T_AUDIO_ROUTE_ADC_GAIN *gain);

/**
 * audio_route.h
 *
 * \brief   Initialize the audio route management.
 *
 * \param[in] void
 *
 * \return  The status of initializing the audio route.
 * \retval  true    Audio route was initialized successfully.
 * \retval  false   Audio route was failed to initialized.
 *
 * \ingroup AUDIO_ROUTE
 */
bool audio_route_init(void);

/**
 * audio_route.h
 *
 * \brief   Deinitialize the audio route managerment.
 *
 * \ingroup AUDIO_ROUTE
 */
void audio_route_deinit(void);

/**
 * audio_route.h
 *
 * \brief   Register the Audio Route ADC and/or DAC digital gain callback.
 *
 * \param[in] category    Audio category \ref T_AUDIO_CATEGORY.
 * \param[in] dac_cback   Audio route DAC gain callback \ref P_AUDIO_ROUTE_DAC_GAIN_CBACK.
 * \param[in] adc_cback   Audio route ADC gain callback \ref P_AUDIO_ROUTE_ADC_GAIN_CBACK.
 *
 * \return  The status of registering the ADC and DAC digital gain callback.
 * \retval  true    Audio Route digital gain callback was registered successfully.
 * \retval  false   Audio Route digital gain callback was failed to register.
 *
 * \note    The ADC or DAC digital gain callback shall be set to NULL if not supported.
 *
 * \ingroup AUDIO_ROUTE
 */
bool audio_route_gain_register(T_AUDIO_CATEGORY             category,
                               P_AUDIO_ROUTE_DAC_GAIN_CBACK dac_cback,
                               P_AUDIO_ROUTE_ADC_GAIN_CBACK adc_cback);

/**
 * audio_route.h
 *
 * \brief   Unregister the Audio Route ADC and DAC digital callback.
 *
 * \param[in] category    Audio category \ref T_AUDIO_CATEGORY.
 *
 * \return  void.
 *
 * \ingroup AUDIO_ROUTE
 */
void audio_route_gain_unregister(T_AUDIO_CATEGORY category);

/**
 * audio_route.h
 *
 * \brief   Get the audio route ADC gain.
 *
 * \param[in]  category Audio category \ref T_AUDIO_CATEGORY.
 * \param[in]  level    The ADC digital gain level.
 * \param[out] gain     The ADC digital gain value \ref T_AUDIO_ROUTE_ADC_GAIN.
 *
 * \return  The status of getting ADC gain.
 *
 * \ingroup AUDIO_ROUTE
 */
bool audio_route_adc_gain_get(T_AUDIO_CATEGORY        category,
                              uint32_t                level,
                              T_AUDIO_ROUTE_ADC_GAIN *gain);

/**
 * audio_route.h
 *
 * \brief   Get the audio route DAC gain.
 *
 * \param[in]  category Audio category \ref T_AUDIO_CATEGORY.
 * \param[in]  level    The DAC digital gain level.
 * \param[out] gain     The DAC digital gain value \ref T_AUDIO_ROUTE_DAC_GAIN.
 *
 * \return  The status of getting DAC gain.
 *
 * \ingroup AUDIO_ROUTE
 */
bool audio_route_dac_gain_get(T_AUDIO_CATEGORY        category,
                              uint32_t                level,
                              T_AUDIO_ROUTE_DAC_GAIN *gain);

/**
 * audio_route.h
 *
 * \brief   Get the audio route path group.
 *
 * \param[in] category    Audio category \ref T_AUDIO_CATEGORY.
 * \param[in] device      Audio route device \ref AUDIO_DEVICE_BITMASK.
 *
 * \return The path group of audio category.
 *
 * \ingroup AUDIO_ROUTE
 */
T_AUDIO_ROUTE_PATH_GROUP audio_route_path_group_take(T_AUDIO_CATEGORY category,
                                                     uint32_t         device);

/**
 * audio_route.h
 *
 * \brief   Free the audio route path group.
 *
 * \param[in] path_group    Audio route path_group \ref T_AUDIO_ROUTE_PATH_GROUP.
 *
 * \ingroup AUDIO_ROUTE
 */
void audio_route_path_group_give(T_AUDIO_ROUTE_PATH_GROUP *path_group);

/**
 * audio_route.h
 *
 * \brief   Register the audio route path.
 *
 * \param[in] category              Audio category \ref T_AUDIO_CATEGORY.
 * \param[in] path                  Audio route path \ref T_AUDIO_ROUTE_PATH.
 * \param[in] path_num              Audio route path num.
 *
 * \return The status of registering audio route path.
 *
 * \ingroup AUDIO_ROUTE
 */
bool audio_route_category_path_register(T_AUDIO_CATEGORY    category,
                                        T_AUDIO_ROUTE_PATH *path,
                                        uint8_t             path_num);

/**
 * audio_route.h
 *
 * \brief   Unregister the audio route path.
 *
 * \param[in] category   Audio category \ref T_AUDIO_CATEGORY.
 *
 * \return The status of unregistering audio route path.
 *
 * \ingroup AUDIO_ROUTE
 */
bool audio_route_category_path_unregister(T_AUDIO_CATEGORY category);

/**
* audio_route.h
*
* \brief   Get the gateway rtx database.
*
* \param[in] type       Gateway type \ref T_AUDIO_ROUTE_GATEWAY_TYPE.
* \param[in] id         Gateway id \ref T_AUDIO_ROUTE_GATEWAY_IDX.
* \param[in] direction  Gateway direction \ref T_AUDIO_ROUTE_GATEWAY_DIR.
*
* \return The GATEWAY rtx database.
*
* \ingroup AUDIO_ROUTE
*/
T_AUDIO_ROUTE_GATEWAY_DB audio_route_gateway_db_get(T_AUDIO_ROUTE_GATEWAY_TYPE type,
                                                    T_AUDIO_ROUTE_GATEWAY_IDX  id,
                                                    T_AUDIO_ROUTE_GATEWAY_DIR  direction);

/**
 * audio_route.h
 *
 * \brief   Get the ramp gain.
 *
 * \param[in] category   Audio category \ref T_AUDIO_CATEGORY.
 *
 * \return The ramp gain.
 *
 * \ingroup AUDIO_ROUTE
 */
int16_t audio_route_ramp_gain_get(T_AUDIO_CATEGORY category);

/**
 * audio_route.h
 *
 * \brief   Get the ramp gain scaling.
 *
 * \param[in] category   Audio category \ref T_AUDIO_CATEGORY.
 *
 * \return The ramp gain scaling.
 *
 * \ingroup AUDIO_ROUTE
 */
uint8_t audio_route_ramp_gain_scaling_get(T_AUDIO_CATEGORY category);

/**
 * audio_route.h
 *
 * \brief   Get the ramp gain calculate mode.
 *
 * \param[in] category   Audio category \ref T_AUDIO_CATEGORY.
 *
 * \return The ramp gain calculate mode..
 *
 * \ingroup AUDIO_ROUTE
 */
bool audio_route_ramp_gain_calc_mode_get(T_AUDIO_CATEGORY category);

/**
 * audio_route.h
 *
 * \brief   Enable the audio route IO for the specific category.
 *
 * \param[in] category   Audio category \ref T_AUDIO_CATEGORY.
 * \param[in] io         logic IO \ref T_AUDIO_ROUTE_IO_TYPE.
 *
 * \return          The status of enabling the audio route IO.
 * \retval true     Audio route IO was enabled successfully.
 * \retval false    Audio route IO was failed to enable.
 *
 * \ingroup AUDIO_ROUTE
 */
bool audio_route_io_enable(T_AUDIO_CATEGORY category, T_AUDIO_ROUTE_IO_TYPE io);

/**
 * audio_route.h
 *
 * \brief   Disable the audio route IO for the specific category.
 *
 * \param[in] category   Audio category \ref T_AUDIO_CATEGORY.
 * \param[in] io         logic IO \ref T_AUDIO_ROUTE_IO_TYPE.
 *
 * \return          The status of disabling the audio route IO.
 * \retval true     Audio route IO was disabled successfully.
 * \retval false    Audio route IO was failed to disable.
 *
 * \ingroup AUDIO_ROUTE
 */
bool audio_route_io_disable(T_AUDIO_CATEGORY category, T_AUDIO_ROUTE_IO_TYPE io);

/**
 * audio_route.h
 *
 * \brief   Get mic class type by different mic id.
 *
 * \param[in] mic_id   mic id number \ref T_AUDIO_ROUTE_MIC_ID.
 *
 * \return          The class of MIC.
 *
 * \ingroup AUDIO_ROUTE
 */
static T_AUDIO_ROUTE_MIC_CLASS audio_route_mic_class_get(uint8_t mic_id);

/**
 * audio_route.h
 *
 * \brief   Get aux class type by different aux id.
 *
 * \param[in] aux_id   aux id number \ref T_AUDIO_ROUTE_AUX_ID.
 *
 * \return          The class of AUX.
 *
 * \ingroup AUDIO_ROUTE
 */
static T_AUDIO_ROUTE_AUX_CLASS audio_route_aux_class_get(uint8_t aux_id);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* _AUDIO_ROUTE_H_ */
