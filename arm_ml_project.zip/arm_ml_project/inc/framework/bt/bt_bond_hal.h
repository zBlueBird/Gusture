/*
 * Copyright (c) 2018, Realsil Semiconductor Corporation. All rights reserved.
 */

#ifndef _BT_BOND_HAL_H_
#define _BT_BOND_HAL_H_

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef uint8_t (*P_BT_MAX_BOND_NUM_GET)(void);

typedef uint8_t (*P_BT_BOND_NUM_GET)(void);

typedef bool (*P_BT_BOND_ADDR_GET)(uint8_t priority, uint8_t *bd_addr);

typedef bool (*P_BT_BOND_INDEX_GET)(uint8_t *bd_addr, uint8_t *index);

typedef bool (*P_BT_BOND_FLAG_GET)(uint8_t *bd_addr, uint32_t *bond_flag);

typedef bool (*P_BT_BOND_FLAG_SET)(uint8_t *bd_addr, uint32_t bond_flag);

typedef bool (*P_BT_BOND_KEY_GET)(uint8_t *bd_addr, uint8_t *link_key, uint8_t *key_type);

typedef bool (*P_BT_BOND_KEY_SET)(uint8_t *bd_addr, uint8_t *linkkey, uint8_t key_type);

typedef bool (*P_BT_BOND_PRIORITY_SET)(uint8_t *bd_addr);

typedef bool (*P_BT_BOND_DELETE)(uint8_t *bd_addr);

typedef void (*P_BT_BOND_CLEAR)(void);

typedef struct
{
    P_BT_MAX_BOND_NUM_GET p_bt_max_bond_num_get;
    P_BT_BOND_NUM_GET p_bt_bond_num_get;
    P_BT_BOND_ADDR_GET p_bt_bond_addr_get;
    P_BT_BOND_INDEX_GET p_bt_bond_index_get;
    P_BT_BOND_FLAG_GET p_bt_bond_flag_get;
    P_BT_BOND_FLAG_SET p_bt_bond_flag_set;
    P_BT_BOND_KEY_GET p_bt_bond_key_get;
    P_BT_BOND_KEY_SET p_bt_bond_key_set;
    P_BT_BOND_PRIORITY_SET p_bt_bond_priority_set;
    P_BT_BOND_DELETE p_bt_bond_delete;
    P_BT_BOND_CLEAR p_bt_bond_clear;
} T_LEGACY_BOND_HAL;

void bt_bond_register_hal(const T_LEGACY_BOND_HAL *p_hal);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* _BT_BOND_H_ */
