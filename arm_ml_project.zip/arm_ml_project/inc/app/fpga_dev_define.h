#ifndef _FPGA_DEV_DEFINE_H_
#define _FPGA_DEV_DEFINE_H_

/* Here define workaround which cannot resolve immediately. */

/* Notice: re-build sdk lib/image if fpga_dev_define.h modified */

/* Feature development */
// skip primary engage check for RWS verify
//#define FPGA_DEV_PRI_ENGAGE_CHECK_COMPLEMENT
// custom MCU config for FPGA verify
#define FPGA_DEV_APP_CUSTOM_CFG

/* Compile error/warning */
// app_dlps.c dlps flow skip
#define FPGA_DEV_DLPS_FLOW_COMPLEMENT

//#define FPGA_CPU_CLK_ALLOW_COMPLEMENT

//#define SET_HCI_DOWNLOAD_COMPLEMENT
//#define BQB_COMPLEMENT
//define ANO_CHECK_COMPLEMENT
#endif /* !_FPGA_DEV_DEFINE_H_ */

