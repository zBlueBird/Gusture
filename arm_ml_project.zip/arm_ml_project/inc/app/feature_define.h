#ifndef __FEATURE_DEFINE_H__
#define __FEATURE_DEFINE_H__

/*============================================================================================*/

/* anc related */
#define ANC_ENABLE     1

#endif
