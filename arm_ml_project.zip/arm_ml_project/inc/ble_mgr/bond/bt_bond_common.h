/**
*********************************************************************************************************
*               Copyright(c) 2016, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      bt_bond_common.h
* @brief     key storage function.
* @details
* @author    jane
* @date      2016-02-18
* @version   v0.1
* *********************************************************************************************************
*/

#ifndef     BT_BOND_COMMON_H
#define     BT_BOND_COMMON_H

#include "bt_bond_le.h"

#ifdef __cplusplus
extern "C"
{
#endif
/*bond state: indicate bond information exist or not*/
#define BT_BOND_INFO_EXIST_FLAG 0x01
/*bond state: indicate bond information need update or not*/
#define BT_BOND_INFO_NEED_UPDATE_FLAG 0x02
/*bond state: indicate re-pair or not*/
#define BT_BOND_INFO_REPAIR_FLAG      0x04

#define BT_BOND_MSG_LE_BOND_ADD       0x00
#define BT_BOND_MSG_LE_BOND_REMOVE    0x01
#define BT_BOND_MSG_LE_BOND_CLEAR     0x02
#define BT_BOND_MSG_LE_BOND_UPDATE    0x03
//#define BT_BOND_MSG_LE_SET_HIGH_PRIORITY    0x04

typedef struct
{
    uint8_t         bond_state;
    uint8_t         key_type;
    uint8_t         remote_bd_type;
    uint8_t         local_bd_type;
    uint8_t         remote_bd[6];
    uint8_t         local_bd[6];
    uint32_t        bond_flag;
} T_BT_BOND_INFO;

typedef void(*P_FUN_BT_BOND_CB)(uint8_t cb_type, void *p_cb_data);

/**
 * @brief bt_bond_register_app_cb
 * APP can call bt_bond_register_app_cb to register callback to get bt bond modify information.
 * @param app_callback
 * @return true
 * @return false
* \code{.c}
    void ble_bond_sync_init(void)
    {
        ......
        bt_bond_register_app_cb(ble_bond_sync_cb);
        ......
    }

    void ble_bond_sync_cb(uint8_t cb_type, void *p_cb_data)
    {
        ......
        switch (cb_type)
        {
        case BT_BOND_MSG_LE_BOND_ADD:
            {

            }
            break;

        case BT_BOND_MSG_LE_BOND_REMOVE:
            {

            }
            break;

        case BT_BOND_MSG_LE_BOND_CLEAR:
            {

            }
            break;

        case BT_BOND_MSG_LE_BOND_UPDATE:
            {

            }
            break;

        default:
            break;
        }
        return;
    }
 * \endcode
 */
bool bt_bond_register_app_cb(P_FUN_BT_BOND_CB app_callback);

#ifdef __cplusplus
}
#endif

#endif /* BT_BOND_COMMON_H */
