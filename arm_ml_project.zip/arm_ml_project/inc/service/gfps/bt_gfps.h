/*
 * Copyright (c) 2018, Realsil Semiconductor Corporation. All rights reserved.
 */

#ifndef _BT_GFPS_H_
#define _BT_GFPS_H_


#include <stdint.h>
#include <stdbool.h>
#include "bt_rfc.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


/** @defgroup GFPS GFPS
  * @brief
  * @{
  */


/**
 * @defgroup BT_GFPS BT GFPS profile
 * @brief Provides BT GFPS profile interfaces.
 * @{
 */

/** @brief Message group(1 byte), Message code(1 byte), Additional data length(2 byte) */
#define GFPS_HEADER_LEN                  0x04
#define GFPS_ADDITIONAL_DATA_LEN         0x02

#define GFPS_MODEL_ID_LEN                0x0003
#define GFPS_BATTERY_LEN                 0x0003
#define GFPS_ACTIVE_COMPONENTS_LEN       0x0001
#define GFPS_SUPPORT_CPBS_LEN            0x0001
#define GFPS_RING_LEN                    0x0001
#define GFPS_ACK_LEN                     0x0002
#define GFPS_NAK_LEN                     0x0003

/** @brief left and right bud active type */
#define GFPS_RIGHT_ACTIVE           0x01
#define GFPS_LEFT_ACTIVE            0x02

/** @brief remote support capabilities type */
#define GFPS_COMPANION_APP          0x01
#define GFPS_SILENCE_MODE           0x02

/** @brief action ringtone type */
#define GFPS_ALL_STOP               0x00
#define GFPS_RIGHT_RING             0x01
#define GFPS_LEFT_RING              0x02
#define GFPS_ALL_RING               0x03

/** @brief NAK reason type */
#define GFPS_NOT_SUPPORT            0x00
#define GFPS_DEVICE_BUSY            0x01
#define GFPS_NOT_ALLOW              0x02

/** @brief gfps message group */
typedef enum
{
    GFPS_BLUETOOTH_EVENT         = 0x01,
    GFPS_COMPANION_APP_EVENT     = 0x02,
    GFPS_DEVICE_INFO_EVENT       = 0x03,
    GFPS_DEVICE_ACTION_EVENT     = 0x04,

    GFPS_ACKNOWLEDGEMENT_EVENT   = 0xFF,
} T_GFPS_MSG_GROUP;

/** @brief gfps message bluetooth event code */
typedef enum
{
    GFPS_ENABLE_SILENCE_MODE     = 0x01,
    GFPS_DISABLE_SILENCE_MODE    = 0x02,
} T_GFPS_MSG_BT_EVENT_CODE;

/** @brief gfps message companion app event code */
typedef enum
{
    GFPS_LOG_BUF_FULL            = 0x01,
} T_GFPS_MSG_APP_EVENT_CODE;

/** @brief gfps message device information event code */
typedef enum
{
    GFPS_MODEL_ID                = 0x01,
    GFPS_BLE_ADDR_UPDATED        = 0x02,
    GFPS_BATTERY_UPDATED         = 0x03,
    GFPS_REMAINING_BATTERY_TIME  = 0x04,
    GFPS_ACITVE_COMPONENTS_REQ   = 0x05,
    GFPS_ACITVE_COMPONENTS_RSP   = 0x06,
    GFPS_CAPABILITIES            = 0x07,
    GFPS_PLATFORM_TYPE           = 0x08,
} T_GFPS_MSG_DEVICE_INFO_EVENT_CODE;

/** @brief gfps message device action event code */
typedef enum
{
    GFPS_RING                   = 0x01,
} T_GFPS_MSG_DEVICE_ACTION_EVENT_CODE;

/** @brief gfps message acknowledgement event code */
typedef enum
{
    GFPS_ACK                    = 0x01,
    GFPS_NAK                    = 0x02,
} T_GFPS_MSG_ACKKNOWLEDGEMENT_CODE;

typedef void (* P_APP_GFPS_RFC_CBACK)(uint8_t *bd_addr, T_BT_RFC_MSG_TYPE msg_type, void *p_msg);

/**
  * @brief  Initialize GFPS profile manager.
  * @param  cback   callback function used to handle RFCOMM message
  * @param  server_chann   rfcomm channel num used for gfps
  * @return The result of initialization.
  * @retval true    Initialization has been completed successfully.
  * @retval false   Initialization was failed to complete.
  */
bool bt_gfps_rfc_init(P_APP_GFPS_RFC_CBACK cback, uint8_t server_chann);

/**
  * @brief  Send a request to create a RFCOMM connection.
  * @param  bd_addr             remote bd_addr
  * @param  remote_server_chann The remote server channel which can be found from the sdp info.
  * @param  local_server_chann  The local server channel of the service that sending this request.
  * @param  frame_size          The max frame_size supported by local device.
  * @param  init_credits        The number of packet that remote can be send. This para is used for flow control. A
                                sending entity may send as many frames on a RFCOMM channel as it has credits;if the
                                credit count reaches zero,the sender will stop and wait for further credits from peer.
  * @return The status of sending connection request.
  * @retval true    Request has been sent successfully.
  * @retval false   Request was fail to send.
  */
bool bt_gfps_connect_req(uint8_t *bd_addr, uint8_t remote_server_chann, uint8_t local_server_chann,
                         uint16_t frame_size, uint8_t init_credits);

/**
  * @brief  Send a confirmation to accept or reject the received RFCOMM connection request.
  * @param  bd_addr            remote bd_addr
  * @param  local_server_chann local server channel
  * @param  accept             confirmation message
  * @arg    true    Accept the received RFCOMM connection request.
  * @arg    false   Reject the received RFCOMM connection request.
  * @param  frame_size         The max frame_size supported by local device.
  * @param  init_credits       The number of packet that remote can be send. This para is used for flow control.A sending
                               entity may send as many frames on a RFCOMM channel as it has credits;if the credit count
                               reaches zero,the sender will stop and wait for further credits from peer.
  * @return The result of sending confirmation.
  * @retval true    The confirmation has benn sent successfully.
  * @retval false   The confirmation was fail to send.
  */
bool bt_gfps_connect_cfm(uint8_t *bd_addr, uint8_t local_server_chann, bool accept,
                         uint16_t frame_size,
                         uint8_t init_credits);

/**
  * @brief  Send a request to disconnect a RFCOMM channel.
  * @param  bd_addr                remote bd_addr
  * @param  local_server_chann     local server channel
  * @return The result of sending request.
  * @retval true    The request has benn sent successfully.
  * @retval false   The request was fail to send.
  */
bool bt_gfps_disconnect_req(uint8_t *bd_addr, uint8_t local_server_chann);

/**
  * @brief  Enable silence mode to remote device.
  * @param  bd_addr                remote bd_addr
  * @param  local_server_chann     local server channel
  * @return The result of sending request.
  * @retval true    The request has benn sent successfully.
  * @retval false   The request was fail to send.
  */
bool bt_gfps_enable_silence_mode(uint8_t *bd_addr, uint8_t local_server_chann);

/**
  * @brief  Disable silence mode to remote device.
  * @param  bd_addr                remote bd_addr
  * @param  local_server_chann     local server channel
  * @return The result of sending request.
  * @retval true    The request has benn sent successfully.
  * @retval false   The request was fail to send.
  */
bool bt_gfps_disable_silence_mode(uint8_t *bd_addr, uint8_t local_server_chann);

/**
  * @brief  Send log buffer full command to remote device.
  * @param  bd_addr                remote bd_addr
  * @param  local_server_chann     local server channel
  * @return The result of sending request.
  * @retval true    The request has benn sent successfully.
  * @retval false   The request was fail to send.
  */
bool bt_gfps_send_log_buf_full(uint8_t *bd_addr, uint8_t local_server_chann);

/**
  * @brief  Send gfps model id to remote device.
  * @param  bd_addr                remote bd_addr
  * @param  local_server_chann     local server channel
  * @param  p_data                 model id
  * @param  data_len               data length
  * @return The result of sending request.
  * @retval true    The request has benn sent successfully.
  * @retval false   The request was fail to send.
  */
bool bt_gfps_send_model_id(uint8_t *bd_addr, uint8_t local_server_chann, uint8_t *p_data,
                           uint16_t data_len);

/**
  * @brief  Send ble random address to remote device.
  * @param  bd_addr                remote bd_addr
  * @param  local_server_chann     local server channel
  * @param  ble_addr               ble random address
  * @return The result of sending request.
  * @retval true    The request has benn sent successfully.
  * @retval false   The request was fail to send.
  */
bool bt_gfps_send_ble_addr(uint8_t *bd_addr, uint8_t local_server_chann, uint8_t *ble_addr);

/**
  * @brief  Update current components and charger box battery to remote device.
  * @param  bd_addr                remote bd_addr
  * @param  local_server_chann     local server channel
  * @param  p_data                 components and charger box battery
  * @param  data_len               data length
  * @return The result of sending request.
  * @retval true    The request has benn sent successfully.
  * @retval false   The request was fail to send.
  */
bool bt_gfps_updated_battery(uint8_t *bd_addr, uint8_t local_server_chann, uint8_t *p_data,
                             uint16_t data_len);

/**
  * @brief  Response current active components state to remote device.
  * @param  bd_addr                remote bd_addr
  * @param  local_server_chann     local server channel
  * @param  p_data                 components state
  * @param  data_len               data length
  * @return The result of sending request.
  * @retval true    The request has benn sent successfully.
  * @retval false   The request was fail to send.
  */
bool bt_gfps_active_components_rsp(uint8_t *bd_addr, uint8_t local_server_chann, uint8_t *p_data,
                                   uint16_t data_len);

/**
  * @brief  Send an ack message to indicate remote device the action be performed.
  * @param  bd_addr                remote bd_addr
  * @param  local_server_chann     local server channel
  * @param  p_data                 message group and code
  * @param  data_len               data length
  * @return The result of sending request.
  * @retval true    The request has benn sent successfully.
  * @retval false   The request was fail to send.
  */
bool bt_gfps_send_ack(uint8_t *bd_addr, uint8_t local_server_chann, uint8_t *p_data,
                      uint16_t data_len);

/**
  * @brief  Send an nak message to indicate remote device the action not be performed.
  * @param  bd_addr                remote bd_addr
  * @param  local_server_chann     local server channel
  * @param  p_data                 message group and message code
  * @param  data_len               data length
  * @param  reason                 nak reason
  * @return The result of sending request.
  * @retval true    The request has benn sent successfully.
  * @retval false   The request was fail to send.
  */
bool bt_gfps_send_nak(uint8_t *bd_addr, uint8_t local_server_chann, uint8_t *p_data,
                      uint16_t data_len, uint8_t reason);

/**
 * End of BT_GFPS
 * @}
 */

/** @} End of GFPS */

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* _BT_GFPS_H_ */

