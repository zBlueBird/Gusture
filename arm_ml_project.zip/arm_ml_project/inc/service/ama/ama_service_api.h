/**
*****************************************************************************************
*     Copyright(c) 2018, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
* @file
* @brief
* @details
* @author
* @date
* @version
**************************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2018 Realtek Semiconductor Corporation</center></h2>
**************************************************************************************
*/

/*============================================================================*
 *                      Define to prevent recursive inclusion
 *============================================================================*/
#ifndef __AMA_SERVICE_API__
#define __AMA_SERVICE_API__

#include "ama_api.h"
#include "common.pb.h"
#include "state.pb.h"
#include "central.pb.h"
#include "system.pb.h"


#ifdef __cplusplus
extern "C" {
#endif


/** @defgroup AMA AMA
  * @brief
  * @{
  */


/** @defgroup AMA_SERVICE_API AMA Service API
  * @brief
  * @{
  */


typedef enum
{

    AMA_EVT_START_SPEECH_RSP                    = 2,
    AMA_EVT_STOP_SPEECH                         = 3,
    AMA_EVT_ENDPOINT_SPEECH                     = 4,
    AMA_EVT_PROVIDE_SPEECH                      = 5,
    AMA_EVT_STOP_SPEECH_RSP                     = 6,

    AMA_EVT_NOTIFY_SPEECH_STATE                 = 14,

    AMA_EVT_GET_DEVICE_INFORMATION              = 20,
    AMA_EVT_GET_DEVICE_CONFIGURATION            = 21,
    AMA_EVT_OVERRIDE_ASSISTANT                  = 22,
    AMA_EVT_START_SETUP                         = 23,
    AMA_EVT_COMPLETE_SETUP                      = 24,
    AMA_EVT_NOTIFY_DEVICE_CONFIGURATION         = 25,
    AMA_EVT_UPGRADE_TRANSPORT                   = 30,
    AMA_EVT_SWITCH_TRANSPORT                    = 31,
    AMA_EVT_FORWARD_AT_COMMAND                  = 40,
    AMA_EVT_INCOMING_CALL                       = 41,
    AMA_EVT_SYNCHRONIZE_SETTINGS                = 50,
    AMA_EVT_RESET_CONNECTION                    = 51,
    AMA_EVT_KEEP_ALIVE                          = 55,
    AMA_EVT_ISSUE_MEDIA_CONTROL                 = 60,
    AMA_EVT_GET_STATE                           = 100,
    AMA_EVT_SET_STATE                           = 101,
    AMA_EVT_SYNCHRONIZE_STATE                   = 102,
    AMA_EVT_GET_CENTRAL_INFORMATION             = 103

} T_AMA_CMD;

typedef enum
{
    AUXILIARY_CONNECTED                = 0x100,

    BLUETOOTH_A2DP_ENABLED             = 0x130,
    BLUETOOTH_HFP_ENABLED              = 0x131,
    BLUETOOTH_A2DP_CONNECTED           = 0x132,
    BLUETOOTH_HFP_CONNECTED            = 0x133,
    BLUETOOTH_CLASSIC_DISCOVERABLE     = 0x134,
    BLUETOOTH_A2DP_ACTIVE              = 0x135,
    BLUETOOTH_HFP_ACTIVE               = 0x136,
    SCO_PRIORITIZATION_ENABLED         = 0x137,

    DEVICE_CALIBRATION_REQUIRED        = 0x200,
    DEVICE_THEME                       = 0x201,
    DEVICE_DND_ENABLED                 = 0x202,
    DEVICE_NETWORK_CONNECTIVITY_STATUS = 0x203,
    PRIVACY_MODE_ENABLED               = 0x204,
    ACTIVE_NOISE_CANCELLATION_LEVEL    = 0x205,
    PASSTHROUGH_LEVEL                  = 0x206,
    SETUP_MODE_ENABLED                 = 0x207,
    EXTERNAL_MICROPHONE_ENABLED        = 0x208,
    FEEDBACK_ANC                       = 0x209,

    MESSAGE_NOTIFICATION               = 0x300,
    CALL_NOTIFICATION                  = 0x301,
    REMOTE_NOTIFICATION                = 0x302,

    START_OF_SPEECH_EARCON_ENABLED     = 0x350,
    END_OF_SPEECH_EARCON_ENABLED       = 0x351,
    WAKE_WORD_DETECTION_ENABLED        = 0x352,
    ALEXA_FOLLOW_UP_MODE_ENABLED       = 0x353,
    MULTI_TURN_DELAY_ENABLED           = 0x354,

    AVRCP_OVERRIDE                     = 0x400,
} T_AMA_STATE_FEATURE;

typedef enum
{
    GOOD_HEALTH,
    TOO_SLOW,
    UNAVAILABLE
} T_NETWORK_CONNECTIVITY_STATUS;

typedef struct
{
    uint32_t    dialog_id;
    ErrorCode   error_code;
} T_AMA_EVENT_START_SPEECH_RSP;

typedef struct
{
    union
    {
        SpeechState speech_state;
        T_AMA_EVENT_START_SPEECH_RSP start_speech_rsp;
        State synchronize_state;
        Platform os_platform;
        SynchronizeSettings synchronize_settings;
    } value;
} T_AMA_CMD_PARAM_INFO;


/**  @brief  AMA status. */
typedef enum
{
    AMA_SUCCESS,
    AMA_ERROR
} T_AMA_STATUS;

typedef struct
{
    uint8_t alexa_state;
    Dialog speech_dialog;
    uint32_t mtu;
} T_AMA_ROLESWAP_SERVICE_PROCESS_INFO;

typedef struct
{
    uint8_t local_bd_addr[6];
    bool is_bt_discoverable;
    bool is_bt_connected;
    bool is_a2dp_connected;
    bool is_hfp_connected;
} T_AMA_BT_INFO;


typedef enum
{
    AMA_ROLE_SINGLE,
    AMA_ROLE_PRIMARY,
    AMA_ROLE_SECONDARY,
} AMA_ROLE;


typedef enum
{
    AMA_STREAM_PROC_CREATED = 0,
    AMA_STREAM_PROC_DELETED = 1,
    AMA_B2B_EVT_MAX         = 2,
} AMA_B2B_EVT;


typedef void (*P_AMA_TX_CBACK)(uint8_t *bd_addr, uint8_t *data, uint16_t length);
typedef void (*P_AMA_CMD_CBACK)(uint8_t *bd_addr, T_AMA_CMD cmd_type, void *event_buf,
                                uint16_t buf_len);
typedef T_AMA_BT_INFO(*P_AMA_GET_BT_INFO_CBACK)(uint8_t *bd_addr);
typedef uint32_t (*AMA_MTU_CBACK)(uint8_t *bd_addr);
typedef bool (*AMA_B2B_SYNC_SEND)(AMA_B2B_EVT evt, uint8_t *buf, uint32_t len);

void ama_cback_register(P_AMA_CMD_CBACK pfn_ama_cmd_cb, P_AMA_GET_BT_INFO_CBACK pfn_get_bt_info,
                        AMA_MTU_CBACK mtu_cb);


/**
    * @brief        This function will initialize the AMA service process module.
    * @return       void
    */
bool ama_service_process_init(P_AMA_TX_CBACK pfn_ama_tx, AMA_B2B_SYNC_SEND sync_send);

/**
    * @brief        This function will process the event.
    * @param[in]    event    The event type.
    * @param[in]    *data    The data provided by the event.
    * @param[in]    len      Length of the data that provide by the event.
    * @return       Status
    */
void ama_process_event_handler(uint8_t *bd_addr, T_AMA_EVENT event, uint8_t *data, uint16_t len);

/**
    * @brief        This function will process the control pdu that received from phone.
    *               The control pdu received from phone must be treated as a stream, it may be not
    *               a complete packet.
    * @param[in]    *stream    The control pdu stream.
    * @param[in]    len        Length of the control pdu stream.
    * @return       Status
    */
T_AMA_STATUS ama_process_control_pdu(uint8_t *bd_addr, uint8_t *stream, uint16_t len);

/**
    * @brief        This function will process the voice data, and the send the voice pdu to the AMA interface.
    * @param[in]    *data      The voice data.
    * @param[in]    len        Length of the voice data.
    * @return       Status
    */
T_AMA_STATUS ama_process_voice_data(uint8_t bd_addr[6], uint8_t *data, uint16_t len);

int32_t ama_set_roleswap_service_process_info(uint8_t *buf);

void ama_get_roleswap_service_process_info(uint8_t *buf);


void ama_set_tx_mtu(uint32_t tx_mtu);

uint32_t ama_get_tx_mtu(void);


void ama_service_update_role(AMA_ROLE role);


void ama_earcon_enable(void);


void ama_earcon_disable(void);


int32_t ama_get_service_info_len(void);


int32_t ama_stream_get_info_len(void);
void ama_stream_proc_b2b_sync_recv(AMA_B2B_EVT evt, uint8_t *buf, uint32_t len);


int32_t ama_stream_set_info(uint8_t *buf);
void ama_stream_get_info(uint8_t *buf);



/** @} End of AMA_SERVICE_API */

/** @} End of AMA */

#ifdef __cplusplus
}
#endif

#endif
