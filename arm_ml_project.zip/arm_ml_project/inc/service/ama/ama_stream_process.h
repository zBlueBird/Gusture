/**
*****************************************************************************************
*     Copyright(c) 2018, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
* @file
* @brief
* @details
* @author
* @date
* @version
**************************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2018 Realtek Semiconductor Corporation</center></h2>
**************************************************************************************
*/

/*============================================================================*
 *                      Define to prevent recursive inclusion
 *============================================================================*/
#ifndef __AMA_STREAM_PROCESS__
#define __AMA_STREAM_PROCESS__

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*
 *                              Header Files
 *============================================================================*/
#include <stdint.h>
#include "ring_buffer.h"
#include "ama_common.h"
#include "ama_service_api.h"


/** @defgroup AMA AMA
  * @brief
  * @{
  */


/** @defgroup  AMA_STREAM_PROCESS AMA Stream Process
    * @brief AMA stream process implementation for audio sample project
    * @{
    */

/*============================================================================*
 *                              Macros
 *============================================================================*/
/** @defgroup AMA_STREAM_PROCESS_Exported_Macros AMA Stream Process Macros
    * @brief
    * @{
    */

#define PDU_FROM_RING_BUFFER_MAX 10

/** End of AMA_STREAM_PROCESS_Exported_Macros
    * @}
    */

/*============================================================================*
 *                              Types
 *============================================================================*/
/** @defgroup AMA_STREAM_PROCESS_Exported_Types AMA Stream Process Types
   * @brief
   * @{
   */
/**  @brief  AMA stream decode state for ring buffer. */
typedef enum
{
    GET_HEADER,
    GET_PAYLOAD
} T_RING_BUFFER_DECODE_STATE;


/**  @brief  AMA stream information. */
typedef struct
{
    uint16_t ama_deocded_pdu_len;
    uint16_t payload_len;
    uint16_t header_len;
    T_RING_BUFFER_DECODE_STATE ama_rb_decode_state;
} T_AMA_STREAM_INFO;


/**  @brief  AMA stream decode packet. */
typedef struct
{
    T_AMA_PKT ama_stream_pkt[PDU_FROM_RING_BUFFER_MAX];
    uint8_t ama_stream_pkt_index;
} T_AMA_STREAM_DECODE_PKT;


typedef struct
{
    uint8_t bd_addr[6];
    T_RING_BUFFER ama_ring_buffer;
    T_AMA_STREAM_INFO ama_stream_info;
    uint8_t *buffer;
    T_AMA_STREAM_DECODE_PKT *ama_stream_decode_pkt;
    bool one_pdu_parsed;
} AMA_STREAM_PROC;


/** End of AMA_STREAM_PROCESS_Exported_Types
    * @}
    */

/*============================================================================*
 *                              Functions
 *============================================================================*/
/** @defgroup AMA_STREAM_PROCESS_Exported_Functions AMA Stream Process Functions
    * @brief
    * @{
    */
bool ama_stream_proc_init(AMA_ROLE *p_role, AMA_B2B_SYNC_SEND sync_send);
AMA_STREAM_PROC *ama_stream_proc_create(uint8_t bd_addr[6]);
bool ama_stream_proc_delete(uint8_t bd_addr[6]);
void ama_stream_send_all_info(void);


/**
    * @brief        This function will process the stream.
    * @param[in]    *stream       The received pdu.
    * @param[in]    stream_len    Length of the received pdu.
    * @param[out]   **pdu         The pdu buffer that store the packaged pdus.
    * @param[out]   *pdu_len      Total length of the packaged pdus.
    * @return       Status
    */
T_AMA_STATUS ama_stream_handler(uint8_t *bd_addr, uint8_t *stream_buf, uint16_t stream_len,
                                uint8_t **pdu,
                                uint16_t *pdu_len);

/** @} */ /* End of group AMA_STREAM_PROCESS_Exported_Functions */

/** @} */ /* End of group AMA_STREAM_PROCESS */

/** @} End of AMA */

#ifdef __cplusplus
}
#endif

#endif

