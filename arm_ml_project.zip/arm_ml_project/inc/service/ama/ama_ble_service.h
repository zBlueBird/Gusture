#ifndef _AMA_BLE_SERVICE_
#define _AMA_BLE_SERVICE_

#include <stdint.h>
#if F_APP_GATT_SERVER_EXT_API_SUPPORT
#include <profile_server_ext.h>
#else
#include <profile_server.h>
#endif

/** @defgroup AMA AMA
  * @brief
  * @{
  */


/** @defgroup AMA_BLE_SERVICE AMA BLE Service
  * @brief
  * @{
  */

#define AMA_RX_DATA_INDEX         (4)
#define AMA_TX_DATA_INDEX         (2)
#define AMA_RX_DATA_CCCD_INDEX    (AMA_RX_DATA_INDEX+1)

//T_TRANSMISSION_STREAM ama_ble_service_init(void);

T_SERVER_ID ama_ble_service_add(void);


/** @} End of AMA_BLE_SERVICE */

/** @} End of AMA */

#endif

