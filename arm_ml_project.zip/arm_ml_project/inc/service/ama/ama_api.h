

#ifndef _AMA_API_H
#define _AMA_API_H


#ifdef __cplusplus
extern "C" {
#endif
/*============================================================================*
 *                              Header Files
 *============================================================================*/

#include <stdint.h>
#include "profile_server.h"
#include "gap.h"
#include "ama_common.h"
#include "speech.pb.h"


/** @defgroup AMA AMA
  * @brief
  * @{
  */


#define SIZEOF_FIELD(STRUCT, FIELD)  (sizeof(((STRUCT*)0)->FIELD))


/** @defgroup AMA_API AMA api
  * @brief
  * @{
  */
#define DEVICE_SERIAL_NUMBER_LENGTH_MAX             SIZEOF_FIELD(DeviceInformation, serial_number)
#define DEVICE_NAME_MAX_LENGTH                      SIZEOF_FIELD(DeviceInformation, name)
#define DEVICE_TYPE_MAX_LENGTH                      SIZEOF_FIELD(DeviceInformation, device_type)
#define DEVICE_SUPPORTED_TRANSPORTS_COUNT_MAX       (SIZEOF_FIELD(DeviceInformation, supported_transports) / sizeof(Transport))


/**  @brief  AMA event type. */
typedef enum
{
    AMA_EVENT_CONNECTED,
    AMA_EVENT_DISCONNECTED,
    AMA_ENENT_NO_OPERATION
} T_AMA_EVENT;



/** @defgroup  AMA_SERVICE_INTERFACE AMA Service Interface
    * @brief AMA service interface implementation for audio sample project
    * @{
    */

/*============================================================================*
 *                              Types
 *============================================================================*/

/*============================================================================*
 *                              Functions
 *============================================================================*/
/** @defgroup AMA_SERVICE_INTERFACE_Exported_Functions AMA Service Interface Functions
    * @brief
    * @{
    */


void ama_set_device_info(char *serial_number, char *name, char *type,
                         pb_size_t supported_transports_count, Transport *supported_transports);

void ama_set_device_config(bool needs_assistant_override, bool needs_setup);

void ama_set_speech_setting(SpeechInitiator *p_speech_initiator, AudioProfile audio_profile,
                            AudioFormat audio_format, AudioSource audio_source);


bool ama_send_start_speech(uint8_t *bd_addr);
bool ama_send_stop_speech(uint8_t *bd_addr);


/** @} End of AMA_API */

/** @} End of AMA */

#ifdef __cplusplus
}
#endif

#endif //HONEYCOMB_CHECKED_AMA_API_H
