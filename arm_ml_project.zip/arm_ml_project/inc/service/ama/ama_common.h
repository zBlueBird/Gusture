/**
*****************************************************************************************
*     Copyright(c) 2018, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
* @file
* @brief
* @details
* @author
* @date
* @version
**************************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2018 Realtek Semiconductor Corporation</center></h2>
**************************************************************************************
*/

/*============================================================================*
 *                 Define to prevent recursive inclusion
 *============================================================================*/
#ifndef __AMA_COMMON__
#define __AMA_COMMON__

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*
 *                                 Header Files
 *============================================================================*/
#include <stdint.h>
#include "trace.h"
#include "os_mem.h"
#include "ring_buffer.h"

/** @defgroup AMA AMA
  * @brief
  * @{
  */

/** @defgroup  AMA_COMMON AMA Common
    * @brief AMA common implementation for audio sample project
    * @{
    */

/*============================================================================*
 *                              Macros
 *============================================================================*/
/** @defgroup AMA_COMMON_Exported_Macros AMA Common Macros
    * @brief
    * @{
    */
#define SIZE_ALIGN(s, align)    (((s) + (align) - 1) & -(align))
#define SIZE_ALIGN4(s)          SIZE_ALIGN(s, 4)
#define SIZE_ALIGN8(s)          SIZE_ALIGN(s, 8)


#define PAYLOAD_LENGTH_1_BYTE_FLAG  0
#define PAYLOAD_LENGTH_2_BYTE_FLAG 1
#define AMA_VERSION 0x01
#define AMA_HEADER_RESERVED_FLAGS 0

#define HEADER_LENGTH_FOR_1_BYTE_PAYLOAD_LENGTH     3
#define HEADER_LENGTH_FOR_2_BYTE_PAYLOAD_LENGTH     (HEADER_LENGTH_FOR_1_BYTE_PAYLOAD_LENGTH + 1)
#define HEADER_LENGTH_MAX_FOR_ALL_PAYLOAD           HEADER_LENGTH_FOR_2_BYTE_PAYLOAD_LENGTH

#define AMA_HEADER_MAX_LENGTH HEADER_LENGTH_FOR_2_BYTE_PAYLOAD_LENGTH
#define AMA_PDU_MAX_LENGTH_OF_BYTES 2

#define UINT16_TO_STREAM(s, u16) {   *s++ = (uint8_t)((u16) >> 8);    \
        *s++ = (uint8_t)((u16) >> 0);   \
    }

//#define AMA_VOICE_FRAME_SIZE 57
#define AMA_VOICE_FRAME_SIZE 48

#define FRAME_NUM 10
#define AMA_VOICE_BUFFER_SIZE 8000

//#define CB_EVENT_DSP_VOICE_DATA_REQ 0xD3

/** End of AMA_COMMON_Exported_Macros
    * @}
    */

/*============================================================================*
 *                                     Types
 *============================================================================*/
/** @defgroup AMA_COMMON_Exported_Types AMA Common Types
    * @brief
    * @{
    */

/**  @brief  AMA packet. */
typedef struct
{
    uint8_t *pdu;
    uint16_t length;
} T_AMA_PKT;


/**  @brief  AMA stream id. */
typedef enum
{
    CONTROL_STREAM_ID = 0,
    VOICE_STREAM_ID = 1,

    UNSUPPORT_STREAM_ID
} T_AMA_STREAM_ID;

/**  @brief  AMA pdu type. */
typedef enum
{
    CONTROL_TYPE = 0,
    VOICE_TYPE = 1,

    UNSUPPORT_TYPE = 31
} T_AMA_PDU_TYPE;

/**  @brief  AMA control pdu type. */
typedef enum
{
    GET_DEVICE_INFO_RESPONSE,
    GET_DEVICE_CONFIG_RESPONSE,
    GENERIC_RESPONSE,
    START_SPEECH,
    STOP_SPEECH,
    PROVIDE_SPEECH,
    UPGRADE_TRANSPORT,
    GET_STATE_RESPONSE,
    GET_STATE,
    GET_CENTRAL_INFORMATION,
    NO_NEED_TO_RESPONSE
} T_AMA_CONTROL_PDU_TYPE;

/**  @brief  AMA send method. */
typedef enum
{
    AMA_BLE,
    AMA_SPP,
    AMA_IAP,
} T_AMA_SEND_METHOD;

typedef enum
{
    AMA_A2DP_PROFILE,
    AMA_HFP_PROFILE
} T_AMA_PROFILE;



/**  @brief  Voice preprocess flow status. */
typedef enum
{
    AMA_VOICE_IDLE,                /* Voice preprocess initial status*/
    AMA_VOICE_RECEIVING,           /* Receing the valid voice data */
    AMA_RECEIVED_LAST_VOICE        /* Voice data preprocessing is complete */
} T_AMA_VOICE_RECEIVE_STATUS;

/**  @brief  Voice data preprocess will use this structure to store the data temporarily */
typedef struct
{
    uint8_t voice_frame_count;                       /* The voice frame count that have been received from dsp */
    uint8_t *voice_buffer;                         /* The voice frame storage buffer */
} T_AMA_VOICE_PREPROCESS_STORAGE;

/**  @brief  AMA alloc memory type */
typedef enum
{
    AMA_VOLATILE_MEMORY,                 /* AMA_VOLATILE_MEMORY will lost data when dlps */
    AMA_NONVOLATILE_MEMORY,              /* AMA_NONVOLATILE_MEMORY will not lost data when dlps */
    AMA_ANY_MEMORY                       /* AMA_ANY_MEMORY will both check AMA_VOLATILE_MEMORY and AMA_NONVOLATILE_MEMORY*/
} T_AMA_ALLOC_MEMORY_TYPE;

void *ama_mem_alloc(T_AMA_ALLOC_MEMORY_TYPE memory_type, uint32_t size);

void ama_mem_free(void *p);


/** @} End of AMA_COMMON */

/** @} End of AMA */

#ifdef __cplusplus
}
#endif

#endif
