#ifndef _MICS_CLIENT_H_
#define _MICS_CLIENT_H_

#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */

#include "mics_def.h"
#include "bt_gatt_client.h"

#if LE_AUDIO_MICS_CLIENT_SUPPORT
typedef struct
{
    uint16_t      conn_handle;
    bool          is_found;
    bool          load_from_ftl;
    T_MICS_MUTE   mic_mute;
} T_MICS_CLIENT_DIS_DONE;

typedef struct
{
    uint16_t        conn_handle;
    uint16_t        cause;
} T_MICS_WRITE_RESULT;

typedef struct
{
    uint16_t            conn_handle;
    T_MICS_MUTE         mic_mute;
} T_MICS_NOTIFY_DATA;

/**
 * \xrefitem Added_API_2_13_1_0 "Added Since 2.13.1.0" "Added API"
 */
bool mics_get_all_inc_aics(uint16_t conn_handle, T_ATTR_INSTANCE *p_aics_instance);
bool mics_write_mute_value(uint16_t conn_handle, T_MICS_MUTE mic_mute);
bool mics_get_mute_value(uint16_t conn_handle, T_MICS_MUTE *p_value);

#endif
#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif
