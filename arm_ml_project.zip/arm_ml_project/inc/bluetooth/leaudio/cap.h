#ifndef _CAP_H_
#define _CAP_H_

#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */

#include "ble_audio_group.h"
#include "csis_def.h"
#include "ble_audio.h"
#include "mics_def.h"

#if LE_AUDIO_CAP_SUPPORT
#define CAP_ACCEPTOR_ROLE    0x01
#define CAP_INITIATOR_ROLE   0x02
#define CAP_COMMANDER_ROLE   0x04

#define GATT_UUID_CAS        0x1853

#define AUDIO_DESCRIPTION_STORAGE  0x01

typedef struct
{
    uint8_t cap_role;
    bool cas_client;
    bool csip_set_coordinator;
    uint8_t csis_num;
    struct
    {
        bool enable;
        T_CSIS_SIRK_TYPE csis_sirk_type;
        uint8_t csis_size;
        uint8_t csis_rank;
        uint8_t csis_feature;
        uint8_t *csis_sirk;
    } cas;
    struct
    {
        bool vcp_vcs_client;
        bool vcp_aics_client;
        uint8_t vcp_aics_cfg;
        bool vcp_vocs_client;
        uint8_t vcp_vocs_cfg;
        bool micp_mic_controller;
    } vcp_micp;

    bool ccp_call_control_client;
    struct
    {
        bool ccp_call_control_server;
        uint8_t tbs_num;
    } tbs;
    bool mcp_media_control_client;
    struct
    {
        bool mcp_media_control_server;
        uint8_t mcs_num;
        uint8_t ots_num;
    } mcs;
} T_CAP_INIT_PARAMS;

typedef struct
{
    uint16_t conn_handle;
    bool     load_from_ftl;
    bool     cas_is_found;
    bool     cas_inc_csis;
    bool     vcs_is_found;
    bool     mics_is_found;
} T_CAP_DIS_DONE;

T_LE_AUDIO_CAUSE cap_vcs_change_mute(T_BLE_AUDIO_GROUP_HANDLE group_handle, uint8_t mute);
T_LE_AUDIO_CAUSE cap_vcs_change_volume(T_BLE_AUDIO_GROUP_HANDLE group_handle,
                                       uint8_t volume_setting);
/**
 * \xrefitem Added_API_2_13_1_0 "Added Since 2.13.1.0" "Added API"
 */
T_LE_AUDIO_CAUSE cap_mics_change_mute(T_BLE_AUDIO_GROUP_HANDLE group_handle, T_MICS_MUTE mic_mute);

bool cap_init(T_CAP_INIT_PARAMS *p_param);

#endif

#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif
