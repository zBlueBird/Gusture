#ifndef _VCS_CLIENT_H_
#define _VCS_CLIENT_H_

#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */

#include "vcs_def.h"
#include "ble_audio.h"
#include "ble_audio_group.h"

#if LE_AUDIO_VCS_CLIENT_SUPPORT

#define VCS_VOLUME_STATE_FLAG 0x01
#define VCS_VOLUME_FLAGS_FLAG 0x02

typedef struct
{
    uint16_t conn_handle;
    bool     is_found;
    bool     load_from_ftl;
    uint8_t  type_exist;
} T_VCS_CLIENT_DIS_DONE;

typedef struct
{
    bool counter_used;
    uint8_t change_counter;
    uint8_t volume_setting;//used only for VCS_CP_SET_ABSOLUTE_VOLUME
} T_VCS_VOLUME_CP_PARAM;

typedef enum
{
    VCS_CHAR_VOLUME_STATE,
    VCS_CHAR_VOLUME_FLAGS,
} T_VCS_CHAR_TYPE;

typedef union
{
    uint8_t volume_flags;
    T_VOLUME_STATE volume_state;
} T_VCS_DATA;

typedef struct
{
    uint16_t        conn_handle;
    bool            is_notify;
    T_VCS_CHAR_TYPE type;
    T_VCS_DATA      data;
} T_VCS_DATA_INFO;

typedef struct
{
    uint16_t    conn_handle;
    uint16_t    cause;
    T_VCS_CP_OP cp_op;
} T_VCS_CP_RESULT;

bool vcs_send_volume_cp(uint16_t conn_handle, T_VCS_CP_OP op, T_VCS_VOLUME_CP_PARAM *p_param);
bool vcs_get_volume_state(uint16_t conn_handle, T_VOLUME_STATE *p_data);
/**
 * \xrefitem Added_API_2_13_1_0 "Added Since 2.13.1.0" "Added API"
 */
bool vcs_get_volume_flags(uint16_t conn_handle, uint8_t *p_data);
/**
 * \xrefitem Added_API_2_13_1_0 "Added Since 2.13.1.0" "Added API"
 */
T_LE_AUDIO_CAUSE vcs_send_volume_cp_by_group(T_BLE_AUDIO_GROUP_HANDLE group_handle, T_VCS_CP_OP op,
                                             T_VCS_VOLUME_CP_PARAM *p_param);

#endif
#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif
