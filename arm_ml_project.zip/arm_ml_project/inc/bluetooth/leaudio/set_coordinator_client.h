#ifndef _SET_COORDINATOR_TEST_H_
#define _SET_COORDINATOR_TEST_H_

#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */

#if LE_AUDIO_CSIS_CLIENT_SUPPORT
#include "csis_rsi.h"
#include "csis_def.h"
#include "ble_audio_group.h"
#include "os_queue.h"

#define CSIS_LOCK_FLAG 0x01
#define CSIS_SIRK_FLAG 0x02
#define CSIS_SIZE_FLAG 0x04
#define CSIS_RANK_FLAG 0x08

typedef enum
{
    SET_COORDINATOR_EVENT_INIT              = 0x00,
    SET_COORDINATOR_EVENT_LOCK_REQ          = 0x01,
    SET_COORDINATOR_EVENT_UNLOCK_REQ        = 0x02,
    SET_COORDINATOR_EVENT_LOCK_NOTIFY       = 0x03,
    SET_COORDINATOR_EVENT_MEM_ADD           = 0x04,
    SET_COORDINATOR_EVENT_MEM_DISC          = 0x05,
    //Error event
    SET_COORDINATOR_EVENT_LOCK_REQ_FAILED   = 0x10,
    SET_COORDINATOR_EVENT_UNLOCK_REQ_FAILED = 0x11,
    SET_COORDINATOR_EVENT_LOCK_DENIED       = 0x12,
} T_SET_COORDINATOR_EVENT;

typedef enum
{
    SET_COORDINATOR_LOCK_UNKNOWN     = 0x00,
    SET_COORDINATOR_LOCK_NO_CONN     = 0x01,
    SET_COORDINATOR_LOCK_NOT_SUPPORT = 0x02,
    SET_COORDINATOR_UNLOCK           = 0x03,
    SET_COORDINATOR_WAIT_FOR_LOCK    = 0x04,
    SET_COORDINATOR_LOCK_GRANTED     = 0x05,
    SET_COORDINATOR_WAIT_FOR_UNLOCK  = 0x06,
    SET_COORDINATOR_LOCK_DENIED      = 0x07,
} T_SET_COORDINATOR_LOCK;

//LE_AUDIO_MSG_CSIS_CLIENT_SEARCH_TIMEOUT
//LE_AUDIO_MSG_CSIS_CLIENT_SEARCH_DONE
typedef struct
{
    T_BLE_AUDIO_GROUP_HANDLE group_handle;
    uint8_t         set_mem_size;
    bool            search_done;
} T_CSIS_SEARCH_RESULT;

//LE_AUDIO_MSG_CSIS_CLIENT_SET_MEM_FOUND
typedef struct
{
    T_BLE_AUDIO_GROUP_HANDLE group_handle;
    T_BLE_AUDIO_DEV_HANDLE   dev_handle;
    uint8_t                 bd_addr[6];
    uint8_t                 addr_type;
    uint16_t                srv_uuid;
    uint8_t                 rank;
    uint8_t                 set_mem_size;
    uint8_t                 sirk[CSI_SIRK_LEN];
} T_CSIS_SET_MEM_FOUND;

//LE_AUDIO_MSG_CSIS_CLIENT_DIS_DONE
typedef struct
{
    uint16_t conn_handle;
    bool    is_found;
    bool    load_from_ftl;
    uint8_t srv_num;
} T_CSIS_CLIENT_DIS_DONE;

//LE_AUDIO_MSG_CSIS_CLIENT_SET_COORDINATOR_LOCK_STATE
typedef struct
{
    T_BLE_AUDIO_GROUP_HANDLE group_handle;
    T_SET_COORDINATOR_EVENT  event;
    T_SET_COORDINATOR_LOCK   lock_state;
} T_CSIS_SET_COORDINATOR_LOCK_STATE;

typedef struct
{
    uint8_t                 bd_addr[6];
    uint8_t                 addr_type;
    uint16_t                srv_uuid;
    uint8_t                 srv_instance_id;
    uint8_t                 char_exit;
    uint8_t                 rank;
    T_CSIS_LOCK             lock;
    uint8_t                 set_mem_size;
    T_CSIS_SIRK_TYPE        sirk_type;
    uint8_t                 sirk[CSI_SIRK_LEN];
} T_CSIS_SET_MEM_INFO;

//LE_AUDIO_MSG_CSIS_CLIENT_READ_RESULT
typedef struct
{
    uint16_t                 cause;
    uint16_t                 conn_handle;
    T_BLE_AUDIO_GROUP_HANDLE group_handle;
    T_BLE_AUDIO_DEV_HANDLE   dev_handle;
    T_CSIS_SET_MEM_INFO      mem_info;
} T_CSIS_READ_RESULT;

//LE_AUDIO_MSG_CSIS_CLIENT_SIRK_CHANGE
typedef struct
{
    T_BLE_AUDIO_GROUP_HANDLE group_handle;
    T_CSIS_SIRK_TYPE         sirk_type;
    uint8_t                  sirk[CSI_SIRK_LEN];
} T_CSIS_SIRK_CHANGE;

typedef struct
{
    uint16_t serv_uuid;
    uint8_t  char_exit;
    uint8_t  set_mem_size;
    T_CSIS_SIRK_TYPE sirk_type;
    uint8_t  sirk[CSI_SIRK_LEN];
} T_CSIS_GROUP_INFO;

bool set_coordinator_check_adv_rsi(uint8_t report_data_len, uint8_t *p_report_data,
                                   uint8_t *p_bd_addr, uint8_t addr_type);
bool set_coordinator_cfg_discover(T_BLE_AUDIO_GROUP_HANDLE group_handle, bool discover,
                                  uint32_t timeout_ms);

bool set_coordinator_read_chars(uint16_t conn_handle, uint8_t instance_id);

/**
 * \xrefitem Added_API_2_13_1_0 "Added Since 2.13.1.0" "Added API"
 */
bool set_coordinator_add_group(T_BLE_AUDIO_GROUP_HANDLE *p_group_handle,
                               P_FUN_AUDIO_GROUP_CB p_fun_cb,
                               T_BLE_AUDIO_DEV_HANDLE *p_dev_handle, T_CSIS_SET_MEM_INFO *p_mem_info);

/**
 * \xrefitem Added_API_2_13_1_0 "Added Since 2.13.1.0" "Added API"
 */
bool set_coordinator_add_dev(T_BLE_AUDIO_GROUP_HANDLE group_handle,
                             T_BLE_AUDIO_DEV_HANDLE *p_dev_handle,
                             T_CSIS_SET_MEM_INFO *p_mem_info);

bool set_coordinator_set_lock(T_BLE_AUDIO_GROUP_HANDLE group_handle);
bool set_coordinator_set_unlock(T_BLE_AUDIO_GROUP_HANDLE group_handle);

/**
 * \xrefitem Added_API_2_13_1_0 "Added Since 2.13.1.0" "Added API"
 */
bool set_coordinator_get_lock_state(T_BLE_AUDIO_GROUP_HANDLE group_handle,
                                    T_SET_COORDINATOR_LOCK *p_lock);

T_BLE_AUDIO_GROUP_HANDLE set_coordinator_find_by_rsi(uint8_t *p_rsi);
T_BLE_AUDIO_GROUP_HANDLE set_coordinator_find_by_sirk(uint8_t *p_sirk);
T_BLE_AUDIO_GROUP_HANDLE set_coordinator_find_by_addr(uint8_t *bd_addr, uint8_t addr_type,
                                                      uint16_t serv_uuid,
                                                      T_BLE_AUDIO_DEV_HANDLE *p_dev_handle);
bool set_coordinator_get_group_info(T_BLE_AUDIO_GROUP_HANDLE group_handle,
                                    T_CSIS_GROUP_INFO *p_info);

/**
 * \xrefitem Added_API_2_13_1_0 "Added Since 2.13.1.0" "Added API"
 */
bool set_coordinator_get_mem_info(T_BLE_AUDIO_GROUP_HANDLE group_handle,
                                  T_BLE_AUDIO_DEV_HANDLE dev_handle,
                                  T_CSIS_SET_MEM_INFO *p_info);

#endif

#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif
