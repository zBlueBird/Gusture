#ifndef _HAP_CLIENT_H_
#define _HAP_CLIENT_H_

#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */

#include "has_def.h"
#include "profile_client.h"


//#if LE_AUDIO_HAS_CLIENT_SUPPORT
typedef enum
{
    HAS_OP_ENABLE_ALL = 0x00
} T_HAS_CCCD_OP_TYPE;

typedef struct
{
    uint16_t conn_handle;
    bool     is_found;
    bool     load_from_ftl;
    bool     is_cp_support;
    uint16_t has_cp_properties;
    bool     is_ha_feature_notify_support;
} T_HAS_CLIENT_DIS_DONE;

typedef struct
{
    uint16_t conn_handle;
    uint16_t cause;
    T_HAS_HA_FEATURES has_feature;
} T_HAS_CLT_READ_HA_FEATURE_RESULT;

typedef struct
{
    uint16_t conn_handle;
    uint16_t cause;
    uint8_t active_preset_idx;
} T_HAS_CLT_READ_ACTIVE_PRESET_IDX_RESULT;

typedef struct
{
    uint16_t conn_handle;
    uint16_t cause;
} T_HAS_CLIENT_WRITE_RESULT;

typedef struct
{
    uint16_t conn_handle;
    T_HAS_HA_FEATURES has_feature;
} T_HAS_HA_FEATURE_NOTIFY_DATA;

typedef struct
{
    uint16_t conn_handle;
    uint8_t active_preset_idx;
} T_HAS_CLIENT_ATV_IDX_NOTIFY_DATA;

typedef struct
{
    uint8_t opcode;
    uint8_t change_id;
    uint8_t is_last;
    uint8_t pre_idx;
    uint8_t name_length;
    T_HAS_PRESET_FORMAT preset;
} T_HAS_CP_NOTIFY_IND_DATA;

typedef struct
{
    uint16_t conn_handle;
    bool notify;
    T_HAS_CP_NOTIFY_IND_DATA cp_data;
} T_HAS_CLIENT_CP_NOTIFY_IND_DATA;

bool has_client_init(void);
void has_client_enable_cccd(T_HAS_CCCD_OP_TYPE cccd_type, uint16_t conn_handle);
bool has_read_hearing_aid_feature(uint16_t conn_handle);
bool has_read_active_preset_idx(uint16_t conn_handle);
bool has_cp_read_preset(uint16_t conn_handle, uint8_t start_preset_idx, uint8_t preset_num);
bool has_cp_write_preset_name(uint16_t conn_handle, uint8_t preset_idx,
                              uint8_t name_len, char *p_name);
bool has_cp_set_active_preset(uint16_t conn_handle, uint8_t preset_idx, bool is_sync_local);
bool has_cp_set_next_preset(uint16_t conn_handle, bool is_sync_local);
bool has_cp_set_previous_preset(uint16_t conn_handle, bool is_sync_local);

//#endif
#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif
