#ifndef _PACS_CLIENT_H_
#define _PACS_CLIENT_H_

#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */

typedef enum
{
    PACS_AUDIO_AVAILABLE_CONTEXTS,
    PACS_AUDIO_SUPPORTED_CONTEXTS,
    PACS_SINK_AUDIO_LOC,
    PACS_SINK_PAC,
    PACS_SOURCE_AUDIO_LOC,
    PACS_SOURCE_PAC,
} T_PACS_TYPE;

//LE_AUDIO_MSG_PACS_CLIENT_DIS_DONE
typedef struct
{
    uint16_t conn_handle;
    bool    is_found;
    bool    load_from_ftl;
    uint8_t sink_pac_num;
    uint8_t source_pac_num;
    bool    sink_loc_writable;
    bool    sink_loc_exist;
    bool    source_loc_writable;
    bool    source_loc_exist;
} T_PACS_CLIENT_DIS_DONE;

//LE_AUDIO_MSG_PACS_CLIENT_WRITE_SINK_LOC_RESULT
//LE_AUDIO_MSG_PACS_CLIENT_WRITE_SOURCE_LOC_RESULT
typedef struct
{
    uint16_t conn_handle;
    uint16_t cause;
} T_PACS_CLIENT_WRITE_RESULT;

bool pacs_write_sink_audio_locations(uint16_t conn_handle, uint32_t sink_audio_location);
bool pacs_write_source_audio_locations(uint16_t conn_handle, uint32_t source_audio_location);

#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif
