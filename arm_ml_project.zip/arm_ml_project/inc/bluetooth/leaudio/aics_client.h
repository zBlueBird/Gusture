#ifndef _AICS_CLIENT_H_
#define _AICS_CLIENT_H_

#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */

#include "aics_def.h"
#include "profile_client.h"
#include "ble_audio.h"
#include "ble_audio_group.h"

#if LE_AUDIO_AICS_CLIENT_SUPPORT

#define AICS_INPUT_STATE_FLAG      0x01 //aics_cfg_cccd
#define AICS_INPUT_STATUS_FLAG     0x02 //aics_cfg_cccd
#define AICS_AUDIO_INPUT_DESC_FLAG 0x04 //aics_cfg_cccd
#define AICS_INPUT_TYPE_FLAG       0x08
#define AICS_GAIN_SETTINGS_FLAG    0x10

typedef struct
{
    uint16_t data_len;
    uint8_t  *p_data;
} T_AUDIO_INPUT_DESC_DATA;

typedef union
{
    T_AICS_INPUT_STATE       input_state;
    T_AICS_GAIN_SETTING_PROP setting_prop;
    uint8_t                  input_type;
    uint8_t                  input_status;
    T_AUDIO_INPUT_DESC_DATA  audio_desc;
} T_AICS_DATA;

typedef enum
{
    AICS_CHAR_INPUT_STATE,
    AICS_CHAR_GAIN_SETTING_PROP,
    AICS_CHAR_INPUT_TYPE,
    AICS_CHAR_INPUT_STATUS,
    AICS_CHAR_AUDIO_INPUT_DESC,
} T_AICS_CHAR_TYPE;

typedef struct
{
    uint16_t            conn_handle;
    uint8_t             srv_instance_id;
    T_AICS_CHAR_TYPE    type;
    T_AICS_DATA         data;
    uint16_t            cause;
} T_AICS_READ_RESULT;

typedef struct
{
    uint16_t conn_handle;
    bool    is_found;
    bool    load_from_ftl;
    uint8_t srv_num;
} T_AICS_CLIENT_DIS_DONE;

typedef struct
{
    bool counter_used;
    uint8_t change_counter;
    int8_t gaining_setting;
} T_AICS_CP_PARAM;


typedef struct
{
    uint16_t            conn_handle;
    uint8_t             srv_instance_id;
    T_AICS_CHAR_TYPE    type;
    T_AICS_DATA         data;
} T_AICS_NOTIFY_DATA;

typedef struct
{
    uint16_t        conn_handle;
    uint8_t         srv_instance_id;
    uint16_t        cause;
    T_AICS_CP_OP    cp_op;
} T_AICS_CP_RESULT;

typedef struct
{
    uint8_t                  srv_idx;
    uint8_t                  type_exist;
    T_AICS_INPUT_STATE       input_state;
    T_AICS_GAIN_SETTING_PROP setting_prop;
    uint8_t                  input_type;
    uint8_t                  input_status;
    T_AUDIO_INPUT_DESC_DATA  audio_desc;
} T_AICS_SRV_DATA;

bool aics_get_srv_data(uint16_t conn_handle, uint8_t srv_idx, T_AICS_SRV_DATA *p_data);
void aics_cfg_cccd(uint16_t conn_handle, uint8_t srv_idx, uint8_t cfg_flags, bool enable);
bool aics_read_char_value(uint16_t conn_handle, uint8_t srv_idx, T_AICS_CHAR_TYPE type);
bool aics_send_cp(uint16_t conn_handle, uint8_t srv_idx, T_AICS_CP_OP op,
                  T_AICS_CP_PARAM *p_param);
/**
 * \xrefitem Added_API_2_13_1_0 "Added Since 2.13.1.0" "Added API"
 */
T_LE_AUDIO_CAUSE aics_send_cp_by_group(T_BLE_AUDIO_GROUP_HANDLE group_handle, uint8_t srv_idx,
                                       T_AICS_CP_OP op,
                                       T_AICS_CP_PARAM *p_param);

#endif
#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif
