#ifndef _HAS_MGR_H_
#define _HAS_MGR_H_

#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */

#include "profile_server.h"
#include "has_def.h"

#if LE_AUDIO_HAS_SUPPORT
typedef struct
{
    bool is_has_cp_exist;
    bool is_hearing_aid_feature_notify_support;
    bool is_cp_notify;
} T_HAS_ATTR_FEATURE;

typedef struct
{
    uint16_t conn_handle;
    uint8_t write_op;
    uint8_t index;
    uint8_t preset_num;
    uint8_t active_preset_idx;
    uint8_t name_len;
    char *p_name;
} T_HAS_WRITE_REQ;

typedef struct
{
    uint16_t conn_handle;
} T_HAS_HANDLE_CCCD;

bool has_init(T_HAS_ATTR_FEATURE attr_feature, T_HAS_HA_FEATURES hearing_aid_features);
void has_clear_cp_flag(void);
bool has_change_hearing_aid_features(T_HAS_HA_FEATURES hearing_aid_features);
bool has_change_active_preset_idx(uint8_t preset_idx);

bool has_handle_read_preset_rsp(uint16_t conn_handle, uint8_t length,
                                uint8_t *p_value, bool is_last);
bool has_send_preset_change_data(T_HAS_PRESET_CHANGE_ID change_id, uint16_t conn_handle,
                                 uint16_t length, uint8_t *p_value, bool is_last);
bool has_send_preset_change_data_all(T_HAS_PRESET_CHANGE_ID change_id,
                                     uint16_t length, uint8_t *p_value, bool is_last);
#endif
#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif
