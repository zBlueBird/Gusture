/*
 * Copyright (c) 2015, Realtek Semiconductor Corporation. All rights reserved.
 */

#ifndef _OS_SCHED_H_
#define _OS_SCHED_H_

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

extern void (*os_sched_set_hook)(void (*hook)(void *from, void *to));
extern void (*os_task_name_get)(void *p_handle, char **p_task_name);

#ifdef __cplusplus
}
#endif

#endif /* _OS_SCHED_H_ */
