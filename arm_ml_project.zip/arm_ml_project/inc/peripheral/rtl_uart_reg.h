#ifndef RTL_UART_REG_H
#define RTL_UART_REG_H

#include <stdint.h>
#include <stdbool.h>
#include "rtl876x.h"

#ifdef  __cplusplus
extern "C" {
#endif /* __cplusplus */

/*============================================================================*
 *                         UART Registers Memory Map
 *============================================================================*/
typedef struct
{
    __IO uint32_t UART_DLL;                  /*!< 0x00 */
    __IO uint32_t UART_DLM_IER;              /*!< 0x04 */
    __IO uint32_t UART_IIR_FCR;              /*!< 0x08 */
    __IO uint32_t UART_LCR;                  /*!< 0x0C */
    __IO uint32_t UART_CTRL0;                /*!< 0x10 */
    __I  uint32_t UART_LSR;                  /*!< 0x14 */
    uint32_t UART_RSVD0;                     /*!< 0x18 */
    __IO uint32_t UART_SCR;                  /*!< 0x1C */
    __IO uint32_t UART_STSR;                 /*!< 0x20 */
    __IO uint32_t UART_RBR_THR;              /*!< 0x24 */
    __IO uint32_t UART_MISCR;                /*!< 0x28 */
    uint32_t UART_RSVD1[5];                  /*!< 0x2C - 0x3C */
    __IO uint32_t UART_RX_TIMEOUT;           /*!< 0x40 */
    __IO uint32_t UART_RX_TIMEOUT_STS;       /*!< 0x44 */
    __IO uint32_t UART_RX_TIMEOUT_EN;        /*!< 0x48 */
    __I uint32_t  UART_RXTX_FIFO_WL;         /*!< 0x4C */
    __IO uint32_t UART_INT_MASK;             /*!< 0x50 */
    __I uint32_t  UART_TXDONE_INT;           /*!< 0x54 */
    __I uint32_t  UART_TX_THD_INT;           /*!< 0x58 */
    uint32_t UART_RSVD2;                     /*!< 0x5C */
} UART_TypeDef;

/*============================================================================*
 *                         UART Declaration
 *============================================================================*/
#define UART0              ((UART_TypeDef *) UART0_REG_BASE)
#define UART1              ((UART_TypeDef *) UART1_REG_BASE)
#define UART2              ((UART_TypeDef *) UART2_REG_BASE)
#define UART3              ((UART_TypeDef *) UART3_REG_BASE)
#define UART4              ((UART_TypeDef *) UART4_REG_BASE)
#define UART5              ((UART_TypeDef *) UART5_REG_BASE)
#define UART6              ((UART_TypeDef *) UART6_REG_BASE)
#define UART7              ((UART_TypeDef *) UART7_REG_BASE)

/*============================================================================*
 *                         UART Registers and Field Descriptions
 *============================================================================*/
/* 0x00
   7:0     R/W    dll                                 8'h0
   31:8    R      reserved1                           24'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t dll: 8;
        __I uint32_t reserved_0: 24;
    } b;
} UART_DLL_t;



/* 0x04
   7:0     R/W    dlm                                 8'h0
   31:8    R      reserved2                           24'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t dlm: 8;
        __I uint32_t reserved_0: 24;
    } b;
} UART_DLM_t;



/* 0x04
   0       R/W    erbi                                1'h0
   1       R/W    etbei                               1'h0
   2       R/W    elsi                                1'h0
   3       R/W    uart_DUMMY_000                      1'h0
   4       R/W    tx_empty_stop_int_en                1'h0
   5       R/W    tx_fifo_th_int_en                   1'h0
   31:6    R      reserved3                           26'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t erbi: 1;
        __IO uint32_t etbei: 1;
        __IO uint32_t elsi: 1;
        __IO uint32_t uart_DUMMY_000: 1;
        __IO uint32_t tx_empty_stop_int_en: 1;
        __IO uint32_t tx_fifo_th_int_en: 1;
        __I uint32_t reserved_0: 26;
    } b;
} UART_IER_t;



/* 0x08
   0       R      int_pend                            1'h1
   3:1     R      int_id                              3'h0
   31:4    R      reserved4                           28'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t int_pend: 1;
        __I uint32_t int_id: 3;
        __I uint32_t reserved_0: 28;
    } b;
} UART_IIR_t;



/* 0x08
   0       W      rxfifo_error_en                     1'h1
   1       W1C    clear_rxfifo                        1'h0
   2       W1C    clear_txfifo                        1'h0
   3       W      dma_mode                            1'h0
   7:4     R      reserved7                           4'h0
   12:8    W      rxfifo_trigger_level                5'he
   15:13   R      reserved6                           3'h0
   20:16   W      tx_fifo_th                          5'h0
   31:21   R      reserved5                           11'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __O uint32_t rxfifo_error_en: 1;
        __IO uint32_t clear_rxfifo: 1;
        __IO uint32_t clear_txfifo: 1;
        __O uint32_t dma_mode: 1;
        __I uint32_t reserved_2: 4;
        __O uint32_t rxfifo_trigger_level: 5;
        __I uint32_t reserved_1: 3;
        __O uint32_t tx_fifo_th: 5;
        __I uint32_t reserved_0: 11;
    } b;
} UART_FCR_t;



/* 0x0C
   0       R/W    wls0                                1'h1
   1       R      reserved9                           1'h1
   2       R/W    stb                                 1'h0
   3       R/W    parity_en                           1'h0
   4       R/W    even_parity_sel                     1'h0
   5       R/W    stick_parity                        1'h0
   6       R/W    break_ctrl                          1'h0
   7       R/W    dlab                                1'h0
   31:8    R      reserved8                           24'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t wls0: 1;
        __I uint32_t reserved_1: 1;
        __IO uint32_t stb: 1;
        __IO uint32_t parity_sel: 3;
        __IO uint32_t break_ctrl: 1;
        __IO uint32_t dlab: 1;
        __I uint32_t reserved_0: 24;
    } b;
} UART_LCR_t;



/* 0x10
   0       R/W    uart_DUMMY_002                      1'h0
   1       R/W    rts                                 1'h0
   3:2     R/W    uart_DUMMY_001                      2'h0
   4       R/W    loopback_en                         1'h0
   5       R/W    autoflow_en                         1'h0
   31:6    R      reserved10                          26'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t uart_DUMMY_002: 1;
        __IO uint32_t rts: 1;
        __IO uint32_t uart_DUMMY_001: 2;
        __IO uint32_t loopback_en: 1;
        __IO uint32_t autoflow_en: 1;
        __I uint32_t reserved_0: 26;
    } b;
} UART_CTRL0_t;



/* 0x14
   0       R      rxfifo_datardy                      1'h0
   1       R      overrun_err                         1'h0
   2       R      parity_err                          1'h0
   3       R      framing_err                         1'h0
   4       R      break_err_int                       1'h0
   5       R      tx_fifo_empty_indicator             1'h1
   6       R      tx_empty                            1'h1
   7       R      rxfifo_err                          1'h0
   31:8    R      reserved11                          24'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t rxfifo_datardy: 1;
        __I uint32_t overrun_err: 1;
        __I uint32_t parity_err: 1;
        __I uint32_t framing_err: 1;
        __I uint32_t break_err_int: 1;
        __I uint32_t tx_fifo_empty_indicator: 1;
        __I uint32_t tx_empty: 1;
        __I uint32_t rxfifo_err: 1;
        __I uint32_t reserved_0: 24;
    } b;
} UART_LSR_t;



/* 0x1C
   2:0     R      reserved16                          3'h0
   3       R/W    Pin_lb_test                         1'h0
   5:4     R/W    uart_DUMMY_003                      2'h0
   6       R/W    rxbreaksignalinterruptenable        1'h0
   7       R/W1C  rxbreaksignalinterruptstatus        1'h0
   11:8    R/W    Dbg_sel[3:0]                        4'h0
   15:12   R      reserved15                          4'h0
   26:16   R/W    xfactor_adj[10:0]                   11'h0
   31:27   R      reserved14                          5'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t reserved_2: 3;
        __IO uint32_t Pin_lb_test: 1;
        __IO uint32_t uart_DUMMY_003: 2;
        __IO uint32_t rx_break_signal_interrupt_enable: 1;
        __IO uint32_t rx_break_signal_interrupt_status: 1;
        __IO uint32_t Dbg_sel: 4;
        __I uint32_t reserved_1: 4;
        __IO uint32_t xfactor_adj: 11;
        __I uint32_t reserved_0: 5;
    } b;
} UART_SCR_t;



/* 0x20
   2:0     R      reserved19                          3'h0
   3       R/W    reset_rcv                           1'h0
   7:4     R/W    xfactor                             4'hb
   18:8    R      reserved18                          11'h0
   23:19   R      tx_fifo_th                          5'h0
   24      R      dma_mode                            1'h0
   25      R      rxfifo_error_en                     1'h1
   30:26   R      rxfifo_trigger_level                5'he
   31      R      reserved17                          1'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t reserved_2: 3;
        __IO uint32_t reset_rcv: 1;
        __IO uint32_t xfactor: 4;
        __I uint32_t reserved_1: 11;
        __I uint32_t tx_fifo_th: 5;
        __I uint32_t dma_mode: 1;
        __I uint32_t rxfifo_error_en: 1;
        __I uint32_t rxfifo_trigger_level: 5;
        __I uint32_t reserved_0: 1;
    } b;
} UART_STSR_t;


/* 0x24
   7:0     W      rx_data                             8'h0
   31:8    R      reserved21                          24'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t rx_data: 8;
        __I uint32_t reserved_0: 24;
    } b;
} UART_RBR_t;



/* 0x24
   7:0     W      tx_data                             8'h0
   31:8    R      reserved21                          24'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __O uint32_t tx_data: 8;
        __I uint32_t reserved_0: 24;
    } b;
} UART_THR_t;



/* 0x28
   0       R/W    uart_DUMMY_005                      1'h0
   1       R/W    txdma_en                            1'h0
   2       R/W    rxdma_en                            1'h0
   7:3     R/W    txdma_burstsize                     5'h0
   13:8    R/W    rxdma_burstsize                     6'h0
   15:14   R/W    uart_DUMMY_004                      2'h0
   31:16   R      reserved22                          16'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t uart_DUMMY_005: 1;
        __IO uint32_t txdma_en: 1;
        __IO uint32_t rxdma_en: 1;
        __IO uint32_t txdma_burstsize: 5;
        __IO uint32_t rxdma_burstsize: 6;
        __IO uint32_t uart_DUMMY_004: 2;
        __I uint32_t reserved_0: 16;
    } b;
} UART_MISCR_t;



/* 0x40
   3:0     R/W    rxidle_timeout_value                4'h0
   30:4    R      reserved23                          27'h0
   31      R/W    rxidle_timeourt_en                  1'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t rxidle_timeout_value: 4;
        __I uint32_t reserved_0: 27;
        __IO uint32_t rxidle_timeourt_en: 1;
    } b;
} UART_RX_TIMEOUT_t;



/* 0x44
   0       R/W1C  rxidle_timeout_int_sts              1'h0
   31:1    R      reserved24                          31'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t rxidle_timeout_int_sts: 1;
        __I uint32_t reserved_0: 31;
    } b;
} UART_RX_TIMEOUT_STS_t;



/* 0x48
   0       R/W    rxidle_timeout_int_en               1'h0
   31:1    R      reserved25                          31'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t rxidle_timeout_int_en: 1;
        __I uint32_t reserved_0: 31;
    } b;
} UART_RX_TIMEOUT_EN_t;



/* 0x4C
   4:0     R      tx_fifo_level                       5'h0
   7:5     R      reserved27                          3'h0
   13:8    R      rx_fifo_level                       6'h0
   31:14   R      reserved26                          18'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t tx_fifo_level: 5;
        __I uint32_t reserved_1: 3;
        __I uint32_t rx_fifo_level: 6;
        __I uint32_t reserved_0: 18;
    } b;
} UART_RXTX_FIFO_WL_t;



/* 0x50
   0       R/W    int_mask_0                          1'h0
   1       R/W    int_mask_1                          1'h0
   2       R/W    int_mask_2                          1'h0
   3       R/W    int_mask_3                          1'h0
   4       R/W    int_mask_4                          1'h0
   5       R/W    int_mask_5                          1'h0
   6       R/W    int_mask_6                          1'h0
   7       R/W    int_mask_7                          1'h0
   31:8    R      reserved28                          24'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t int_mask_0: 1;
        __IO uint32_t int_mask_1: 1;
        __IO uint32_t int_mask_2: 1;
        __IO uint32_t int_mask_3: 1;
        __IO uint32_t int_mask_4: 1;
        __IO uint32_t int_mask_5: 1;
        __IO uint32_t int_mask_6: 1;
        __IO uint32_t int_mask_7: 1;
        __I uint32_t reserved_0: 24;
    } b;
} UART_INT_MASK_t;



/* 0x54
   0       R      tx_empty_stop_rdy                   1'h0
   31:1    R      reserved29                          31'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t tx_empty_stop_rdy: 1;
        __I uint32_t reserved_0: 31;
    } b;
} UART_TXDONE_INT_t;



/* 0x58
   0       R      int_tx_fifo                         1'h0
   31:1    R      reserved30                          31'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t int_tx_fifo: 1;
        __I uint32_t reserved_0: 31;
    } b;
} UART_TX_THD_INT_t;


#ifdef  __cplusplus
}
#endif /* __cplusplus */
#endif /* RTL_UART_REG_H */
