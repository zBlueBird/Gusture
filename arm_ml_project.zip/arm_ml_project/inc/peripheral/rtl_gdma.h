/**
*********************************************************************************************************
*               Copyright(c) 2021, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file     rtl_gdma.h
* @brief    The header file of the peripheral GDMA driver.
* @details  This file provides all GDMA firmware functions.
* @author   Bert
* @date     2021-10-18
* @version  v1.0.2
* *********************************************************************************************************
*/

#ifndef RTL_GDMA_H
#define RTL_GDMA_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * \addtogroup  IO          Peripheral Drivers
 * \defgroup    GDMA        GDMA
 *
 * \brief       Manage the GDMA peripheral functions.
 *
 * \ingroup     IO
 */

/*============================================================================*
 *                         Includes
 *============================================================================*/
#include "rtl876x.h"
#include "rtl_gdma_reg.h"

/*============================================================================*
 *                         Constants
 *============================================================================*/
/**
 * \defgroup    GDMA_Exported_Constants     Macro Definitions
 *
 * \ingroup     GDMA
 */

/**
 * \defgroup    GDMA_Define GDMA Define
 * \{
 * \ingroup     GDMAT_Exported_Constants
 */
#define IS_GDMA_ChannelNum(NUM) ((NUM) < 27)
#define GDMA0_CH_MAX        3
#define GDMA1_CH_MAX        8
#define GDMA2_CH_MAX        16

#define GDMA0_CH_NUM0       0
#define GDMA0_CH_NUM1       1
#define GDMA0_CH_NUM2       2

#define GDMA1_CH_NUM0       3
#define GDMA1_CH_NUM1       4
#define GDMA1_CH_NUM2       5
#define GDMA1_CH_NUM3       6
#define GDMA1_CH_NUM4       7
#define GDMA1_CH_NUM5       8
#define GDMA1_CH_NUM6       9
#define GDMA1_CH_NUM7       10

#define GDMA2_CH_NUM0       11
#define GDMA2_CH_NUM1       12
#define GDMA2_CH_NUM2       13
#define GDMA2_CH_NUM3       14
#define GDMA2_CH_NUM4       15
#define GDMA2_CH_NUM5       16
#define GDMA2_CH_NUM6       17
#define GDMA2_CH_NUM7       18
#define GDMA2_CH_NUM8       19
#define GDMA2_CH_NUM9       20
#define GDMA2_CH_NUM10      21
#define GDMA2_CH_NUM11      22
#define GDMA2_CH_NUM12      23
#define GDMA2_CH_NUM13      24
#define GDMA2_CH_NUM14      25
#define GDMA2_CH_NUM15      26

#define GDMA_CH_NUM0        GDMA0_CH_NUM0
#define GDMA_CH_NUM1        GDMA0_CH_NUM1
#define GDMA_CH_NUM2        GDMA0_CH_NUM2

#define GDMA_CH_NUM3        GDMA1_CH_NUM0
#define GDMA_CH_NUM4        GDMA1_CH_NUM1
#define GDMA_CH_NUM5        GDMA1_CH_NUM2
#define GDMA_CH_NUM6        GDMA1_CH_NUM3
#define GDMA_CH_NUM7        GDMA1_CH_NUM4
#define GDMA_CH_NUM8        GDMA1_CH_NUM5
#define GDMA_CH_NUM9        GDMA1_CH_NUM6
#define GDMA_CH_NUM10       GDMA1_CH_NUM7

#define GDMA_CH_NUM11       GDMA2_CH_NUM0
#define GDMA_CH_NUM12       GDMA2_CH_NUM1
#define GDMA_CH_NUM13       GDMA2_CH_NUM2
#define GDMA_CH_NUM14       GDMA2_CH_NUM3
#define GDMA_CH_NUM15       GDMA2_CH_NUM4
#define GDMA_CH_NUM16       GDMA2_CH_NUM5
#define GDMA_CH_NUM17       GDMA2_CH_NUM6
#define GDMA_CH_NUM18       GDMA2_CH_NUM7
#define GDMA_CH_NUM19       GDMA2_CH_NUM8
#define GDMA_CH_NUM20       GDMA2_CH_NUM9
#define GDMA_CH_NUM21       GDMA2_CH_NUM10
#define GDMA_CH_NUM22       GDMA2_CH_NUM11
#define GDMA_CH_NUM23       GDMA2_CH_NUM12
#define GDMA_CH_NUM24       GDMA2_CH_NUM13
#define GDMA_CH_NUM25       GDMA2_CH_NUM14
#define GDMA_CH_NUM26       GDMA2_CH_NUM15

#define GDMA0_CH_NUM_MIN    GDMA_CH_NUM0
#define GDMA0_CH_NUM_MAX    GDMA_CH_NUM2

#define GDMA1_CH_NUM_MIN    GDMA_CH_NUM3
#define GDMA1_CH_NUM_MAX    GDMA_CH_NUM10

#define GDMA2_CH_NUM_MIN    GDMA_CH_NUM11
#define GDMA2_CH_NUM_MAX    GDMA_CH_NUM26

#define IS_GDMA_ALL_PERIPH(PERIPH) (((PERIPH) == GDMA_Channel0) || \
                                    ((PERIPH) == GDMA_Channel1) || \
                                    ((PERIPH) == GDMA_Channel2) || \
                                    ((PERIPH) == GDMA_Channel3) || \
                                    ((PERIPH) == GDMA_Channel4) || \
                                    ((PERIPH) == GDMA_Channel5) || \
                                    ((PERIPH) == GDMA_Channel6) || \
                                    ((PERIPH) == GDMA_Channel7) || \
                                    ((PERIPH) == GDMA_Channel8) || \
                                    ((PERIPH) == GDMA_Channel9) || \
                                    ((PERIPH) == GDMA_Channel10) || \
                                    ((PERIPH) == GDMA_Channel11) || \
                                    ((PERIPH) == GDMA_Channel12) || \
                                    ((PERIPH) == GDMA_Channel13) || \
                                    ((PERIPH) == GDMA_Channel14) || \
                                    ((PERIPH) == GDMA_Channel15) || \
                                    ((PERIPH) == GDMA_Channel16) || \
                                    ((PERIPH) == GDMA_Channel17) || \
                                    ((PERIPH) == GDMA_Channel18) || \
                                    ((PERIPH) == GDMA_Channel19) || \
                                    ((PERIPH) == GDMA_Channel20) || \
                                    ((PERIPH) == GDMA_Channel21) || \
                                    ((PERIPH) == GDMA_Channel22) || \
                                    ((PERIPH) == GDMA_Channel23) || \
                                    ((PERIPH) == GDMA_Channel24) || \
                                    ((PERIPH) == GDMA_Channel25) || \
                                    ((PERIPH) == GDMA_Channel26))

/**
 * \defgroup    GDMA_Handshake_Type GDMA Handshake Type
 * \{
 * \ingroup     GDMA_Exported_Constants
 */
#define GDMA_Handshake_UART0_TX             (0)
#define GDMA_Handshake_UART0_RX             (1)
#define GDMA_Handshake_UART1_TX             (2)
#define GDMA_Handshake_UART1_RX             (3)
#define GDMA_Handshake_UART2_TX             (4)
#define GDMA_Handshake_UART2_RX             (5)
#define GDMA_Handshake_UART3_TX             (6)
#define GDMA_Handshake_UART3_RX             (7)
#define GDMA_Handshake_UART4_TX             (8)
#define GDMA_Handshake_UART4_RX             (9)
#define GDMA_Handshake_UART5_TX             (10)
#define GDMA_Handshake_UART5_RX             (11)
#define GDMA_Handshake_UART6_TX             (12)
#define GDMA_Handshake_UART6_RX             (13)
#define GDMA_Handshake_I2C0_TX              (14)
#define GDMA_Handshake_I2C0_RX              (15)
#define GDMA_Handshake_I2C1_TX              (16)
#define GDMA_Handshake_I2C1_RX              (17)
#define GDMA_Handshake_I2C2_TX              (18)
#define GDMA_Handshake_I2C2_RX              (19)
#define GDMA_Handshake_I2C3_TX              (20)
#define GDMA_Handshake_I2C3_RX              (21)
#define GDMA_Handshake_SPI0_TX              (22)
#define GDMA_Handshake_SPI0_RX              (23)
#define GDMA_Handshake_SPI1_TX              (24)
#define GDMA_Handshake_SPI1_RX              (25)
#define GDMA_Handshake_SPI2_TX              (26)
#define GDMA_Handshake_SPI2_RX              (27)
#define GDMA_Handshake_SPI3_TX              (28)
#define GDMA_Handshake_SPI3_RX              (29)
#define GDMA_Handshake_SPI_SLAVE_TX         (30)
#define GDMA_Handshake_SPI_SLAVE_RX         (31)
#define GDMA_Handshake_ENH_TIM0             (32)
#define GDMA_Handshake_ENH_TIM1             (33)
#define GDMA_Handshake_ENH_TIM2             (34)
#define GDMA_Handshake_ENH_TIM3             (35)
#define GDMA_Handshake_ENH_TIM4             (36)
#define GDMA_Handshake_ENH_TIM5             (37)
#define GDMA_Handshake_ENH_TIM6             (38)
#define GDMA_Handshake_ENH_TIM7             (39)
#define GDMA_Handshake_ADC_RX               (40)
#define GDMA_Handshake_AES_TX               (41)
#define GDMA_Handshake_AES_RX               (42)
#define GDMA_Handshake_ECC_TX               (43)
#define GDMA_Handshake_PUB_KEY_TX           (44)
#define GDMA_Handshake_PUB_KEY_RX           (45)
#define GDMA_Handshake_SPIC1_TX             (46)
#define GDMA_Handshake_SPIC1_RX             (47)
#define GDMA_Handshake_SPIC2_TX             (48)
#define GDMA_Handshake_SPIC2_RX             (49)
#define GDMA_Handshake_SPIC3_TX             (50)
#define GDMA_Handshake_SPIC3_RX             (51)
#define GDMA_Handshake_IR_TX                (52)
#define GDMA_Handshake_IR_RX                (53)
#define GDMA_Handshake_I2S0_TDM0_TX         (54)
#define GDMA_Handshake_I2S0_TDM0_RX         (55)
#define GDMA_Handshake_I2S1_TDM0_TX         (56)
#define GDMA_Handshake_I2S1_TDM0_RX         (57)
#define GDMA_Handshake_I2S2_TDM0_TX         (58)
#define GDMA_Handshake_I2S2_TDM0_RX         (59)
#define GDMA_Handshake_I2S3_TDM0_TX         (60)
#define GDMA_Handshake_I2S3_TDM0_RX         (61)
#define GDMA_Handshake_I2S0_TDM1_TX         (62)
#define GDMA_Handshake_I2S0_TDM1_RX         (63)
#define GDMA_Handshake_I2S1_TDM1_TX         (64)
#define GDMA_Handshake_I2S1_TDM1_RX         (65)
#define GDMA_Handshake_I2S2_TDM1_TX         (66)
#define GDMA_Handshake_I2S2_TDM1_RX         (67)
#define GDMA_Handshake_I2S3_TDM1_TX         (68)
#define GDMA_Handshake_I2S3_TDM1_RX         (69)
#define GDMA_Handshake_SPIC0_TX             (70)
#define GDMA_Handshake_SPIC0_RX             (71)
/** \} */ /** End of Group GDMA_Handshake_Type */

#define IS_GDMA_TransferType(Type) (((Type) == GDMA_Handshake_UART0_TX) || \
                                    ((Type) == GDMA_Handshake_UART0_RX) || \
                                    ((Type) == GDMA_Handshake_UART1_TX) || \
                                    ((Type) == GDMA_Handshake_UART1_RX) || \
                                    ((Type) == GDMA_Handshake_UART2_TX) || \
                                    ((Type) == GDMA_Handshake_UART2_RX) || \
                                    ((Type) == GDMA_Handshake_UART3_TX) || \
                                    ((Type) == GDMA_Handshake_UART3_RX) || \
                                    ((Type) == GDMA_Handshake_UART4_TX) || \
                                    ((Type) == GDMA_Handshake_UART4_RX) || \
                                    ((Type) == GDMA_Handshake_UART5_TX) || \
                                    ((Type) == GDMA_Handshake_UART5_RX) || \
                                    ((Type) == GDMA_Handshake_UART6_TX) || \
                                    ((Type) == GDMA_Handshake_UART6_RX) || \
                                    ((Type) == GDMA_Handshake_I2C0_TX)  || \
                                    ((Type) == GDMA_Handshake_I2C0_RX)  || \
                                    ((Type) == GDMA_Handshake_I2C1_TX)  || \
                                    ((Type) == GDMA_Handshake_I2C1_RX)  || \
                                    ((Type) == GDMA_Handshake_I2C2_TX)  || \
                                    ((Type) == GDMA_Handshake_I2C2_RX)  || \
                                    ((Type) == GDMA_Handshake_I2C3_TX)  || \
                                    ((Type) == GDMA_Handshake_I2C3_RX)  ||\
                                    ((Type) == GDMA_Handshake_SPI0_TX)  ||\
                                    ((Type) == GDMA_Handshake_SPI0_RX)  ||\
                                    ((Type) == GDMA_Handshake_SPI1_TX)  ||\
                                    ((Type) == GDMA_Handshake_SPI1_RX)  ||\
                                    ((Type) == GDMA_Handshake_SPI2_TX)  ||\
                                    ((Type) == GDMA_Handshake_SPI2_RX)  ||\
                                    ((Type) == GDMA_Handshake_SPI3_TX)  || \
                                    ((Type) == GDMA_Handshake_SPI3_RX)  || \
                                    ((Type) == GDMA_Handshake_SPI_SLAVE_TX) || \
                                    ((Type) == GDMA_Handshake_SPI_SLAVE_RX) || \
                                    ((Type) == GDMA_Handshake_ENH_TIM0)     || \
                                    ((Type) == GDMA_Handshake_ENH_TIM1)     || \
                                    ((Type) == GDMA_Handshake_ENH_TIM2)     || \
                                    ((Type) == GDMA_Handshake_ENH_TIM3)     || \
                                    ((Type) == GDMA_Handshake_ENH_TIM4)     || \
                                    ((Type) == GDMA_Handshake_ENH_TIM5)     || \
                                    ((Type) == GDMA_Handshake_ENH_TIM6)     || \
                                    ((Type) == GDMA_Handshake_ENH_TIM7)     ||\
                                    ((Type) == GDMA_Handshake_ADC_RX)       || \
                                    ((Type) == GDMA_Handshake_AES_TX)       || \
                                    ((Type) == GDMA_Handshake_AES_RX)       || \
                                    ((Type) == GDMA_Handshake_ECC_TX)       || \
                                    ((Type) == GDMA_Handshake_PUB_KEY_TX)   || \
                                    ((Type) == GDMA_Handshake_PUB_KEY_RX)   || \
                                    ((Type) == GDMA_Handshake_SPIC1_TX)     || \
                                    ((Type) == GDMA_Handshake_SPIC1_RX)     || \
                                    ((Type) == GDMA_Handshake_SPIC2_TX)     || \
                                    ((Type) == GDMA_Handshake_SPIC2_RX)     || \
                                    ((Type) == GDMA_Handshake_SPIC3_TX)     || \
                                    ((Type) == GDMA_Handshake_SPIC3_RX)     || \
                                    ((Type) == GDMA_Handshake_IR_TX)        || \
                                    ((Type) == GDMA_Handshake_IR_RX)        || \
                                    ((Type) == GDMA_Handshake_I2S0_TDM0_TX) || \
                                    ((Type) == GDMA_Handshake_I2S0_TDM0_RX) || \
                                    ((Type) == GDMA_Handshake_I2S1_TDM0_TX) || \
                                    ((Type) == GDMA_Handshake_I2S1_TDM0_RX) || \
                                    ((Type) == GDMA_Handshake_I2S2_TDM0_TX) || \
                                    ((Type) == GDMA_Handshake_I2S2_TDM0_RX) || \
                                    ((Type) == GDMA_Handshake_I2S3_TDM0_TX) || \
                                    ((Type) == GDMA_Handshake_I2S3_TDM0_RX) || \
                                    ((Type) == GDMA_Handshake_I2S0_TDM1_TX) || \
                                    ((Type) == GDMA_Handshake_I2S0_TDM1_RX) || \
                                    ((Type) == GDMA_Handshake_I2S1_TDM1_TX) || \
                                    ((Type) == GDMA_Handshake_I2S1_TDM1_RX) || \
                                    ((Type) == GDMA_Handshake_I2S2_TDM1_TX) || \
                                    ((Type) == GDMA_Handshake_I2S2_TDM1_RX) || \
                                    ((Type) == GDMA_Handshake_I2S3_TDM1_TX) || \
                                    ((Type) == GDMA_Handshake_I2S3_TDM1_RX) || \
                                    ((Type) == GDMA_Handshake_SPIC0_TX)     || \
                                    ((Type) == GDMA_Handshake_SPIC0_RX))

/**
 * \defgroup    GDMA_Channel_Re_define GDMA Channe Type Re_define
 * \{
 * \ingroup     GDMA_Exported_Constants
 */
#define GDMA_Channel3_IRQn              GDMA1_Channel0_IRQn
#define GDMA_Channel4_IRQn              GDMA1_Channel1_IRQn
#define GDMA_Channel5_IRQn              GDMA1_Channel2_IRQn
#define GDMA_Channel6_IRQn              GDMA1_Channel3_IRQn
#define GDMA_Channel7_IRQn              GDMA1_Channel4_IRQn
#define GDMA_Channel8_IRQn              GDMA1_Channel5_IRQn
#define GDMA_Channel9_IRQn              GDMA1_Channel6_IRQn
#define GDMA_Channel10_IRQn             GDMA1_Channel7_IRQn
#define GDMA_Channel11_IRQn             GDMA2_Channel0_IRQn
#define GDMA_Channel12_IRQn             GDMA2_Channel1_IRQn
#define GDMA_Channel13_IRQn             GDMA2_Channel2_IRQn
#define GDMA_Channel14_IRQn             GDMA2_Channel3_IRQn
#define GDMA_Channel15_IRQn             GDMA2_Channel4_IRQn
#define GDMA_Channel16_IRQn             GDMA2_Channel5_IRQn
#define GDMA_Channel17_IRQn             GDMA2_Channel6_IRQn
#define GDMA_Channel18_IRQn             GDMA2_Channel7_IRQn
#define GDMA_Channel19_IRQn             GDMA2_Channel8_IRQn
#define GDMA_Channel20_IRQn             GDMA2_Channel9_IRQn
#define GDMA_Channel21_IRQn             GDMA2_Channel10_IRQn
#define GDMA_Channel22_IRQn             GDMA2_Channel11_IRQn
#define GDMA_Channel23_IRQn             GDMA2_Channel12_IRQn
#define GDMA_Channel24_IRQn             GDMA2_Channel13_IRQn
#define GDMA_Channel25_IRQn             GDMA2_Channel14_IRQn
#define GDMA_Channel26_IRQn             GDMA2_Channel15_IRQn

#define GDMA_Channel3_Handler           GDMA1_Channel0_Handler
#define GDMA_Channel4_Handler           GDMA1_Channel1_Handler
#define GDMA_Channel5_Handler           GDMA1_Channel2_Handler
#define GDMA_Channel6_Handler           GDMA1_Channel3_Handler
#define GDMA_Channel7_Handler           GDMA1_Channel4_Handler
#define GDMA_Channel8_Handler           GDMA1_Channel5_Handler
#define GDMA_Channel9_Handler           GDMA1_Channel6_Handler
#define GDMA_Channel10_Handler          GDMA1_Channel7_Handler
#define GDMA_Channel11_Handler          GDMA2_Channel0_Handler
#define GDMA_Channel12_Handler          GDMA2_Channel1_Handler
#define GDMA_Channel13_Handler          GDMA2_Channel2_Handler
#define GDMA_Channel14_Handler          GDMA2_Channel3_Handler
#define GDMA_Channel15_Handler          GDMA2_Channel4_Handler
#define GDMA_Channel16_Handler          GDMA2_Channel5_Handler
#define GDMA_Channel17_Handler          GDMA2_Channel6_Handler
#define GDMA_Channel18_Handler          GDMA2_Channel7_Handler
#define GDMA_Channel19_Handler          GDMA2_Channel8_Handler
#define GDMA_Channel20_Handler          GDMA2_Channel9_Handler
#define GDMA_Channel21_Handler          GDMA2_Channel10_Handler
#define GDMA_Channel22_Handler          GDMA2_Channel11_Handler
#define GDMA_Channel23_Handler          GDMA2_Channel12_Handler
#define GDMA_Channel24_Handler          GDMA2_Channel13_Handler
#define GDMA_Channel25_Handler          GDMA2_Channel14_Handler
#define GDMA_Channel26_Handler          GDMA2_Channel15_Handler
/** \} */ /** End of Group GDMA_Channel_Re_define */

/*============================================================================*
 *                         Types
 *============================================================================*/
/**
 * \defgroup   GDMA_Exported_Types  GDMA Exported Types
 * \brief
 * \ingroup    GDMA
 */

/**
 * \defgroup    GDMA_Data_Transfer_Direction GDMA Data Transfer Direction
 * \{
 * \ingroup     GDMA_Exported_Constants
 */

typedef enum
{
    GDMA_DIR_MemoryToMemory = 0x0,
    GDMA_DIR_MemoryToPeripheral = 0x1,
    GDMA_DIR_PeripheralToMemory = 0x2,
    GDMA_DIR_PeripheralToPeripheral = 0x3,
} GDMA_DIRECTION_T;
/** \} */ /** End of Group GDMA_Data_Transfer_Direction */

#define IS_GDMA_DIR(DIR) (((DIR) == GDMA_DIR_MemoryToMemory) || \
                          ((DIR) == GDMA_DIR_MemoryToPeripheral) || \
                          ((DIR) == GDMA_DIR_PeripheralToMemory) || \
                          ((DIR) == GDMA_DIR_PeripheralToPeripheral))

/**
 * \defgroup    GDMA_Source_Incremented_Mode GDMA Source Incremented Mode
 * \{
 * \ingroup     GDMA_Exported_Constants
 */
typedef enum
{
    DMA_SourceInc_Inc = 0x0,
    DMA_SourceInc_Dec = 0x1,
    DMA_SourceInc_Fix = 0x2,
} GDMA_SRC_INC_T;
/** \} */ /** End of Group GDMA_Source_Incremented_Mode */

#define IS_GDMA_SourceInc(STATE) (((STATE) == DMA_SourceInc_Inc) || \
                                  ((STATE) == DMA_SourceInc_Dec) || \
                                  ((STATE) == DMA_SourceInc_Fix))

/**
 * \defgroup    GDMA_Destination_Incremented_Mode GDMA Destination Incremented Mode
 * \{
 * \ingroup     GDMA_Exported_Constants
 */
typedef enum
{
    DMA_DestinationInc_Inc = 0x0,
    DMA_DestinationInc_Dec = 0x1,
    DMA_DestinationInc_Fix = 0x2,
} GDMA_DEST_INC_T;
/** \} */ /** End of Group GDMA_Destination_Incremented_Mode */

#define IS_GDMA_DestinationInc(STATE) (((STATE) == DMA_DestinationInc_Inc) || \
                                       ((STATE) == DMA_DestinationInc_Dec) || \
                                       ((STATE) == DMA_DestinationInc_Fix))

/**
 * \defgroup    GDMA_Data_Size GDMA Data Size
 * \{
 * \ingroup     GDMA_Exported_Constants
 */
typedef enum
{
    GDMA_DataSize_Byte     = 0x0,
    GDMA_DataSize_HalfWord = 0x1,
    GDMA_DataSize_Word     = 0x2,
} GDMA_DATASIZE_T;
/** \} */ /** End of Group GDMA_Data_Size */

#define IS_GDMA_DATA_SIZE(SIZE) (((SIZE) == GDMA_DataSize_Byte) || \
                                 ((SIZE) == GDMA_DataSize_HalfWord) || \
                                 ((SIZE) == GDMA_DataSize_Word))

/**
 * \defgroup    GDMA_Msize GDMA Msize
 * \{
 * \ingroup     GDMA_Exported_Constants
 */
typedef enum
{
    GDMA_Msize_1   = 0x0,
    GDMA_Msize_4   = 0x1,
    GDMA_Msize_8   = 0x2,
    GDMA_Msize_16  = 0x3,
    GDMA_Msize_32  = 0x4,
    GDMA_Msize_64  = 0x5,
    GDMA_Msize_128 = 0x6,
    GDMA_Msize_256 = 0x7,
} GDMA_MSIZE_T;
/** \} */ /** End of Group GDMA_Msize */

#define IS_GDMA_MSIZE(SIZE) (((SIZE) == GDMA_Msize_1) || \
                             ((SIZE) == GDMA_Msize_4) || \
                             ((SIZE) == GDMA_Msize_8) || \
                             ((SIZE) == GDMA_Msize_16) || \
                             ((SIZE) == GDMA_Msize_32) || \
                             ((SIZE) == GDMA_Msize_64) || \
                             ((SIZE) == GDMA_Msize_128) || \
                             ((SIZE) == GDMA_Msize_256))

/**
 * \defgroup    DMA_Interrupts_Definition DMA Interrupts Definition
 * \{
 * \ingroup     GDMA_Exported_Constants
 */
#define GDMA_INT_Transfer               (BIT0)
#define GDMA_INT_Block                  (BIT1)
#define GDMA_INT_SrcTransfer            (BIT2)
#define GDMA_INT_DstTransfer            (BIT3)
#define GDMA_INT_Error                  (BIT4)
/** \} */ /** End of Group DMA_Interrupts_Definition */

#define IS_GDMA_CONFIG_IT(IT) ((((IT) & 0xFFFFFFE0) == 0x00) && ((IT) != 0x00))

/**
 * \defgroup    GDMA_Multiblock_Mode GDMA Multi-block Mode
 * \{
 * \ingroup     GDMA_Exported_Constants
 */
#define AUTO_RELOAD_WITH_CONTIGUOUS_SAR (BIT30)
#define AUTO_RELOAD_WITH_CONTIGUOUS_DAR (BIT31)
#define AUTO_RELOAD_TRANSFER            (BIT30 | BIT31)
#define LLI_WITH_CONTIGUOUS_SAR         (BIT27)
#define LLI_WITH_AUTO_RELOAD_SAR        (BIT27 | BIT30)
#define LLI_WITH_CONTIGUOUS_DAR         (BIT28)
#define LLI_WITH_AUTO_RELOAD_DAR        (BIT28 | BIT31)
#define LLI_TRANSFER                    (BIT27 | BIT28)
/** \} */ /** End of Group GDMA_Multiblock_Mode */

#define IS_GDMA_MULTIBLOCKMODE(MODE) (((MODE) == AUTO_RELOAD_WITH_CONTIGUOUS_SAR) || \
                                      ((MODE) == AUTO_RELOAD_WITH_CONTIGUOUS_DAR) || \
                                      ((MODE) == AUTO_RELOAD_TRANSFER) || \
                                      ((MODE) == LLI_WITH_CONTIGUOUS_SAR) || \
                                      ((MODE) == LLI_WITH_AUTO_RELOAD_SAR) || \
                                      ((MODE) == LLI_WITH_CONTIGUOUS_DAR) || \
                                      ((MODE) == LLI_WITH_AUTO_RELOAD_DAR) || \
                                      ((MODE) == LLI_TRANSFER))

/**
 * \defgroup    GDMA_Multiblock_Select_Bit Multi-Block Select Bit
 * \{
 * \ingroup     GDMA_Exported_Constants
 */
#define AUTO_RELOAD_SELECTED_BIT        (BIT30 | BIT31)
#define LLP_SELECTED_BIT                (BIT27 | BIT28)

/**
 * \defgroup    DMA_Suspend_Flag_Definition DMA Suspend Flag Definition
 * \{
 * \ingroup     GDMA_Exported_Constants
 */
#define GDMA_FIFO_STATUS                (BIT(9))
#define GDMA_SUSPEND_TRANSMISSSION      (BIT(8))
#define GDMA_SUSPEND_CMD_STATUS         (BIT(2) | BIT(1))
#define GDMA_SUSPEND_CHANNEL_STATUS     (BIT(0))

/**
 * \brief       GDMA init structure definition.
 *
 * \ingroup     GDMA_Exported_Types
 */
typedef struct
{
    uint8_t  GDMA_ChannelNum;               /*!< Specifies channel number for GDMA. */
    GDMA_DIRECTION_T GDMA_DIR;              /*!< Specifies transfer direction. */
    uint32_t GDMA_BufferSize;               /*!< Specifies the buffer size(<=65535).
                                                 The data unit is equal to the configuration set in DMA_PeripheralDataSize
                                                 or DMA_MemoryDataSize members depending in the transfer direction. */
    GDMA_SRC_INC_T GDMA_SourceInc;          /*!< Specifies whether the source address
                                                 register is incremented or not. */
    GDMA_DEST_INC_T GDMA_DestinationInc;    /*!< Specifies whether the destination address
                                                 register is incremented or not.*/
    GDMA_DATASIZE_T GDMA_SourceDataSize;    /*!< Specifies the source data width. */
    GDMA_DATASIZE_T GDMA_DestinationDataSize; /*!< Specifies the destination data width. */
    GDMA_MSIZE_T GDMA_SourceMsize;          /*!< Specifies items number to be transferred. */
    GDMA_MSIZE_T GDMA_DestinationMsize;     /*!< Specifies items number to be transferred. */
    uint32_t GDMA_SourceAddr;               /*!< Specifies the source base address for GDMA Channelx. */
    uint32_t GDMA_DestinationAddr;          /*!< Specifies the destination base address for GDMA Channelx. */
    uint32_t GDMA_ChannelPriority;          /*!< Specifies the software priority for the GDMA Channelx.
                                                 This parameter can be a value of 0~7 for GDMA1 and 0~15 for GDMA2. */
    uint32_t GDMA_Multi_Block_Mode;         /*!< Specifies the multi block transfer mode.
                                                 This parameter can be a value of \ref GDMA_Multiblock_Mode. */
    uint32_t GDMA_Multi_Block_Struct;       /*!< Pointer to the first struct of LLI. */
    uint8_t  GDMA_Multi_Block_En;           /*!< Enable or disable multi-block function. */
    uint8_t  GDMA_SourceHandshake;          /*!< Specifies the handshake index in source.
                                                 This parameter can be a value of \ref GDMA_Handshake_Type. */
    uint8_t  GDMA_DestHandshake;            /*!< Specifies the handshake index in Destination.
                                                 This parameter can be a value of \ref GDMA_Handshake_Type. */
    uint8_t  GDMA_Gather_En;                /*!< Enable or disable Gather function. NOTE:4 bytes ALIGN.*/
    uint32_t GDMA_GatherCount;              /*!< Specifies the GatherCount.NOTE:4 bytes ALIGN.*/
    uint32_t GDMA_GatherInterval;           /*!< Specifies the GatherInterval. */
    uint8_t  GDMA_Scatter_En;               /*!< Enable or disable Scatter function. */
    uint32_t GDMA_ScatterCount;             /*!< Specifies the ScatterCount. */
    uint32_t GDMA_ScatterInterval;          /*!< Specifies the ScatterInterval. */
    uint32_t GDMA_GatherCircularStreamingNum;  /*!< Specifies the GatherCircularStreamingNum. */
    uint32_t GDMA_ScatterCircularStreamingNum; /*!< Specifies the ScatterCircularStreamingNum. */
    uint8_t  GDMA_Secure_En;                /*!< Enable or disable Secure function. */
} GDMA_InitTypeDef;

/**
 * \brief       GDMA link list item structure definition.
 *
 * \ingroup     GDMA_Exported_Types
 */
typedef struct
{
    __IO uint32_t SAR;
    __IO uint32_t DAR;
    __IO uint32_t LLP;
    __IO uint32_t CTL_LOW;
    __IO uint32_t CTL_HIGH;
} GDMA_LLIDef;

/*============================================================================*
 *                         Functions
 *============================================================================*/
/**
 * \defgroup    GDMA_Exported_Functions Peripheral APIs
 * \{
 * \ingroup     GDMA
 */

/**
 * \brief  Deinitializes the GDMA registers to their default reset
 *         values.
 * \param  None.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_gdma_init(void)
 * {
 *     GDMA_DeInit(GDMA1);
 * }
 * \endcode
 */
void GDMA_DeInit(GDMA_TypeDef *GDMAx);

/**
 * \brief     Initializes the GDMA Channelx according to the specified
 *            parameters in the GDMA_InitStruct.
 * \param[in] GDMA_Channelx: Where x can be 3 to 26 to select the DMA Channel.
 * \param[in] GDMA_InitStruct: Pointer to a GDMA_InitTypeDef structure that
 *            contains the configuration information for the specified DMA Channel.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_gdma_init(void)
 * {
 *     for (uint32_t i = 0; i < UART_TX_GDMA_BUFFER_SIZE; i++)
 *     {
 *         GDMA_SendData_Buffer[i] = 0x10 + i;
 *     }
 *
 *     GDMA_InitTypeDef GDMA_InitStruct;
 *     GDMA_StructInit(&GDMA_InitStruct);
 *     GDMA_InitStruct.GDMA_ChannelNum      = 1;
 *     GDMA_InitStruct.GDMA_DIR             = GDMA_DIR_MemoryToPeripheral;
 *     GDMA_InitStruct.GDMA_BufferSize      = UART_TX_GDMA_BUFFER_SIZE;//determine total transfer size
 *     GDMA_InitStruct.GDMA_SourceInc       = DMA_SourceInc_Inc;
 *     GDMA_InitStruct.GDMA_DestinationInc  = DMA_DestinationInc_Fix;
 *     GDMA_InitStruct.GDMA_SourceDataSize  = GDMA_DataSize_Byte;
 *     GDMA_InitStruct.GDMA_DestinationDataSize = GDMA_DataSize_Byte;
 *     GDMA_InitStruct.GDMA_SourceMsize      = GDMA_Msize_1;
 *     GDMA_InitStruct.GDMA_DestinationMsize = GDMA_Msize_1;
 *     GDMA_InitStruct.GDMA_SourceAddr      = (uint32_t)GDMA_SendData_Buffer;
 *     GDMA_InitStruct.GDMA_DestinationAddr = (uint32_t)(&(UART0->UART_RBR_THR));
 *     GDMA_InitStruct.GDMA_DestHandshake   = GDMA0_Handshake_UART0_TX;
 *     GDMA_InitStruct.GDMA_ChannelPriority = 2;//channel prority between 0 to 5
 *     GDMA_Init(UART_TX_GDMA_CHANNEL, &GDMA_InitStruct);
 *
 *     GDMA_INTConfig(UART_TX_GDMA_CHANNEL_NUM, GDMA_INT_Transfer, ENABLE);
 *
 *     NVIC_InitTypeDef NVIC_InitStruct;
 *     NVIC_InitStruct.NVIC_IRQChannel = UART_TX_GDMA_CHANNEL_IRQN;
 *     NVIC_InitStruct.NVIC_IRQChannelPriority = 3;
 *     NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
 *     NVIC_Init(&NVIC_InitStruct);
 *
 *     GDMA_Cmd(UART_TX_GDMA_CHANNEL_NUM, ENABLE);
 * }
 * \endcode
 */
void GDMA_Init(GDMA_ChannelTypeDef *GDMA_Channelx, GDMA_InitTypeDef *GDMA_InitStruct);

/**
 * \brief     Fills each GDMA_InitStruct member with its default value.
 * \param[in] GDMA_InitStruct : pointer to a GDMA_InitTypeDef structure which will
 *            be initialized.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_gdma_init(void)
 * {
 *
 *     for (uint32_t i = 0; i < UART_TX_GDMA_BUFFER_SIZE; i++)
 *     {
 *         GDMA_SendData_Buffer[i] = 0x10 + i;
 *     }
 *
 *     GDMA_InitTypeDef GDMA_InitStruct;
 *     GDMA_StructInit(&GDMA_InitStruct);
 *     GDMA_InitStruct.GDMA_ChannelNum      = 1;
 *     GDMA_InitStruct.GDMA_DIR             = GDMA_DIR_MemoryToPeripheral;
 *     GDMA_InitStruct.GDMA_BufferSize      = UART_TX_GDMA_BUFFER_SIZE;//determine total transfer size
 *     GDMA_InitStruct.GDMA_SourceInc       = DMA_SourceInc_Inc;
 *     GDMA_InitStruct.GDMA_DestinationInc  = DMA_DestinationInc_Fix;
 *     GDMA_InitStruct.GDMA_SourceDataSize  = GDMA_DataSize_Byte;
 *     GDMA_InitStruct.GDMA_DestinationDataSize = GDMA_DataSize_Byte;
 *     GDMA_InitStruct.GDMA_SourceMsize      = GDMA_Msize_1;
 *     GDMA_InitStruct.GDMA_DestinationMsize = GDMA_Msize_1;
 *     GDMA_InitStruct.GDMA_SourceAddr      = (uint32_t)GDMA_SendData_Buffer;
 *     GDMA_InitStruct.GDMA_DestinationAddr = (uint32_t)(&(UART0->UART_RBR_THR));
 *     GDMA_InitStruct.GDMA_DestHandshake   = GDMA0_Handshake_UART0_TX;
 *     GDMA_InitStruct.GDMA_ChannelPriority = 2;//channel prority between 0 to 5
 *     GDMA_Init(UART_TX_GDMA_CHANNEL, &GDMA_InitStruct);
 *
 * }
 * \endcode
 */
void GDMA_StructInit(GDMA_InitTypeDef *GDMA_InitStruct);

/**
 * \brief  Enables or disables the selected GDMA channel.
 * \param[in]  GDMA_Channel_Num: can be 3 to 26 to select the DMA Channel.
 * \param[in]  NewState: New state of the selected DMA channel.
 *      This parameter can be: ENABLE or DISABLE.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_gdma_init(void)
 * {
 *
 *     for (uint32_t i = 0; i < UART_TX_GDMA_BUFFER_SIZE; i++)
 *     {
 *         GDMA_SendData_Buffer[i] = 0x10 + i;
 *     }

 *     GDMA_InitTypeDef GDMA_InitStruct;
 *     GDMA_StructInit(&GDMA_InitStruct);
 *     GDMA_InitStruct.GDMA_ChannelNum      = 1;
 *     GDMA_InitStruct.GDMA_DIR             = GDMA_DIR_MemoryToPeripheral;
 *     GDMA_InitStruct.GDMA_BufferSize      = UART_TX_GDMA_BUFFER_SIZE;//determine total transfer size
 *     GDMA_InitStruct.GDMA_SourceInc       = DMA_SourceInc_Inc;
 *     GDMA_InitStruct.GDMA_DestinationInc  = DMA_DestinationInc_Fix;
 *     GDMA_InitStruct.GDMA_SourceDataSize  = GDMA_DataSize_Byte;
 *     GDMA_InitStruct.GDMA_DestinationDataSize = GDMA_DataSize_Byte;
 *     GDMA_InitStruct.GDMA_SourceMsize      = GDMA_Msize_1;
 *     GDMA_InitStruct.GDMA_DestinationMsize = GDMA_Msize_1;
 *     GDMA_InitStruct.GDMA_SourceAddr      = (uint32_t)GDMA_SendData_Buffer;
 *     GDMA_InitStruct.GDMA_DestinationAddr = (uint32_t)(&(UART0->UART_RBR_THR));
 *     GDMA_InitStruct.GDMA_DestHandshake   = GDMA0_Handshake_UART0_TX;
 *     GDMA_InitStruct.GDMA_ChannelPriority = 2;
 *     GDMA_Init(UART_TX_GDMA_CHANNEL, &GDMA_InitStruct);

 *     GDMA_INTConfig(UART_TX_GDMA_CHANNEL_NUM, GDMA_INT_Transfer, ENABLE);

 *     NVIC_InitTypeDef NVIC_InitStruct;
 *     NVIC_InitStruct.NVIC_IRQChannel = UART_TX_GDMA_CHANNEL_IRQN;
 *     NVIC_InitStruct.NVIC_IRQChannelPriority = 3;
 *     NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
 *     NVIC_Init(&NVIC_InitStruct);

 *     GDMA_Cmd(UART_TX_GDMA_CHANNEL_NUM, ENABLE);
 * }
 * \endcode
 */
void GDMA_Cmd(uint8_t GDMA_ChannelNum, FunctionalState NewState);

/**
 * \brief   Enables or disables the specified DMA channelx interrupt source.
 * \param[in] GDMA_Channel_Num: can be 3 to 26 to select the DMA Channel.
 * \param[in]  GDMA_IT: Specifies the GDMA interrupt source to be enabled or disabled.
 *      This parameter can be any combination of the following values:
 *      \arg GDMA_INT_Transfer: Transfer complete interrupt source.
 *      \arg GDMA_INT_Block: Block transfer interrupt source.
 *      \arg GDMA_INT_SrcTransfer: SourceTransfer interrupt source.
 *      \arg GDMA_INT_DstTransfer: Destination Transfer interruptsource.
 *      \arg GDMA_INT_Error: Transfer error interrupt source.
 * \param[in] NewState: New state of the specified DMA interrupt source.
 *      This parameter can be: ENABLE or DISABLE.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_gdma_init(void)
 * {
 *
 *     for (uint32_t i = 0; i < UART_TX_GDMA_BUFFER_SIZE; i++)
 *     {
 *         GDMA_SendData_Buffer[i] = 0x10 + i;
 *     }

 *     GDMA_InitTypeDef GDMA_InitStruct;
 *     GDMA_StructInit(&GDMA_InitStruct);
 *     GDMA_InitStruct.GDMA_ChannelNum      = 1;
 *     GDMA_InitStruct.GDMA_DIR             = GDMA_DIR_MemoryToPeripheral;
 *     GDMA_InitStruct.GDMA_BufferSize      = UART_TX_GDMA_BUFFER_SIZE;//determine total transfer size
 *     GDMA_InitStruct.GDMA_SourceInc       = DMA_SourceInc_Inc;
 *     GDMA_InitStruct.GDMA_DestinationInc  = DMA_DestinationInc_Fix;
 *     GDMA_InitStruct.GDMA_SourceDataSize  = GDMA_DataSize_Byte;
 *     GDMA_InitStruct.GDMA_DestinationDataSize = GDMA_DataSize_Byte;
 *     GDMA_InitStruct.GDMA_SourceMsize      = GDMA_Msize_1;
 *     GDMA_InitStruct.GDMA_DestinationMsize = GDMA_Msize_1;
 *     GDMA_InitStruct.GDMA_SourceAddr      = (uint32_t)GDMA_SendData_Buffer;
 *     GDMA_InitStruct.GDMA_DestinationAddr = (uint32_t)(&(UART0->UART_RBR_THR));
 *     GDMA_InitStruct.GDMA_DestHandshake   = GDMA0_Handshake_UART0_TX;
 *     GDMA_InitStruct.GDMA_ChannelPriority = 2;
 *     GDMA_Init(UART_TX_GDMA_CHANNEL, &GDMA_InitStruct);

 *     GDMA_INTConfig(UART_TX_GDMA_CHANNEL_NUM, GDMA_INT_Transfer, ENABLE);

 *     NVIC_InitTypeDef NVIC_InitStruct;
 *     NVIC_InitStruct.NVIC_IRQChannel = UART_TX_GDMA_CHANNEL_IRQN;
 *     NVIC_InitStruct.NVIC_IRQChannelPriority = 3;
 *     NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
 *     NVIC_Init(&NVIC_InitStruct);

 *     GDMA_Cmd(UART_TX_GDMA_CHANNEL_NUM, ENABLE);
 * }
 * \endcode
 */
void GDMA_INTConfig(uint8_t GDMA_ChannelNum, uint32_t GDMA_IT, FunctionalState NewState);

/**
 * \brief  Check whether GDMA Channel transfer interrupt is set.
 * \param[in] GDMA_Channel_Num: can be 3 to 26 to select the DMA Channel.
 * \return  Transfer interrupt status, SET or RESET.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     ITStatus int_status = GDMA_GetTransferINTStatus(0);
 * }
 * \endcode
 */
ITStatus GDMA_GetTransferINTStatus(uint8_t GDMA_ChannelNum);

/**
 * \brief  Clear the specified DMA channelx interrupt pending bit.
 * \param[in] GDMA_Channel_Num: can be 3 to 26 to select the DMA Channel.
 * \param[in] GDMA_IT: Specifies the GDMA interrupts sources to be enabled or disabled.
 *      This parameter can be any combination of the following values:
 *      \arg GDMA_INT_Transfer: Transfer complete interrupt source.
 *      \arg GDMA_INT_Block: Block transfer interrupt source.
 *      \arg GDMA_INT_SrcTransfer: SourceTransfer interrupt source.
 *      \arg GDMA_INT_DstTransfer: Destination Transfer interruptsource.
 *      \arg GDMA_INT_Error: Transfer error interrupt source.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     driver_gdma_init();
 * }
 *
 * void UART_TX_GDMA_Handler(void)
 * {
 *     GDMA_ClearINTPendingBit(1, GDMA_INT_Transfer);
 *     //Add user code here.
 * }
 * \endcode
 */
void GDMA_ClearINTPendingBit(uint8_t GDMA_ChannelNum, uint32_t GDMA_IT);

/**
 * \brief     Clear GDMAx Channelx all type interrupt.
 * \param[in] GDMA_ChannelNum: can be 3 to 26 to select the DMA Channel.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     GDMA_ClearAllTypeINT(GDMA2, 0);
 * }
 * \endcode
 */
void GDMA_ClearAllTypeINT(uint8_t GDMA_ChannelNum);

/**
 * \brief   Get selected GDMA channel status.
 * \param[in] GDMA_Channel_Num: can be 3 to 26 to select the DMA Channel.
 * \return  GDMA channel status.
 * \retval  SET: Channel is be used
 * \retval  RESET: Channel is free.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     FlagStatus flag_status = GDMA_GetChannelStatus(3);
 * }
 * \endcode
 */
FlagStatus GDMA_GetChannelStatus(uint8_t GDMA_ChannelNum);

/**
 * \brief     Enable or disable the specified DMA channel secure functions.
 * \param[in] GDMA_Channelx: Where x can be 3 to 26 to select the DMA Channel.
 * \param[in] NewState: Specifies the GDMA channel secure function to be enabled or disabled.
 *            This parameter can be ENABLE or DISABLE.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     GDMA_SecureCmd(GDMA_Channel3, ENABLE);
 * }
 *
 * \endcode
 */
void GDMA_SecureCmd(GDMA_ChannelTypeDef *GDMA_Channelx, FunctionalState NewState);


/**
 * \brief     Set GDMA OSW.
 * \param[in] GDMA_ChannelNum: can be 3 to 26 to select the DMA Channel.
 * \param[in] osw_count: outstanding write count.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     GDMA_SetOSW(GDMA_Channel0, 10);
 * }
 * \endcode
 */
void GDMA_SetOSW(uint8_t GDMA_ChannelNum, uint8_t osw_count);

/**
 * \brief  Set GDMA OSR.
 * \param[in] GDMA_ChannelNum: can be 3 to 26 to select the DMA Channel.
 * \param[in] osr_count: outstanding read count.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     GDMA_SetOSR(GDMA_Channel0, 10);
 * }
 * \endcode
 */
void GDMA_SetOSR(uint8_t GDMA_ChannelNum, uint8_t osr_count);

/**
 * \brief     Get GDMA OSW.
 * \param[in] GDMA_ChannelNum: can be 3 to 26 to select the DMA Channel.
 * \return    osw_count: outstanding write count.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     uint32_t osw_count = GDMA_GetOSWCount(GDMA_Channel0);
 * }
 * \endcode
 */
uint8_t GDMA_GetOSWCount(uint8_t GDMA_ChannelNum);

/**
 * \brief     Get GDMA OSR.
 * \param[in] GDMA_ChannelNum: can be 3 to 26 to select the DMA Channel.
 * \return    osr_count: outstanding read count.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     uint8_t osr_count = GDMA_GetOSRCount(GDMA_Channel0);
 * }
 * \endcode
 */
uint8_t GDMA_GetOSRCount(uint8_t GDMA_ChannelNum);

/**
 * \brief      Set GDMA transmission source address.
 * \param[in]  GDMA_Channelx: Where x can be 3 to 26 to select the DMA Channel.
 * \param[in]  Address: Source address.
 * \return     None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     uint32_t data_buf[10] = {0};
 *     GDMA_SetSourceAddress(GDMA2_Channel0,(uint32_t)data_buf);
 * }
 * \endcode
 */
__STATIC_INLINE void GDMA_SetSourceAddress(GDMA_ChannelTypeDef *GDMA_Channelx, uint32_t Address)
{
    /* Check the parameters */
    assert_param(IS_GDMA_ALL_PERIPH(GDMA_Channelx));

    GDMA_Channelx->GDMA_SARx = Address;
}

/**
 * \brief     Set GDMA transmission destination address.
 * \param[in] GDMA_Channelx: Where x can be 3 to 26 to select the DMA Channel.
 * \param[in] Address: Destination address.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     uint32_t data_buf[10] = {0};
 *     GDMA_SetDestinationAddress(GDMA_Channel0,(uint32_t)data_buf);
 * }
 * \endcode
 */
__STATIC_INLINE void GDMA_SetDestinationAddress(GDMA_ChannelTypeDef *GDMA_Channelx,
                                                uint32_t Address)
{
    /* Check the parameters */
    assert_param(IS_GDMA_ALL_PERIPH(GDMA_Channelx));

    GDMA_Channelx->GDMA_DARx = Address;
}

/**
 * \brief     Set GDMA LLP stucture address.
 * \param[in] GDMA_Channelx: Where x can be 3 to 26 to select the DMA Channel.
 * \param[in] Address: LLP stucture address.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     GDMA_LLIDef GDMA_LLIStruct[4000];
 *     GDMA_SetLLPAddress(GDMA2_Channel0,(uint32_t)GDMA_LLIStruct);
 * }
 * \endcode
 */
__STATIC_INLINE void GDMA_SetLLPAddress(GDMA_ChannelTypeDef *GDMA_Channelx, uint32_t Address)
{
    /* Check the parameters */
    assert_param(IS_GDMA_ALL_PERIPH(GDMA_Channelx));

    GDMA_Channelx->GDMA_LLPx = Address & 0xFFFFFFFC;
}

/**
 * \brief     Set GDMA buffer size.
 * \param[in] GDMA_Channelx: Where x can be 3 to 26 to select the DMA Channel.
 * \param[in] buffer_size: Set GDMA_BufferSize, max 65535.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     uint32_t data_buf_size = 4095;
 *     GDMA_SetBufferSize(GDMA_Channel0,data_buf_size);
 * }
 * \endcode
 */
__STATIC_INLINE void GDMA_SetBufferSize(GDMA_ChannelTypeDef *GDMA_Channelx, uint32_t buffer_size)
{
    /* Check the parameters */
    assert_param(IS_GDMA_ALL_PERIPH(GDMA_Channelx));

    /* Configure high 32 bit of CTL register */
    GDMA_Channelx->GDMA_CTL_HIGHx = buffer_size;
}

/**
 * \brief  Get GDMA source address.
 * \param[in] GDMA_Channelx: Where x can be 3 to 26 to select the DMA Channel.
 * \return Source address.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     uint32_t address = GDMA_GetSrcTransferAddress(GDMA2_Channel0);
 * }
 * \endcode
 */
__STATIC_INLINE uint32_t GDMA_GetSrcTransferAddress(GDMA_ChannelTypeDef *GDMA_Channelx)
{
    /* Check the parameters */
    assert_param(IS_GDMA_ALL_PERIPH(GDMA_Channelx));

    uint32_t address = 0;
    address = GDMA_Channelx->GDMA_SARx;
    return address;
}

/**
 * \brief  Get GDMA destination address.
 * \param[in] GDMA_Channelx: Where x can be 3 to 26 to select the DMA Channel.
 * \return Destination address.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     uint32_t address = GDMA_GetDstTransferAddress(GDMA2_Channel0);
 * }
 * \endcode
 */
__STATIC_INLINE uint32_t GDMA_GetDstTransferAddress(GDMA_ChannelTypeDef *GDMA_Channelx)
{
    /* Check the parameters */
    assert_param(IS_GDMA_ALL_PERIPH(GDMA_Channelx));

    uint32_t address = 0;
    address = GDMA_Channelx->GDMA_DARx;
    return address;
}

/**
 * \brief     Get GDMA transfer data length.
 * \param[in] GDMA_Channelx: Where x can be 3 to 26 to select the DMA Channel.
 * \return    GDMA transfer data length.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     uint16_t data_len = GDMA_GetTransferLen(GDMA2_Channel0);
 * }
 * \endcode
 */
__STATIC_INLINE uint16_t GDMA_GetTransferLen(GDMA_ChannelTypeDef *GDMA_Channelx)
{
    /* Check the parameters */
    assert_param(IS_GDMA_ALL_PERIPH(GDMA_Channelx));

    return (uint16_t)(GDMA_Channelx->GDMA_CTL_HIGHx & 0xffffffff);
}

/**
 * \brief     Check GDMA FIFO status.
 * \param[in] GDMA_Channelx: Where x can be 3 to 26 to select the DMA Channel.
 * \return GDMA FIFO status.
 * \retval SET: FIFO empty.
 * \retval RESET: FIFO not empty.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     FlagStatus flag_status = GDMA_GetFIFOStatus(GDMA2_Channel0);
 * }
 * \endcode
 */
__STATIC_INLINE FlagStatus GDMA_GetFIFOStatus(GDMA_ChannelTypeDef *GDMA_Channelx)
{
    FlagStatus bit_status = RESET;

    /* Check the parameters */
    assert_param(IS_GDMA_ALL_PERIPH(GDMA_Channelx));

    if ((GDMA_Channelx->GDMA_CFG_LOWx & GDMA_FIFO_STATUS) != (uint32_t)RESET)
    {
        bit_status = SET;
    }

    /* Return the selected channel status */
    return  bit_status;
}

/**
 * \brief      Suspend GDMA transmission from the source.
 * \param[in]  GDMA_Channelx: Where x can be 3 to 26 to select the DMA Channel.
 * \param[in]  NewState: New state of the GDMAx Channelx.
 *             This parameter can be: ENABLE or DISABLE.
 * \return     None.
 * \note       To prevent data loss, it is necessary to check whether FIFO data transmission is completed
 *             after suspend, and judge by checking whether GDMA FIFO is empty.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     GDMA_SuspendCmd(GDMA2_Channel0, ENABLE);
 * }
 * \endcode
 */
__STATIC_INLINE void GDMA_SuspendCmd(GDMA_ChannelTypeDef *GDMA_Channelx,
                                     FunctionalState NewState)
{
    /* Check the parameters */
    assert_param(IS_GDMA_ALL_PERIPH(GDMA_Channelx));
    assert_param(IS_FUNCTIONAL_STATE(NewState));

    if (NewState == DISABLE)
    {
        /* Not suspend transmission*/
        GDMA_Channelx->GDMA_CFG_LOWx &= ~(GDMA_SUSPEND_TRANSMISSSION);
    }
    else
    {
        /* Suspend transmission */
        GDMA_Channelx->GDMA_CFG_LOWx |= GDMA_SUSPEND_TRANSMISSSION;
    }
}

/**
 * \brief  Check GDMA suspend command status.
 * \param  GDMA_Channelx: Where x can be 3 to 26 to select the DMA Channel.
 * \return GDMA suspend command status.
 * \retval SET: Suspend.
 * \retval RESET: Not suspend.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     FlagStatus flag_status = GDMA_GetSuspendCmdStatus(GDMA2_Channel0);
 * }
 * \endcode
 */
__STATIC_INLINE FlagStatus GDMA_GetSuspendCmdStatus(GDMA_ChannelTypeDef *GDMA_Channelx)
{
    FlagStatus bit_status = RESET;

    /* Check the parameters */
    assert_param(IS_GDMA_ALL_PERIPH(GDMA_Channelx));

    if ((GDMA_Channelx->GDMA_CFG_LOWx & GDMA_SUSPEND_CMD_STATUS) == GDMA_SUSPEND_CMD_STATUS)
    {
        bit_status = SET;
    }

    /* Return the selected channel suspend status */
    return  bit_status;
}

/**
 * \brief  Check GDMA suspend channel status.
 * \param[in] GDMA_Channelx: Where x can be 3 to 26 to select the DMA Channel.
 * \return GDMA suspend channel status.
 * \retval SET: Inactive.
 * \retval RESET: Active.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void gdma_demo(void)
 * {
 *     FlagStatus flag_status = GDMA_GetSuspendChannelStatus(GDMA2_Channel0);
 * }
 * \endcode
 */
__STATIC_INLINE FlagStatus GDMA_GetSuspendChannelStatus(GDMA_ChannelTypeDef *GDMA_Channelx)
{
    FlagStatus bit_status = RESET;

    /* Check the parameters */
    assert_param(IS_GDMA_ALL_PERIPH(GDMA_Channelx));

    if ((GDMA_Channelx->GDMA_CFG_LOWx & GDMA_SUSPEND_CHANNEL_STATUS) == GDMA_SUSPEND_CHANNEL_STATUS)
    {
        bit_status = SET;
    }

    /* Return the selected channel suspend status */
    return  bit_status;
}
/** \} */ /* End of group GDMA_Exported_Functions */

#ifdef __cplusplus
}
#endif

#endif /* RTL_GDMA_H */


/******************* (C) COPYRIGHT 2020 Realtek Semiconductor Corporation *****END OF FILE****/

