/**
*********************************************************************************************************
*               Copyright(c) 2022, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* \file     rtl_adc.h
* \brief    The header file of the peripheral ADC driver.
* \details  This file provides all ADC firmware functions.
* \author   echo
* \date     2022-09-02
* \version  v2.1.0
* *********************************************************************************************************
*/
#ifndef RTL_ADC_H
#define RTL_ADC_H
#ifdef __cplusplus
extern "C" {
#endif
/**
 * \addtogroup  IO          Peripheral Drivers
 * \defgroup    ADC         ADC
 *
 * \brief       Manage the ADC peripheral functions.
 *
 * \ingroup     IO
 */
/*============================================================================*
 *                         Includes
 *============================================================================*/
#include "rtl876x.h"
#include "rtl_adc_reg.h"
#include "rtl876x_aon_reg.h"
#include "rtl_rcc.h"
#include "utils.h"

/* Defines --------------------------------------------------------------*/
#define ADC_Channel_Index_0         0
#define ADC_Channel_Index_1         1
#define ADC_Channel_Index_2         2
#define ADC_Channel_Index_3         3
#define ADC_Channel_Index_4         4
#define ADC_Channel_Index_5         5
#define ADC_Channel_Index_6         6
#define ADC_Channel_Index_7         7
#define ADC_Channel_Index_8         8
#define ADC_Channel_Index_9         9
#define ADC_Channel_Index_10        10
#define ADC_Channel_Index_11        11
#define ADC_Channel_Index_12        12
#define ADC_Channel_Index_13        13
#define ADC_Channel_Index_14        14
#define ADC_Channel_Index_15        15

#define ADC_Schedule_Index_0        0
#define ADC_Schedule_Index_1        1
#define ADC_Schedule_Index_2        2
#define ADC_Schedule_Index_3        3
#define ADC_Schedule_Index_4        4
#define ADC_Schedule_Index_5        5
#define ADC_Schedule_Index_6        6
#define ADC_Schedule_Index_7        7
#define ADC_Schedule_Index_8        8
#define ADC_Schedule_Index_9        9
#define ADC_Schedule_Index_10       10
#define ADC_Schedule_Index_11       11
#define ADC_Schedule_Index_12       12
#define ADC_Schedule_Index_13       13
#define ADC_Schedule_Index_14       14
#define ADC_Schedule_Index_15       15
#define ADC_Schedule_Index_16       16
#define ADC_Schedule_Index_17       17
#define ADC_Schedule_Index_18       18
#define ADC_Schedule_Index_19       19

#define IS_ADC_SCH_INDEX(IDEX) ((IDEX) <= 19)
/*============================================================================*
 *                         Types
 *============================================================================*/
/**
 * \defgroup    ADC_Exported_Types  Init Params Struct
 *
 * \ingroup     ADC
 */
/*============================================================================*
 *                         Constants
 *============================================================================*/

/**
 * \defgroup    ADC_Schedule_Table ADC Channel and Mode
 * \{
 * \ingroup     ADC_Exported_Constants
 */
#define EXT_SINGLE_ENDED(index)                     ((uint16_t)((0x00 << 4) | (index)))
#define EXT_DIFFERENTIAL(index)                     ((uint16_t)((0x01 << 4) | (index)))
#define INTERNAL_VBAT_MODE                          ((uint16_t)((0x02 << 4) | 0x00))
/** \} */

/** \} */
/**
 * \defgroup    ADC_Convert_Time ADC_CONVERT_TIME
 * \{
 * \ingroup     ADC_Exported_Constants
 */
typedef enum
{
    ADC_CONVERT_TIME_500NS,
    ADC_CONVERT_TIME_700NS,
    ADC_CONVERT_TIME_900NS,
    ADC_CONVERT_TIME_1100NS,
} ADC_CONVERT_TIM_TypeDef;

#define IS_ADC_CONVERT_TIM_TYPE(TYPE) ((TYPE) <= 0x7)

/**
 * \defgroup    ADC_Latch_Data_Edge ADC Latch Data Edge
 * \{
 * \ingroup     ADC_Exported_Constants
 */
typedef enum
{
    ADC_LATCH_DATA_Positive,
    ADC_LATCH_DATA_Negative,
} ADC_DATA_LATCH_EDGE_TypeDef;
/** \} */

#define IS_ADC_LATCH_DATA_EDGE(EDGE) (((EDGE) == ADC_LATCH_DATA_Positive) || ((EDGE) == ADC_LATCH_DATA_Negative))

/**
 * \defgroup    ADC_Data_Align ADC Data Align
 * \{
 * \ingroup     ADC_Exported_Constants
 */
typedef enum
{
    ADC_DATA_ALIGN_LSB,
    ADC_DATA_ALIGN_MSB,
} ADC_ALIGN_TypeDef;

/** \} */

#define IS_ADC_DATA_ALIGN(DATA_ALIGN) (((DATA_ALIGN) == ADC_DATA_ALIGN_LSB) || ((DATA_ALIGN) == ADC_DATA_ALIGN_MSB))


/**
 * \defgroup    ADC_Data_Avg_Num ADC Data Averge Num
 * \{
 * \brief       Number of raw data for calculate average.
 * \ingroup     ADC_Exported_Constants
 */

typedef enum
{
    ADC_DATA_AVERAGE_OF_2,
    ADC_DATA_AVERAGE_OF_4,
    ADC_DATA_AVERAGE_OF_8,
    ADC_DATA_AVERAGE_OF_16,
    ADC_DATA_AVERAGE_OF_32,
    ADC_DATA_AVERAGE_OF_64,
    ADC_DATA_AVERAGE_OF_128,
    ADC_DATA_AVERAGE_OF_256,
} ADC_DATA_AVG_SEL_TypeDef;
/** \} */

#define IS_ADC_DATA_AVG_NUM(NUM) (((NUM) == ADC_DATA_AVERAGE_OF_2) ||\
                                  ((NUM) == ADC_DATA_AVERAGE_OF_4) ||\
                                  ((NUM) == ADC_DATA_AVERAGE_OF_8) ||\
                                  ((NUM) == ADC_DATA_AVERAGE_OF_16) ||\
                                  ((NUM) == ADC_DATA_AVERAGE_OF_32) ||\
                                  ((NUM) == ADC_DATA_AVERAGE_OF_64) ||\
                                  ((NUM) == ADC_DATA_AVERAGE_OF_128) ||\
                                  ((NUM) == ADC_DATA_AVERAGE_OF_256))

/**
 * \defgroup    ADC_Power_On_Mode ADC Power On Mode
 * \{
 * \ingroup     ADC_Exported_Constants
 */

typedef enum
{
    ADC_POWER_ON_AUTO,
    ADC_POWER_ON_MANUAL,
} ADC_POW_ON_MODE_TypeDef;
/** \} */

#define IS_ADC_POWER_ON_MODE(MODE) (((MODE) == ADC_POWER_ON_AUTO) || ((MODE) == ADC_POWER_ON_MANUAL))

/**
 * \defgroup    ADC_RG2X_0_Delay_Time ADC RG2X_0 Delay Time
 * \{
 * \ingroup     ADC_Exported_Constants
 */
typedef enum
{
    ADC_RG2X_0_DELAY_10_US,
    ADC_RG2X_0_DELAY_20_US,
    ADC_RG2X_0_DELAY_40_US,
    ADC_RG2X_0_DELAY_80_US,
} ADC_RG2X0_DELAY_TypeDef;

/** \} */

#define IS_ADC_RG2X_0_DELAY_TIME(TIME) (((TIME) == ADC_RG2X_0_DELAY_10_US) || ((TIME) == ADC_RG2X_0_DELAY_20_US)\
                                        || ((TIME) == ADC_RG2X_0_DELAY_40_US) || ((TIME) == ADC_RG2X_0_DELAY_80_US))

/**
 * \defgroup    ADC_RG0X_1_Delay_Time ADC RG0X_1 Delay Time
 * \{
 * \ingroup     ADC_Exported_Constants
 */
typedef enum
{
    ADC_RG0X_1_DELAY_20_US,
    ADC_RG0X_1_DELAY_40_US,
    ADC_RG0X_1_DELAY_80_US,
    ADC_RG0X_1_DELAY_160_US,
} ADC_RG0X1_DELAY_TypeDef;
/** \} */

#define IS_ADC_RG0X_1_DELAY_TIME(TIME) (((TIME) == ADC_RG0X_1_DELAY_20_US) || ((TIME) == ADC_RG0X_1_DELAY_40_US)\
                                        || ((TIME) == ADC_RG0X_1_DELAY_80_US) || ((TIME) == ADC_RG0X_1_DELAY_160_US))

/**
 * \defgroup    ADC_RG0X_0_Delay_Time ADC RG0X_0 Delay Time
 * \{
 * \ingroup     ADC_Exported_Constants
 */
typedef enum
{
    ADC_RG0X_0_DELAY_30_US,
    ADC_RG0X_0_DELAY_60_US,
    ADC_RG0X_0_DELAY_120_US,
    ADC_RG0X_0_DELAY_240_US,
} ADC_RG0X0_DELAY_TypeDef;

/** \} */

#define IS_ADC_RG0X_0_DELAY_TIME(TIME) (((TIME) == ADC_RG0X_0_DELAY_30_US) || ((TIME) == ADC_RG0X_0_DELAY_60_US)\
                                        || ((TIME) == ADC_RG0X_0_DELAY_120_US) || ((TIME) == ADC_RG0X_0_DELAY_240_US))

/**
 * \def     ADC_FIFO_Threshold  ADC FIFO Threshold
 */
#define IS_ADC_FIFO_THRESHOLD(THD) ((THD) <= 0x3F)

/**
 * \def     ADC_Burst_Size  ADC Burst Size
 */
#define IS_ADC_WATER_LEVEL_CONFIG(CONFIG) ((CONFIG) <= 0x3F)

/**
 * \defgroup    ADC_Operation_Mode ADC Operation Mode
 * \{
 * \ingroup     ADC_Exported_Constants
 */

typedef enum
{
    ADC_CONTINUOUS_MODE,
    ADC_ONE_SHOT_MODE,
} ADC_Operation_Mode_TypeDef;
/** \} */

#define IS_ADC_SAMPLE_MODE(MODE) (((MODE) == ADC_CONTINUOUS_MODE) || ((MODE) == ADC_ONE_SHOT_MODE))

/**
 * \defgroup    ADC_Interrupts_Definition ADC Interrupts Definition
 * \{
 * \ingroup     ADC_Exported_Constants
 */

#define ADC_INT_FIFO_RD_REQ                         ((uint32_t)(1 << 0))
#define ADC_INT_FIFO_RD_ERR                         ((uint32_t)(1 << 1))
#define ADC_INT_FIFO_THD                            ((uint32_t)(1 << 2))
#define ADC_INT_FIFO_OVERFLOW                       ((uint32_t)(1 << 3))
#define ADC_INT_ONE_SHOT_DONE                       ((uint32_t)(1 << 4))
/** \} */

#define IS_ADC_INT(INT) (((INT) == ADC_INT_FIFO_RD_REQ) || ((INT) == ADC_INT_FIFO_RD_ERR)\
                         || ((INT) == ADC_INT_FIFO_THD) || ((INT) == ADC_INT_FIFO_OVERFLOW)\
                         || ((INT) == ADC_INT_ONE_SHOT_DONE))

/**
 * \brief       ADC init structure definition.
 *
 * \ingroup     ADC_Exported_Types
 */
/**
 * @brief ADC initialize parameters
 *
 */

typedef struct
{
    uint16_t ADC_SampleTime;                        /*!< Specifies the ADC Sample clock. (n+1) cycles of 10MHz (1~16384)*/
    ADC_CONVERT_TIM_TypeDef ADC_ConvertTime;        /**< Specifies the ADC Sample convert time.*/
    FunctionalState ADC_DataWriteToFifoEn;          /*!< Write ADC one shot mode data into fifo */
    uint8_t ADC_FifoThdLevel;                       /*!< Specifies the ADC fifo threshold to trigger interrupt ADC_INT_FIFO_TH.
                                                         This parameter can be a value of 0 to 31 */
    uint8_t ADC_WaterLevel;                         /*!< Specifies the ADC fifo Burst Size to trigger GDMA.
                                                         This parameter can be a value of 0 to 31 */
    FunctionalState
    ADC_FifoOverWriteEn;            /*!< Specifies if Over Write fifo when fifo overflow.*/
    ADC_DATA_LATCH_EDGE_TypeDef ADC_DataLatchEdge;  /*!< Specifies ADC data latch mode.*/
    uint16_t ADC_SchIndex[20];                      /*!< Specifies ADC mode and channel for schedule table.*/
    uint32_t ADC_Bitmap;                            /*!< Specifies the schedule table channel map.
                                                         This parameter can be a value of 19Bits map */
    FunctionalState ADC_TimerTriggerEn;             /*!< Enable ADC one-shot mode when timB2 toggles */
    ADC_ALIGN_TypeDef ADC_DataAlign;                /*!< ADC Data MSB or LSB aligned */

    FunctionalState
    ADC_DataMinusEn;                /**< Enable or disable function that adc data latched minus
                                                         the given offset before writes to reg/FIFO. */
    uint16_t ADC_DataMinusOffset;                   /**< Offset to be minused from adc data latched.
                                                         This parameter can be a value of 0 to 4095 */
    ADC_DATA_AVG_SEL_TypeDef ADC_DataAvgSel;        /**< Number of data for calculate average. */
    uint8_t ADC_DataAvgEn;                          /**< Enable the calculation for average result of the one-shot data. */
    /* adc power setting */
    ADC_POW_ON_MODE_TypeDef ADC_PowerOnMode;        /*!< Specifies ADC Power mode. */
    uint8_t ADC_DataLatchDly;                       /*!< Specifies delay of ck_ad to latch data.*/
    ADC_RG2X0_DELAY_TypeDef
    ADC_RG2X0Dly;           /*!< Specifies the power on delay time selection of RG2X_AUXADC[0]. */
    ADC_RG0X1_DELAY_TypeDef
    ADC_RG0X1Dly;           /*!< Specifies the power on delay time selection of RG0X_AUXADC[1]. */
    ADC_RG0X0_DELAY_TypeDef
    ADC_RG0X0Dly;           /*!< Specifies the power on delay time selection of RG0X_AUXADC[0]. */

    FunctionalState
    ADC_FifoStopWriteEn;            /*!< Stop fifo from writing data. This bit will be asserted automatically as fifo overflow,
                                                        (not automatically when ADC_FIFO_OVER_WRITE_ENABLE), need to be cleared in order to write
                                                         data again. This will not stop overwrite mode.*/

    FunctionalState ADC_PowerAlwaysOnEn;             /*!< Specifies the power always on. */

} ADC_InitTypeDef;
/*============================================================================*
 *                         Functions
 *============================================================================*/
/**
 * \defgroup    ADC_Exported_Functions Peripheral APIs
 * \{
 * \ingroup     ADC
 */

/**
 * rtl876x_adc.h
 *
 * \brief   Deinitializes the ADC peripheral registers to their
 *          default reset values(turn off ADC clock).
 * \details
 * \param[in] ADCx: Specify ADC peripheral, can only be ADC.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_adc_init(void)
 * {
 *    //Turn off the clock.
 *    ADC_DeInit(ADC);
 * }
 * \endcode
 */
void ADC_DeInit(void);
/**
 * rtl876x_adc.h
 * \brief Initializes the ADC peripheral according to the specified
 *     parameters in the ADC_InitStruct
 * \param[in]  ADCx: selected ADC peripheral.
 * \param[in]  ADC_InitStruct: pointer to a ADC_InitTypeDef structure that
 *     contains the configuration information for the specified ADC peripheral
 * \return      None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_adc_init(void)
 * {
 *    //Turn on the clock.
 *    RCC_PeriphClockCmd(APBPeriph_ADC, APBPeriph_ADC_CLOCK, ENABLE);

 *    ADC_InitTypeDef ADC_InitStruct;
 *    ADC_StructInit(&ADC_InitStruct);
 *    ADC_InitStruct.ADC_SchIndex[0] = EXT_SINGLE_ENDED(0);
 *    ADC_InitStruct.ADC_SchIndex[1] = EXT_SINGLE_ENDED(1);
 *    ADC_InitStruct.ADC_Bitmap = 0x03;
 *    //Add other initialization parameters that need to be configured here.
 *    ADC_Init(ADC, &ADC_InitStruct);
 * }
 * \endcode
 */
void ADC_Init(ADC_TypeDef *ADCx, ADC_InitTypeDef *ADC_InitStruct);
/**
 * rtl876x_adc.h
 * \brief   Fills each ADC_InitStruct member with its default value.
 * \param[in] ADC_InitStruct: Pointer to an ADC_InitTypeDef structure which will be initialized.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_adc_init(void)
 * {
 *    //Turn on the clock.
 *    RCC_PeriphClockCmd(APBPeriph_ADC, APBPeriph_ADC_CLOCK, ENABLE);

 *    ADC_InitTypeDef ADC_InitStruct;
 *    ADC_StructInit(&ADC_InitStruct);
 *    ADC_InitStruct.ADC_SchIndex[0] = EXT_SINGLE_ENDED(0);
 *    ADC_InitStruct.ADC_SchIndex[1] = EXT_SINGLE_ENDED(1);
 *    ADC_InitStruct.ADC_Bitmap = 0x03;
 *    //Add other initialization parameters that need to be configured here.
 *    ADC_Init(ADC, &ADC_InitStruct);
 * }
 * \endcode
 * \callgraph
 *
 */
void ADC_StructInit(ADC_InitTypeDef *ADC_InitStruct);
/**
 * rtl876x_adc.h
 * \brief   Enables or disables the ADC peripheral.
 * \param[in]  ADCx: Specify ADC peripheral.
 * \param[in]  adcMode: ADC operation mode selection.
        This parameter can be one of the following values:
 *     \arg ADC_ONE_SHOT_MODE: One shot mode.
 *     \arg ADC_CONTINUOUS_MODE: Continuous sampling mode.
 * \param[in]  NewState: New state of the ADC peripheral.
 *     This parameter can be: ENABLE or DISABLE.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_adc_init(void)
 * {
 *     Pad_Config(P2_0, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE,
 *                PAD_OUT_LOW);
 *
 *     Pad_Config(P2_1, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE,
 *                PAD_OUT_LOW);
 * }
 *
 * void driver_adc_init(void)
 * {
 *    //open clock
 *    RCC_PeriphClockCmd(APBPeriph_ADC, APBPeriph_ADC_CLOCK, ENABLE);
 *
 *    ADC_InitTypeDef ADC_InitStruct;
 *    ADC_StructInit(&ADC_InitStruct);
 *    ADC_InitStruct.ADC_SchIndex[0] = EXT_SINGLE_ENDED(0);
 *    ADC_InitStruct.ADC_SchIndex[1] = EXT_SINGLE_ENDED(1);
 *    ADC_InitStruct.ADC_Bitmap = 0x03;
 *    //Add other initialization parameters here.
 *    ADC_Init(ADC, &ADC_InitStruct);
 *
 *    ADC_INTConfig(ADC, ADC_INT_ONE_SHOT_DONE, ENABLE);
 * }
 *
 * void adc_demo(void)
 * {
 *    board_adc_init();
 *    driver_adc_init();
 *    ADC_Cmd(ADC, ADC_ONE_SHOT_MODE, ENABLE);
 * }
 * \endcode
 */
void ADC_Cmd(ADC_TypeDef *ADCx, ADC_Operation_Mode_TypeDef AdcMode, FunctionalState NewState);
/**
 * rtl876x_adc.h
 * \brief   Enables or disables the specified ADC interrupts.
 * \param[in]  ADCx: Specify ADC peripheral.
 * \param[in]  ADC_IT: Specify the ADC interrupts sources to be enabled or disabled.
 *     This parameter can be any combination of the following values:
 *     \arg ADC_INT_FIFO_RD_REQ : FIFO read request.
 *     \arg ADC_INT_FIFO_RD_ERR : FIFO read error.
 *     \arg ADC_INT_FIFO_THD : ADC FIFO size > thd.
 *     \arg ADC_INT_FIFO_OVERFLOW : ADC FIFO overflow.
 *     \arg ADC_INT_ONE_SHOT_DONE : ADC one shot mode done.
 * \param[in]  NewState: New state of the specified ADC interrupt.
 *     This parameter can be: ENABLE or DISABLE.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_adc_init(void)
 * {
 *    //open clock
 *    RCC_PeriphClockCmd(APBPeriph_ADC, APBPeriph_ADC_CLOCK, ENABLE);
 *
 *    ADC_InitTypeDef ADC_InitStruct;
 *    ADC_StructInit(&ADC_InitStruct);
 *    ADC_InitStruct.ADC_SchIndex[0] = EXT_SINGLE_ENDED(0);
 *    ADC_InitStruct.ADC_SchIndex[1] = EXT_SINGLE_ENDED(1);
 *    ADC_InitStruct.ADC_Bitmap = 0x03;
 *    //Add other initialization parameters here.
 *    ADC_Init(ADC, &ADC_InitStruct);
 *
 *    ADC_INTConfig(ADC, ADC_INT_FIFO_RD_ERR, ENABLE);
 *    ADC_INTConfig(ADC, ADC_INT_ONE_SHOT_DONE, ENABLE);
 * }
 * \endcode
 *
 */
void ADC_INTConfig(ADC_TypeDef *ADCx, uint32_t ADC_INT, FunctionalState NewState);

/**
 * rtl876x_adc.h
 * \brief      Read ADC data according to specific channel.
 * \param[in]  ADCx: Specify ADC peripheral.
 * \param[in]  Index: Can be 0 to 15.
 * \return     The 12-bit converted ADC raw data.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_adc_init(void)
 * {
 *     Pad_Config(P2_0, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE,
 *                PAD_OUT_LOW);
 *
 *     Pad_Config(P2_1, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE,
 *                PAD_OUT_LOW);
 * }
 *
 * void driver_adc_init(void)
 * {
 *    //open clock
 *    RCC_PeriphClockCmd(APBPeriph_ADC, APBPeriph_ADC_CLOCK, ENABLE);
 *
 *    ADC_InitTypeDef ADC_InitStruct;
 *    ADC_StructInit(&ADC_InitStruct);
 *    ADC_InitStruct.ADC_SchIndex[0] = EXT_SINGLE_ENDED(0);
 *    ADC_InitStruct.ADC_SchIndex[1] = EXT_SINGLE_ENDED(1);
 *    ADC_InitStruct.ADC_Bitmap = 0x03;
 *    //Add other initialization parameters here.
 *    ADC_Init(ADC, &ADC_InitStruct);
 *
 *    ADC_INTConfig(ADC, ADC_INT_ONE_SHOT_DONE, ENABLE);
 * }
 *
 * void adc_demo(void)
 * {
 *    board_adc_init();
 *    driver_adc_init();
 *    ADC_Cmd(ADC, ADC_ONE_SHOT_MODE, ENABLE);
 *    while(ADC_GetINTStatus(ADC, ADC_INT_ONE_SHOT_DONE) == RESET);
 *    uint16_t raw_data_0 = ADC_ReadRawData(ADC, 0);
 *    uint16_t raw_data_1 = ADC_ReadRawData(ADC, 1);
 * }
 * \endcode
 */
uint16_t ADC_ReadRawData(ADC_TypeDef *ADCx, uint8_t Index);

/**
 * rtl876x_adc.h
 * \brief   Get ADC average data from ADC schedule table0.
 * \param[in]  ADCx: Specify ADC peripheral.
 * \param[out] OutBuf: Buffer to save data read from ADC FIFO.
 * \return  The 12-bit converted ADC raw data.
 * \callgraph
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_adc_init(void)
 * {
 *     Pad_Config(P2_0, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE,
 *                PAD_OUT_LOW);
 * }
 *
 * void driver_adc_init(void)
 * {
 *    //open clock
 *    RCC_PeriphClockCmd(APBPeriph_ADC, APBPeriph_ADC_CLOCK, ENABLE);
 *
 *    ADC_InitTypeDef ADC_InitStruct;
 *    ADC_StructInit(&ADC_InitStruct);
 *    ADC_InitStruct.ADC_SchIndex[0] = EXT_SINGLE_ENDED(0);
 *    ADC_InitStruct.ADC_Bitmap = 0x01;
 *    ADC_InitStruct.ADC_DataAvgEn  = ADC_DATA_AVERAGE_ENABLE;
 *    ADC_InitStruct.ADC_DataAvgSel = ADC_DATA_AVERAGE_OF_2;
 *    //Add other initialization parameters here.
 *    ADC_Init(ADC, &ADC_InitStruct);
 *
 *    ADC_INTConfig(ADC, ADC_INT_ONE_SHOT_DONE, ENABLE);
 * }
 *
 * void adc_demo(void)
 * {
 *    board_adc_init();
 *    driver_adc_init();
 *    ADC_Cmd(ADC, ADC_ONE_SHOT_MODE, ENABLE);
 *    while(ADC_GetINTStatus(ADC, ADC_INT_ONE_SHOT_DONE) == RESET);
 *    uint16_t raw_data = 0;
 *    raw_data = ADC_ReadAvgRawData(ADC);
 * }
 * \endcode
 *
 */
uint16_t ADC_ReadAvgRawData(ADC_TypeDef *ADCx);

/**
 * rtl876x_adc.h
 * \brief  Read one byte data from ADC FIFO.
 * \param[in]  ADCx: selected ADC peripheral.
 * \return adc FIFO data.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_adc_init(void)
 * {
 *     Pad_Config(P2_0, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE,
 *                PAD_OUT_LOW);
 * }
 *
 * void driver_adc_init(void)
 * {
 *    //open clock
 *    RCC_PeriphClockCmd(APBPeriph_ADC, APBPeriph_ADC_CLOCK, ENABLE);
 *
 *    ADC_InitTypeDef ADC_InitStruct;
 *    ADC_StructInit(&ADC_InitStruct);
 *    ADC_InitStruct.ADC_SchIndex[0] = EXT_SINGLE_ENDED(0);
 *    ADC_InitStruct.ADC_Bitmap = 0x01;
 *    ADC_InitStruct.ADC_DataWriteToFifo = ADC_DATA_WRITE_TO_FIFO_DISABLE;
 *    ADC_Init(ADC, &ADC_InitStruct);
 *
 *    ADC_INTConfig(ADC, ADC_INT_ONE_SHOT_DONE, ENABLE);
 * }
 *
 * void adc_demo(void)
 * {
 *    board_adc_init();
 *    driver_adc_init();
 *    ADC_Cmd(ADC, ADC_ONE_SHOT_MODE, ENABLE);
 *    while(ADC_GetINTStatus(ADC, ADC_INT_ONE_SHOT_DONE) == RESET);
 *    uint16_t raw_data = 0;
 *    raw_data = ADC_ReadFIFO(ADC);
 * }
 * \endcode
 */
uint16_t ADC_ReadFIFO(ADC_TypeDef *ADCx);

/**
 * rtl876x_adc.h
 * \brief   Get data from ADC FIFO.
 * \param[in]  ADCx: Specify ADC peripheral.
 * \param[out] outBuf: Buffer to save data read from ADC FIFO.
 * \param[in]  Num: Number of data to be read.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void adc_demo(void)
 * {
 *    //ADC already start
 *    uint16_t raw_data[32] = {0};
 *    uint8_t data_len = ADC_GetFIFODataLen(ADC);
 *    ADC_ReadFIFOData(ADC,raw_data,data_len);
 * }
 * \endcode
 *
 */
void ADC_ReadFIFOData(ADC_TypeDef *ADCx, uint16_t *outBuf, uint16_t Num);

/**
 * rtl876x_adc.h
 * \brief   Get ADC fifo data number.
 * \param[in] ADCx: selected ADC peripheral.
 * \return  Current data number in ADC FIFO.
 * <b>Example usage</b>
 * \code{.c}
 *
 * void adc_demo(void)
 * {
 *    //ADC already start
 *    uint16_t raw_data[32] = {0};
 *    uint8_t data_len = ADC_GetFIFODataLen(ADC);
 *    ADC_ReadFIFOData(ADC,raw_data,data_len);
 * }
 * \endcode
 *
 */
uint8_t ADC_GetFIFODataLen(ADC_TypeDef *ADCx);

/**
 * rtl876x_adc.h
 * \brief   Config ADC schedule table.
 * \param[in]  ADCx: Specify ADC peripheral.
 * \param[in]  AdcMode: ADC operation mode.
 *     This parameter can be one of the following values:
 *     \arg EXT_SINGLE_ENDED(index)
 *     \arg EXT_DIFFERENTIAL(index)
 *     \arg INTERNAL_VBAT_MODE
 * \param[in]  Index: Schedule table index.
 * \return  None.
 * <b>Example usage</b>
 * \code{.c}
 *
 * void adc_demo(void)
 * {
 *   ADC_SchIndexConfig(ADC,INTERNAL_VBAT_MODE,0);
 * }
 * \endcode
 *
 */
void ADC_SchIndexConfig(ADC_TypeDef *ADCx, uint8_t AdcMode, uint16_t Index);

/**
 * \brief  Same as function ADC_SchIndexConfig, this function is version bee2.
 */
void ADC_SchTableConfig(ADC_TypeDef *ADCx, uint16_t Index, uint8_t AdcMode);

/**
 * rtl876x_adc.h
 * \brief   Config adc schedule table.
 * \param[in]  ADCx: Specify ADC peripheral.
 * \param[in]  BitMap: ADC bit map.
 * \param[in]  NewState: New state of the ADC peripheral.
 *      This parameter can be: ENABLE or DISABLE.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void adc_demo(void)
 * {
 *   uint16_t bit_map = 0x03;
 *   ADC_BitMapConfig(ADC,bit_map,ENABLE);
 * }
 * \endcode
 */
void ADC_BitMapConfig(ADC_TypeDef *ADCx, uint16_t BitMap, FunctionalState NewState);

/**
 * rtl876x_adc.h
 * \brief   Power on ADC manually.
 * \param[in]  ADCx: Specify ADC peripheral.
 * \param[in]  NewState: New state of the ADC power on.
 *      This parameter can be: ENABLE or DISABLE. If enabled, ADC power will always be on until disabled.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void adc_demo(void)
 * {
 *   ADC_ManualPowerOnCmd(ADC,ENABLE);
 * }
 * \endcode
 */
void ADC_ManualPowerOnCmd(ADC_TypeDef *ADCx, FunctionalState NewState);

/**
 * rtl876x_adc.h
 * \brief   Enbale or disable stop FIFO from writing data.
 * \param[in]  ADCx: Specify ADC peripheral.
 * \param[in]  NewState: New state of the ADC FIFO write.
 *     This parameter can be: ENABLE or DISABLE.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void adc_demo(void)
 * {
 *   ADC_WriteFIFOCmd(ADC, ENABLE);
 * }
 * \endcode
 */
void ADC_WriteFIFOCmd(ADC_TypeDef *ADCx, FunctionalState NewState);

/**
 * rtl876x_adc.h
 * \brief     Config ADC bypass resistor.
 * \param[in] channelNum: External channel number, can be 0~7.
 * \param[in] NewState: Specifies whether the channel enables bypass mode.
 *            This parameter can be: ENABLE or DISABLE.
 * \return    None.
 * \attention The input voltage of channel pin using bypass mode cannot exceed 0.9V!
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void adc_demo(void)
 * {
 *   ADC_BypassCmd(0,ENABLE);
 * }
 * \endcode
 */
void ADC_BypassCmd(uint8_t ChannelNum, FunctionalState NewState);

/**
 * rtl876x_adc.h
 * \brief   Config ADC power supply.
 * \param[in] NewState: New state of the ADC power supply.
 *      This parameter can be: ENABLE or DISABLE.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void adc_demo(void)
 * {
 *   ADC_PowerSupplyConfig(ENABLE);
 * }
 * \endcode
 */
void ADC_PowerSupplyConfig(FunctionalState NewState);

/**
 * rtl876x_adc.h
 * \brief   Config ADC fast power supply.
 * \param[in] NewState: New state of the ADC fast power supply.
 *      This parameter can be: ENABLE or DISABLE.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void adc_demo(void)
 * {
 *   ADC_FastPowerSupplyConfig(ENABLE);
 * }
 * \endcode
 */
void ADC_FastPowerSupplyConfig(FunctionalState NewState);

/**
 * rtl876x_adc.h
 * \brief  Check whether the specified ADC interrupt flag is set.
 * \param[in]  ADCx: selected ADC peripheral.
 * \param[in]  ADC_INT_FLAG: Specifies the interrupt flag to check.
 *     This parameter can be one of the following values:
 *     \arg ADC_INT_ONE_SHOT_DONE: ADC once convert end interrupt.
 *     \arg ADC_INT_FIFO_OVERFLOW: ADC FIFO overflow interrupt.
 *     \arg ADC_INT_FIFO_THD: FIFO larger than threshold interrupt.
 *     \arg ADC_INT_FIFO_RD_ERR: ADC read FIFO error interrupt.
 *     \arg ADC_INT_FIFO_RD_REQ: ADC read FIFO request interrupt.
 *
 * \return The new state of ADC_INT (SET or RESET).
 * \retval SET.
 * \retval RESET.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void adc_demo(void)
 * {
 *     ITStatus int_status = RESET;
 *     int_status = ADC_GetINTStatus(ADC,ADC_INT_FIFO_OVERFLOW);
 * }
 * \endcode
 */
ITStatus ADC_GetINTStatus(ADC_TypeDef *ADCx, uint32_t ADC_INT);

/**
 * rtl876x_adc.h
 * \brief  Clear the ADC interrupt pending bit.
 * \param[in] ADCx: Specify ADC peripheral.
 * \param[in] ADC_INT: Specifies the interrupt pending bit to clear.
 *     This parameter can be any combination of the following values:
 *     \arg ADC_INT_ONE_SHOT_DONE: ADC once convert end interrupt.
 *     \arg ADC_INT_FIFO_OVERFLOW: ADC FIFO overflow interrupt.
 *     \arg ADC_INT_FIFO_THD: FIFO larger than threshold interrupt.
 *     \arg ADC_INT_FIFO_RD_ERR: ADC read FIFO error interrupt.
 *     \arg ADC_INT_FIFO_RD_REQ: ADC read FIFO request interrupt.
 *
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void adc_demo(void)
 * {
 *   ADC_ClearINTPendingBit(ADC,ADC_INT_FIFO_OVERFLOW);
 * }
 * \endcode
 */
void ADC_ClearINTPendingBit(ADC_TypeDef *ADCx, uint32_t ADC_INT);

/**
 * rtl876x_adc.h
 * \brief   Clear ADC FIFO.
 * \param[in] ADCx: Specify ADC peripheral.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void adc_demo(void)
 * {
 *   ADC_ClearFIFO(ADC);
 * }
 * \endcode
 */
__STATIC_INLINE void ADC_ClearFIFO(ADC_TypeDef *ADCx)
{
    /* Check the parameters */
    assert_param(IS_ADC_PERIPH(ADCx));

    ADCx->ADC_DIG_CTRL |= BIT26;
}

/**
 * rtl876x_adc.h
 * \brief   Get all adc interrupt flag status.
 * \param[in] ADCx: Specify ADC peripheral.
 * \return  All ADC interrupt status.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void adc_demo(void)
 * {
 *   uint8_t all_flag_status = 0;
 *   all_flag_status = ADC_GetAllFlagStatus(ADC);
 * }
 * \endcode
 *
 */
__STATIC_INLINE uint8_t ADC_GetAllFlagStatus(ADC_TypeDef *ADCx)
{
    /* Check the parameters */
    assert_param(IS_ADC_PERIPH(ADCx));

    return ((uint8_t)(((ADCx->ADC_CTRL_INT) & (0x1f << 16)) >> 16));
}

/** \} */ /* End of Group ADC_Exported_Functions */
#ifdef __cplusplus
}
#endif
#endif /* RTL_ADC_24BIT_H */
/******************* (C) COPYRIGHT 2020 Realtek Semiconductor *****END OF FILE****/
