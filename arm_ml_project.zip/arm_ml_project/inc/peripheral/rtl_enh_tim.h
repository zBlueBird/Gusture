/**
*********************************************************************************************************
*               Copyright(c) 2021, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* \file     rtl_enh_tim.h
* \brief    The header file of the peripheral Enhance ENHTIMER driver.
* \details  This file provides all Enhance ENHTIMER firmware functions.
* \author   Grace_yan
* \date     2022-02-17
* \version  v1.0.1
* *********************************************************************************************************
*/

#ifndef RTL_ENH_TIM_H
#define RTL_ENH_TIM_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * \addtogroup  IO          Peripheral Drivers
 * \defgroup    ENHTIM      ENHTIM
 * \brief       Manage the ENHTIM peripheral functions.
 * \ingroup     IO
 */

/*============================================================================*
 *                         Includes
 *============================================================================*/
#include "rtl876x.h"
#include "rtl_enhtim_reg.h"
#include "rtl_alias.h"

/*============================================================================*
 *                         Constants
 *============================================================================*/

/**
 * \defgroup    ENHTIM_Exported_Constants Macro Definitions
 * \ingroup     ENHTIM
 */
#define IS_ENHTIM_ALL_PERIPH(PERIPH) (((PERIPH) == ENH_ENHTIM0) || \
                                      ((PERIPH) == ENH_ENHTIM1)|| \
                                      ((PERIPH) == ENH_ENHTIM2)|| \
                                      ((PERIPH) == ENH_ENHTIM3)|| \
                                      ((PERIPH) == ENH_ENHTIM4)|| \
                                      ((PERIPH) == ENH_ENHTIM5)|| \
                                      ((PERIPH) == ENH_ENHTIM6)|| \
                                      ((PERIPH) == ENH_ENHTIM7))


/*============================================================================*
 *                         Types
 *============================================================================*/
#define PWM_0X270_EMG_STOP        BIT8
/**
 * \defgroup    ENHTIM_Clock_Source ENHTIM Clock Source
 * \{
 * \ingroup     ENHTIM_Exported_Types
 */
typedef enum
{
    ENHTIM_SOURCE_CLOCK_40M = 0x00,
    ENHTIM_SOURCE_CLOCK_PLL4 = 0x01,
    ENHTIM_SOURCE_CLOCK_PLL2 = 0x03,
    ENHTIM_SOURCE_CLOCK_PLL1 = 0x07,
} ENHTIM_CLK_SOURCE_T;
/** \} */
#define IS_ENHTIM_CLK_SOURCE(src) (((src) == ENHTIM_SOURCE_CLOCK_40M) || \
                                   ((src) == ENHTIM_SOURCE_CLOCK_PLL4)|| \\
                                   ((src) == ENHTIM_SOURCE_CLOCK_PLL2)|| \\
                                   ((src) == ENHTIM_SOURCE_CLOCK_PLL1))

/**
 * \defgroup    ENHTIM_DMA_CTRL_MODE ENHTIM DMA Control Mode
 * \{
 * \ingroup     ENHTIM_Exported_Types
 */
typedef enum
{
    ENHTIM_DMAC_FLOW_CONTROL = 0x00,
    ENHTIM_FLOW_CONTROL = 0x01,
} ENHTIM_DMA_CTRL_MODE_T;
/** \} */
#define IS_ENHTIM_DMA_CTRL_MODE (mode) (((mode) == ENHTIM_DMAC_FLOW_CONTROL) || \
                                        ((mode) == ENHTIM_FLOW_CONTROL))

/**
 * \defgroup    ENHTIM_DMA_TARGET ENHTIM DMA TARGET
 * \{
 * \ingroup     ENHTIM_Exported_Types
 */
typedef enum
{
    ENHTIM_DMA_CCR_FIFO = 0x00,
    ENHTIM_DMA_LC_FIFO = 0x01,
} ENHTIM_DMA_TARGET_T;
/** \} */
#define IS_ENHTIM_DMA_TARGET(mode) (((mode) == ENHTIM_DMA_CCR_FIFO) || \
                                    ((mode) == ENHTIM_DMA_LC_FIFO))

/**
 * \defgroup    ENHTIM_Latch_Trigger_Mode ENHTIM Latch Trigger Mode
 * \{
 * \ingroup     ENHTIM_Exported_Types
 */
typedef enum
{
    ENHTIM_LATCH_TRIGGER_RISING_EDGE = 0x00,
    ENHTIM_LATCH_TRIGGER_FALLING_EDGE = 0x01,
    ENHTIM_LATCH_TRIGGER_BOTH_EDGE = 0x02,
} ENHTIM_LATCH_TRIG_Mode_T;
/** \} */
#define IS_ENHTIM_LATCH_TRIG_Mode(mode) (((mode) == ENHTIM_LATCH_TRIGGER_BOTH_EDGE) || \
                                         ((mode) == ENHTIM_LATCH_TRIGGER_FALLING_EDGE) || \
                                         ((mode) == ENHTIM_LATCH_TRIGGER_RISING_EDGE))

/**
 * \defgroup    ENHTIM_PWM_Polarity ENHTIM PWM Polarity
 * \{
 * \ingroup     ENHTIM_Exported_Types
 */
typedef enum
{
    ENHTIM_PWM_START_WITH_LOW = 0x00,
    ENHTIM_PWM_START_WITH_HIGH = 0x01,
} ENHTIM_PWM_POLARITY_T;
/** \} */
#define IS_ENHTIM_PWM_POLARITY(pola) (((pola) == ENHTIM_PWM_START_WITH_HIGH) || \
                                      ((pola) == ENHTIM_PWM_START_WITH_LOW))

/**
 * \defgroup    ENHTIM_Mode ENHTIM Mode
 * \{
 * \ingroup     ENHTIM_Exported_Types
 */
typedef enum
{
    ENHTIM_MODE_FreeRun = 0x00,   /*!< User define freerun mode. */
    ENHTIM_MODE_PWM_AUTO = 0x01,  /*!< User define pwm auto mode. */
    ENHTIM_MODE_PWM_MANUAL = 0x02,/*!< User define pwm manual mode. */
} ENHTIM_MODE_T;
/** \} */
#define IS_ENHTIM_MODE(mode) (((mode) == ENHTIM_MODE_PWM_MANUAL) || \
                              ((mode) == ENHTIM_MODE_PWM_AUTO) || \
                              ((mode) == ENHTIM_MODE_UserDefine))

/**
 * \defgroup    ENHTIM_Interrupts_Definition ENHTIM Interrupts Definition
 * \{
 * \ingroup     ENHTIM_Exported_Types
 */
#define ENHTIM_INT_TIM                            (0x00)
#define ENHTIM_INT_LATCH_CNT_FIFO_FULL            (0x40)
#define ENHTIM_INT_LATCH_CNT_FIFO_THD             (0x42)
#define ENHTIM_INT_LATCH_CNT_FIFO_EMPTY           (0x01) /*!< Empty interrupt flag bit but no interrupt. */
/** \} */

#define IS_ENHTIM_INT(INT) (((INT) == ENHTIM_INT_TIM) || \
                            ((INT) == ENHTIM_INT_LATCH_CNT_FIFO_FULL) || \
                            ((INT) == ENHTIM_INT_LATCH_CNT_FIFO_THD))

/**
 * \defgroup    ENHTIM_FIFO_Flag ENHTIM FIFO Flag
 * \{
 * \ingroup     ENHTIM_Exported_Types
 */



#define ENHTIM_FLAG_TIM7_FIFO_EMPTY         BIT15
#define ENHTIM_FLAG_TIM7_FIFO_FULL          BIT14
#define ENHTIM_FLAG_TIM6_FIFO_EMPTY         BIT13
#define ENHTIM_FLAG_TIM6_FIFO_FULL          BIT12
#define ENHTIM_FLAG_TIM5_FIFO_EMPTY         BIT11
#define ENHTIM_FLAG_TIM5_FIFO_FULL          BIT10
#define ENHTIM_FLAG_TIM4_FIFO_EMPTY         BIT9
#define ENHTIM_FLAG_TIM4_FIFO_FULL          BIT8
#define ENHTIM_FLAG_TIM3_FIFO_EMPTY         BIT7
#define ENHTIM_FLAG_TIM3_FIFO_FULL          BIT6
#define ENHTIM_FLAG_TIM2_FIFO_EMPTY         BIT5
#define ENHTIM_FLAG_TIM2_FIFO_FULL          BIT4
#define ENHTIM_FLAG_TIM1_FIFO_EMPTY         BIT3
#define ENHTIM_FLAG_TIM1_FIFO_FULL          BIT2
#define ENHTIM_FLAG_TIM0_FIFO_EMPTY         BIT1
#define ENHTIM_FLAG_TIM0_FIFO_FULL          BIT0

/** \} */
#define IS_ENHTIM_CCR_FIFO_FLAG(flag) (((flag) == ENHTIM_FLAG_TIM0_FIFO_FULL) || \
                                       ((flag) == ENHTIM_FLAG_TIM0_FIFO_EMPTY) || \
                                       ((flag) == ENHTIM_FLAG_TIM1_FIFO_FULL) || \
                                       ((flag) == ENHTIM_FLAG_TIM1_FIFO_EMPTY) || \
                                       ((flag) == ENHTIM_FLAG_TIM2_FIFO_FULL) || \
                                       ((flag) == ENHTIM_FLAG_TIM2_FIFO_EMPTY) || \
                                       ((flag) == ENHTIM_FLAG_TIM3_FIFO_FULL) || \
                                       ((flag) == ENHTIM_FLAG_TIM3_FIFO_EMPTY) || \
                                       ((flag) == ENHTIM_FLAG_TIM4_FIFO_FULL) || \
                                       ((flag) == ENHTIM_FLAG_TIM4_FIFO_EMPTY) || \
                                       ((flag) == ENHTIM_FLAG_TIM5_FIFO_FULL) || \
                                       ((flag) == ENHTIM_FLAG_TIM5_FIFO_EMPTY) || \
                                       ((flag) == ENHTIM_FLAG_TIM6_FIFO_FULL) || \
                                       ((flag) == ENHTIM_FLAG_TIM6_FIFO_EMPTY) || \
                                       ((flag) == ENHTIM_FLAG_TIM7_FIFO_FULL) || \
                                       ((flag) == ENHTIM_FLAG_TIM7_FIFO_EMPTY) ))

/**
 * \defgroup    ENHTIM_PWM_DeadZone_Clock_Source ENHTIM PWM DeadZone Clock Source
 * \{
 * \ingroup     ENHTIM_Exported_Types
 */
typedef enum
{
    ENHTIM_PWM_DZCLKSRCE_ENHTIM = 0x0,
    ENHTIM_PWM_DZCLKSRCE_32K = 0x1,
} ENHTIM_PWM_DeadZone_Clock_Source_T;
/** \} */
#define IS_ENHTIM_PWM_DeadZone_Clock_Source(src) (((src) == ENHTIM_PWM_DZCLKSRCE_ENHTIM) || \
                                                  ((src) == ENHTIM_PWM_DZCLKSRCE_32K))

/**
 * \defgroup    ENHTIM_PWM_DeadZone_Stop_State ENHTIM PWM DeadZone Stop State
 * \{
 * \ingroup     ENHTIM_Exported_Types
 */
typedef enum
{
    ENHTIM_PWM_STOP_AT_LOW = 0x0,
    ENHTIM_PWM_STOP_AT_HIGH = 0x1,
} ENHTIM_PWM_DZ_STOP_STATE_T;
/** \} */

/**
 * \defgroup    ENHTIM_FIFO_Clear_Flag ENHTIM FIFO Clear Flag
 * \{
 * \ingroup     ENHTIM_Exported_Types
 */
#define ENHTIM_FIFO_CLR_CCR                 (0)
#define ENHTIM_FIFO_CLR_CNT0                (8)
/** \} */

/**
 * \defgroup    ENHTIM_Clock_Divider ENHTIM Clock Divider
 * \{
 * \ingroup     ENHTIM_Exported_Types
 */
typedef enum
{
    ENHTIM_CLOCK_DIVIDER_1   = 0x0,
    ENHTIM_CLOCK_DIVIDER_2   = 0x1,
    ENHTIM_CLOCK_DIVIDER_4   = 0x2,
    ENHTIM_CLOCK_DIVIDER_8   = 0x3,
    ENHTIM_CLOCK_DIVIDER_16  = 0x4,
    ENHTIM_CLOCK_DIVIDER_32  = 0x5,
    ENHTIM_CLOCK_DIVIDER_40  = 0x6,
    ENHTIM_CLOCK_DIVIDER_64  = 0x7,
} ENHTIM_CLKDIV_T;
/** \} */

/**
 * \defgroup    ENHTIM_Latch_Channel_Count ENHTIM Latch Channel Order Number
 * \{
 * \ingroup     ENHTIM_Exported_Types
 */
typedef enum
{
    LATCH_CNT_0 = 0x0,
//    LATCH_CNT_1 = 0x1,
//    LATCH_CNT_2 = 0x2,
} ENHTIM_LATCHCNT_T;
/** \} */

/**
 * \defgroup    ENHTIM_Exported_Types Init Params Struct
 *
 * \ingroup     ENHTIM
 */

/**
 * \brief       ENHTIM init structure definition.
 *
 * \ingroup     ENHTIM_Exported_Types
 */
typedef struct
{
    ENHTIM_CLK_SOURCE_T ENHTIM_ClockSource;    /*!< Specifies the ENHTIM clock source.*/
    FunctionalState ENHTIM_ClockDiv_En;        /*!< Specifies enable ENHTIM clock source divider .
                                                    This parameter can be a value of DISABLE or ENABLE*/
    ENHTIM_CLKDIV_T ENHTIM_ClockDiv;           /*!< Specifies the ENHTIM clock source div.*/
    ENHTIM_MODE_T ENHTIM_Mode;                 /*!< Specifies the counter mode.*/
    FunctionalState ENHTIM_PWMOutputEn;        /*!< Specifies enable Enhtimer PWM oupput.
                                                    This parameter can be a value of DISABLE or ENABLE */
    ENHTIM_PWM_POLARITY_T
    ENHTIM_PWMStartPolarity;                   /*!< Specifies enhtim toggle output polarity
                                                    for user-define PWM mode.*/
    FunctionalState ENHTIM_LatchCountEn;       /*!< Specifies enbale EnhtimerN Latch_cnt.
                                                    This parameter can be a value of DISABLE or ENABLE */
    ENHTIM_LATCH_TRIG_Mode_T
    ENHTIM_LatchCountTrigger;                  /*!< Specifies EnhtimerN counter latch
                                                    trigger mode. */
    uint16_t ENHTIM_LatchCountThd;             /*!< Specifies EnhtimerN latched counter fifo threshold.
                                                    This parameter can be value of  0~0x1F. */
    uint16_t ENHTIM_LatchTriggerPad;           /*!< Specifies the PWM mode.
                                                    This parameter can be a value of P0_0 to P19_0 */
    uint32_t ENHTIM_MaxCount;                  /*!< Specifies the Enhtimer max counter value for user-define PWM mode.
                                                    This parameter leagel value range is from 0 ~ 2^32-2. */
    uint32_t ENHTIM_CCValue;                   /*!< Specifies the Enhtimer capture/compare value for user-define PWM mode.
                                                    This parameter leagel value range is from 0 ~ 2^32-2*/
    FunctionalState ENHTIM_PWMDeadZoneEn;      /*!< Specifies the Enhtimer PWM Deadzone enable.
                                                    This parameter can be a value of ENABLE or DISABLE. */
    uint16_t ENHTIM_PWMDeadZoneClockSource;    /*!< Specifies ENHTIM PWM Deadzone Clock Source.
                                                    This parameter can be a value of ENHTIM_PWM_DeadZone_Clock_Source. */
    FunctionalState
    ENHTIM_PWMDeadZone_ClockDivEn;             /*!< Specifies enbale ENHTIM PWM Deadzone Clock Source DIV. */
    ENHTIM_CLKDIV_T
    ENHTIM_PWMDeadZone_ClockDiv;               /*!< Specifies ENHTIM PWM Deadzone Clock Source DIV. */
    ENHTIM_PWM_DZ_STOP_STATE_T ENHTIM_PWMStopStateP; /*!< Specifies the ENHTIM PWM P stop state. */
    ENHTIM_PWM_DZ_STOP_STATE_T ENHTIM_PWMStopStateN; /*!< Specifies the PWM N stop state. */
    uint32_t ENHTIM_DeadZoneSize;              /*!< Specifies size of deadzone time, DeadzoneTime=deadzonesize/32000 or 32768.
                                                    This parameter must range from 1 to 0xff. */
    FunctionalState ENHTIM_DmaEn;              /*!< Specifies enable Enhtimer DMA.
                                                    This parameter can be a value of DISABLE or ENABLE. */
    ENHTIM_DMA_TARGET_T ENHTIM_DmaTragget;     /*!< Specifies Enhtimer DMA target. */
} ENHTIM_InitTypeDef;

/*============================================================================*
 *                         Functions
 *============================================================================*/
/**
 * \defgroup    ENHTIM_Exported_Functions  Peripheral APIs
 * \{
 * \ingroup     ENHTIM
 */

/**
 * \brief     Initialize the ENHTIMx unit peripheral according to
 *            the specified parameters in ENHTIM_InitStruct.
 * \param[in] ENHTIMx: Where x can be 0 to 7 to select the ENHTIM peripheral.
 * \param[in] ENHTIM_InitStruct: pointer to a ENHTIM_InitTypeDef structure
  *           that contains the configuration information for the specified ENHTIM peripheral.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_enhance_timer_init(void)
 * {
 *     RCC_PeriphClockCmd(APBPeriph_TIMER, APBPeriph_TIMER_CLOCK, ENABLE);
 *
 *     ENHTIM_InitTypeDef ENHTIM_InitStruct;
 *     ENHTIM_StructInit(&ENHTIM_InitStruct);
 *
 *     ENHTIM_InitStruct.ENHTIM_PWM_En = PWM_DISABLE;
 *     ENHTIM_InitStruct.ENHTIM_Period = 1000000 - 1 ;
 *     ENHTIM_InitStruct.ENHTIM_Mode = ENHTIM_Mode_UserDefine;
 *     ENHTIM_Init(ENHTIMER_NUM, &ENHTIM_InitStruct);
 * }
 * \endcode
 */
void ENHTIM_Init(ENHTIM_TypeDef *ENHTIMx, ENHTIM_InitTypeDef *ENHTIM_TimeBaseInitStruct);
/**
 * \brief       Fills each ENHTIM_InitStruct member with its default value.
 * \param[in]   ENHTIM_TimeBaseInitStruct: Pointer to a ENHTIM_TimeBaseInitTypeDef structure which will be initialized.
 * \return      None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_enhance_timer_init(void)
 * {
 *     RCC_PeriphClockCmd(APBPeriph_ENHTIMER, APBPeriph_ENHTIMER_CLOCK, ENABLE);
 *
 *     ENHTIM_TimeBaseInitTypeDef ENHTIM_InitStruct;
 *     ENHTIM_StructInit(&ENHTIM_InitStruct);
 *
 *     ENHTIM_InitStruct.ENHTIM_PWM_En = PWM_DISABLE;
 *     ENHTIM_InitStruct.ENHTIM_Period = 1000000 - 1;
 *     ENHTIM_InitStruct.ENHTIM_Mode = ENHTIM_Mode_UserDefine;
 *     ENHTIM_TimeBaseInit(ENH_TIM0, &ENHTIM_InitStruct);
 * }
 * \endcode
 */
void ENHTIM_StructInit(ENHTIM_InitTypeDef *ENHTIM_InitStruct);
/**
 * \brief     Enables or disables the specified ENHTIM peripheral.
 * \param[in] ENHTIMx: Where x can be 0 to 7 to select the ENHTIMx peripheral.
 * \param[in] NewState: New state of the ENHTIMx peripheral.
 *            This parameter can be: ENABLE or DISABLE.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_enhance_timer_init(void)
 * {
 *     RCC_PeriphClockCmd(APBPeriph_ENHTIMER, APBPeriph_ENHTIMER_CLOCK, ENABLE);
 *
 *     ENHTIM_InitTypeDef ENHTIM_InitStruct;
 *     ENHTIM_StructInit(&ENHTIM_InitStruct);
 *
 *     ENHTIM_InitStruct.ENHTIM_PWM_En = PWM_DISABLE;
 *     ENHTIM_InitStruct.ENHTIM_Period = 1000000 - 1;
 *     ENHTIM_InitStruct.ENHTIM_Mode = ENHTIM_Mode_UserDefine;
 *     ENHTIM_Init(ENH_TIM0, &ENHTIM_InitStruct);
 *     ENHTIM_Cmd(ENH_TIM0, ENABLE);
 * }
 * \endcode
 */
void ENHTIM_Cmd(ENHTIM_TypeDef *ENHTIMx, FunctionalState NewState);
/**
 * \brief     Enables or disables ENHTIMx interrupt.
 * \param[in] ENHTIMx: Where x can be 0 to 7 to select the ENHTIMx peripheral.
 * \param[in] ENHTIM_INT: Specifies the ENHTIMx interrupt source which to be enabled or disabled.
 *            This parameter can be one of the following values:
 *            \arg ENHTIM_INT_TIM: Enhance Timer interrupt source.
 *            \arg ENHTIM_INT_LATCH_CNT2_FIFO_FULL: Enhance Timer latch count2 fifo full interrupt source.
 *            \arg ENHTIM_INT_LATCH_CNT2_FIFO_THD: Enhance Timer latch count2 fifo threshold interrupt source.
 * \param[in] NewState: New state of the ENHTIMx peripheral.
 *            This parameter can be: ENABLE or DISABLE.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_enhance_timer_init(void)
 * {
 *     RCC_PeriphClockCmd(APBPeriph_TIMER, APBPeriph_TIMER_CLOCK, ENABLE);
 *
 *     ENHTIM_InitTypeDef ENHTIM_InitStruct;
 *     ENHTIM_StructInit(&ENHTIM_InitStruct);
 *
 *     ENHTIM_InitStruct.ENHTIM_PWM_En = PWM_DISABLE;
 *     ENHTIM_InitStruct.ENHTIM_Period = 1000000 - 1;
 *     ENHTIM_InitStruct.ENHTIM_Mode = ENHTIM_Mode_UserDefine;
 *     ENHTIM_Init(ENH_TIM0, &ENHTIM_InitStruct);
 *     ENHTIM_ClearINT(ENH_TIM0);
 *     ENHTIM_INTConfig(ENH_TIM0, ENABLE);
 */
void ENHTIM_INTConfig(ENHTIM_TypeDef *ENHTIMx, uint8_t ENHTIM_INT, FunctionalState NewState);
/**
 * \brief     Get ENHTIMx current value when timer is running.
 * \param[in] ENHTIMx: where x can be 0 to 7 to select the ENHTIMx peripheral.
 * \return    The counter value.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     uint32_t cur_value = ENHTIM_GetCurrentValue(ENH_TIM0);
 * }
 * \endcode
 */

/**
* \brief     Read ENHTIMx latch counter0 fifo data.
* \param[in] ENHTIMx: Where x can be 0 to 7 to select the ENHTIMx peripheral.
* \param[in] length: Latch count0 fifo length, max 4.
* \pBuf[out] pBuf: FIFO data out buffer.
* \return    None.
*
* <b>Example usage</b>
* \code{.c}
*
* void enhance_timer_demo(void)
* {
*     uint8_t length = ENHTIM_GetLatchCountFIFOLength(ENH_TIM0);
* }
* \endcode
*/
void ENHTIM_ReadLatchCountFIFO(ENHTIM_TypeDef *ENHTIMx, uint32_t *pBuf, uint8_t length);

/**
 * \brief     Check whether the ENHTIM interrupt has occurred or not.
 * \param[in] ENHTIMx: Where x can be 0 to 7 to select the ENHTIMx peripheral.
 * \param[in] ENHTIM_INT: Specifies the ENHTIMx interrupt source which to be enabled or disabled.
 *            This parameter can be one of the following values:
 *            \arg ENHTIM_INT_TIM: Enhance Timer interrupt source.
 *            \arg ENHTIM_INT_LATCH_CNT_FIFO_FULL: Enhance Timer latch count0 fifo full interrupt source.
 *            \arg ENHTIM_INT_LATCH_CNT_FIFO_EMPTY: Enhance Timer latch count0 fifo empty interrupt source.
 *            \arg ENHTIM_INT_LATCH_CNT_FIFO_THD: Enhance Timer latch count0 fifo threshold interrupt source.
 * \return    The new state of the ENHTIM_INT(SET or RESET).
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     ENHTIM_GetINTStatus(ENH_TIM0, ENHTIM_INT_TIM);
 * }
 * \endcode
 */
ITStatus ENHTIM_GetINTStatus(ENHTIM_TypeDef *ENHTIMx, uint8_t ENHTIM_INT);

/**
 * \brief     Clear ENHTIMx interrupt.
 * \param[in] ENHTIMx: Where x can be 0 to 7 to select the ENHTIMx peripheral.
 * \param[in] ENHTIM_INT: Specifies the ENHTIMx interrupt source which to be enabled or disabled.
 *            This parameter can be one of the following values:
 *            \arg ENHTIM_INT_TIM: Enhance Timer interrupt source.
 *            \arg ENHTIM_INT_LATCH_CNT_FIFO_FULL: Enhance Timer latch count0 fifo full interrupt source.
 *            \arg ENHTIM_INT_LATCH_CNT_FIFO_THD: Enhance Timer latch count0 fifo threshold interrupt source.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     ENHTIM_ClearINTPendingBit(ENH_TIM0, ENHTIM_INT_TIM);
 * }
 * \endcode
 */
void ENHTIM_ClearINTPendingBit(ENHTIM_TypeDef *ENHTIMx, uint8_t ENHTIM_INT);

/**
 * \brief     Get ENHTIMx toggle state.
 * \param[in] ENHTIMx: Where x can be 0 to 7 to select the ENHTIMx peripheral.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     bool State=ENHTIM_GetToggleState(ENHTIM0);
 * }
 * \endcode
 */
bool ENHTIM_GetToggleState(ENHTIM_TypeDef *ENHTIMx);


__STATIC_INLINE uint32_t ENHTIM_GetCurrentCount(ENHTIM_TypeDef *ENHTIMx)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

    return ENHTIMx->ENHTIM_CUR_CNT;
}

/**
 * \brief     Set Max Count value.
 * \param[in] ENHTIMx: Where x can be 0 to 7 to select the ENHTIMx peripheral.
 * \param[in] count: .
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     ENHTIM_SetMaxCount(ENH_TIM0, 0x10000);
 * }
 * \endcode
 */
__STATIC_INLINE void ENHTIM_SetMaxCount(ENHTIM_TypeDef *ENHTIMx, uint32_t count)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

    ENHTIMx->ENHTIM_MAX_CNT = count & 0xFFFFFFFE;
}

/**
 * \brief     Set ENHTIMx capture/compare value for user-define PWM manual mode.
 * \param[in] ENHTIMx: Where x can be 0 to 7 to select the ENHTIMx peripheral.
 * \param[in] value: .
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     ENHTIM_SetCCValue(ENH_TIM0, 0x1000);
 * }
 * \endcode
 */
__STATIC_INLINE void ENHTIM_SetCCValue(ENHTIM_TypeDef *ENHTIMx, uint32_t value)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

    ENHTIMx->ENHTIM_CCR = value;
}

/**
 * \brief     Set ENHTIMx capture/compare value for user-define PWM auto mode.
 * \param[in] ENHTIMx: Where x can be 0 to 7 to select the ENHTIMx peripheral.
 * \param[in] value: .
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     ENHTIM_WriteCCFIFO(ENH_TIM0,0x10000);
 * }
 * \endcode
 */
__STATIC_INLINE void ENHTIM_WriteCCFIFO(ENHTIM_TypeDef *ENHTIMx, uint32_t value)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

    ENHTIMx->ENHTIM_CCR_FIFO_ENTRY = value;
}


__STATIC_INLINE FlagStatus ENHTIM_GetCCRFIFOFlagStatus(uint32_t ENHTIM_CCR_FLAG)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_FIFO_FLAG(ENHTIM_CCR_FLAG));

    FlagStatus bitstatus = RESET;

    if (ENH_TIM_SHARE->ENHTIM_CCR_FIFO_STATUS & ENHTIM_CCR_FLAG)
    {
        bitstatus = SET;
    }

    return bitstatus;
}
__STATIC_INLINE FlagStatus ENHTIM_GetLCFIFOFlagStatus(uint32_t ENHTIM_LC_FLAG)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_FIFO_FLAG(ENHTIM_LC_FLAG));

    FlagStatus bitstatus = RESET;

    if (ENH_TIM_SHARE->ENHTIM_LATCH_CNT_FIFO_STATUS & ENHTIM_LC_FLAG)
    {
        bitstatus = SET;
    }

    return bitstatus;
}
/**
 * \brief     Enable ENHTIMx latch counter.
 * \param[in] ENHTIMx: where x can be 0 to 7 to select the ENHTIMx peripheral.
 * \param[in] LatchCntIdx: E_ENHTIM_LATCHCNT enum value.
 *            This parameter can be one of follow.
 *            \arg LATCH_COUNT_0: Enhance timer latch count 0.
 *            \arg LATCH_COUNT_1: Enhance timer latch count 1.
 *            \arg LATCH_COUNT_2: Enhance timer latch count 2.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     uint32_t cur_value = ENHTIM_LatchCountEnable(ENH_TIM0, LATCH_COUNT_0);
 * }
 * \endcode
 */
__STATIC_INLINE void ENHTIM_LatchCountEnable(ENHTIM_TypeDef *ENHTIMx, ENHTIM_LATCHCNT_T LatchCntIdx)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

    if (LatchCntIdx == LATCH_CNT_0)
    {
        ENHTIM_CONFIGURE_t ENHTIM_0x10 = {.d32 = ENHTIMx->ENHTIM_CONFIGURE};
        ENHTIM_0x10.b.Enhtimer_Latch_cnt_0_en = 0x1;
        ENHTIMx->ENHTIM_CONFIGURE = ENHTIM_0x10.d32;
    }
}

/**
 * \brief     Disable ENHTIMx latch counter.
 * \param[in] ENHTIMx: where x can be 0 to 7 to select the ENHTIMx peripheral.
 * \param[in] LatchCntIdx: E_ENHTIM_LATCHCNT enum value.
 *            This parameter can be one of follow.
 *            \arg LATCH_COUNT_0: Enhance timer latch count 0.
 *            \arg LATCH_COUNT_1: Enhance timer latch count 1.
 *            \arg LATCH_COUNT_2: Enhance timer latch count 2.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     uint32_t cur_value = ENHTIM_LatchCountDisable(ENH_TIM0, LATCH_COUNT_0);
 * }
 * \endcode
 */
__STATIC_INLINE void ENHTIM_LatchCountDisable(ENHTIM_TypeDef *ENHTIMx,
                                              ENHTIM_LATCHCNT_T LatchCntIdx)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

    if (LatchCntIdx == LATCH_CNT_0)
    {
        ENHTIM_CONFIGURE_t ENHTIM_0x10 = {.d32 = ENHTIMx->ENHTIM_CONFIGURE};
        ENHTIM_0x10.b.Enhtimer_Latch_cnt_0_en = 0x0;
        ENHTIMx->ENHTIM_CONFIGURE = ENHTIM_0x10.d32;
    }
}

/**
 * \brief     Get ENHTIMx latch count value.
 * \param[in] ENHTIMx: Where x can be 0 to 7 to select the ENHTIMx peripheral.
 * \param[in] LatchCntIdx: E_ENHTIM_LATCHCNT enum value.
 *            This parameter can be one of follow.
 *            \arg LATCH_COUNT_0: Enhance timer latch count 0.
 *            \arg LATCH_COUNT_1: Enhance timer latch count 1.
 *            \arg LATCH_COUNT_2: Enhance timer latch count 2.
 * \return    The latch counter value.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     uint32_t count_value = ENHTIM_GetLatchCountValue(ENH_TIM0, LATCH_COUNT_0);
 * }
 * \endcode
 */
__STATIC_INLINE uint32_t ENHTIM_GetLatchCount(ENHTIM_TypeDef *ENHTIMx,
                                              ENHTIM_LATCHCNT_T LatchCntIdx)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

    uint32_t count = 0;
    count = *(volatile uint32_t *)(&(ENHTIMx->ENHTIM_LATCH_CNT_0) + LatchCntIdx);
    return count;
}

/**
 * \brief     Get ENHTIMx latch counter2 fifo length.
 * \param[in] ENHTIMx: where x can be 0 to 7 to select the ENHTIMx peripheral.
 * \return    FIFO data length.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     uint8_t length = ENHTIM_GetLatchCount2FIFOLength(ENH_TIM0);
 * }
 * \endcode
 */
__STATIC_INLINE uint8_t ENHTIM_GetLatchCountFIFOLength(ENHTIM_TypeDef *ENHTIMx)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

    uint32_t enhtim_id = ((uint32_t)ENHTIMx - (uint32_t)ENH_TIM0) / 0X24;

    return (uint8_t)(*(&(ENH_TIM_SHARE->ENHTIM0_LATCH_FIFO_DEPTH) + enhtim_id)) & 0xF;
}

/**
 * \brief     Clear capture/compare or latch count2 fifo.
 * \param[in] ENHTIMx: Where x can be 0 to 7 to select the ENHTIMx peripheral.
 * \param[in] FIFO_CLR: Specifies the FIFO type which to be clear.
 *            This parameter can be one of the following values:
 *            \arg ENHTIM_FIFO_CLR_CCR: Enhance Timer CCR FIFO clear flag.
 *            \arg ENHTIM_FIFO_CLR_CNT2: Enhance Timer latch count2 FIFO clear flag.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     ENHTIM_ClearFIFO(ENH_TIM0, ENHTIM_FIFO_CLR_CCR);
 * }
 * \endcode
 */
__STATIC_INLINE void ENHTIM_ClearFIFO(ENHTIM_TypeDef *ENHTIMx, uint8_t FIFO_CLR)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

    uint32_t enhtim_id = ((uint32_t)ENHTIMx - (uint32_t)ENH_TIM0) / 0X24;

    ENH_TIM_SHARE->ENHTIM_FIFO_CLR |= (BIT(FIFO_CLR + enhtim_id));
}

/**
 * \brief   ENHTIM PWM complementary output emergency stop.
 * \param   None.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     ENHTIM_PWMDeadZoneEMStop();
 * }
 * \endcode
 */
__STATIC_INLINE void ENHTIM_PWMDeadZoneEMStop(ENHTIM_TypeDef *ENHTIMx)
{
    uint32_t enhtim_id = ((uint32_t)ENHTIMx - (uint32_t)ENH_TIM0) / 0X24;
    if (enhtim_id == 0)
    {
        ENH_TIM0_PWM->ENHTIMER_PWM_WRAP_CFG |= PWM_0X270_EMG_STOP;
    }
    else if (enhtim_id == 1)
    {
        ENH_TIM1_PWM->ENHTIMER_PWM_WRAP_CFG |= PWM_0X270_EMG_STOP;
    }
    else if (enhtim_id == 2)
    {
        ENH_TIM2_PWM->ENHTIMER_PWM_WRAP_CFG |= PWM_0X270_EMG_STOP;
    }
    else if (enhtim_id == 3)
    {
        ENH_TIM3_PWM->ENHTIMER_PWM_WRAP_CFG |= PWM_0X270_EMG_STOP;
    }
    else if (enhtim_id == 4)
    {
        ENH_TIM4_PWM->ENHTIMER_PWM_WRAP_CFG |= PWM_0X270_EMG_STOP;
    }
    else if (enhtim_id == 5)
    {
        ENH_TIM5_PWM->ENHTIMER_PWM_WRAP_CFG |= PWM_0X270_EMG_STOP;
    }
    else if (enhtim_id == 6)
    {
        ENH_TIM6_PWM->ENHTIMER_PWM_WRAP_CFG |= PWM_0X270_EMG_STOP;
    }
    else if (enhtim_id == 7)
    {
        ENH_TIM7_PWM->ENHTIMER_PWM_WRAP_CFG |= PWM_0X270_EMG_STOP;
    }

}

/**
 * \brief     Check whether the ENHTIM interrupt has occurred or not.
 * \param[in] ENHTIMx: Where x can be 0 to 7 to select the ENHTIMx peripheral.
 * \return    The new state of the ENHTIM_IT(SET or RESET).
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     ITStatus int_status = ENHTIM_GetINTStatus(ENH_TIM0);
 * }
 * \endcode
 */
__STATIC_INLINE uint32_t ENHTIM_GetAllINTStatus(void)
{
    return ENH_TIM_SHARE->ENHTIM_INT_STATUS;
}

/** \} */ /* End of group ENHTIM_Exported_Functions */

#ifdef __cplusplus
}
#endif


#endif /* RTL_ENH_TIM_H */
