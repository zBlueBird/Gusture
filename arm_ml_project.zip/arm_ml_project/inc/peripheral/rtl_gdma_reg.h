#ifndef RTL_GDMA_REG_H
#define RTL_GDMA_REG_H

#include <stdint.h>
#include <stdbool.h>
#include "rtl876x.h"

#ifdef  __cplusplus
extern "C" {
#endif /* __cplusplus */

/*============================================================================*
 *                         GDMA Registers Memory Map
 *============================================================================*/
#define GDMA_REGISTER_DEFINE 1
typedef struct
{
    __IO uint32_t GDMA_SARx;                /*!< 0x00 */
    __I  uint32_t GDMA_CURR_SARx;           /*!< 0x04 */
    __IO uint32_t GDMA_DARx;                /*!< 0x08 */
    __I  uint32_t GDMA_CURR_DARx;           /*!< 0x0C */
    __IO uint32_t GDMA_LLPx;                /*!< 0x10 */
    uint32_t GDMA_RSVD;                     /*!< 0x14 */
    __IO uint32_t GDMA_CTL_LOWx;            /*!< 0x18 */
    __IO uint32_t GDMA_CTL_HIGHx;           /*!< 0x1C */
    uint32_t GDMA_RSVD1[8];                 /*!< 0x20 ~ 0x3C */
    __IO uint32_t GDMA_CFG_LOWx;            /*!< 0x40 */
    __IO uint32_t GDMA_CFG_HIGHx;           /*!< 0x44 */
    __IO uint32_t GDMA_SGR_LOW;             /*!< 0x48 */
    __IO uint32_t GDMA_SGR_HIGH;            /*!< 0x4C */
    __IO uint32_t GDMA_DSR_LOW;             /*!< 0x50 */
    __IO uint32_t GDMA_DSR_HIGH;            /*!< 0x54 */
} GDMA_ChannelTypeDef;

typedef struct
{
    uint32_t GDMA_RSVD[10];                 /*!< 0x2C0 - 0x2E4 */

    __I uint32_t GDMA_StatusTfr;            /*!< 0x2E8 */
    uint32_t GDMA_RSVD1;
    __I uint32_t GDMA_StatusBlock;          /*!< 0x2F0 */
    uint32_t GDMA_RSVD2;
    __I uint32_t GDMA_StatusSrcTran;        /*!< 0x2F8 */
    uint32_t GDMA_RSVD3;
    __I uint32_t GDMA_StatusDstTran;        /*!< 0x300 */
    uint32_t GDMA_RSVD4;
    __I uint32_t GDMA_StatuErr;             /*!< 0x308 */
    __I uint32_t GDMA_StatuErrNonSecure;

    __IO uint32_t GDMA_MaskTfr;             /*!< 0x310 */
    uint32_t GDMA_RSVD6;
    __IO uint32_t GDMA_MaskBlock;           /*!< 0x318 */
    uint32_t GDMA_RSVD7;
    __IO uint32_t GDMA_MaskSrcTran;         /*!< 0x320 */
    uint32_t GDMA_RSVD8;
    __IO uint32_t GDMA_MaskDstTran;         /*!< 0x328 */
    uint32_t GDMA_RSVD9;
    __IO uint32_t GDMA_MaskErr;             /*!< 0x330 */
    __IO uint32_t GDMA_MaskErrNonSecure;

    __O uint32_t GDMA_ClearTfr;             /*!< 0x338 */
    uint32_t GDMA_RSVD11;
    __O uint32_t GDMA_ClearBlock;           /*!< 0x340 */
    uint32_t GDMA_RSVD12;
    __O uint32_t GDMA_ClearSrcTran;         /*!< 0x348 */
    uint32_t GDMA_RSVD13;
    __O uint32_t GDMA_ClearDstTran;         /*!< 0x350 */
    uint32_t GDMA_RSVD14;
    __O uint32_t GDMA_ClearErr;             /*!< 0x358 */
    __O uint32_t GDMA_ClearErrNonSecure;

    uint32_t GDMA_RSVD16[14];               /*!< 0x360 ~ 0x394 */

    __IO uint32_t GDMA_DmaCfgReg;           /*!< 0x398 */
    uint32_t GDMA_RSVD17;
    __IO uint32_t GDMA_ChEnReg;             /*!< 0x3A0 */
    uint32_t GDMA_RSVD18;

    uint32_t GDMA_RSVD19[4];                /*!< 0x3A8 ~ 0x3B4 */
    __IO uint32_t GDMA_DmaOsNum;            /*!< 0x3B8 */
    uint32_t GDMA_RSVD20;
} GDMA_TypeDef;

/*============================================================================*
 *                         GDMA Declaration
 *============================================================================*/
#define GDMA0              ((GDMA_TypeDef        *) GDMA0_REG_BASE)
#define GDMA0_Channel0     ((GDMA_ChannelTypeDef *) GDMA0_Channel0_BASE)
#define GDMA0_Channel1     ((GDMA_ChannelTypeDef *) GDMA0_Channel1_BASE)
#define GDMA0_Channel2     ((GDMA_ChannelTypeDef *) GDMA0_Channel2_BASE)
#define GDMA1              ((GDMA_TypeDef        *) GDMA1_REG_BASE)
#define GDMA1_Channel0     ((GDMA_ChannelTypeDef *) GDMA1_Channel0_BASE)
#define GDMA1_Channel1     ((GDMA_ChannelTypeDef *) GDMA1_Channel1_BASE)
#define GDMA1_Channel2     ((GDMA_ChannelTypeDef *) GDMA1_Channel2_BASE)
#define GDMA1_Channel3     ((GDMA_ChannelTypeDef *) GDMA1_Channel3_BASE)
#define GDMA1_Channel4     ((GDMA_ChannelTypeDef *) GDMA1_Channel4_BASE)
#define GDMA1_Channel5     ((GDMA_ChannelTypeDef *) GDMA1_Channel5_BASE)
#define GDMA1_Channel6     ((GDMA_ChannelTypeDef *) GDMA1_Channel6_BASE)
#define GDMA1_Channel7     ((GDMA_ChannelTypeDef *) GDMA1_Channel7_BASE)
#define GDMA2              ((GDMA_TypeDef        *) GDMA2_REG_BASE)
#define GDMA2_Channel0     ((GDMA_ChannelTypeDef *) GDMA2_Channel0_BASE)
#define GDMA2_Channel1     ((GDMA_ChannelTypeDef *) GDMA2_Channel1_BASE)
#define GDMA2_Channel2     ((GDMA_ChannelTypeDef *) GDMA2_Channel2_BASE)
#define GDMA2_Channel3     ((GDMA_ChannelTypeDef *) GDMA2_Channel3_BASE)
#define GDMA2_Channel4     ((GDMA_ChannelTypeDef *) GDMA2_Channel4_BASE)
#define GDMA2_Channel5     ((GDMA_ChannelTypeDef *) GDMA2_Channel5_BASE)
#define GDMA2_Channel6     ((GDMA_ChannelTypeDef *) GDMA2_Channel6_BASE)
#define GDMA2_Channel7     ((GDMA_ChannelTypeDef *) GDMA2_Channel7_BASE)
#define GDMA2_Channel8     ((GDMA_ChannelTypeDef *) GDMA2_Channel8_BASE)
#define GDMA2_Channel9     ((GDMA_ChannelTypeDef *) GDMA2_Channel9_BASE)
#define GDMA2_Channel10    ((GDMA_ChannelTypeDef *) GDMA2_Channel10_BASE)
#define GDMA2_Channel11    ((GDMA_ChannelTypeDef *) GDMA2_Channel11_BASE)
#define GDMA2_Channel12    ((GDMA_ChannelTypeDef *) GDMA2_Channel12_BASE)
#define GDMA2_Channel13    ((GDMA_ChannelTypeDef *) GDMA2_Channel13_BASE)
#define GDMA2_Channel14    ((GDMA_ChannelTypeDef *) GDMA2_Channel14_BASE)
#define GDMA2_Channel15    ((GDMA_ChannelTypeDef *) GDMA2_Channel15_BASE)
#define GDMA_Channel0      GDMA0_Channel0
#define GDMA_Channel1      GDMA0_Channel1
#define GDMA_Channel2      GDMA0_Channel2
#define GDMA_Channel3      GDMA1_Channel0
#define GDMA_Channel4      GDMA1_Channel1
#define GDMA_Channel5      GDMA1_Channel2
#define GDMA_Channel6      GDMA1_Channel3
#define GDMA_Channel7      GDMA1_Channel4
#define GDMA_Channel8      GDMA1_Channel5
#define GDMA_Channel9      GDMA1_Channel6
#define GDMA_Channel10     GDMA1_Channel7
#define GDMA_Channel11     GDMA2_Channel0
#define GDMA_Channel12     GDMA2_Channel1
#define GDMA_Channel13     GDMA2_Channel2
#define GDMA_Channel14     GDMA2_Channel3
#define GDMA_Channel15     GDMA2_Channel4
#define GDMA_Channel16     GDMA2_Channel5
#define GDMA_Channel17     GDMA2_Channel6
#define GDMA_Channel18     GDMA2_Channel7
#define GDMA_Channel19     GDMA2_Channel8
#define GDMA_Channel20     GDMA2_Channel9
#define GDMA_Channel21     GDMA2_Channel10
#define GDMA_Channel22     GDMA2_Channel11
#define GDMA_Channel23     GDMA2_Channel12
#define GDMA_Channel24     GDMA2_Channel13
#define GDMA_Channel25     GDMA2_Channel14
#define GDMA_Channel26     GDMA2_Channel15

/*============================================================================*
 *                         GDMA Registers and Field Descriptions
 *============================================================================*/
/* 0x00
   31:0    R/W    SAR                 undefined
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t SAR: 32;
    } b;
} GDMA_SARx_t;



/* 0x04
   31:0    R      CURR_SAR            0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t CURR_SAR: 32;
    } b;
} GDMA_CURR_SARx_t;



/* 0x08
   31:0    R/W    DAR                 undefined
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t DAR: 32;
    } b;
} GDMA_DARx_t;



/* 0x0C
   31:0    R      CURR_DAR            0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t CURR_DAR: 32;
    } b;
} GDMA_CURR_DARx_t;



/* 0x10
   1:0     R/W    reserved13          0x0
   31:2    R/W    LOC                 0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t reserved_0: 2;
        __IO uint32_t LOC: 30;
    } b;
} GDMA_LLPx_t;


/* 0x18
   0       R/W    INT_EN              0x1
   3:1     R/W    DST_TR_WIDTH        0x0
   6:4     R/W    SRC_TR_WIDTH        0x0
   8:7     R/W    DINC                0x0
   10:9    R/W    SINC                0x0
   13:11   R/W    DEST_MSIZE          0x1
   16:14   R/W    SRC_MSIZE           0x1
   17      R/W    SRC_GATHER_EN       0x0
   18      R/W    DST_SCATTER_EN      0x0
   19      R/W    reserved20          0x0
   22:20   R/W    TT_FC               0x0
   26:23   R      reserved18          0x0
   27      R/W    LLP_DST_EN          0x0
   28      R/W    LLP_SRC_EN          0x0
   31:29   R      reserved15          0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t INT_EN: 1;
        __IO uint32_t DST_TR_WIDTH: 3;
        __IO uint32_t SRC_TR_WIDTH: 3;
        __IO uint32_t DINC: 2;
        __IO uint32_t SINC: 2;
        __IO uint32_t DEST_MSIZE: 3;
        __IO uint32_t SRC_MSIZE: 3;
        __IO uint32_t SRC_GATHER_EN: 1;
        __IO uint32_t DST_SCATTER_EN: 1;
        __IO uint32_t reserved_2: 1;
        __IO uint32_t TT_FC: 3;
        __I uint32_t reserved_1: 4;
        __IO uint32_t LLP_DST_EN: 1;
        __IO uint32_t LLP_SRC_EN: 1;
        __I uint32_t reserved_0: 3;
    } b;
} GDMA_CTL_LOWx_t;



/* 0x1C
   31:0    R      TRANS_DATA_CNT      0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t TRANS_DATA_CNT: 32;
    } b;
} GDMA_CTL_HIGHx_R_t;



/* 0x1C
   15:0    W      BLOCK_TS            0x2
   31:16   W      reserved31          0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __O uint32_t BLOCK_TS: 16;
        __O uint32_t reserved_0: 16;
    } b;
} GDMA_CTL_HIGHx_W_t;


/* 0x40
   0       R      INACTIVE            0x1
   1       R      SRC_PCTL_OVER       0x1
   2       R      DST_PCTL_OVER       0x1
   3       R      reserved45          0x0
   7:4     R/W    CH_PRIOR            0x0
   8       R/W    CH_SUSP             0x0
   9       R      FIFO_EMPTY          0x1
   10      R/W    HS_SEL_DST          0x1
   11      R/W    HS_SEL_SRC          0x1
   17:12   R      reserved39          0x0
   18      R/W    DST_HS_POL          0x0
   19      R/W    SRC_HS_POL          0x0
   29:20   R/W    reserved36          0x0
   30      R/W    RELOAD_SRC          0x0
   31      R/W    RELOAD_DST          0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t INACTIVE: 1;
        __I uint32_t SRC_PCTL_OVER: 1;
        __I uint32_t DST_PCTL_OVER: 1;
        __I uint32_t reserved_2: 1;
        __IO uint32_t CH_PRIOR: 4;
        __IO uint32_t CH_SUSP: 1;
        __I uint32_t FIFO_EMPTY: 1;
        __IO uint32_t HS_SEL_DST: 1;
        __IO uint32_t HS_SEL_SRC: 1;
        __I uint32_t reserved_1: 6;
        __IO uint32_t DST_HS_POL: 1;
        __IO uint32_t SRC_HS_POL: 1;
        __IO uint32_t reserved_0: 10;
        __IO uint32_t RELOAD_SRC: 1;
        __IO uint32_t RELOAD_DST: 1;
    } b;
} GDMA_CFG_LOWx_t;



/* 0x44
   0       R/W    reserved63          0x0
   1       R/W    reserved62          0x0
   2       R      reserved61          0x0
   3       R/W    PROTCTL             0x1
   6:4     R      reserved59          0x0
   10:7    R/W    SRC_PER             0x0
   14:11   R/W    DEST_PER            0x0
   15      R/W    ExtendedSRC_PER1    0x0
   16      R/W    ExtendedDEST_PER1   0x0
   17      R/W    ExtendedSRC_PER2    0x0
   18      R/W    ExtendedDEST_PER2   0x0
   19      R      ExtendedSRC_PER3    0x0
   20      R      ExtendedDEST_PER3   0x0
   31:21   R      reserved50          0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t reserved_4: 1;
        __IO uint32_t reserved_3: 1;
        __I uint32_t reserved_2: 1;
        __IO uint32_t PROTCTL: 1;
        __I uint32_t reserved_1: 3;
        __IO uint32_t SRC_PER: 4;
        __IO uint32_t DEST_PER: 4;
        __IO uint32_t ExtendedSRC_PER1: 1;
        __IO uint32_t ExtendedDEST_PER1: 1;
        __IO uint32_t ExtendedSRC_PER2: 1;
        __IO uint32_t ExtendedDEST_PER2: 1;
        __IO uint32_t ExtendedSRC_PER3: 1;
        __IO uint32_t ExtendedDEST_PER3: 1;
        __I uint32_t reserved_0: 11;
    } b;
} GDMA_CFG_HIGHx_t;



/* 0x48
   19:0    R/W    SGI                 0x0
   31:20   R/W    SGC                 0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t SGI: 20;
        __IO uint32_t SGC: 12;
    } b;
} GDMA_SGR_LOW_t;


/* 0x4C
   15:0    R/W    SGSN                0x0
   31:16   R      reserved68          0x2
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t SGSN: 16;
        __I uint32_t reserved_0: 16;
    } b;
} GDMA_SGR_HIGH_t;




/* 0x50
   19:0    R/W    DSI                 0x0
   31:20   R      DSC                 0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t DSI: 20;
        __IO uint32_t DSC: 12;
    } b;
} GDMA_DSR_LOW_t;


/* 0x54
   15:0    R/W    DSSN                0x0
   31:16   R      reserved74          0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t DSSN: 16;
        __I uint32_t reserved_0: 16;
    } b;
} GDMA_DSR_HIGH_t;



/* 0x2E8
   31:0    R      STATUS              0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t STATUS: 32;
    } b;
} GDMA_StatusTfr_t;



/* 0x2F0
   31:0    R      STATUS              0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t STATUS: 32;
    } b;
} GDMA_StatusBlock_t;



/* 0x2F8
   31:0    R      STATUS              0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t STATUS: 32;
    } b;
} GDMA_StatusSrcTran_t;



/* 0x300
   31:0    R      STATUS              0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t STATUS: 32;
    } b;
} GDMA_StatusDstTran_t;



/* 0x308
   31:0    R      STATUS              0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t STATUS: 32;
    } b;
} GDMA_StatusErr_t;



/* 0x310
   7:0     R/W    INT_MASK_L          0x0
   15:8    W      INT_MASK_WE_L       0x0
   23:16   R/W    INT_MASK_H          0x0
   31:24   W      INT_MASK_WE_H       0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t INT_MASK_L: 8;
        __O uint32_t INT_MASK_WE_L: 8;
        __IO uint32_t INT_MASK_H: 8;
        __O uint32_t INT_MASK_WE_H: 8;
    } b;
} GDMA_MaskTfr_t;



/* 0x318
   7:0     R/W    INT_MASK_L          0x0
   15:8    W      INT_MASK_WE_L       0x0
   23:16   R/W    INT_MASK_H          0x0
   31:24   W      INT_MASK_WE_H       0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t INT_MASK_L: 8;
        __O uint32_t INT_MASK_WE_L: 8;
        __IO uint32_t INT_MASK_H: 8;
        __O uint32_t INT_MASK_WE_H: 8;
    } b;
} GDMA_MaskBlock_t;



/* 0x320
   7:0     R/W    INT_MASK_L          0x0
   15:8    W      INT_MASK_WE_L       0x0
   23:16   R/W    INT_MASK_H          0x0
   31:24   W      INT_MASK_WE_H       0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t INT_MASK_L: 8;
        __O uint32_t INT_MASK_WE_L: 8;
        __IO uint32_t INT_MASK_H: 8;
        __O uint32_t INT_MASK_WE_H: 8;
    } b;
} GDMA_MaskSrcTran_t;



/* 0x328
   7:0     R/W    INT_MASK_L          0x0
   15:8    W      INT_MASK_WE_L       0x0
   23:16   R/W    INT_MASK_H          0x0
   31:24   W      INT_MASK_WE_H       0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t INT_MASK_L: 8;
        __O uint32_t INT_MASK_WE_L: 8;
        __IO uint32_t INT_MASK_H: 8;
        __O uint32_t INT_MASK_WE_H: 8;
    } b;
} GDMA_MaskDstTran_t;



/* 0x330
   7:0     R/W    INT_MASK_L          0x0
   15:8    W      INT_MASK_WE_L       0x0
   23:16   R/W    INT_MASK_H          0x0
   31:24   W      INT_MASK_WE_H       0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t INT_MASK_L: 8;
        __O uint32_t INT_MASK_WE_L: 8;
        __IO uint32_t INT_MASK_H: 8;
        __O uint32_t INT_MASK_WE_H: 8;
    } b;
} GDMA_MaskErr_t;



/* 0x338
   31:0    W      CLEAR               0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __O uint32_t CLEAR: 32;
    } b;
} GDMA_ClearTfr_t;



/* 0x340
   31:0    W      CLEAR               0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __O uint32_t CLEAR: 32;
    } b;
} GDMA_ClearBlock_t;



/* 0x348
   31:0    W      CLEAR               0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __O uint32_t CLEAR: 32;
    } b;
} GDMA_ClearSrcTran_t;



/* 0x350
   31:0    W      CLEAR               0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __O uint32_t CLEAR: 32;
    } b;
} GDMA_ClearDstTran_t;



/* 0x358
   31:0    W      CLEAR               0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __O uint32_t CLEAR: 32;
    } b;
} GDMA_ClearErr_t;



/* 0x398
   0       R/W    DMAC_EN             0x0
   31:1    R      reserved130         0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t DMAC_EN: 1;
        __I uint32_t reserved_0: 31;
    } b;
} GDMA_DmaCfgReg_t;



/* 0x3A0
   7:0     R/W    CH_EN_L             0x0
   15:8    W      CH_EN_WE_L          0x0
   23:16   R/W    CH_EN_H             0x0
   31:24   W      CH_EN_WE_H          0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t CH_EN_L: 8;
        __O uint32_t CH_EN_WE_L: 8;
        __IO uint32_t CH_EN_H: 8;
        __O uint32_t CH_EN_WE_H: 8;
    } b;
} GDMA_ChEnReg_t;



/* 0x3B8
   7:0     R/W    OSR                 0x0
   15:8    R/W    OSW                 0x0
   31:16   R      Reserved            0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t OSR: 8;
        __IO uint32_t OSW: 8;
        __I uint32_t reserved_0: 16;
    } b;
} GDMA_DmaOsNum_t;


#ifdef  __cplusplus
}
#endif /* __cplusplus */
#endif /* RTL_GDMA_REG_H */
