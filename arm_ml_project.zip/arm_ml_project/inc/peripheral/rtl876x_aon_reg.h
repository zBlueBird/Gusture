#ifndef _RTL876X_AON_REG_H
#define _RTL876X_AON_REG_H
#include <stdint.h>

#ifdef  __cplusplus
extern "C" {
#endif /* __cplusplus */

/* Auto gen based on RLE1155_BTAON_fast_reg_PAGE0_20220628_v2.xlsx */
#define AON_0x0                             0x0
#define AON_DEBUG_PASSWORD                  0x4     // 0x4 ~ 0x13 store the debug password
#define AON_0x8                             0x8
#define AON_0xc                             0xc
#define AON_0x10                            0x10
#define AON_0x14                            0x14
#define AON_0x18                            0x18
#define AON_0x20                            0x20
#define AON_0xa8                            0xa8
#define AON_0xe8                            0xe8
#define AON_0xec                            0xec
#define AON_0xf4                            0xf4
#define AON_0x124                           0x124
#define AON_0x128                           0x128
#define AON_0x12c                           0x12c
#define AON_0x150                           0x150
#define AON_0x154                           0x154
#define AON_0x158                           0x158
#define AON_0x15c                           0x15c
#define AON_0x160                           0x160
#define AON_0x164                           0x164
#define AON_0x17C                           0x17C
#define AON_0x184                           0x184
#define AON_0x188                           0x188
#define AON_0x18C                           0x18C
#define AON_0x190                           0x190
#define AON_0x194                           0x194
#define AON_0x198                           0x198
#define AON_0x19C                           0x19C
#define AON_0x1A0                           0x1A0
#define AON_0x1A4                           0x1A4
#define AON_0x1A8                           0x1A8
#define AON_0x1AC                           0x1AC
#define AON_0x1B0                           0x1B0
#define AON_0x1B4                           0x1B4
#define AON_0x1B8                           0x1B8
#define AON_0x1BC                           0x1BC
#define AON_0x1C0                           0x1C0
#define AON_0x1C4                           0x1C4
#define AON_0x1CC                           0x1CC
#define AON_0x1D0                           0x1D0
#define AON_0x1D4                           0x1D4
#define AON_0x1D8                           0x1D8
#define AON_0x1DC                           0x1DC
#define AON_0x1E0                           0x1E0
#define AON_0x1E4                           0x1E4
#define AON_0x1E8                           0x1E8
#define AON_0x1EC                           0x1EC
#define AON_0x1F0                           0x1F0
#define AON_0x35c                           0x35c
#define AON_0x378                           0x378
#define AON_0x3A8                           0x3A8
#define AON_0x3AC                           0x3AC
#define AON_0x3F0                           0x3F0
#define AON_0x3F4                           0x3F4
/* 0x0      0x4000_0000
    15:00   rw  freg0                               16'h0
    31:16   rw  freg1                               16'h0
 */
typedef volatile union _AON_0x0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t freg0: 16;
        uint32_t freg1: 16;
    };
} AON_0x0_TYPE;

/* 0x4      0x4000_0004
    15:00   rw  freg2                               16'h0
    31:16   rw  freg3                               16'h0
 */
typedef volatile union _AON_DEBUG_PASSWORD_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t freg2: 16;
        uint32_t freg3: 16;
    };
} AON_DEBUG_PASSWORD_TYPE;

/* 0x8      0x4000_0008
    15:00   rw  freg4                               16'h0
    31:16   rw  freg5                               16'h0
 */
typedef volatile union _AON_0x8_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t freg4: 16;
        uint32_t freg5: 16;
    };
} AON_0x8_TYPE;

/* 0xc      0x4000_000c
    15:00   rw  freg6                               16'h0
    31:16   rw  freg7                               16'h0
 */
typedef volatile union _AON_0xc_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t freg6: 16;
        uint32_t freg7: 16;
    };
} AON_0xc_TYPE;

/* 0x10     0x4000_0010
    15:00   rw  freg8                               16'h0
    31:16   rw  freg9                               16'h0
 */
typedef volatile union _AON_0x10_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t freg8: 16;
        uint32_t freg9: 16;
    };
} AON_0x10_TYPE;

/* 0x14     0x4000_0014
    0       rw  is_password_mpl_cmd                 1'b0
    15:01   rw  freg10                              15'h0
    31:16   rw  freg11                              16'h0
 */
typedef volatile union _AON_0x14_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t is_password_mpl_cmd: 1;
        uint32_t freg10: 15;
        uint32_t freg11: 16;
    };
} AON_0x14_TYPE;

/* 0x18     0x4000_0018
    15:0    r   RSVD                                16'h0
    21:16   rw  RCAL[5:0]                           6'b100000
    26:22   rw  XTAL32K_Reserved15[10:6]            5'b00000
    27      w1o reg_aon_w1o_clk_flash_dis           1'b0
    31:28   w1o XTAL32K_Reserved15[15:12]           4'h0
 */
typedef volatile union _AON_0x18_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD: 16;
        uint32_t RCAL_5_0: 6;
        uint32_t XTAL32K_Reserved15_10_6: 5;
        uint32_t reg_aon_w1o_clk_flash_dis: 1;
        uint32_t XTAL32K_Reserved15_15_12: 4;
    };
} AON_0x18_TYPE;

/* 0x20     0x4000_0020
    1:0     r   RSVD_2                              2'h0
    2       w1o reg_dsp_flash_prot                  1'b0
    3       w1o reg_aon_hwspi_en_rp                 1'b0
    4       rw  reg_aon_hwspi_en                    1'b0
    5       w1o reg_aon_debug_port_wp               1'b0
    6       rw  reg_aon_debug_port                  1'b1
    7       w1o reg_aon_dbg_boot_dis                1'b0
    15:08   w1o XTAL32K_Reserved16[13:6]            8'h0
    31:16   r   RSVD                                16'h0
 */
typedef volatile union _AON_0x20_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_2: 2;
        uint32_t reg_dsp_flash_prot: 1;
        uint32_t reg_aon_hwspi_en_rp: 1;
        uint32_t reg_aon_hwspi_en: 1;
        uint32_t reg_aon_debug_port_wp: 1;
        uint32_t reg_aon_debug_port: 1;
        uint32_t reg_aon_dbg_boot_dis: 1;
        uint32_t XTAL32K_Reserved16_13_6: 8;
        uint32_t RSVD: 16;
    };
} AON_0x20_TYPE;

/* 0xa8     0x4000_00a8
    02:00   rw  XTAL_FREQ_SEL                       3'h5
    3       rw  AAC_SEL                             1'b0
    09:04   rw  AAC_GM1                             6'h1f
    15:10   rw  AAC_GM                              6'h1f
    16      rw  ADDA_SW_LDO2PWRCUT                  1'b0
    17      rw  ADDA_POW_LDO_VREF                   1'b0
    18      rw  ADDA_POW_LDO_OP                     1'b1
    19      rw  ADDA_LDO_VPULSE                     1'b1
    24:20   r   RSVD_2                              5'h0
    25      rw  U11_POW_BC_V33                      1'b0
    26      rw  U11_POW_USB_V33                     1'b0
    27      rw  U11_en_pc_mode                      1'b0
    28      r   RSVD                                1'b0
    29      rw  U11_POW_BC_L                        1'b0
    30      rw  ISO_UA2USB                          1'b1
    31      rw  RCAL_32K_SEL                        1'b0
 */
typedef volatile union _AON_0xa8_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t XTAL_FREQ_SEL: 3;
        uint32_t AAC_SEL: 1;
        uint32_t AAC_GM1: 6;
        uint32_t AAC_GM: 6;
        uint32_t ADDA_SW_LDO2PWRCUT: 1;
        uint32_t ADDA_POW_LDO_VREF: 1;
        uint32_t ADDA_POW_LDO_OP: 1;
        uint32_t ADDA_LDO_VPULSE: 1;
        uint32_t RSVD_2: 5;
        uint32_t U11_POW_BC_V33: 1;
        uint32_t U11_POW_USB_V33: 1;
        uint32_t U11_en_pc_mode: 1;
        uint32_t RSVD: 1;
        uint32_t U11_POW_BC_L: 1;
        uint32_t ISO_UA2USB: 1;
        uint32_t RCAL_32K_SEL: 1;
    };
} AON_0xa8_TYPE;

/* 0xe8     0x4000_00e8
    15:0    r   RSVD_2                              16'h0
    16      rw  MCLK2_EN                            1'b0
    17      rw  MCLK2_DIV_SEL                       1'b0
    19:18   r   RSVD                                2'h0
    22:20   rw  MCLK2_SRC_SEL                       3'h0
    23      rw  MCLK2_DIV_ONE                       1'b0
    31:24   rw  MCLK2_DIV_SETTING                   8'h0
 */
typedef volatile union _AON_0xe8_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_2: 16;
        uint32_t MCLK2_EN: 1;
        uint32_t MCLK2_DIV_SEL: 1;
        uint32_t RSVD: 2;
        uint32_t MCLK2_SRC_SEL: 3;
        uint32_t MCLK2_DIV_ONE: 1;
        uint32_t MCLK2_DIV_SETTING: 8;
    };
} AON_0xe8_TYPE;

/* 0xec     0x4000_00ec
    15:0    r   RSVD_5                              9'h0
    18:16   r   RSVD_4                              3'h0
    19      rw  usb_wakeup_sel                      1'b1
    27:20   r   RSVD_3                              8'h0
    28      r   reg_aon_wdt_reset                   1'b0
    29      r   RSVD_2                              1'b0
    30      rw  r_aon_cko2_mux_cg_en                1'b1
    31      r   RSVD                                1'b0
 */
typedef volatile union _AON_0xec_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_5: 16;
        uint32_t RSVD_4: 3;
        uint32_t usb_wakeup_sel: 1;
        uint32_t RSVD_3: 8;
        uint32_t reg_aon_wdt_reset: 1;
        uint32_t RSVD_2: 1;
        uint32_t r_aon_cko2_mux_cg_en: 1;
        uint32_t RSVD: 1;
    };
} AON_0xec_TYPE;

/* 0xf4     0x4000_00f4
    0       rw  SEL_32K_XTAL                        1'b0
    1       rw  SEL_32K_LP                          1'b0
    2       rw  BRWN_OUT_GATING                     1'b0
    7:3     r   RSVD_2                              5'h0
    8       rw  LOP_DIS_BR_NWAKE                    1'b1
    10:9    r   RSVD                                2'h0
    15:11   rw  AON_DBG_SEL                         5'h0
    19:16   rw  DUMMY_2                             4'b0
    23:20   rw  DUMMY                               4'b0
    26:24   rw  AON_DBG_C_KOUT_BUCK_SEL             3'b0
    31:27   rw  AON_DBG_DUMMY                       5'h0
 */
typedef volatile union _AON_0xf4_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SEL_32K_XTAL: 1;
        uint32_t SEL_32K_LP: 1;
        uint32_t BRWN_OUT_GATING: 1;
        uint32_t RSVD_2: 5;
        uint32_t LOP_DIS_BR_NWAKE: 1;
        uint32_t RSVD: 2;
        uint32_t AON_DBG_SEL: 5;
        uint32_t DUMMY_2: 4;
        uint32_t DUMMY: 4;
        uint32_t AON_DBG_C_KOUT_BUCK_SEL: 3;
        uint32_t AON_DBG_DUMMY: 5;
    };
} AON_0xf4_TYPE;

/* 0x124    0x4000_0124
    4:0     r   RSVD_8                              3'b0
    5       w1c DUMMY0_STS                          1'b1
    6       w1c DUMMY1_STS                          1'b1
    7       w1c DUMMY2_STS                          1'b1
    8       w1c AONWDT_STS                          1'b1
    9       w1c COREWDT_STS                         1'b1
    10      w1c DUMMY3_STS                          1'b1
    11      w1c DUMMY4_STS                          1'b1
    12      w1c DUMMY5_STS                          1'b1
    15:13   r   RSVD_7                              3'h0
    19:16   r   RSVD_6                              4'h0
    20      r   RSVD_5                              1'b0
    21      r   RSVD_4                              1'b0
    22      w1c USB_STS                             1'b1
    23      w1c DUMMY6_STS                          1'b1
    24      w1c DUMMY7_STS                          1'b1
    25      w1c DUMMY8_STS                          1'b1
    26      r   RSVD_3                              1'b0
    27      r   RSVD_2                              1'b0
    28      w1c VAD_STS                             1'b1
    29      w1c VADBUF_STS                          1'b1
    30      w1c DUMMY9_STS                          1'b1
    31      r   RSVD                                1'b0
 */
typedef volatile union _AON_0x124_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_8: 5;
        uint32_t DUMMY0_STS: 1;
        uint32_t DUMMY1_STS: 1;
        uint32_t DUMMY2_STS: 1;
        uint32_t AONWDT_STS: 1;
        uint32_t COREWDT_STS: 1;
        uint32_t DUMMY3_STS: 1;
        uint32_t DUMMY4_STS: 1;
        uint32_t DUMMY5_STS: 1;
        uint32_t RSVD_7: 3;
        uint32_t RSVD_6: 4;
        uint32_t RSVD_5: 1;
        uint32_t RSVD_4: 1;
        uint32_t USB_STS: 1;
        uint32_t DUMMY6_STS: 1;
        uint32_t DUMMY7_STS: 1;
        uint32_t DUMMY8_STS: 1;
        uint32_t RSVD_3: 1;
        uint32_t RSVD_2: 1;
        uint32_t VAD_STS: 1;
        uint32_t VADBUF_STS: 1;
        uint32_t DUMMY9_STS: 1;
        uint32_t RSVD: 1;
    };
} AON_0x124_TYPE;

/* 0x128    0x4000_0128
    15:0    r   RSVD_2                              16'h0
    25:16   r   RSVD                                10'h0
    26      rw  MFB_WKPOL                           1'b0
    27      rw  MFB_WKEN                            1'b0
    28      rw  BAT_WKPOL                           1'b0
    29      rw  BAT_WKEN                            1'b0
    30      rw  ADP_WKPOL                           1'b0
    31      rw  ADP_WKEN                            1'b0
 */
typedef volatile union _AON_0x128_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_2: 16;
        uint32_t RSVD: 10;
        uint32_t MFB_WKPOL: 1;
        uint32_t MFB_WKEN: 1;
        uint32_t BAT_WKPOL: 1;
        uint32_t BAT_WKEN: 1;
        uint32_t ADP_WKPOL: 1;
        uint32_t ADP_WKEN: 1;
    };
} AON_0x128_TYPE;

/* 0x12c    0x4000_012c
    5:0     r   RSVD_4                              6'h0
    6       rw  brwn_int_en                         1'b0
    7       rw  brwn_int_pol                        1'b1
    8       w1c brwn_det_intr                       1'b1
    9       rw  wakeup_blk_ind                      1'b1
    10      r   PAD_P2_0_I                          1'b0
    11      r   RSVD_3                              1'b0
    15:12   r   RSVD_2                              4'h0
    31:16   r   RSVD                                16'h0
 */
typedef volatile union _AON_0x12c_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_4: 6;
        uint32_t brwn_int_en: 1;
        uint32_t brwn_int_pol: 1;
        uint32_t brwn_det_intr: 1;
        uint32_t wakeup_blk_ind: 1;
        uint32_t PAD_P2_0_I: 1;
        uint32_t RSVD_3: 1;
        uint32_t RSVD_2: 4;
        uint32_t RSVD: 16;
    };
} AON_0x12c_TYPE;

/* 0x150    0x4000_0150
    0       rw  SEL_32K_SDM_tic_KM4                 1'h0
    1       rw  SEL_32K_GPIO_tic_KM4                1'h0
    2       rw  SEL_32K_LP_tic_KM4                  1'h0
    3       rw  SEL_32K_XTAL_tic_KM4                1'h0
    4       rw  SEL_32K_SDM_tic_KM0                 1'h0
    5       rw  SEL_32K_GPIO_tic_KM0                1'h0
    6       rw  SEL_32K_LP_tic_KM0                  1'h0
    7       rw  SEL_32K_XTAL_tic_KM0                1'h0
    8       rw  SEL_32K_SDM_rtc_pf                  1'h0
    9       rw  SEL_32K_GPIO_rtc_pf                 1'h0
    10      rw  SEL_32K_LP_rtc_pf                   1'h0
    11      rw  SEL_32K_XTAL_rtc_pf                 1'h0
    12      rw  SEL_32K_SDM_simo                    1'h0
    13      rw  SEL_32K_GPIO_simo                   1'h0
    14      rw  SEL_32K_LP_simo                     1'h0
    15      rw  SEL_32K_XTAL_simo                   1'h1
    31:16   r   RSVD                                16'h0
 */
typedef volatile union _AON_0x150_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SEL_32K_SDM_tic_KM4: 1;
        uint32_t SEL_32K_GPIO_tic_KM4: 1;
        uint32_t SEL_32K_LP_tic_KM4: 1;
        uint32_t SEL_32K_XTAL_tic_KM4: 1;
        uint32_t SEL_32K_SDM_tic_KM0: 1;
        uint32_t SEL_32K_GPIO_tic_KM0: 1;
        uint32_t SEL_32K_LP_tic_KM0: 1;
        uint32_t SEL_32K_XTAL_tic_KM0: 1;
        uint32_t SEL_32K_SDM_rtc_pf: 1;
        uint32_t SEL_32K_GPIO_rtc_pf: 1;
        uint32_t SEL_32K_LP_rtc_pf: 1;
        uint32_t SEL_32K_XTAL_rtc_pf: 1;
        uint32_t SEL_32K_SDM_simo: 1;
        uint32_t SEL_32K_GPIO_simo: 1;
        uint32_t SEL_32K_LP_simo: 1;
        uint32_t SEL_32K_XTAL_simo: 1;
        uint32_t RSVD: 16;
    };
} AON_0x150_TYPE;

/* 0x154    0x4000_0154
    5:0     rw  lp_xtal_ppm_err_lp                  8'h0
    6       rw  lp_xtal_ppm_plus_lp                 8'h0
    7       rw  lp_xtal_ppm_hy_hw                   8'h0
    10:08   rw  lp_xtal_sel                         3'h0
    13:11   rw  lp_xtal_sel_prediv                  3'h0
    15:14   r   RSVD_3                              2'h0
    21:16   rw  lp_xtal_ppm_err_fw                  6'h0
    22      rw  lp_xtal_ppm_plus_fw                 1'h0
    23      r   RSVD_2                              1'b0
    29:24   rw  lp_xtal_ppm_err_nm                  8'h0
    30      rw  lp_xtal_ppm_plus_nm                 8'h0
    31      r   RSVD                                8'h0
 */
typedef volatile union _AON_0x154_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t lp_xtal_ppm_err_lp: 6;
        uint32_t lp_xtal_ppm_plus_lp: 1;
        uint32_t lp_xtal_ppm_hy_hw: 1;
        uint32_t lp_xtal_sel: 3;
        uint32_t lp_xtal_sel_prediv: 3;
        uint32_t RSVD_3: 2;
        uint32_t lp_xtal_ppm_err_fw: 6;
        uint32_t lp_xtal_ppm_plus_fw: 1;
        uint32_t RSVD_2: 1;
        uint32_t lp_xtal_ppm_err_nm: 6;
        uint32_t lp_xtal_ppm_plus_nm: 1;
        uint32_t RSVD: 1;
    };
} AON_0x154_TYPE;

/* 0x158    0x4000_0158
    0       rw  SEL_32K_SDM_go                      1'b0
    1       rw  SEL_32K_GPIO_go                     1'b0
    2       rw  SEL_32K_LP_go                       1'b0
    3       rw  SEL_32K_XTAL_go                     1'b0
    4       r   RSVD_6                              1'b0
    5       r   RSVD_5                              1'b0
    6       r   RSVD_4                              1'b0
    7       r   RSVD_3                              1'b0
    8       rw  SEL_32K_SDM_bt                      1'b0
    9       rw  SEL_32K_GPIO_bt                     1'b0
    10      rw  SEL_32K_LP_bt                       1'b0
    11      rw  SEL_32K_XTAL_bt                     1'b0
    12      rw  SEL_32K_SDM_rtc                     1'b0
    13      rw  SEL_32K_GPIO_rtc                    1'b0
    14      rw  SEL_32K_LP_rtc                      1'b0
    15      rw  SEL_32K_XTAL_rtc                    1'b0
    16      rw  SEL_32K_SDM_qd                      1'b0
    17      rw  SEL_32K_GPIO_qd                     1'b0
    18      rw  SEL_32K_LP_qd                       1'b0
    19      rw  SEL_32K_XTAL_qd                     1'b0
    20      rw  SEL_32K_SDM_wdg                     1'b0
    21      rw  SEL_32K_GPIO_wdg                    1'b0
    22      rw  SEL_32K_LP_wdg                      1'b0
    23      rw  SEL_32K_XTAL_wdg                    1'b0
    27:24   r   RSVD_2                              4'h0
    31:28   r   RSVD                                4'h0
 */
typedef volatile union _AON_0x158_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SEL_32K_SDM_go: 1;
        uint32_t SEL_32K_GPIO_go: 1;
        uint32_t SEL_32K_LP_go: 1;
        uint32_t SEL_32K_XTAL_go: 1;
        uint32_t RSVD_6: 1;
        uint32_t RSVD_5: 1;
        uint32_t RSVD_4: 1;
        uint32_t RSVD_3: 1;
        uint32_t SEL_32K_SDM_bt: 1;
        uint32_t SEL_32K_GPIO_bt: 1;
        uint32_t SEL_32K_LP_bt: 1;
        uint32_t SEL_32K_XTAL_bt: 1;
        uint32_t SEL_32K_SDM_rtc: 1;
        uint32_t SEL_32K_GPIO_rtc: 1;
        uint32_t SEL_32K_LP_rtc: 1;
        uint32_t SEL_32K_XTAL_rtc: 1;
        uint32_t SEL_32K_SDM_qd: 1;
        uint32_t SEL_32K_GPIO_qd: 1;
        uint32_t SEL_32K_LP_qd: 1;
        uint32_t SEL_32K_XTAL_qd: 1;
        uint32_t SEL_32K_SDM_wdg: 1;
        uint32_t SEL_32K_GPIO_wdg: 1;
        uint32_t SEL_32K_LP_wdg: 1;
        uint32_t SEL_32K_XTAL_wdg: 1;
        uint32_t RSVD_2: 4;
        uint32_t RSVD: 4;
    };
} AON_0x158_TYPE;

/* 0x15c    0x4000_015c
    15:0    r   RSVD_2                              16'h0
    16      rw  USB_WKPOL                           1'b0
    17      rw  USB_WKEN                            1'b0
    18      rw  VAD_WKPOL                           1'b0
    19      rw  VAD_WKEN                            1'b0
    20      rw  VADBUF_WKPOL                        1'b0
    21      rw  VADBUF_WKEN                         1'b0
    22      rw  ADSP_WKPOL                          1'b0
    23      rw  ADSP_WKEN                           1'b0
    31:24   r   RSVD                                8'h0
 */
typedef volatile union _AON_0x15c_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_2: 16;
        uint32_t USB_WKPOL: 1;
        uint32_t USB_WKEN: 1;
        uint32_t VAD_WKPOL: 1;
        uint32_t VAD_WKEN: 1;
        uint32_t VADBUF_WKPOL: 1;
        uint32_t VADBUF_WKEN: 1;
        uint32_t ADSP_WKPOL: 1;
        uint32_t ADSP_WKEN: 1;
        uint32_t RSVD: 8;
    };
} AON_0x15c_TYPE;

/* 0x160    0x4000_0160
    7:0     r   RSVD_4                              8'h0
    8       rw  SEL_32K_SDM                         1'b0
    9       rw  SEL_32K_GPIO                        1'b0
    10      rw  SEL_40M_OSC                         1'b1
    11      r   RSVD_3                              1'b0
    12      rw  en_gpio_32k                         1'b0
    15:13   r   RSVD_2                              3'b000
    31:16   r   RSVD                                16'h0
 */
typedef volatile union _AON_0x160_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_4: 8;
        uint32_t SEL_32K_SDM: 1;
        uint32_t SEL_32K_GPIO: 1;
        uint32_t SEL_40M_OSC: 1;
        uint32_t RSVD_3: 1;
        uint32_t en_gpio_32k: 1;
        uint32_t RSVD_2: 3;
        uint32_t RSVD: 16;
    };
} AON_0x160_TYPE;

/* 0x164    0x4000_0164
    01:00   r   RSVD_3                              2'b00
    2       rw  r_PMUX_SCAN_FT_2_EN                 1'b0
    3       rw  r_PMUX_SCAN_FT_EN                   1'b0
    4       rw  r_PMUX_SCAN_FT_2_EN_src             1'b0
    5       rw  r_PMUX_SCAN_FT_EN_src               1'b0
    6       rw  r_PMUX_SCAN_MODE_EN                 1'b0
    7       rw  r_PMUX_SCAN_VSEL                    1'b1
    15:8    r   RSVD_2                              9'h0
    20:16   r   XPDCK_VREF_OUT                      5'b11111
    21      r   XPDCK_READY                         1'b0
    22      r   XPDCK_BUSY                          1'b0
    23      r   RSVD                                1'b0
    28:24   r   XTAL_PDCK_LP                        5'b00000
    29      r   XTAL_PDCK_OK                        1'b0
    30      r   XTAL_PDCK_BUSY                      1'b0
    31      rw  xtal_pdck_rslt_latch                1'b0
 */
typedef volatile union _AON_0x164_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_3: 2;
        uint32_t r_PMUX_SCAN_FT_2_EN: 1;
        uint32_t r_PMUX_SCAN_FT_EN: 1;
        uint32_t r_PMUX_SCAN_FT_2_EN_src: 1;
        uint32_t r_PMUX_SCAN_FT_EN_src: 1;
        uint32_t r_PMUX_SCAN_MODE_EN: 1;
        uint32_t r_PMUX_SCAN_VSEL: 1;
        uint32_t RSVD_2: 8;
        uint32_t XPDCK_VREF_OUT: 5;
        uint32_t XPDCK_READY: 1;
        uint32_t XPDCK_BUSY: 1;
        uint32_t RSVD: 1;
        uint32_t XTAL_PDCK_LP: 5;
        uint32_t XTAL_PDCK_OK: 1;
        uint32_t XTAL_PDCK_BUSY: 1;
        uint32_t xtal_pdck_rslt_latch: 1;
    };
} AON_0x164_TYPE;

/* 0x17C    0x4000_017c
    15:0    r   RSVD_3                              16'h0
    16      w1o DUMMY_3                             1'b0
    17      w1o DUMMY_2                             1'b0
    23:18   rw  DUMMY                               6'h0
    27:24   r   RSVD_2                              4'h0
    29:28   w1o reg_aon_w1o_dbg_dis_range           2'h0
    31:30   r   RSVD                                2'h0
 */
typedef volatile union _AON_0x17C_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_3: 16;
        uint32_t DUMMY_3: 1;
        uint32_t DUMMY_2: 1;
        uint32_t DUMMY: 6;
        uint32_t RSVD_2: 4;
        uint32_t reg_aon_w1o_dbg_dis_range: 2;
        uint32_t RSVD: 2;
    };
} AON_0x17C_TYPE;

/* 0x184    0x4000_0184
    0       rw  is_km0_sys_patch_valid              1'b0
    1       rw  is_km0_stack_patch_valid            1'b0
    2       rw  is_lowerstack_init_ready            1'b0
    3       rw  is_km0_enter_shutdown_mode_ready    1'b0
    4       rw  is_airplane_mode                    1'b0
    06:05   rw  grab_pad_resources                  2'b0
    08:07   rw  km0_log_mode                        2'b0
    15:09   rw  reg_aon_gpr_0_rsvd                  7'h0
    31:16   rw  reg_aon_gpr_1                       16'h0
 */
typedef volatile union _AON_0x184_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t is_km0_sys_patch_valid: 1;
        uint32_t is_km0_stack_patch_valid: 1;
        uint32_t is_lowerstack_init_ready: 1;
        uint32_t is_km0_enter_shutdown_mode_ready: 1;
        uint32_t is_airplane_mode: 1;
        uint32_t grab_pad_resources: 2;
        uint32_t km0_log_mode: 2;
        uint32_t reg_aon_gpr_0_rsvd: 7;
        uint32_t reg_aon_gpr_1: 16;
    };
} AON_0x184_TYPE;

/* 0x188    0x4000_0188
    31:00   rw  random_number                       32'h0
 */
typedef volatile union _AON_0x188_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t random_number;
    };
} AON_0x188_TYPE;

/* 0x18C    0x4000_018c
    31:00   rw  km0_occd_start_addr                 32'h0
 */
typedef volatile union _AON_0x18C_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t km0_occd_start_addr;
    };
} AON_0x18C_TYPE;

/* 0x190    0x4000_0190
    15:00   rw  km0_syspatch_start_offset           16'h0
    31:16   rw  km0_stackpatch_start_offset         16'h0
 */
typedef volatile union _AON_0x190_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t km0_syspatch_start_offset: 16;
        uint32_t km0_stackpatch_start_offset: 16;
    };
} AON_0x190_TYPE;

/* 0x194    0x4000_0194
    0       rw  is_kr0_pmc_patch_valid            1'b0
    15:01   rw  reg_aon_gpr_8_rsvd                  15'h0
    31:16   rw  kr0_pmc_patch_start_offset        16'h0
 */
typedef volatile union _AON_0x194_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t is_kr0_pmc_patch_valid: 1;
        uint32_t reg_aon_gpr_8_rsvd: 15;
        uint32_t kr0_pmc_patch_start_offset: 16;
    };
} AON_0x194_TYPE;

/* 0x198    0x4000_0198
    31:00   rw  kr0_occd_start_addr                 32'h0
 */
typedef volatile union _AON_0x198_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t kr0_occd_start_addr;
    };
} AON_0x198_TYPE;

/* 0x19C    0x4000_019c
    15:00   rw  reg_aon_gpr_12                      16'h0
    31:16   rw  reg_aon_gpr_13                      16'h0
 */
typedef volatile union _AON_0x19C_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_aon_gpr_12: 16;
        uint32_t reg_aon_gpr_13: 16;
    };
} AON_0x19C_TYPE;

/* 0x1A0    0x4000_01a0
    15:00   rw  reg_aon_gpr_14                      16'h0
    16      rw  gpio_wkup_event_latch               1'b0
    17      rw  lpcomp0_wkup_event_latch            1'b0
    18      rw  lpcomp1_wkup_event_latch            1'b0
    19      rw  qdec_wkup_event_latch               1'b0
    20      rw  vadbuf_wkup_event_latch             1'b0
    21      rw  vad_wkup_event_latch                1'b0
    22      rw  usb_wkup_event_latch                1'b0
    23      rw  rtc_user_wkup_event_latch           1'b0
    24      rw  rtc_pf_wkup_event_latch             1'b0
    31:25   rw  reg_aon_gpr_15[15:9]                7'h0
 */
typedef volatile union _AON_0x1A0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_aon_gpr_14: 16;
        uint32_t gpio_wkup_event_latch: 1;
        uint32_t lpcomp0_wkup_event_latch: 1;
        uint32_t lpcomp1_wkup_event_latch: 1;
        uint32_t qdec_wkup_event_latch: 1;
        uint32_t vadbuf_wkup_event_latch: 1;
        uint32_t vad_wkup_event_latch: 1;
        uint32_t usb_wkup_event_latch: 1;
        uint32_t rtc_user_wkup_event_latch: 1;
        uint32_t rtc_pf_wkup_event_latch: 1;
        uint32_t reg_aon_gpr_15_15_9: 7;
    };
} AON_0x1A0_TYPE;

/* 0x1A4    0x4000_01a4
    12:0    w1o reg_aon_w1o_gpr_0                   13'h0
    13:13   w1o reg_aon_w1o_adsp_ahb_r_dis          1'b0
    14:14   w1o reg_aon_w1o_pon_rst2core_en         1'b0
    15:15   w1o reg_aon_w1o_sniff_half_slot_dis     1'b0
    31:16   w1o reg_aon_w1o_gpr_1                   16'h0
 */
typedef volatile union _AON_0x1A4_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_aon_w1o_gpr_0: 13;
        uint32_t reg_aon_w1o_adsp_ahb_r_dis: 1;
        uint32_t reg_aon_w1o_pon_rst2core_en: 1;
        uint32_t reg_aon_w1o_sniff_half_slot_dis: 1;
        uint32_t reg_aon_w1o_gpr_1: 16;
    };
} AON_0x1A4_TYPE;

/* 0x1A8    0x4000_01a8
    0       w1o is_otp_invalid                      1'b0
    1       w1o is_enable_otp_read_protect          1'b0
    2       w1o is_enable_otp_write_protect         1'b0
    3       w1o is_hw_aes_dma_mode                  1'b0
    4       w1o is_debug_password_invalid           1'b0
    5       w1o is_disable_set_reg_by_otp           1'b0
    6       w1o is_enable_image_auth_when_resume    1'b0
    7       w1o is_enable_pmc_platform              1'b0
    8       w1o is_enable_bt_platform               1'b0
    15:09   w1o reg_aon_w1o_gpr_2                   7'h0
    31:16   w1o reg_aon_w1o_gpr_3                   16'h0
 */
typedef volatile union _AON_0x1A8_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t is_otp_invalid: 1;
        uint32_t is_enable_otp_read_protect: 1;
        uint32_t is_enable_otp_write_protect: 1;
        uint32_t is_hw_aes_dma_mode: 1;
        uint32_t is_debug_password_invalid: 1;
        uint32_t is_disable_set_reg_by_otp: 1;
        uint32_t is_enable_image_auth_when_resume: 1;
        uint32_t is_enable_pmc_platform: 1;
        uint32_t is_enable_bt_platform: 1;
        uint32_t reg_aon_w1o_gpr_2: 8;
        uint32_t reg_aon_w1o_gpr_3: 16;
    };
} AON_0x1A8_TYPE;

/* 0x1AC    0x4000_01ac
    0       w1o is_disable_hci_read_chip_info       1'b0
    1       w1o is_disable_hci_mac_rf_access        1'b0
    2       w1o is_disable_hci_wifi_coexist_func    1'b0
    3       w1o is_disable_hci_set_uart_baudrate    1'b0
    4       w1o is_disable_hci_rf_dbg_func          1'b0
    5       w1o is_disable_hci_bt_extension         1'b0
    6       w1o is_disable_hci_bt_dbg_func          1'b0
    7       w1o is_disable_hci_bt_test              1'b0
    8       w1o is_disable_hci_rf_test              1'b0
    9       w1o is_disable_mpl_ram_patch            1'b0
    10      w1o is_disable_mpl_flash_access         1'b0
    11      w1o is_disable_mpl_system_access        1'b0
    12      w1o is_disable_mpl_otp_access           1'b0
    15:13   w1o reg_aon_w1o_gpr_4                   3'h0
    31:16   w1o reg_aon_w1o_gpr_5                   16'h0
 */
typedef volatile union _AON_0x1AC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t is_disable_hci_read_chip_info: 1;
        uint32_t is_disable_hci_mac_rf_access: 1;
        uint32_t is_disable_hci_wifi_coexist_func: 1;
        uint32_t is_disable_hci_set_uart_baudrate: 1;
        uint32_t is_disable_hci_rf_dbg_func: 1;
        uint32_t is_disable_hci_bt_extension: 1;
        uint32_t is_disable_hci_bt_dbg_func: 1;
        uint32_t is_disable_hci_bt_test: 1;
        uint32_t is_disable_hci_rf_test: 1;
        uint32_t is_disable_mpl_ram_patch: 1;
        uint32_t is_disable_mpl_flash_access: 1;
        uint32_t is_disable_mpl_system_access: 1;
        uint32_t is_disable_mpl_otp_access: 1;
        uint32_t reg_aon_w1o_gpr_4: 3;
        uint32_t reg_aon_w1o_gpr_5: 16;
    };
} AON_0x1AC_TYPE;

/* 0x1B0    0x4000_01b0
    15:00   w1o reg_aon_w1o_gpr_6                   16'h0
    31:16   w1o reg_aon_w1o_gpr_7                   16'h0
 */
typedef volatile union _AON_0x1B0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_aon_w1o_gpr_6: 16;
        uint32_t reg_aon_w1o_gpr_7: 16;
    };
} AON_0x1B0_TYPE;

/* 0x1B4    0x4000_01b4
    15:00   w1o reg_aon_w1o_gpr_8                   16'h0
    31:16   w1o reg_aon_w1o_gpr_9                   16'h0
 */
typedef volatile union _AON_0x1B4_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_aon_w1o_gpr_8: 16;
        uint32_t reg_aon_w1o_gpr_9: 16;
    };
} AON_0x1B4_TYPE;

/* 0x1B8    0x4000_01b8
    15:00   w1o reg_aon_w1o_gpr_10                  16'h0
    31:16   w1o reg_aon_w1o_gpr_11                  16'h0
 */
typedef volatile union _AON_0x1B8_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_aon_w1o_gpr_10: 16;
        uint32_t reg_aon_w1o_gpr_11: 16;
    };
} AON_0x1B8_TYPE;

/* 0x1BC    0x4000_01bc
    15:00   w1o reg_aon_w1o_gpr_12                  16'h0
    31:16   w1o reg_aon_w1o_gpr_13                  16'h0
 */
typedef volatile union _AON_0x1BC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_aon_w1o_gpr_12: 16;
        uint32_t reg_aon_w1o_gpr_13: 16;
    };
} AON_0x1BC_TYPE;

/* 0x1C0    0x4000_01c0
    15:00   w1o reg_aon_w1o_gpr_14                  16'h0
    23:16   w1o reg_aon_w1o_gpr_15[7:0]             8'h0
    24      w1o reg_aon_w1o_pa_func_dis             1'b0
    25      w1o reg_aon_w1o_cis_func_dis            1'b0
    26      w1o reg_aon_w1o_bis_func_dis            1'b0
    27      w1o reg_aon_w1o_gpr_15[11]              1'b0
    31:28   w1o reg_aon_w1o_gpr_15[15:12]           4'h0
 */
typedef volatile union _AON_0x1C0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_aon_w1o_gpr_14: 16;
        uint32_t reg_aon_w1o_gpr_15_7_0: 8;
        uint32_t reg_aon_w1o_pa_func_dis: 1;
        uint32_t reg_aon_w1o_cis_func_dis: 1;
        uint32_t reg_aon_w1o_bis_func_dis: 1;
        uint32_t reg_aon_w1o_gpr_15_11: 1;
        uint32_t reg_aon_w1o_gpr_15_15_12: 4;
    };
} AON_0x1C0_TYPE;

/* 0x1C4    0x4000_01c4
    0       w1o reg_aon_w1o_wpgpr_lock0             1'b0
    1       w1o reg_aon_w1o_wpgpr_lock1             1'b0
    2       w1o reg_aon_w1o_wpgpr_lock2             1'b0
    3       w1o reg_aon_w1o_wpgpr_lock3             1'b0
    4       w1o reg_aon_w1o_wpgpr_lock4             1'b0
    5       w1o reg_aon_w1o_wpgpr_lock5             1'b0
    6       w1o reg_aon_w1o_wpgpr_lock6             1'b0
    7       w1o reg_aon_w1o_wpgpr_lock7             1'b0
    8       w1o reg_aon_w1o_xo_lock                 1'b0
    9       w1o reg_aon_w1o_aes_out_hidden_lock     1'b0
    10      rw  reg_aon_pll1_cp_dis_by_xtal         1'b0
    11      rw  reg_aon_pll2_cp_dis_by_xtal         1'b0
    12      rw  reg_aon_pll1_cp_dis_fw              1'b0
    13      rw  reg_aon_pll2_cp_dis_fw              1'b0
    14      rw  reg_aon_pll3_cp_dis_by_xtal         1'b0
    15      rw  reg_aon_pll3_cp_dis_fw              1'b0
    16      rw  reg_aon_pll4_cp_dis_by_xtal         1'b0
    17      rw  reg_aon_pll4_cp_dis_fw              1'b0
    31:18   rw  RSVD                                14'h0
 */
typedef volatile union _AON_0x1C4_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_aon_w1o_wpgpr_lock0: 1;
        uint32_t reg_aon_w1o_wpgpr_lock1: 1;
        uint32_t reg_aon_w1o_wpgpr_lock2: 1;
        uint32_t reg_aon_w1o_wpgpr_lock3: 1;
        uint32_t reg_aon_w1o_wpgpr_lock4: 1;
        uint32_t reg_aon_w1o_wpgpr_lock5: 1;
        uint32_t reg_aon_w1o_wpgpr_lock6: 1;
        uint32_t reg_aon_w1o_wpgpr_lock7: 1;
        uint32_t reg_aon_w1o_xo_lock: 1;
        uint32_t reg_aon_w1o_aes_out_hidden_lock: 1;
        uint32_t reg_aon_pll1_cp_dis_by_xtal: 1;
        uint32_t reg_aon_pll2_cp_dis_by_xtal: 1;
        uint32_t reg_aon_pll1_cp_dis_fw: 1;
        uint32_t reg_aon_pll2_cp_dis_fw: 1;
        uint32_t reg_aon_pll3_cp_dis_by_xtal: 1;
        uint32_t reg_aon_pll3_cp_dis_fw: 1;
        uint32_t reg_aon_pll4_cp_dis_by_xtal: 1;
        uint32_t reg_aon_pll4_cp_dis_fw: 1;
        uint32_t RSVD: 14;
    };
} AON_0x1C4_TYPE;

/* 0x1CC    0x4000_01cc
    15:0    rw  reg_aon_wpgpr_0_2                   16'h0
    31:16   rw  reg_aon_wpgpr_0                     16'h0
 */
typedef volatile union _AON_0x1CC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_aon_wpgpr_0_2: 16;
        uint32_t reg_aon_wpgpr_0: 16;
    };
} AON_0x1CC_TYPE;

/* 0x1D0    0x4000_01d0
    15:0    rw  reg_aon_wpgpr_1_2                   16'h0
    31:16   rw  reg_aon_wpgpr_1                     16'h0
 */
typedef volatile union _AON_0x1D0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_aon_wpgpr_1_2: 16;
        uint32_t reg_aon_wpgpr_1: 16;
    };
} AON_0x1D0_TYPE;

/* 0x1D4    0x4000_01d4
    15:0    rw  reg_aon_wpgpr_2_2                   16'h0
    31:16   rw  reg_aon_wpgpr_2                     16'h0
 */
typedef volatile union _AON_0x1D4_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_aon_wpgpr_2_2: 16;
        uint32_t reg_aon_wpgpr_2: 16;
    };
} AON_0x1D4_TYPE;

/* 0x1D8    0x4000_01d8
    15:0    rw  reg_aon_wpgpr_3_2                   16'h0
    31:16   rw  reg_aon_wpgpr_3                     16'h0
 */
typedef volatile union _AON_0x1D8_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_aon_wpgpr_3_2: 16;
        uint32_t reg_aon_wpgpr_3: 16;
    };
} AON_0x1D8_TYPE;

/* 0x1DC    0x4000_01dc
    15:0    rw  reg_aon_wpgpr_4_2                   16'h0
    31:16   rw  reg_aon_wpgpr_4                     16'h0
 */
typedef volatile union _AON_0x1DC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_aon_wpgpr_4_2: 16;
        uint32_t reg_aon_wpgpr_4: 16;
    };
} AON_0x1DC_TYPE;

/* 0x1E0    0x4000_01e0
    15:0    rw  reg_aon_wpgpr_5_2                   16'h0
    31:16   rw  reg_aon_wpgpr_5                     16'h0
 */
typedef volatile union _AON_0x1E0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_aon_wpgpr_5_2: 16;
        uint32_t reg_aon_wpgpr_5: 16;
    };
} AON_0x1E0_TYPE;

/* 0x1E4    0x4000_01e4
    15:0    rw  reg_aon_wpgpr_6_2                   16'h0
    31:16   rw  reg_aon_wpgpr_6                     16'h0
 */
typedef volatile union _AON_0x1E4_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_aon_wpgpr_6_2: 16;
        uint32_t reg_aon_wpgpr_6: 16;
    };
} AON_0x1E4_TYPE;

/* 0x1E8    0x4000_01e8
    15:0    rw  reg_aon_wpgpr_7_2                   16'h0
    31:16   rw  reg_aon_wpgpr_7                     16'h0
 */
typedef volatile union _AON_0x1E8_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_aon_wpgpr_7_2: 16;
        uint32_t reg_aon_wpgpr_7: 16;
    };
} AON_0x1E8_TYPE;

/* 0x1EC    0x4000_01ec
    0       wp  DUMMY_6                             1'b0
    1       w1o DUMMY_5                             1'b0
    2       wp  DUMMY_4                             1'b0
    3       w1o reg_aon_w1o_vad_dis                 1'b0
    4       w1o reg_aon_w1o_mic1_dis                1'b0
    5       w1o reg_aon_w1o_mic2_dis                1'b0
    6       w1o reg_aon_w1o_mic3_dis                1'b0
    7       w1o reg_aon_w1o_mic4_dis                1'b0
    8       w1o reg_aon_w1o_spk1_dis                1'b0
    9       w1o reg_aon_w1o_spk2_dis                1'b0
    11:10   w1o DUMMY_3                             2'h0
    15:12   w1o DUMMY_2                             4'h0
    23:16   w1o DUMMY                               8'h0
    24      w1o reg_aon_w1o_bt4_func_dis            1'b0
    25      w1o reg_aon_w1o_bt2_func_dis            1'b0
    26      w1o reg_aon_w1o_handover_func_dis       1'b0
    27      w1o reg_aon_w1o_sniff2_func_dis         1'b0
    28      w1o reg_aon_w1o_sniff1_func_dis         1'b0
    29      w1o reg_aon_w1o_spic0_ft_dis            1'b0
    30      w1o reg_aon_w1o_spic0_mp_dis            1'b0
    31      w1o reg_aon_w1o_spic0_dbg_dis           1'b0
 */
typedef volatile union _AON_0x1EC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t DUMMY_6: 1;
        uint32_t DUMMY_5: 1;
        uint32_t DUMMY_4: 1;
        uint32_t reg_aon_w1o_vad_dis: 1;
        uint32_t reg_aon_w1o_mic1_dis: 1;
        uint32_t reg_aon_w1o_mic2_dis: 1;
        uint32_t reg_aon_w1o_mic3_dis: 1;
        uint32_t reg_aon_w1o_mic4_dis: 1;
        uint32_t reg_aon_w1o_spk1_dis: 1;
        uint32_t reg_aon_w1o_spk2_dis: 1;
        uint32_t DUMMY_3: 2;
        uint32_t DUMMY_2: 4;
        uint32_t DUMMY: 8;
        uint32_t reg_aon_w1o_bt4_func_dis: 1;
        uint32_t reg_aon_w1o_bt2_func_dis: 1;
        uint32_t reg_aon_w1o_handover_func_dis: 1;
        uint32_t reg_aon_w1o_sniff2_func_dis: 1;
        uint32_t reg_aon_w1o_sniff1_func_dis: 1;
        uint32_t reg_aon_w1o_spic0_ft_dis: 1;
        uint32_t reg_aon_w1o_spic0_mp_dis: 1;
        uint32_t reg_aon_w1o_spic0_dbg_dis: 1;
    };
} AON_0x1EC_TYPE;

/* 0x1F0    0x4000_01f0
    0       w1o reg_aon_w1o_mic5_dis                1'b0
    1       w1o reg_aon_w1o_mic6_dis                1'b0
    2       w1o reg_aon_w1o_vadbuf_dis              1'b0
    3       w1o reg_aon_w1o_mic7_dis                1'b0
    4       w1o reg_aon_w1o_repaired_mode_lock      1'b0
    5       w1o reg_aon_w1o_test_row_en_lock        1'b0
    6       w1o reg_aon_w1o_test_mode_sel_lock      1'b0
    7       w1o DUMMY_14                            1'b0
    8       w1o reg_aon_w1o_spic1_dis               1'b0
    9       w1o reg_aon_w1o_spic2_dis               1'b0
    10      w1o reg_aon_w1o_spic3_dis               1'b0
    11      w1o DUMMY_13                            1'b0
    12      w1o reg_aon_w1o_guardtime_agc_dis       1'b0
    13      w1o reg_aon_w1o_pn_cfo_comp_dis         1'b0
    14      w1o reg_aon_w1o_detail_rxrpt_dis        1'b0
    15      w1o reg_aon_w1o_detail_rxrpt_cfoe_dis   1'b0
    16      w1o DUMMY_12                            1'b0
    17      w1o DUMMY_11                            1'b0
    18      r   RSVD_2                              2'h0
    19      w1o DUMMY_10                            2'h0
    20      w1o DUMMY_9                             1'b0
    21      w1o DUMMY_8                             1'b0
    22      w1o DUMMY_7                             1'b0
    23      w1o DUMMY_6                             1'b0
    24      w1o reg_aon_w1o_dsp1_dis                1'b0
    25      w1o DUMMY_5                             1'b0
    26      w1o DUMMY_4                             1'b0
    27      r   RSVD                                1'b0
    28      w1o reg_aon_w1o_dsp1_jtag_dis           1'b0
    29      w1o DUMMY_3                             1'b0
    30      w1o DUMMY_2                             1'b0
    31      w1o DUMMY                               1'b0
 */
typedef volatile union _AON_0x1F0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_aon_w1o_mic5_dis: 1;
        uint32_t reg_aon_w1o_mic6_dis: 1;
        uint32_t reg_aon_w1o_vadbuf_dis: 1;
        uint32_t reg_aon_w1o_mic7_dis: 1;
        uint32_t reg_aon_w1o_repaired_mode_lock: 1;
        uint32_t reg_aon_w1o_test_row_en_lock: 1;
        uint32_t reg_aon_w1o_test_mode_sel_lock: 1;
        uint32_t DUMMY_14: 1;
        uint32_t reg_aon_w1o_spic1_dis: 1;
        uint32_t reg_aon_w1o_spic2_dis: 1;
        uint32_t reg_aon_w1o_spic3_dis: 1;
        uint32_t DUMMY_13: 1;
        uint32_t reg_aon_w1o_guardtime_agc_dis: 1;
        uint32_t reg_aon_w1o_pn_cfo_comp_dis: 1;
        uint32_t reg_aon_w1o_detail_rxrpt_dis: 1;
        uint32_t reg_aon_w1o_detail_rxrpt_cfoe_dis: 1;
        uint32_t DUMMY_12: 1;
        uint32_t DUMMY_11: 1;
        uint32_t RSVD_2: 1;
        uint32_t DUMMY_10: 1;
        uint32_t DUMMY_9: 1;
        uint32_t DUMMY_8: 1;
        uint32_t DUMMY_7: 1;
        uint32_t DUMMY_6: 1;
        uint32_t reg_aon_w1o_dsp1_dis: 1;
        uint32_t DUMMY_5: 1;
        uint32_t DUMMY_4: 1;
        uint32_t RSVD: 1;
        uint32_t reg_aon_w1o_dsp1_jtag_dis: 1;
        uint32_t DUMMY_3: 1;
        uint32_t DUMMY_2: 1;
        uint32_t DUMMY: 1;
    };
} AON_0x1F0_TYPE;

/* 0x35c    0x4000_035c
    15:00   r   aon_st[15:0]                        16'h1
    31:16   r   aon_st[31:16]                       16'h0
 */
typedef volatile union _AON_0x35c_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t aon_st_15_0: 16;
        uint32_t aon_st_31_16: 16;
    };
} AON_0x35c_TYPE;

/* 0x378    0x4000_0378
    15:0    r   RSVD_2                              16'h0
    16      r   loader_over_512byte                 1'b0
    17      r   forbidden_addr                      1'b0
    18      r   incorrext_key                       1'b0
    19      r   aon_loader_done                     1'b0
    20      r   aon_loader_bypass                   1'b0
    31:21   r   RSVD                                11'h0
 */
typedef volatile union _AON_0x378_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_2: 16;
        uint32_t loader_over_512byte: 1;
        uint32_t forbidden_addr: 1;
        uint32_t incorrext_key: 1;
        uint32_t aon_loader_done: 1;
        uint32_t aon_loader_bypass: 1;
        uint32_t RSVD: 11;
    };
} AON_0x378_TYPE;

/* 0x3A8    0x4000_03a8
    15:0    rw  DUMMY_6                             16'hff00
    16      rw  aon_loader_efuse_ctrl_sel           1'b1
    17      rw  aon_loader_clk_en                   1'b1
    18      rw  DUMMY_5                             1'b0
    19      rw  DUMMY_4                             1'b0
    20      rw  DUMMY_3                             1'b0
    21      rw  DUMMY_2                             1'b0
    23:22   rw  DUMMY                               2'b00
    31:24   rw  FAST_REG_469_dummy_B15toB8          8'b11111111
 */
typedef volatile union _AON_0x3A8_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t DUMMY_6: 16;
        uint32_t aon_loader_efuse_ctrl_sel: 1;
        uint32_t aon_loader_clk_en: 1;
        uint32_t DUMMY_5: 1;
        uint32_t DUMMY_4: 1;
        uint32_t DUMMY_3: 1;
        uint32_t DUMMY_2: 1;
        uint32_t DUMMY: 2;
        uint32_t FAST_REG_469_dummy_B15toB8: 8;
    };
} AON_0x3A8_TYPE;

/* 0x3AC    0x4000_03ac
    7:0     rw  DUMMY_3                             8'h0
    8       rw  CKO2_LP_enable                      1'b1
    9       rw  CKO2_HP_enable                      1'b1
    10      rw  DUMMY_2                             1'b1
    13:11   rw  FAST_REG_470_dummy_B15toB8          3'b111
    14      rw  DUMMY                               1'b1
    15      rw  quick_wakeup                        1'b0
    31:16   r   RSVD                                16'h0
 */
typedef volatile union _AON_0x3AC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t DUMMY_3: 8;
        uint32_t CKO2_LP_enable: 1;
        uint32_t CKO2_HP_enable: 1;
        uint32_t DUMMY_2: 1;
        uint32_t FAST_REG_470_dummy_B15toB8: 3;
        uint32_t DUMMY: 1;
        uint32_t quick_wakeup: 1;
        uint32_t RSVD: 16;
    };
} AON_0x3AC_TYPE;

/* 0x3F0    0x4000_03f0
    9:0     r   RO_WK_REASON                        10'h0
    15:10   r   RSVD_3                              6'h0
    17:16   rw  DUMMY_2                             2'b11
    19:18   r   RSVD_2                              2'h0
    20      rw  DUMMY                               1'b1
    30:21   r   RO_WK_REASON_STS                    10'h0
    31      r   RSVD                                1'h0
 */
typedef volatile union _AON_0x3F0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RO_WK_REASON: 10;
        uint32_t RSVD_3: 6;
        uint32_t DUMMY_2: 2;
        uint32_t RSVD_2: 2;
        uint32_t DUMMY: 1;
        uint32_t RO_WK_REASON_STS: 10;
        uint32_t RSVD: 1;
    };
} AON_0x3F0_TYPE;

/* 0x3F4    0x4000_03f4
    1:0     rw  BT_CKI_AD_DIG_ctl                   2'b11
    3:2     rw  BT_CKI_DA_DIG_ctl                   2'b11
    4       rw  BT_CKI_AD_DIG_sel                   1'b1
    5       rw  DUMMY_3                             1'b0
    6       rw  BT_CKI_DA_DIG_sel                   1'b1
    7       r   RSVD                                1'b0
    15:8    rw  DUMMY_2                             8'h0
    31:16   rw  DUMMY                               16'h0
 */
typedef volatile union _AON_0x3F4_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t BT_CKI_AD_DIG_ctl: 2;
        uint32_t BT_CKI_DA_DIG_ctl: 2;
        uint32_t BT_CKI_AD_DIG_sel: 1;
        uint32_t DUMMY_3: 1;
        uint32_t BT_CKI_DA_DIG_sel: 1;
        uint32_t RSVD: 1;
        uint32_t DUMMY_2: 8;
        uint32_t DUMMY: 16;
    };
} AON_0x3F4_TYPE;

/* Auto gen based on RLE1155_AON_Autogen_table_2022_0811_CFCHIN.xlsx */
#define AON_FAST_BOOT                       0x400
#define AON_FAST_REBOOT_SW_INFO0            0x404
#define AON_REG4X_FW_GENERAL                0x408
#define AON_REG6X_FW_GENERAL                0x40C
#define AON_REG8X_FW_GENERAL                0x410
#define AON_REG10X_FW_GENERAL               0x414
#define AON_REG12X_FW_GENERAL               0x418
#define AON_REG14X_FW_GENERAL               0x41C
#define AON_REG16X_FW_GENERAL               0x420
#define AON_REG18X_FW_GENERAL               0x424
#define AON_REG20X_FW_GENERAL               0x428
#define AON_REG22X_FW_GENERAL               0x42C
#define AON_RTC_PF_S_COMP_CONTROLLER_REG    0x4B0
#define AON_RTC_PF_S0_COMP0_REG             0x4B4
#define AON_RTC_PF_S0_COMP1_REG             0x4B8
#define AON_RTC_PF_S0_COMP2_REG             0x4BC
#define AON_RTC_PF_S1_COMP0_REG             0x4C0
#define AON_RTC_PF_S1_COMP1_REG             0x4C4
#define AON_RTC_PF_S1_COMP2_REG             0x4C8
#define AON_RTC_PF_S_COMP_MANUAL_INT_REG    0x4CC
#define AON_RTC_PF_CNT_REG                  0x4D0
#define AON_RTC_PF_S_COMP_INT_CLR_REG       0x4D4
#define AON_RTC_PF_S_COMP_INT_SR_REG        0x4D8
#define AON_RTC_PF_RTL_VERSION_REG          0x4DC
#define AON_RTC_PF_M_COMP_CONTROLLER_REG    0x4E0
#define AON_RTC_PF_M_COMP0_REG              0x4E4
#define AON_RTC_PF_M_COMP1_REG              0x4E8
#define AON_RTC_PF_M_COMP2_REG              0x4EC
#define AON_RTC_PF_M_COMP3_REG              0x4F0
#define AON_RTC_PF_M_COMP_INT_CLR_REG       0x4F4
#define AON_RTC_PF_M_COMP_INT_SR_REG        0x4F8
#define AON_RTC_PF_WK_COMP_CONTROLLER_REG   0x4FC
#define AON_RTC_PF_WK_COMP_REG              0x500
#define AON_RTC_PF_WK_COMP_WK_CLR_REG       0x504
#define AON_RTC_PF_WK_COMP_WK_SR_REG        0x508
#define AON_MEMORY_REG1X                    0x580
#define AON_MEMORY_REG2X                    0x584
#define AON_REG_KM4_ROM_RAM_VSEL            0x588
#define AON_REG_KM0_KR0_ROM_RAM_VSEL        0x58C
#define AON_AON_LOADER_TIMER0_TIMER1        0x590
#define AON_AON_LOADER_TIMER2_TIMER3        0x594
#define AON_AON_LOADER_TIMER4_TIMER5        0x598
#define AON_MEM_VSEL_SYNC_EN_MISC           0x59C
#define AON_ROM                             0x5A0
#define AON_ROM_SD                          0x5A4
#define AON_REG_ROM_KM4_KM0_HV              0x5B0
#define AON_REG_ROM_KR0_DSP_HV              0x5B4
#define AON_REG_RAM_KM4_HV                  0x5B8
#define AON_REG_RAM_KM4_RF_HV               0x5BC
#define AON_REG_RAM_KM0_HV                  0x5C0
#define AON_REG_RAM_KM0_RF_HV               0x5C4
#define AON_REG_RAM_KR0_PMC_HV              0x5C8
#define AON_REG_RAM_KR0_IPC_HV              0x5CC
#define AON_REG_RAM_KR0_LOG_HV              0x5D0
#define AON_REG_RAM_DATA_HV                 0x5D4
#define AON_REG_RAM_DSP_SYS_HV              0x5D8
#define AON_REG_RAM_BUF_HV                  0x5DC
#define AON_REG_RAM_DSP_DATA_HV             0x5E0
#define AON_REG_RAM_DSP_HV                  0x5E4
#define AON_REG_RAM_DSP_RF_HV               0x5E8
#define AON_REG_RAM_FFT_RF_HV               0x5EC
#define AON_REG_RAM_SDIO_HV                 0x5F0
#define AON_REG_RAM_USB_HV                  0x5F4
#define AON_REG_RAM_DISPLAY_RF_HV           0x5F8
#define AON_REG_RAM_MIPI_RF_HV              0x5FC
#define AON_REG_RAM_MAC_HV                  0x600
#define AON_REG_RAM_MAC_RF_HV               0x604
#define AON_REG_RAM_MDM_HV                  0x608
#define AON_REG_RAM_MDM_RF_HV               0x60C
#define AON_REG_RAM_VADBUF_HV               0x610
#define AON_REG_RAM_PKE_RF_HV               0x614
#define AON_REG_RAM_GPU_RF_HV               0x618
#define AON_REG_RAM_GPU_RF_2P_HV            0x61C
#define AON_REG_ROM_KM4_KM0_LV              0x630
#define AON_REG_ROM_KR0_DSP_LV              0x634
#define AON_REG_RAM_KM4_LV                  0x638
#define AON_REG_RAM_KM4_RF_LV               0x63C
#define AON_REG_RAM_KM4_LV_0P7V             0x640
#define AON_REG_RAM_KM4_RF_LV_0P7V          0x644
#define AON_REG_RAM_KM0_LV                  0x648
#define AON_REG_RAM_KM0_RF_LV               0x64C
#define AON_REG_RAM_KR0_PMC_LV              0x650
#define AON_REG_RAM_KR0_IPC_LV              0x654
#define AON_REG_RAM_KR0_LOG_LV              0x658
#define AON_REG_RAM_DATA_LV                 0x65C
#define AON_REG_RAM_DSP_SYS_LV              0x660
#define AON_REG_RAM_BUF_LV                  0x664
#define AON_REG_RAM_DSP_DATA_LV             0x668
#define AON_REG_RAM_DSP_LV                  0x66C
#define AON_REG_RAM_DSP_RF_LV               0x670
#define AON_REG_RAM_FFT_RF_LV               0x674
#define AON_REG_RAM_SDIO_LV                 0x678
#define AON_REG_RAM_USB_LV                  0x67C
#define AON_REG_RAM_DISPLAY_RF_LV           0x680
#define AON_REG_RAM_MIPI_RF_LV              0x684
#define AON_REG_RAM_MAC_LV                  0x688
#define AON_REG_RAM_MAC_RF_LV               0x68C
#define AON_REG_RAM_MDM_LV                  0x690
#define AON_REG_RAM_MDM_RF_LV               0x694
#define AON_REG_RAM_VADBUF_LV               0x698
#define AON_REG_RAM_PKE_RF_LV               0x69C
#define AON_REG_RAM_GPU_RF_LV               0x6A0
#define AON_REG_RAM_GPU_RF_2P_LV            0x6A4
#define AON_ARM_SRAM_PGEN_ISO0_3            0x6B0
#define AON_ARM_SRAM_PGEN_ISO0_4            0x6B4
#define AON_ARM_SRAM_PGEN_ISO0_5            0x6B8
#define AON_ARM_SRAM_PGEN_ISO0_6            0x6BC
#define AON_ARM_SRAM_PGEN_ISO0_7            0x6C0
#define AON_ARM_SRAM_PGEN_ISO0_8            0x6C4
#define AON_ARM_SRAM_PGEN_ISO0_9            0x6C8
#define AON_ARM_SRAM_PGEN_ISO0_10           0x6CC
#define AON_ARM_SRAM_PGEN_ISO0_11           0x6D0
#define AON_ARM_SRAM_PGEN_ISO0_12           0x6D4
#define AON_ARM_SRAM_PGEN_ISO1_3            0x6F0
#define AON_ARM_SRAM_PGEN_ISO1_4            0x6F4
#define AON_ARM_SRAM_PGEN_ISO1_5            0x6F8
#define AON_ARM_SRAM_PGEN_ISO1_6            0x6FC
#define AON_ARM_SRAM_PGEN_ISO1_7            0x700
#define AON_ARM_SRAM_PGEN_ISO1_8            0x704
#define AON_ARM_SRAM_PGEN_ISO1_9            0x708
#define AON_ARM_SRAM_PGEN_ISO1_10           0x70C
#define AON_ARM_SRAM_PGEN_ISO1_11           0x710
#define AON_ARM_SRAM_PGEN_ISO1_12           0x714
#define AON_ARM_SRAM_RET1N_ISO0_1           0x720
#define AON_ARM_SRAM_RET1N_ISO0_2           0x724
#define AON_ARM_SRAM_RET1N_ISO0_3           0x728
#define AON_ARM_SRAM_RET1N_ISO0_4           0x72C
#define AON_ARM_SRAM_RET1N_ISO0_5           0x730
#define AON_ARM_SRAM_RET1N_ISO0_6           0x734
#define AON_ARM_SRAM_RET1N_ISO0_7           0x738
#define AON_ARM_SRAM_RET1N_ISO0_8           0x73C
#define AON_ARM_SRAM_RET1N_ISO0_9           0x740
#define AON_ARM_SRAM_RET1N_ISO0_10          0x744
#define AON_ARM_SRAM_RET1N_ISO0_11          0x748
#define AON_ARM_SRAM_RET1N_ISO0_12          0x74C
#define AON_ARM_SRAM_RET1N_ISO1_1           0x760
#define AON_ARM_SRAM_RET1N_ISO1_2           0x764
#define AON_ARM_SRAM_RET1N_ISO1_3           0x768
#define AON_ARM_SRAM_RET1N_ISO1_4           0x76C
#define AON_ARM_SRAM_RET1N_ISO1_5           0x770
#define AON_ARM_SRAM_RET1N_ISO1_6           0x774
#define AON_ARM_SRAM_RET1N_ISO1_7           0x778
#define AON_ARM_SRAM_RET1N_ISO1_8           0x77C
#define AON_ARM_SRAM_RET1N_ISO1_9           0x780
#define AON_ARM_SRAM_RET1N_ISO1_10          0x784
#define AON_ARM_SRAM_RET1N_ISO1_11          0x788
#define AON_ARM_SRAM_RET1N_ISO1_12          0x78C
#define AON_ARM_SRAM_RET2N_ISO0_3           0x7A0
#define AON_ARM_SRAM_RET2N_ISO0_4           0x7A4
#define AON_ARM_SRAM_RET2N_ISO0_5           0x7A8
#define AON_ARM_SRAM_RET2N_ISO0_6           0x7AC
#define AON_ARM_SRAM_RET2N_ISO0_7           0x7B0
#define AON_ARM_SRAM_RET2N_ISO0_8           0x7B4
#define AON_ARM_SRAM_RET2N_ISO0_9           0x7B8
#define AON_ARM_SRAM_RET2N_ISO0_10          0x7BC
#define AON_ARM_SRAM_RET2N_ISO0_11          0x7C0
#define AON_ARM_SRAM_RET2N_ISO0_12          0x7C4
#define AON_ARM_SRAM_RET2N_ISO1_3           0x7D0
#define AON_ARM_SRAM_RET2N_ISO1_4           0x7D4
#define AON_ARM_SRAM_RET2N_ISO1_5           0x7D8
#define AON_ARM_SRAM_RET2N_ISO1_6           0x7DC
#define AON_ARM_SRAM_RET2N_ISO1_7           0x7E0
#define AON_ARM_SRAM_RET2N_ISO1_8           0x7E4
#define AON_ARM_SRAM_RET2N_ISO1_9           0x7E8
#define AON_ARM_SRAM_RET2N_ISO1_10          0x7EC
#define AON_ARM_SRAM_RET2N_ISO1_11          0x7F0
#define AON_ARM_SRAM_RET2N_ISO1_12          0x7F4
#define AON_REG00_SYS                       0x800
#define AON_REG01_SYS                       0x804
#define AON_REG02_SYS                       0x808
#define AON_REG03_SYS                       0x80C
#define AON_REG04_SYS                       0x810
#define AON_REG05_SYS                       0x814
#define AON_REG00_POS                       0x818
#define AON_REG01_POS                       0x81C
#define AON_REG02_POS                       0x820
#define AON_REG03_POS                       0x824
#define AON_REG04_POS                       0x828
#define AON_REG05_POS                       0x82C
#define AON_REG06_POS                       0x830
#define AON_REG07_POS                       0x834
#define AON_REG00_CLK                       0x838
#define AON_REG04_CLK                       0x83C
#define AON_REG08_SAF                       0x840
#define AON_REG0C_SAF                       0x844
#define AON_REG10_SAF                       0x848
#define AON_REG14_SC                        0x84C
#define AON_REG18_SLV_ACC                   0x850
#define AON_REG1C_SLV_ACC                   0x854
#define AON_REG20_SLV_ACC                   0x858
#define AON_REG24_KR0_CLK                   0x85C
#define AON_REG28_KM4_DBG_CTRL              0x860
#define AON_REG32_OSC40M_CAL_CTRL           0x864
#define AON_REG36_OSC40M_CAL_CTRL           0x868
#define AON_OCC_debug_en_bus_0              0x86C
#define AON_OCC_debug_en_bus_2              0x870
#define AON_HW_FSM_DUMMY_1                  0x874
#define AON_HW_FSM_DUMMY_2                  0x878
#define AON_HW_FSM_DUMMY_3                  0x87C
#define AON_HW_FSM_DUMMY_4                  0x880
#define AON_HW_FSM_DUMMY_5                  0x884
#define AON_HW_FSM_DUMMY_6                  0x888
#define AON_REG08_POS                       0x88C
#define AON_REG06_SYS                       0x890
#define AON_OCC_debug_en_bus4_1             0x894
#define AON_CLAMP_ESDCTRL                   0x898
#define AON_LOP_RG0X                        0xAB0
#define AON_LOP_RG1X                        0xAB4
#define AON_LOP_RG2X                        0xAB8
#define AON_LOP_RG3X                        0xABC
#define AON_LOP_RG4X                        0xAC0
#define AON_LOP_RG5X                        0xAC4
#define AON_LOP_RG6X                        0xAC8
#define AON_LOP_RG7X                        0xACC
#define AON_LOP_RG8X                        0xAD0
#define AON_LOP_RG9X                        0xAD4
#define AON_LOP_RG10X                       0xAD8
#define AON_LOP_RG11X                       0xADC
#define AON_LOP_RG12X                       0xAE0
#define AON_LOP_RG13X                       0xAE4
#define AON_LOP_RG14X                       0xAE8
#define AON_LOP_RG15X                       0xAEC
#define AON_LOP_RG16X                       0xAF0
#define AON_LOP_RG17X                       0xAF4
#define AON_LOP_RG18X                       0xAF8
#define AON_REG0X_MBIAS                     0xC00
#define AON_REG2X_MBIAS                     0xC04
#define AON_REG4X_MBIAS                     0xC08
#define AON_REG6X_MBIAS                     0xC0C
#define AON_REG0X_LDO                       0xC10
#define AON_REG2X_LDO                       0xC14
#define AON_REG4X_LDO                       0xC18
#define AON_REG0X_BUCK                      0xC20
#define AON_REG2X_BUCK                      0xC24
#define AON_REG4X_BUCK                      0xC28
#define AON_REG6X_BUCK                      0xC2C
#define AON_REG8X_BUCK                      0xC30
#define AON_REG10X_BUCK                     0xC34
#define AON_REG12X_BUCK                     0xC38
#define AON_REG14X_BUCK                     0xC3C
#define AON_REG16X_BUCK                     0xC40
#define AON_REG18X_BUCK                     0xC44
#define AON_REG20X_BUCK                     0xC48
#define AON_REG22X_BUCK                     0xC4C
#define AON_REG24X_BUCK                     0xC50
#define AON_REG26X_BUCK                     0xC54
#define AON_REG28X_BUCK                     0xC58
#define AON_REG30X_BUCK                     0xC5C
#define AON_REG32X_BUCK                     0xC60
#define AON_REG34X_BUCK                     0xC64
#define AON_C_KOUT0X_BUCK                   0xC68
#define AON_CKOUT2X_BUCK                    0xC6C
#define AON_CKOUT4X_BUCK                    0xC70
#define AON_CKOUT6X_BUCK                    0xC74
#define AON_C_KOUT8X_BUCK                   0xC78
#define AON_RG0X_32KXTAL                    0xC80
#define AON_RG2X_32KXTAL                    0xC84
#define AON_RG0X_32KOSC                     0xC88
#define AON_REG0X_40MOSC                    0xC8C
#define AON_POW_32K                         0xC90
#define AON_ANAPAR_XTAL_MODE                0xCA0
#define AON_ANAPAR_XTAL0                    0xCA4
#define AON_ANAPAR_XTAL2                    0xCA8
#define AON_ANAPAR_XTAL4                    0xCAC
#define AON_ANAPAR_XTAL6                    0xCB0
#define AON_ANAPAR_XTAL8                    0xCB4
#define AON_ANAPAR_XTAL10                   0xCB8
#define AON_ANAPAR_XTAL12                   0xCBC
#define AON_ANAPAR_XTAL14                   0xCC0
#define AON_LDOPA_REG3X_LDO                 0xCD0
#define AON_LDOPA_REG_DUMMYLOAD             0xCD4
#define AON_BT_ANAPAR_LDO_ADDA              0xCD8
#define AON_BT_TPMK_ADC_LDO                 0xCDC
#define AON_BT_RF18_LDO                     0xCE0
#define AON_BT_ANAPAR_PLL0                  0xD00
#define AON_BT_ANAPAR_PLL2                  0xD04
#define AON_BT_ANAPAR_PLL4                  0xD08
#define AON_BT_ANAPAR_PLL6                  0xD0C
#define AON_BT_ANAPAR_PLL8                  0xD10
#define AON_BT_ANAPAR_PLL10                 0xD14
#define AON_BT_ANAPAR_PLL13_BT_ANAPAR_PLL12 0xD18
#define AON_BT_ANAPAR_PLL14                 0xD1C
#define AON_BT_ANAPAR_PLL16                 0xD20
#define AON_BT_ANAPAR_PLL18                 0xD24
#define AON_BT_ANAPAR_PLL20                 0xD28
#define AON_BT_ANAPAR_PLL22                 0xD2C
#define AON_BT_ANAPAR_PLL_LDO1              0xD30
#define AON_NS_RTC_CR0                      0x1800
#define AON_NS_RTC_INT_clear                0x1804
#define AON_NS_RTC_INT_SR                   0x1808
#define AON_NS_RTC_PRESCALER0               0x180C
#define AON_NS_RTC_COMP_0                   0x1810
#define AON_NS_RTC_COMP_1                   0x1814
#define AON_NS_RTC_COMP_2                   0x1818
#define AON_NS_RTC_COMP_3                   0x181C
#define AON_NS_RTC_COMP0_GT                 0x1820
#define AON_NS_RTC_COMP1_GT                 0x1824
#define AON_NS_RTC_COMP2_GT                 0x1828
#define AON_NS_RTC_COMP3_GT                 0x182C
#define AON_NS_RTC_CNT0                     0x1830
#define AON_NS_RTC_PRESCALE_CNT0            0x1834
#define AON_NS_RTC_PRESCALE_CMP0            0x1838
#define AON_NS_RTC_BACKUP_REG               0x183C
#define AON_NS_RTC_RTL_VERSION0             0x1840
#define AON_NS_LPC0_CR0                     0x1850
#define AON_NS_LPC0_SR                      0x1854
#define AON_NS_LPC1_CR0                     0x1858
#define AON_NS_LPC1_SR                      0x185C
#define AON_NS_ADC_0_ADC_1_PAD_CFG          0x1900
#define AON_NS_ADC_2_ADC_3_PAD_CFG          0x1904
#define AON_NS_ADC_4_ADC_5_PAD_CFG          0x1908
#define AON_NS_ADC_6_ADC_7_PAD_CFG          0x190C
#define AON_NS_P1_0_P1_1_PAD_CFG            0x1910
#define AON_NS_P1_2_P1_3_PAD_CFG            0x1914
#define AON_NS_P1_4_P1_5_PAD_CFG            0x1918
#define AON_NS_P1_6_P1_7_PAD_CFG            0x191C
#define AON_NS_P2_0_P2_1_PAD_CFG            0x1920
#define AON_NS_P2_2_P2_3_PAD_CFG            0x1924
#define AON_NS_P2_4_P2_5_PAD_CFG            0x1928
#define AON_NS_P2_6_P2_7_PAD_CFG            0x192C
#define AON_NS_P3_0_P3_1_PAD_CFG            0x1930
#define AON_NS_P3_2_P3_3_PAD_CFG            0x1934
#define AON_NS_P3_4_P3_5_PAD_CFG            0x1938
#define AON_NS_P3_6_P3_7_PAD_CFG            0x193C
#define AON_NS_P4_0_P4_1_PAD_CFG            0x1940
#define AON_NS_P4_2_P4_3_PAD_CFG            0x1944
#define AON_NS_P4_4_P4_5_PAD_CFG            0x1948
#define AON_NS_P4_6_P4_7_PAD_CFG            0x194C
#define AON_NS_P5_0_P5_1_PAD_CFG            0x1950
#define AON_NS_P5_2_P5_3_PAD_CFG            0x1954
#define AON_NS_P5_4_P5_5_PAD_CFG            0x1958
#define AON_NS_P5_6_P5_7_PAD_CFG            0x195C
#define AON_NS_P6_0_P6_1_PAD_CFG            0x1960
#define AON_NS_P6_2_P6_3_PAD_CFG            0x1964
#define AON_NS_P6_4_P6_5_PAD_CFG            0x1968
#define AON_NS_P6_6_P6_7_PAD_CFG            0x196C
#define AON_NS_P7_0_P7_1_PAD_CFG            0x1970
#define AON_NS_P7_2_P7_3_PAD_CFG            0x1974
#define AON_NS_P7_4_P7_5_PAD_CFG            0x1978
#define AON_NS_P7_6_P7_7_PAD_CFG            0x197C
#define AON_NS_P8_0_P8_1_PAD_CFG            0x1980
#define AON_NS_P8_2_P8_3_PAD_CFG            0x1984
#define AON_NS_P8_4_P8_5_PAD_CFG            0x1988
#define AON_NS_P8_6_P8_7_PAD_CFG            0x198C
#define AON_NS_P9_0_P9_1_PAD_CFG            0x1990
#define AON_NS_P9_2_P9_3_PAD_CFG            0x1994
#define AON_NS_P9_4_P9_5_PAD_CFG            0x1998
#define AON_NS_P9_6_P9_7_PAD_CFG            0x199C
#define AON_NS_P10_0_P10_1_PAD_CFG          0x19A0
#define AON_NS_P10_2_P10_3_PAD_CFG          0x19A4
#define AON_NS_P10_4_P10_5_PAD_CFG          0x19A8
#define AON_NS_P10_6_P10_7_PAD_CFG          0x19AC
#define AON_NS_P11_0_P11_1_PAD_CFG          0x19B0
#define AON_NS_P11_2_P11_3_PAD_CFG          0x19B4
#define AON_NS_P11_4_P11_5_PAD_CFG          0x19B8
#define AON_NS_P11_6_P11_7_PAD_CFG          0x19BC
#define AON_NS_P12_0_P12_1_PAD_CFG          0x19C0
#define AON_NS_P12_2_P12_3_PAD_CFG          0x19C4
#define AON_NS_P12_4_P12_5_PAD_CFG          0x19C8
#define AON_NS_P12_6_P12_7_PAD_CFG          0x19CC
#define AON_NS_P13_0_P13_1_PAD_CFG          0x19D0
#define AON_NS_P13_2_P13_3_PAD_CFG          0x19D4
#define AON_NS_P13_4_P13_5_PAD_CFG          0x19D8
#define AON_NS_P13_6_P13_7_PAD_CFG          0x19DC
#define AON_NS_P14_0_P14_1_PAD_CFG          0x19E0
#define AON_NS_P14_2_P14_3_PAD_CFG          0x19E4
#define AON_NS_P14_4_P14_5_PAD_CFG          0x19E8
#define AON_NS_P14_6_P14_7_PAD_CFG          0x19EC
#define AON_NS_P15_0_P15_1_PAD_CFG          0x19F0
#define AON_NS_P15_2_P15_3_PAD_CFG          0x19F4
#define AON_NS_P15_4_P15_5_PAD_CFG          0x19F8
#define AON_NS_P15_6_P15_7_PAD_CFG          0x19FC
#define AON_NS_P16_0_P16_1_PAD_CFG          0x1A00
#define AON_NS_P16_2_P16_3_PAD_CFG          0x1A04
#define AON_NS_P16_4_P16_5_PAD_CFG          0x1A08
#define AON_NS_SPIC0_PAD_CFG0               0x1A0C
#define AON_NS_SPIC0_PAD_CFG1               0x1A10
#define AON_NS_SPIC0_PAD_CFG2               0x1A14
#define AON_NS_Codec_MIC3_N_P_PAD_CFG       0x1A18
#define AON_NS_Codec_MIC2_N_P_PAD_CFG       0x1A1C
#define AON_NS_Codec_MIC1_N_P_PAD_CFG       0x1A20
#define AON_NS_Codec_DAC2_N_P_PAD_CFG       0x1A24
#define AON_NS_Codec_DAC1_N_P_PAD_CFG       0x1A28
#define AON_NS_PAD_Group_CFG0               0x1A2C
#define AON_NS_PAD_Group_CFG1               0x1A30
#define AON_NS_PAD_AON_PINMUX_CFG0          0x1A34
#define AON_NS_P16_6_P16_7_PAD_CFG          0x1A38
#define AON_NS_P17_0_P17_1_PAD_CFG          0x1A3C
#define AON_NS_P17_2_P17_3_PAD_CFG          0x1A40
#define AON_NS_P17_4_P17_5_PAD_CFG          0x1A44
#define AON_NS_P17_6_P17_7_PAD_CFG          0x1A48
#define AON_NS_P18_0_P18_1_PAD_CFG          0x1A4C
#define AON_NS_P18_2_P18_3_PAD_CFG          0x1A50
#define AON_NS_P18_4_P18_5_PAD_CFG          0x1A54
#define AON_NS_P18_6_P18_7_PAD_CFG          0x1A58
#define AON_NS_P19_0_P19_1_PAD_CFG          0x1A5C
#define AON_NS_P19_2_P19_3_PAD_CFG          0x1A60
#define AON_NS_P19_4_P19_5_PAD_CFG          0x1A64
#define AON_NS_P19_6_P19_7_PAD_CFG          0x1A68
#define AON_NS_P_BOOT_SEL_PAD_CFG           0x1A6C
#define AON_NS_PAD_AON_PINMUX_CFG1          0x1A70
#define AON_NS_PAD_AON_PINMUX_CFG2          0x1A74
#define AON_NS_P20_0_P20_1_PAD_CFG          0x1A78
#define AON_NS_P20_2_P20_3_PAD_CFG          0x1A7C
#define AON_NS_P20_4_P20_5_PAD_CFG          0x1A80
#define AON_NS_P20_6_P20_7_PAD_CFG          0x1A84
#define AON_NS_PAD_Status_0                 0x1AA0
#define AON_NS_PAD_Status_1                 0x1AA4
#define AON_NS_PAD_Status_2                 0x1AA8
#define AON_NS_PAD_Status_3                 0x1AAC
#define AON_NS_PAD_Status_4                 0x1AB0
#define AON_NS_REG_DEBIO_CNT_19_18          0x1AB4
#define AON_NS_REG_DEBIO_CNT_17_16          0x1AB8
#define AON_NS_REG_DEBIO_CNT_15_14          0x1ABC
#define AON_NS_REG_DEBIO_CNT_13_12          0x1AC0
#define AON_NS_REG_DEBIO_CNT_11_10          0x1AC4
#define AON_NS_REG_DEBIO_CNT_09_08          0x1AC8
#define AON_NS_REG_DEBIO_CNT_07_06          0x1ACC
#define AON_NS_REG_DEBIO_CNT_05_04          0x1AD0
#define AON_NS_REG_DEBIO_CNT_03_02          0x1AD4
#define AON_NS_REG_DEBIO_CNT_01_00          0x1AD8
#define AON_NS_PAD_Status_5                 0x1ADC
#define AON_NS_REG0X_APP                    0x1AE0
#define AON_NS_REG1X_APP                    0x1AE4
#define AON_NS_REG2X_APP                    0x1AE8
#define AON_NS_REG3X_APP                    0x1AEC
#define AON_NS_REG4X_APP                    0x1AF0
#define AON_NS_REG5X_APP                    0x1AF4
#define AON_NS_REG6X_APP                    0x1AF8
#define AON_NS_REG7X_APP                    0x1AFC
#define AON_NS_REG8X_APP                    0x1B00
#define AON_NS_REG9X_APP                    0x1B04
#define AON_NS_REG10X_APP                   0x1B08
#define AON_NS_REG11X_APP                   0x1B0C
#define AON_NS_REG12X_APP                   0x1B10
#define AON_NS_REG13X_APP                   0x1B14
#define AON_NS_REG14X_APP                   0x1B18
#define AON_NS_REG15X_APP                   0x1B1C
#define AON_NS_AON_WDG_WP0                  0x1B60
#define AON_NS_AON_WDG_CONFIG               0x1B64
#define AON_NS_AON_WDG_CNT_RESET0           0x1B68
#define AON_NS_AON_WDG_SEC_CTL              0x1B6C
#define AON_NS_REG0X_AUXADC                 0x1B90
#define AON_NS_REG2X_AUXADC                 0x1B94
#define AON_NS_REG4X_AUXADC                 0x1B98
#define AON_NS_REG6X_AUXADC                 0x1B9C
#define AON_NS_REG8X_AUXADC                 0x1BA0
#define AON_NS_REG10X_AUXADC                0x1BA4
#define AON_NS_REG12X_AUXADC                0x1BA8
#define AON_NS_REG_CONFIG                   0x1BD0
#define AON_NS_REG_SR_X                     0x1BD4
#define AON_NS_INT_CLR                      0x1BD8
#define AON_NS_REG30_CORE_KM4_PC            0x1C00
#define AON_NS_REG34_CORE_KM4_LR            0x1C04
#define AON_NS_REG38_CORE_KM4_PC_EX         0x1C08
#define AON_NS_REG3C_CORE_KM4_XPSR_R        0x1C0C
#define AON_NS_REG40_CORE_KM4_MSP_S         0x1C10
#define AON_NS_REG44_CORE_KM4_PSP_S         0x1C14
#define AON_NS_REG48_CORE_KM4_MSP_NS        0x1C18
#define AON_NS_REG4C_CORE_KM4_PSP_NS        0x1C1C
#define AON_NS_REG50_AON_KM4_PC             0x1C20
#define AON_NS_REG54_AON_KM4_LR             0x1C24
#define AON_NS_REG58_AON_KM4_PC_EX          0x1C28
#define AON_NS_REG5C_AON_KM4_XPSR_R         0x1C2C
#define AON_NS_REG60_AON_KM4_MSP_S          0x1C30
#define AON_NS_REG64_AON_KM4_PSP_S          0x1C34
#define AON_NS_REG68_AON_KM4_MSP_NS         0x1C38
#define AON_NS_REG6C_AON_KM4_PSP_NS         0x1C3C
#define AON_NS_REG70_KR0_WDT_KM4_PC         0x1C40
#define AON_NS_REG74_KR0_WDT_KM4_LR         0x1C44
#define AON_NS_REG78_KR0_WDT_KM4_PC_EX      0x1C48
#define AON_NS_REG7C_KR0_WDT_KM4_XPSR_R     0x1C4C
#define AON_NS_REG80_KR0_WDT_KM4_MSP_S      0x1C50
#define AON_NS_REG84_KR0_WDT_KM4_PSP_S      0x1C54
#define AON_NS_REG88_KR0_WDT_KM4_MSP_NS     0x1C58
#define AON_NS_REG8C_KR0_WDT_KM4_PSP_NS     0x1C5C
#define AON_NS_REG90_KR0_WDT_KR0_PC_VALUE   0x1C60
#define AON_NS_REG94_KR0_WDT_KR0_GPR_RA     0x1C64
#define AON_NS_REG98_KR0_WDT_KR0_GPR_SP     0x1C68
#define AON_NS_REG9C_KR0_WDT_KR0_GPR_TP     0x1C6C
#define AON_NS_REGA0_AON_WDT_KR0_PC_VALUE   0x1C70
#define AON_NS_REGA4_KR0_WDT_KR0_GPR_RA     0x1C74
#define AON_NS_REGA8_KR0_WDT_KR0_GPR_SP     0x1C78
#define AON_NS_REGAC_KR0_WDT_KR0_GPR_TP     0x1C7C
#define AON_NS_REGB0_KM4_WDT_KM0_PC         0x1C80
#define AON_NS_REGB4_KM4_WDT_KM0_LR         0x1C84
#define AON_NS_REGB8_KM4_WDT_KM0_EX         0x1C88
#define AON_NS_REGBC_KM4_WDT_KM0_XPSR_R     0x1C8C
#define AON_NS_REGC0_KM4_WDT_KM0_MSP_NS     0x1C90
#define AON_NS_REGC4_KM4_WDT_KM0_PSP_NS     0x1C94
#define AON_NS_REGC8_KM0_WDT_KM0_PC         0x1C98
#define AON_NS_REGCC_KM0_WDT_KM0_LR         0x1C9C
#define AON_NS_REGD0_KM0_WDT_KM0_EX         0x1CA0
#define AON_NS_REGD4_KM0_WDT_KM0_XPSR_R     0x1CA4
#define AON_NS_REGD8_KM0_WDT_KM0_MSP_NS     0x1CA8
#define AON_NS_REGDC_KM0_WDT_KM0_PSP_NS     0x1CAC
#define AON_NS_REGE0_KR0_WDT_KM0_PC         0x1CB0
#define AON_NS_REGE4_KR0_WDT_KM0_LR         0x1CB4
#define AON_NS_REGE8_KR0_WDT_KM0_EX         0x1CB8
#define AON_NS_REGEC_KR0_WDT_KM0_XPSR_R     0x1CBC
#define AON_NS_REGF0_KR0_WDT_KM0_MSP_NS     0x1CC0
#define AON_NS_REGF4_KR0_WDT_KM0_PSP_NS     0x1CC4
#define AON_NS_REGF8_AON_WDT_KM0_PC         0x1CC8
#define AON_NS_REGFC_AON_WDT_KM0_LR         0x1CCC
#define AON_NS_REG100_AON_WDT_KM0_EX        0x1CD0
#define AON_NS_REG104_AON_WDT_KM0_XPSR_R    0x1CD4
#define AON_NS_REG108_AON_WDT_KM0_MSP_NS    0x1CD8
#define AON_NS_REG10C_AON_WDT_KM0_PSP_NS    0x1CDC
#define AON_NS_REG10C_AON_WDT_MODE          0x1CE0
#define AON_NS_REG110_KM0_WDT_MODE          0x1CE4
#define AON_NS_REG110_KM4_WDT_MODE          0x1CE8
#define AON_NS_REG110_KR0_WDT_MODE          0x1CEC
#define AON_NS_REG0X_FW_GENERAL_NS          0x1D00
#define AON_NS_REG2X_FW_GENERAL_NS          0x1D04
#define AON_NS_REG4X_FW_GENERAL_NS          0x1D08
#define AON_NS_REG6X_FW_GENERAL_NS          0x1D0C
#define AON_NS_REG8X_FW_GENERAL_NS          0x1D10
#define AON_NS_REG10X_FW_GENERAL_NS         0x1D14
#define AON_NS_RG0X_CODEC_LDO               0x1D40
#define AON_NS_RG2X_CODEC_LDO               0x1D44
#define AON_NS_RG4X_CODEC_LDO               0x1D48
#define AON_NS_RG6X_CODEC_LDO               0x1D4C
/* 0x400    0x4000_0400
    31:0    R/W reserved                            32'b0
 */
typedef volatile union _AON_FAST_BOOT_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t rsvd:                  32; /* bit[31:0]: reserved                          */
    };
} AON_FAST_BOOT_TYPE;

/* 0x404    0x4000_0404
    15:0    R/W FW_GENERAL_REG2X                    16'h0
    31:16   R/W FW_GENERAL_REG3X                    16'h0
 */
typedef volatile union _AON_FAST_REBOOT_SW_INFO0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t is_xtal_use_ext_cap: 1;           /* bit[0]: use external cap */
        uint32_t rsvd:                15;
        uint32_t FW_GENERAL_REG3X:    16;
    };
} AON_FAST_REBOOT_SW_INFO0_TYPE;

/* 0x408    0x4000_0408
    15:0    R/W FW_GENERAL_REG4X                    16'h0
    31:16   R/W FW_GENERAL_REG5X                    16'h0
 */
typedef volatile union _AON_REG4X_FW_GENERAL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t ota_valid: 1;                  /* bit[0]: ota valid */
        uint32_t is_rom_code_patch: 1;          /* bit[1]: is rom code patch ? */
        uint32_t is_fw_trig_wdg_to: 1;          /* bit[2]: does fw trigger watchdog timeout ? */
        uint32_t is_send_patch_end_evt: 1;      /* bit[3]: does we send patch end event ? */
        uint32_t is_hci_mode: 1;                /* bit[4]: switch to hci mode? */
        uint32_t is_single_tone_mode: 1;        /* bit[5]: reserved */
        uint32_t rsvd0: 1;                      /* bit[6]: reserved */
        uint32_t REBOOT_SW_INFO1: 6;            /* bit[12:7] for AON_FAST_REBOOT_SW_INFO1 */
        uint32_t rsvd1: 3;
        uint32_t FW_GENERAL_REG5X: 16;
    };
} AON_REG4X_FW_GENERAL_TYPE;

/* 0x40C    0x4000_040c
    15:0    R/W FW_GENERAL_REG6X                    16'h0
    31:16   R/W FW_GENERAL_REG7X                    16'h0
 */
typedef volatile union _AON_REG6X_FW_GENERAL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_GENERAL_REG6X: 16;
        uint32_t FW_GENERAL_REG7X: 16;
    };
} AON_REG6X_FW_GENERAL_TYPE;

/* 0x410    0x4000_0410
    15:0    R/W FW_GENERAL_REG8X                    16'h0
    31:16   R/W FW_GENERAL_REG9X                    16'h0
 */
typedef volatile union _AON_REG8X_FW_GENERAL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_GENERAL_REG8X: 16;
        uint32_t FW_GENERAL_REG9X: 16;
    };
} AON_REG8X_FW_GENERAL_TYPE;

/* 0x414    0x4000_0414
    15:0    R/W FW_GENERAL_REG10X                   16'h0
    31:16   R/W FW_GENERAL_REG11X                   16'h0
 */
typedef volatile union _AON_REG10X_FW_GENERAL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_GENERAL_REG10X: 16;
        uint32_t FW_GENERAL_REG11X: 16;
    };
} AON_REG10X_FW_GENERAL_TYPE;

/* 0x418    0x4000_0418
    15:0    R/W FW_GENERAL_REG12X                   16'h0
    31:16   R/W FW_GENERAL_REG13X                   16'h0
 */
typedef volatile union _AON_REG12X_FW_GENERAL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_GENERAL_REG12X: 16;
        uint32_t FW_GENERAL_REG13X: 16;
    };
} AON_REG12X_FW_GENERAL_TYPE;

/* 0x41C    0x4000_041c
    15:0    R/W FW_GENERAL_REG14X                   16'h0
    31:16   R/W FW_GENERAL_REG15X                   16'h0
 */
typedef volatile union _AON_REG14X_FW_GENERAL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_GENERAL_REG14X: 16;
        uint32_t FW_GENERAL_REG15X: 16;
    };
} AON_REG14X_FW_GENERAL_TYPE;

/* 0x420    0x4000_0420
    15:0    R/W FW_GENERAL_REG16X                   16'h0
    31:16   R/W FW_GENERAL_REG17X                   16'h0
 */
typedef volatile union _AON_REG16X_FW_GENERAL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_GENERAL_REG16X: 16;
        uint32_t FW_GENERAL_REG17X: 16;
    };
} AON_REG16X_FW_GENERAL_TYPE;

/* 0x424    0x4000_0424
    15:0    R/W FW_GENERAL_REG18X                   16'h0
    31:16   R/W FW_GENERAL_REG19X                   16'h0
 */
typedef volatile union _AON_REG18X_FW_GENERAL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_GENERAL_REG18X: 16;
        uint32_t FW_GENERAL_REG19X: 16;
    };
} AON_REG18X_FW_GENERAL_TYPE;

/* 0x428    0x4000_0428
    15:0    R/W FW_GENERAL_REG20X                   16'h0
    31:16   R/W FW_GENERAL_REG21X                   16'h0
 */
typedef volatile union _AON_REG20X_FW_GENERAL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_GENERAL_REG20X: 16;
        uint32_t FW_GENERAL_REG21X: 16;
    };
} AON_REG20X_FW_GENERAL_TYPE;

/* 0x42C    0x4000_042c
    15:0    R/W FW_GENERAL_REG22X                   16'h0
    31:16   R/W FW_GENERAL_REG23X                   16'h0
 */
typedef volatile union _AON_REG22X_FW_GENERAL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_GENERAL_REG22X: 16;
        uint32_t FW_GENERAL_REG23X: 16;
    };
} AON_REG22X_FW_GENERAL_TYPE;

/* 0x4B0    0x4000_04b0
    0       R/W RTC_PF_CNT_START                    1'b0
    1       R/W RTC_PF_CNT_RST                      1'b0
    11:2    R/W RTC_PF_S_COMP_controller_DUMMY0     10'b0
    12      R/W RTC_PF_S0_COMP0_INT_EN              1'b0
    13      R/W RTC_PF_S0_COMP1_INT_EN              1'b0
    14      R/W RTC_PF_S0_COMP2_INT_EN              1'b0
    15      R/W RTC_PF_S1_COMP0_INT_EN              1'b0
    16      R/W RTC_PF_S1_COMP1_INT_EN              1'b0
    17      R/W RTC_PF_S1_COMP2_INT_EN              1'b0
    28:18   R/W RTC_PF_S_COMP_controller_DUMMY1     11'b0
    29      R/W RTC_PF_S0_INT_EN                    1'b0
    30      R/W RTC_PF_S1_INT_EN                    1'b0
    31      R/W RTC_PF_RST                          1'b0
 */
typedef volatile union _AON_RTC_PF_S_COMP_CONTROLLER_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_CNT_START: 1;
        uint32_t RTC_PF_CNT_RST: 1;
        uint32_t RTC_PF_S_COMP_controller_DUMMY0: 10;
        uint32_t RTC_PF_S0_COMP0_INT_EN: 1;
        uint32_t RTC_PF_S0_COMP1_INT_EN: 1;
        uint32_t RTC_PF_S0_COMP2_INT_EN: 1;
        uint32_t RTC_PF_S1_COMP0_INT_EN: 1;
        uint32_t RTC_PF_S1_COMP1_INT_EN: 1;
        uint32_t RTC_PF_S1_COMP2_INT_EN: 1;
        uint32_t RTC_PF_S_COMP_controller_DUMMY1: 11;
        uint32_t RTC_PF_S0_INT_EN: 1;
        uint32_t RTC_PF_S1_INT_EN: 1;
        uint32_t RTC_PF_RST: 1;
    };
    struct
    {
        uint32_t RTC_PF_S_COMP_CONTROLLER_ASSEMBLE0: 12;
        uint32_t RTC_PF_S_COMP_INT_EN: 6;
        uint32_t RTC_PF_S_COMP_CONTROLLER_ASSEMBLE1: 11;
        uint32_t RTC_PF_S_GRP_INT_EN: 2;
        uint32_t RTC_PF_S_COMP_CONTROLLER_ASSEMBLE2: 1;
    };
} AON_RTC_PF_S_COMP_CONTROLLER_REG_TYPE;

/* 0x4B4    0x4000_04b4
    31:0    R/W RTC_PF_S0_COMP0                     32'b0
 */
typedef volatile union _AON_RTC_PF_S0_COMP0_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_S0_COMP0;
    };
} AON_RTC_PF_S0_COMP0_REG_TYPE;

/* 0x4B8    0x4000_04b8
    31:0    R/W RTC_PF_S0_COMP1                     32'b0
 */
typedef volatile union _AON_RTC_PF_S0_COMP1_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_S0_COMP1;
    };
} AON_RTC_PF_S0_COMP1_REG_TYPE;

/* 0x4BC    0x4000_04bc
    31:0    R/W RTC_PF_S0_COMP2                     32'b0
 */
typedef volatile union _AON_RTC_PF_S0_COMP2_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_S0_COMP2;
    };
} AON_RTC_PF_S0_COMP2_REG_TYPE;

/* 0x4C0    0x4000_04c0
    31:0    R/W RTC_PF_S1_COMP0                     32'b0
 */
typedef volatile union _AON_RTC_PF_S1_COMP0_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_S1_COMP0;
    };
} AON_RTC_PF_S1_COMP0_REG_TYPE;

/* 0x4C4    0x4000_04c4
    31:0    R/W RTC_PF_S1_COMP1                     32'b0
 */
typedef volatile union _AON_RTC_PF_S1_COMP1_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_S1_COMP1;
    };
} AON_RTC_PF_S1_COMP1_REG_TYPE;

/* 0x4C8    0x4000_04c8
    31:0    R/W RTC_PF_S1_COMP2                     32'b0
 */
typedef volatile union _AON_RTC_PF_S1_COMP2_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_S1_COMP2;
    };
} AON_RTC_PF_S1_COMP2_REG_TYPE;

/* 0x4CC    0x4000_04cc
    0       R/W RTC_PF_S0_COMP0_MANUAL_INT          1'b0
    1       R/W RTC_PF_S0_COMP1_MANUAL_INT          1'b0
    2       R/W RTC_PF_S0_COMP2_MANUAL_INT          1'b0
    3       R/W RTC_PF_S1_COMP0_MANUAL_INT          1'b0
    4       R/W RTC_PF_S1_COMP1_MANUAL_INT          1'b0
    5       R/W RTC_PF_S1_COMP2_MANUAL_INT          1'b0
    31:6    R/W RTC_PF_S_COMP_MANUAL_INT_DUMMY      26'b0
 */
typedef volatile union _AON_RTC_PF_S_COMP_MANUAL_INT_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_S0_COMP0_MANUAL_INT: 1;
        uint32_t RTC_PF_S0_COMP1_MANUAL_INT: 1;
        uint32_t RTC_PF_S0_COMP2_MANUAL_INT: 1;
        uint32_t RTC_PF_S1_COMP0_MANUAL_INT: 1;
        uint32_t RTC_PF_S1_COMP1_MANUAL_INT: 1;
        uint32_t RTC_PF_S1_COMP2_MANUAL_INT: 1;
        uint32_t RTC_PF_S_COMP_MANUAL_INT_DUMMY: 26;
    };
    struct
    {
        uint32_t RTC_PF_S_COMP_MANUAL_INT: 6;
        uint32_t RTC_PF_S_COMP_MANUAL_INT_ASSEMBLE: 26;
    };
} AON_RTC_PF_S_COMP_MANUAL_INT_REG_TYPE;

/* 0x4D0    0x4000_04d0
    31:0    R   RTC_PF_CNT                          32'b0
 */
typedef volatile union _AON_RTC_PF_CNT_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_CNT;
    };
} AON_RTC_PF_CNT_REG_TYPE;

/* 0x4D4    0x4000_04d4
    0       R/WACRTC_PF_S0_COMP0_INT_CLR             1'b0
    1       R/WACRTC_PF_S0_COMP1_INT_CLR             1'b0
    2       R/WACRTC_PF_S0_COMP2_INT_CLR             1'b0
    3       R/WACRTC_PF_S1_COMP0_INT_CLR             1'b0
    4       R/WACRTC_PF_S1_COMP1_INT_CLR             1'b0
    5       R/WACRTC_PF_S1_COMP2_INT_CLR             1'b0
    31:6    R/W RTC_PF_S_COMP_INT_CLR_DUMMY         26'b0
 */
typedef volatile union _AON_RTC_PF_S_COMP_INT_CLR_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_S0_COMP0_INT_CLR: 1;
        uint32_t RTC_PF_S0_COMP1_INT_CLR: 1;
        uint32_t RTC_PF_S0_COMP2_INT_CLR: 1;
        uint32_t RTC_PF_S1_COMP0_INT_CLR: 1;
        uint32_t RTC_PF_S1_COMP1_INT_CLR: 1;
        uint32_t RTC_PF_S1_COMP2_INT_CLR: 1;
        uint32_t RTC_PF_S_COMP_INT_CLR_DUMMY: 26;
    };
    struct
    {
        uint32_t RTC_PF_S_COMP_INT_CLR: 6;
        uint32_t RTC_PF_S_COMP_INT_CLR_ASSEMBLE: 26;
    };
} AON_RTC_PF_S_COMP_INT_CLR_REG_TYPE;

/* 0x4D8    0x4000_04d8
    0       R/W1CRTC_PF_S0_COMP0_INT_SR              1'b0
    1       R/W1CRTC_PF_S0_COMP1_INT_SR              1'b0
    2       R/W1CRTC_PF_S0_COMP2_INT_SR              1'b0
    3       R/W1CRTC_PF_S1_COMP0_INT_SR              1'b0
    4       R/W1CRTC_PF_S1_COMP1_INT_SR              1'b0
    5       R/W1CRTC_PF_S1_COMP2_INT_SR              1'b0
    31:6    R/W RTC_PF_S_COMP_INT_SR_DUMMY          26'b0
 */
typedef volatile union _AON_RTC_PF_S_COMP_INT_SR_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_S0_COMP0_INT_SR: 1;
        uint32_t RTC_PF_S0_COMP1_INT_SR: 1;
        uint32_t RTC_PF_S0_COMP2_INT_SR: 1;
        uint32_t RTC_PF_S1_COMP0_INT_SR: 1;
        uint32_t RTC_PF_S1_COMP1_INT_SR: 1;
        uint32_t RTC_PF_S1_COMP2_INT_SR: 1;
        uint32_t RTC_PF_S_COMP_INT_SR_DUMMY: 26;
    };
    struct
    {
        uint32_t RTC_PF_S_COMP_INT_SR: 6;
        uint32_t RTC_PF_S_COMP_INT_SR_ASSEMBLE: 26;
    };
} AON_RTC_PF_S_COMP_INT_SR_REG_TYPE;

/* 0x4DC    0x4000_04dc
    31:0    R   RTC_PF_RTL_VERSION                  32'h2112180A
 */
typedef volatile union _AON_RTC_PF_RTL_VERSION_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_RTL_VERSION;
    };
} AON_RTC_PF_RTL_VERSION_REG_TYPE;

/* 0x4E0    0x4000_04e0
    0       R/W RTC_PF_M_COMP0_INT_EN               1'b0
    1       R/W RTC_PF_M_COMP1_INT_EN               1'b0
    2       R/W RTC_PF_M_COMP2_INT_EN               1'b0
    3       R/W RTC_PF_M_COMP3_INT_EN               1'b0
    4       R/W RTC_PF_M_INT_EN                     1'b0
    31:5    R/W RTC_PF_M_COMP_CONTROLLER_DUMMY1     27'b0
 */
typedef volatile union _AON_RTC_PF_M_COMP_CONTROLLER_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_M_COMP0_INT_EN: 1;
        uint32_t RTC_PF_M_COMP1_INT_EN: 1;
        uint32_t RTC_PF_M_COMP2_INT_EN: 1;
        uint32_t RTC_PF_M_COMP3_INT_EN: 1;
        uint32_t RTC_PF_M_INT_EN: 1;
        uint32_t RTC_PF_M_COMP_CONTROLLER_DUMMY1: 27;
    };
    struct
    {
        uint32_t RTC_PF_M_COMP_INT_EN: 4;
        uint32_t RTC_PF_M_GRP_INT_EN: 1;
        uint32_t RTC_PF_M_COMP_CONTROLLER_ASSEMBLE: 27;
    };
} AON_RTC_PF_M_COMP_CONTROLLER_REG_TYPE;

/* 0x4E4    0x4000_04e4
    31:0    R/W RTC_PF_M_COMP0                      32'b0
 */
typedef volatile union _AON_RTC_PF_M_COMP0_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_M_COMP0;
    };
} AON_RTC_PF_M_COMP0_REG_TYPE;

/* 0x4E8    0x4000_04e8
    31:0    R/W RTC_PF_M_COMP1                      32'b0
 */
typedef volatile union _AON_RTC_PF_M_COMP1_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_M_COMP1;
    };
} AON_RTC_PF_M_COMP1_REG_TYPE;

/* 0x4EC    0x4000_04ec
    31:0    R/W RTC_PF_M_COMP2                      32'b0
 */
typedef volatile union _AON_RTC_PF_M_COMP2_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_M_COMP2;
    };
} AON_RTC_PF_M_COMP2_REG_TYPE;

/* 0x4F0    0x4000_04f0
    31:0    R/W RTC_PF_M_COMP3                      32'b0
 */
typedef volatile union _AON_RTC_PF_M_COMP3_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_M_COMP3;
    };
} AON_RTC_PF_M_COMP3_REG_TYPE;

/* 0x4F4    0x4000_04f4
    0       R/WACRTC_PF_M_COMP0_INT_CLR              1'b0
    1       R/WACRTC_PF_M_COMP1_INT_CLR              1'b0
    2       R/WACRTC_PF_M_COMP2_INT_CLR              1'b0
    3       R/WACRTC_PF_M_COMP3_INT_CLR              1'b0
    31:4    R/W RTC_PF_M_COMP_INT_CLR_DUMMY         28'b0
 */
typedef volatile union _AON_RTC_PF_M_COMP_INT_CLR_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_M_COMP0_INT_CLR: 1;
        uint32_t RTC_PF_M_COMP1_INT_CLR: 1;
        uint32_t RTC_PF_M_COMP2_INT_CLR: 1;
        uint32_t RTC_PF_M_COMP3_INT_CLR: 1;
        uint32_t RTC_PF_M_COMP_INT_CLR_DUMMY: 28;
    };
    struct
    {
        uint32_t RTC_PF_M_COMP_INT_CLR: 4;
        uint32_t RTC_PF_M_COMP_INT_CLR_ASSEMBLE: 28;
    };
} AON_RTC_PF_M_COMP_INT_CLR_REG_TYPE;

/* 0x4F8    0x4000_04f8
    0       R/W1CRTC_PF_M_COMP0_INT_SR               1'b0
    1       R/W1CRTC_PF_M_COMP1_INT_SR               1'b0
    2       R/W1CRTC_PF_M_COMP2_INT_SR               1'b0
    3       R/W1CRTC_PF_M_COMP3_INT_SR               1'b0
    31:4    R/W RTC_PF_M_COMP_INT_SR_DUMMY          28'b0
 */
typedef volatile union _AON_RTC_PF_M_COMP_INT_SR_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_M_COMP0_INT_SR: 1;
        uint32_t RTC_PF_M_COMP1_INT_SR: 1;
        uint32_t RTC_PF_M_COMP2_INT_SR: 1;
        uint32_t RTC_PF_M_COMP3_INT_SR: 1;
        uint32_t RTC_PF_M_COMP_INT_SR_DUMMY: 28;
    };
    struct
    {
        uint32_t RTC_PF_M_COMP_INT_SR: 4;
        uint32_t RTC_PF_M_COMP_INT_SR_ASSEMBLE: 28;
    };
} AON_RTC_PF_M_COMP_INT_SR_REG_TYPE;

/* 0x4FC    0x4000_04fc
    0       R/W RTC_PF_WK_COMP_WK_EN                1'b0
    1       R/W RTC_PF_WK_WK_EN                     1'b0
    31:2    R/W RTC_PF_WK_COMP_CONTROLLER_DUMMY1    30'b0
 */
typedef volatile union _AON_RTC_PF_WK_COMP_CONTROLLER_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_WK_COMP_WK_EN: 1;
        uint32_t RTC_PF_WK_WK_EN: 1;
        uint32_t RTC_PF_WK_COMP_CONTROLLER_DUMMY1: 30;
    };
} AON_RTC_PF_WK_COMP_CONTROLLER_REG_TYPE;

/* 0x500    0x4000_0500
    31:0    R/W RTC_PF_WK_COMP                      32'b0
 */
typedef volatile union _AON_RTC_PF_WK_COMP_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_WK_COMP;
    };
} AON_RTC_PF_WK_COMP_REG_TYPE;

/* 0x504    0x4000_0504
    0       R/WACRTC_PF_WK_COMP_WK_CLR               1'b0
    31:1    R/W RTC_PF_WK_COMP_WK_CLR_DUMMY         31'b0
 */
typedef volatile union _AON_RTC_PF_WK_COMP_WK_CLR_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_WK_COMP_WK_CLR: 1;
        uint32_t RTC_PF_WK_COMP_WK_CLR_DUMMY: 31;
    };
} AON_RTC_PF_WK_COMP_WK_CLR_REG_TYPE;

/* 0x508    0x4000_0508
    0       R/W1CRTC_PF_WK_COMP_WK_SR                1'b0
    31:1    R/W RTC_PF_WK_COMP_WK_SR_DUMMY          31'b0
 */
typedef volatile union _AON_RTC_PF_WK_COMP_WK_SR_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PF_WK_COMP_WK_SR: 1;
        uint32_t RTC_PF_WK_COMP_WK_SR_DUMMY: 31;
    };
} AON_RTC_PF_WK_COMP_WK_SR_REG_TYPE;

/* 0x580    0x4000_0580
    7:0     R/W reg_dsp1_cache_sys_ram              8'h0
    15:8    R/W MEMORY_REG1X_DUMMY1                 8'h0
    31:16   R/W reg_com2_share_en                   16'hffff
 */
typedef volatile union _AON_MEMORY_REG1X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_dsp1_cache_sys_ram: 8;
        uint32_t MEMORY_REG1X_DUMMY1: 8;
        uint32_t reg_com2_share_en: 16;
    };
} AON_MEMORY_REG1X_TYPE;

/* 0x584    0x4000_0584
    19:0    R/W reg_dsp1_sys_ram                    20'h0
    31:20   R/W reg_dsp2_sys_ram                    12'h0
 */
typedef volatile union _AON_MEMORY_REG2X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_dsp1_sys_ram: 20;
        uint32_t reg_dsp2_sys_ram: 12;
    };
} AON_MEMORY_REG2X_TYPE;

/* 0x588    0x4000_0588
    8:0     R   RSVD                                9'b1
    9       R/W dsp_sys_vsel                        1'b1
    10      R/W dsp_sys_DATA_vsel                   1'b1
    11      R/W log_vsel                            1'b1
    12      R/W ipc_vsel                            1'b1
    13      R/W gpu_vsel                            1'b1
    14      R/W pke_vsel                            1'b1
    15      R/W vadbuf_vsel                         1'b1
    16      R   RSVD                                1'b1
    17      R   RSVD                                1'b1
    18      R/W mipi_vsel                           1'b1
    19      R/W display_vsel                        1'b1
    20      R/W usb_vsel                            1'b1
    21      R/W sdio_vsel                           1'b1
    22      R/W fft_vsel                            1'b1
    23      R/W dsp_vsel                            1'b1
    24      R/W dsp_DATA_vsel                       1'b1
    25      R/W RSVD                                1'b1
    26      R/W data_vsel                           1'b1
    27      R   RSVD                                1'b1
    28      R   RSVD                                1'b1
    29      R/W km4_vsel                            1'b1
    30      R   RSVD                                1'b1
    31      R/W km4_sensor_mode                     1'b0
 */
typedef volatile union _AON_REG_KM4_ROM_RAM_VSEL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_6: 9;
        uint32_t dsp_sys_vsel: 1;
        uint32_t dsp_sys_DATA_vsel: 1;
        uint32_t log_vsel: 1;
        uint32_t ipc_vsel: 1;
        uint32_t gpu_vsel: 1;
        uint32_t pke_vsel: 1;
        uint32_t vadbuf_vsel: 1;
        uint32_t RSVD_5: 1;
        uint32_t RSVD_4: 1;
        uint32_t mipi_vsel: 1;
        uint32_t display_vsel: 1;
        uint32_t usb_vsel: 1;
        uint32_t sdio_vsel: 1;
        uint32_t fft_vsel: 1;
        uint32_t dsp_vsel: 1;
        uint32_t dsp_DATA_vsel: 1;
        uint32_t RSVD_3: 1;
        uint32_t data_vsel: 1;
        uint32_t RSVD_2: 1;
        uint32_t RSVD_1: 1;
        uint32_t km4_vsel: 1;
        uint32_t RSVD: 1;
        uint32_t km4_sensor_mode: 1;
    };
} AON_REG_KM4_ROM_RAM_VSEL_TYPE;

/* 0x58C    0x4000_058c
    26:0    R   RSVD                                27'b1
    27      R/W phy_vsel                            1'b0
    28      R/W mac_vsel                            1'b0
    29      R/W buf_vsel                            1'b0
    30      R/W kr0_vsel                            1'b1
    31      R/W km0_vsel                            1'b0
 */
typedef volatile union _AON_REG_KM0_KR0_ROM_RAM_VSEL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD: 27;
        uint32_t phy_vsel: 1;
        uint32_t mac_vsel: 1;
        uint32_t buf_vsel: 1;
        uint32_t kr0_vsel: 1;
        uint32_t km0_vsel: 1;
    };
} AON_REG_KM0_KR0_ROM_RAM_VSEL_TYPE;

/* 0x590    0x4000_0590
    15:0    R/W reg_otp_ctrl_w4_loader_1            16'd2
    31:16   R/W reg_otp_ctrl_w4_loader_0            16'd1
 */
typedef volatile union _AON_AON_LOADER_TIMER0_TIMER1_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_otp_ctrl_w4_loader_1: 16;
        uint32_t reg_otp_ctrl_w4_loader_0: 16;
    };
} AON_AON_LOADER_TIMER0_TIMER1_TYPE;

/* 0x594    0x4000_0594
    15:0    R/W reg_otp_ctrl_w5_loader_1            16'd1
    31:16   R/W reg_otp_ctrl_w5_loader_0            16'd1
 */
typedef volatile union _AON_AON_LOADER_TIMER2_TIMER3_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_otp_ctrl_w5_loader_1: 16;
        uint32_t reg_otp_ctrl_w5_loader_0: 16;
    };
} AON_AON_LOADER_TIMER2_TIMER3_TYPE;

/* 0x598    0x4000_0598
    15:0    R/W reg_otp_ctrl_w9_loader_1            16'd17
    31:16   R/W reg_otp_ctrl_w9_loader_0            16'd1
 */
typedef volatile union _AON_AON_LOADER_TIMER4_TIMER5_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_otp_ctrl_w9_loader_1: 16;
        uint32_t reg_otp_ctrl_w9_loader_0: 16;
    };
} AON_AON_LOADER_TIMER4_TIMER5_TYPE;

/* 0x59C    0x4000_059c
    0       R/W r_ram_ret1n                         1'h1
    1       R/W r_bist_mem_speed_mode               1'h0
    10:2    R   RSVD                                9'h0
    11      R/W mem_dsp1_vsel_sync_en               1'h1
    12      R/W mem_dsp2_vsel_sync_en               1'h1
    13      R/W ram_nna_vsel_sync_en                1'h1
    14      R/W mem_ancdsp_sys_vsel_sync_en         1'h1
    15      R/W ram_dsp_sys_vsel_sync_en            1'h1
    31:16   R   RSVD                                16'h0
 */
typedef volatile union _AON_MEM_VSEL_SYNC_EN_MISC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_ram_ret1n: 1;
        uint32_t r_bist_mem_speed_mode: 1;
        uint32_t RSVD_1: 9;
        uint32_t mem_dsp1_vsel_sync_en: 1;
        uint32_t mem_dsp2_vsel_sync_en: 1;
        uint32_t ram_nna_vsel_sync_en: 1;
        uint32_t mem_ancdsp_sys_vsel_sync_en: 1;
        uint32_t ram_dsp_sys_vsel_sync_en: 1;
        uint32_t RSVD: 16;
    };
} AON_MEM_VSEL_SYNC_EN_MISC_TYPE;

/* 0x5A0    0x4000_05a0
    3:0     R/W r_LS_dsp_drom                       4'h0
    13:4    R/W r_LS_dsp_irom                       10'h0
    14      R/W r_LS_pke_rom                        1'h0
    16:15   R/W r_LS_kr0_rom                        2'h0
    22:17   R/W r_LS_km0_rom                        6'h0
    30:23   R/W r_PGEN_km4_rom                      8'h0
    31      R   RSVD                                1'h0
 */
typedef volatile union _AON_ROM_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_LS_dsp_drom: 4;
        uint32_t r_LS_dsp_irom: 10;
        uint32_t r_LS_pke_rom: 1;
        uint32_t r_LS_kr0_rom: 2;
        uint32_t r_LS_km0_rom: 6;
        uint32_t r_PGEN_km4_rom: 8;
        uint32_t RSVD: 1;
    };
} AON_ROM_TYPE;

/* 0x5A4    0x4000_05a4
    1:0     R/W r_SD_kr0_rom                        2'h0
    31:2    R   RSVD                                30'h0
 */
typedef volatile union _AON_ROM_SD_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_SD_kr0_rom: 2;
        uint32_t RSVD: 30;
    };
} AON_ROM_SD_TYPE;

/* 0x5B0    0x4000_05b0
    5:0     R/W reg_rom_km0_hv                      6'b010010
    15:6    R   RSVD                                10'b0
    21:16   R/W reg_rom_km4_hv                      6'b001010
    31:22   R   RSVD                                10'b0
 */
typedef volatile union _AON_REG_ROM_KM4_KM0_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_rom_km0_hv: 6;
        uint32_t RSVD_1: 10;
        uint32_t reg_rom_km4_hv: 6;
        uint32_t RSVD: 10;
    };
} AON_REG_ROM_KM4_KM0_HV_TYPE;

/* 0x5B4    0x4000_05b4
    5:0     R/W reg_rom_dsp_hv                      6'b010011
    11:6    R/W reg_rom_pke_hv                      6'b010011
    15:12   R   RSVD                                4'b0
    21:16   R/W reg_rom_kr0_hv                      6'b010011
    31:22   R   RSVD                                10'b0
 */
typedef volatile union _AON_REG_ROM_KR0_DSP_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_rom_dsp_hv: 6;
        uint32_t reg_rom_pke_hv: 6;
        uint32_t RSVD_1: 4;
        uint32_t reg_rom_kr0_hv: 6;
        uint32_t RSVD: 10;
    };
} AON_REG_ROM_KR0_DSP_HV_TYPE;

/* 0x5B8    0x4000_05b8
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_km4_hv                      14'h10D
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_KM4_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_km4_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_KM4_HV_TYPE;

/* 0x5BC    0x4000_05bc
    15:0    R   RSVD                                2'b0
    29:16   R/W reg_ram_km4_rf_hv                   14'h1A8
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_KM4_RF_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_km4_rf_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_KM4_RF_HV_TYPE;

/* 0x5C0    0x4000_05c0
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_km0_hv                      14'h58E
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_KM0_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_km0_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_KM0_HV_TYPE;

/* 0x5C4    0x4000_05c4
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_km0_rf_hv                   14'h608
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_KM0_RF_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_km0_rf_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_KM0_RF_HV_TYPE;

/* 0x5C8    0x4000_05c8
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_kr0_pmc_hv                  14'h10D
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_KR0_PMC_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_kr0_pmc_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_KR0_PMC_HV_TYPE;

/* 0x5CC    0x4000_05cc
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_kr0_ipc_hv                  14'h10D
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_KR0_IPC_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_kr0_ipc_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_KR0_IPC_HV_TYPE;

/* 0x5D0    0x4000_05d0
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_kr0_log_hv                  14'h10D
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_KR0_LOG_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_kr0_log_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_KR0_LOG_HV_TYPE;

/* 0x5D4    0x4000_05d4
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_data_hv                     14'h10D
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_DATA_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_data_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_DATA_HV_TYPE;

/* 0x5D8    0x4000_05d8
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_dsp_sys_hv                  14'h10D
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_DSP_SYS_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_dsp_sys_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_DSP_SYS_HV_TYPE;

/* 0x5DC    0x4000_05dc
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_buf_hv                      14'h10D
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_BUF_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_buf_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_BUF_HV_TYPE;

/* 0x5E0    0x4000_05e0
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_dsp_DATA_hv                 14'h10D
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_DSP_DATA_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_dsp_DATA_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_DSP_DATA_HV_TYPE;

/* 0x5E4    0x4000_05e4
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_dsp_hv                      14'h10D
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_DSP_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_dsp_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_DSP_HV_TYPE;

/* 0x5E8    0x4000_05e8
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_dsp_rf_hv                   14'h1A8
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_DSP_RF_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_dsp_rf_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_DSP_RF_HV_TYPE;

/* 0x5EC    0x4000_05ec
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_fft_rf_hv                   14'h1A8
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_FFT_RF_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_fft_rf_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_FFT_RF_HV_TYPE;

/* 0x5F0    0x4000_05f0
    15:0    R   RSVD                                16'b0
    30:16   R/W reg_ram_sdio_hv                     15'hE83
    31      R   RSVD                                1'b0
 */
typedef volatile union _AON_REG_RAM_SDIO_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_sdio_hv: 15;
        uint32_t RSVD: 1;
    };
} AON_REG_RAM_SDIO_HV_TYPE;

/* 0x5F4    0x4000_05f4
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_usb_hv                      14'h10D
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_USB_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_usb_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_USB_HV_TYPE;

/* 0x5F8    0x4000_05f8
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_display_rf_hv               14'h82
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_DISPLAY_RF_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_display_rf_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_DISPLAY_RF_HV_TYPE;

/* 0x5FC    0x4000_05fc
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_mipi_rf_hv                  14'h82
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_MIPI_RF_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_mipi_rf_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_MIPI_RF_HV_TYPE;

/* 0x600    0x4000_0600
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_mac_hv                      14'h58E
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_MAC_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_mac_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_MAC_HV_TYPE;

/* 0x604    0x4000_0604
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_mac_rf_hv                   14'h608
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_MAC_RF_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_mac_rf_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_MAC_RF_HV_TYPE;

/* 0x608    0x4000_0608
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_mdm_hv                      14'h58E
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_MDM_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_mdm_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_MDM_HV_TYPE;

/* 0x60C    0x4000_060c
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_mdm_rf_hv                   14'h608
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_MDM_RF_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_mdm_rf_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_MDM_RF_HV_TYPE;

/* 0x610    0x4000_0610
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_vadbuf_hv                   14'h10D
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_VADBUF_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_vadbuf_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_VADBUF_HV_TYPE;

/* 0x614    0x4000_0614
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_pke_rf_hv                   14'h82
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_PKE_RF_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_pke_rf_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_PKE_RF_HV_TYPE;

/* 0x618    0x4000_0618
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_gpu_rf_hv                   14'h1A8
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_GPU_RF_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_gpu_rf_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_GPU_RF_HV_TYPE;

/* 0x61C    0x4000_061c
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_gpu_rf_2p_hv                14'h82
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_GPU_RF_2P_HV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_gpu_rf_2p_hv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_GPU_RF_2P_HV_TYPE;

/* 0x630    0x4000_0630
    5:0     R/W reg_rom_km0_lv                      6'b010010
    15:6    R   RSVD                                10'b0
    21:16   R/W reg_rom_km4_lv_0p7v                 6'b001100
    27:22   R/W reg_rom_km4_lv                      6'b001011
    31:28   R   RSVD                                4'b0
 */
typedef volatile union _AON_REG_ROM_KM4_KM0_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_rom_km0_lv: 6;
        uint32_t RSVD_1: 10;
        uint32_t reg_rom_km4_lv_0p7v: 6;
        uint32_t reg_rom_km4_lv: 6;
        uint32_t RSVD: 4;
    };
} AON_REG_ROM_KM4_KM0_LV_TYPE;

/* 0x634    0x4000_0634
    5:0     R/W reg_rom_dsp_lv                      6'b010010
    11:6    R/W reg_rom_pke_lv                      6'b010010
    15:12   R   RSVD                                4'b0
    21:16   R/W reg_rom_kr0_lv                      6'b010011
    31:22   R   RSVD                                10'b0
 */
typedef volatile union _AON_REG_ROM_KR0_DSP_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_rom_dsp_lv: 6;
        uint32_t reg_rom_pke_lv: 6;
        uint32_t RSVD_1: 4;
        uint32_t reg_rom_kr0_lv: 6;
        uint32_t RSVD: 10;
    };
} AON_REG_ROM_KR0_DSP_LV_TYPE;

/* 0x638    0x4000_0638
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_km4_lv                      14'h58E
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_KM4_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_km4_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_KM4_LV_TYPE;

/* 0x63C    0x4000_063c
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_km4_rf_lv                   14'h608
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_KM4_RF_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_km4_rf_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_KM4_RF_LV_TYPE;

/* 0x640    0x4000_0640
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_km4_lv_0p7v                 14'h58D
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_KM4_LV_0P7V_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_km4_lv_0p7v: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_KM4_LV_0P7V_TYPE;

/* 0x644    0x4000_0644
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_km4_rf_lv_0p7v              14'h588
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_KM4_RF_LV_0P7V_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_km4_rf_lv_0p7v: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_KM4_RF_LV_0P7V_TYPE;

/* 0x648    0x4000_0648
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_km0_lv                      14'h58E
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_KM0_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_km0_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_KM0_LV_TYPE;

/* 0x64C    0x4000_064c
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_km0_rf_lv                   14'h608
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_KM0_RF_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_km0_rf_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_KM0_RF_LV_TYPE;

/* 0x650    0x4000_0650
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_kr0_pmc_lv                  14'h10D
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_KR0_PMC_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_kr0_pmc_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_KR0_PMC_LV_TYPE;

/* 0x654    0x4000_0654
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_kr0_ipc_lv                  14'h10D
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_KR0_IPC_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_kr0_ipc_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_KR0_IPC_LV_TYPE;

/* 0x658    0x4000_0658
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_kr0_log_lv                  14'h10D
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_KR0_LOG_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_kr0_log_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_KR0_LOG_LV_TYPE;

/* 0x65C    0x4000_065c
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_data_lv                     14'h58E
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_DATA_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_data_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_DATA_LV_TYPE;

/* 0x660    0x4000_0660
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_dsp_sys_lv                  14'h58E
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_DSP_SYS_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_dsp_sys_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_DSP_SYS_LV_TYPE;

/* 0x664    0x4000_0664
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_buf_lv                      14'h58E
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_BUF_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_buf_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_BUF_LV_TYPE;

/* 0x668    0x4000_0668
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_dsp_DATA_lv                 14'h58E
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_DSP_DATA_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_dsp_DATA_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_DSP_DATA_LV_TYPE;

/* 0x66C    0x4000_066c
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_dsp_lv                      14'h58E
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_DSP_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_dsp_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_DSP_LV_TYPE;

/* 0x670    0x4000_0670
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_dsp_rf_lv                   14'h608
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_DSP_RF_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_dsp_rf_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_DSP_RF_LV_TYPE;

/* 0x674    0x4000_0674
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_fft_rf_lv                   14'h608
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_FFT_RF_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_fft_rf_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_FFT_RF_LV_TYPE;

/* 0x678    0x4000_0678
    15:0    R   RSVD                                16'b0
    30:16   R/W reg_ram_sdio_lv                     15'h128c
    31      R   RSVD                                1'b0
 */
typedef volatile union _AON_REG_RAM_SDIO_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_sdio_lv: 15;
        uint32_t RSVD: 1;
    };
} AON_REG_RAM_SDIO_LV_TYPE;

/* 0x67C    0x4000_067c
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_usb_lv                      14'h58E
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_USB_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_usb_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_USB_LV_TYPE;

/* 0x680    0x4000_0680
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_display_rf_lv               14'h184
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_DISPLAY_RF_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_display_rf_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_DISPLAY_RF_LV_TYPE;

/* 0x684    0x4000_0684
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_mipi_rf_lv                  14'h184
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_MIPI_RF_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_mipi_rf_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_MIPI_RF_LV_TYPE;

/* 0x688    0x4000_0688
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_mac_lv                      14'h58E
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_MAC_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_mac_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_MAC_LV_TYPE;

/* 0x68C    0x4000_068c
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_mac_rf_lv                   14'h608
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_MAC_RF_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_mac_rf_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_MAC_RF_LV_TYPE;

/* 0x690    0x4000_0690
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_mdm_lv                      14'h58E
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_MDM_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_mdm_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_MDM_LV_TYPE;

/* 0x694    0x4000_0694
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_mdm_rf_lv                   14'h608
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_MDM_RF_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_mdm_rf_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_MDM_RF_LV_TYPE;

/* 0x698    0x4000_0698
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_vadbuf_lv                   14'h58E
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_VADBUF_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_vadbuf_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_VADBUF_LV_TYPE;

/* 0x69C    0x4000_069c
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_pke_rf_lv                   14'h184
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_PKE_RF_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_pke_rf_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_PKE_RF_LV_TYPE;

/* 0x6A0    0x4000_06a0
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_gpu_rf_lv                   14'h608
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_GPU_RF_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_gpu_rf_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_GPU_RF_LV_TYPE;

/* 0x6A4    0x4000_06a4
    15:0    R   RSVD                                16'b0
    29:16   R/W reg_ram_gpu_rf_2p_lv                14'h184
    31:30   R   RSVD                                2'b0
 */
typedef volatile union _AON_REG_RAM_GPU_RF_2P_LV_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RSVD_1: 16;
        uint32_t reg_ram_gpu_rf_2p_lv: 14;
        uint32_t RSVD: 2;
    };
} AON_REG_RAM_GPU_RF_2P_LV_TYPE;

/* 0x6B0    0x4000_06b0
    0       R/W r_PGEN_kr0_log_iso0                 1'h0
    2:1     R/W r_PGEN_kr0_ipc_iso0                 2'h0
    3       R/W r_PGEN_kr0_pmc_iso0                 1'h0
    14:4    R   RSVD                                11'h0
    15      R/W r_PGEN_km0_dc_data_iso0             1'h0
    16      R/W r_PGEN_km0_dc_tag_iso0              1'h0
    17      R/W r_PGEN_km0_ic_data_iso0             1'h0
    18      R/W r_PGEN_km0_ic_tag_iso0              1'h0
    20:19   R/W r_PGEN_km0_dtcm1_iso0               2'h0
    24:21   R/W r_PGEN_km0_dtcm0_iso0               4'h0
    31:25   R/W r_PGEN_km0_itcm1_iso0               7'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO0_3_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_kr0_log_iso0: 1;
        uint32_t r_PGEN_kr0_ipc_iso0: 2;
        uint32_t r_PGEN_kr0_pmc_iso0: 1;
        uint32_t RSVD: 11;
        uint32_t r_PGEN_km0_dc_data_iso0: 1;
        uint32_t r_PGEN_km0_dc_tag_iso0: 1;
        uint32_t r_PGEN_km0_ic_data_iso0: 1;
        uint32_t r_PGEN_km0_ic_tag_iso0: 1;
        uint32_t r_PGEN_km0_dtcm1_iso0: 2;
        uint32_t r_PGEN_km0_dtcm0_iso0: 4;
        uint32_t r_PGEN_km0_itcm1_iso0: 7;
    };
} AON_ARM_SRAM_PGEN_ISO0_3_TYPE;

/* 0x6B4    0x4000_06b4
    15:0    R/W r_PGEN_data_iso0                    16'h0
    19:16   R/W r_PGEN_buf_iso0                     4'h0
    31:20   R   RSVD                                12'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO0_4_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_data_iso0: 16;
        uint32_t r_PGEN_buf_iso0: 4;
        uint32_t RSVD: 12;
    };
} AON_ARM_SRAM_PGEN_ISO0_4_TYPE;

/* 0x6B8    0x4000_06b8
    24:0    R/W r_PGEN_dsp_data_ram_iso0            25'h0
    31:25   R   RSVD                                7'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO0_5_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_dsp_data_ram_iso0: 25;
        uint32_t RSVD: 7;
    };
} AON_ARM_SRAM_PGEN_ISO0_5_TYPE;

/* 0x6BC    0x4000_06bc
    24:0    R/W r_PGEN_dsp_ram_iso0                 25'h0
    31:25   R   RSVD                                7'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO0_6_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_dsp_ram_iso0: 25;
        uint32_t RSVD: 7;
    };
} AON_ARM_SRAM_PGEN_ISO0_6_TYPE;

/* 0x6C0    0x4000_06c0
    0       R/W r_PGEN_dsp_dcache_prefetch_iso0     1'h0
    3:1     R/W r_PGEN_dsp_dcache_tag_iso0          3'h0
    6:4     R/W r_PGEN_dsp_dcache_data_iso0         3'h0
    17:7    R   RSVD                                11'h0
    23:18   R/W r_PGEN_fft_iso0                     6'h0
    26:24   R/W r_PGEN_dsp_icache_tag_iso0          3'h0
    29:27   R/W r_PGEN_dsp_icache_data_iso0         3'h0
    31:30   R   RSVD                                2'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO0_7_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_dsp_dcache_prefetch_iso0: 1;
        uint32_t r_PGEN_dsp_dcache_tag_iso0: 3;
        uint32_t r_PGEN_dsp_dcache_data_iso0: 3;
        uint32_t RSVD_1: 11;
        uint32_t r_PGEN_fft_iso0: 6;
        uint32_t r_PGEN_dsp_icache_tag_iso0: 3;
        uint32_t r_PGEN_dsp_icache_data_iso0: 3;
        uint32_t RSVD: 2;
    };
} AON_ARM_SRAM_PGEN_ISO0_7_TYPE;

/* 0x6C4    0x4000_06c4
    1:0     R/W r_PGEN_sdio_iso0                    2'h0
    2       R/W r_PGEN_usb_iso0                     1'h0
    5:3     R/W r_PGEN_mipi_iso0                    3'h0
    7:6     R/W r_PGEN_display_iso0                 2'h0
    20:8    R/W r_PGEN_mac_iso0                     13'h0
    29:21   R/W r_PGEN_phy_iso0                     9'h0
    31:30   R   RSVD                                2'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO0_8_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_sdio_iso0: 2;
        uint32_t r_PGEN_usb_iso0: 1;
        uint32_t r_PGEN_mipi_iso0: 3;
        uint32_t r_PGEN_display_iso0: 2;
        uint32_t r_PGEN_mac_iso0: 13;
        uint32_t r_PGEN_phy_iso0: 9;
        uint32_t RSVD: 2;
    };
} AON_ARM_SRAM_PGEN_ISO0_8_TYPE;

/* 0x6C8    0x4000_06c8
    1:0     R/W r_PGEN_vadbuf_iso0                  2'h0
    4:2     R/W r_PGEN_pke_iso0                     3'h0
    31:5    R   RSVD                                27'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO0_9_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_vadbuf_iso0: 2;
        uint32_t r_PGEN_pke_iso0: 3;
        uint32_t RSVD: 27;
    };
} AON_ARM_SRAM_PGEN_ISO0_9_TYPE;

/* 0x6CC    0x4000_06cc
    29:0    R/W r_PGEN_gpu_iso0                     30'h0
    31:30   R   RSVD                                2'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO0_10_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_gpu_iso0: 30;
        uint32_t RSVD: 2;
    };
} AON_ARM_SRAM_PGEN_ISO0_10_TYPE;

/* 0x6D0    0x4000_06d0
    15:0    R/W r_PGEN_dsp_repair_ram_iso0          16'h0
    31:16   R   RSVD                                16'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO0_11_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_dsp_repair_ram_iso0: 16;
        uint32_t RSVD: 16;
    };
} AON_ARM_SRAM_PGEN_ISO0_11_TYPE;

/* 0x6D4    0x4000_06d4
    3:0     R/W r_PGEN_dsp_sys_ram_iso0             4'h0
    31:4    R   RSVD                                28'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO0_12_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_dsp_sys_ram_iso0: 4;
        uint32_t RSVD: 28;
    };
} AON_ARM_SRAM_PGEN_ISO0_12_TYPE;

/* 0x6F0    0x4000_06f0
    0       R/W r_PGEN_kr0_log_iso1                 1'h0
    2:1     R/W r_PGEN_kr0_ipc_iso1                 2'h0
    3       R/W r_PGEN_kr0_pmc_iso1                 1'h0
    14:4    R   RSVD                                11'h0
    15      R/W r_PGEN_km0_dc_data_iso1             1'h0
    16      R/W r_PGEN_km0_dc_tag_iso1              1'h0
    17      R/W r_PGEN_km0_ic_data_iso1             1'h0
    18      R/W r_PGEN_km0_ic_tag_iso1              1'h0
    20:19   R/W r_PGEN_km0_dtcm1_iso1               2'h0
    24:21   R/W r_PGEN_km0_dtcm0_iso1               4'h0
    31:25   R/W r_PGEN_km0_itcm1_iso1               7'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO1_3_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_kr0_log_iso1: 1;
        uint32_t r_PGEN_kr0_ipc_iso1: 2;
        uint32_t r_PGEN_kr0_pmc_iso1: 1;
        uint32_t RSVD: 11;
        uint32_t r_PGEN_km0_dc_data_iso1: 1;
        uint32_t r_PGEN_km0_dc_tag_iso1: 1;
        uint32_t r_PGEN_km0_ic_data_iso1: 1;
        uint32_t r_PGEN_km0_ic_tag_iso1: 1;
        uint32_t r_PGEN_km0_dtcm1_iso1: 2;
        uint32_t r_PGEN_km0_dtcm0_iso1: 4;
        uint32_t r_PGEN_km0_itcm1_iso1: 7;
    };
} AON_ARM_SRAM_PGEN_ISO1_3_TYPE;

/* 0x6F4    0x4000_06f4
    15:0    R/W r_PGEN_data_iso1                    16'h0
    19:16   R/W r_PGEN_buf_iso1                     4'h0
    31:20   R   RSVD                                12'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO1_4_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_data_iso1: 16;
        uint32_t r_PGEN_buf_iso1: 4;
        uint32_t RSVD: 12;
    };
} AON_ARM_SRAM_PGEN_ISO1_4_TYPE;

/* 0x6F8    0x4000_06f8
    24:0    R/W r_PGEN_dsp_data_ram_iso1            25'h0
    31:25   R   RSVD                                7'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO1_5_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_dsp_data_ram_iso1: 25;
        uint32_t RSVD: 7;
    };
} AON_ARM_SRAM_PGEN_ISO1_5_TYPE;

/* 0x6FC    0x4000_06fc
    24:0    R/W r_PGEN_dsp_ram_iso1                 25'h0
    31:25   R   RSVD                                7'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO1_6_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_dsp_ram_iso1: 25;
        uint32_t RSVD: 7;
    };
} AON_ARM_SRAM_PGEN_ISO1_6_TYPE;

/* 0x700    0x4000_0700
    0       R/W r_PGEN_dsp_dcache_prefetch_iso1     1'h0
    3:1     R/W r_PGEN_dsp_dcache_tag_iso1          3'h0
    6:4     R/W r_PGEN_dsp_dcache_data_iso1         3'h0
    17:7    R   RSVD                                11'h0
    23:18   R/W r_PGEN_fft_iso1                     6'h0
    26:24   R/W r_PGEN_dsp_icache_tag_iso1          3'h0
    29:27   R/W r_PGEN_dsp_icache_data_iso1         3'h0
    31:30   R   RSVD                                2'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO1_7_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_dsp_dcache_prefetch_iso1: 1;
        uint32_t r_PGEN_dsp_dcache_tag_iso1: 3;
        uint32_t r_PGEN_dsp_dcache_data_iso1: 3;
        uint32_t RSVD_1: 11;
        uint32_t r_PGEN_fft_iso1: 6;
        uint32_t r_PGEN_dsp_icache_tag_iso1: 3;
        uint32_t r_PGEN_dsp_icache_data_iso1: 3;
        uint32_t RSVD: 2;
    };
} AON_ARM_SRAM_PGEN_ISO1_7_TYPE;

/* 0x704    0x4000_0704
    1:0     R/W r_PGEN_sdio_iso1                    2'h0
    2       R/W r_PGEN_usb_iso1                     1'h0
    5:3     R/W r_PGEN_mipi_iso1                    3'h0
    7:6     R/W r_PGEN_display_iso1                 2'h0
    20:8    R/W r_PGEN_mac_iso1                     13'h0
    29:21   R/W r_PGEN_phy_iso1                     9'h0
    31:30   R   RSVD                                2'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO1_8_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_sdio_iso1: 2;
        uint32_t r_PGEN_usb_iso1: 1;
        uint32_t r_PGEN_mipi_iso1: 3;
        uint32_t r_PGEN_display_iso1: 2;
        uint32_t r_PGEN_mac_iso1: 13;
        uint32_t r_PGEN_phy_iso1: 9;
        uint32_t RSVD: 2;
    };
} AON_ARM_SRAM_PGEN_ISO1_8_TYPE;

/* 0x708    0x4000_0708
    1:0     R/W r_PGEN_vadbuf_iso1                  2'h0
    4:2     R/W r_PGEN_pke_iso1                     3'h0
    31:5    R   RSVD                                27'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO1_9_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_vadbuf_iso1: 2;
        uint32_t r_PGEN_pke_iso1: 3;
        uint32_t RSVD: 27;
    };
} AON_ARM_SRAM_PGEN_ISO1_9_TYPE;

/* 0x70C    0x4000_070c
    29:0    R/W r_PGEN_gpu_iso1                     30'h0
    31:30   R   RSVD                                2'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO1_10_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_gpu_iso1: 30;
        uint32_t RSVD: 2;
    };
} AON_ARM_SRAM_PGEN_ISO1_10_TYPE;

/* 0x710    0x4000_0710
    15:0    R/W r_PGEN_dsp_repair_ram_iso1          16'h0
    31:16   R   RSVD                                16'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO1_11_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_dsp_repair_ram_iso1: 16;
        uint32_t RSVD: 16;
    };
} AON_ARM_SRAM_PGEN_ISO1_11_TYPE;

/* 0x714    0x4000_0714
    3:0     R/W r_PGEN_dsp_sys_ram_iso1             4'h0
    31:4    R   RSVD                                28'h0
 */
typedef volatile union _AON_ARM_SRAM_PGEN_ISO1_12_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_PGEN_dsp_sys_ram_iso1: 4;
        uint32_t RSVD: 28;
    };
} AON_ARM_SRAM_PGEN_ISO1_12_TYPE;

/* 0x720    0x4000_0720
    7:0     R/W r_RET1N_km4_dtcm1_iso0              8'hff
    15:8    R/W r_RET1N_km4_dtcm0_iso0              8'hff
    31:16   R/W r_RET1N_km4_itcm1_iso0              16'hffff
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO0_1_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_km4_dtcm1_iso0: 8;
        uint32_t r_RET1N_km4_dtcm0_iso0: 8;
        uint32_t r_RET1N_km4_itcm1_iso0: 16;
    };
} AON_ARM_SRAM_RET1N_ISO0_1_TYPE;

/* 0x724    0x4000_0724
    1:0     R/W r_RET1N_km4_dc_data_iso0            2'h3
    2       R/W r_RET1N_km4_dc_tag_iso0             1'h1
    6:3     R/W r_RET1N_km4_ic_data_iso0            4'hf
    7       R/W r_RET1N_km4_ic_tag_iso0             1'h1
    31:8    R   RSVD                                24'hf_ffff
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO0_2_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_km4_dc_data_iso0: 2;
        uint32_t r_RET1N_km4_dc_tag_iso0: 1;
        uint32_t r_RET1N_km4_ic_data_iso0: 4;
        uint32_t r_RET1N_km4_ic_tag_iso0: 1;
        uint32_t RSVD: 24;
    };
} AON_ARM_SRAM_RET1N_ISO0_2_TYPE;

/* 0x728    0x4000_0728
    0       R/W r_RET1N_kr0_log_iso0                1'h1
    2:1     R/W r_RET1N_kr0_ipc_iso0                2'h3
    3       R/W r_RET1N_kr0_pmc_iso0                1'h1
    14:4    R   RSVD                                11'h7ff
    15      R/W r_RET1N_km0_dc_data_iso0            1'h1
    16      R/W r_RET1N_km0_dc_tag_iso0             1'h1
    17      R/W r_RET1N_km0_ic_data_iso0            1'h1
    18      R/W r_RET1N_km0_ic_tag_iso0             1'h1
    20:19   R/W r_RET1N_km0_dtcm1_iso0              2'h3
    24:21   R/W r_RET1N_km0_dtcm0_iso0              4'hf
    31:25   R/W r_RET1N_km0_itcm1_iso0              7'h7f
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO0_3_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_kr0_log_iso0: 1;
        uint32_t r_RET1N_kr0_ipc_iso0: 2;
        uint32_t r_RET1N_kr0_pmc_iso0: 1;
        uint32_t RSVD: 11;
        uint32_t r_RET1N_km0_dc_data_iso0: 1;
        uint32_t r_RET1N_km0_dc_tag_iso0: 1;
        uint32_t r_RET1N_km0_ic_data_iso0: 1;
        uint32_t r_RET1N_km0_ic_tag_iso0: 1;
        uint32_t r_RET1N_km0_dtcm1_iso0: 2;
        uint32_t r_RET1N_km0_dtcm0_iso0: 4;
        uint32_t r_RET1N_km0_itcm1_iso0: 7;
    };
} AON_ARM_SRAM_RET1N_ISO0_3_TYPE;

/* 0x72C    0x4000_072c
    15:0    R/W r_RET1N_data_iso0                   16'hffff
    19:16   R/W r_RET1N_buf_iso0                    4'hf
    31:20   R   RSVD                                12'hfff
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO0_4_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_data_iso0: 16;
        uint32_t r_RET1N_buf_iso0: 4;
        uint32_t RSVD: 12;
    };
} AON_ARM_SRAM_RET1N_ISO0_4_TYPE;

/* 0x730    0x4000_0730
    24:0    R/W r_RET1N_dsp_data_ram_iso0           25'h1ff_ffff
    31:25   R   RSVD                                7'h7f
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO0_5_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_dsp_data_ram_iso0: 25;
        uint32_t RSVD: 7;
    };
} AON_ARM_SRAM_RET1N_ISO0_5_TYPE;

/* 0x734    0x4000_0734
    24:0    R/W r_RET1N_dsp_ram_iso0                25'h1ff_ffff
    31:25   R   RSVD                                7'h7f
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO0_6_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_dsp_ram_iso0: 25;
        uint32_t RSVD: 7;
    };
} AON_ARM_SRAM_RET1N_ISO0_6_TYPE;

/* 0x738    0x4000_0738
    0       R/W r_RET1N_dsp_dcache_prefetch_iso0    1'h1
    3:1     R/W r_RET1N_dsp_dcache_tag_iso0         3'h7
    6:4     R/W r_RET1N_dsp_dcache_data_iso0        3'h7
    17:7    R   RSVD                                11'h7ff
    23:18   R/W r_RET1N_fft_iso0                    6'h3f
    26:24   R/W r_RET1N_dsp_icache_tag_iso0         3'h7
    29:27   R/W r_RET1N_dsp_icache_data_iso0        3'h7
    31:30   R   RSVD                                2'h3
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO0_7_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_dsp_dcache_prefetch_iso0: 1;
        uint32_t r_RET1N_dsp_dcache_tag_iso0: 3;
        uint32_t r_RET1N_dsp_dcache_data_iso0: 3;
        uint32_t RSVD_1: 11;
        uint32_t r_RET1N_fft_iso0: 6;
        uint32_t r_RET1N_dsp_icache_tag_iso0: 3;
        uint32_t r_RET1N_dsp_icache_data_iso0: 3;
        uint32_t RSVD: 2;
    };
} AON_ARM_SRAM_RET1N_ISO0_7_TYPE;

/* 0x73C    0x4000_073c
    1:0     R/W r_RET1N_sdio_iso0                   2'h3
    2       R/W r_RET1N_usb_iso0                    1'h1
    5:3     R/W r_RET1N_mipi_iso0                   3'h7
    7:6     R/W r_RET1N_display_iso0                2'h3
    20:8    R/W r_RET1N_mac_iso0                    13'h1fff
    29:21   R/W r_RET1N_phy_iso0                    9'h1ff
    31:30   R   RSVD                                2'h3
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO0_8_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_sdio_iso0: 2;
        uint32_t r_RET1N_usb_iso0: 1;
        uint32_t r_RET1N_mipi_iso0: 3;
        uint32_t r_RET1N_display_iso0: 2;
        uint32_t r_RET1N_mac_iso0: 13;
        uint32_t r_RET1N_phy_iso0: 9;
        uint32_t RSVD: 2;
    };
} AON_ARM_SRAM_RET1N_ISO0_8_TYPE;

/* 0x740    0x4000_0740
    1:0     R/W r_RET1N_vadbuf_iso0                 2'h3
    4:2     R/W r_RET1N_pke_iso0                    3'h7
    31:5    R   RSVD                                27'h7ff_ffff
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO0_9_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_vadbuf_iso0: 2;
        uint32_t r_RET1N_pke_iso0: 3;
        uint32_t RSVD: 27;
    };
} AON_ARM_SRAM_RET1N_ISO0_9_TYPE;

/* 0x744    0x4000_0744
    29:0    R/W r_RET1N_gpu_iso0                    30'h3fff_ffff
    31:30   R   RSVD                                2'h3
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO0_10_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_gpu_iso0: 30;
        uint32_t RSVD: 2;
    };
} AON_ARM_SRAM_RET1N_ISO0_10_TYPE;

/* 0x748    0x4000_0748
    15:0    R/W r_RET1N_dsp_repair_ram_iso0         16'hffff
    31:16   R   RSVD                                16'hffff
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO0_11_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_dsp_repair_ram_iso0: 16;
        uint32_t RSVD: 16;
    };
} AON_ARM_SRAM_RET1N_ISO0_11_TYPE;

/* 0x74C    0x4000_074c
    3:0     R/W r_RET1N_dsp_sys_ram_iso0            4'hf
    31:4    R   RSVD                                28'hfff_ffff
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO0_12_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_dsp_sys_ram_iso0: 4;
        uint32_t RSVD: 28;
    };
} AON_ARM_SRAM_RET1N_ISO0_12_TYPE;

/* 0x760    0x4000_0760
    7:0     R/W r_RET1N_km4_dtcm1_iso1              8'hff
    15:8    R/W r_RET1N_km4_dtcm0_iso1              8'hff
    31:16   R/W r_RET1N_km4_itcm1_iso1              16'hffff
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO1_1_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_km4_dtcm1_iso1: 8;
        uint32_t r_RET1N_km4_dtcm0_iso1: 8;
        uint32_t r_RET1N_km4_itcm1_iso1: 16;
    };
} AON_ARM_SRAM_RET1N_ISO1_1_TYPE;

/* 0x764    0x4000_0764
    1:0     R/W r_RET1N_km4_dc_data_iso1            2'h3
    2       R/W r_RET1N_km4_dc_tag_iso1             1'h1
    6:3     R/W r_RET1N_km4_ic_data_iso1            4'hf
    7       R/W r_RET1N_km4_ic_tag_iso1             1'h1
    31:8    R   RSVD                                24'hf_ffff
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO1_2_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_km4_dc_data_iso1: 2;
        uint32_t r_RET1N_km4_dc_tag_iso1: 1;
        uint32_t r_RET1N_km4_ic_data_iso1: 4;
        uint32_t r_RET1N_km4_ic_tag_iso1: 1;
        uint32_t RSVD: 24;
    };
} AON_ARM_SRAM_RET1N_ISO1_2_TYPE;

/* 0x768    0x4000_0768
    0       R/W r_RET1N_kr0_log_iso1                1'h1
    2:1     R/W r_RET1N_kr0_ipc_iso1                2'h3
    3       R/W r_RET1N_kr0_pmc_iso1                1'h1
    14:4    R   RSVD                                11'h7ff
    15      R/W r_RET1N_km0_dc_data_iso1            1'h1
    16      R/W r_RET1N_km0_dc_tag_iso1             1'h1
    17      R/W r_RET1N_km0_ic_data_iso1            1'h1
    18      R/W r_RET1N_km0_ic_tag_iso1             1'h1
    20:19   R/W r_RET1N_km0_dtcm1_iso1              2'h3
    24:21   R/W r_RET1N_km0_dtcm0_iso1              4'hf
    31:25   R/W r_RET1N_km0_itcm1_iso1              7'h7f
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO1_3_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_kr0_log_iso1: 1;
        uint32_t r_RET1N_kr0_ipc_iso1: 2;
        uint32_t r_RET1N_kr0_pmc_iso1: 1;
        uint32_t RSVD: 11;
        uint32_t r_RET1N_km0_dc_data_iso1: 1;
        uint32_t r_RET1N_km0_dc_tag_iso1: 1;
        uint32_t r_RET1N_km0_ic_data_iso1: 1;
        uint32_t r_RET1N_km0_ic_tag_iso1: 1;
        uint32_t r_RET1N_km0_dtcm1_iso1: 2;
        uint32_t r_RET1N_km0_dtcm0_iso1: 4;
        uint32_t r_RET1N_km0_itcm1_iso1: 7;
    };
} AON_ARM_SRAM_RET1N_ISO1_3_TYPE;

/* 0x76C    0x4000_076c
    15:0    R/W r_RET1N_data_iso1                   16'hffff
    19:16   R/W r_RET1N_buf_iso1                    4'hf
    31:20   R   RSVD                                12'hfff
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO1_4_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_data_iso1: 16;
        uint32_t r_RET1N_buf_iso1: 4;
        uint32_t RSVD: 12;
    };
} AON_ARM_SRAM_RET1N_ISO1_4_TYPE;

/* 0x770    0x4000_0770
    24:0    R/W r_RET1N_dsp_data_ram_iso1           25'h1ff_ffff
    31:25   R   RSVD                                7'h7f
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO1_5_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_dsp_data_ram_iso1: 25;
        uint32_t RSVD: 7;
    };
} AON_ARM_SRAM_RET1N_ISO1_5_TYPE;

/* 0x774    0x4000_0774
    24:0    R/W r_RET1N_dsp_ram_iso1                25'h1ff_ffff
    31:25   R   RSVD                                7'h7f
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO1_6_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_dsp_ram_iso1: 25;
        uint32_t RSVD: 7;
    };
} AON_ARM_SRAM_RET1N_ISO1_6_TYPE;

/* 0x778    0x4000_0778
    0       R/W r_RET1N_dsp_dcache_prefetch_iso1    1'h1
    3:1     R/W r_RET1N_dsp_dcache_tag_iso1         3'h7
    6:4     R/W r_RET1N_dsp_dcache_data_iso1        3'h7
    17:7    R   RSVD                                11'h7ff
    23:18   R/W r_RET1N_fft_iso1                    6'h3f
    26:24   R/W r_RET1N_dsp_icache_tag_iso1         3'h7
    29:27   R/W r_RET1N_dsp_icache_data_iso1        3'h7
    31:30   R   RSVD                                2'h3
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO1_7_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_dsp_dcache_prefetch_iso1: 1;
        uint32_t r_RET1N_dsp_dcache_tag_iso1: 3;
        uint32_t r_RET1N_dsp_dcache_data_iso1: 3;
        uint32_t RSVD_1: 11;
        uint32_t r_RET1N_fft_iso1: 6;
        uint32_t r_RET1N_dsp_icache_tag_iso1: 3;
        uint32_t r_RET1N_dsp_icache_data_iso1: 3;
        uint32_t RSVD: 2;
    };
} AON_ARM_SRAM_RET1N_ISO1_7_TYPE;

/* 0x77C    0x4000_077c
    1:0     R/W r_RET1N_sdio_iso1                   2'h3
    2       R/W r_RET1N_usb_iso1                    1'h1
    5:3     R/W r_RET1N_mipi_iso1                   3'h7
    7:6     R/W r_RET1N_display_iso1                2'h3
    20:8    R/W r_RET1N_mac_iso1                    13'h1fff
    29:21   R/W r_RET1N_phy_iso1                    9'h1ff
    31:30   R   RSVD                                2'h3
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO1_8_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_sdio_iso1: 2;
        uint32_t r_RET1N_usb_iso1: 1;
        uint32_t r_RET1N_mipi_iso1: 3;
        uint32_t r_RET1N_display_iso1: 2;
        uint32_t r_RET1N_mac_iso1: 13;
        uint32_t r_RET1N_phy_iso1: 9;
        uint32_t RSVD: 2;
    };
} AON_ARM_SRAM_RET1N_ISO1_8_TYPE;

/* 0x780    0x4000_0780
    1:0     R/W r_RET1N_vadbuf_iso1                 2'h3
    4:2     R/W r_RET1N_pke_iso1                    3'h7
    31:5    R   RSVD                                27'h7ff_ffff
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO1_9_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_vadbuf_iso1: 2;
        uint32_t r_RET1N_pke_iso1: 3;
        uint32_t RSVD: 27;
    };
} AON_ARM_SRAM_RET1N_ISO1_9_TYPE;

/* 0x784    0x4000_0784
    29:0    R/W r_RET1N_gpu_iso1                    30'h3fff_ffff
    31:30   R   RSVD                                2'h3
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO1_10_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_gpu_iso1: 30;
        uint32_t RSVD: 2;
    };
} AON_ARM_SRAM_RET1N_ISO1_10_TYPE;

/* 0x788    0x4000_0788
    15:0    R/W r_RET1N_dsp_repair_ram_iso1         16'hffff
    31:16   R   RSVD                                16'hffff
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO1_11_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_dsp_repair_ram_iso1: 16;
        uint32_t RSVD: 16;
    };
} AON_ARM_SRAM_RET1N_ISO1_11_TYPE;

/* 0x78C    0x4000_078c
    3:0     R/W r_RET1N_dsp_sys_ram_iso1            4'hf
    31:4    R   RSVD                                28'hfff_ffff
 */
typedef volatile union _AON_ARM_SRAM_RET1N_ISO1_12_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET1N_dsp_sys_ram_iso1: 4;
        uint32_t RSVD: 28;
    };
} AON_ARM_SRAM_RET1N_ISO1_12_TYPE;

/* 0x7A0    0x4000_07a0
    0       R/W r_RET2N_kr0_log_iso0                1'h1
    2:1     R/W r_RET2N_kr0_ipc_iso0                2'h3
    3       R/W r_RET2N_kr0_pmc_iso0                1'h1
    14:4    R   RSVD                                11'h7ff
    15      R/W r_RET2N_km0_dc_data_iso0            1'h1
    16      R/W r_RET2N_km0_dc_tag_iso0             1'h1
    17      R/W r_RET2N_km0_ic_data_iso0            1'h1
    18      R/W r_RET2N_km0_ic_tag_iso0             1'h1
    20:19   R/W r_RET2N_km0_dtcm1_iso0              2'h3
    24:21   R/W r_RET2N_km0_dtcm0_iso0              4'hf
    31:25   R/W r_RET2N_km0_itcm1_iso0              7'h7f
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO0_3_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_kr0_log_iso0: 1;
        uint32_t r_RET2N_kr0_ipc_iso0: 2;
        uint32_t r_RET2N_kr0_pmc_iso0: 1;
        uint32_t RSVD: 11;
        uint32_t r_RET2N_km0_dc_data_iso0: 1;
        uint32_t r_RET2N_km0_dc_tag_iso0: 1;
        uint32_t r_RET2N_km0_ic_data_iso0: 1;
        uint32_t r_RET2N_km0_ic_tag_iso0: 1;
        uint32_t r_RET2N_km0_dtcm1_iso0: 2;
        uint32_t r_RET2N_km0_dtcm0_iso0: 4;
        uint32_t r_RET2N_km0_itcm1_iso0: 7;
    };
} AON_ARM_SRAM_RET2N_ISO0_3_TYPE;

/* 0x7A4    0x4000_07a4
    15:0    R/W r_RET2N_data_iso0                   16'hffff
    19:16   R/W r_RET2N_buf_iso0                    4'hf
    31:20   R   RSVD                                12'hfff
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO0_4_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_data_iso0: 16;
        uint32_t r_RET2N_buf_iso0: 4;
        uint32_t RSVD: 12;
    };
} AON_ARM_SRAM_RET2N_ISO0_4_TYPE;

/* 0x7A8    0x4000_07a8
    24:0    R/W r_RET2N_dsp_data_ram_iso0           25'h1ff_ffff
    31:25   R   RSVD                                7'h7f
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO0_5_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_dsp_data_ram_iso0: 25;
        uint32_t RSVD: 7;
    };
} AON_ARM_SRAM_RET2N_ISO0_5_TYPE;

/* 0x7AC    0x4000_07ac
    24:0    R/W r_RET2N_dsp_ram_iso0                25'h1ff_ffff
    31:25   R   RSVD                                7'h7f
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO0_6_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_dsp_ram_iso0: 25;
        uint32_t RSVD: 7;
    };
} AON_ARM_SRAM_RET2N_ISO0_6_TYPE;

/* 0x7B0    0x4000_07b0
    0       R/W r_RET2N_dsp_dcache_prefetch_iso0    1'h1
    3:1     R/W r_RET2N_dsp_dcache_tag_iso0         3'h7
    6:4     R/W r_RET2N_dsp_dcache_data_iso0        3'h7
    17:7    R   RSVD                                11'h7ff
    23:18   R/W r_RET2N_fft_iso0                    6'h3f
    26:24   R/W r_RET2N_dsp_icache_tag_iso0         3'h7
    29:27   R/W r_RET2N_dsp_icache_data_iso0        3'h7
    31:30   R   RSVD                                2'h3
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO0_7_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_dsp_dcache_prefetch_iso0: 1;
        uint32_t r_RET2N_dsp_dcache_tag_iso0: 3;
        uint32_t r_RET2N_dsp_dcache_data_iso0: 3;
        uint32_t RSVD_1: 11;
        uint32_t r_RET2N_fft_iso0: 6;
        uint32_t r_RET2N_dsp_icache_tag_iso0: 3;
        uint32_t r_RET2N_dsp_icache_data_iso0: 3;
        uint32_t RSVD: 2;
    };
} AON_ARM_SRAM_RET2N_ISO0_7_TYPE;

/* 0x7B4    0x4000_07b4
    1:0     R/W r_RET2N_sdio_iso0                   2'h3
    2       R/W r_RET2N_usb_iso0                    1'h1
    5:3     R/W r_RET2N_mipi_iso0                   3'h7
    7:6     R/W r_RET2N_display_iso0                2'h3
    20:8    R/W r_RET2N_mac_iso0                    13'h1fff
    29:21   R/W r_RET2N_phy_iso0                    9'h1ff
    31:30   R   RSVD                                2'h3
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO0_8_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_sdio_iso0: 2;
        uint32_t r_RET2N_usb_iso0: 1;
        uint32_t r_RET2N_mipi_iso0: 3;
        uint32_t r_RET2N_display_iso0: 2;
        uint32_t r_RET2N_mac_iso0: 13;
        uint32_t r_RET2N_phy_iso0: 9;
        uint32_t RSVD: 2;
    };
} AON_ARM_SRAM_RET2N_ISO0_8_TYPE;

/* 0x7B8    0x4000_07b8
    1:0     R/W r_RET2N_vadbuf_iso0                 2'h3
    4:2     R/W r_RET2N_pke_iso0                    3'h7
    31:5    R   RSVD                                27'h7ff_ffff
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO0_9_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_vadbuf_iso0: 2;
        uint32_t r_RET2N_pke_iso0: 3;
        uint32_t RSVD: 27;
    };
} AON_ARM_SRAM_RET2N_ISO0_9_TYPE;

/* 0x7BC    0x4000_07bc
    29:0    R/W r_RET2N_gpu_iso0                    30'h3fff_ffff
    31:30   R   RSVD                                2'h3
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO0_10_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_gpu_iso0: 30;
        uint32_t RSVD: 2;
    };
} AON_ARM_SRAM_RET2N_ISO0_10_TYPE;

/* 0x7C0    0x4000_07c0
    15:0    R/W r_RET2N_dsp_repair_ram_iso0         16'hffff
    31:16   R   RSVD                                16'hffff
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO0_11_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_dsp_repair_ram_iso0: 16;
        uint32_t RSVD: 16;
    };
} AON_ARM_SRAM_RET2N_ISO0_11_TYPE;

/* 0x7C4    0x4000_07c4
    3:0     R/W r_RET2N_dsp_sys_ram_iso0            4'hf
    31:4    R   RSVD                                28'hfff_ffff
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO0_12_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_dsp_sys_ram_iso0: 4;
        uint32_t RSVD: 28;
    };
} AON_ARM_SRAM_RET2N_ISO0_12_TYPE;

/* 0x7D0    0x4000_07d0
    0       R/W r_RET2N_kr0_log_iso1                1'h1
    2:1     R/W r_RET2N_kr0_ipc_iso1                2'h3
    3       R/W r_RET2N_kr0_pmc_iso1                1'h1
    14:4    R   RSVD                                11'h7ff
    15      R/W r_RET2N_km0_dc_data_iso1            1'h1
    16      R/W r_RET2N_km0_dc_tag_iso1             1'h1
    17      R/W r_RET2N_km0_ic_data_iso1            1'h1
    18      R/W r_RET2N_km0_ic_tag_iso1             1'h1
    20:19   R/W r_RET2N_km0_dtcm1_iso1              2'h3
    24:21   R/W r_RET2N_km0_dtcm0_iso1              4'hf
    31:25   R/W r_RET2N_km0_itcm1_iso1              7'h7f
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO1_3_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_kr0_log_iso1: 1;
        uint32_t r_RET2N_kr0_ipc_iso1: 2;
        uint32_t r_RET2N_kr0_pmc_iso1: 1;
        uint32_t RSVD: 11;
        uint32_t r_RET2N_km0_dc_data_iso1: 1;
        uint32_t r_RET2N_km0_dc_tag_iso1: 1;
        uint32_t r_RET2N_km0_ic_data_iso1: 1;
        uint32_t r_RET2N_km0_ic_tag_iso1: 1;
        uint32_t r_RET2N_km0_dtcm1_iso1: 2;
        uint32_t r_RET2N_km0_dtcm0_iso1: 4;
        uint32_t r_RET2N_km0_itcm1_iso1: 7;
    };
} AON_ARM_SRAM_RET2N_ISO1_3_TYPE;

/* 0x7D4    0x4000_07d4
    15:0    R/W r_RET2N_data_iso1                   16'hffff
    19:16   R/W r_RET2N_buf_iso1                    4'hf
    31:20   R   RSVD                                12'hfff
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO1_4_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_data_iso1: 16;
        uint32_t r_RET2N_buf_iso1: 4;
        uint32_t RSVD: 12;
    };
} AON_ARM_SRAM_RET2N_ISO1_4_TYPE;

/* 0x7D8    0x4000_07d8
    24:0    R/W r_RET2N_dsp_data_ram_iso1           25'h1ff_ffff
    31:25   R   RSVD                                7'h7f
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO1_5_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_dsp_data_ram_iso1: 25;
        uint32_t RSVD: 7;
    };
} AON_ARM_SRAM_RET2N_ISO1_5_TYPE;

/* 0x7DC    0x4000_07dc
    24:0    R/W r_RET2N_dsp_ram_iso1                25'h1ff_ffff
    31:25   R   RSVD                                7'h7f
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO1_6_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_dsp_ram_iso1: 25;
        uint32_t RSVD: 7;
    };
} AON_ARM_SRAM_RET2N_ISO1_6_TYPE;

/* 0x7E0    0x4000_07e0
    0       R/W r_RET2N_dsp_dcache_prefetch_iso1    1'h1
    3:1     R/W r_RET2N_dsp_dcache_tag_iso1         3'h7
    6:4     R/W r_RET2N_dsp_dcache_data_iso1        3'h7
    17:7    R   RSVD                                11'h7ff
    23:18   R/W r_RET2N_fft_iso1                    6'h3f
    26:24   R/W r_RET2N_dsp_icache_tag_iso1         3'h7
    29:27   R/W r_RET2N_dsp_icache_data_iso1        3'h7
    31:30   R   RSVD                                2'h3
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO1_7_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_dsp_dcache_prefetch_iso1: 1;
        uint32_t r_RET2N_dsp_dcache_tag_iso1: 3;
        uint32_t r_RET2N_dsp_dcache_data_iso1: 3;
        uint32_t RSVD_1: 11;
        uint32_t r_RET2N_fft_iso1: 6;
        uint32_t r_RET2N_dsp_icache_tag_iso1: 3;
        uint32_t r_RET2N_dsp_icache_data_iso1: 3;
        uint32_t RSVD: 2;
    };
} AON_ARM_SRAM_RET2N_ISO1_7_TYPE;

/* 0x7E4    0x4000_07e4
    1:0     R/W r_RET2N_sdio_iso1                   2'h3
    2       R/W r_RET2N_usb_iso1                    1'h1
    5:3     R/W r_RET2N_mipi_iso1                   3'h7
    7:6     R/W r_RET2N_display_iso1                2'h3
    20:8    R/W r_RET2N_mac_iso1                    13'h1fff
    29:21   R/W r_RET2N_phy_iso1                    9'h1ff
    31:30   R   RSVD                                2'h3
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO1_8_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_sdio_iso1: 2;
        uint32_t r_RET2N_usb_iso1: 1;
        uint32_t r_RET2N_mipi_iso1: 3;
        uint32_t r_RET2N_display_iso1: 2;
        uint32_t r_RET2N_mac_iso1: 13;
        uint32_t r_RET2N_phy_iso1: 9;
        uint32_t RSVD: 2;
    };
} AON_ARM_SRAM_RET2N_ISO1_8_TYPE;

/* 0x7E8    0x4000_07e8
    1:0     R/W r_RET2N_vadbuf_iso1                 2'h3
    4:2     R/W r_RET2N_pke_iso1                    3'h7
    31:5    R   RSVD                                27'h7ff_ffff
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO1_9_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_vadbuf_iso1: 2;
        uint32_t r_RET2N_pke_iso1: 3;
        uint32_t RSVD: 27;
    };
} AON_ARM_SRAM_RET2N_ISO1_9_TYPE;

/* 0x7EC    0x4000_07ec
    29:0    R/W r_RET2N_gpu_iso1                    30'h3fff_ffff
    31:30   R   RSVD                                2'h3
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO1_10_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_gpu_iso1: 30;
        uint32_t RSVD: 2;
    };
} AON_ARM_SRAM_RET2N_ISO1_10_TYPE;

/* 0x7F0    0x4000_07f0
    15:0    R/W r_RET2N_dsp_repair_ram_iso1         16'hffff
    31:16   R   RSVD                                16'hffff
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO1_11_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_dsp_repair_ram_iso1: 16;
        uint32_t RSVD: 16;
    };
} AON_ARM_SRAM_RET2N_ISO1_11_TYPE;

/* 0x7F4    0x4000_07f4
    3:0     R/W r_RET2N_dsp_sys_ram_iso1            4'hf
    31:4    R   RSVD                                28'hfff_ffff
 */
typedef volatile union _AON_ARM_SRAM_RET2N_ISO1_12_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_RET2N_dsp_sys_ram_iso1: 4;
        uint32_t RSVD: 28;
    };
} AON_ARM_SRAM_RET2N_ISO1_12_TYPE;

/* 0x800    0x4000_0800
    0       R/W REG00_SYS_DUMMY3                    1'b1
    1       R/W REG00_SYS_DUMMY2                    1'b1
    2       R/W ENPC_SRAM_4_2_VG2                   1'b1
    3       R/W ENPC_SRAM_4_1_VG2                   1'b1
    4       R/W ENPC_SRAM_4_0_VG2                   1'b1
    5       R/W ENPC_SRAM_3_3_VG2                   1'b1
    6       R/W ENPC_SRAM_3_2_VG2                   1'b1
    7       R/W ENPC_SRAM_3_1_VG2                   1'b1
    8       R/W ENPC_SRAM_3_0_VG2                   1'b1
    9       R/W ENPC_SRAM_2_2_VG2                   1'b1
    10      R/W ENPC_SRAM_2_1_VG2                   1'b1
    11      R/W ENPC_SRAM_2_0_VG2                   1'b1
    12      R/W ENPC_CORE_4_VG2                     1'b1
    13      R/W ENPC_CORE_3_VG2                     1'b1
    14      R/W ENPC_CORE_2_VG2                     1'b1
    15      R/W ENPC_CORE_1_VG2                     1'b1
    16      R/W REG00_SYS_DUMMY1                    1'b1
    17      R/W REG00_SYS_DUMMY0                    1'b1
    18      R/W ENPC_SRAM_4_2_VG1                   1'b1
    19      R/W ENPC_SRAM_4_1_VG1                   1'b1
    20      R/W ENPC_SRAM_4_0_VG1                   1'b1
    21      R/W ENPC_SRAM_3_3_VG1                   1'b1
    22      R/W ENPC_SRAM_3_2_VG1                   1'b1
    23      R/W ENPC_SRAM_3_1_VG1                   1'b1
    24      R/W ENPC_SRAM_3_0_VG1                   1'b1
    25      R/W ENPC_SRAM_2_2_VG1                   1'b1
    26      R/W ENPC_SRAM_2_1_VG1                   1'b1
    27      R/W ENPC_SRAM_2_0_VG1                   1'b1
    28      R/W ENPC_CORE_4_VG1                     1'b1
    29      R/W ENPC_CORE_3_VG1                     1'b1
    30      R/W ENPC_CORE_2_VG1                     1'b1
    31      R/W ENPC_CORE_1_VG1                     1'b1
 */
typedef volatile union _AON_REG00_SYS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t REG00_SYS_DUMMY3: 1;
        uint32_t REG00_SYS_DUMMY2: 1;
        uint32_t ENPC_SRAM_4_2_VG2: 1;
        uint32_t ENPC_SRAM_4_1_VG2: 1;
        uint32_t ENPC_SRAM_4_0_VG2: 1;
        uint32_t ENPC_SRAM_3_3_VG2: 1;
        uint32_t ENPC_SRAM_3_2_VG2: 1;
        uint32_t ENPC_SRAM_3_1_VG2: 1;
        uint32_t ENPC_SRAM_3_0_VG2: 1;
        uint32_t ENPC_SRAM_2_2_VG2: 1;
        uint32_t ENPC_SRAM_2_1_VG2: 1;
        uint32_t ENPC_SRAM_2_0_VG2: 1;
        uint32_t ENPC_CORE_4_VG2: 1;
        uint32_t ENPC_CORE_3_VG2: 1;
        uint32_t ENPC_CORE_2_VG2: 1;
        uint32_t ENPC_CORE_1_VG2: 1;
        uint32_t REG00_SYS_DUMMY1: 1;
        uint32_t REG00_SYS_DUMMY0: 1;
        uint32_t ENPC_SRAM_4_2_VG1: 1;
        uint32_t ENPC_SRAM_4_1_VG1: 1;
        uint32_t ENPC_SRAM_4_0_VG1: 1;
        uint32_t ENPC_SRAM_3_3_VG1: 1;
        uint32_t ENPC_SRAM_3_2_VG1: 1;
        uint32_t ENPC_SRAM_3_1_VG1: 1;
        uint32_t ENPC_SRAM_3_0_VG1: 1;
        uint32_t ENPC_SRAM_2_2_VG1: 1;
        uint32_t ENPC_SRAM_2_1_VG1: 1;
        uint32_t ENPC_SRAM_2_0_VG1: 1;
        uint32_t ENPC_CORE_4_VG1: 1;
        uint32_t ENPC_CORE_3_VG1: 1;
        uint32_t ENPC_CORE_2_VG1: 1;
        uint32_t ENPC_CORE_1_VG1: 1;
    };
} AON_REG00_SYS_TYPE;

/* 0x804    0x4000_0804
    0       R/W ISO_BT_SRAM_4_2                     1'b1
    1       R/W ISO_BT_SRAM_4_1                     1'b1
    2       R/W ISO_BT_SRAM_4_0                     1'b1
    3       R/W ISO_BT_SRAM_3_3                     1'b1
    4       R/W ISO_BT_SRAM_3_2                     1'b1
    5       R/W ISO_BT_SRAM_3_1                     1'b1
    6       R/W ISO_BT_SRAM_3_0                     1'b1
    7       R/W ISO_BT_SRAM_2_2                     1'b1
    8       R/W ISO_BT_SRAM_2_1                     1'b1
    9       R/W ISO_BT_SRAM_2_0                     1'b1
    10      R/W ISO_BT_SRAM_1                       1'b1
    11      R/W ISO_BT_CORE_4                       1'b1
    12      R/W ISO_BT_CORE_3                       1'b1
    13      R/W ISO_BT_CORE_2                       1'b1
    14      R/W ISO_BT_CORE_1                       1'b1
    15      R/W REG01_SYS_DUMMY1                    1'b1
    16      R/W ISO_KR0_ROM                         1'b1
    17      R/W ISO_AUXADC_AON                      1'b1
    18      R/W ISO_BT_AON_1                        1'b1
    19      R/W ISO_BT_AON_2                        1'b1
    20      R/W ISO_BT_AON_3                        1'b1
    21      R/W ISO_BT_AON_4                        1'b1
    22      R/W ISO_OTP_PDOUT                       1'b0
    23      R/W ISO_PLL                             1'b1
    31:24   R/W REG01_SYS_DUMMY0                    8'b1
 */
typedef volatile union _AON_REG01_SYS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t ISO_BT_SRAM_4_2: 1;
        uint32_t ISO_BT_SRAM_4_1: 1;
        uint32_t ISO_BT_SRAM_4_0: 1;
        uint32_t ISO_BT_SRAM_3_3: 1;
        uint32_t ISO_BT_SRAM_3_2: 1;
        uint32_t ISO_BT_SRAM_3_1: 1;
        uint32_t ISO_BT_SRAM_3_0: 1;
        uint32_t ISO_BT_SRAM_2_2: 1;
        uint32_t ISO_BT_SRAM_2_1: 1;
        uint32_t ISO_BT_SRAM_2_0: 1;
        uint32_t ISO_BT_SRAM_1: 1;
        uint32_t ISO_BT_CORE_4: 1;
        uint32_t ISO_BT_CORE_3: 1;
        uint32_t ISO_BT_CORE_2: 1;
        uint32_t ISO_BT_CORE_1: 1;
        uint32_t REG01_SYS_DUMMY1: 1;
        uint32_t ISO_KR0_ROM: 1;
        uint32_t ISO_AUXADC_AON: 1;
        uint32_t ISO_BT_AON_1: 1;
        uint32_t ISO_BT_AON_2: 1;
        uint32_t ISO_BT_AON_3: 1;
        uint32_t ISO_BT_AON_4: 1;
        uint32_t ISO_OTP_PDOUT: 1;
        uint32_t ISO_PLL: 1;
        uint32_t REG01_SYS_DUMMY0: 8;
    };
} AON_REG01_SYS_TYPE;

/* 0x808    0x4000_0808
    0       R/W KR0_SRAM_BUS_RSTB                   1'b0
    1       R/W KR0_CPU_RSTB_BY_HW_FSM              1'b0
    2       R   KR0_CPU_RSTB                        1'b0
    3       R/W KM0_CORE1_RSTB                      1'b0
    4       R/W KM4_CORE4_RSTB                      1'b0
    5       R/W KM4_CORE3_RSTB                      1'b0
    6       R/W KM4_CORE2_RSTB                      1'b0
    7       R/W M0_RET_RSTB                         1'b0
    8       R/W M4_RET_RSTB                         1'b0
    9       R/W M4_load_R0_patch                    1'b0
    10      R/W M4_HW_FSM                           1'b1
    11      R/W R0_HW_FSM                           1'b1
    12      R/W PENVDD2_VDD2                        1'b0
    13      R/W REG02_SYS_DUMMY3                    1'b1
    14      R/W REG02_SYS_DUMMY2                    1'b1
    15      R/W REG02_SYS_DUMMY1                    1'b1
    16      R/W REG02_SYS_DUMMY0                    1'b1
    17      R/W ENPC_AON_4_VG2                      1'b0
    18      R/W ENPC_AON_3_VG2                      1'b1
    19      R/W ENPC_AON_2_VG2                      1'b1
    20      R/W ENPC_AON_1_VG2                      1'b1
    21      R/W ENPC_AON_4_VG1                      1'b0
    22      R/W ENPC_AON_3_VG1                      1'b1
    23      R/W ENPC_AON_2_VG1                      1'b1
    24      R/W ENPC_AON_1_VG1                      1'b1
    25      R/W AON1_RSTB                           1'b0
    26      R/W AON_REG_RST                         1'b0
    27      R/W REG02_SYS_DUMMY4                    1'b1
    28      R/W km0_cpu_rst_halt                    1'b1
    29      R/W km4_cpu_rst_halt                    1'b0
    30      R/W AON4_RSTB                           1'b0
    31      R/W AON2_RSTB                           1'b0
 */
typedef volatile union _AON_REG02_SYS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t KR0_SRAM_BUS_RSTB: 1;
        uint32_t KR0_CPU_RSTB_BY_HW_FSM: 1;
        uint32_t KR0_CPU_RSTB: 1;
        uint32_t KM0_CORE1_RSTB: 1;
        uint32_t KM4_CORE4_RSTB: 1;
        uint32_t KM4_CORE3_RSTB: 1;
        uint32_t KM4_CORE2_RSTB: 1;
        uint32_t M0_RET_RSTB: 1;
        uint32_t M4_RET_RSTB: 1;
        uint32_t M4_load_R0_patch: 1;
        uint32_t M4_HW_FSM: 1;
        uint32_t R0_HW_FSM: 1;
        uint32_t PENVDD2_VDD2: 1;
        uint32_t REG02_SYS_DUMMY3: 1;
        uint32_t REG02_SYS_DUMMY2: 1;
        uint32_t REG02_SYS_DUMMY1: 1;
        uint32_t REG02_SYS_DUMMY0: 1;
        uint32_t ENPC_AON_4_VG2: 1;
        uint32_t ENPC_AON_3_VG2: 1;
        uint32_t ENPC_AON_2_VG2: 1;
        uint32_t ENPC_AON_1_VG2: 1;
        uint32_t ENPC_AON_4_VG1: 1;
        uint32_t ENPC_AON_3_VG1: 1;
        uint32_t ENPC_AON_2_VG1: 1;
        uint32_t ENPC_AON_1_VG1: 1;
        uint32_t AON1_RSTB: 1;
        uint32_t AON_REG_RST: 1;
        uint32_t REG02_SYS_DUMMY4: 1;
        uint32_t km0_cpu_rst_halt: 1;
        uint32_t km4_cpu_rst_halt: 1;
        uint32_t AON4_RSTB: 1;
        uint32_t AON2_RSTB: 1;
    };
} AON_REG02_SYS_TYPE;

/* 0x80C    0x4000_080c
    0       R/W POW_40M_OSC_R0                      1'b1
    1       R/W POW_40M_OSC_M0                      1'b0
    2       R/W POW_40M_OSC_M4                      1'b0
    3       R/W TX_BIG_POUT                         1'b0
    4       R/W Only_TPM_int                        1'b0
    11:5    R/W POW_PA_TPM_LDO_PA_TUNE_0            7'b1101110
    18:12   R/W POW_PA_TPM_LDO_PA_TUNE_1            7'b1101110
    19      R/W SWITCH_BY_POW_PA_TPM                1'b0
    20      R/W BT_HW_EN_VDDCORE                    1'b0
    25:21   R/W KR0_ST_M4                           5'b0
    30:26   R/W KR0_ST_M0                           5'b0
    31      R/W BT_PON_SEC_RSTB                     1'b0
 */
typedef volatile union _AON_REG03_SYS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t POW_40M_OSC_R0: 1;
        uint32_t POW_40M_OSC_M0: 1;
        uint32_t POW_40M_OSC_M4: 1;
        uint32_t TX_BIG_POUT: 1;
        uint32_t Only_TPM_int: 1;
        uint32_t POW_PA_TPM_LDO_PA_TUNE_0: 7;
        uint32_t POW_PA_TPM_LDO_PA_TUNE_1: 7;
        uint32_t SWITCH_BY_POW_PA_TPM: 1;
        uint32_t BT_HW_EN_VDDCORE: 1;
        uint32_t KR0_ST_M4: 5;
        uint32_t KR0_ST_M0: 5;
        uint32_t BT_PON_SEC_RSTB: 1;
    };
} AON_REG03_SYS_TYPE;

/* 0x810    0x4000_0810
    0       R/W FW_enter_lps                        1'b0
    1       R/W FW_PON_SEQ_RST_N                    1'b0
    2       R/W Force_WFI_FSM                       1'b0
    3       R/W WAIT_MBIAS_VCORE_DET                1'b0
    4       R   XTAL_OK_40M                         1'b0
    5       R/W aon_loader_en                       1'b0
    6       R/W Enable_WFI_FSM                      1'b1
    22:7    R/W R0_interrupt_enable                 16'hffff
    26:23   R/W PMU_DBG_SEL                         4'b0
    27      R   XTAL_OK_32K                         1'b0
    28      R   OSC_OK_32K                          1'b0
    29      R/W short_pulse_wkup                    1'b0
    31:30   R/W REG04_SYS_DUMMY                     2'b1
 */
typedef volatile union _AON_REG04_SYS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_enter_lps: 1;
        uint32_t FW_PON_SEQ_RST_N: 1;
        uint32_t Force_WFI_FSM: 1;
        uint32_t WAIT_MBIAS_VCORE_DET: 1;
        uint32_t XTAL_OK_40M: 1;
        uint32_t aon_loader_en: 1;
        uint32_t Enable_WFI_FSM: 1;
        uint32_t R0_interrupt_enable: 16;
        uint32_t PMU_DBG_SEL: 4;
        uint32_t XTAL_OK_32K: 1;
        uint32_t OSC_OK_32K: 1;
        uint32_t short_pulse_wkup: 1;
        uint32_t REG04_SYS_DUMMY: 2;
    };
} AON_REG04_SYS_TYPE;

/* 0x814    0x4000_0814
    0       R/W PF_VCORE4_RESTORE                   1'b0
    1       R/W PF_VCORE2_RESTORE                   1'b0
    2       R/W PF_VCORE1_RESTORE                   1'b0
    3       R/W BLE_RESTORE                         1'b0
    4       R/W BZ_RESTORE                          1'b0
    5       R/W DP_MODEM_RESTORE                    1'b0
    6       R/W MODEM_RESTORE                       1'b0
    7       R/W RFC_RESTORE                         1'b0
    8       R/W PF_VCORE4_STORE                     1'b0
    9       R/W PF_VCORE2_STORE                     1'b0
    10      R/W PF_VCORE1_STORE                     1'b0
    11      R/W BLE_STORE                           1'b0
    12      R/W BZ_STORE                            1'b0
    13      R/W DP_MODEM_STORE                      1'b0
    14      R/W MODEM_STORE                         1'b0
    15      R/W RFC_STORE                           1'b0
    31:16   R/W REG05_SYS_DUMMY                     16'b0
 */
typedef volatile union _AON_REG05_SYS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PF_VCORE4_RESTORE: 1;
        uint32_t PF_VCORE2_RESTORE: 1;
        uint32_t PF_VCORE1_RESTORE: 1;
        uint32_t BLE_RESTORE: 1;
        uint32_t BZ_RESTORE: 1;
        uint32_t DP_MODEM_RESTORE: 1;
        uint32_t MODEM_RESTORE: 1;
        uint32_t RFC_RESTORE: 1;
        uint32_t PF_VCORE4_STORE: 1;
        uint32_t PF_VCORE2_STORE: 1;
        uint32_t PF_VCORE1_STORE: 1;
        uint32_t BLE_STORE: 1;
        uint32_t BZ_STORE: 1;
        uint32_t DP_MODEM_STORE: 1;
        uint32_t MODEM_STORE: 1;
        uint32_t RFC_STORE: 1;
        uint32_t REG05_SYS_DUMMY: 16;
    };
} AON_REG05_SYS_TYPE;

/* 0x818    0x4000_0818
    1:0     R/W SIMO_CH1_PFM_POS_STEP_SIZE          2'b10
    4:2     R/W SIMO_CH1_PFM_POS_WAIT               3'b1
    8:5     R/W SIMO_CH1_PFM_POS_STEP               4'b1
    13:9    R/W REG00_POS_DUMMY_2                   5'b11111
    18:14   R/W REG00_POS_DUMMY_1                   5'b0
    19      R/W SIMO_CH1_POS_RSTB                   1'b1
    20      R/W SIMO_CH1_EN_POS                     1'b0
    31:21   R/W REG00_POS_DUMMY                     11'b0
 */
typedef volatile union _AON_REG00_POS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SIMO_CH1_PFM_POS_STEP_SIZE: 2;
        uint32_t SIMO_CH1_PFM_POS_WAIT: 3;
        uint32_t SIMO_CH1_PFM_POS_STEP: 4;
        uint32_t REG00_POS_DUMMY_2: 5;
        uint32_t REG00_POS_DUMMY_1: 5;
        uint32_t SIMO_CH1_POS_RSTB: 1;
        uint32_t SIMO_CH1_EN_POS: 1;
        uint32_t REG00_POS_DUMMY: 11;
    };
} AON_REG00_POS_TYPE;

/* 0x81C    0x4000_081c
    1:0     R/W SIMO_CH2_PFM_POS_STEP_SIZE          2'b10
    4:2     R/W SIMO_CH2_PFM_POS_WAIT               3'b1
    8:5     R/W SIMO_CH2_PFM_POS_STEP               4'b1
    13:9    R/W REG01_POS_DUMMY_2                   5'b11111
    18:14   R/W REG01_POS_DUMMY_1                   5'b0
    19      R/W SIMO_CH2_POS_RSTB                   1'b1
    20      R/W SIMO_CH2_EN_POS                     1'b0
    31:21   R/W REG01_POS_DUMMY                     11'b0
 */
typedef volatile union _AON_REG01_POS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SIMO_CH2_PFM_POS_STEP_SIZE: 2;
        uint32_t SIMO_CH2_PFM_POS_WAIT: 3;
        uint32_t SIMO_CH2_PFM_POS_STEP: 4;
        uint32_t REG01_POS_DUMMY_2: 5;
        uint32_t REG01_POS_DUMMY_1: 5;
        uint32_t SIMO_CH2_POS_RSTB: 1;
        uint32_t SIMO_CH2_EN_POS: 1;
        uint32_t REG01_POS_DUMMY: 11;
    };
} AON_REG01_POS_TYPE;

/* 0x820    0x4000_0820
    1:0     R/W SIMO_CH3_PFM_POS_STEP_SIZE          2'b10
    4:2     R/W SIMO_CH3_PFM_POS_WAIT               3'b1
    8:5     R/W SIMO_CH3_PFM_POS_STEP               4'b1
    13:9    R/W REG02_POS_DUMMY_2                   5'b11111
    18:14   R/W REG02_POS_DUMMY_1                   5'b0
    19      R/W SIMO_CH3_POS_RSTB                   1'b1
    20      R/W SIMO_CH3_EN_POS                     1'b0
    31:21   R/W REG02_POS_DUMMY                     11'b0
 */
typedef volatile union _AON_REG02_POS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SIMO_CH3_PFM_POS_STEP_SIZE: 2;
        uint32_t SIMO_CH3_PFM_POS_WAIT: 3;
        uint32_t SIMO_CH3_PFM_POS_STEP: 4;
        uint32_t REG02_POS_DUMMY_2: 5;
        uint32_t REG02_POS_DUMMY_1: 5;
        uint32_t SIMO_CH3_POS_RSTB: 1;
        uint32_t SIMO_CH3_EN_POS: 1;
        uint32_t REG02_POS_DUMMY: 11;
    };
} AON_REG02_POS_TYPE;

/* 0x824    0x4000_0824
    1:0     R/W SIMO_CH4_PFM_POS_STEP_SIZE          2'b10
    4:2     R/W SIMO_CH4_PFM_POS_WAIT               3'b1
    8:5     R/W SIMO_CH4_PFM_POS_STEP               4'b1
    13:9    R/W REG03_POS_DUMMY_2                   5'b11111
    18:14   R/W REG03_POS_DUMMY_1                   5'b0
    19      R/W SIMO_CH4_POS_RSTB                   1'b1
    20      R/W SIMO_CH4_EN_POS                     1'b0
    31:21   R/W REG03_POS_DUMMY                     11'b0
 */
typedef volatile union _AON_REG03_POS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SIMO_CH4_PFM_POS_STEP_SIZE: 2;
        uint32_t SIMO_CH4_PFM_POS_WAIT: 3;
        uint32_t SIMO_CH4_PFM_POS_STEP: 4;
        uint32_t REG03_POS_DUMMY_2: 5;
        uint32_t REG03_POS_DUMMY_1: 5;
        uint32_t SIMO_CH4_POS_RSTB: 1;
        uint32_t SIMO_CH4_EN_POS: 1;
        uint32_t REG03_POS_DUMMY: 11;
    };
} AON_REG03_POS_TYPE;

/* 0x828    0x4000_0828
    4:0     R/W flag1_pon_set_ch1                   5'h0
    9:5     R/W flag2_pon_set_ch1                   5'h0
    14:10   R/W flag3_pon_set_ch1                   5'h1f
    19:15   R/W flag4_pon_set_ch1                   5'h1f
    31:20   R/W REG04_POS_DUMMY                     12'h0
 */
typedef volatile union _AON_REG04_POS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t flag1_pon_set_ch1: 5;
        uint32_t flag2_pon_set_ch1: 5;
        uint32_t flag3_pon_set_ch1: 5;
        uint32_t flag4_pon_set_ch1: 5;
        uint32_t REG04_POS_DUMMY: 12;
    };
} AON_REG04_POS_TYPE;

/* 0x82C    0x4000_082c
    4:0     R/W flag1_pon_set_ch2                   5'h0
    9:5     R/W flag2_pon_set_ch2                   5'h0
    14:10   R/W flag3_pon_set_ch2                   5'h1f
    19:15   R/W flag4_pon_set_ch2                   5'h1f
    31:20   R/W REG05_POS_DUMMY                     12'h0
 */
typedef volatile union _AON_REG05_POS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t flag1_pon_set_ch2: 5;
        uint32_t flag2_pon_set_ch2: 5;
        uint32_t flag3_pon_set_ch2: 5;
        uint32_t flag4_pon_set_ch2: 5;
        uint32_t REG05_POS_DUMMY: 12;
    };
} AON_REG05_POS_TYPE;

/* 0x830    0x4000_0830
    4:0     R/W flag1_pon_set_ch3                   5'h0
    9:5     R/W flag2_pon_set_ch3                   5'h0
    14:10   R/W flag3_pon_set_ch3                   5'h1f
    19:15   R/W flag4_pon_set_ch3                   5'h1f
    31:20   R/W REG06_POS_DUMMY                     12'h0
 */
typedef volatile union _AON_REG06_POS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t flag1_pon_set_ch3: 5;
        uint32_t flag2_pon_set_ch3: 5;
        uint32_t flag3_pon_set_ch3: 5;
        uint32_t flag4_pon_set_ch3: 5;
        uint32_t REG06_POS_DUMMY: 12;
    };
} AON_REG06_POS_TYPE;

/* 0x834    0x4000_0834
    4:0     R/W flag1_pon_set_ch4                   5'h0
    9:5     R/W flag2_pon_set_ch4                   5'h0
    14:10   R/W flag3_pon_set_ch4                   5'h1f
    19:15   R/W flag4_pon_set_ch4                   5'h1f
    31:20   R/W REG07_POS_DUMMY                     12'h0
 */
typedef volatile union _AON_REG07_POS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t flag1_pon_set_ch4: 5;
        uint32_t flag2_pon_set_ch4: 5;
        uint32_t flag3_pon_set_ch4: 5;
        uint32_t flag4_pon_set_ch4: 5;
        uint32_t REG07_POS_DUMMY: 12;
    };
} AON_REG07_POS_TYPE;

/* 0x838    0x4000_0838
    0       R/W r_aon_clk_en0                       1'b0
    1       R/W r_aon_clk_en1                       1'b0
    2       R/W r_aon_clk_en2                       1'b0
    3       R/W r_aon_clk_en3                       1'b0
    4       R/W r_aon_clk_en4                       1'b0
    5       R/W r_aon_clk_en5                       1'b0
    6       R/W r_aon_clk_en6                       1'b0
    7       R/W r_aon_clk_en7                       1'b0
    8       R/W r_aon_clk_en8                       1'b0
    9       R/W r_aon_clk_en9                       1'b0
    10      R/W r_aon_clk_en10                      1'b1
    11      R/W r_aon_clk_en11                      1'b0
    12      R/W r_aon_clk_en12                      1'b0
    13      R/W r_aon_clk_en13                      1'b0
    14      R/W r_aon_clk_en14                      1'b0
    15      R/W r_aon_clk_en15                      1'b0
    16      R/W r_aon_clk_en16                      1'b0
    17      R/W r_aon_clk_en17                      1'b0
    18      R/W r_aon_clk_en18                      1'b0
    19      R/W r_aon_clk_en19                      1'b0
    20      R/W r_aon_clk_en20                      1'b0
    21      R/W r_aon_clk_en21                      1'b0
    22      R/W r_aon_clk_en22                      1'b0
    23      R/W r_aon_clk_en23                      1'b0
    24      R/W r_aon_clk_en24                      1'b0
    25      R/W r_aon_clk_en25                      1'b0
    26      R/W r_aon_clk_en26                      1'b0
    27      R/W r_aon_clk_en27                      1'b0
    28      R   RSVD                                1'b0
    29      R   RSVD                                1'b0
    30      R   RSVD                                1'b0
    31      R   RSVD                                1'b0
 */
typedef volatile union _AON_REG00_CLK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_aon_clk_en0: 1;
        uint32_t r_aon_clk_en1: 1;
        uint32_t r_aon_clk_en2: 1;
        uint32_t r_aon_clk_en3: 1;
        uint32_t r_aon_clk_en4: 1;
        uint32_t r_aon_clk_en5: 1;
        uint32_t r_aon_clk_en6: 1;
        uint32_t r_aon_clk_en7: 1;
        uint32_t r_aon_clk_en8: 1;
        uint32_t r_aon_clk_en9: 1;
        uint32_t r_aon_clk_en10: 1;
        uint32_t r_aon_clk_en11: 1;
        uint32_t r_aon_clk_en12: 1;
        uint32_t r_aon_clk_en13: 1;
        uint32_t r_aon_clk_en14: 1;
        uint32_t r_aon_clk_en15: 1;
        uint32_t r_aon_clk_en16: 1;
        uint32_t r_aon_clk_en17: 1;
        uint32_t r_aon_clk_en18: 1;
        uint32_t r_aon_clk_en19: 1;
        uint32_t r_aon_clk_en20: 1;
        uint32_t r_aon_clk_en21: 1;
        uint32_t r_aon_clk_en22: 1;
        uint32_t r_aon_clk_en23: 1;
        uint32_t r_aon_clk_en24: 1;
        uint32_t r_aon_clk_en25: 1;
        uint32_t r_aon_clk_en26: 1;
        uint32_t r_aon_clk_en27: 1;
        uint32_t RSVD_3: 1;
        uint32_t RSVD_2: 1;
        uint32_t RSVD_1: 1;
        uint32_t RSVD: 1;
    };
} AON_REG00_CLK_TYPE;

/* 0x83C    0x4000_083c
    0       R/W r_aon_cko2_mux_src_sel0             1'b0
    1       R/W r_aon_f40m_mux_src_sel              1'b1
    2       R/W r_aon_cko2_mux_force_hp             1'b0
    3       R/W r_aon_sport0_pll_src_sel            1'b0
    4       R/W r_aon_sport1_pll_src_sel            1'b0
    5       R/W r_aon_sport2_pll_src_sel            1'b0
    6       R/W r_aon_sport3_pll_src_sel            1'b0
    7       R/W r_aon_dsp_pll_clk_src_sel0          1'b0
    8       R/W r_aon_dsp_pll_clk_src_sel1          1'b0
    9       R/W r_aon_cko2_mux_src_sel1             1'b0
    10      R/W r_aon_mclk_pll_src_sel              1'b0
    11      R/W r_aon_clk_sel0                      1'b0
    12      R/W r_aon_clk_sel1                      1'b0
    13      R/W r_aon_clk_sel2                      1'b0
    14      R/W r_aon_clk_sel3                      1'b0
    15      R/W r_aon_clk_sel4                      1'b0
    19:16   R/W r_aon_cko2_pll4_div_sel             4'b0
    31:20   R   RSVD                                12'b0
 */
typedef volatile union _AON_REG04_CLK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_aon_cko2_mux_src_sel0: 1;
        uint32_t r_aon_f40m_mux_src_sel: 1;
        uint32_t r_aon_cko2_mux_force_hp: 1;
        uint32_t r_aon_sport0_pll_src_sel: 1;
        uint32_t r_aon_sport1_pll_src_sel: 1;
        uint32_t r_aon_sport2_pll_src_sel: 1;
        uint32_t r_aon_sport3_pll_src_sel: 1;
        uint32_t r_aon_dsp_pll_clk_src_sel0: 1;
        uint32_t r_aon_dsp_pll_clk_src_sel1: 1;
        uint32_t r_aon_cko2_mux_src_sel1: 1;
        uint32_t r_aon_mclk_pll_src_sel: 1;
        uint32_t r_aon_clk_sel0: 1;
        uint32_t r_aon_clk_sel1: 1;
        uint32_t r_aon_clk_sel2: 1;
        uint32_t r_aon_clk_sel3: 1;
        uint32_t r_aon_clk_sel4: 1;
        uint32_t r_aon_cko2_pll4_div_sel: 4;
        uint32_t RSVD: 12;
    };
} AON_REG04_CLK_TYPE;

/* 0x840    0x4000_0840
    0       R/W saf_gpioA_nonsec_slave              1'b1
    1       R/W saf_gpioB_nonsec_slave              1'b1
    2       R/W saf_gpioC_nonsec_slave              1'b1
    3       R/W saf_gpioD_nonsec_slave              1'b1
    4       R/W saf_soc_vendor2_reg_nonsec_slave    1'b1
    5       R/W saf_qdec_nonsec_slave               1'b1
    6       R/W saf_key_scan_nonsec_slave           1'b1
    7       R/W saf_peri_on_nonsec_slave            1'b1
    8       R/W saf_aux_adc0_nonsec_slave           1'b1
    9       R/W saf_spi0_nonsec_slave               1'b1
    10      R/W saf_spi1_nonsec_slave               1'b1
    11      R/W saf_spi0_slave_nonsec_slave         1'b1
    12      R/W saf_i2c0_nonsec_slave               1'b1
    13      R/W saf_i2c1_nonsec_slave               1'b1
    14      R/W saf_i2c2_nonsec_slave               1'b1
    15      R/W saf_rtk_uart2_nonsec_slave          1'b1
    16      R/W saf_rtk_uart3_nonsec_slave          1'b1
    17      R/W saf_rtk_uart4_nonsec_slave          1'b1
    18      R/W saf_rtk_uart5_nonsec_slave          1'b1
    19      R/W saf_enhanced_timer_nonsec_slave     1'b1
    20      R/W saf_TimerB_nonsec_slave             1'b1
    21      R/W saf_rxi350_dmac1_cfg_nonsec_slave   1'b1
    22      R/W saf_usb_otg_cfg_nonsec_slave        1'b1
    23      R/W saf_gpu_cfg_nonsec_slave            1'b1
    24      R/W saf_sdio_host0_cfg_nonsec_slave     1'b1
    25      R/W saf_sdio_host1_cfg_nonsec_slave     1'b1
    26      R/W saf_spi2_hs_nonsec_slave            1'b1
    27      R/W saf_spi3_hs_nonsec_slave            1'b1
    28      R/W saf_i2s0_nonsec_slave               1'b1
    29      R/W saf_i2s1_nonsec_slave               1'b1
    30      R/W saf_i2s2_nonsec_slave               1'b1
    31      R/W saf_i2s3_nonsec_slave               1'b1
 */
typedef volatile union _AON_REG08_SAF_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t saf_gpioA_nonsec_slave: 1;
        uint32_t saf_gpioB_nonsec_slave: 1;
        uint32_t saf_gpioC_nonsec_slave: 1;
        uint32_t saf_gpioD_nonsec_slave: 1;
        uint32_t saf_soc_vendor2_reg_nonsec_slave: 1;
        uint32_t saf_qdec_nonsec_slave: 1;
        uint32_t saf_key_scan_nonsec_slave: 1;
        uint32_t saf_peri_on_nonsec_slave: 1;
        uint32_t saf_aux_adc0_nonsec_slave: 1;
        uint32_t saf_spi0_nonsec_slave: 1;
        uint32_t saf_spi1_nonsec_slave: 1;
        uint32_t saf_spi0_slave_nonsec_slave: 1;
        uint32_t saf_i2c0_nonsec_slave: 1;
        uint32_t saf_i2c1_nonsec_slave: 1;
        uint32_t saf_i2c2_nonsec_slave: 1;
        uint32_t saf_rtk_uart2_nonsec_slave: 1;
        uint32_t saf_rtk_uart3_nonsec_slave: 1;
        uint32_t saf_rtk_uart4_nonsec_slave: 1;
        uint32_t saf_rtk_uart5_nonsec_slave: 1;
        uint32_t saf_enhanced_timer_nonsec_slave: 1;
        uint32_t saf_TimerB_nonsec_slave: 1;
        uint32_t saf_rxi350_dmac1_cfg_nonsec_slave: 1;
        uint32_t saf_usb_otg_cfg_nonsec_slave: 1;
        uint32_t saf_gpu_cfg_nonsec_slave: 1;
        uint32_t saf_sdio_host0_cfg_nonsec_slave: 1;
        uint32_t saf_sdio_host1_cfg_nonsec_slave: 1;
        uint32_t saf_spi2_hs_nonsec_slave: 1;
        uint32_t saf_spi3_hs_nonsec_slave: 1;
        uint32_t saf_i2s0_nonsec_slave: 1;
        uint32_t saf_i2s1_nonsec_slave: 1;
        uint32_t saf_i2s2_nonsec_slave: 1;
        uint32_t saf_i2s3_nonsec_slave: 1;
    };
} AON_REG08_SAF_TYPE;

/* 0x844    0x4000_0844
    0       R/W saf_vadbuf_nonsec_slave             1'b1
    1       R/W saf_ecc_nonsec_slave                1'b1
    2       R/W saf_spi_codec_nonsec_slave          1'b1
    3       R/W saf_h2d_d2h_nonsec_slave            1'b1
    4       R/W saf_TimerC_nonsec_slave             1'b1
    5       R/W saf_rtk_uart6_nonsec_slave          1'b1
    6       R/W saf_ir_nonsec_slave                 1'b1
    7       R/W saf_i2c3_nonsec_slave               1'b1
    8       R/W saf_iso7816_nonsec_slave            1'b1
    9       R/W saf_rxi350_dmac2_cfg_nonsec_slave   1'b1
    10      R/W saf_public_key_engine_nonsec_slave  1'b1
    11      R/W saf_Flash_SEC0_nonsec_slave         1'b1
    12      R/W saf_AES_nonsec_slave                1'b1
    13      R/W saf_dummy_nonsec_slave              1'b1
    14      R/W saf_SHA3_nonsec_slave               1'b1
    15      R/W saf_spi2_nonsec_slave               1'b1
    16      R/W saf_spi3_nonsec_slave               1'b1
    17      R/W saf_mipi_nonsec_slave               1'b1
    18      R/W saf_display_ctrl_nonsec_slave       1'b1
    19      R/W saf_dsp_peripheral_nonsec_slave     1'b1
    20      R/W saf_TRNG_nonsec_slave               1'b1
    21      R/W saf_aux_adc1_nonsec_slave           1'b1
    22      R/W saf_SHA2_CTRL_nonsec_slave          1'b1
    23      R/W saf_SHA2_DMA_nonsec_slave           1'b1
    24      R/W saf_bluewiz_nonsec_slave            1'b1
    25      R/W saf_bt_vendor_reg_nonsec_slave      1'b1
    26      R/W saf_rxi350_dmac0_cfg_nonsec_slave   1'b1
    27      R/W saf_soc_vendor1_reg_nonsec_slave    1'b1
    28      R/W saf_TimerA_nonsec_slave             1'b1
    29      R/W saf_rtk_uart0_nonsec_slave          1'b1
    30      R/W saf_rtk_uart1_nonsec_slave          1'b1
    31      R/W saf_OTP_controller_nonsec_slave     1'b1
 */
typedef volatile union _AON_REG0C_SAF_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t saf_vadbuf_nonsec_slave: 1;
        uint32_t saf_ecc_nonsec_slave: 1;
        uint32_t saf_spi_codec_nonsec_slave: 1;
        uint32_t saf_h2d_d2h_nonsec_slave: 1;
        uint32_t saf_TimerC_nonsec_slave: 1;
        uint32_t saf_rtk_uart6_nonsec_slave: 1;
        uint32_t saf_ir_nonsec_slave: 1;
        uint32_t saf_i2c3_nonsec_slave: 1;
        uint32_t saf_iso7816_nonsec_slave: 1;
        uint32_t saf_rxi350_dmac2_cfg_nonsec_slave: 1;
        uint32_t saf_public_key_engine_nonsec_slave: 1;
        uint32_t saf_Flash_SEC0_nonsec_slave: 1;
        uint32_t saf_AES_nonsec_slave: 1;
        uint32_t saf_dummy_nonsec_slave: 1;
        uint32_t saf_SHA3_nonsec_slave: 1;
        uint32_t saf_spi2_nonsec_slave: 1;
        uint32_t saf_spi3_nonsec_slave: 1;
        uint32_t saf_mipi_nonsec_slave: 1;
        uint32_t saf_display_ctrl_nonsec_slave: 1;
        uint32_t saf_dsp_peripheral_nonsec_slave: 1;
        uint32_t saf_TRNG_nonsec_slave: 1;
        uint32_t saf_aux_adc1_nonsec_slave: 1;
        uint32_t saf_SHA2_CTRL_nonsec_slave: 1;
        uint32_t saf_SHA2_DMA_nonsec_slave: 1;
        uint32_t saf_bluewiz_nonsec_slave: 1;
        uint32_t saf_bt_vendor_reg_nonsec_slave: 1;
        uint32_t saf_rxi350_dmac0_cfg_nonsec_slave: 1;
        uint32_t saf_soc_vendor1_reg_nonsec_slave: 1;
        uint32_t saf_TimerA_nonsec_slave: 1;
        uint32_t saf_rtk_uart0_nonsec_slave: 1;
        uint32_t saf_rtk_uart1_nonsec_slave: 1;
        uint32_t saf_OTP_controller_nonsec_slave: 1;
    };
} AON_REG0C_SAF_TYPE;

/* 0x848    0x4000_0848
    0       R/W saf_aon_nonsec_slave                1'b1
    1       R/W saf_mae_nonsec_slave                1'b1
    2       R/W saf_ipc0_nonsec_slave               1'b1
    3       R/W saf_ipc1_nonsec_slave               1'b1
    4       R/W saf_ipc2_nonsec_slave               1'b1
    5       R/W saf_ipc3_nonsec_slave               1'b1
    6       R/W saf_ipc4_nonsec_slave               1'b1
    7       R/W saf_ipc5_nonsec_slave               1'b1
    8       R/W saf_soc_vendor0_reg_nonsec_slave    1'b1
    9       R/W saf_hw_mutex_nonsec_slave           1'b1
    10      R/W saf_Flash_SEC1_nonsec_slave         1'b1
    11      R/W saf_dummy0_nonsec_slave             1'b1
    12      R/W saf_dummy1_nonsec_slave             1'b1
    13      R/W saf_dummy2_nonsec_slave             1'b1
    14      R/W saf_dummy3_nonsec_slave             1'b1
    15      R/W saf_dummy4_nonsec_slave             1'b1
    16      W1O saf_lock                            1'b0
    17      R   RSVD                                1'b0
    18      R   RSVD                                1'b0
    19      R   RSVD                                1'b0
    20      R   RSVD                                1'b0
    21      R   RSVD                                1'b0
    22      R   RSVD                                1'b0
    23      R   RSVD                                1'b0
    24      R   RSVD                                1'b0
    25      R   RSVD                                1'b0
    26      R   RSVD                                1'b0
    27      R   RSVD                                1'b0
    28      R   RSVD                                1'b0
    29      R   RSVD                                1'b0
    30      R   RSVD                                1'b0
    31      R   RSVD                                1'b0
 */
typedef volatile union _AON_REG10_SAF_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t saf_aon_nonsec_slave: 1;
        uint32_t saf_mae_nonsec_slave: 1;
        uint32_t saf_ipc0_nonsec_slave: 1;
        uint32_t saf_ipc1_nonsec_slave: 1;
        uint32_t saf_ipc2_nonsec_slave: 1;
        uint32_t saf_ipc3_nonsec_slave: 1;
        uint32_t saf_ipc4_nonsec_slave: 1;
        uint32_t saf_ipc5_nonsec_slave: 1;
        uint32_t saf_soc_vendor0_reg_nonsec_slave: 1;
        uint32_t saf_hw_mutex_nonsec_slave: 1;
        uint32_t saf_Flash_SEC1_nonsec_slave: 1;
        uint32_t saf_dummy0_nonsec_slave: 1;
        uint32_t saf_dummy1_nonsec_slave: 1;
        uint32_t saf_dummy2_nonsec_slave: 1;
        uint32_t saf_dummy3_nonsec_slave: 1;
        uint32_t saf_dummy4_nonsec_slave: 1;
        uint32_t saf_lock: 1;
        uint32_t RSVD_14: 1;
        uint32_t RSVD_13: 1;
        uint32_t RSVD_12: 1;
        uint32_t RSVD_11: 1;
        uint32_t RSVD_10: 1;
        uint32_t RSVD_9: 1;
        uint32_t RSVD_8: 1;
        uint32_t RSVD_7: 1;
        uint32_t RSVD_6: 1;
        uint32_t RSVD_5: 1;
        uint32_t RSVD_4: 1;
        uint32_t RSVD_3: 1;
        uint32_t RSVD_2: 1;
        uint32_t RSVD_1: 1;
        uint32_t RSVD: 1;
    };
} AON_REG10_SAF_TYPE;

/* 0x84C    0x4000_084c
    0       R/W kr0_i_arprot_1                      1'b1
    1       R/W kr0_i_awprot_1                      1'b1
    2       R/W kr0_d_arprot_1                      1'b1
    3       R/W kr0_d_awprot_1                      1'b1
    4       R/W km0_arprot_1                        1'b1
    5       R/W km0_awprot_1                        1'b1
    6       R/W km0_pbus_arprot_1                   1'b1
    7       R/W km0_pbus_awprot_1                   1'b1
    8       R/W sha3_m_arprot_1                     1'b1
    9       R/W sha3_m_awprot_1                     1'b1
    10      R/W dsp_m_arprot_1                      1'b1
    11      R/W dsp_m_awprot_1                      1'b1
    12      R/W sdio_host0_hnonsec                  1'b1
    13      R/W sdio_host1_hnonsec                  1'b1
    14      R/W usbotg_hnonsec                      1'b1
    15      R/W display_arprot_1                    1'b1
    16      R/W display_awprot_1                    1'b1
    17      R/W gpu_arprot_1                        1'b1
    18      R/W gpu_awprot_1                        1'b1
    19      W1O sc_lock                             1'b0
    20      R   RSVD                                1'b0
    21      R   RSVD                                1'b0
    22      R   RSVD                                1'b0
    23      R   RSVD                                1'b0
    24      R   RSVD                                1'b0
    25      R   RSVD                                1'b0
    26      R   RSVD                                1'b0
    27      R   RSVD                                1'b0
    28      R   RSVD                                1'b0
    29      R   RSVD                                1'b0
    30      R   RSVD                                1'b0
    31      R   RSVD                                1'b0
 */
typedef volatile union _AON_REG14_SC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t kr0_i_arprot_1: 1;
        uint32_t kr0_i_awprot_1: 1;
        uint32_t kr0_d_arprot_1: 1;
        uint32_t kr0_d_awprot_1: 1;
        uint32_t km0_arprot_1: 1;
        uint32_t km0_awprot_1: 1;
        uint32_t km0_pbus_arprot_1: 1;
        uint32_t km0_pbus_awprot_1: 1;
        uint32_t sha3_m_arprot_1: 1;
        uint32_t sha3_m_awprot_1: 1;
        uint32_t dsp_m_arprot_1: 1;
        uint32_t dsp_m_awprot_1: 1;
        uint32_t sdio_host0_hnonsec: 1;
        uint32_t sdio_host1_hnonsec: 1;
        uint32_t usbotg_hnonsec: 1;
        uint32_t display_arprot_1: 1;
        uint32_t display_awprot_1: 1;
        uint32_t gpu_arprot_1: 1;
        uint32_t gpu_awprot_1: 1;
        uint32_t sc_lock: 1;
        uint32_t RSVD_11: 1;
        uint32_t RSVD_10: 1;
        uint32_t RSVD_9: 1;
        uint32_t RSVD_8: 1;
        uint32_t RSVD_7: 1;
        uint32_t RSVD_6: 1;
        uint32_t RSVD_5: 1;
        uint32_t RSVD_4: 1;
        uint32_t RSVD_3: 1;
        uint32_t RSVD_2: 1;
        uint32_t RSVD_1: 1;
        uint32_t RSVD: 1;
    };
} AON_REG14_SC_TYPE;

/* 0x850    0x4000_0850
    0       R/W S2_access_by_M4_en                  1'b1
    1       R/W S1_access_by_M4_en                  1'b1
    2       R/W S21_access_by_M5_en                 1'b1
    3       R/W S6_access_by_M5_en                  1'b1
    4       R/W S23_access_by_M7_en                 1'b1
    5       R/W S20_access_by_M7_en                 1'b1
    6       R/W S2_access_by_M7_en                  1'b1
    7       R/W S1_access_by_M7_en                  1'b1
    8       R/W S22_access_by_M7_en                 1'b1
    9       R/W S8_access_by_M7_en                  1'b1
    10      R/W S22_access_by_M8_en                 1'b1
    11      R/W S23_access_by_M8_en                 1'b1
    12      R/W S20_access_by_M8_en                 1'b1
    13      R/W S8_access_by_M8_en                  1'b1
    14      R/W S2_access_by_M8_en                  1'b1
    15      R/W S1_access_by_M8_en                  1'b1
    16      R/W S22_access_by_M2_en                 1'b1
    17      R/W S15_0_access_by_M2_en               1'b1
    18      R/W S14_0_access_by_M2_en               1'b1
    19      R/W S13_0_access_by_M2_en               1'b1
    20      R/W S12_0_access_by_M2_en               1'b1
    21      R/W S4_access_by_M2_en                  1'b1
    22      R/W S3_access_by_M2_en                  1'b1
    23      R/W S19_access_by_M3_en                 1'b1
    24      R/W S18_access_by_M3_en                 1'b1
    25      R/W S15_1_access_by_M3_en               1'b1
    26      R/W S14_1_access_by_M3_en               1'b1
    27      R/W S13_1_access_by_M3_en               1'b1
    28      R/W S12_1_access_by_M3_en               1'b1
    29      R/W S11_access_by_M3_en                 1'b1
    30      R/W S8_access_by_M3_en                  1'b1
    31      R/W S7_access_by_M3_en                  1'b1
 */
typedef volatile union _AON_REG18_SLV_ACC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t S2_access_by_M4_en: 1;
        uint32_t S1_access_by_M4_en: 1;
        uint32_t S21_access_by_M5_en: 1;
        uint32_t S6_access_by_M5_en: 1;
        uint32_t S23_access_by_M7_en: 1;
        uint32_t S20_access_by_M7_en: 1;
        uint32_t S2_access_by_M7_en: 1;
        uint32_t S1_access_by_M7_en: 1;
        uint32_t S22_access_by_M7_en: 1;
        uint32_t S8_access_by_M7_en: 1;
        uint32_t S22_access_by_M8_en: 1;
        uint32_t S23_access_by_M8_en: 1;
        uint32_t S20_access_by_M8_en: 1;
        uint32_t S8_access_by_M8_en: 1;
        uint32_t S2_access_by_M8_en: 1;
        uint32_t S1_access_by_M8_en: 1;
        uint32_t S22_access_by_M2_en: 1;
        uint32_t S15_0_access_by_M2_en: 1;
        uint32_t S14_0_access_by_M2_en: 1;
        uint32_t S13_0_access_by_M2_en: 1;
        uint32_t S12_0_access_by_M2_en: 1;
        uint32_t S4_access_by_M2_en: 1;
        uint32_t S3_access_by_M2_en: 1;
        uint32_t S19_access_by_M3_en: 1;
        uint32_t S18_access_by_M3_en: 1;
        uint32_t S15_1_access_by_M3_en: 1;
        uint32_t S14_1_access_by_M3_en: 1;
        uint32_t S13_1_access_by_M3_en: 1;
        uint32_t S12_1_access_by_M3_en: 1;
        uint32_t S11_access_by_M3_en: 1;
        uint32_t S8_access_by_M3_en: 1;
        uint32_t S7_access_by_M3_en: 1;
    };
} AON_REG18_SLV_ACC_TYPE;

/* 0x854    0x4000_0854
    0       R/W S23_access_by_M6_en                 1'b1
    1       R/W S15_0_access_by_M6_en               1'b1
    2       R/W S14_0_access_by_M6_en               1'b1
    3       R/W S13_0_access_by_M6_en               1'b1
    4       R/W S12_0_access_by_M6_en               1'b1
    5       R/W S4_access_by_M6_en                  1'b1
    6       R/W S3_access_by_M6_en                  1'b1
    7       R/W S22_access_by_M1_en                 1'b1
    8       R/W S12_0_access_by_M1_en               1'b1
    9       R/W S4_access_by_M1_en                  1'b1
    10      R/W S26_access_by_M7_en                 1'b1
    11      R/W S26_access_by_M8_en                 1'b1
    12      R/W S26_access_by_M6_en                 1'b1
    13      R/W S8_access_by_M6_en                  1'b1
    14      R/W S15_0_access_by_M1_en               1'b1
    15      W1O slv_acc_lock                        1'b0
    16      R   RSVD                                1'b0
    17      R   RSVD                                1'b0
    18      R   RSVD                                1'b0
    19      R   RSVD                                1'b0
    20      R   RSVD                                1'b0
    21      R   RSVD                                1'b0
    22      R   RSVD                                1'b0
    23      R   RSVD                                1'b0
    24      R   RSVD                                1'b0
    25      R   RSVD                                1'b0
    26      R   RSVD                                1'b0
    27      R   RSVD                                1'b0
    28      R   RSVD                                1'b0
    29      R   RSVD                                1'b0
    30      R   RSVD                                1'b0
    31      R   RSVD                                1'b0
 */
typedef volatile union _AON_REG1C_SLV_ACC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t S23_access_by_M6_en: 1;
        uint32_t S15_0_access_by_M6_en: 1;
        uint32_t S14_0_access_by_M6_en: 1;
        uint32_t S13_0_access_by_M6_en: 1;
        uint32_t S12_0_access_by_M6_en: 1;
        uint32_t S4_access_by_M6_en: 1;
        uint32_t S3_access_by_M6_en: 1;
        uint32_t S22_access_by_M1_en: 1;
        uint32_t S12_0_access_by_M1_en: 1;
        uint32_t S4_access_by_M1_en: 1;
        uint32_t S26_access_by_M7_en: 1;
        uint32_t S26_access_by_M8_en: 1;
        uint32_t S26_access_by_M6_en: 1;
        uint32_t S8_access_by_M6_en: 1;
        uint32_t S15_0_access_by_M1_en: 1;
        uint32_t slv_acc_lock: 1;
        uint32_t RSVD_15: 1;
        uint32_t RSVD_14: 1;
        uint32_t RSVD_13: 1;
        uint32_t RSVD_12: 1;
        uint32_t RSVD_11: 1;
        uint32_t RSVD_10: 1;
        uint32_t RSVD_9: 1;
        uint32_t RSVD_8: 1;
        uint32_t RSVD_7: 1;
        uint32_t RSVD_6: 1;
        uint32_t RSVD_5: 1;
        uint32_t RSVD_4: 1;
        uint32_t RSVD_3: 1;
        uint32_t RSVD_2: 1;
        uint32_t RSVD_1: 1;
        uint32_t RSVD: 1;
    };
} AON_REG1C_SLV_ACC_TYPE;

/* 0x858    0x4000_0858
    0       R/W km0_pbus_pmc_domain_on              1'b1
    1       R/W km0_pbus_sensor_domain_on           1'b1
    2       R/W km0_pbus_application_domain_on      1'b1
    3       R/W application_domain_on_pmc_platform  1'b1
    4       R/W sha_m_pmc_domain_on                 1'b1
    5       R/W sha_m_bluetooth_domain_on           1'b1
    6       R/W sha_m_sensor_domain_on              1'b1
    7       R/W dmac1_pmc_domain_on                 1'b1
    8       R/W dmac1_bluetooth_domain_on           1'b1
    9       R/W dmac1_application_domain_on         1'b1
    10      R/W km4_pmc_domain_on                   1'b1
    11      R/W km4_bluetooth_domain_on             1'b1
    12      R/W km4_application_domain_on           1'b1
    13      R/W km4_pbus_pmc_domain_on              1'b1
    14      R/W km4_pbus_bluetooth_domain_on        1'b1
    15      R/W km4_pbus_application_domain_on      1'b1
    16      R/W dmac2_pmc_domain_on                 1'b1
    17      R/W dmac2_bluetooth_domain_on           1'b1
    18      R/W dmac2_sensor_domain_on_0            1'b1
    19      R/W dmac2_sensor_domain_on_1            1'b1
    20      R/W sha3_m_bluetooth_domain_on          1'b1
    21      R/W sha3_m_sensor_domain_on             1'b1
    22      R/W dmac0_pmc_domain_on                 1'b1
    23      R/W dmac0_sensor_domain_on              1'b1
    24      R/W dmac0_application_domain_on         1'b1
    25      R/W km0_pmc_domain_on                   1'b1
    26      R/W km0_sensor_domain_on                1'b1
    27      R/W km0_application_domain_on           1'b1
    28      R/W display_sensor_domain_on            1'b1
    29      R   RSVD                                1'b0
    30      R   RSVD                                1'b0
    31      R/W reg_dsp_data_ram_en                 1'b0
 */
typedef volatile union _AON_REG20_SLV_ACC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t km0_pbus_pmc_domain_on: 1;
        uint32_t km0_pbus_sensor_domain_on: 1;
        uint32_t km0_pbus_application_domain_on: 1;
        uint32_t application_domain_on_pmc_platform: 1;
        uint32_t sha_m_pmc_domain_on: 1;
        uint32_t sha_m_bluetooth_domain_on: 1;
        uint32_t sha_m_sensor_domain_on: 1;
        uint32_t dmac1_pmc_domain_on: 1;
        uint32_t dmac1_bluetooth_domain_on: 1;
        uint32_t dmac1_application_domain_on: 1;
        uint32_t km4_pmc_domain_on: 1;
        uint32_t km4_bluetooth_domain_on: 1;
        uint32_t km4_application_domain_on: 1;
        uint32_t km4_pbus_pmc_domain_on: 1;
        uint32_t km4_pbus_bluetooth_domain_on: 1;
        uint32_t km4_pbus_application_domain_on: 1;
        uint32_t dmac2_pmc_domain_on: 1;
        uint32_t dmac2_bluetooth_domain_on: 1;
        uint32_t dmac2_sensor_domain_on_0: 1;
        uint32_t dmac2_sensor_domain_on_1: 1;
        uint32_t sha3_m_bluetooth_domain_on: 1;
        uint32_t sha3_m_sensor_domain_on: 1;
        uint32_t dmac0_pmc_domain_on: 1;
        uint32_t dmac0_sensor_domain_on: 1;
        uint32_t dmac0_application_domain_on: 1;
        uint32_t km0_pmc_domain_on: 1;
        uint32_t km0_sensor_domain_on: 1;
        uint32_t km0_application_domain_on: 1;
        uint32_t display_sensor_domain_on: 1;
        uint32_t RSVD_1: 1;
        uint32_t RSVD: 1;
        uint32_t reg_dsp_data_ram_en: 1;  //deprecated, refer to reg_data_ram_share_en
    };
} AON_REG20_SLV_ACC_TYPE;

/* 0x85C    0x4000_085c
    1:0     R/W kr0_div_sel                         2'b0
    2       R/W kr0_div_en                          1'b0
    3       R/W kr0_cpu_clk_en                      1'b0
    4       R/W kr0_bus_clk_en                      1'b0
    5       R/W kr0_pmc_mem_clk_en                  1'b0
    6       R/W r_cpu_pll_src_sel0                  1'b0
    7       R/W r_cpu_pll_src_sel1                  1'b0
    8       R/W r_cpu_clk_src_sel                   1'b0
    9       R   RSVD                                1'b0
    10      R   RSVD                                1'b1
    11      R   RSVD                                1'b0
    12      R   RSVD                                1'b0
    13      R   RSVD                                1'b0
    14      R   RSVD                                1'b0
    15      R   RSVD                                1'b0
    16      R   RSVD                                1'b0
    17      R   RSVD                                1'b0
    18      R   RSVD                                1'b0
    19      R   RSVD                                1'b0
    20      R   RSVD                                1'b0
    21      R   RSVD                                1'b0
    22      R   RSVD                                1'b0
    23      R   RSVD                                1'b0
    24      R   RSVD                                1'b0
    25      R   RSVD                                1'b0
    26      R   RSVD                                1'b0
    27      R   RSVD                                1'b0
    28      R   RSVD                                1'b0
    29      R   RSVD                                1'b0
    30      R   RSVD                                1'b0
    31      R   RSVD                                1'b0
 */
typedef volatile union _AON_REG24_KR0_CLK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t kr0_div_sel: 2;
        uint32_t kr0_div_en: 1;
        uint32_t kr0_cpu_clk_en: 1;
        uint32_t kr0_bus_clk_en: 1;
        uint32_t kr0_pmc_mem_clk_en: 1;
        uint32_t r_cpu_pll_src_sel0: 1;
        uint32_t r_cpu_pll_src_sel1: 1;
        uint32_t r_cpu_clk_src_sel: 1;
        uint32_t RSVD_22: 1;
        uint32_t RSVD_21: 1;
        uint32_t RSVD_20: 1;
        uint32_t RSVD_19: 1;
        uint32_t RSVD_18: 1;
        uint32_t RSVD_17: 1;
        uint32_t RSVD_16: 1;
        uint32_t RSVD_15: 1;
        uint32_t RSVD_14: 1;
        uint32_t RSVD_13: 1;
        uint32_t RSVD_12: 1;
        uint32_t RSVD_11: 1;
        uint32_t RSVD_10: 1;
        uint32_t RSVD_9: 1;
        uint32_t RSVD_8: 1;
        uint32_t RSVD_7: 1;
        uint32_t RSVD_6: 1;
        uint32_t RSVD_5: 1;
        uint32_t RSVD_4: 1;
        uint32_t RSVD_3: 1;
        uint32_t RSVD_2: 1;
        uint32_t RSVD_1: 1;
        uint32_t RSVD: 1;
    };
} AON_REG24_KR0_CLK_TYPE;

/* 0x860    0x4000_0860
    0       R/W km4_dbgen                           1'b1
    1       R/W km4_niden                           1'b1
    2       R/W km4_spiden                          1'b0
    3       R/W km4_spniden                         1'b1
    4       R/W km0_dbgen                           1'b0
    5       R/W km0_niden                           1'b1
    6       R/W kr0_dbgen                           1'b0
    7       W1O km4_dbgen_lock                      1'b0
    8       W1O km4_niden_lock                      1'b0
    9       W1O km4_spiden_lock                     1'b0
    10      W1O km4_spniden_lock                    1'b0
    11      W1O km0_dbgen_lock                      1'b0
    12      W1O km0_niden_lock                      1'b0
    13      W1O kr0_dbgen_lock                      1'b0
    14      R   RSVD                                1'b0
    15      R   RSVD                                1'b0
    16      R   RSVD                                1'b0
    17      R   RSVD                                1'b0
    18      R   RSVD                                1'b0
    19      R   RSVD                                1'b0
    20      R   RSVD                                1'b0
    21      R   RSVD                                1'b0
    22      R   RSVD                                1'b0
    23      R   RSVD                                1'b0
    24      R   RSVD                                1'b0
    25      R   RSVD                                1'b0
    26      R   RSVD                                1'b0
    31:27   R/W reg_data_ram_share_en               5'b0
 */
typedef volatile union _AON_REG28_KM4_DBG_CTRL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t km4_dbgen: 1;
        uint32_t km4_niden: 1;
        uint32_t km4_spiden: 1;
        uint32_t km4_spniden: 1;
        uint32_t km0_dbgen: 1;
        uint32_t km0_niden: 1;
        uint32_t kr0_dbgen: 1;
        uint32_t km4_dbgen_lock: 1;
        uint32_t km4_niden_lock: 1;
        uint32_t km4_spiden_lock: 1;
        uint32_t km4_spniden_lock: 1;
        uint32_t km0_dbgen_lock: 1;
        uint32_t km0_niden_lock: 1;
        uint32_t kr0_dbgen_lock: 1;
        uint32_t RSVD_12: 1;
        uint32_t RSVD_11: 1;
        uint32_t RSVD_10: 1;
        uint32_t RSVD_9: 1;
        uint32_t RSVD_8: 1;
        uint32_t RSVD_7: 1;
        uint32_t RSVD_6: 1;
        uint32_t RSVD_5: 1;
        uint32_t RSVD_4: 1;
        uint32_t RSVD_3: 1;
        uint32_t RSVD_2: 1;
        uint32_t RSVD_1: 1;
        uint32_t RSVD: 1;
        uint32_t reg_data_ram_share_en: 5;
    };
} AON_REG28_KM4_DBG_CTRL_TYPE;

/* 0x864    0x4000_0864
    15:0    R/W OSC40M_cal_target_value             16'h4C4
    16      R/W OSC40M_cal_en                       1'b0
    17      R/W OSC40M_cal_soft_ctrl                1'b0
    20:18   R/W OSC40M_cal_gain                     3'b100
    22:21   R/W OSC40M_cal_cycle_per_k              2'b0
    24:23   R/W OSC40M_cal_div_clk_sel              2'b0
    27:25   R/W OSC40M_cal_alpha                    3'h0
    28      R/W OSC40M_cal_bypass_ACQ               1'b0
    31:29   R/W OSC40M_cal_ctrl1_DUMMY              3'h0
 */
typedef volatile union _AON_REG32_OSC40M_CAL_CTRL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t OSC40M_cal_target_value: 16;
        uint32_t OSC40M_cal_en: 1;
        uint32_t OSC40M_cal_soft_ctrl: 1;
        uint32_t OSC40M_cal_gain: 3;
        uint32_t OSC40M_cal_cycle_per_k: 2;
        uint32_t OSC40M_cal_div_clk_sel: 2;
        uint32_t OSC40M_cal_alpha: 3;
        uint32_t OSC40M_cal_bypass_ACQ: 1;
        uint32_t OSC40M_cal_ctrl1_DUMMY: 3;
    };
} AON_REG32_OSC40M_CAL_CTRL_TYPE;

/* 0x868    0x4000_0868
    0       R/W OSC40M_cal_rst_n                    1'b0
    8:1     R   OSC40M_cal_RCAL                     8'b0
    9       R   OSC40M_cal_K_ready                  1'b0
    31:10   R/W OSC40M_cal_ctrl2_DUMMY              22'h0
 */
typedef volatile union _AON_REG36_OSC40M_CAL_CTRL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t OSC40M_cal_rst_n: 1;
        uint32_t OSC40M_cal_RCAL: 8;
        uint32_t OSC40M_cal_K_ready: 1;
        uint32_t OSC40M_cal_ctrl2_DUMMY: 22;
    };
} AON_REG36_OSC40M_CAL_CTRL_TYPE;

/* 0x86C    0x4000_086c
    15:0    R/W OCC_debug_en_bus0                   16'h0
    31:16   R/W OCC_debug_en_bus1                   16'h0
 */
typedef volatile union _AON_OCC_debug_en_bus_0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t OCC_debug_en_bus0: 16;
        uint32_t OCC_debug_en_bus1: 16;
    };
} AON_OCC_debug_en_bus_0_TYPE;

/* 0x870    0x4000_0870
    15:0    R/W OCC_debug_en_bus2                   16'h0
    31:16   R/W OCC_debug_en_bus3                   16'h0
 */
typedef volatile union _AON_OCC_debug_en_bus_2_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t OCC_debug_en_bus2: 16;
        uint32_t OCC_debug_en_bus3: 16;
    };
} AON_OCC_debug_en_bus_2_TYPE;

/* 0x874    0x4000_0874
    7:0     R/W ST_PON_KM4_LDO_BIAS_DUMMY           8'hf0
    15:8    R/W ST_PON_OTP_DUMMY                    8'hf0
    23:16   R/W ST_PON_AON_RST_DUMMY                8'hf0
    31:24   R/W ST_IDLE_DUMMY                       8'hf0
 */
typedef volatile union _AON_HW_FSM_DUMMY_1_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t ST_PON_KM4_LDO_BIAS_DUMMY: 8;
        uint32_t ST_PON_OTP_DUMMY: 8;
        uint32_t ST_PON_AON_RST_DUMMY: 8;
        uint32_t ST_IDLE_DUMMY: 8;
    };
} AON_HW_FSM_DUMMY_1_TYPE;

/* 0x878    0x4000_0878
    7:0     R/W ST_PON_ISO_DUMMY                    8'hf0
    15:8    R/W ST_PON_PC_VG2_DUMMY                 8'hf0
    23:16   R/W ST_PON_PC_VG1_DUMMY                 8'hf0
    31:24   R/W ST_PON_KM4_LDO_DUMMY                8'hf0
 */
typedef volatile union _AON_HW_FSM_DUMMY_2_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t ST_PON_ISO_DUMMY: 8;
        uint32_t ST_PON_PC_VG2_DUMMY: 8;
        uint32_t ST_PON_PC_VG1_DUMMY: 8;
        uint32_t ST_PON_KM4_LDO_DUMMY: 8;
    };
} AON_HW_FSM_DUMMY_2_TYPE;

/* 0x87C    0x4000_087c
    7:0     R/W ST_POF_KR0_CG_DUMMY                 8'hf0
    15:8    R/W ST_POF_KR0_RSTB_DUMMY               8'hf0
    23:16   R/W ST_ACTIVE_DUMMY                     8'hf0
    31:24   R/W ST_PON_CG_DUMMY                     8'hf0
 */
typedef volatile union _AON_HW_FSM_DUMMY_3_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t ST_POF_KR0_CG_DUMMY: 8;
        uint32_t ST_POF_KR0_RSTB_DUMMY: 8;
        uint32_t ST_ACTIVE_DUMMY: 8;
        uint32_t ST_PON_CG_DUMMY: 8;
    };
} AON_HW_FSM_DUMMY_3_TYPE;

/* 0x880    0x4000_0880
    7:0     R/W ST_WFI_POF_CG_DUMMY                 8'hf0
    15:8    R/W ST_PWRDWN_DUMMY                     8'hf0
    23:16   R/W ST_POF_KR0_PC_DUMMY                 8'hf0
    31:24   R/W ST_POF_KR0_ISO_DUMMY                8'hf0
 */
typedef volatile union _AON_HW_FSM_DUMMY_4_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t ST_WFI_POF_CG_DUMMY: 8;
        uint32_t ST_PWRDWN_DUMMY: 8;
        uint32_t ST_POF_KR0_PC_DUMMY: 8;
        uint32_t ST_POF_KR0_ISO_DUMMY: 8;
    };
} AON_HW_FSM_DUMMY_4_TYPE;

/* 0x884    0x4000_0884
    7:0     R/W ST_WFI_PON_ROM_RAM_DUMMY            8'hf0
    15:8    R/W ST_WFI_PON_40MOSC_DUMMY             8'hf0
    23:16   R/W ST_WFI_POF_40MOSC_DUMMY             8'hf0
    31:24   R/W ST_WFI_POF_ROM_RAM_DUMMY            8'hf0
 */
typedef volatile union _AON_HW_FSM_DUMMY_5_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t ST_WFI_PON_ROM_RAM_DUMMY: 8;
        uint32_t ST_WFI_PON_40MOSC_DUMMY: 8;
        uint32_t ST_WFI_POF_40MOSC_DUMMY: 8;
        uint32_t ST_WFI_POF_ROM_RAM_DUMMY: 8;
    };
} AON_HW_FSM_DUMMY_5_TYPE;

/* 0x888    0x4000_0888
    7:0     R/W ST_WFI_PON_CG_DUMMY                 8'hf0
    15:8    R/W ST_WFI_POF_ISO_DUMMY                8'hf0
    23:16   R/W ST_WFI_PON_ISO_DUMMY                8'hf0
    31:24   R/W HW_FSM_DUMMY_6_DUMMY                8'hf0
 */
typedef volatile union _AON_HW_FSM_DUMMY_6_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t ST_WFI_PON_CG_DUMMY: 8;
        uint32_t ST_WFI_POF_ISO_DUMMY: 8;
        uint32_t ST_WFI_PON_ISO_DUMMY: 8;
        uint32_t HW_FSM_DUMMY_6_DUMMY: 8;
    };
} AON_HW_FSM_DUMMY_6_TYPE;

/* 0x88C    0x4000_088c
    1:0     R/W LDO_M0_POS_STEP_SIZE                2'b10
    4:2     R/W LDO_M0_POS_WAIT                     3'b1
    8:5     R/W LDO_M0_POS_STEP                     4'b1
    13:9    R/W flag4_pon_set_m0                    5'b11111
    18:14   R/W REG08_POS_DUMMY_1                   5'b0
    19      R/W LDO_M0_POS_RSTB                     1'b1
    20      R/W LDO_M0_EN_POS                       1'b0
    31:21   R/W REG08_POS_DUMMY                     11'b0
 */
typedef volatile union _AON_REG08_POS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LDO_M0_POS_STEP_SIZE: 2;
        uint32_t LDO_M0_POS_WAIT: 3;
        uint32_t LDO_M0_POS_STEP: 4;
        uint32_t flag4_pon_set_m0: 5;
        uint32_t REG08_POS_DUMMY_1: 5;
        uint32_t LDO_M0_POS_RSTB: 1;
        uint32_t LDO_M0_EN_POS: 1;
        uint32_t REG08_POS_DUMMY: 11;
    };
} AON_REG08_POS_TYPE;

/* 0x890    0x4000_0890
    0       R   BT_READY_PLL4                       1'b0
    1       R   BT_READY_PLL3                       1'b0
    2       R   BT_READY_PLL2                       1'b0
    3       R   BT_READY_PLL1                       1'b0
    4       R/W CLK_DIV_EN_OSC40M_AON               1'b1
    7:5     R/W CLK_DIV_SEL_OSC40M_AON              3'b001
    31:8    R/W REG06_SYS_DUMMY                     24'b0
 */
typedef volatile union _AON_REG06_SYS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t BT_READY_PLL4: 1;
        uint32_t BT_READY_PLL3: 1;
        uint32_t BT_READY_PLL2: 1;
        uint32_t BT_READY_PLL1: 1;
        uint32_t CLK_DIV_EN_OSC40M_AON: 1;
        uint32_t CLK_DIV_SEL_OSC40M_AON: 3;
        uint32_t REG06_SYS_DUMMY: 24;
    };
} AON_REG06_SYS_TYPE;

/* 0x894    0x4000_0894
    15:0    R/W OCC_debug_en_bus4                   16'h0
    31:16   R/W OCC_debug_en_bus5                   16'h0
 */
typedef volatile union _AON_OCC_debug_en_bus4_1_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t OCC_debug_en_bus4: 16;
        uint32_t OCC_debug_en_bus5: 16;
    };
} AON_OCC_debug_en_bus4_1_TYPE;

/* 0x898    0x4000_0898
    0       R/W AON_4_CLAMP_ESDCTRL                 1'b1
    1       R/W AON_3_CLAMP_ESDCTRL                 1'b1
    2       R/W AON_2_CLAMP_ESDCTRL                 1'b1
    3       R/W AON_1_CLAMP_ESDCTRL                 1'b1
    4       R/W CORE_4_CLAMP_ESDCTRL                1'b1
    5       R/W CORE_3_CLAMP_ESDCTRL                1'b1
    6       R/W CORE_2_CLAMP_ESDCTRL                1'b1
    7       R/W CORE_1_CLAMP_ESDCTRL                1'b1
    31:8    R/W CLAMP_ESDCTRL_DUMMY                 24'h0
 */
typedef volatile union _AON_CLAMP_ESDCTRL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t AON_4_CLAMP_ESDCTRL: 1;
        uint32_t AON_3_CLAMP_ESDCTRL: 1;
        uint32_t AON_2_CLAMP_ESDCTRL: 1;
        uint32_t AON_1_CLAMP_ESDCTRL: 1;
        uint32_t CORE_4_CLAMP_ESDCTRL: 1;
        uint32_t CORE_3_CLAMP_ESDCTRL: 1;
        uint32_t CORE_2_CLAMP_ESDCTRL: 1;
        uint32_t CORE_1_CLAMP_ESDCTRL: 1;
        uint32_t CLAMP_ESDCTRL_DUMMY: 24;
    };
} AON_CLAMP_ESDCTRL_TYPE;

/* 0xAB0    0x4000_0ab0
    0       R/W LOP_PON_ENPC_AON_2_VG1              1'b1
    1       R/W LOP_PON_ENPC_AON_1_VG1              1'b1
    2       R/W LOP_PON_ENPC_AON_2_VG2              1'b1
    3       R/W LOP_PON_ENPC_AON_1_VG2              1'b1
    8:4     R/W LOP_PON_LDOAON_VOUT_TUNE            5'b10110
    9       R/W LOP_PON_LDOAON_EN_DMYL_70U          1'b1
    10      R/W LOP_PON_LDOAON_EN_DMYL_1M           1'b0
    11      R/W LOP_PON_LDOAON_EN_DMYL_10U          1'b1
    12      R/W LOP_PON_LDOAON_ENLDO_IB20nA         1'b1
    13      R/W LOP_PON_ISO_BT_SRAM_4_2             1'b0
    14      R/W LOP_PON_ISO_BT_SRAM_4_1             1'b0
    15      R/W LOP_PON_r_PGEN_kr0_log_iso0         1'b0
    17:16   R/W LOP_PON_r_PGEN_kr0_ipc_iso0         2'b0
    18      R/W LOP_PON_r_PGEN_kr0_pmc_iso0         1'b0
    19      R/W LOP_PON_r_RET2N_kr0_log_iso0        1'b1
    21:20   R/W LOP_PON_r_RET2N_kr0_ipc_iso0        2'b11
    22      R/W LOP_PON_r_RET2N_kr0_pmc_iso0        1'b1
    23      R/W LOP_PON_r_RET1N_kr0_log_iso0        1'b1
    25:24   R/W LOP_PON_r_RET1N_kr0_ipc_iso0        2'b11
    26      R/W LOP_PON_r_RET1N_kr0_pmc_iso0        1'b1
    31:27   R/W LOP_RG0X_DUMMY                      5'b0
 */
typedef volatile union _AON_LOP_RG0X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LOP_PON_ENPC_AON_2_VG1: 1;
        uint32_t LOP_PON_ENPC_AON_1_VG1: 1;
        uint32_t LOP_PON_ENPC_AON_2_VG2: 1;
        uint32_t LOP_PON_ENPC_AON_1_VG2: 1;
        uint32_t LOP_PON_LDOAON_VOUT_TUNE: 5;
        uint32_t LOP_PON_LDOAON_EN_DMYL_70U: 1;
        uint32_t LOP_PON_LDOAON_EN_DMYL_1M: 1;
        uint32_t LOP_PON_LDOAON_EN_DMYL_10U: 1;
        uint32_t LOP_PON_LDOAON_ENLDO_IB20nA: 1;
        uint32_t LOP_PON_ISO_BT_SRAM_4_2: 1;
        uint32_t LOP_PON_ISO_BT_SRAM_4_1: 1;
        uint32_t LOP_PON_r_PGEN_kr0_log_iso0: 1;
        uint32_t LOP_PON_r_PGEN_kr0_ipc_iso0: 2;
        uint32_t LOP_PON_r_PGEN_kr0_pmc_iso0: 1;
        uint32_t LOP_PON_r_RET2N_kr0_log_iso0: 1;
        uint32_t LOP_PON_r_RET2N_kr0_ipc_iso0: 2;
        uint32_t LOP_PON_r_RET2N_kr0_pmc_iso0: 1;
        uint32_t LOP_PON_r_RET1N_kr0_log_iso0: 1;
        uint32_t LOP_PON_r_RET1N_kr0_ipc_iso0: 2;
        uint32_t LOP_PON_r_RET1N_kr0_pmc_iso0: 1;
        uint32_t LOP_RG0X_DUMMY: 5;
    };
} AON_LOP_RG0X_TYPE;

/* 0xAB4    0x4000_0ab4
    0       R/W LOP_PON_ISO_BT_AON_2                1'b0
    1       R/W LOP_PON_ISO_BT_AON_1                1'b0
    2       R/W LOP_PON_ISO_BT_SRAM_4_0             1'b0
    3       R/W LOP_PON_ISO_BT_SRAM_3_3             1'b0
    4       R/W LOP_PON_ISO_BT_SRAM_3_2             1'b0
    5       R/W LOP_PON_ISO_BT_SRAM_3_1             1'b0
    6       R/W LOP_PON_ISO_BT_SRAM_3_0             1'b0
    7       R/W LOP_PON_ISO_BT_SRAM_2_2             1'b0
    8       R/W LOP_PON_ISO_BT_SRAM_2_1             1'b0
    9       R/W LOP_PON_ISO_BT_SRAM_2_0             1'b0
    10      R/W LOP_PON_ISO_BT_CORE_4               1'b0
    11      R/W LOP_PON_ISO_BT_CORE_3               1'b0
    12      R/W LOP_PON_ISO_BT_CORE_2               1'b0
    13      R/W LOP_PON_r_aon_clk_en13              1'b1
    14      R/W LOP_PON_r_aon_clk_en12              1'b1
    15      R/W LOP_PON_r_aon_clk_en11              1'b1
    16      R/W LOP_PON_r_aon_clk_en10              1'b1
    17      R/W LOP_PON_kr0_cpu_clk_en              1'b1
    18      R/W LOP_PON_KM4_CORE4_RSTB              1'b1
    19      R/W LOP_PON_KM4_CORE3_RSTB              1'b1
    20      R/W LOP_PON_KM4_CORE2_RSTB              1'b1
    21      R/W LOP_PON_KR0_SRAM_BUS_RSTB           1'b1
    22      R/W LOP_PON_KR0_CPU_RSTB_BY_HW_FSM      1'b1
    23      R/W LOP_PON_ENPC_AON_3_VG2              1'b1
    24      R/W LOP_PON_ENPC_AON_3_VG1              1'b1
    25      R/W LOP_PON_AON1_RSTB                   1'b1
    26      R/W LOP_PON_ISO_BT_AON_3                1'b0
    27      R/W LOP_PON_AON_REG_RST                 1'b0
    28      R/W LOP_PON_kr0_bus_clk_en              1'b1
    29      R/W LOP_PON_kr0_pmc_mem_clk_en          1'b1
    30      R/W LOP_PON_M4_RET_RSTB                 1'b1
    31      R/W LOP_PON_AON2_RSTB                   1'b1
 */
typedef volatile union _AON_LOP_RG1X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LOP_PON_ISO_BT_AON_2: 1;
        uint32_t LOP_PON_ISO_BT_AON_1: 1;
        uint32_t LOP_PON_ISO_BT_SRAM_4_0: 1;
        uint32_t LOP_PON_ISO_BT_SRAM_3_3: 1;
        uint32_t LOP_PON_ISO_BT_SRAM_3_2: 1;
        uint32_t LOP_PON_ISO_BT_SRAM_3_1: 1;
        uint32_t LOP_PON_ISO_BT_SRAM_3_0: 1;
        uint32_t LOP_PON_ISO_BT_SRAM_2_2: 1;
        uint32_t LOP_PON_ISO_BT_SRAM_2_1: 1;
        uint32_t LOP_PON_ISO_BT_SRAM_2_0: 1;
        uint32_t LOP_PON_ISO_BT_CORE_4: 1;
        uint32_t LOP_PON_ISO_BT_CORE_3: 1;
        uint32_t LOP_PON_ISO_BT_CORE_2: 1;
        uint32_t LOP_PON_r_aon_clk_en13: 1;
        uint32_t LOP_PON_r_aon_clk_en12: 1;
        uint32_t LOP_PON_r_aon_clk_en11: 1;
        uint32_t LOP_PON_r_aon_clk_en10: 1;
        uint32_t LOP_PON_kr0_cpu_clk_en: 1;
        uint32_t LOP_PON_KM4_CORE4_RSTB: 1;
        uint32_t LOP_PON_KM4_CORE3_RSTB: 1;
        uint32_t LOP_PON_KM4_CORE2_RSTB: 1;
        uint32_t LOP_PON_KR0_SRAM_BUS_RSTB: 1;
        uint32_t LOP_PON_KR0_CPU_RSTB_BY_HW_FSM: 1;
        uint32_t LOP_PON_ENPC_AON_3_VG2: 1;
        uint32_t LOP_PON_ENPC_AON_3_VG1: 1;
        uint32_t LOP_PON_AON1_RSTB: 1;
        uint32_t LOP_PON_ISO_BT_AON_3: 1;
        uint32_t LOP_PON_AON_REG_RST: 1;
        uint32_t LOP_PON_kr0_bus_clk_en: 1;
        uint32_t LOP_PON_kr0_pmc_mem_clk_en: 1;
        uint32_t LOP_PON_M4_RET_RSTB: 1;
        uint32_t LOP_PON_AON2_RSTB: 1;
    };
} AON_LOP_RG1X_TYPE;

/* 0xAB8    0x4000_0ab8
    0       R/W LOP_POF_KR0_SRAM_BUS_RSTB           1'b0
    1       R/W LOP_POF_KR0_CPU_RSTB_BY_HW_FSM      1'b0
    2       R/W LOP_POF_kr0_cpu_clk_en              1'b0
    3       R/W LOP_POF_ISO_BT_AON_2                1'b1
    4       R/W LOP_POF_ISO_BT_AON_1                1'b1
    5       R/W LOP_POF_ENPC_AON_2_VG1              1'b0
    6       R/W LOP_POF_ENPC_AON_1_VG1              1'b0
    7       R/W LOP_POF_ENPC_AON_2_VG2              1'b0
    8       R/W LOP_POF_ENPC_AON_1_VG2              1'b0
    9       R/W LOP_POF_POW_32KOSC                  1'b0
    10      R/W LOP_POF_POW_32KXTAL                 1'b0
    11      R/W LOP_POF_POW_40M_OSC_R0              1'b0
    12      R/W LOP_POF_ENPC_AON_3_VG2              1'b1
    13      R/W LOP_POF_ENPC_AON_3_VG1              1'b1
    14      R/W LOP_POF_AON1_RSTB                   1'b0
    15      R/W LOP_POF_ISO_BT_AON_3                1'b0
    16      R/W LOP_POF_kr0_bus_clk_en              1'b0
    17      R/W LOP_POF_kr0_pmc_mem_clk_en          1'b0
    22:18   R/W LOP_POF_LDOAON_VOUT_TUNE            5'b01111
    23      R/W LOP_POF_LDOAON_EN_DMYL_70U          1'b0
    24      R/W LOP_POF_LDOAON_EN_DMYL_1M           1'b0
    25      R/W LOP_POF_LDOAON_EN_DMYL_10U          1'b0
    26      R/W LOP_POF_LDOAON_ENLDO_IB20nA         1'b0
    27      R/W LOP_POF_CLK_DIV_EN_OSC40M_AON       1'b1
    30:28   R/W LOP_POF_CLK_DIV_SEL_OSC40M_AON      3'b1
    31      R/W LOP_POF_OSC40M_cal_en               1'b0
 */
typedef volatile union _AON_LOP_RG2X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LOP_POF_KR0_SRAM_BUS_RSTB: 1;
        uint32_t LOP_POF_KR0_CPU_RSTB_BY_HW_FSM: 1;
        uint32_t LOP_POF_kr0_cpu_clk_en: 1;
        uint32_t LOP_POF_ISO_BT_AON_2: 1;
        uint32_t LOP_POF_ISO_BT_AON_1: 1;
        uint32_t LOP_POF_ENPC_AON_2_VG1: 1;
        uint32_t LOP_POF_ENPC_AON_1_VG1: 1;
        uint32_t LOP_POF_ENPC_AON_2_VG2: 1;
        uint32_t LOP_POF_ENPC_AON_1_VG2: 1;
        uint32_t LOP_POF_POW_32KOSC: 1;
        uint32_t LOP_POF_POW_32KXTAL: 1;
        uint32_t LOP_POF_POW_40M_OSC_R0: 1;
        uint32_t LOP_POF_ENPC_AON_3_VG2: 1;
        uint32_t LOP_POF_ENPC_AON_3_VG1: 1;
        uint32_t LOP_POF_AON1_RSTB: 1;
        uint32_t LOP_POF_ISO_BT_AON_3: 1;
        uint32_t LOP_POF_kr0_bus_clk_en: 1;
        uint32_t LOP_POF_kr0_pmc_mem_clk_en: 1;
        uint32_t LOP_POF_LDOAON_VOUT_TUNE: 5;
        uint32_t LOP_POF_LDOAON_EN_DMYL_70U: 1;
        uint32_t LOP_POF_LDOAON_EN_DMYL_1M: 1;
        uint32_t LOP_POF_LDOAON_EN_DMYL_10U: 1;
        uint32_t LOP_POF_LDOAON_ENLDO_IB20nA: 1;
        uint32_t LOP_POF_CLK_DIV_EN_OSC40M_AON: 1;
        uint32_t LOP_POF_CLK_DIV_SEL_OSC40M_AON: 3;
        uint32_t LOP_POF_OSC40M_cal_en: 1;
    };
} AON_LOP_RG2X_TYPE;

/* 0xABC    0x4000_0abc
    7:0     R/W LOP_PON_KM4_LDO_BIAS_DELAY          8'h62
    15:8    R/W LOP_PON_KM4_LDO_DELAY               8'h62
    23:16   R/W LOP_PON_PC_VG1_DELAY                8'h62
    31:24   R/W LOP_PON_PC_VG2_DELAY                8'h62
 */
typedef volatile union _AON_LOP_RG3X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LOP_PON_KM4_LDO_BIAS_DELAY: 8;
        uint32_t LOP_PON_KM4_LDO_DELAY: 8;
        uint32_t LOP_PON_PC_VG1_DELAY: 8;
        uint32_t LOP_PON_PC_VG2_DELAY: 8;
    };
} AON_LOP_RG3X_TYPE;

/* 0xAC0    0x4000_0ac0
    7:0     R/W LOP_PON_ISO_DELAY                   8'h62
    15:8    R/W LOP_PON_CG_DELAY                    8'h62
    31:16   R/W LOP_RG4X_DUMMY                      16'haa
 */
typedef volatile union _AON_LOP_RG4X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LOP_PON_ISO_DELAY: 8;
        uint32_t LOP_PON_CG_DELAY: 8;
        uint32_t LOP_RG4X_DUMMY: 16;
    };
} AON_LOP_RG4X_TYPE;

/* 0xAC4    0x4000_0ac4
    7:0     R/W LOP_POF_KR0_ISO_DELAY               8'hc3
    15:8    R/W LOP_POF_KR0_PC_DELAY                8'hc3
    23:16   R/W LOP_POF_KR0_RSTB_DELAY              8'hc3
    31:24   R/W LOP_POF_KR0_CG_DELAY                8'hc3
 */
typedef volatile union _AON_LOP_RG5X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LOP_POF_KR0_ISO_DELAY: 8;
        uint32_t LOP_POF_KR0_PC_DELAY: 8;
        uint32_t LOP_POF_KR0_RSTB_DELAY: 8;
        uint32_t LOP_POF_KR0_CG_DELAY: 8;
    };
} AON_LOP_RG5X_TYPE;

/* 0xAC8    0x4000_0ac8
    7:0     R/W WFI_PON_ISO_DELAY                   8'hc
    15:8    R/W WFI_PON_ROM_RAM_DELAY               8'hc
    23:16   R/W WFI_PON_40MOSC_DELAY                8'hc
    25:24   R/W WFI_PON_ISO_DELAY_STEP              2'b11
    27:26   R/W WFI_PON_ROM_RAM_DELAY_STEP          2'b11
    29:28   R/W WFI_PON_40MOSC_DELAY_STEP           2'b11
    31:30   R/W LOP_RG6X_DUMMY                      2'b10
 */
typedef volatile union _AON_LOP_RG6X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t WFI_PON_ISO_DELAY: 8;
        uint32_t WFI_PON_ROM_RAM_DELAY: 8;
        uint32_t WFI_PON_40MOSC_DELAY: 8;
        uint32_t WFI_PON_ISO_DELAY_STEP: 2;
        uint32_t WFI_PON_ROM_RAM_DELAY_STEP: 2;
        uint32_t WFI_PON_40MOSC_DELAY_STEP: 2;
        uint32_t LOP_RG6X_DUMMY: 2;
    };
} AON_LOP_RG6X_TYPE;

/* 0xACC    0x4000_0acc
    7:0     R/W WFI_POF_CG_DELAY                    8'hc
    15:8    R/W WFI_POF_ISO_DELAY                   8'hc
    23:16   R/W WFI_POF_ROM_RAM_DELAY               8'hc
    25:24   R/W WFI_POF_CG_DELAY_STEP               2'b11
    27:26   R/W WFI_POF_ISO_DELAY_STEP              2'b11
    29:28   R/W WFI_POF_ROM_RAM_DELAY_STEP          2'b11
    31:30   R/W LOP_RG7X_DUMMY                      2'b10
 */
typedef volatile union _AON_LOP_RG7X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t WFI_POF_CG_DELAY: 8;
        uint32_t WFI_POF_ISO_DELAY: 8;
        uint32_t WFI_POF_ROM_RAM_DELAY: 8;
        uint32_t WFI_POF_CG_DELAY_STEP: 2;
        uint32_t WFI_POF_ISO_DELAY_STEP: 2;
        uint32_t WFI_POF_ROM_RAM_DELAY_STEP: 2;
        uint32_t LOP_RG7X_DUMMY: 2;
    };
} AON_LOP_RG7X_TYPE;

/* 0xAD0    0x4000_0ad0
    1:0     R/W LOP_POF_KR0_RSTB_DELAY_STEP         2'b11
    3:2     R/W LOP_POF_KR0_CG_DELAY_STEP           2'b11
    5:4     R/W LOP_POF_KR0_ISO_DELAY_STEP          2'b11
    7:6     R/W LOP_POF_KR0_PC_DELAY_STEP           2'b11
    31:8    R/W LOP_RG8X_DUMMY                      24'b0
 */
typedef volatile union _AON_LOP_RG8X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LOP_POF_KR0_RSTB_DELAY_STEP: 2;
        uint32_t LOP_POF_KR0_CG_DELAY_STEP: 2;
        uint32_t LOP_POF_KR0_ISO_DELAY_STEP: 2;
        uint32_t LOP_POF_KR0_PC_DELAY_STEP: 2;
        uint32_t LOP_RG8X_DUMMY: 24;
    };
} AON_LOP_RG8X_TYPE;

/* 0xAD4    0x4000_0ad4
    1:0     R/W LOP_PON_KM4_LDO_BIAS_DELAY_STEP     2'b11
    3:2     R/W LOP_PON_KM4_LDO_DELAY_STEP          2'b11
    5:4     R/W LOP_PON_PC_VG1_DELAY_STEP           2'b11
    7:6     R/W LOP_PON_PC_VG2_DELAY_STEP           2'b11
    9:8     R/W LOP_PON_ISO_DELAY_STEP              2'b11
    11:10   R/W LOP_PON_CG_DELAY_STEP               2'b11
    31:12   R/W LOP_RG9X_DUMMY                      20'b11
 */
typedef volatile union _AON_LOP_RG9X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LOP_PON_KM4_LDO_BIAS_DELAY_STEP: 2;
        uint32_t LOP_PON_KM4_LDO_DELAY_STEP: 2;
        uint32_t LOP_PON_PC_VG1_DELAY_STEP: 2;
        uint32_t LOP_PON_PC_VG2_DELAY_STEP: 2;
        uint32_t LOP_PON_ISO_DELAY_STEP: 2;
        uint32_t LOP_PON_CG_DELAY_STEP: 2;
        uint32_t LOP_RG9X_DUMMY: 20;
    };
} AON_LOP_RG9X_TYPE;

/* 0xAD8    0x4000_0ad8
    0       R/W WFI_PON_kr0_cpu_clk_en              1'b1
    1       R/W WFI_PON_kr0_bus_clk_en              1'b1
    3:2     R/W WFI_PON_r_SD_kr0_rom                2'b0
    4       R/W WFI_PON_ISO_BT_AON_2                1'b0
    5       R/W WFI_PON_LDOAON_ENLDO_IB20nA         1'b1
    6       R/W WFI_PON_LDOAON_EN_DMYL_70U          1'b1
    7       R/W WFI_PON_LDOAON_EN_DMYL_1M           1'b0
    8       R/W WFI_PON_LDOAON_EN_DMYL_10U          1'b1
    13:9    R/W WFI_PON_LDOAON_VOUT_TUNE            5'b10110
    14      R/W WFI_PON_ENPC_AON_2_VG2              1'b1
    15      R/W WFI_PON_ENPC_AON_2_VG1              1'b1
    17:16   R/W WFI_PON_r_RET2N_kr0_ipc_iso0        2'b11
    18      R/W WFI_PON_r_RET2N_kr0_pmc_iso0        1'b1
    20:19   R/W WFI_PON_r_LS_kr0_rom                2'b0
    21      R/W WFI_PON_POW_40M_OSC_R0              1'b1
    22      R/W WFI_PON_r_RET2N_kr0_log_iso0        1'b1
    23      R/W WFI_PON_r_PGEN_kr0_log_iso0         1'b0
    25:24   R/W WFI_PON_r_PGEN_kr0_ipc_iso0         2'b0
    26      R/W WFI_PON_r_PGEN_kr0_pmc_iso0         1'b0
    27      R/W WFI_PON_r_RET1N_kr0_log_iso0        1'b1
    29:28   R/W WFI_PON_r_RET1N_kr0_ipc_iso0        2'b11
    30      R/W WFI_PON_r_RET1N_kr0_pmc_iso0        1'b1
    31      R/W LOP_RG10X_DUMMY                     1'b0
 */
typedef volatile union _AON_LOP_RG10X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t WFI_PON_kr0_cpu_clk_en: 1;
        uint32_t WFI_PON_kr0_bus_clk_en: 1;
        uint32_t WFI_PON_r_SD_kr0_rom: 2;
        uint32_t WFI_PON_ISO_BT_AON_2: 1;
        uint32_t WFI_PON_LDOAON_ENLDO_IB20nA: 1;
        uint32_t WFI_PON_LDOAON_EN_DMYL_70U: 1;
        uint32_t WFI_PON_LDOAON_EN_DMYL_1M: 1;
        uint32_t WFI_PON_LDOAON_EN_DMYL_10U: 1;
        uint32_t WFI_PON_LDOAON_VOUT_TUNE: 5;
        uint32_t WFI_PON_ENPC_AON_2_VG2: 1;
        uint32_t WFI_PON_ENPC_AON_2_VG1: 1;
        uint32_t WFI_PON_r_RET2N_kr0_ipc_iso0: 2;
        uint32_t WFI_PON_r_RET2N_kr0_pmc_iso0: 1;
        uint32_t WFI_PON_r_LS_kr0_rom: 2;
        uint32_t WFI_PON_POW_40M_OSC_R0: 1;
        uint32_t WFI_PON_r_RET2N_kr0_log_iso0: 1;
        uint32_t WFI_PON_r_PGEN_kr0_log_iso0: 1;
        uint32_t WFI_PON_r_PGEN_kr0_ipc_iso0: 2;
        uint32_t WFI_PON_r_PGEN_kr0_pmc_iso0: 1;
        uint32_t WFI_PON_r_RET1N_kr0_log_iso0: 1;
        uint32_t WFI_PON_r_RET1N_kr0_ipc_iso0: 2;
        uint32_t WFI_PON_r_RET1N_kr0_pmc_iso0: 1;
        uint32_t LOP_RG10X_DUMMY: 1;
    };
} AON_LOP_RG10X_TYPE;

/* 0xADC    0x4000_0adc
    0       R/W WFI_POF_kr0_cpu_clk_en              1'b0
    1       R/W WFI_POF_kr0_bus_clk_en              1'b1
    3:2     R/W WFI_POF_r_SD_kr0_rom                2'b11
    4       R/W WFI_POF_ISO_BT_AON_2                1'b0
    5       R/W WFI_POF_LDOAON_ENLDO_IB20nA         1'b0
    6       R/W WFI_POF_LDOAON_EN_DMYL_70U          1'b0
    7       R/W WFI_POF_LDOAON_EN_DMYL_1M           1'b0
    8       R/W WFI_POF_LDOAON_EN_DMYL_10U          1'b0
    13:9    R/W WFI_POF_LDOAON_VOUT_TUNE            5'b10110
    14      R/W WFI_POF_ENPC_AON_2_VG2              1'b1
    15      R/W WFI_POF_ENPC_AON_2_VG1              1'b1
    17:16   R/W WFI_POF_r_RET2N_kr0_ipc_iso0        2'b11
    18      R/W WFI_POF_r_RET2N_kr0_pmc_iso0        1'b0
    20:19   R/W WFI_POF_r_LS_kr0_rom                2'b11
    21      R/W WFI_POF_POW_40M_OSC_R0              1'b1
    22      R/W WFI_POF_r_RET2N_kr0_log_iso0        1'b1
    23      R/W WFI_POF_r_PGEN_kr0_log_iso0         1'b0
    25:24   R/W WFI_POF_r_PGEN_kr0_ipc_iso0         2'b0
    26      R/W WFI_POF_r_PGEN_kr0_pmc_iso0         1'b1
    27      R/W WFI_POF_r_RET1N_kr0_log_iso0        1'b1
    29:28   R/W WFI_POF_r_RET1N_kr0_ipc_iso0        2'b11
    30      R/W WFI_POF_r_RET1N_kr0_pmc_iso0        1'b1
    31      R/W LOP_RG11X_DUMMY                     1'b0
 */
typedef volatile union _AON_LOP_RG11X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t WFI_POF_kr0_cpu_clk_en: 1;
        uint32_t WFI_POF_kr0_bus_clk_en: 1;
        uint32_t WFI_POF_r_SD_kr0_rom: 2;
        uint32_t WFI_POF_ISO_BT_AON_2: 1;
        uint32_t WFI_POF_LDOAON_ENLDO_IB20nA: 1;
        uint32_t WFI_POF_LDOAON_EN_DMYL_70U: 1;
        uint32_t WFI_POF_LDOAON_EN_DMYL_1M: 1;
        uint32_t WFI_POF_LDOAON_EN_DMYL_10U: 1;
        uint32_t WFI_POF_LDOAON_VOUT_TUNE: 5;
        uint32_t WFI_POF_ENPC_AON_2_VG2: 1;
        uint32_t WFI_POF_ENPC_AON_2_VG1: 1;
        uint32_t WFI_POF_r_RET2N_kr0_ipc_iso0: 2;
        uint32_t WFI_POF_r_RET2N_kr0_pmc_iso0: 1;
        uint32_t WFI_POF_r_LS_kr0_rom: 2;
        uint32_t WFI_POF_POW_40M_OSC_R0: 1;
        uint32_t WFI_POF_r_RET2N_kr0_log_iso0: 1;
        uint32_t WFI_POF_r_PGEN_kr0_log_iso0: 1;
        uint32_t WFI_POF_r_PGEN_kr0_ipc_iso0: 2;
        uint32_t WFI_POF_r_PGEN_kr0_pmc_iso0: 1;
        uint32_t WFI_POF_r_RET1N_kr0_log_iso0: 1;
        uint32_t WFI_POF_r_RET1N_kr0_ipc_iso0: 2;
        uint32_t WFI_POF_r_RET1N_kr0_pmc_iso0: 1;
        uint32_t LOP_RG11X_DUMMY: 1;
    };
} AON_LOP_RG11X_TYPE;

/* 0xAE0    0x4000_0ae0
    7:0     R/W LOP_PON_ST_PON_KM4_LDO_BIAS_DUMMY   8'hf0
    15:8    R/W LOP_PON_ST_PON_OTP_DUMMY            8'hf0
    23:16   R/W LOP_PON_ST_PON_AON_RST_DUMMY        8'hf0
    31:24   R/W LOP_PON_ST_IDLE_DUMMY               8'hf0
 */
typedef volatile union _AON_LOP_RG12X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LOP_PON_ST_PON_KM4_LDO_BIAS_DUMMY: 8;
        uint32_t LOP_PON_ST_PON_OTP_DUMMY: 8;
        uint32_t LOP_PON_ST_PON_AON_RST_DUMMY: 8;
        uint32_t LOP_PON_ST_IDLE_DUMMY: 8;
    };
} AON_LOP_RG12X_TYPE;

/* 0xAE4    0x4000_0ae4
    7:0     R/W LOP_PON_ST_PON_ISO_DUMMY            8'hf0
    15:8    R/W LOP_PON_ST_PON_PC_VG2_DUMMY         8'hf0
    23:16   R/W LOP_PON_ST_PON_PC_VG1_DUMMY         8'hf0
    31:24   R/W LOP_PON_ST_PON_KM4_LDO_DUMMY        8'hf0
 */
typedef volatile union _AON_LOP_RG13X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LOP_PON_ST_PON_ISO_DUMMY: 8;
        uint32_t LOP_PON_ST_PON_PC_VG2_DUMMY: 8;
        uint32_t LOP_PON_ST_PON_PC_VG1_DUMMY: 8;
        uint32_t LOP_PON_ST_PON_KM4_LDO_DUMMY: 8;
    };
} AON_LOP_RG13X_TYPE;

/* 0xAE8    0x4000_0ae8
    7:0     R/W LOP_PON_ST_ACTIVE_DUMMY             8'hf0
    15:8    R/W LOP_PON_ST_PON_CG_DUMMY             8'hf0
    31:16   R/W LOP_RG14X_DUMMY                     16'hf0f0
 */
typedef volatile union _AON_LOP_RG14X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LOP_PON_ST_ACTIVE_DUMMY: 8;
        uint32_t LOP_PON_ST_PON_CG_DUMMY: 8;
        uint32_t LOP_RG14X_DUMMY: 16;
    };
} AON_LOP_RG14X_TYPE;

/* 0xAEC    0x4000_0aec
    7:0     R/W LOP_POF_ST_POF_KR0_CG_DUMMY         8'hf0
    15:8    R/W LOP_POF_ST_POF_KR0_RSTB_DUMMY       8'hf0
    23:16   R/W LOP_POF_ST_POF_KR0_PC_DUMMY         8'hf0
    31:24   R/W LOP_POF_ST_POF_KR0_ISO_DUMMY        8'hf0
 */
typedef volatile union _AON_LOP_RG15X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LOP_POF_ST_POF_KR0_CG_DUMMY: 8;
        uint32_t LOP_POF_ST_POF_KR0_RSTB_DUMMY: 8;
        uint32_t LOP_POF_ST_POF_KR0_PC_DUMMY: 8;
        uint32_t LOP_POF_ST_POF_KR0_ISO_DUMMY: 8;
    };
} AON_LOP_RG15X_TYPE;

/* 0xAF0    0x4000_0af0
    7:0     R/W LOP_POF_ST_PWRDWN_DUMMY             8'hf0
    8       R/W LOP_POF_r_PGEN_kr0_log_iso0         1'b1
    10:9    R/W LOP_POF_r_PGEN_kr0_ipc_iso0         2'b11
    11      R/W LOP_POF_r_PGEN_kr0_pmc_iso0         1'b1
    12      R/W LOP_POF_r_RET2N_kr0_log_iso0        1'b0
    14:13   R/W LOP_POF_r_RET2N_kr0_ipc_iso0        2'b0
    15      R/W LOP_POF_r_RET2N_kr0_pmc_iso0        1'b0
    16      R/W LOP_POF_r_RET1N_kr0_log_iso0        1'b1
    18:17   R/W LOP_POF_r_RET1N_kr0_ipc_iso0        2'b11
    19      R/W LOP_POF_r_RET1N_kr0_pmc_iso0        1'b1
    31:20   R/W LOP_RG16X_DUMMY                     12'h0
 */
typedef volatile union _AON_LOP_RG16X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LOP_POF_ST_PWRDWN_DUMMY: 8;
        uint32_t LOP_POF_r_PGEN_kr0_log_iso0: 1;
        uint32_t LOP_POF_r_PGEN_kr0_ipc_iso0: 2;
        uint32_t LOP_POF_r_PGEN_kr0_pmc_iso0: 1;
        uint32_t LOP_POF_r_RET2N_kr0_log_iso0: 1;
        uint32_t LOP_POF_r_RET2N_kr0_ipc_iso0: 2;
        uint32_t LOP_POF_r_RET2N_kr0_pmc_iso0: 1;
        uint32_t LOP_POF_r_RET1N_kr0_log_iso0: 1;
        uint32_t LOP_POF_r_RET1N_kr0_ipc_iso0: 2;
        uint32_t LOP_POF_r_RET1N_kr0_pmc_iso0: 1;
        uint32_t LOP_RG16X_DUMMY: 12;
    };
} AON_LOP_RG16X_TYPE;

/* 0xAF4    0x4000_0af4
    7:0     R/W WFI_PON_ST_WFI_PON_CG_DUMMY         8'hf0
    15:8    R/W WFI_PON_ST_WFI_PON_40MOSC_DUMMY     8'hf0
    23:16   R/W WFI_PON_ST_WFI_PON_ROM_RAM_DUMMY    8'hf0
    31:24   R/W WFI_PON_ST_WFI_PON_ISO_DUMMY        8'hf0
 */
typedef volatile union _AON_LOP_RG17X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t WFI_PON_ST_WFI_PON_CG_DUMMY: 8;
        uint32_t WFI_PON_ST_WFI_PON_40MOSC_DUMMY: 8;
        uint32_t WFI_PON_ST_WFI_PON_ROM_RAM_DUMMY: 8;
        uint32_t WFI_PON_ST_WFI_PON_ISO_DUMMY: 8;
    };
} AON_LOP_RG17X_TYPE;

/* 0xAF8    0x4000_0af8
    7:0     R/W WFI_POF_ST_WFI_POF_CG_DUMMY         8'hf0
    15:8    R/W WFI_POF_ST_WFI_POF_40MOSC_DUMMY     8'hf0
    23:16   R/W WFI_POF_ST_WFI_POF_ROM_RAM_DUMMY    8'hf0
    31:24   R/W WFI_POF_ST_WFI_POF_ISO_DUMMY        8'hf0
 */
typedef volatile union _AON_LOP_RG18X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t WFI_POF_ST_WFI_POF_CG_DUMMY: 8;
        uint32_t WFI_POF_ST_WFI_POF_40MOSC_DUMMY: 8;
        uint32_t WFI_POF_ST_WFI_POF_ROM_RAM_DUMMY: 8;
        uint32_t WFI_POF_ST_WFI_POF_ISO_DUMMY: 8;
    };
} AON_LOP_RG18X_TYPE;

/* 0xC00    0x4000_0c00
    2:0     R/W MBIAS_POR18_SEL_L                   3'b100
    5:3     R/W MBIAS_POR18_SEL_H                   3'b100
    8:6     R/W MBIAS_BG_TUNE<2:0>                  3'b100
    9       R/W MBIAS_POW_PCUT_EHVT_VAON            1'b1
    10      R/W MBIAS_POW_PCUT_EHVT_VCORE2          1'b0
    11      R/W MBIAS_POW_PCUT_VDD2OTP              1'b1
    12      R/W MBIAS_ENB_BIAS_500NA_IQ_SEL<2>      1'b1
    13      R/W MBIAS_EN_VINRC                      1'b0
    15:14   R/W MBIAS_LDOAON_VREF_SEL<1:0>          2'b01
    18:16   R/W MBIAS_POR33_SEL_H<2:0>              3'b100
    21:19   R/W MBIAS_POR33_SEL_L<2:0>              3'b100
    23:22   R/W MBIAS_LPBG_IQ_SEL<1:0>              2'b00
    26:24   R/W MBIAS_BG_R2_TUNE<2:0>               3'b100
    29:27   R/W MBIAS_BIAS_50NA_TUNE<2:0>           3'b100
    30      R/W MBIAS_POW_BIAS_50NA                 1'b0
    31      R/W MBIAS_POW_EBIAS                     1'b0
 */
typedef volatile union _AON_REG0X_MBIAS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t MBIAS_POR18_SEL_L: 3;
        uint32_t MBIAS_POR18_SEL_H: 3;
        uint32_t MBIAS_BG_TUNE_2_0: 3;
        uint32_t MBIAS_POW_PCUT_EHVT_VAON: 1;
        uint32_t MBIAS_POW_PCUT_EHVT_VCORE2: 1;
        uint32_t MBIAS_POW_PCUT_VDD2OTP: 1;
        uint32_t MBIAS_ENB_BIAS_500NA_IQ_SEL_2: 1;
        uint32_t MBIAS_EN_VINRC: 1;
        uint32_t MBIAS_LDOAON_VREF_SEL_1_0: 2;
        uint32_t MBIAS_POR33_SEL_H_2_0: 3;
        uint32_t MBIAS_POR33_SEL_L_2_0: 3;
        uint32_t MBIAS_LPBG_IQ_SEL_1_0: 2;
        uint32_t MBIAS_BG_R2_TUNE_2_0: 3;
        uint32_t MBIAS_BIAS_50NA_TUNE_2_0: 3;
        uint32_t MBIAS_POW_BIAS_50NA: 1;
        uint32_t MBIAS_POW_EBIAS: 1;
    };
} AON_REG0X_MBIAS_TYPE;

/* 0xC04    0x4000_0c04
    2:0     R/W MBIAS_BIAS_50NA_IQ_SEL<2:0>         3'b000
    3       R/W MBIAS_POW_VANA_DET                  1'b0
    4       R/W MBIAS_POW_VPA_TPM_DET               1'b0
    5       R/W MBIAS_POW_VSRAM_DET                 1'b0
    10:6    R/W MBIAS_SWR_LPPFM2_REF<4:0>           5'b10000
    15:11   R/W MBIAS_SWR_LPPFM3_REF<4:0>           5'b11010
    20:16   R/W MBIAS_VREF_H1_LPC                   5'b10000
    25:21   R/W MBIAS_VREF_L1_LPC                   5'b10000
    30:26   R/W MBIAS_VREF_H2_LPC                   5'b10000
    31      R/W MBIAS_ENB_BIAS_500NA_IQ_SEL<1>      1'b1
 */
typedef volatile union _AON_REG2X_MBIAS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t MBIAS_BIAS_50NA_IQ_SEL_2_0: 3;
        uint32_t MBIAS_POW_VANA_DET: 1;
        uint32_t MBIAS_POW_VPA_TPM_DET: 1;
        uint32_t MBIAS_POW_VSRAM_DET: 1;
        uint32_t MBIAS_SWR_LPPFM2_REF_4_0: 5;
        uint32_t MBIAS_SWR_LPPFM3_REF_4_0: 5;
        uint32_t MBIAS_VREF_H1_LPC: 5;
        uint32_t MBIAS_VREF_L1_LPC: 5;
        uint32_t MBIAS_VREF_H2_LPC: 5;
        uint32_t MBIAS_ENB_BIAS_500NA_IQ_SEL_1: 1;
    };
} AON_REG2X_MBIAS_TYPE;

/* 0xC08    0x4000_0c08
    4:0     R/W MBIAS_VREF_L2_LPC                   5'b10000
    5       R/W MBIAS_ENB_BIAS_500NA_IQ_SEL<0>      1'b1
    10:6    R/W MBIAS_SWR_LPPFM4_REF<4:0>           5'b10000
    14:11   R/W MBIAS_VREFOCP_LPPFM<3:0>            4'b1000
    15      R/W MBIAS_POW_VCOREA_DET                1'b0
    16      R/W MBIAS_ERC_HW_PDB_33V_DVDD_HV33      1'b0
    17      R/W MBIAS_ERC_r33_pdn33_HV33            1'b0
    20:18   R/W MBIAS_VR_VANA_SEL_H                 3'b100
    25:21   R/W MBIAS_SWR_LPPFM1_REF<4:0>           5'b10000
    28:26   R/W MBIAS_VR_VCOREA_SEL_L               3'b100
    31:29   R/W MBIAS_VR_VCOREA_SEL_H               3'b100
 */
typedef volatile union _AON_REG4X_MBIAS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t MBIAS_VREF_L2_LPC: 5;
        uint32_t MBIAS_ENB_BIAS_500NA_IQ_SEL_0: 1;
        uint32_t MBIAS_SWR_LPPFM4_REF_4_0: 5;
        uint32_t MBIAS_VREFOCP_LPPFM_3_0: 4;
        uint32_t MBIAS_POW_VCOREA_DET: 1;
        uint32_t MBIAS_ERC_HW_PDB_33V_DVDD_HV33: 1;
        uint32_t MBIAS_ERC_r33_pdn33_HV33: 1;
        uint32_t MBIAS_VR_VANA_SEL_H: 3;
        uint32_t MBIAS_SWR_LPPFM1_REF_4_0: 5;
        uint32_t MBIAS_VR_VCOREA_SEL_L: 3;
        uint32_t MBIAS_VR_VCOREA_SEL_H: 3;
    };
} AON_REG4X_MBIAS_TYPE;

/* 0xC0C    0x4000_0c0c
    0       R/W MBIAS_REG6X_DUMMY0                  1'b1
    3:1     R/W MBIAS_VR_VSRAM_SEL_L                3'b100
    6:4     R/W MBIAS_VR_VSRAM_SEL_H                3'b100
    9:7     R/W MBIAS_VR_VPA_SEL_L                  3'b100
    12:10   R/W MBIAS_VR_VPA_SEL_H                  3'b100
    15:13   R/W MBIAS_VR_VANA_SEL_L                 3'b100
    31:16   R/W MBIAS_REG6X_DUMMY1                  16'b0101010101010101
 */
typedef volatile union _AON_REG6X_MBIAS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t MBIAS_REG6X_DUMMY0: 1;
        uint32_t MBIAS_VR_VSRAM_SEL_L: 3;
        uint32_t MBIAS_VR_VSRAM_SEL_H: 3;
        uint32_t MBIAS_VR_VPA_SEL_L: 3;
        uint32_t MBIAS_VR_VPA_SEL_H: 3;
        uint32_t MBIAS_VR_VANA_SEL_L: 3;
        uint32_t MBIAS_REG6X_DUMMY1: 16;
    };
} AON_REG6X_MBIAS_TYPE;

/* 0xC10    0x4000_0c10
    0       R/W LDOANA_POWLDO                       1'b0
    1       R/W LDOANA_EN_PC                        1'b0
    2       R/W LDOANA_ENB_FB_LOCAL                 1'b0
    9:3     R/W LDOANA_VOUT_TUNE                    7'b1000110
    10      R/W LDOANA_ENB_DMYL_50U                 1'b0
    11      R/W LDOANA_ENB_DMYL_200U                1'b1
    12      R/W LDOHQ_ENB_DMYL_10U                  1'b0
    13      R/W LDOHQ_ENBPC_CORE2SRAM               1'b1
    14      R/W LDOHQ_POWLDO                        1'b0
    15      R/W LDOHQ_ENLDO_IB20nA                  1'b1
    16      R/W LDOAON_ENLDO_IB20nA                 1'b1
    17      R/W LDOAON_EN_DMYL_70U                  1'b1
    18      R/W LDOAON_EN_DMYL_1M                   1'b0
    19      R/W LDOAON_EN_DMYL_10U                  1'b1
    24:20   R/W LDOAON_VOUT_TUNE                    5'b10110
    29:25   R/W LDOHQ_VOUT_TUNE                     5'b11000
    30      R/W LDOHQ_ENB_DMYL_70U                  1'b0
    31      R/W LDOHQ_ENB_DMYL_1M                   1'b1
 */
typedef volatile union _AON_REG0X_LDO_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LDOANA_POWLDO: 1;
        uint32_t LDOANA_EN_PC: 1;
        uint32_t LDOANA_ENB_FB_LOCAL: 1;
        uint32_t LDOANA_VOUT_TUNE: 7;
        uint32_t LDOANA_ENB_DMYL_50U: 1;
        uint32_t LDOANA_ENB_DMYL_200U: 1;
        uint32_t LDOHQ_ENB_DMYL_10U: 1;
        uint32_t LDOHQ_ENBPC_CORE2SRAM: 1;
        uint32_t LDOHQ_POWLDO: 1;
        uint32_t LDOHQ_ENLDO_IB20nA: 1;
        uint32_t LDOAON_ENLDO_IB20nA: 1;
        uint32_t LDOAON_EN_DMYL_70U: 1;
        uint32_t LDOAON_EN_DMYL_1M: 1;
        uint32_t LDOAON_EN_DMYL_10U: 1;
        uint32_t LDOAON_VOUT_TUNE: 5;
        uint32_t LDOHQ_VOUT_TUNE: 5;
        uint32_t LDOHQ_ENB_DMYL_70U: 1;
        uint32_t LDOHQ_ENB_DMYL_1M: 1;
    };
} AON_REG0X_LDO_TYPE;

/* 0xC14    0x4000_0c14
    1:0     R/W LDOANA_EN_Add_IBIAS                 2'b10
    5:2     R/W LDOANA_EN_DIS_R                     4'b0000
    6       R/W LDOM0_POWLDO                        1'b0
    7       R/W LDOM0_EN_PC                         1'b0
    8       R/W LDOM0_ENB_FB_LOCAL                  1'b0
    15:9    R/W LDOM0_VOUT_TUNE                     7'b1000110
    17:16   R/W LDOM0_EN_Add_IBIAS                  2'b10
    18      R/W LDOM0_ENB_DMYL_200U                 1'b1
    19      R/W LDOM0_ENB_DMYL_50U                  1'b0
    23:20   R/W LDOM0_EN_DIS_R                      4'b0000
    24      R/W LDOM0_SEL_POS_VREFSS1               1'b1
    29:25   R   LDOM0_TUNE_VREFSS                   5'b00000
    30      R/W LDO_REG3X_DUMMY30                   1'b0
    31      R/W LDOHQ_ENBPC_CORE2ANA                1'b1
 */
typedef volatile union _AON_REG2X_LDO_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LDOANA_EN_Add_IBIAS: 2;
        uint32_t LDOANA_EN_DIS_R: 4;
        uint32_t LDOM0_POWLDO: 1;
        uint32_t LDOM0_EN_PC: 1;
        uint32_t LDOM0_ENB_FB_LOCAL: 1;
        uint32_t LDOM0_VOUT_TUNE: 7;
        uint32_t LDOM0_EN_Add_IBIAS: 2;
        uint32_t LDOM0_ENB_DMYL_200U: 1;
        uint32_t LDOM0_ENB_DMYL_50U: 1;
        uint32_t LDOM0_EN_DIS_R: 4;
        uint32_t LDOM0_SEL_POS_VREFSS1: 1;
        uint32_t LDOM0_TUNE_VREFSS: 5;
        uint32_t LDO_REG3X_DUMMY30: 1;
        uint32_t LDOHQ_ENBPC_CORE2ANA: 1;
    };
} AON_REG2X_LDO_TYPE;

/* 0xC18    0x4000_0c18
    2:0     R/W LDOM0_TUNE_POS_VREFSRAM1            3'b011
    3       R/W LDO_REG4X_DUMMY3                    1'b1
    4       R/W LDOAON_EN_COMP_C                    1'b0
    5       R/W LDO_REG4X_DUMMY5                    1'b1
    6       R/W LDOAON_EN_BUFFER<0>                 1'b0
    7       R/W LDO_REG4X_DUMMY7                    1'b1
    8       R/W LDOAON_EN_BUFFER<1>                 1'b0
    9       R/W LDO_REG4X_DUMMY9                    1'b1
    10      R/W LDOAON_EN_BUFFER<2>                 1'b0
    11      R/W LDO_REG4X_DUMMY11                   1'b1
    12      R/W LDOANA_EN_CFF_COMP<0>               1'b0
    13      R/W LDO_REG4X_DUMMY13                   1'b1
    14      R/W LDOANA_EN_CFF_COMP<1>               1'b0
    15      R/W LDO_REG4X_DUMMY15                   1'b1
    16      R/W LDO_REG5X_DUMMY16                   1'b0
    17      R/W LDO_REG5X_DUMMY17                   1'b1
    18      R/W LDO_REG5X_DUMMY18                   1'b0
    19      R/W LDO_REG5X_DUMMY19                   1'b1
    20      R/W LDO_REG5X_DUMMY20                   1'b0
    21      R/W LDO_REG5X_DUMMY21                   1'b1
    22      R/W LDO_REG5X_DUMMY22                   1'b0
    23      R/W LDO_REG5X_DUMMY23                   1'b1
    24      R/W LDO_REG5X_DUMMY24                   1'b0
    25      R/W LDO_REG5X_DUMMY25                   1'b1
    26      R/W LDO_REG5X_DUMMY26                   1'b0
    27      R/W LDO_REG5X_DUMMY27                   1'b1
    28      R/W LDO_REG5X_DUMMY28                   1'b0
    29      R/W LDO_REG5X_DUMMY29                   1'b1
    30      R/W LDO_REG5X_DUMMY30                   1'b0
    31      R/W LDO_REG5X_DUMMY31                   1'b1
 */
typedef volatile union _AON_REG4X_LDO_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LDOM0_TUNE_POS_VREFSRAM1: 3;
        uint32_t LDO_REG4X_DUMMY3: 1;
        uint32_t LDOAON_EN_COMP_C: 1;
        uint32_t LDO_REG4X_DUMMY5: 1;
        uint32_t LDOAON_EN_BUFFER_0: 1;
        uint32_t LDO_REG4X_DUMMY7: 1;
        uint32_t LDOAON_EN_BUFFER_1: 1;
        uint32_t LDO_REG4X_DUMMY9: 1;
        uint32_t LDOAON_EN_BUFFER_2: 1;
        uint32_t LDO_REG4X_DUMMY11: 1;
        uint32_t LDOANA_EN_CFF_COMP_0: 1;
        uint32_t LDO_REG4X_DUMMY13: 1;
        uint32_t LDOANA_EN_CFF_COMP_1: 1;
        uint32_t LDO_REG4X_DUMMY15: 1;
        uint32_t LDO_REG5X_DUMMY16: 1;
        uint32_t LDO_REG5X_DUMMY17: 1;
        uint32_t LDO_REG5X_DUMMY18: 1;
        uint32_t LDO_REG5X_DUMMY19: 1;
        uint32_t LDO_REG5X_DUMMY20: 1;
        uint32_t LDO_REG5X_DUMMY21: 1;
        uint32_t LDO_REG5X_DUMMY22: 1;
        uint32_t LDO_REG5X_DUMMY23: 1;
        uint32_t LDO_REG5X_DUMMY24: 1;
        uint32_t LDO_REG5X_DUMMY25: 1;
        uint32_t LDO_REG5X_DUMMY26: 1;
        uint32_t LDO_REG5X_DUMMY27: 1;
        uint32_t LDO_REG5X_DUMMY28: 1;
        uint32_t LDO_REG5X_DUMMY29: 1;
        uint32_t LDO_REG5X_DUMMY30: 1;
        uint32_t LDO_REG5X_DUMMY31: 1;
    };
} AON_REG4X_LDO_TYPE;

/* 0xC20    0x4000_0c20
    2:0     R/W SWR_CORE_REG0X_DUMMY1               3'b100
    3       R/W SWR_CORE_EN_SAW_RAMP4               1'b1
    4       R/W SWR_CORE_EN_SAW_RAMP3               1'b1
    5       R/W SWR_CORE_EN_SAW_RAMP2               1'b1
    6       R/W SWR_CORE_EN_SAW_RAMP1               1'b1
    12:7    R/W SWR_CORE_TUNE_SAW_ICLK              6'b100110
    14:13   R/W SWR_CORE_TUNE_SAW_CCLK              2'b10
    15      R/W SWR_CORE_BYPASS_SAW_RAMPONDELAY     1'b1
    17:16   R/W SWR_CORE_REG1X_DUMMY1               2'b00
    18      R/W SWR_CORE_EN_FLAG_OUT                1'b1
    19      R   SWR_CORE_POS4_FLAG2                 1'b0
    20      R   SWR_CORE_POS3_FLAG2                 1'b0
    21      R   SWR_CORE_POS2_FLAG2                 1'b0
    22      R   SWR_CORE_POS1_FLAG2                 1'b0
    23      R   SWR_CORE_POS4_FLAG1                 1'b0
    24      R   SWR_CORE_POS3_FLAG1                 1'b0
    25      R   SWR_CORE_POS2_FLAG1                 1'b0
    26      R   SWR_CORE_POS1_FLAG1                 1'b0
    27      R/W SWR_CORE_EN_POS_AUTO_VSEL           1'b0
    31:28   R/W SWR_CORE_TUNE_POS_VREFOCP           4'b1111
 */
typedef volatile union _AON_REG0X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_REG0X_DUMMY1: 3;
        uint32_t SWR_CORE_EN_SAW_RAMP4: 1;
        uint32_t SWR_CORE_EN_SAW_RAMP3: 1;
        uint32_t SWR_CORE_EN_SAW_RAMP2: 1;
        uint32_t SWR_CORE_EN_SAW_RAMP1: 1;
        uint32_t SWR_CORE_TUNE_SAW_ICLK: 6;
        uint32_t SWR_CORE_TUNE_SAW_CCLK: 2;
        uint32_t SWR_CORE_BYPASS_SAW_RAMPONDELAY: 1;
        uint32_t SWR_CORE_REG1X_DUMMY1: 2;
        uint32_t SWR_CORE_EN_FLAG_OUT: 1;
        uint32_t SWR_CORE_POS4_FLAG2: 1;
        uint32_t SWR_CORE_POS3_FLAG2: 1;
        uint32_t SWR_CORE_POS2_FLAG2: 1;
        uint32_t SWR_CORE_POS1_FLAG2: 1;
        uint32_t SWR_CORE_POS4_FLAG1: 1;
        uint32_t SWR_CORE_POS3_FLAG1: 1;
        uint32_t SWR_CORE_POS2_FLAG1: 1;
        uint32_t SWR_CORE_POS1_FLAG1: 1;
        uint32_t SWR_CORE_EN_POS_AUTO_VSEL: 1;
        uint32_t SWR_CORE_TUNE_POS_VREFOCP: 4;
    };
} AON_REG0X_BUCK_TYPE;

/* 0xC24    0x4000_0c24
    4:0     R   SWR_CORE_TUNE_VREFSS1               5'b00000
    5       R/W SWR_CORE_SEL_POS_VREFLPPFM1         1'b0
    6       R/W SWR_CORE_SEL_POS_VREFSS1            1'b1
    9:7     R/W SWR_CORE_TUNE_POS_VREFPWM1          3'b011
    12:10   R/W SWR_CORE_TUNE_POS_VREFOFT1          3'b100
    15:13   R/W SWR_CORE_TUNE_POS_VREFOT1           3'b100
    20:16   R   SWR_CORE_TUNE_VREFSS2               5'b00000
    21      R/W SWR_CORE_SEL_POS_VREFLPPFM2         1'b0
    22      R/W SWR_CORE_SEL_POS_VREFSS2            1'b1
    25:23   R/W SWR_CORE_TUNE_POS_VREFPWM2          3'b011
    28:26   R/W SWR_CORE_TUNE_POS_VREFOFT2          3'b100
    31:29   R/W SWR_CORE_TUNE_POS_VREFOT2           3'b100
 */
typedef volatile union _AON_REG2X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_TUNE_VREFSS1: 5;
        uint32_t SWR_CORE_SEL_POS_VREFLPPFM1: 1;
        uint32_t SWR_CORE_SEL_POS_VREFSS1: 1;
        uint32_t SWR_CORE_TUNE_POS_VREFPWM1: 3;
        uint32_t SWR_CORE_TUNE_POS_VREFOFT1: 3;
        uint32_t SWR_CORE_TUNE_POS_VREFOT1: 3;
        uint32_t SWR_CORE_TUNE_VREFSS2: 5;
        uint32_t SWR_CORE_SEL_POS_VREFLPPFM2: 1;
        uint32_t SWR_CORE_SEL_POS_VREFSS2: 1;
        uint32_t SWR_CORE_TUNE_POS_VREFPWM2: 3;
        uint32_t SWR_CORE_TUNE_POS_VREFOFT2: 3;
        uint32_t SWR_CORE_TUNE_POS_VREFOT2: 3;
    };
} AON_REG2X_BUCK_TYPE;

/* 0xC28    0x4000_0c28
    4:0     R   SWR_CORE_TUNE_VREFSS3               5'b00000
    5       R/W SWR_CORE_SEL_POS_VREFLPPFM3         1'b0
    6       R/W SWR_CORE_SEL_POS_VREFSS3            1'b1
    9:7     R/W SWR_CORE_TUNE_POS_VREFPWM3          3'b011
    12:10   R/W SWR_CORE_TUNE_POS_VREFOFT3          3'b100
    15:13   R/W SWR_CORE_TUNE_POS_VREFOT3           3'b100
    20:16   R   SWR_CORE_TUNE_VREFSS4               5'b00000
    21      R/W SWR_CORE_SEL_POS_VREFLPPFM4         1'b0
    22      R/W SWR_CORE_SEL_POS_VREFSS4            1'b1
    25:23   R/W SWR_CORE_TUNE_POS_VREFPWM4          3'b011
    28:26   R/W SWR_CORE_TUNE_POS_VREFOFT4          3'b100
    31:29   R/W SWR_CORE_TUNE_POS_VREFOT4           3'b100
 */
typedef volatile union _AON_REG4X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_TUNE_VREFSS3: 5;
        uint32_t SWR_CORE_SEL_POS_VREFLPPFM3: 1;
        uint32_t SWR_CORE_SEL_POS_VREFSS3: 1;
        uint32_t SWR_CORE_TUNE_POS_VREFPWM3: 3;
        uint32_t SWR_CORE_TUNE_POS_VREFOFT3: 3;
        uint32_t SWR_CORE_TUNE_POS_VREFOT3: 3;
        uint32_t SWR_CORE_TUNE_VREFSS4: 5;
        uint32_t SWR_CORE_SEL_POS_VREFLPPFM4: 1;
        uint32_t SWR_CORE_SEL_POS_VREFSS4: 1;
        uint32_t SWR_CORE_TUNE_POS_VREFPWM4: 3;
        uint32_t SWR_CORE_TUNE_POS_VREFOFT4: 3;
        uint32_t SWR_CORE_TUNE_POS_VREFOT4: 3;
    };
} AON_REG4X_BUCK_TYPE;

/* 0xC2C    0x4000_0c2c
    0       R/W SWR_CORE_FORCE_TRIG                 1'b0
    1       R/W SWR_CORE_PFM1COMP_PS                1'b0
    2       R/W SWR_CORE_PFM2COMP_PS                1'b0
    3       R/W SWR_CORE_PFM3COMP_PS                1'b0
    4       R/W SWR_CORE_PFM4COMP_PS                1'b0
    9:5     R/W SWR_CORE_REG6X_DUMMY1               5'b11110
    10      R/W SWR_CORE_EN_OFF_OT_PS               1'b0
    11      R/W SWR_CORE_EN_ICOTON                  1'b1
    12      R/W SWR_CORE_EN_SIMO                    1'b0
    13      R/W SWR_CORE_EN_SWR_SHORT               1'b0
    14      R/W SWR_CORE_SEL_FOLLOWCTRL1            1'b1
    15      R/W SWR_CORE_EN_SCP                     1'b0
    16      R/W SWR_CORE_POW_PWM_CLP1               1'b0
    17      R/W SWR_CORE_POW_PWM_CLP2               1'b0
    20:18   R/W SWR_CORE_TUNE_PWM_VCH_OUT1          3'b110
    23:21   R/W SWR_CORE_TUNE_PWM_VCL_OUT1          3'b001
    26:24   R/W SWR_CORE_TUNE_PWM_VCH_OUT2          3'b110
    29:27   R/W SWR_CORE_TUNE_PWM_VCL_OUT2          3'b001
    30      R/W SWR_CORE_SEL_PWM_BP_ROUGH_SS1       1'b0
    31      R/W SWR_CORE_SEL_PWM_BP_ROUGH_SS2       1'b0
 */
typedef volatile union _AON_REG6X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_FORCE_TRIG: 1;
        uint32_t SWR_CORE_PFM1COMP_PS: 1;
        uint32_t SWR_CORE_PFM2COMP_PS: 1;
        uint32_t SWR_CORE_PFM3COMP_PS: 1;
        uint32_t SWR_CORE_PFM4COMP_PS: 1;
        uint32_t SWR_CORE_REG6X_DUMMY1: 5;
        uint32_t SWR_CORE_EN_OFF_OT_PS: 1;
        uint32_t SWR_CORE_EN_ICOTON: 1;
        uint32_t SWR_CORE_EN_SIMO: 1;
        uint32_t SWR_CORE_EN_SWR_SHORT: 1;
        uint32_t SWR_CORE_SEL_FOLLOWCTRL1: 1;
        uint32_t SWR_CORE_EN_SCP: 1;
        uint32_t SWR_CORE_POW_PWM_CLP1: 1;
        uint32_t SWR_CORE_POW_PWM_CLP2: 1;
        uint32_t SWR_CORE_TUNE_PWM_VCH_OUT1: 3;
        uint32_t SWR_CORE_TUNE_PWM_VCL_OUT1: 3;
        uint32_t SWR_CORE_TUNE_PWM_VCH_OUT2: 3;
        uint32_t SWR_CORE_TUNE_PWM_VCL_OUT2: 3;
        uint32_t SWR_CORE_SEL_PWM_BP_ROUGH_SS1: 1;
        uint32_t SWR_CORE_SEL_PWM_BP_ROUGH_SS2: 1;
    };
} AON_REG6X_BUCK_TYPE;

/* 0xC30    0x4000_0c30
    1:0     R/W SWR_CORE_REG8X_DUMMY1               2'b10
    2       R/W SWR_CORE_FPWM1                      1'b0
    3       R/W SWR_CORE_FPWM2                      1'b0
    4       R/W SWR_CORE_POW_PWM1                   1'b0
    5       R/W SWR_CORE_POW_PWM2                   1'b0
    6       R/W SWR_CORE_BYPASS_PWM_SSR1            1'b1
    7       R/W SWR_CORE_BYPASS_PWM_SSR2            1'b1
    8       R/W SWR_CORE_X4_PWM_COMP_IB_OUT1        1'b0
    9       R/W SWR_CORE_X4_PWM_COMP_IB_OUT2        1'b0
    12:10   R/W SWR_CORE_TUNE_PWM_C1_OUT1           3'b101
    15:13   R/W SWR_CORE_TUNE_PWM_C2_OUT1           3'b000
    19:16   R/W SWR_CORE_REG9X_DUMMY1               4'b1100
    22:20   R/W SWR_CORE_TUNE_PWM_C3_OUT1           3'b000
    25:23   R/W SWR_CORE_TUNE_PWM_R1_OUT1           3'b000
    28:26   R/W SWR_CORE_TUNE_PWM_R2_OUT1           3'b111
    31:29   R/W SWR_CORE_TUNE_PWM_R3_OUT1           3'b000
 */
typedef volatile union _AON_REG8X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_REG8X_DUMMY1: 2;
        uint32_t SWR_CORE_FPWM1: 1;
        uint32_t SWR_CORE_FPWM2: 1;
        uint32_t SWR_CORE_POW_PWM1: 1;
        uint32_t SWR_CORE_POW_PWM2: 1;
        uint32_t SWR_CORE_BYPASS_PWM_SSR1: 1;
        uint32_t SWR_CORE_BYPASS_PWM_SSR2: 1;
        uint32_t SWR_CORE_X4_PWM_COMP_IB_OUT1: 1;
        uint32_t SWR_CORE_X4_PWM_COMP_IB_OUT2: 1;
        uint32_t SWR_CORE_TUNE_PWM_C1_OUT1: 3;
        uint32_t SWR_CORE_TUNE_PWM_C2_OUT1: 3;
        uint32_t SWR_CORE_REG9X_DUMMY1: 4;
        uint32_t SWR_CORE_TUNE_PWM_C3_OUT1: 3;
        uint32_t SWR_CORE_TUNE_PWM_R1_OUT1: 3;
        uint32_t SWR_CORE_TUNE_PWM_R2_OUT1: 3;
        uint32_t SWR_CORE_TUNE_PWM_R3_OUT1: 3;
    };
} AON_REG8X_BUCK_TYPE;

/* 0xC34    0x4000_0c34
    1:0     R/W SWR_CORE_TUNE_PWM_ROUGH_SS1         2'b11
    3:2     R/W SWR_CORE_TUNE_PWM_ROUGH_SS2         2'b11
    4       R/W SWR_CORE_POW_PWM_MINON1             1'b1
    5       R/W SWR_CORE_POW_PWM_MINON2             1'b1
    7:6     R/W SWR_CORE_TUNE_PWM_IMINON1           2'b10
    9:8     R/W SWR_CORE_TUNE_PWM_IMINON2           2'b10
    12:10   R/W SWR_CORE_TUNE_PWM_C_OUT2            3'b100
    15:13   R/W SWR_CORE_TUNE_PWM_R_OUT2            3'b011
    16      R/W SWR_CORE_REG11X_DUMMY1              1'b0
    17      R/W SWR_CORE_EN_AfterTOFF4              1'b1
    18      R/W SWR_CORE_EN_AfterTOFF3              1'b1
    19      R/W SWR_CORE_EN_AfterTOFF2              1'b1
    20      R/W SWR_CORE_EN_AfterTOFF1              1'b1
    21      R/W SWR_CORE_EN_AfterTOFF_ALL           1'b0
    22      R/W SWR_CORE_EN_OTEXT4                  1'b1
    23      R/W SWR_CORE_EN_OTEXT3                  1'b1
    24      R/W SWR_CORE_EN_OTEXT2                  1'b1
    25      R/W SWR_CORE_EN_OTEXT1                  1'b1
    26      R/W SWR_CORE_EN_OTEXT_ALL               1'b0
    27      R/W SWR_CORE_POW_PFM4                   1'b0
    28      R/W SWR_CORE_POW_PFM3                   1'b0
    29      R/W SWR_CORE_POW_PFM2                   1'b0
    30      R/W SWR_CORE_POW_PFM1                   1'b0
    31      R/W SWR_CORE_WaitSampleOver             1'b1
 */
typedef volatile union _AON_REG10X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_TUNE_PWM_ROUGH_SS1: 2;
        uint32_t SWR_CORE_TUNE_PWM_ROUGH_SS2: 2;
        uint32_t SWR_CORE_POW_PWM_MINON1: 1;
        uint32_t SWR_CORE_POW_PWM_MINON2: 1;
        uint32_t SWR_CORE_TUNE_PWM_IMINON1: 2;
        uint32_t SWR_CORE_TUNE_PWM_IMINON2: 2;
        uint32_t SWR_CORE_TUNE_PWM_C_OUT2: 3;
        uint32_t SWR_CORE_TUNE_PWM_R_OUT2: 3;
        uint32_t SWR_CORE_REG11X_DUMMY1: 1;
        uint32_t SWR_CORE_EN_AfterTOFF4: 1;
        uint32_t SWR_CORE_EN_AfterTOFF3: 1;
        uint32_t SWR_CORE_EN_AfterTOFF2: 1;
        uint32_t SWR_CORE_EN_AfterTOFF1: 1;
        uint32_t SWR_CORE_EN_AfterTOFF_ALL: 1;
        uint32_t SWR_CORE_EN_OTEXT4: 1;
        uint32_t SWR_CORE_EN_OTEXT3: 1;
        uint32_t SWR_CORE_EN_OTEXT2: 1;
        uint32_t SWR_CORE_EN_OTEXT1: 1;
        uint32_t SWR_CORE_EN_OTEXT_ALL: 1;
        uint32_t SWR_CORE_POW_PFM4: 1;
        uint32_t SWR_CORE_POW_PFM3: 1;
        uint32_t SWR_CORE_POW_PFM2: 1;
        uint32_t SWR_CORE_POW_PFM1: 1;
        uint32_t SWR_CORE_WaitSampleOver: 1;
    };
} AON_REG10X_BUCK_TYPE;

/* 0xC38    0x4000_0c38
    1:0     R/W SWR_CORE_SEL_SIMO_LOGICS            2'b00
    2       R/W SWR_CORE_SEL_COMP_DEG               1'b0
    3       R/W SWR_CORE_REG12X_DUMMY1              1'b1
    4       R/W SWR_CORE_EN_PMOS_TIMEOFF            1'b1
    5       R/W SWR_CORE_EN_NMOS_TIMEOFF            1'b1
    6       R/W SWR_CORE_SEL_CK_CTRL_PFM            1'b1
    7       R/W SWR_CORE_X4_PFM_COMP_IB_OUT4        1'b0
    8       R/W SWR_CORE_X4_PFM_COMP_IB_OUT3        1'b0
    9       R/W SWR_CORE_X4_PFM_COMP_IB_OUT2        1'b0
    10      R/W SWR_CORE_X4_PFM_COMP_IB_OUT1        1'b0
    11      R/W SWR_CORE_EN_PFM_FORCE_OFF_TO_ZCD4   1'b1
    12      R/W SWR_CORE_EN_PFM_FORCE_OFF_TO_ZCD3   1'b1
    13      R/W SWR_CORE_EN_PFM_FORCE_OFF_TO_ZCD2   1'b1
    14      R/W SWR_CORE_EN_PFM_FORCE_OFF_TO_ZCD1   1'b1
    15      R/W SWR_CORE_EN_PFM_TDM                 1'b0
    18:16   R/W SWR_CORE_REG13X_DUMMY1              3'b100
    19      R/W SWR_CORE_SEL_PFM_COT1               1'b0
    24:20   R/W SWR_CORE_TUNE_PFM_CCOFT1            5'b10000
    29:25   R/W SWR_CORE_TUNE_PFM_CCOT1             5'b10000
    31:30   R/W SWR_CORE_TUNE_PFM_ICOT1             2'b10
 */
typedef volatile union _AON_REG12X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_SEL_SIMO_LOGICS: 2;
        uint32_t SWR_CORE_SEL_COMP_DEG: 1;
        uint32_t SWR_CORE_REG12X_DUMMY1: 1;
        uint32_t SWR_CORE_EN_PMOS_TIMEOFF: 1;
        uint32_t SWR_CORE_EN_NMOS_TIMEOFF: 1;
        uint32_t SWR_CORE_SEL_CK_CTRL_PFM: 1;
        uint32_t SWR_CORE_X4_PFM_COMP_IB_OUT4: 1;
        uint32_t SWR_CORE_X4_PFM_COMP_IB_OUT3: 1;
        uint32_t SWR_CORE_X4_PFM_COMP_IB_OUT2: 1;
        uint32_t SWR_CORE_X4_PFM_COMP_IB_OUT1: 1;
        uint32_t SWR_CORE_EN_PFM_FORCE_OFF_TO_ZCD4: 1;
        uint32_t SWR_CORE_EN_PFM_FORCE_OFF_TO_ZCD3: 1;
        uint32_t SWR_CORE_EN_PFM_FORCE_OFF_TO_ZCD2: 1;
        uint32_t SWR_CORE_EN_PFM_FORCE_OFF_TO_ZCD1: 1;
        uint32_t SWR_CORE_EN_PFM_TDM: 1;
        uint32_t SWR_CORE_REG13X_DUMMY1: 3;
        uint32_t SWR_CORE_SEL_PFM_COT1: 1;
        uint32_t SWR_CORE_TUNE_PFM_CCOFT1: 5;
        uint32_t SWR_CORE_TUNE_PFM_CCOT1: 5;
        uint32_t SWR_CORE_TUNE_PFM_ICOT1: 2;
    };
} AON_REG12X_BUCK_TYPE;

/* 0xC3C    0x4000_0c3c
    2:0     R/W SWR_CORE_REG14X_DUMMY1              3'b100
    3       R/W SWR_CORE_SEL_PFM_COT2               1'b0
    8:4     R/W SWR_CORE_TUNE_PFM_CCOFT2            5'b10000
    13:9    R/W SWR_CORE_TUNE_PFM_CCOT2             5'b10000
    15:14   R/W SWR_CORE_TUNE_PFM_ICOT2             2'b10
    18:16   R/W SWR_CORE_REG15X_DUMMY1              3'b100
    19      R/W SWR_CORE_SEL_PFM_COT3               1'b0
    24:20   R/W SWR_CORE_TUNE_PFM_CCOFT3            5'b10000
    29:25   R/W SWR_CORE_TUNE_PFM_CCOT3             5'b10000
    31:30   R/W SWR_CORE_TUNE_PFM_ICOT3             2'b10
 */
typedef volatile union _AON_REG14X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_REG14X_DUMMY1: 3;
        uint32_t SWR_CORE_SEL_PFM_COT2: 1;
        uint32_t SWR_CORE_TUNE_PFM_CCOFT2: 5;
        uint32_t SWR_CORE_TUNE_PFM_CCOT2: 5;
        uint32_t SWR_CORE_TUNE_PFM_ICOT2: 2;
        uint32_t SWR_CORE_REG15X_DUMMY1: 3;
        uint32_t SWR_CORE_SEL_PFM_COT3: 1;
        uint32_t SWR_CORE_TUNE_PFM_CCOFT3: 5;
        uint32_t SWR_CORE_TUNE_PFM_CCOT3: 5;
        uint32_t SWR_CORE_TUNE_PFM_ICOT3: 2;
    };
} AON_REG14X_BUCK_TYPE;

/* 0xC40    0x4000_0c40
    2:0     R/W SWR_CORE_REG16X_DUMMY1              3'b100
    3       R/W SWR_CORE_SEL_PFM_COT4               1'b0
    8:4     R/W SWR_CORE_TUNE_PFM_CCOFT4            5'b10000
    13:9    R/W SWR_CORE_TUNE_PFM_CCOT4             5'b10000
    15:14   R/W SWR_CORE_TUNE_PFM_ICOT4             2'b10
    16      R/W SWR_CORE_EN_NONOVERLAP_SR           1'b0
    17      R/W SWR_CORE_ENB_NONOVERLAP_OCPMUX      1'b1
    18      R/W SWR_CORE_EN_NONOVERLAP_DLY_PFB      1'b0
    19      R/W SWR_CORE_EN_NONOVERLAP_DLY_NFB      1'b0
    22:20   R/W SWR_CORE_TUNE_NONOVERLAP_SDZP       3'b000
    25:23   R/W SWR_CORE_TUNE_NONOVERLAP_SDZN       3'b000
    28:26   R/W SWR_CORE_SEL_PREDRV_P               3'b111
    31:29   R/W SWR_CORE_SEL_PREDRV_N               3'b111
 */
typedef volatile union _AON_REG16X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_REG16X_DUMMY1: 3;
        uint32_t SWR_CORE_SEL_PFM_COT4: 1;
        uint32_t SWR_CORE_TUNE_PFM_CCOFT4: 5;
        uint32_t SWR_CORE_TUNE_PFM_CCOT4: 5;
        uint32_t SWR_CORE_TUNE_PFM_ICOT4: 2;
        uint32_t SWR_CORE_EN_NONOVERLAP_SR: 1;
        uint32_t SWR_CORE_ENB_NONOVERLAP_OCPMUX: 1;
        uint32_t SWR_CORE_EN_NONOVERLAP_DLY_PFB: 1;
        uint32_t SWR_CORE_EN_NONOVERLAP_DLY_NFB: 1;
        uint32_t SWR_CORE_TUNE_NONOVERLAP_SDZP: 3;
        uint32_t SWR_CORE_TUNE_NONOVERLAP_SDZN: 3;
        uint32_t SWR_CORE_SEL_PREDRV_P: 3;
        uint32_t SWR_CORE_SEL_PREDRV_N: 3;
    };
} AON_REG16X_BUCK_TYPE;

/* 0xC44    0x4000_0c44
    3:0     R/W SWR_CORE_TUNE_PREDRV_P_SP           4'b1111
    7:4     R/W SWR_CORE_TUNE_PREDRV_P_SN           4'b1111
    11:8    R/W SWR_CORE_TUNE_PREDRV_N_SP           4'b1111
    15:12   R/W SWR_CORE_TUNE_PREDRV_N_SN           4'b1111
    19:16   R/W SWR_CORE_TUNE_PREDRV_N_SN_OUT4      4'b1111
    23:20   R/W SWR_CORE_TUNE_PREDRV_N_SN_OUT3      4'b1111
    27:24   R/W SWR_CORE_TUNE_PREDRV_N_SN_OUT2      4'b1111
    31:28   R/W SWR_CORE_TUNE_PREDRV_N_SN_OUT1      4'b1111
 */
typedef volatile union _AON_REG18X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_TUNE_PREDRV_P_SP: 4;
        uint32_t SWR_CORE_TUNE_PREDRV_P_SN: 4;
        uint32_t SWR_CORE_TUNE_PREDRV_N_SP: 4;
        uint32_t SWR_CORE_TUNE_PREDRV_N_SN: 4;
        uint32_t SWR_CORE_TUNE_PREDRV_N_SN_OUT4: 4;
        uint32_t SWR_CORE_TUNE_PREDRV_N_SN_OUT3: 4;
        uint32_t SWR_CORE_TUNE_PREDRV_N_SN_OUT2: 4;
        uint32_t SWR_CORE_TUNE_PREDRV_N_SN_OUT1: 4;
    };
} AON_REG18X_BUCK_TYPE;

/* 0xC48    0x4000_0c48
    3:0     R/W SWR_CORE_TUNE_PREDRV_N_SP_OUT4      4'b1111
    7:4     R/W SWR_CORE_TUNE_PREDRV_N_SP_OUT3      4'b1111
    11:8    R/W SWR_CORE_TUNE_PREDRV_N_SP_OUT2      4'b1111
    15:12   R/W SWR_CORE_TUNE_PREDRV_N_SP_OUT1      4'b1111
    16      R/W SWR_CORE_EN_NONOVERLAP_DLY_N4FB     1'b0
    17      R/W SWR_CORE_EN_NONOVERLAP_DLY_N3FB     1'b0
    18      R/W SWR_CORE_EN_NONOVERLAP_DLY_N2FB     1'b0
    19      R/W SWR_CORE_EN_NONOVERLAP_DLY_N1FB     1'b0
    22:20   R/W SWR_CORE_TUNE_NONOVERLAP_SDZN4      3'b000
    25:23   R/W SWR_CORE_TUNE_NONOVERLAP_SDZN3      3'b000
    28:26   R/W SWR_CORE_TUNE_NONOVERLAP_SDZN2      3'b000
    31:29   R/W SWR_CORE_TUNE_NONOVERLAP_SDZN1      3'b000
 */
typedef volatile union _AON_REG20X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_TUNE_PREDRV_N_SP_OUT4: 4;
        uint32_t SWR_CORE_TUNE_PREDRV_N_SP_OUT3: 4;
        uint32_t SWR_CORE_TUNE_PREDRV_N_SP_OUT2: 4;
        uint32_t SWR_CORE_TUNE_PREDRV_N_SP_OUT1: 4;
        uint32_t SWR_CORE_EN_NONOVERLAP_DLY_N4FB: 1;
        uint32_t SWR_CORE_EN_NONOVERLAP_DLY_N3FB: 1;
        uint32_t SWR_CORE_EN_NONOVERLAP_DLY_N2FB: 1;
        uint32_t SWR_CORE_EN_NONOVERLAP_DLY_N1FB: 1;
        uint32_t SWR_CORE_TUNE_NONOVERLAP_SDZN4: 3;
        uint32_t SWR_CORE_TUNE_NONOVERLAP_SDZN3: 3;
        uint32_t SWR_CORE_TUNE_NONOVERLAP_SDZN2: 3;
        uint32_t SWR_CORE_TUNE_NONOVERLAP_SDZN1: 3;
    };
} AON_REG20X_BUCK_TYPE;

/* 0xC4C    0x4000_0c4c
    0       R   SWR_CORE_POS4_FLAG4                 1'b0
    1       R   SWR_CORE_POS3_FLAG4                 1'b0
    2       R   SWR_CORE_POS2_FLAG4                 1'b0
    3       R   SWR_CORE_POS1_FLAG4                 1'b0
    4       R   SWR_CORE_POS4_FLAG3                 1'b0
    5       R   SWR_CORE_POS3_FLAG3                 1'b0
    6       R   SWR_CORE_POS2_FLAG3                 1'b0
    7       R   SWR_CORE_POS1_FLAG3                 1'b0
    8       R/W SWR_CORE_POW_VDIV4                  1'b1
    9       R/W SWR_CORE_POW_VDIV3                  1'b1
    10      R/W SWR_CORE_POW_VDIV2                  1'b1
    11      R/W SWR_CORE_POW_VDIV1                  1'b1
    12      R/W SWR_CORE_EN_DMYLOAD4                1'b0
    13      R/W SWR_CORE_EN_DMYLOAD3                1'b0
    14      R/W SWR_CORE_EN_DMYLOAD2                1'b0
    15      R/W SWR_CORE_EN_DMYLOAD1                1'b0
    23:16   R/W SWR_CORE_TUNE_VDIV2                 8'b00111010
    31:24   R/W SWR_CORE_TUNE_VDIV1                 8'b00111010
 */
typedef volatile union _AON_REG22X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_POS4_FLAG4: 1;
        uint32_t SWR_CORE_POS3_FLAG4: 1;
        uint32_t SWR_CORE_POS2_FLAG4: 1;
        uint32_t SWR_CORE_POS1_FLAG4: 1;
        uint32_t SWR_CORE_POS4_FLAG3: 1;
        uint32_t SWR_CORE_POS3_FLAG3: 1;
        uint32_t SWR_CORE_POS2_FLAG3: 1;
        uint32_t SWR_CORE_POS1_FLAG3: 1;
        uint32_t SWR_CORE_POW_VDIV4: 1;
        uint32_t SWR_CORE_POW_VDIV3: 1;
        uint32_t SWR_CORE_POW_VDIV2: 1;
        uint32_t SWR_CORE_POW_VDIV1: 1;
        uint32_t SWR_CORE_EN_DMYLOAD4: 1;
        uint32_t SWR_CORE_EN_DMYLOAD3: 1;
        uint32_t SWR_CORE_EN_DMYLOAD2: 1;
        uint32_t SWR_CORE_EN_DMYLOAD1: 1;
        uint32_t SWR_CORE_TUNE_VDIV2: 8;
        uint32_t SWR_CORE_TUNE_VDIV1: 8;
    };
} AON_REG22X_BUCK_TYPE;

/* 0xC50    0x4000_0c50
    7:0     R/W SWR_CORE_TUNE_VDIV4                 8'b01110110
    15:8    R/W SWR_CORE_TUNE_VDIV3                 8'b01110110
    23:16   R/W SWR_CORE_TUNE_ZCD_FORCECODE2        8'b01100000
    31:24   R/W SWR_CORE_TUNE_ZCD_FORCECODE1        8'b01100000
 */
typedef volatile union _AON_REG24X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_TUNE_VDIV4: 8;
        uint32_t SWR_CORE_TUNE_VDIV3: 8;
        uint32_t SWR_CORE_TUNE_ZCD_FORCECODE2: 8;
        uint32_t SWR_CORE_TUNE_ZCD_FORCECODE1: 8;
    };
} AON_REG24X_BUCK_TYPE;

/* 0xC54    0x4000_0c54
    7:0     R/W SWR_CORE_TUNE_ZCD_FORCECODE4        8'b01100000
    15:8    R/W SWR_CORE_TUNE_ZCD_FORCECODE3        8'b01100000
    16      R/W SWR_CORE_SEL_FB4_EXT                1'b0
    17      R/W SWR_CORE_SEL_FB3_EXT                1'b0
    18      R/W SWR_CORE_SEL_FB2_EXT                1'b0
    19      R/W SWR_CORE_SEL_FB1_EXT                1'b0
    22:20   R/W SWR_CORE_REG27X_DUMMY1              3'b111
    23      R/W SWR_CORE_SEL_ZCD_RST                1'b1
    24      R/W SWR_CORE_STICKY_ZCD_CODE4           1'b0
    25      R/W SWR_CORE_STICKY_ZCD_CODE3           1'b0
    26      R/W SWR_CORE_STICKY_ZCD_CODE2           1'b0
    27      R/W SWR_CORE_STICKY_ZCD_CODE1           1'b0
    28      R/W SWR_CORE_FORCE_ZCD_CODE4            1'b0
    29      R/W SWR_CORE_FORCE_ZCD_CODE3            1'b0
    30      R/W SWR_CORE_FORCE_ZCD_CODE2            1'b0
    31      R/W SWR_CORE_FORCE_ZCD_CODE1            1'b0
 */
typedef volatile union _AON_REG26X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_TUNE_ZCD_FORCECODE4: 8;
        uint32_t SWR_CORE_TUNE_ZCD_FORCECODE3: 8;
        uint32_t SWR_CORE_SEL_FB4_EXT: 1;
        uint32_t SWR_CORE_SEL_FB3_EXT: 1;
        uint32_t SWR_CORE_SEL_FB2_EXT: 1;
        uint32_t SWR_CORE_SEL_FB1_EXT: 1;
        uint32_t SWR_CORE_REG27X_DUMMY1: 3;
        uint32_t SWR_CORE_SEL_ZCD_RST: 1;
        uint32_t SWR_CORE_STICKY_ZCD_CODE4: 1;
        uint32_t SWR_CORE_STICKY_ZCD_CODE3: 1;
        uint32_t SWR_CORE_STICKY_ZCD_CODE2: 1;
        uint32_t SWR_CORE_STICKY_ZCD_CODE1: 1;
        uint32_t SWR_CORE_FORCE_ZCD_CODE4: 1;
        uint32_t SWR_CORE_FORCE_ZCD_CODE3: 1;
        uint32_t SWR_CORE_FORCE_ZCD_CODE2: 1;
        uint32_t SWR_CORE_FORCE_ZCD_CODE1: 1;
    };
} AON_REG26X_BUCK_TYPE;

/* 0xC58    0x4000_0c58
    6:0     R/W SWR_CORE_REG28X_DUMMY1              7'b1110000
    8:7     R/W SWR_CORE_TUNE_ZCD_SDZ2D             2'b00
    11:9    R/W SWR_CORE_TUNE_ZCD_SDZ2              3'b001
    13:12   R/W SWR_CORE_TUNE_ZCD_SDZ1              2'b00
    14      R/W SWR_CORE_SEL_ZCD_ZCDQ               1'b0
    15      R/W SWR_CORE_POW_ZCD_COMP_CLAMPLX       1'b1
    17:16   R/W SWR_CORE_TUNE_CCMPFM_C_LXLPF        2'b01
    19:18   R/W SWR_CORE_TUNE_CCMPFM_R_LXLPF        2'b01
    21:20   R/W SWR_CORE_TUNE_CCMPFM_C_CCMCOT       2'b10
    23:22   R/W SWR_CORE_TUNE_CCMPFM_R_CCMCOT       2'b10
    25:24   R/W SWR_CORE_TUNE_CCMPFM_RoughSS        2'b00
    26      R/W SWR_CORE_CCMPFM_BPRoughSS           1'b0
    27      R/W SWR_CORE_CCMPFM_EN_IQX4             1'b0
    28      R/W SWR_CORE_CCMPFM_FollowSTOP          1'b1
    30:29   R/W SWR_CORE_SEL_CCMPFM_VCL             2'b10
    31      R/W SWR_CORE_POW_CCMCOT                 1'b0
 */
typedef volatile union _AON_REG28X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_REG28X_DUMMY1: 7;
        uint32_t SWR_CORE_TUNE_ZCD_SDZ2D: 2;
        uint32_t SWR_CORE_TUNE_ZCD_SDZ2: 3;
        uint32_t SWR_CORE_TUNE_ZCD_SDZ1: 2;
        uint32_t SWR_CORE_SEL_ZCD_ZCDQ: 1;
        uint32_t SWR_CORE_POW_ZCD_COMP_CLAMPLX: 1;
        uint32_t SWR_CORE_TUNE_CCMPFM_C_LXLPF: 2;
        uint32_t SWR_CORE_TUNE_CCMPFM_R_LXLPF: 2;
        uint32_t SWR_CORE_TUNE_CCMPFM_C_CCMCOT: 2;
        uint32_t SWR_CORE_TUNE_CCMPFM_R_CCMCOT: 2;
        uint32_t SWR_CORE_TUNE_CCMPFM_RoughSS: 2;
        uint32_t SWR_CORE_CCMPFM_BPRoughSS: 1;
        uint32_t SWR_CORE_CCMPFM_EN_IQX4: 1;
        uint32_t SWR_CORE_CCMPFM_FollowSTOP: 1;
        uint32_t SWR_CORE_SEL_CCMPFM_VCL: 2;
        uint32_t SWR_CORE_POW_CCMCOT: 1;
    };
} AON_REG28X_BUCK_TYPE;

/* 0xC5C    0x4000_0c5c
    0       R/W SWR_CORE_POW_OCP_OT                 1'b0
    1       R/W SWR_CORE_OCPCOMP_PS                 1'b0
    6:2     R/W SWR_CORE_REG30X_DUMMY1              5'b11100
    7       R/W SWR_CORE_EN_OCP                     1'b0
    9:8     R/W SWR_CORE_TUNE_OCP_RES               2'b10
    10      R/W SWR_CORE_SEL_OCP_RST2               1'b1
    11      R/W SWR_CORE_SEL_OCP_RST                1'b0
    12      R/W SWR_CORE_SEL_OCP_SET                1'b1
    13      R/W SWR_CORE_SEL_OCP_TABLE              1'b0
    15:14   R/W SWR_CORE_TUNE_OCP_ICOTOCP           2'b00
    20:16   R/W SWR_CORE_REG31X_DUMMY1              5'b11100
    21      R/W SWR_CORE_POW_ZCD                    1'b0
    22      R/W SWR_CORE_POW_SAW                    1'b0
    23      R/W SWR_CORE_POW_SAW_IB                 1'b0
    24      R/W SWR_CORE_POW_REF                    1'b0
    25      R/W SWR_CORE_POW_IMIR                   1'b0
    26      R/W SWR_CORE_POW_ZCD_COMP_LOWIQ         1'b0
    27      R/W SWR_CORE_EN_SWR_OUT4                1'b0
    28      R/W SWR_CORE_EN_SWR_OUT3                1'b0
    29      R/W SWR_CORE_EN_SWR_OUT2                1'b0
    30      R/W SWR_CORE_EN_SWR_OUT1                1'b0
    31      R/W SWR_CORE_POW_SWR                    1'b0
 */
typedef volatile union _AON_REG30X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_POW_OCP_OT: 1;
        uint32_t SWR_CORE_OCPCOMP_PS: 1;
        uint32_t SWR_CORE_REG30X_DUMMY1: 5;
        uint32_t SWR_CORE_EN_OCP: 1;
        uint32_t SWR_CORE_TUNE_OCP_RES: 2;
        uint32_t SWR_CORE_SEL_OCP_RST2: 1;
        uint32_t SWR_CORE_SEL_OCP_RST: 1;
        uint32_t SWR_CORE_SEL_OCP_SET: 1;
        uint32_t SWR_CORE_SEL_OCP_TABLE: 1;
        uint32_t SWR_CORE_TUNE_OCP_ICOTOCP: 2;
        uint32_t SWR_CORE_REG31X_DUMMY1: 5;
        uint32_t SWR_CORE_POW_ZCD: 1;
        uint32_t SWR_CORE_POW_SAW: 1;
        uint32_t SWR_CORE_POW_SAW_IB: 1;
        uint32_t SWR_CORE_POW_REF: 1;
        uint32_t SWR_CORE_POW_IMIR: 1;
        uint32_t SWR_CORE_POW_ZCD_COMP_LOWIQ: 1;
        uint32_t SWR_CORE_EN_SWR_OUT4: 1;
        uint32_t SWR_CORE_EN_SWR_OUT3: 1;
        uint32_t SWR_CORE_EN_SWR_OUT2: 1;
        uint32_t SWR_CORE_EN_SWR_OUT1: 1;
        uint32_t SWR_CORE_POW_SWR: 1;
    };
} AON_REG30X_BUCK_TYPE;

/* 0xC60    0x4000_0c60
    15:0    R/W REG32X_BUCK_DUMMY0                  16'b0
    31:16   R/W REG33X_BUCK_DUMMY0                  16'hffff
 */
typedef volatile union _AON_REG32X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t REG32X_BUCK_DUMMY0: 16;
        uint32_t REG33X_BUCK_DUMMY0: 16;
    };
} AON_REG32X_BUCK_TYPE;

/* 0xC64    0x4000_0c64
    15:0    R/W REG34X_BUCK_DUMMY0                  16'b0
    31:16   R   RSVD                                16'b0
 */
typedef volatile union _AON_REG34X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t REG34X_BUCK_DUMMY0: 16;
        uint32_t RSVD: 16;
    };
} AON_REG34X_BUCK_TYPE;

/* 0xC68    0x4000_0c68
    0       R   SWR_CORE_SOFTSTART_OVER             1'b0
    1       R   SWR_CORE_VREFSS_OVER                1'b0
    2       R   SWR_CORE_NGATE_HV                   1'b0
    3       R   SWR_CORE_PGATE_HV                   1'b0
    4       R   SWR_CORE_PFM_CTRL4                  1'b0
    5       R   SWR_CORE_PFM_CTRL3                  1'b0
    6       R   SWR_CORE_PFM_CTRL2                  1'b0
    7       R   SWR_CORE_PFM_CTRL1                  1'b0
    8       R   SWR_CORE_STOPg                      1'b0
    9       R   SWR_CORE_VREFSS4_OVER               1'b0
    10      R   SWR_CORE_VREFSS3_OVER               1'b0
    11      R   SWR_CORE_VREFSS2_OVER               1'b0
    12      R   SWR_CORE_VREFSS1_OVER               1'b0
    13      R   SWR_CORE_VREFSS4_START              1'b0
    14      R   SWR_CORE_VREFSS3_START              1'b0
    15      R   SWR_CORE_VREFSS2_START              1'b0
    16      R   SWR_CORE_VREFSS1_START              1'b0
    17      R   SWR_CORE_VREFSS_START               1'b0
    18      R   SWR_CORE_CK                         1'b0
    19      R   SWR_CORE_CK_CTRL                    1'b0
    21:20   R   SWR_CORE_S<1:0>                     2'b00
    22      R   SWR_CORE_NI_OUT4                    1'b0
    23      R   SWR_CORE_NI_OUT3                    1'b0
    24      R   SWR_CORE_NI_OUT2                    1'b0
    25      R   SWR_CORE_NI_OUT1                    1'b0
    26      R   SWR_CORE_NI                         1'b0
    27      R   SWR_CORE_PI                         1'b0
    28      R   SWR_CORE_OUT4GATE_HV                1'b0
    29      R   SWR_CORE_OUT3GATE_HV                1'b0
    30      R   SWR_CORE_OUT2GATE_HV                1'b0
    31      R   SWR_CORE_OUT1GATE_HV                1'b0
 */
typedef volatile union _AON_C_KOUT0X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_SOFTSTART_OVER: 1;
        uint32_t SWR_CORE_VREFSS_OVER: 1;
        uint32_t SWR_CORE_NGATE_HV: 1;
        uint32_t SWR_CORE_PGATE_HV: 1;
        uint32_t SWR_CORE_PFM_CTRL4: 1;
        uint32_t SWR_CORE_PFM_CTRL3: 1;
        uint32_t SWR_CORE_PFM_CTRL2: 1;
        uint32_t SWR_CORE_PFM_CTRL1: 1;
        uint32_t SWR_CORE_STOPg: 1;
        uint32_t SWR_CORE_VREFSS4_OVER: 1;
        uint32_t SWR_CORE_VREFSS3_OVER: 1;
        uint32_t SWR_CORE_VREFSS2_OVER: 1;
        uint32_t SWR_CORE_VREFSS1_OVER: 1;
        uint32_t SWR_CORE_VREFSS4_START: 1;
        uint32_t SWR_CORE_VREFSS3_START: 1;
        uint32_t SWR_CORE_VREFSS2_START: 1;
        uint32_t SWR_CORE_VREFSS1_START: 1;
        uint32_t SWR_CORE_VREFSS_START: 1;
        uint32_t SWR_CORE_CK: 1;
        uint32_t SWR_CORE_CK_CTRL: 1;
        uint32_t SWR_CORE_S_1_0: 2;
        uint32_t SWR_CORE_NI_OUT4: 1;
        uint32_t SWR_CORE_NI_OUT3: 1;
        uint32_t SWR_CORE_NI_OUT2: 1;
        uint32_t SWR_CORE_NI_OUT1: 1;
        uint32_t SWR_CORE_NI: 1;
        uint32_t SWR_CORE_PI: 1;
        uint32_t SWR_CORE_OUT4GATE_HV: 1;
        uint32_t SWR_CORE_OUT3GATE_HV: 1;
        uint32_t SWR_CORE_OUT2GATE_HV: 1;
        uint32_t SWR_CORE_OUT1GATE_HV: 1;
    };
} AON_C_KOUT0X_BUCK_TYPE;

/* 0xC6C    0x4000_0c6c
    0       R   SWR_CORE_VANA_DET_B                 1'b0
    1       R   SWR_CORE_VANA_DET                   1'b0
    2       R   SWR_CORE_ONTIME_OVER2               1'b0
    3       R   SWR_CORE_VCOMPPFM2                  1'b0
    4       R   SWR_CORE_ONTIME_OVER1               1'b0
    5       R   SWR_CORE_VCOMPPFM1                  1'b0
    6       R   SWR_CORE_VCOMP2                     1'b0
    7       R   SWR_CORE_VCOMP1                     1'b0
    8       R   SWR_CORE_CKOUT2X_DUMMY8             1'b0
    9       R   SWR_CORE_CKOUT2X_DUMMY9             1'b0
    10      R   SWR_CORE_PWM_CTRL2                  1'b0
    11      R   SWR_CORE_PWM_CTRL1                  1'b0
    12      R   SWR_CORE_CKOUT2X_DUMMY12            1'b0
    13      R   SWR_CORE_CKOUT2X_DUMMY13            1'b0
    14      R   SWR_CORE_CK_CTRL2                   1'b0
    15      R   SWR_CORE_CK_CTRL1                   1'b0
    16      R   SWR_CORE_VPA_TPM_DET_B              1'b0
    17      R   SWR_CORE_VPA_TPM_DET                1'b0
    18      R   SWR_CORE_ZCD                        1'b0
    19      R   SWR_CORE_ZCD_SET                    1'b0
    20      R   SWR_CORE_OUT4_OCCUPY                1'b0
    21      R   SWR_CORE_OUT3_OCCUPY                1'b0
    22      R   SWR_CORE_OUT2_OCCUPY                1'b0
    23      R   SWR_CORE_OUT1_OCCUPY                1'b0
    24      R   SWR_CORE_OUT4_CTRL                  1'b0
    25      R   SWR_CORE_OUT3_CTRL                  1'b0
    26      R   SWR_CORE_OUT2_CTRL                  1'b0
    27      R   SWR_CORE_OUT1_CTRL                  1'b0
    28      R   SWR_CORE_ONTIME_OVER4               1'b0
    29      R   SWR_CORE_VCOMPPFM4                  1'b0
    30      R   SWR_CORE_ONTIME_OVER3               1'b0
    31      R   SWR_CORE_VCOMPPFM3                  1'b0
 */
typedef volatile union _AON_CKOUT2X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_VANA_DET_B: 1;
        uint32_t SWR_CORE_VANA_DET: 1;
        uint32_t SWR_CORE_ONTIME_OVER2: 1;
        uint32_t SWR_CORE_VCOMPPFM2: 1;
        uint32_t SWR_CORE_ONTIME_OVER1: 1;
        uint32_t SWR_CORE_VCOMPPFM1: 1;
        uint32_t SWR_CORE_VCOMP2: 1;
        uint32_t SWR_CORE_VCOMP1: 1;
        uint32_t SWR_CORE_CKOUT2X_DUMMY8: 1;
        uint32_t SWR_CORE_CKOUT2X_DUMMY9: 1;
        uint32_t SWR_CORE_PWM_CTRL2: 1;
        uint32_t SWR_CORE_PWM_CTRL1: 1;
        uint32_t SWR_CORE_CKOUT2X_DUMMY12: 1;
        uint32_t SWR_CORE_CKOUT2X_DUMMY13: 1;
        uint32_t SWR_CORE_CK_CTRL2: 1;
        uint32_t SWR_CORE_CK_CTRL1: 1;
        uint32_t SWR_CORE_VPA_TPM_DET_B: 1;
        uint32_t SWR_CORE_VPA_TPM_DET: 1;
        uint32_t SWR_CORE_ZCD: 1;
        uint32_t SWR_CORE_ZCD_SET: 1;
        uint32_t SWR_CORE_OUT4_OCCUPY: 1;
        uint32_t SWR_CORE_OUT3_OCCUPY: 1;
        uint32_t SWR_CORE_OUT2_OCCUPY: 1;
        uint32_t SWR_CORE_OUT1_OCCUPY: 1;
        uint32_t SWR_CORE_OUT4_CTRL: 1;
        uint32_t SWR_CORE_OUT3_CTRL: 1;
        uint32_t SWR_CORE_OUT2_CTRL: 1;
        uint32_t SWR_CORE_OUT1_CTRL: 1;
        uint32_t SWR_CORE_ONTIME_OVER4: 1;
        uint32_t SWR_CORE_VCOMPPFM4: 1;
        uint32_t SWR_CORE_ONTIME_OVER3: 1;
        uint32_t SWR_CORE_VCOMPPFM3: 1;
    };
} AON_CKOUT2X_BUCK_TYPE;

/* 0xC70    0x4000_0c70
    0       R   SWR_CORE_VSRAM_DET_B                1'b0
    1       R   SWR_CORE_VSRAM_DET                  1'b0
    2       R   SWR_CORE_SEL_ZCDQ<0>                1'b0
    3       R   SWR_CORE_SEL_ZCDQ<1>                1'b0
    4       R   EN_UPDATE_CK4                       1'b0
    5       R   EN_UPDATE_CK3                       1'b0
    6       R   EN_UPDATE_CK2                       1'b0
    7       R   EN_UPDATE_CK1                       1'b0
    8       R   SWR_CORE_UPDATE_CK4                 1'b0
    9       R   SWR_CORE_UPDATE_CK3                 1'b0
    10      R   SWR_CORE_UPDATE_CK2                 1'b0
    11      R   SWR_CORE_UPDATE_CK1                 1'b0
    12      R   SWR_CORE_CKOUT4X_DUMMY12            1'b0
    13      R   SWR_CORE_EN_UPDATE                  1'b0
    14      R   SWR_CORE_UD                         1'b0
    15      R   SWR_CORE_CKOUT4X_DUMMY15            1'b0
    16      R   MBIAS_VCORE_DET                     1'b0
    17      R   MBIAS_RSTB_HV18                     1'b0
    18      R   MBIAS_RSTB_HV33                     1'b0
    19      R   MBIAS_PORBAON_HV33                  1'b0
    20      R   MBIAS_PORB18V_HV33                  1'b0
    21      R   MBIAS_PORB33V_HV33                  1'b0
    22      R   MBIAS_dly_BGOK                      1'b0
    23      R   MBIAS_BGOK                          1'b0
    31:24   R   SWR_CORE_ZCDQ<7:0>                  8'b0
 */
typedef volatile union _AON_CKOUT4X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_VSRAM_DET_B: 1;
        uint32_t SWR_CORE_VSRAM_DET: 1;
        uint32_t SWR_CORE_SEL_ZCDQ_0: 1;
        uint32_t SWR_CORE_SEL_ZCDQ_1: 1;
        uint32_t EN_UPDATE_CK4: 1;
        uint32_t EN_UPDATE_CK3: 1;
        uint32_t EN_UPDATE_CK2: 1;
        uint32_t EN_UPDATE_CK1: 1;
        uint32_t SWR_CORE_UPDATE_CK4: 1;
        uint32_t SWR_CORE_UPDATE_CK3: 1;
        uint32_t SWR_CORE_UPDATE_CK2: 1;
        uint32_t SWR_CORE_UPDATE_CK1: 1;
        uint32_t SWR_CORE_CKOUT4X_DUMMY12: 1;
        uint32_t SWR_CORE_EN_UPDATE: 1;
        uint32_t SWR_CORE_UD: 1;
        uint32_t SWR_CORE_CKOUT4X_DUMMY15: 1;
        uint32_t MBIAS_VCORE_DET: 1;
        uint32_t MBIAS_RSTB_HV18: 1;
        uint32_t MBIAS_RSTB_HV33: 1;
        uint32_t MBIAS_PORBAON_HV33: 1;
        uint32_t MBIAS_PORB18V_HV33: 1;
        uint32_t MBIAS_PORB33V_HV33: 1;
        uint32_t MBIAS_dly_BGOK: 1;
        uint32_t MBIAS_BGOK: 1;
        uint32_t SWR_CORE_ZCDQ_7_0: 8;
    };
} AON_CKOUT4X_BUCK_TYPE;

/* 0xC74    0x4000_0c74
    0       R   SWR_CORE_CKOUT6X_DUMMY0             1'b0
    1       R   SWR_CORE_CKOUT6X_DUMMY1             1'b0
    2       R   SWR_CORE_CKOUT6X_DUMMY2             1'b0
    3       R   SWR_CORE_CKOUT6X_DUMMY3             1'b0
    4       R   SWR_CORE_CKOUT6X_DUMMY4             1'b0
    5       R   SWR_CORE_CKOUT6X_DUMMY5             1'b0
    6       R   SWR_CORE_CKOUT6X_DUMMY6             1'b0
    7       R   SWR_CORE_CKOUT6X_DUMMY7             1'b0
    8       R   SWR_CORE_CKOUT6X_DUMMY8             1'b0
    9       R   SWR_CORE_CKOUT6X_DUMMY9             1'b0
    10      R   SWR_CORE_CKOUT6X_DUMMY10            1'b0
    11      R   SWR_CORE_CKOUT6X_DUMMY11            1'b0
    12      R   SWR_CORE_CKOUT6X_DUMMY12            1'b0
    13      R   SWR_CORE_CKOUT6X_DUMMY13            1'b0
    14      R   SWR_CORE_CKOUT6X_DUMMY14            1'b0
    15      R   SWR_CORE_CKOUT6X_DUMMY15            1'b0
    16      R   SWR_CORE_CKOUT7X_DUMMY16            1'b0
    17      R   SWR_CORE_CKOUT7X_DUMMY17            1'b0
    18      R   SWR_CORE_CKOUT7X_DUMMY18            1'b0
    19      R   SWR_CORE_CKOUT7X_DUMMY19            1'b0
    20      R   SWR_CORE_OCP                        1'b0
    21      R   SWR_CORE_CKOUT7X_DUMMY21            1'b0
    22      R   SWR_CORE_X_CLK1or2                  1'b0
    23      R   SWR_CORE_X_RAMP4ON                  1'b0
    24      R   SWR_CORE_X_RAMP3ON                  1'b0
    25      R   SWR_CORE_X_RAMP2ON                  1'b0
    26      R   SWR_CORE_X_RAMP1ON                  1'b0
    27      R   SWR_CORE_X_CLK4                     1'b0
    28      R   SWR_CORE_X_CLK3                     1'b0
    29      R   SWR_CORE_X_CLK2                     1'b0
    30      R   SWR_CORE_X_CLK1                     1'b0
    31      R   SWR_CORE_SCP1                       1'b0
 */
typedef volatile union _AON_CKOUT6X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_CKOUT6X_DUMMY0: 1;
        uint32_t SWR_CORE_CKOUT6X_DUMMY1: 1;
        uint32_t SWR_CORE_CKOUT6X_DUMMY2: 1;
        uint32_t SWR_CORE_CKOUT6X_DUMMY3: 1;
        uint32_t SWR_CORE_CKOUT6X_DUMMY4: 1;
        uint32_t SWR_CORE_CKOUT6X_DUMMY5: 1;
        uint32_t SWR_CORE_CKOUT6X_DUMMY6: 1;
        uint32_t SWR_CORE_CKOUT6X_DUMMY7: 1;
        uint32_t SWR_CORE_CKOUT6X_DUMMY8: 1;
        uint32_t SWR_CORE_CKOUT6X_DUMMY9: 1;
        uint32_t SWR_CORE_CKOUT6X_DUMMY10: 1;
        uint32_t SWR_CORE_CKOUT6X_DUMMY11: 1;
        uint32_t SWR_CORE_CKOUT6X_DUMMY12: 1;
        uint32_t SWR_CORE_CKOUT6X_DUMMY13: 1;
        uint32_t SWR_CORE_CKOUT6X_DUMMY14: 1;
        uint32_t SWR_CORE_CKOUT6X_DUMMY15: 1;
        uint32_t SWR_CORE_CKOUT7X_DUMMY16: 1;
        uint32_t SWR_CORE_CKOUT7X_DUMMY17: 1;
        uint32_t SWR_CORE_CKOUT7X_DUMMY18: 1;
        uint32_t SWR_CORE_CKOUT7X_DUMMY19: 1;
        uint32_t SWR_CORE_OCP: 1;
        uint32_t SWR_CORE_CKOUT7X_DUMMY21: 1;
        uint32_t SWR_CORE_X_CLK1or2: 1;
        uint32_t SWR_CORE_X_RAMP4ON: 1;
        uint32_t SWR_CORE_X_RAMP3ON: 1;
        uint32_t SWR_CORE_X_RAMP2ON: 1;
        uint32_t SWR_CORE_X_RAMP1ON: 1;
        uint32_t SWR_CORE_X_CLK4: 1;
        uint32_t SWR_CORE_X_CLK3: 1;
        uint32_t SWR_CORE_X_CLK2: 1;
        uint32_t SWR_CORE_X_CLK1: 1;
        uint32_t SWR_CORE_SCP1: 1;
    };
} AON_CKOUT6X_BUCK_TYPE;

/* 0xC78    0x4000_0c78
    0       R   SWR_CORE_CKOUT8X_DUMMY0             1'b0
    1       R   SWR_CORE_CKOUT8X_DUMMY1             1'b0
    2       R   SWR_CORE_CKOUT8X_DUMMY2             1'b0
    3       R   SWR_CORE_CKOUT8X_DUMMY3             1'b0
    4       R   SWR_CORE_CKOUT8X_DUMMY4             1'b0
    5       R   SWR_CORE_CKOUT8X_DUMMY5             1'b0
    6       R   SWR_CORE_CKOUT8X_DUMMY6             1'b0
    7       R   SWR_CORE_CKOUT8X_DUMMY7             1'b0
    8       R   SWR_CORE_CKOUT8X_DUMMY8             1'b0
    9       R   SWR_CORE_CKOUT8X_DUMMY9             1'b0
    10      R   SWR_CORE_CKOUT8X_DUMMY10            1'b0
    11      R   SWR_CORE_CKOUT8X_DUMMY11            1'b0
    12      R   SWR_CORE_CKOUT8X_DUMMY12            1'b0
    13      R   SWR_CORE_CKOUT8X_DUMMY13            1'b0
    14      R   SWR_CORE_CKOUT8X_DUMMY14            1'b0
    15      R   SWR_CORE_CKOUT8X_DUMMY15            1'b0
    16      R   SWR_CORE_CKOUT9X_DUMMY16            1'b0
    17      R   SWR_CORE_CKOUT9X_DUMMY17            1'b0
    18      R   SWR_CORE_CKOUT9X_DUMMY18            1'b0
    19      R   SWR_CORE_CKOUT9X_DUMMY19            1'b0
    20      R   SWR_CORE_CKOUT9X_DUMMY20            1'b0
    21      R   SWR_CORE_CKOUT9X_DUMMY21            1'b0
    22      R   SWR_CORE_CKOUT9X_DUMMY22            1'b0
    23      R   SWR_CORE_CKOUT9X_DUMMY23            1'b0
    24      R   SWR_CORE_CKOUT9X_DUMMY24            1'b0
    25      R   SWR_CORE_CKOUT9X_DUMMY25            1'b0
    26      R   SWR_CORE_CKOUT9X_DUMMY26            1'b0
    27      R   SWR_CORE_CKOUT9X_DUMMY27            1'b0
    28      R   SWR_CORE_CKOUT9X_DUMMY28            1'b0
    29      R   SWR_CORE_CKOUT9X_DUMMY29            1'b0
    30      R   SWR_CORE_CKOUT9X_DUMMY30            1'b0
    31      R   SWR_CORE_CKOUT9X_DUMMY31            1'b0
 */
typedef volatile union _AON_C_KOUT8X_BUCK_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SWR_CORE_CKOUT8X_DUMMY0: 1;
        uint32_t SWR_CORE_CKOUT8X_DUMMY1: 1;
        uint32_t SWR_CORE_CKOUT8X_DUMMY2: 1;
        uint32_t SWR_CORE_CKOUT8X_DUMMY3: 1;
        uint32_t SWR_CORE_CKOUT8X_DUMMY4: 1;
        uint32_t SWR_CORE_CKOUT8X_DUMMY5: 1;
        uint32_t SWR_CORE_CKOUT8X_DUMMY6: 1;
        uint32_t SWR_CORE_CKOUT8X_DUMMY7: 1;
        uint32_t SWR_CORE_CKOUT8X_DUMMY8: 1;
        uint32_t SWR_CORE_CKOUT8X_DUMMY9: 1;
        uint32_t SWR_CORE_CKOUT8X_DUMMY10: 1;
        uint32_t SWR_CORE_CKOUT8X_DUMMY11: 1;
        uint32_t SWR_CORE_CKOUT8X_DUMMY12: 1;
        uint32_t SWR_CORE_CKOUT8X_DUMMY13: 1;
        uint32_t SWR_CORE_CKOUT8X_DUMMY14: 1;
        uint32_t SWR_CORE_CKOUT8X_DUMMY15: 1;
        uint32_t SWR_CORE_CKOUT9X_DUMMY16: 1;
        uint32_t SWR_CORE_CKOUT9X_DUMMY17: 1;
        uint32_t SWR_CORE_CKOUT9X_DUMMY18: 1;
        uint32_t SWR_CORE_CKOUT9X_DUMMY19: 1;
        uint32_t SWR_CORE_CKOUT9X_DUMMY20: 1;
        uint32_t SWR_CORE_CKOUT9X_DUMMY21: 1;
        uint32_t SWR_CORE_CKOUT9X_DUMMY22: 1;
        uint32_t SWR_CORE_CKOUT9X_DUMMY23: 1;
        uint32_t SWR_CORE_CKOUT9X_DUMMY24: 1;
        uint32_t SWR_CORE_CKOUT9X_DUMMY25: 1;
        uint32_t SWR_CORE_CKOUT9X_DUMMY26: 1;
        uint32_t SWR_CORE_CKOUT9X_DUMMY27: 1;
        uint32_t SWR_CORE_CKOUT9X_DUMMY28: 1;
        uint32_t SWR_CORE_CKOUT9X_DUMMY29: 1;
        uint32_t SWR_CORE_CKOUT9X_DUMMY30: 1;
        uint32_t SWR_CORE_CKOUT9X_DUMMY31: 1;
    };
} AON_C_KOUT8X_BUCK_TYPE;

/* 0xC80    0x4000_0c80
    1:0     R/W XTAL32K_CUR_MAIN[1:0]               2'b01
    5:2     R/W XTAL32K_CUR_GM_INI[3:0]             4'b1001
    9:6     R/W XTAL32K_CUR_GM[3:0]                 4'b0101
    11:10   R/W XTAL32K_CUR_REP[1:0]                2'b01
    15:12   R/W XTAL32K_GM[3:0]                     4'b1111
    16      R/W EN_XTAL32K_CAP_INITIAL              1'b1
    17      R/W EN_XTAL32K_CAP_AWAKE                1'b1
    23:18   R/W XTAL32K_SC_XI[5:0]                  6'b100000
    29:24   R/W XTAL32K_SC_XO[5:0]                  6'b100000
    31:30   R/W XTAL32K_TOK[1:0]                    2'b11
 */
typedef volatile union _AON_RG0X_32KXTAL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t XTAL32K_CUR_MAIN_1_0: 2;
        uint32_t XTAL32K_CUR_GM_INI_3_0: 4;
        uint32_t XTAL32K_CUR_GM_3_0: 4;
        uint32_t XTAL32K_CUR_REP_1_0: 2;
        uint32_t XTAL32K_GM_3_0: 4;
        uint32_t EN_XTAL32K_CAP_INITIAL: 1;
        uint32_t EN_XTAL32K_CAP_AWAKE: 1;
        uint32_t XTAL32K_SC_XI_5_0: 6;
        uint32_t XTAL32K_SC_XO_5_0: 6;
        uint32_t XTAL32K_TOK_1_0: 2;
    };
} AON_RG0X_32KXTAL_TYPE;

/* 0xC84    0x4000_0c84
    0       R/W ENB_XTAL32K_FBRES                   1'b0
    3:1     R/W XTAL32K_GM_REP[2:0]                 3'b111
    4       R/W XTAL32K_SC_XI_EXTRA                 1'b0
    5       R/W XTAL32K_SC_XO_EXTRA                 1'b0
    6       R/W XTAL32K_GPIO_SEL                    1'b0
    7       R/W XTAL32K_RG2X_DUMMY2                 1'b0
    15:8    R/W XTAL32K_RG2X_DUMMY1                 8'b00000000
    31:16   R   RSVD                                16'b0
 */
typedef volatile union _AON_RG2X_32KXTAL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t ENB_XTAL32K_FBRES: 1;
        uint32_t XTAL32K_GM_REP_2_0: 3;
        uint32_t XTAL32K_SC_XI_EXTRA: 1;
        uint32_t XTAL32K_SC_XO_EXTRA: 1;
        uint32_t XTAL32K_GPIO_SEL: 1;
        uint32_t XTAL32K_RG2X_DUMMY2: 1;
        uint32_t XTAL32K_RG2X_DUMMY1: 8;
        uint32_t RSVD: 16;
    };
} AON_RG2X_32KXTAL_TYPE;

/* 0xC88    0x4000_0c88
    5:0     R/W RCAL[5:0]                           6'b100000
    12:6    R/W OSC32K_RG0X_DUMMY2                  7'b0000000
    13      R/W OSC32K_RG0X_DUMMY1                  1'b0
    14      R/W GATED_STUP_OK                       1'b0
    15      R/W SEL_LDO_VREF                        1'b0
    31:16   R   RSVD                                16'b0
 */
typedef volatile union _AON_RG0X_32KOSC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RCAL_5_0: 6;
        uint32_t OSC32K_RG0X_DUMMY2: 7;
        uint32_t OSC32K_RG0X_DUMMY1: 1;
        uint32_t GATED_STUP_OK: 1;
        uint32_t SEL_LDO_VREF: 1;
        uint32_t RSVD: 16;
    };
} AON_RG0X_32KOSC_TYPE;

/* 0xC8C    0x4000_0c8c
    7:0     R/W RCAL[7:0]                           8'b10000000
    9:8     R/W OSC_SEL_TOK[1:0]                    2'b10
    15:10   R/W OSC40M_RG0X_DUMMY1                  6'b0
    31:16   R/W RSVD                                16'b0
 */
typedef volatile union _AON_REG0X_40MOSC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RCAL_7_0: 8;
        uint32_t OSC_SEL_TOK_1_0: 2;
        uint32_t OSC40M_RG0X_DUMMY1: 6;
        uint32_t RSVD: 16;
    };
} AON_REG0X_40MOSC_TYPE;

/* 0xC90    0x4000_0c90
    0       R/W POW_32KOSC                          1'b1
    1       R/W POW_32KXTAL                         1'b1
    2       R   POW_40MOSC                          1'b0
    15:3    R   RSVD                                13'b0
    31:16   R   RSVD                                16'b0
 */
typedef volatile union _AON_POW_32K_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t POW_32KOSC: 1;
        uint32_t POW_32KXTAL: 1;
        uint32_t POW_40MOSC: 1;
        uint32_t RSVD_1: 13;
        uint32_t RSVD: 16;
    };
} AON_POW_32K_TYPE;

/* 0xCA0    0x4000_0ca0
    2:0     R/W XTAL_SEL_MODE                       3'b100
    5:3     R/W XTAL_EN_MODE_DEBUG                  3'b0
    6       R/W POW_XTAL                            1'b0
    7       R/W XTAL_ISO_XTAL2DIG                   1'b1
    8       R/W XTAL_SUPPLY_MODE                    1'b0
    9       R/W STARTUP_BK                          1'b0
    10      R/W ISO_VDDON_XTAL                      1'b1
    11      R/W ISO_XTAL_MODE_CTRL                  1'b1
    15:12   R/W ANAPAR_XTAL_MODE_DUMMY              4'b0
    31:16   R   RSVD                                16'b0
 */
typedef volatile union _AON_ANAPAR_XTAL_MODE_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t XTAL_SEL_MODE: 3;
        uint32_t XTAL_EN_MODE_DEBUG: 3;
        uint32_t POW_XTAL: 1;
        uint32_t XTAL_ISO_XTAL2DIG: 1;
        uint32_t XTAL_SUPPLY_MODE: 1;
        uint32_t STARTUP_BK: 1;
        uint32_t ISO_VDDON_XTAL: 1;
        uint32_t ISO_XTAL_MODE_CTRL: 1;
        uint32_t ANAPAR_XTAL_MODE_DUMMY: 4;
        uint32_t RSVD: 16;
    };
} AON_ANAPAR_XTAL_MODE_TYPE;

/* 0xCA4    0x4000_0ca4
    7:0     R/W XTAL_TUNE_SC_XI_FREQ                8'b00111111
    15:8    R/W XTAL_TUNE_SC_XO_FREQ                8'b00111111
    23:16   R/W XTAL_TUNE_SC_INI                    8'b01110000
    31:24   R/W XTAL_TUNE_SC_LP                     8'b01111111
 */
typedef volatile union _AON_ANAPAR_XTAL0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t XTAL_TUNE_SC_XI_FREQ: 8;
        uint32_t XTAL_TUNE_SC_XO_FREQ: 8;
        uint32_t XTAL_TUNE_SC_INI: 8;
        uint32_t XTAL_TUNE_SC_LP: 8;
    };
} AON_ANAPAR_XTAL0_TYPE;

/* 0xCA8    0x4000_0ca8
    0       R/W XTAL_REG2X_DUMMY1                   1'b0
    5:1     R/W XTAL_SEL_BUF_GM_N                   5'b01000
    10:6    R/W XTAL_REG2X_DUMMY2                   5'b01000
    15:11   R/W XTAL_SEL_BUF_GM_P                   5'b01000
    20:16   R/W XTAL_REG3X_DUMMY1                   5'b01000
    21      R/W XTAL_EN_LPCNT_CLK_DIV               1'b0
    22      R/W XTAL_EN_LPMODE_CLK_SEL              1'b0
    23      R/W XTAL_EN_LPS_CLK                     1'b1
    24      R/W XTAL_EN_PDCK_VREF                   1'b1
    25      R/W XTAL_EN_XO_CLK_SW                   1'b0
    26      R/W XTAL_EN_DAAC_GM                     1'b0
    27      R/W XTAL_EN_SEL_TOK01                   1'b0
    29:28   R/W XTAL_SEL_AAAC_CAP                   2'b11
    31:30   R/W XTAL_SEL_AAAC_IOFFSET               2'b00
 */
typedef volatile union _AON_ANAPAR_XTAL2_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t XTAL_REG2X_DUMMY1: 1;
        uint32_t XTAL_SEL_BUF_GM_N: 5;
        uint32_t XTAL_REG2X_DUMMY2: 5;
        uint32_t XTAL_SEL_BUF_GM_P: 5;
        uint32_t XTAL_REG3X_DUMMY1: 5;
        uint32_t XTAL_EN_LPCNT_CLK_DIV: 1;
        uint32_t XTAL_EN_LPMODE_CLK_SEL: 1;
        uint32_t XTAL_EN_LPS_CLK: 1;
        uint32_t XTAL_EN_PDCK_VREF: 1;
        uint32_t XTAL_EN_XO_CLK_SW: 1;
        uint32_t XTAL_EN_DAAC_GM: 1;
        uint32_t XTAL_EN_SEL_TOK01: 1;
        uint32_t XTAL_SEL_AAAC_CAP: 2;
        uint32_t XTAL_SEL_AAAC_IOFFSET: 2;
    };
} AON_ANAPAR_XTAL2_TYPE;

/* 0xCAC    0x4000_0cac
    1:0     R/W XTAL_SEL_AAAC_OP_CUR                2'b00
    3:2     R/W XTAL_SEL_AAAC_PKDET_SW              2'b01
    4       R/W XTAL_EN_AAAC_TIE_MID                1'b0
    9:5     R/W XTAL_SEL_AAAC_VREF                  5'b10000
    10      R/W XTAL_REG4X_DUMMY1                   1'b0
    11      R/W XTAL_SEL_BUF_LPS                    1'b0
    14:12   R/W XTAL_REG4X_DUMMY2                   3'b110
    15      R/W XTAL_REG4X_DUMMY3                   1'b0
    16      R/W XTAL_REG5X_DUMMY1                   1'b0
    17      R/W XTAL_EN_MANU_DAAC_PKDET             1'b0
    20:18   R/W XTAL_SEL_DAAC_PK                    3'b100
    23:21   R/W XTAL_EN_MANU_DAAC_PK_SEL            3'b100
    24      R/W XTAL_EN_DEBUG                       1'b0
    25      R/W XTAL_SEL_AFE_DELAY                  1'b0
    26      R/W XTAL_SEL_DIGI_DELAY                 1'b0
    28:27   R/W XTAL_SEL_AFE_DRV                    2'b11
    29      R/W XTAL_EN_AFE_DRV_LATCH               1'b0
    31:30   R/W XTAL_SEL_AFE_DRV_LP                 2'b11
 */
typedef volatile union _AON_ANAPAR_XTAL4_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t XTAL_SEL_AAAC_OP_CUR: 2;
        uint32_t XTAL_SEL_AAAC_PKDET_SW: 2;
        uint32_t XTAL_EN_AAAC_TIE_MID: 1;
        uint32_t XTAL_SEL_AAAC_VREF: 5;
        uint32_t XTAL_REG4X_DUMMY1: 1;
        uint32_t XTAL_SEL_BUF_LPS: 1;
        uint32_t XTAL_REG4X_DUMMY2: 3;
        uint32_t XTAL_REG4X_DUMMY3: 1;
        uint32_t XTAL_REG5X_DUMMY1: 1;
        uint32_t XTAL_EN_MANU_DAAC_PKDET: 1;
        uint32_t XTAL_SEL_DAAC_PK: 3;
        uint32_t XTAL_EN_MANU_DAAC_PK_SEL: 3;
        uint32_t XTAL_EN_DEBUG: 1;
        uint32_t XTAL_SEL_AFE_DELAY: 1;
        uint32_t XTAL_SEL_DIGI_DELAY: 1;
        uint32_t XTAL_SEL_AFE_DRV: 2;
        uint32_t XTAL_EN_AFE_DRV_LATCH: 1;
        uint32_t XTAL_SEL_AFE_DRV_LP: 2;
    };
} AON_ANAPAR_XTAL4_TYPE;

/* 0xCB0    0x4000_0cb0
    0       R/W XTAL_EN_AFE_DRV_LP_LATCH            1'b0
    2:1     R/W XTAL_SEL_DIGI_DRV                   2'b11
    3       R/W XTAL_EN_DIGI_DRV_LATCH              1'b0
    5:4     R/W XTAL_SEL_DIGI_DRV_LP                2'b11
    7:6     R/W XTAL_SEL_LPS_DRV                    2'b00
    9:8     R/W XTAL_SEL_RF_DRV                     2'b11
    10      R/W XTAL_EN_RF_DRV_LATCH                1'b0
    11      R/W XTAL_EN_FW_CTRL_GATED_B             1'b1
    12      R/W XTAL_GATED_AFEN                     1'b0
    13      R/W XTAL_GATED_AFEN_LP                  1'b0
    14      R/W XTAL_GATED_AFEP                     1'b0
    15      R/W XTAL_GATED_AFEP_LP                  1'b0
    16      R/W XTAL_GATED_DIGIN                    1'b0
    17      R/W XTAL_GATED_DIGIP                    1'b0
    18      R/W XTAL_GATED_DIGI_LP                  1'b0
    19      R/W XTAL_GATED_LPS                      1'b0
    20      R/W XTAL_GATED_RFN                      1'b0
    21      R/W XTAL_GATED_RFP                      1'b0
    27:22   R/W XTAL_SEL_GM_N                       6'b111111
    31:28   R/W XTAL_REG7X_DUMMY1                   4'b0000
 */
typedef volatile union _AON_ANAPAR_XTAL6_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t XTAL_EN_AFE_DRV_LP_LATCH: 1;
        uint32_t XTAL_SEL_DIGI_DRV: 2;
        uint32_t XTAL_EN_DIGI_DRV_LATCH: 1;
        uint32_t XTAL_SEL_DIGI_DRV_LP: 2;
        uint32_t XTAL_SEL_LPS_DRV: 2;
        uint32_t XTAL_SEL_RF_DRV: 2;
        uint32_t XTAL_EN_RF_DRV_LATCH: 1;
        uint32_t XTAL_EN_FW_CTRL_GATED_B: 1;
        uint32_t XTAL_GATED_AFEN: 1;
        uint32_t XTAL_GATED_AFEN_LP: 1;
        uint32_t XTAL_GATED_AFEP: 1;
        uint32_t XTAL_GATED_AFEP_LP: 1;
        uint32_t XTAL_GATED_DIGIN: 1;
        uint32_t XTAL_GATED_DIGIP: 1;
        uint32_t XTAL_GATED_DIGI_LP: 1;
        uint32_t XTAL_GATED_LPS: 1;
        uint32_t XTAL_GATED_RFN: 1;
        uint32_t XTAL_GATED_RFP: 1;
        uint32_t XTAL_SEL_GM_N: 6;
        uint32_t XTAL_REG7X_DUMMY1: 4;
    };
} AON_ANAPAR_XTAL6_TYPE;

/* 0xCB4    0x4000_0cb4
    1:0     R/W XTAL_REG8X_DUMMY2                   2'b00
    7:2     R/W XTAL_SEL_GM_P                       6'b111111
    13:8    R/W XTAL_SEL_GM_P_LP                    6'b111111
    14      R/W XTAL_EN_GM_SEPERATE                 1'b0
    15      R/W XTAL_REG8X_DUMMY1                   1'b0
    18:16   R/W XTAL_REG9X_DUMMY1                   3'b000
    20:19   R/W XTAL_SEL_LDOFASTSET_CYCLE           2'b01
    21      R/W XTAL_EN_LDOFASTSET_MANU             1'b0
    22      R/W XTAL_REG9X_DUMMY2                   1'b0
    26:23   R/W XTAL_TUNE_LDO_OK_VOUT               4'b0101
    27      R/W XTAL_EN_LPMODE_AUTO_GATED           1'b0
    28      R/W XTAL_EN_LPMODE_CLK_AON              1'b0
    31:29   R/W XTAL_SEL_LPS_DIV                    3'b110
 */
typedef volatile union _AON_ANAPAR_XTAL8_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t XTAL_REG8X_DUMMY2: 2;
        uint32_t XTAL_SEL_GM_P: 6;
        uint32_t XTAL_SEL_GM_P_LP: 6;
        uint32_t XTAL_EN_GM_SEPERATE: 1;
        uint32_t XTAL_REG8X_DUMMY1: 1;
        uint32_t XTAL_REG9X_DUMMY1: 3;
        uint32_t XTAL_SEL_LDOFASTSET_CYCLE: 2;
        uint32_t XTAL_EN_LDOFASTSET_MANU: 1;
        uint32_t XTAL_REG9X_DUMMY2: 1;
        uint32_t XTAL_TUNE_LDO_OK_VOUT: 4;
        uint32_t XTAL_EN_LPMODE_AUTO_GATED: 1;
        uint32_t XTAL_EN_LPMODE_CLK_AON: 1;
        uint32_t XTAL_SEL_LPS_DIV: 3;
    };
} AON_ANAPAR_XTAL8_TYPE;

/* 0xCB8    0x4000_0cb8
    0       R/W XTAL_REG10X_DUMMY1                  1'b0
    1       R/W XTAL_LP_GATE_FW_CTRL_B              1'b0
    2       R/W XTAL_EN_NMDAAC                      1'b1
    3       R/W XTAL_REG10X_DUMMY2                  1'b0
    4       R/W XTAL_REG10X_DUMMY3                  1'b0
    5       R/W XTAL_EN_PDCK_OK_MANU                1'b1
    6       R/W XTAL_EN_PKDET_CMP_SWAP              1'b0
    7       R/W XTAL_EN_PKDET_LOAD_SWAP             1'b0
    10:8    R/W XTAL_SEL_TOK01                      3'b100
    13:11   R/W XTAL_SEL_TOK                        3'b101
    14      R/W XTAL_REG10X_DUMMY4                  1'b1
    15      R/W XTAL_EN_SUPPLY_MODE_CTRLBYFASTAON_B 1'b1
    16      R/W XTAL_EN_SUPPLY_MODE_FASTAON         1'b1
    17      R/W XTAL_EN_LDO2PWRCUT                  1'b0
    20:18   R/W XTAL_SEL_XORES                      3'b000
    21      R/W XTAL_EN_PDCK_MANU                   1'b0
    22      R/W XTAL_EN_PLL_CP_ALWAYS_ON            1'b0
    24:23   R/W XTAL_SEL_CP_DISABLE_CYCLE           2'b11
    30:25   R/W XTAL_REG11X_DUMMY1                  6'b111111
    31      R/W EN_XTAL_AAC_PKDET                   1'b0
 */
typedef volatile union _AON_ANAPAR_XTAL10_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t XTAL_REG10X_DUMMY1: 1;
        uint32_t XTAL_LP_GATE_FW_CTRL_B: 1;
        uint32_t XTAL_EN_NMDAAC: 1;
        uint32_t XTAL_REG10X_DUMMY2: 1;
        uint32_t XTAL_REG10X_DUMMY3: 1;
        uint32_t XTAL_EN_PDCK_OK_MANU: 1;
        uint32_t XTAL_EN_PKDET_CMP_SWAP: 1;
        uint32_t XTAL_EN_PKDET_LOAD_SWAP: 1;
        uint32_t XTAL_SEL_TOK01: 3;
        uint32_t XTAL_SEL_TOK: 3;
        uint32_t XTAL_REG10X_DUMMY4: 1;
        uint32_t XTAL_EN_SUPPLY_MODE_CTRLBYFASTAON_B: 1;
        uint32_t XTAL_EN_SUPPLY_MODE_FASTAON: 1;
        uint32_t XTAL_EN_LDO2PWRCUT: 1;
        uint32_t XTAL_SEL_XORES: 3;
        uint32_t XTAL_EN_PDCK_MANU: 1;
        uint32_t XTAL_EN_PLL_CP_ALWAYS_ON: 1;
        uint32_t XTAL_SEL_CP_DISABLE_CYCLE: 2;
        uint32_t XTAL_REG11X_DUMMY1: 6;
        uint32_t EN_XTAL_AAC_PKDET: 1;
    };
} AON_ANAPAR_XTAL10_TYPE;

/* 0xCBC    0x4000_0cbc
    3:0     R/W XTAL_TUNE_LDO_VOUT                  4'b0101
    6:4     R/W BG_T_OPTION                         3'b011
    7       R/W XTAL_HP_IBGPMU_SEL                  1'b0
    8       R/W XTAL_LPLDO_SEL                      1'b0
    9       R/W XTAK_NMPC_SEL                       1'b0
    15:10   R/W XTAL_REG12X_DUMMY1                  6'b000000
    31:16   R/W XTAL_REG13X_DUMMY1                  16'b0000000000000000
 */
typedef volatile union _AON_ANAPAR_XTAL12_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t XTAL_TUNE_LDO_VOUT: 4;
        uint32_t BG_T_OPTION: 3;
        uint32_t XTAL_HP_IBGPMU_SEL: 1;
        uint32_t XTAL_LPLDO_SEL: 1;
        uint32_t XTAK_NMPC_SEL: 1;
        uint32_t XTAL_REG12X_DUMMY1: 6;
        uint32_t XTAL_REG13X_DUMMY1: 16;
    };
} AON_ANAPAR_XTAL12_TYPE;

/* 0xCC0    0x4000_0cc0
    15:0    R/W XTAL_REG14X_DUMMY1                  16'b0000000000000000
    31:16   R/W XTAL_REG15X_DUMMY1                  16'b0000000000000000
 */
typedef volatile union _AON_ANAPAR_XTAL14_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t XTAL_REG14X_DUMMY1: 16;
        uint32_t XTAL_REG15X_DUMMY1: 16;
    };
} AON_ANAPAR_XTAL14_TYPE;

/* 0xCD0    0x4000_0cd0
    0       R/W LDO_PA_POW_LDO                      1'b0
    1       R/W LDO_PA_EN_PC                        1'b0
    2       R/W LDO_PA_EN_OFF30MV                   1'b0
    9:3     R/W LDO_PA_TUNE_VOUT                    7'b1101110
    10      R/W LDO_PA_ENB_ADP_PC_CTRL              1'b1
    13:11   R/W LDO_PA_TUNE_VREF                    3'b100
    14      R/W LDO_PA_VOUT_DISCHARGE               1'b0
    15      R/W LDO_PA_EN_VREF                      1'b0
    31:16   R   RSVD                                16'b0
 */
typedef volatile union _AON_LDOPA_REG3X_LDO_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LDO_PA_POW_LDO: 1;
        uint32_t LDO_PA_EN_PC: 1;
        uint32_t LDO_PA_EN_OFF30MV: 1;
        uint32_t LDO_PA_TUNE_VOUT: 7;
        uint32_t LDO_PA_ENB_ADP_PC_CTRL: 1;
        uint32_t LDO_PA_TUNE_VREF: 3;
        uint32_t LDO_PA_VOUT_DISCHARGE: 1;
        uint32_t LDO_PA_EN_VREF: 1;
        uint32_t RSVD: 16;
    };
} AON_LDOPA_REG3X_LDO_TYPE;

/* 0xCD4    0x4000_0cd4
    1:0     R/W LDO_PA_REG_DUMMYLOAD0               2'b10
    15:2    R/W LDO_PA_REG_DUMMY0                   14'b0
    31:16   R   RSVD                                16'b0
 */
typedef volatile union _AON_LDOPA_REG_DUMMYLOAD_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t LDO_PA_REG_DUMMYLOAD0: 2;
        uint32_t LDO_PA_REG_DUMMY0: 14;
        uint32_t RSVD: 16;
    };
} AON_LDOPA_REG_DUMMYLOAD_TYPE;

/* 0xCD8    0x4000_0cd8
    0       R/W BT_ANAPAR_LDO_ADDA<0>               1'b0
    1       R/W BT_ANAPAR_LDO_ADDA<1>               1'b1
    2       R/W BT_ANAPAR_LDO_ADDA<2>               1'b0
    6:3     R/W BT_ANAPAR_LDO_ADDA<6:3>             4'b0100
    7       R/W BT_ANAPAR_LDO_ADDA<7>               1'b0
    15:8    R/W BT_ANAPAR_LDO_ADDA_DUMMY            8'b0
    31:16   R   RSVD                                16'b0
 */
typedef volatile union _AON_BT_ANAPAR_LDO_ADDA_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t BT_ANAPAR_LDO_ADDA_0: 1;
        uint32_t BT_ANAPAR_LDO_ADDA_1: 1;
        uint32_t BT_ANAPAR_LDO_ADDA_2: 1;
        uint32_t BT_ANAPAR_LDO_ADDA_6_3: 4;
        uint32_t BT_ANAPAR_LDO_ADDA_7: 1;
        uint32_t BT_ANAPAR_LDO_ADDA_DUMMY: 8;
        uint32_t RSVD: 16;
    };
} AON_BT_ANAPAR_LDO_ADDA_TYPE;

/* 0xCDC    0x4000_0cdc
    0       R/W BT_TPMK_ADC_LDO<0>                  1'b0
    1       R/W BT_TPMK_ADC_LDO<1>                  1'b1
    2       R/W BT_TPMK_ADC_LDO<2>                  1'b0
    6:3     R/W BT_TPMK_ADC_LDO<6:3>                4'b0101
    7       R/W BT_TPMK_ADC_LDO<7>                  1'b0
    15:8    R/W BT_TPMK_ADC_LDO_DUMMY               8'b0
    31:16   R   RSVD                                16'b0
 */
typedef volatile union _AON_BT_TPMK_ADC_LDO_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t BT_TPMK_ADC_LDO_0: 1;
        uint32_t BT_TPMK_ADC_LDO_1: 1;
        uint32_t BT_TPMK_ADC_LDO_2: 1;
        uint32_t BT_TPMK_ADC_LDO_6_3: 4;
        uint32_t BT_TPMK_ADC_LDO_7: 1;
        uint32_t BT_TPMK_ADC_LDO_DUMMY: 8;
        uint32_t RSVD: 16;
    };
} AON_BT_TPMK_ADC_LDO_TYPE;

/* 0xCE0    0x4000_0ce0
    0       R/W BT_RF18_LDO<0>                      1'b0
    1       R/W BT_RF18_LDO<1>                      1'b0
    2       R/W BT_RF18_LDO<2>                      1'b0
    5:3     R/W BT_RF18_LDO<5:3>                    3'b101
    15:6    R/W BT_RF18_LDO_DUMMY                   10'b0
    31:16   R   RSVD                                16'b0
 */
typedef volatile union _AON_BT_RF18_LDO_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t BT_RF18_LDO_0: 1;
        uint32_t BT_RF18_LDO_1: 1;
        uint32_t BT_RF18_LDO_2: 1;
        uint32_t BT_RF18_LDO_5_3: 3;
        uint32_t BT_RF18_LDO_DUMMY: 10;
        uint32_t RSVD: 16;
    };
} AON_BT_RF18_LDO_TYPE;

/* 0xD00    0x4000_0d00
    0       R/W BTPLL1_ANAPAR_PLL0_DUMMY3           1'b0
    1       R/W BTPLL1_POW_PLL                      1'b0
    4:2     R/W BTPLL1_SEL_CP_BIA                   3'b000
    5       R/W BTPLL1_ANAPAR_PLL0_DUMMY2           1'b0
    7:6     R/W BTPLL1_SEL_LDO1_VOUT                2'b01
    9:8     R/W BTPLL1_SEL_LPF_CP                   2'b10
    11:10   R/W BTPLL1_SEL_LPF_CS                   2'b10
    14:12   R/W BTPLL1_SEL_LPF_R3                   3'b010
    15      R/W BTPLL1_ANAPAR_PLL0_DUMMY1           1'b0
    18:16   R/W BTPLL1_SEL_LPF_RS                   3'b100
    19      R/W BTPLL1_EN_DOG_B                     1'b1
    21:20   R/W BTPLL1_VC_THL                       2'b00
    22      R/W BTPLL1_SEL_FREF_EDGE                1'b0
    23      R/W BTPLL1_ANAPAR_PLL1_DUMMY2           1'b0
    25:24   R/W BTPLL1_CK_BTDAC_SEL                 2'b01
    27:26   R/W BTPLL1_SEL_LPF_C3                   2'b10
    28      R/W BTPLL1_ANAPAR_PLL1_DUMMY1           1'b0
    29      R/W BTPLL1_GATED_TPMKAD_CLK             1'b1
    30      R/W BTPLL1_GATED_DAC_CLK                1'b1
    31      R/W BTPLL1_GATED_ADC_CLK                1'b1
 */
typedef volatile union _AON_BT_ANAPAR_PLL0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t BTPLL1_ANAPAR_PLL0_DUMMY3: 1;
        uint32_t BTPLL1_POW_PLL: 1;
        uint32_t BTPLL1_SEL_CP_BIA: 3;
        uint32_t BTPLL1_ANAPAR_PLL0_DUMMY2: 1;
        uint32_t BTPLL1_SEL_LDO1_VOUT: 2;
        uint32_t BTPLL1_SEL_LPF_CP: 2;
        uint32_t BTPLL1_SEL_LPF_CS: 2;
        uint32_t BTPLL1_SEL_LPF_R3: 3;
        uint32_t BTPLL1_ANAPAR_PLL0_DUMMY1: 1;
        uint32_t BTPLL1_SEL_LPF_RS: 3;
        uint32_t BTPLL1_EN_DOG_B: 1;
        uint32_t BTPLL1_VC_THL: 2;
        uint32_t BTPLL1_SEL_FREF_EDGE: 1;
        uint32_t BTPLL1_ANAPAR_PLL1_DUMMY2: 1;
        uint32_t BTPLL1_CK_BTDAC_SEL: 2;
        uint32_t BTPLL1_SEL_LPF_C3: 2;
        uint32_t BTPLL1_ANAPAR_PLL1_DUMMY1: 1;
        uint32_t BTPLL1_GATED_TPMKAD_CLK: 1;
        uint32_t BTPLL1_GATED_DAC_CLK: 1;
        uint32_t BTPLL1_GATED_ADC_CLK: 1;
    };
} AON_BT_ANAPAR_PLL0_TYPE;

/* 0xD04    0x4000_0d04
    0       R/W BTPLL1_EN_PLL_CKO1                  1'b1
    1       R/W BTPLL1_SEL_DIV2_PLL_CKO1            1'b0
    2       R/W BTPLL1_SEL_PLL_CKO1                 1'b0
    3       R/W BTPLL1_EN_PLL_CKO2                  1'b1
    4       R/W BTPLL1_EN_PLL_ADC_CLK               1'b0
    5       R/W BTPLL1_SEL_PLL_ADC_CLK              1'b1
    6       R/W BTPLL1_EN_PLL_DAC_CLK               1'b0
    7       R/W BTPLL1_SEL_IF160M                   1'b0
    8       R/W BTPLL1_EN_PLL_TPMKADC_CLK           1'b1
    10:9    R/W BTPLL1_SEL_DIVDN_PLL_CLK            2'b01
    11      R/W BTPLL1_SEL_IF40M                    1'b0
    12      R/W BTPLL1_ANAPAR_PLL2_DUMMY2           1'b0
    13      R/W BTPLL1_EN_BTADDA_TPMKAD             1'b1
    14      R/W BTPLL1_EN_BTADDA_DA                 1'b1
    15      R/W BTPLL1_EN_BTADDA_AD                 1'b1
    16      R/W BTPLL1_POW_DIV_PLL_CLK              1'b0
    17      R/W BTPLL_SEL_CK_EXT_FREF               1'b0
    18      R/W BTPLL1_SEL_CKFREF                   1'b0
    20:19   R/W BTPLL1_SEL_DIVDN_XTAL               2'b00
    24:21   R/W BTPLL1_SEL_DBG_SDM                  4'b0000
    31:25   R/W BTPLL1_SEL_DIVN_SDM                 7'b0010010
 */
typedef volatile union _AON_BT_ANAPAR_PLL2_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t BTPLL1_EN_PLL_CKO1: 1;
        uint32_t BTPLL1_SEL_DIV2_PLL_CKO1: 1;
        uint32_t BTPLL1_SEL_PLL_CKO1: 1;
        uint32_t BTPLL1_EN_PLL_CKO2: 1;
        uint32_t BTPLL1_EN_PLL_ADC_CLK: 1;
        uint32_t BTPLL1_SEL_PLL_ADC_CLK: 1;
        uint32_t BTPLL1_EN_PLL_DAC_CLK: 1;
        uint32_t BTPLL1_SEL_IF160M: 1;
        uint32_t BTPLL1_EN_PLL_TPMKADC_CLK: 1;
        uint32_t BTPLL1_SEL_DIVDN_PLL_CLK: 2;
        uint32_t BTPLL1_SEL_IF40M: 1;
        uint32_t BTPLL1_ANAPAR_PLL2_DUMMY2: 1;
        uint32_t BTPLL1_EN_BTADDA_TPMKAD: 1;
        uint32_t BTPLL1_EN_BTADDA_DA: 1;
        uint32_t BTPLL1_EN_BTADDA_AD: 1;
        uint32_t BTPLL1_POW_DIV_PLL_CLK: 1;
        uint32_t BTPLL_SEL_CK_EXT_FREF: 1;
        uint32_t BTPLL1_SEL_CKFREF: 1;
        uint32_t BTPLL1_SEL_DIVDN_XTAL: 2;
        uint32_t BTPLL1_SEL_DBG_SDM: 4;
        uint32_t BTPLL1_SEL_DIVN_SDM: 7;
    };
} AON_BT_ANAPAR_PLL2_TYPE;

/* 0xD08    0x4000_0d08
    15:0    R/W BTPLL1_SEL_SDM_F0F_LSB              16'h0000
    20:16   R/W BTPLL1_SEL_SDM_F0F_MSB              5'b00000
    23:21   R/W BTPLL1_SEL_SDM_F0N                  3'b000
    24      R/W BTPLL1_SEL_SDM_ORDER                1'b0
    25      R/W BTPLL1_EN_AGPIO                     1'b0
    26      R/W BTPLL1_SEL_AGPIO                    1'b0
    28:27   R/W BTPLL1_SEL_AGPIO_BUFFER             2'b00
    29      R/W BTPLL1_ANAPAR_PLL5_DUMMY1           1'b0
    30      R/W BTPLL1_EN_SDM_NF_CODE_SYNC          1'b0
    31      R/W BTPLL1_EN_SDM_NF_CODE_LOAD          1'b0
 */
typedef volatile union _AON_BT_ANAPAR_PLL4_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t BTPLL1_SEL_SDM_F0F_LSB: 16;
        uint32_t BTPLL1_SEL_SDM_F0F_MSB: 5;
        uint32_t BTPLL1_SEL_SDM_F0N: 3;
        uint32_t BTPLL1_SEL_SDM_ORDER: 1;
        uint32_t BTPLL1_EN_AGPIO: 1;
        uint32_t BTPLL1_SEL_AGPIO: 1;
        uint32_t BTPLL1_SEL_AGPIO_BUFFER: 2;
        uint32_t BTPLL1_ANAPAR_PLL5_DUMMY1: 1;
        uint32_t BTPLL1_EN_SDM_NF_CODE_SYNC: 1;
        uint32_t BTPLL1_EN_SDM_NF_CODE_LOAD: 1;
    };
} AON_BT_ANAPAR_PLL4_TYPE;

/* 0xD0C    0x4000_0d0c
    0       R/W BTPLL2_ANAPAR_PLL6_DUMMY3           1'b0
    1       R/W BTPLL2_POW_PLL                      1'b0
    4:2     R/W BTPLL2_SEL_CP_BIA                   3'b000
    5       R/W BTPLL2_ANAPAR_PLL6_DUMMY2           1'b0
    7:6     R/W BTPLL2_SEL_LDO1_VOUT                2'b01
    9:8     R/W BTPLL2_SEL_LPF_CP                   2'b10
    11:10   R/W BTPLL2_SEL_LPF_CS                   2'b10
    14:12   R/W BTPLL2_SEL_LPF_R3                   3'b010
    15      R/W BTPLL2_ANAPAR_PLL6_DUMMY1           1'b0
    18:16   R/W BTPLL2_SEL_LPF_RS                   3'b100
    19      R/W BTPLL2_EN_DOG_B                     1'b1
    21:20   R/W BTPLL2_VC_THL                       2'b00
    22      R/W BTPLL2_SEL_FREF_EDGE                1'b0
    31:23   R/W BTPLL2_ANAPAR_PLL7_DUMMY1           9'b0000000
 */
typedef volatile union _AON_BT_ANAPAR_PLL6_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t BTPLL2_ANAPAR_PLL6_DUMMY3: 1;
        uint32_t BTPLL2_POW_PLL: 1;
        uint32_t BTPLL2_SEL_CP_BIA: 3;
        uint32_t BTPLL2_ANAPAR_PLL6_DUMMY2: 1;
        uint32_t BTPLL2_SEL_LDO1_VOUT: 2;
        uint32_t BTPLL2_SEL_LPF_CP: 2;
        uint32_t BTPLL2_SEL_LPF_CS: 2;
        uint32_t BTPLL2_SEL_LPF_R3: 3;
        uint32_t BTPLL2_ANAPAR_PLL6_DUMMY1: 1;
        uint32_t BTPLL2_SEL_LPF_RS: 3;
        uint32_t BTPLL2_EN_DOG_B: 1;
        uint32_t BTPLL2_VC_THL: 2;
        uint32_t BTPLL2_SEL_FREF_EDGE: 1;
        uint32_t BTPLL2_ANAPAR_PLL7_DUMMY1: 9;
    };
} AON_BT_ANAPAR_PLL6_TYPE;

/* 0xD10    0x4000_0d10
    0       R/W BTPLL2_EN_PLL_CKO1                  1'b1
    1       R/W BTPLL2_SEL_DIV2_PLL_CKO1            1'b0
    2       R/W BTPLL2_SEL_PLL_CKO1                 1'b0
    3       R/W BTPLL2_ANAPAR_PLL8_DUMMY3           1'b0
    5:4     R/W BTPLL2_SEL_AGPIO_OUTPUT             2'b01
    12:6    R/W BTPLL2_ANAPAR_PLL8_DUMMY2           7'b0000000
    14:13   R/W BTPLL2_SEL_LPF_C3                   2'b10
    15      R/W BTPLL2_ANAPAR_PLL8_DUMMY1           1'b0
    16      R/W BTPLL2_POW_DIV_PLL_CLK              1'b0
    17      R/W BTPLL2_EN_MBIAS_LPF                 1'b1
    18      R/W BTPLL2_SEL_CKFREF                   1'b0
    20:19   R/W BTPLL2_SEL_DIVDN_XTAL               2'b00
    24:21   R/W BTPLL2_SEL_DBG_SDM                  4'b0000
    31:25   R/W BTPLL2_SEL_DIVN_SDM                 7'b0001110
 */
typedef volatile union _AON_BT_ANAPAR_PLL8_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t BTPLL2_EN_PLL_CKO1: 1;
        uint32_t BTPLL2_SEL_DIV2_PLL_CKO1: 1;
        uint32_t BTPLL2_SEL_PLL_CKO1: 1;
        uint32_t BTPLL2_ANAPAR_PLL8_DUMMY3: 1;
        uint32_t BTPLL2_SEL_AGPIO_OUTPUT: 2;
        uint32_t BTPLL2_ANAPAR_PLL8_DUMMY2: 7;
        uint32_t BTPLL2_SEL_LPF_C3: 2;
        uint32_t BTPLL2_ANAPAR_PLL8_DUMMY1: 1;
        uint32_t BTPLL2_POW_DIV_PLL_CLK: 1;
        uint32_t BTPLL2_EN_MBIAS_LPF: 1;
        uint32_t BTPLL2_SEL_CKFREF: 1;
        uint32_t BTPLL2_SEL_DIVDN_XTAL: 2;
        uint32_t BTPLL2_SEL_DBG_SDM: 4;
        uint32_t BTPLL2_SEL_DIVN_SDM: 7;
    };
} AON_BT_ANAPAR_PLL8_TYPE;

/* 0xD14    0x4000_0d14
    15:0    R/W BTPLL2_SEL_SDM_F0F_LSB              16'h0000
    20:16   R/W BTPLL2_SEL_SDM_F0F_MSB              5'b00000
    23:21   R/W BTPLL2_SEL_SDM_F0N                  3'b000
    24      R/W BTPLL2_SEL_SDM_ORDER                1'b0
    25      R/W BTPLL2_EN_AGPIO                     1'b0
    26      R/W BTPLL2_SEL_AGPIO                    1'b0
    28:27   R/W BTPLL2_SEL_AGPIO_BUFFER             2'b00
    29      R/W BTPLL2_ANAPAR_PLL11_DUMMY1          1'b0
    30      R/W BTPLL2_EN_SDM_NF_CODE_SYNC          1'b0
    31      R/W BTPLL2_EN_SDM_NF_CODE_LOAD          1'b0
 */
typedef volatile union _AON_BT_ANAPAR_PLL10_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t BTPLL2_SEL_SDM_F0F_LSB: 16;
        uint32_t BTPLL2_SEL_SDM_F0F_MSB: 5;
        uint32_t BTPLL2_SEL_SDM_F0N: 3;
        uint32_t BTPLL2_SEL_SDM_ORDER: 1;
        uint32_t BTPLL2_EN_AGPIO: 1;
        uint32_t BTPLL2_SEL_AGPIO: 1;
        uint32_t BTPLL2_SEL_AGPIO_BUFFER: 2;
        uint32_t BTPLL2_ANAPAR_PLL11_DUMMY1: 1;
        uint32_t BTPLL2_EN_SDM_NF_CODE_SYNC: 1;
        uint32_t BTPLL2_EN_SDM_NF_CODE_LOAD: 1;
    };
} AON_BT_ANAPAR_PLL10_TYPE;

/* 0xD18    0x4000_0d18
    0       R/W BTPLL3_DUMMY3                       1'b0
    1       R/W BTPLL3_POW_PLL                      1'b0
    4:2     R/W BTPLL3_SEL_CP_BIA                   3'b000
    7:5     R/W BTPLL3_ANAPAR_PLL12_DUMMY2          3'b0
    9:8     R/W BTPLL3_SEL_LPF_CP                   2'b10
    11:10   R/W BTPLL3_SEL_LPF_CS                   2'b10
    14:12   R/W BTPLL3_SEL_LPF_R3                   3'b010
    15      R/W BTPLL3_ANAPAR_PLL12_DUMMY1          1'b0
    18:16   R/W BTPLL3_SEL_LPF_RS                   3'b100
    19      R/W BTPLL3_EN_DOG_B                     1'b1
    21:20   R/W BTPLL3_VC_THL                       2'b00
    22      R/W BTPLL3_SEL_FREF_EDGE                1'b0
    31:23   R/W BTPLL3_ANAPAR_PLL13_DUMMY1          9'b0000000
 */
typedef volatile union _AON_BT_ANAPAR_PLL13_BT_ANAPAR_PLL12_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t BTPLL3_DUMMY3: 1;
        uint32_t BTPLL3_POW_PLL: 1;
        uint32_t BTPLL3_SEL_CP_BIA: 3;
        uint32_t BTPLL3_ANAPAR_PLL12_DUMMY2: 3;
        uint32_t BTPLL3_SEL_LPF_CP: 2;
        uint32_t BTPLL3_SEL_LPF_CS: 2;
        uint32_t BTPLL3_SEL_LPF_R3: 3;
        uint32_t BTPLL3_ANAPAR_PLL12_DUMMY1: 1;
        uint32_t BTPLL3_SEL_LPF_RS: 3;
        uint32_t BTPLL3_EN_DOG_B: 1;
        uint32_t BTPLL3_VC_THL: 2;
        uint32_t BTPLL3_SEL_FREF_EDGE: 1;
        uint32_t BTPLL3_ANAPAR_PLL13_DUMMY1: 9;
    };
} AON_BT_ANAPAR_PLL13_BT_ANAPAR_PLL12_TYPE;

/* 0xD1C    0x4000_0d1c
    0       R/W BTPLL3_EN_PLL_CKO1                  1'b1
    1       R/W BTPLL3_SEL_DIV2_PLL_CKO1            1'b0
    2       R/W BTPLL3_SEL_PLL_CKO1                 1'b0
    12:3    R/W BTPLL3_DUMMY2                       10'b0000000000
    14:13   R/W BTPLL3_SEL_LPF_C3                   2'b10
    15      R/W BTPLL3_ANAPAR_PLL14_DUMMY1          1'b0
    16      R/W BTPLL3_POW_DIV_PLL_CLK              1'b0
    17      R/W BTPLL3_EN_MBIAS_LPF                 1'b1
    18      R/W BTPLL3_SEL_CKFREF                   1'b0
    20:19   R/W BTPLL3_SEL_DIVDN_XTAL               2'b11
    24:21   R/W BTPLL3_ANAPAR_PLL15_DUMMY1          4'b0000
    31:25   R/W BTPLL3_SEL_DIVN_SDM                 7'b0000010
 */
typedef volatile union _AON_BT_ANAPAR_PLL14_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t BTPLL3_EN_PLL_CKO1: 1;
        uint32_t BTPLL3_SEL_DIV2_PLL_CKO1: 1;
        uint32_t BTPLL3_SEL_PLL_CKO1: 1;
        uint32_t BTPLL3_DUMMY2: 10;
        uint32_t BTPLL3_SEL_LPF_C3: 2;
        uint32_t BTPLL3_ANAPAR_PLL14_DUMMY1: 1;
        uint32_t BTPLL3_POW_DIV_PLL_CLK: 1;
        uint32_t BTPLL3_EN_MBIAS_LPF: 1;
        uint32_t BTPLL3_SEL_CKFREF: 1;
        uint32_t BTPLL3_SEL_DIVDN_XTAL: 2;
        uint32_t BTPLL3_ANAPAR_PLL15_DUMMY1: 4;
        uint32_t BTPLL3_SEL_DIVN_SDM: 7;
    };
} AON_BT_ANAPAR_PLL14_TYPE;

/* 0xD20    0x4000_0d20
    15:0    R/W BTPLL3_ANAPAR_PLL16_DUMMY1          16'h0000
    31:16   R/W BTPLL3_ANAPAR_PLL17_DUMMY1          16'h0000
 */
typedef volatile union _AON_BT_ANAPAR_PLL16_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t BTPLL3_ANAPAR_PLL16_DUMMY1: 16;
        uint32_t BTPLL3_ANAPAR_PLL17_DUMMY1: 16;
    };
} AON_BT_ANAPAR_PLL16_TYPE;

/* 0xD24    0x4000_0d24
    0       R/W BTPLL4_DUMMY3                       1'b0
    1       R/W BTPLL4_POW_PLL                      1'b0
    4:2     R/W BTPLL4_SEL_CP_BIA                   3'b000
    7:5     R/W BTPLL4_ANAPAR_PLL12_DUMMY2          3'b0
    9:8     R/W BTPLL4_SEL_LPF_CP                   2'b10
    11:10   R/W BTPLL4_SEL_LPF_CS                   2'b10
    14:12   R/W BTPLL4_SEL_LPF_R3                   3'b000
    15      R/W BTPLL4_ANAPAR_PLL18_DUMMY1          1'b0
    18:16   R/W BTPLL4_SEL_LPF_RS                   3'b100
    19      R/W BTPLL4_EN_DOG_B                     1'b1
    21:20   R/W BTPLL4_VC_THL                       2'b00
    22      R/W BTPLL4_SEL_FREF_EDGE                1'b0
    31:23   R/W BTPLL4_ANAPAR_PLL19_DUMMY1          9'b0000000
 */
typedef volatile union _AON_BT_ANAPAR_PLL18_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t BTPLL4_DUMMY3: 1;
        uint32_t BTPLL4_POW_PLL: 1;
        uint32_t BTPLL4_SEL_CP_BIA: 3;
        uint32_t BTPLL4_ANAPAR_PLL12_DUMMY2: 3;
        uint32_t BTPLL4_SEL_LPF_CP: 2;
        uint32_t BTPLL4_SEL_LPF_CS: 2;
        uint32_t BTPLL4_SEL_LPF_R3: 3;
        uint32_t BTPLL4_ANAPAR_PLL18_DUMMY1: 1;
        uint32_t BTPLL4_SEL_LPF_RS: 3;
        uint32_t BTPLL4_EN_DOG_B: 1;
        uint32_t BTPLL4_VC_THL: 2;
        uint32_t BTPLL4_SEL_FREF_EDGE: 1;
        uint32_t BTPLL4_ANAPAR_PLL19_DUMMY1: 9;
    };
} AON_BT_ANAPAR_PLL18_TYPE;

/* 0xD28    0x4000_0d28
    0       R/W BTPLL4_EN_PLL_CKO1                  1'b1
    1       R/W BTPLL4_SEL_DIV2_PLL_CKO1            1'b0
    2       R/W BTPLL4_SEL_PLL_CKO1                 1'b0
    12:3    R/W BTPLL4_DUMMY2                       10'b0000000000
    14:13   R/W BTPLL4_SEL_LPF_C3                   2'b10
    15      R/W BTPLL4_ANAPAR_PLL20_DUMMY1          1'b0
    16      R/W BTPLL4_POW_DIV_PLL_CLK              1'b0
    17      R/W BTPLL4_EN_MBIAS_LPF                 1'b1
    18      R/W BTPLL4_SEL_CKFREF                   1'b0
    20:19   R/W BTPLL4_SEL_DIVDN_XTAL               2'b00
    24:21   R/W BTPLL4_ANAPAR_PLL21_DUMMY1          4'b0000
    31:25   R/W BTPLL4_SEL_DIVN_SDM                 7'b0001000
 */
typedef volatile union _AON_BT_ANAPAR_PLL20_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t BTPLL4_EN_PLL_CKO1: 1;
        uint32_t BTPLL4_SEL_DIV2_PLL_CKO1: 1;
        uint32_t BTPLL4_SEL_PLL_CKO1: 1;
        uint32_t BTPLL4_DUMMY2: 10;
        uint32_t BTPLL4_SEL_LPF_C3: 2;
        uint32_t BTPLL4_ANAPAR_PLL20_DUMMY1: 1;
        uint32_t BTPLL4_POW_DIV_PLL_CLK: 1;
        uint32_t BTPLL4_EN_MBIAS_LPF: 1;
        uint32_t BTPLL4_SEL_CKFREF: 1;
        uint32_t BTPLL4_SEL_DIVDN_XTAL: 2;
        uint32_t BTPLL4_ANAPAR_PLL21_DUMMY1: 4;
        uint32_t BTPLL4_SEL_DIVN_SDM: 7;
    };
} AON_BT_ANAPAR_PLL20_TYPE;

/* 0xD2C    0x4000_0d2c
    15:0    R/W BTPLL4_ANAPAR_PLL22_DUMMY1          16'h0000
    31:16   R/W BTPLL4_ANAPAR_PLL23_DUMMY1          16'h0000
 */
typedef volatile union _AON_BT_ANAPAR_PLL22_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t BTPLL4_ANAPAR_PLL22_DUMMY1: 16;
        uint32_t BTPLL4_ANAPAR_PLL23_DUMMY1: 16;
    };
} AON_BT_ANAPAR_PLL22_TYPE;

/* 0xD30    0x4000_0d30
    0       R/W BTPLL_LDO1_EN_LDO_PC                1'b0
    1       R/W BTPLL_LDO1_DUMMY3                   1'b1
    2       R/W BTPLL_LDO1_POW_LDO                  1'b0
    3       R/W BTPLL_LDO1_EN_LDO_VPULSE            1'b0
    5:4     R/W BTPLL_LDO1_TUNE_LDO_VOUT            2'b10
    6       R/W BTPLL_LDO1_DUMMY2                   1'b0
    7       R/W BTPLL_LDO1_DOUBLE_LDO_OP_I          1'b0
    15:8    R/W BTPLL_LDO1_DUMMY1                   8'b00000000
    16      R/W BTPLL_LDO2_EN_LDO_PC                1'b0
    17      R/W BTPLL_LDO2_DUMMY3                   1'b1
    18      R/W BTPLL_LDO2_POW_LDO                  1'b0
    19      R/W BTPLL_LDO2_EN_LDO_VPULSE            1'b0
    21:20   R/W BTPLL_LDO2_TUNE_LDO_VOUT            2'b10
    22      R/W BTPLL_LDO2_DUMMY2                   1'b0
    23      R/W BTPLL_LDO2_DOUBLE_LDO_OP_I          1'b0
    31:24   R/W BTPLL_LDO2_DUMMY1                   8'b00000000
 */
typedef volatile union _AON_BT_ANAPAR_PLL_LDO1_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t BTPLL_LDO1_EN_LDO_PC: 1;
        uint32_t BTPLL_LDO1_DUMMY3: 1;
        uint32_t BTPLL_LDO1_POW_LDO: 1;
        uint32_t BTPLL_LDO1_EN_LDO_VPULSE: 1;
        uint32_t BTPLL_LDO1_TUNE_LDO_VOUT: 2;
        uint32_t BTPLL_LDO1_DUMMY2: 1;
        uint32_t BTPLL_LDO1_DOUBLE_LDO_OP_I: 1;
        uint32_t BTPLL_LDO1_DUMMY1: 8;
        uint32_t BTPLL_LDO2_EN_LDO_PC: 1;
        uint32_t BTPLL_LDO2_DUMMY3: 1;
        uint32_t BTPLL_LDO2_POW_LDO: 1;
        uint32_t BTPLL_LDO2_EN_LDO_VPULSE: 1;
        uint32_t BTPLL_LDO2_TUNE_LDO_VOUT: 2;
        uint32_t BTPLL_LDO2_DUMMY2: 1;
        uint32_t BTPLL_LDO2_DOUBLE_LDO_OP_I: 1;
        uint32_t BTPLL_LDO2_DUMMY1: 8;
    };
} AON_BT_ANAPAR_PLL_LDO1_TYPE;

/* 0x1800   0x4000_1800
    0       R/W RTC_CNT_START                   1'b0
    1       R/W RTC_CNT_RST                     1'b0
    2       R/W RTC_PRE_CNT_RST                 1'b0
    7:3     R/W RTC_CR0_DUMMY0                  5'b0
    8       R/W RTC_TICK_IE                     1'b0
    9       R/W RTC_CNT_OV_IE                   1'b0
    10      R/W RTC_PRECMP_IE                   1'b0
    11      R/W RTC_PRECMP_CMP3_IE              1'b0
    12      R/W RTC_CMP0GT_IE                   1'b0
    13      R/W RTC_CMP1GT_IE                   1'b0
    14      R/W RTC_CMP2GT_IE                   1'b0
    15      R/W RTC_CMP3GT_IE                   1'b0
    16      R/W RTC_CMP0_NV_IE                  1'b0
    17      R/W RTC_CMP1_NV_IE                  1'b0
    18      R/W RTC_CMP2_NV_IE                  1'b0
    19      R/W RTC_CMP3_NV_IE                  1'b0
    20      R/W RTC_CMP0_WK_IE                  1'b0
    21      R/W RTC_CMP1_WK_IE                  1'b0
    22      R/W RTC_CMP2_WK_IE                  1'b0
    23      R/W RTC_CMP3_WK_IE                  1'b0
    28:24   R/W RTC_CR0_DUMMY1                  5'b0
    29      R/W RTC_WK_IE                       1'b0
    30      R/W RTC_NV_IE                       1'b0
    31      R/W RTC_RST                         1'b0
 */
typedef volatile union _AON_NS_RTC_CR0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_CNT_START: 1;
        uint32_t RTC_CNT_RST: 1;
        uint32_t RTC_PRE_CNT_RST: 1;
        uint32_t RTC_CR0_DUMMY0: 5;
        uint32_t RTC_TICK_IE: 1;
        uint32_t RTC_CNT_OV_IE: 1;
        uint32_t RTC_PRECMP_IE: 1;
        uint32_t RTC_PRECMP_CMP3_IE: 1;
        uint32_t RTC_CMP0GT_IE: 1;
        uint32_t RTC_CMP1GT_IE: 1;
        uint32_t RTC_CMP2GT_IE: 1;
        uint32_t RTC_CMP3GT_IE: 1;
        uint32_t RTC_CMP0_NV_IE: 1;
        uint32_t RTC_CMP1_NV_IE: 1;
        uint32_t RTC_CMP2_NV_IE: 1;
        uint32_t RTC_CMP3_NV_IE: 1;
        uint32_t RTC_CMP0_WK_IE: 1;
        uint32_t RTC_CMP1_WK_IE: 1;
        uint32_t RTC_CMP2_WK_IE: 1;
        uint32_t RTC_CMP3_WK_IE: 1;
        uint32_t RTC_CR0_DUMMY1: 5;
        uint32_t RTC_WK_IE: 1;
        uint32_t RTC_NV_IE: 1;
        uint32_t RTC_RST: 1;
    };
} AON_NS_RTC_CR0_TYPE;

/* 0x1804   0x4000_1804
    0       R/WACRTC_TICK_CLR                    1'b0
    1       R/WACRTC_CNT_OV_CLR                  1'b0
    2       R/WACRTC_PRECMP_CLR                  1'b0
    3       R/WACRTC_PRECMP_CMP3_CLR             1'b0
    4       R/WACRTC_CMP0GT_CLR                  1'b0
    5       R/WACRTC_CMP1GT_CLR                  1'b0
    6       R/WACRTC_CMP2GT_CLR                  1'b0
    7       R/WACRTC_CMP3GT_CLR                  1'b0
    8       R/WACRTC_CMP0_NV_CLR                 1'b0
    9       R/WACRTC_CMP1_NV_CLR                 1'b0
    10      R/WACRTC_CMP2_NV_CLR                 1'b0
    11      R/WACRTC_CMP3_NV_CLR                 1'b0
    12      R/WACRTC_CMP0_WK_CLR                 1'b0
    13      R/WACRTC_CMP1_WK_CLR                 1'b0
    14      R/WACRTC_CMP2_WK_CLR                 1'b0
    15      R/WACRTC_CMP3_WK_CLR                 1'b0
    31:16   R/W RTC_INT_clear_DUMMY             16'b0
 */
typedef volatile union _AON_NS_RTC_INT_clear_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t rtc_tick_clr: 1;
        uint32_t rtc_cnt_ov_clr: 1;
        uint32_t rtc_precmp_clr: 1;
        uint32_t rtc_precmp_cmp3_clr: 1;
        uint32_t rtc_cmp0gt_clr: 1;
        uint32_t rtc_cmp1gt_clr: 1;
        uint32_t rtc_cmp2gt_clr: 1;
        uint32_t rtc_cmp3gt_clr: 1;
        uint32_t rtc_cmp0_nv_clr: 1;
        uint32_t rtc_cmp1_nv_clr: 1;
        uint32_t rtc_cmp2_nv_clr: 1;
        uint32_t rtc_cmp3_nv_clr: 1;
        uint32_t rtc_cmp0_wk_clr: 1;
        uint32_t rtc_cmp1_wk_clr: 1;
        uint32_t rtc_cmp2_wk_clr: 1;
        uint32_t rtc_cmp3_wk_clr: 1;
        uint32_t RTC_INT_clear_DUMMY: 16;
    };
} AON_NS_RTC_INT_clear_TYPE;

/* 0x1808   0x4000_1808
    0       R/W1CRTC_TICK_SR                     1'b0
    1       R/W1CRTC_CNT_OV_SR                   1'b0
    2       R/W1CRTC_PRECMP_SR                   1'b0
    3       R/W1CRTC_PRECMP_CMP3_SR              1'b0
    4       R/W1CRTC_CMP0GT_SR                   1'b0
    5       R/W1CRTC_CMP1GT_SR                   1'b0
    6       R/W1CRTC_CMP2GT_SR                   1'b0
    7       R/W1CRTC_CMP3GT_SR                   1'b0
    8       R/W1CRTC_CMP0_NV_SR                  1'b0
    9       R/W1CRTC_CMP1_NV_SR                  1'b0
    10      R/W1CRTC_CMP2_NV_SR                  1'b0
    11      R/W1CRTC_CMP3_NV_SR                  1'b0
    12      R/W1CRTC_CMP0_WK_SR                  1'b0
    13      R/W1CRTC_CMP1_WK_SR                  1'b0
    14      R/W1CRTC_CMP2_WK_SR                  1'b0
    15      R/W1CRTC_CMP3_WK_SR                  1'b0
    31:16   R/W RTC_INT_SR_DUMMY                16'b0
 */
typedef volatile union _AON_NS_RTC_INT_SR_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_TICK_SR: 1;
        uint32_t RTC_CNT_OV_SR: 1;
        uint32_t RTC_PRECMP_SR: 1;
        uint32_t RTC_PRECMP_CMP3_SR: 1;
        uint32_t RTC_CMP0GT_SR: 1;
        uint32_t RTC_CMP1GT_SR: 1;
        uint32_t RTC_CMP2GT_SR: 1;
        uint32_t RTC_CMP3GT_SR: 1;
        uint32_t RTC_CMP0_NV_SR: 1;
        uint32_t RTC_CMP1_NV_SR: 1;
        uint32_t RTC_CMP2_NV_SR: 1;
        uint32_t RTC_CMP3_NV_SR: 1;
        uint32_t RTC_CMP0_WK_SR: 1;
        uint32_t RTC_CMP1_WK_SR: 1;
        uint32_t RTC_CMP2_WK_SR: 1;
        uint32_t RTC_CMP3_WK_SR: 1;
        uint32_t RTC_INT_SR_DUMMY: 16;
    };
} AON_NS_RTC_INT_SR_TYPE;

/* 0x180C   0x4000_180c
    11:0    R/W RTC_PRESCALER                   12'b0
    31:12   R/W RTC_PRESCALER_DUMMY             20'b0
 */
typedef volatile union _AON_NS_RTC_PRESCALER0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PRESCALER: 12;
        uint32_t RTC_PRESCALER_DUMMY: 20;
    };
} AON_NS_RTC_PRESCALER0_TYPE;

/* 0x1810   0x4000_1810
    31:0    R/W RTC_CMP0                        32'b0
 */
typedef volatile union _AON_NS_RTC_COMP_0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_CMP0;
    };
} AON_NS_RTC_COMP_0_TYPE;

/* 0x1814   0x4000_1814
    31:0    R/W RTC_CMP1                        32'b0
 */
typedef volatile union _AON_NS_RTC_COMP_1_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_CMP1;
    };
} AON_NS_RTC_COMP_1_TYPE;

/* 0x1818   0x4000_1818
    31:0    R/W RTC_CMP2                        32'b0
 */
typedef volatile union _AON_NS_RTC_COMP_2_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_CMP2;
    };
} AON_NS_RTC_COMP_2_TYPE;

/* 0x181C   0x4000_181c
    31:0    R/W RTC_CMP3                        32'b0
 */
typedef volatile union _AON_NS_RTC_COMP_3_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_CMP3;
    };
} AON_NS_RTC_COMP_3_TYPE;

/* 0x1820   0x4000_1820
    31:0    R/W RTC_CMP0GT                      32'b0
 */
typedef volatile union _AON_NS_RTC_COMP0_GT_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_CMP0GT;
    };
} AON_NS_RTC_COMP0_GT_TYPE;

/* 0x1824   0x4000_1824
    31:0    R/W RTC_CMP1GT                      32'b0
 */
typedef volatile union _AON_NS_RTC_COMP1_GT_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_CMP1GT;
    };
} AON_NS_RTC_COMP1_GT_TYPE;

/* 0x1828   0x4000_1828
    31:0    R/W RTC_CMP2GT                      32'b0
 */
typedef volatile union _AON_NS_RTC_COMP2_GT_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_CMP2GT;
    };
} AON_NS_RTC_COMP2_GT_TYPE;

/* 0x182C   0x4000_182c
    31:0    R/W RTC_CMP3GT                      32'b0
 */
typedef volatile union _AON_NS_RTC_COMP3_GT_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_CMP3GT;
    };
} AON_NS_RTC_COMP3_GT_TYPE;

/* 0x1830   0x4000_1830
    31:0    R   RTC_CNT                         32'b0
 */
typedef volatile union _AON_NS_RTC_CNT0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_CNT;
    };
} AON_NS_RTC_CNT0_TYPE;

/* 0x1834   0x4000_1834
    11:0    R   RTC_PRESCALE_CNT                12'b0
    31:12   R/W RTC_PRESCALE_CNT_DUMMY          20'b0
 */
typedef volatile union _AON_NS_RTC_PRESCALE_CNT0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PRESCALE_CNT: 12;
        uint32_t RTC_PRESCALE_CNT_DUMMY: 20;
    };
} AON_NS_RTC_PRESCALE_CNT0_TYPE;

/* 0x1838   0x4000_1838
    11:0    R/W RTC_PRESCALE_CMP                12'b0
    31:12   R/W RTC_PRESCALE_CMP_DUMMY          20'b0
 */
typedef volatile union _AON_NS_RTC_PRESCALE_CMP0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_PRESCALE_CMP: 12;
        uint32_t RTC_PRESCALE_CMP_DUMMY: 20;
    };
} AON_NS_RTC_PRESCALE_CMP0_TYPE;

/* 0x183C   0x4000_183c
    31:0    R/W RTC_BACKUP                      32'b0
 */
typedef volatile union _AON_NS_RTC_BACKUP_REG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_BACKUP;
    };
} AON_NS_RTC_BACKUP_REG_TYPE;

/* 0x1840   0x4000_1840
    31:0    R   RTC_RTL_VERSION                 32'h2112180A
 */
typedef volatile union _AON_NS_RTC_RTL_VERSION0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t RTC_RTL_VERSION;
    };
} AON_NS_RTC_RTL_VERSION0_TYPE;

/* 0x1850   0x4000_1850
    7:0     R/W reg_lpcomp0_deb_cnt             8'b0
    10:8    R/W reg_lpcomp_deb_div              3'b0
    11      R/W reg_lpcomp0_deb_en              1'b0
    12      R/W reg_lpcomp0_hys_en              1'b0
    13      R/W reg_lpcomp0_single_output_en    1'b0
    14      R/W RSVD                            1'b0
    15      R/W RSVD                            1'b0
    16      R/W reg_lpcomp0_ie                  1'b0
    17      R/W reg_lpcomp0_src_int_en          1'b0
    18      R/W reg_lpcomp0_src_aon_int_en      1'b0
    19      R/W reg_lpcomp0_deb_sel             1'b0
    30:20   R/W LPC0_CR0_Dummy                  11'b0
    31      R/W LPC0_CR1_Dummy                  1'b0
 */
typedef volatile union _AON_NS_LPC0_CR0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_lpcomp0_deb_cnt: 8;
        uint32_t reg_lpcomp_deb_div: 3;
        uint32_t reg_lpcomp0_deb_en: 1;
        uint32_t reg_lpcomp0_hys_en: 1;
        uint32_t reg_lpcomp0_single_output_en: 1;
        uint32_t RSVD_1: 1;
        uint32_t RSVD: 1;
        uint32_t reg_lpcomp0_ie: 1;
        uint32_t reg_lpcomp0_src_int_en: 1;
        uint32_t reg_lpcomp0_src_aon_int_en: 1;
        uint32_t reg_lpcomp0_deb_sel: 1;
        uint32_t LPC0_CR0_Dummy: 11;
        uint32_t LPC0_CR1_Dummy: 1;
    };
} AON_NS_LPC0_CR0_TYPE;

/* 0x1854   0x4000_1854
    0       R   reg_lpcomp0_flag                1'b0
    1       R   reg_lpcomp0_out_aon_flag        1'b0
    31:2    R/W LPC0_SR_Dummy                   30'b0
 */
typedef volatile union _AON_NS_LPC0_SR_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_lpcomp0_flag: 1;
        uint32_t reg_lpcomp0_out_aon_flag: 1;
        uint32_t LPC0_SR_Dummy: 30;
    };
} AON_NS_LPC0_SR_TYPE;

/* 0x1858   0x4000_1858
    7:0     R/W reg_lpcomp1_deb_cnt             8'b0
    10:8    R/W reg_lpcomp1_deb_div_dummy       3'b0
    11      R/W reg_lpcomp1_deb_en              1'b0
    12      R/W reg_lpcomp1_hys_en              1'b0
    13      R/W reg_lpcomp1_single_output_en    1'b0
    14      R/W RSVD                            1'b0
    15      R/W RSVD                            1'b0
    16      R/W reg_lpcomp1_ie                  1'b0
    17      R/W reg_lpcomp1_src_int_en          1'b0
    18      R/W reg_lpcomp1_src_aon_int_en      1'b0
    19      R/W reg_lpcomp1_deb_sel             1'b0
    30:20   R/W LPC1_CR0_Dummy                  11'b0
    31      R/W LPC1_CR1_Dummy                  1'b0
 */
typedef volatile union _AON_NS_LPC1_CR0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_lpcomp1_deb_cnt: 8;
        uint32_t reg_lpcomp1_deb_div_dummy: 3;
        uint32_t reg_lpcomp1_deb_en: 1;
        uint32_t reg_lpcomp1_hys_en: 1;
        uint32_t reg_lpcomp1_single_output_en: 1;
        uint32_t RSVD_1: 1;
        uint32_t RSVD: 1;
        uint32_t reg_lpcomp1_ie: 1;
        uint32_t reg_lpcomp1_src_int_en: 1;
        uint32_t reg_lpcomp1_src_aon_int_en: 1;
        uint32_t reg_lpcomp1_deb_sel: 1;
        uint32_t LPC1_CR0_Dummy: 11;
        uint32_t LPC1_CR1_Dummy: 1;
    };
} AON_NS_LPC1_CR0_TYPE;

/* 0x185C   0x4000_185c
    0       R   reg_lpcomp1_flag                1'b0
    1       R   reg_lpcomp1_out_aon_flag        1'b0
    31:2    R/W LPC1_SR_Dummy                   30'b0
 */
typedef volatile union _AON_NS_LPC1_SR_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t reg_lpcomp1_flag: 1;
        uint32_t reg_lpcomp1_out_aon_flag: 1;
        uint32_t LPC1_SR_Dummy: 30;
    };
} AON_NS_LPC1_SR_TYPE;

/* 0x1900   0x4000_1900
    0       R/W PAD_ADC_SHDN[0]                 1'b1
    1       R/W AON_PAD_ADC_E[0]                1'b0
    2       R/W AON_PAD_ADC_O[0]                1'b0
    3       R/W PAD_ADC_E3[0]                   1'b0
    4       R/W PAD_ADC_E2[0]                   1'b0
    5       R/W PAD_ADC_PDPUC[0]                1'b0
    6       R/W AON_PAD_ADC_PU[0]               1'b0
    7       R/W AON_PAD_ADC_PU_EN[0]            1'b1
    8       R/W PAD_ADC_WKPOL[0]                1'b0
    9       R/W PAD_ADC_WKEN[0]                 1'b0
    10      R/W PAD_ADC_DEB[0]                  1'b0
    12:11   R/W PAD_ADC_AON_MUX[0]              2'b0
    13      R/W PAD_ADC_O_EN[0]                 1'b1
    14      R/W PAD_ADC_DUMMY0[0]               1'b0
    15      R/W PAD_ADC_DUMMY1[0]               1'b0
    16      R/W PAD_ADC_SHDN[1]                 1'b1
    17      R/W AON_PAD_ADC_E[1]                1'b0
    18      R/W AON_PAD_ADC_O[1]                1'b0
    19      R/W PAD_ADC_E3[1]                   1'b0
    20      R/W PAD_ADC_E2[1]                   1'b0
    21      R/W PAD_ADC_PDPUC[1]                1'b0
    22      R/W AON_PAD_ADC_PU[1]               1'b0
    23      R/W AON_PAD_ADC_PU_EN[1]            1'b1
    24      R/W PAD_ADC_WKPOL[1]                1'b0
    25      R/W PAD_ADC_WKEN[1]                 1'b0
    26      R/W PAD_ADC_DEB[1]                  1'b0
    28:27   R/W PAD_ADC_AON_MUX[1]              2'b0
    29      R/W PAD_ADC_O_EN[1]                 1'b1
    30      R/W PAD_ADC_DUMMY0[1]               1'b0
    31      R/W PAD_ADC_DUMMY1[1]               1'b0
 */
typedef volatile union _AON_NS_ADC_0_ADC_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_ADC_SHDN_0: 1;
        uint32_t AON_PAD_ADC_E_0: 1;
        uint32_t AON_PAD_ADC_O_0: 1;
        uint32_t PAD_ADC_E3_0: 1;
        uint32_t PAD_ADC_E2_0: 1;
        uint32_t PAD_ADC_PDPUC_0: 1;
        uint32_t AON_PAD_ADC_PU_0: 1;
        uint32_t AON_PAD_ADC_PU_EN_0: 1;
        uint32_t PAD_ADC_WKPOL_0: 1;
        uint32_t PAD_ADC_WKEN_0: 1;
        uint32_t PAD_ADC_DEB_0: 1;
        uint32_t PAD_ADC_AON_MUX_0: 2;
        uint32_t PAD_ADC_O_EN_0: 1;
        uint32_t PAD_ADC_DUMMY0_0: 1;
        uint32_t PAD_ADC_DUMMY1_0: 1;
        uint32_t PAD_ADC_SHDN_1: 1;
        uint32_t AON_PAD_ADC_E_1: 1;
        uint32_t AON_PAD_ADC_O_1: 1;
        uint32_t PAD_ADC_E3_1: 1;
        uint32_t PAD_ADC_E2_1: 1;
        uint32_t PAD_ADC_PDPUC_1: 1;
        uint32_t AON_PAD_ADC_PU_1: 1;
        uint32_t AON_PAD_ADC_PU_EN_1: 1;
        uint32_t PAD_ADC_WKPOL_1: 1;
        uint32_t PAD_ADC_WKEN_1: 1;
        uint32_t PAD_ADC_DEB_1: 1;
        uint32_t PAD_ADC_AON_MUX_1: 2;
        uint32_t PAD_ADC_O_EN_1: 1;
        uint32_t PAD_ADC_DUMMY0_1: 1;
        uint32_t PAD_ADC_DUMMY1_1: 1;
    };
} AON_NS_ADC_0_ADC_1_PAD_CFG_TYPE;

/* 0x1904   0x4000_1904
    0       R/W PAD_ADC_SHDN[2]                 1'b1
    1       R/W AON_PAD_ADC_E[2]                1'b0
    2       R/W AON_PAD_ADC_O[2]                1'b0
    3       R/W PAD_ADC_E3[2]                   1'b0
    4       R/W PAD_ADC_E2[2]                   1'b0
    5       R/W PAD_ADC_PDPUC[2]                1'b0
    6       R/W AON_PAD_ADC_PU[2]               1'b0
    7       R/W AON_PAD_ADC_PU_EN[2]            1'b1
    8       R/W PAD_ADC_WKPOL[2]                1'b0
    9       R/W PAD_ADC_WKEN[2]                 1'b0
    10      R/W PAD_ADC_DEB[2]                  1'b0
    12:11   R/W PAD_ADC_AON_MUX[2]              2'b0
    13      R/W PAD_ADC_O_EN[2]                 1'b1
    14      R/W PAD_ADC_DUMMY0[2]               1'b0
    15      R/W PAD_ADC_DUMMY1[2]               1'b0
    16      R/W PAD_ADC_SHDN[3]                 1'b1
    17      R/W AON_PAD_ADC_E[3]                1'b0
    18      R/W AON_PAD_ADC_O[3]                1'b0
    19      R/W PAD_ADC_E3[3]                   1'b0
    20      R/W PAD_ADC_E2[3]                   1'b0
    21      R/W PAD_ADC_PDPUC[3]                1'b0
    22      R/W AON_PAD_ADC_PU[3]               1'b0
    23      R/W AON_PAD_ADC_PU_EN[3]            1'b1
    24      R/W PAD_ADC_WKPOL[3]                1'b0
    25      R/W PAD_ADC_WKEN[3]                 1'b0
    26      R/W PAD_ADC_DEB[3]                  1'b0
    28:27   R/W PAD_ADC_AON_MUX[3]              2'b0
    29      R/W PAD_ADC_O_EN[3]                 1'b1
    30      R/W PAD_ADC_DUMMY0[3]               1'b0
    31      R/W PAD_ADC_DUMMY1[3]               1'b0
 */
typedef volatile union _AON_NS_ADC_2_ADC_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_ADC_SHDN_2: 1;
        uint32_t AON_PAD_ADC_E_2: 1;
        uint32_t AON_PAD_ADC_O_2: 1;
        uint32_t PAD_ADC_E3_2: 1;
        uint32_t PAD_ADC_E2_2: 1;
        uint32_t PAD_ADC_PDPUC_2: 1;
        uint32_t AON_PAD_ADC_PU_2: 1;
        uint32_t AON_PAD_ADC_PU_EN_2: 1;
        uint32_t PAD_ADC_WKPOL_2: 1;
        uint32_t PAD_ADC_WKEN_2: 1;
        uint32_t PAD_ADC_DEB_2: 1;
        uint32_t PAD_ADC_AON_MUX_2: 2;
        uint32_t PAD_ADC_O_EN_2: 1;
        uint32_t PAD_ADC_DUMMY0_2: 1;
        uint32_t PAD_ADC_DUMMY1_2: 1;
        uint32_t PAD_ADC_SHDN_3: 1;
        uint32_t AON_PAD_ADC_E_3: 1;
        uint32_t AON_PAD_ADC_O_3: 1;
        uint32_t PAD_ADC_E3_3: 1;
        uint32_t PAD_ADC_E2_3: 1;
        uint32_t PAD_ADC_PDPUC_3: 1;
        uint32_t AON_PAD_ADC_PU_3: 1;
        uint32_t AON_PAD_ADC_PU_EN_3: 1;
        uint32_t PAD_ADC_WKPOL_3: 1;
        uint32_t PAD_ADC_WKEN_3: 1;
        uint32_t PAD_ADC_DEB_3: 1;
        uint32_t PAD_ADC_AON_MUX_3: 2;
        uint32_t PAD_ADC_O_EN_3: 1;
        uint32_t PAD_ADC_DUMMY0_3: 1;
        uint32_t PAD_ADC_DUMMY1_3: 1;
    };
} AON_NS_ADC_2_ADC_3_PAD_CFG_TYPE;

/* 0x1908   0x4000_1908
    0       R/W PAD_ADC_SHDN[4]                 1'b1
    1       R/W AON_PAD_ADC_E[4]                1'b0
    2       R/W AON_PAD_ADC_O[4]                1'b0
    3       R/W PAD_ADC_E3[4]                   1'b0
    4       R/W PAD_ADC_E2[4]                   1'b0
    5       R/W PAD_ADC_PDPUC[4]                1'b0
    6       R/W AON_PAD_ADC_PU[4]               1'b0
    7       R/W AON_PAD_ADC_PU_EN[4]            1'b1
    8       R/W PAD_ADC_WKPOL[4]                1'b0
    9       R/W PAD_ADC_WKEN[4]                 1'b0
    10      R/W PAD_ADC_DEB[4]                  1'b0
    12:11   R/W PAD_ADC_AON_MUX[4]              2'b0
    13      R/W PAD_ADC_O_EN[4]                 1'b1
    14      R/W PAD_ADC_DUMMY0[4]               1'b0
    15      R/W PAD_ADC_DUMMY1[4]               1'b0
    16      R/W PAD_ADC_SHDN[5]                 1'b1
    17      R/W AON_PAD_ADC_E[5]                1'b0
    18      R/W AON_PAD_ADC_O[5]                1'b0
    19      R/W PAD_ADC_E3[5]                   1'b0
    20      R/W PAD_ADC_E2[5]                   1'b0
    21      R/W PAD_ADC_PDPUC[5]                1'b0
    22      R/W AON_PAD_ADC_PU[5]               1'b0
    23      R/W AON_PAD_ADC_PU_EN[5]            1'b1
    24      R/W PAD_ADC_WKPOL[5]                1'b0
    25      R/W PAD_ADC_WKEN[5]                 1'b0
    26      R/W PAD_ADC_DEB[5]                  1'b0
    28:27   R/W PAD_ADC_AON_MUX[5]              2'b0
    29      R/W PAD_ADC_O_EN[5]                 1'b1
    30      R/W PAD_ADC_DUMMY0[5]               1'b0
    31      R/W PAD_ADC_DUMMY1[5]               1'b0
 */
typedef volatile union _AON_NS_ADC_4_ADC_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_ADC_SHDN_4: 1;
        uint32_t AON_PAD_ADC_E_4: 1;
        uint32_t AON_PAD_ADC_O_4: 1;
        uint32_t PAD_ADC_E3_4: 1;
        uint32_t PAD_ADC_E2_4: 1;
        uint32_t PAD_ADC_PDPUC_4: 1;
        uint32_t AON_PAD_ADC_PU_4: 1;
        uint32_t AON_PAD_ADC_PU_EN_4: 1;
        uint32_t PAD_ADC_WKPOL_4: 1;
        uint32_t PAD_ADC_WKEN_4: 1;
        uint32_t PAD_ADC_DEB_4: 1;
        uint32_t PAD_ADC_AON_MUX_4: 2;
        uint32_t PAD_ADC_O_EN_4: 1;
        uint32_t PAD_ADC_DUMMY0_4: 1;
        uint32_t PAD_ADC_DUMMY1_4: 1;
        uint32_t PAD_ADC_SHDN_5: 1;
        uint32_t AON_PAD_ADC_E_5: 1;
        uint32_t AON_PAD_ADC_O_5: 1;
        uint32_t PAD_ADC_E3_5: 1;
        uint32_t PAD_ADC_E2_5: 1;
        uint32_t PAD_ADC_PDPUC_5: 1;
        uint32_t AON_PAD_ADC_PU_5: 1;
        uint32_t AON_PAD_ADC_PU_EN_5: 1;
        uint32_t PAD_ADC_WKPOL_5: 1;
        uint32_t PAD_ADC_WKEN_5: 1;
        uint32_t PAD_ADC_DEB_5: 1;
        uint32_t PAD_ADC_AON_MUX_5: 2;
        uint32_t PAD_ADC_O_EN_5: 1;
        uint32_t PAD_ADC_DUMMY0_5: 1;
        uint32_t PAD_ADC_DUMMY1_5: 1;
    };
} AON_NS_ADC_4_ADC_5_PAD_CFG_TYPE;

/* 0x190C   0x4000_190c
    0       R/W PAD_ADC_SHDN[6]                 1'b1
    1       R/W AON_PAD_ADC_E[6]                1'b0
    2       R/W AON_PAD_ADC_O[6]                1'b0
    3       R/W PAD_ADC_E3[6]                   1'b0
    4       R/W PAD_ADC_E2[6]                   1'b0
    5       R/W PAD_ADC_PDPUC[6]                1'b0
    6       R/W AON_PAD_ADC_PU[6]               1'b0
    7       R/W AON_PAD_ADC_PU_EN[6]            1'b1
    8       R/W PAD_ADC_WKPOL[6]                1'b0
    9       R/W PAD_ADC_WKEN[6]                 1'b0
    10      R/W PAD_ADC_DEB[6]                  1'b0
    12:11   R/W PAD_ADC_AON_MUX[6]              2'b0
    13      R/W PAD_ADC_O_EN[6]                 1'b1
    14      R/W PAD_ADC_DUMMY0[6]               1'b0
    15      R/W PAD_ADC_DUMMY1[6]               1'b0
    16      R/W PAD_ADC_SHDN[7]                 1'b1
    17      R/W AON_PAD_ADC_E[7]                1'b0
    18      R/W AON_PAD_ADC_O[7]                1'b0
    19      R/W PAD_ADC_E3[7]                   1'b0
    20      R/W PAD_ADC_E2[7]                   1'b0
    21      R/W PAD_ADC_PDPUC[7]                1'b0
    22      R/W AON_PAD_ADC_PU[7]               1'b0
    23      R/W AON_PAD_ADC_PU_EN[7]            1'b1
    24      R/W PAD_ADC_WKPOL[7]                1'b0
    25      R/W PAD_ADC_WKEN[7]                 1'b0
    26      R/W PAD_ADC_DEB[7]                  1'b0
    28:27   R/W PAD_ADC_AON_MUX[7]              2'b0
    29      R/W PAD_ADC_O_EN[7]                 1'b1
    30      R/W PAD_ADC_DUMMY0[7]               1'b0
    31      R/W PAD_ADC_DUMMY1[7]               1'b0
 */
typedef volatile union _AON_NS_ADC_6_ADC_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_ADC_SHDN_6: 1;
        uint32_t AON_PAD_ADC_E_6: 1;
        uint32_t AON_PAD_ADC_O_6: 1;
        uint32_t PAD_ADC_E3_6: 1;
        uint32_t PAD_ADC_E2_6: 1;
        uint32_t PAD_ADC_PDPUC_6: 1;
        uint32_t AON_PAD_ADC_PU_6: 1;
        uint32_t AON_PAD_ADC_PU_EN_6: 1;
        uint32_t PAD_ADC_WKPOL_6: 1;
        uint32_t PAD_ADC_WKEN_6: 1;
        uint32_t PAD_ADC_DEB_6: 1;
        uint32_t PAD_ADC_AON_MUX_6: 2;
        uint32_t PAD_ADC_O_EN_6: 1;
        uint32_t PAD_ADC_DUMMY0_6: 1;
        uint32_t PAD_ADC_DUMMY1_6: 1;
        uint32_t PAD_ADC_SHDN_7: 1;
        uint32_t AON_PAD_ADC_E_7: 1;
        uint32_t AON_PAD_ADC_O_7: 1;
        uint32_t PAD_ADC_E3_7: 1;
        uint32_t PAD_ADC_E2_7: 1;
        uint32_t PAD_ADC_PDPUC_7: 1;
        uint32_t AON_PAD_ADC_PU_7: 1;
        uint32_t AON_PAD_ADC_PU_EN_7: 1;
        uint32_t PAD_ADC_WKPOL_7: 1;
        uint32_t PAD_ADC_WKEN_7: 1;
        uint32_t PAD_ADC_DEB_7: 1;
        uint32_t PAD_ADC_AON_MUX_7: 2;
        uint32_t PAD_ADC_O_EN_7: 1;
        uint32_t PAD_ADC_DUMMY0_7: 1;
        uint32_t PAD_ADC_DUMMY1_7: 1;
    };
} AON_NS_ADC_6_ADC_7_PAD_CFG_TYPE;

/* 0x1910   0x4000_1910
    0       R/W PAD_P1_SHDN[0]                  1'b1
    1       R/W AON_PAD_P1_E[0]                 1'b0
    2       R/W AON_PAD_P1_O[0]                 1'b0
    3       R/W PAD_P1_E3[0]                    1'b0
    4       R/W PAD_P1_E2[0]                    1'b0
    5       R/W PAD_P1_PDPUC[0]                 1'b0
    6       R/W AON_PAD_P1_PU[0]                1'b0
    7       R/W AON_PAD_P1_PU_EN[0]             1'b1
    8       R/W PAD_P1_WKPOL[0]                 1'b0
    9       R/W PAD_P1_WKEN[0]                  1'b0
    10      R/W PAD_P1_DEB[0]                   1'b0
    12:11   R/W PAD_P1_AON_MUX[0]               2'b0
    13      R/W PAD_P1_O_EN[0]                  1'b1
    14      R/W PAD_P1_DUMMY0[0]                1'b0
    15      R/W PAD_P1_DUMMY1[0]                1'b0
    16      R/W PAD_P1_SHDN[1]                  1'b1
    17      R/W AON_PAD_P1_E[1]                 1'b0
    18      R/W AON_PAD_P1_O[1]                 1'b0
    19      R/W PAD_P1_E3[1]                    1'b0
    20      R/W PAD_P1_E2[1]                    1'b0
    21      R/W PAD_P1_PDPUC[1]                 1'b0
    22      R/W AON_PAD_P1_PU[1]                1'b0
    23      R/W AON_PAD_P1_PU_EN[1]             1'b1
    24      R/W PAD_P1_WKPOL[1]                 1'b0
    25      R/W PAD_P1_WKEN[1]                  1'b0
    26      R/W PAD_P1_DEB[1]                   1'b0
    28:27   R/W PAD_P1_AON_MUX[1]               2'b0
    29      R/W PAD_P1_O_EN[1]                  1'b1
    30      R/W PAD_P1_DUMMY0[1]                1'b0
    31      R/W PAD_P1_DUMMY1[1]                1'b0
 */
typedef volatile union _AON_NS_P1_0_P1_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P1_SHDN_0: 1;
        uint32_t AON_PAD_P1_E_0: 1;
        uint32_t AON_PAD_P1_O_0: 1;
        uint32_t PAD_P1_E3_0: 1;
        uint32_t PAD_P1_E2_0: 1;
        uint32_t PAD_P1_PDPUC_0: 1;
        uint32_t AON_PAD_P1_PU_0: 1;
        uint32_t AON_PAD_P1_PU_EN_0: 1;
        uint32_t PAD_P1_WKPOL_0: 1;
        uint32_t PAD_P1_WKEN_0: 1;
        uint32_t PAD_P1_DEB_0: 1;
        uint32_t PAD_P1_AON_MUX_0: 2;
        uint32_t PAD_P1_O_EN_0: 1;
        uint32_t PAD_P1_DUMMY0_0: 1;
        uint32_t PAD_P1_DUMMY1_0: 1;
        uint32_t PAD_P1_SHDN_1: 1;
        uint32_t AON_PAD_P1_E_1: 1;
        uint32_t AON_PAD_P1_O_1: 1;
        uint32_t PAD_P1_E3_1: 1;
        uint32_t PAD_P1_E2_1: 1;
        uint32_t PAD_P1_PDPUC_1: 1;
        uint32_t AON_PAD_P1_PU_1: 1;
        uint32_t AON_PAD_P1_PU_EN_1: 1;
        uint32_t PAD_P1_WKPOL_1: 1;
        uint32_t PAD_P1_WKEN_1: 1;
        uint32_t PAD_P1_DEB_1: 1;
        uint32_t PAD_P1_AON_MUX_1: 2;
        uint32_t PAD_P1_O_EN_1: 1;
        uint32_t PAD_P1_DUMMY0_1: 1;
        uint32_t PAD_P1_DUMMY1_1: 1;
    };
} AON_NS_P1_0_P1_1_PAD_CFG_TYPE;

/* 0x1914   0x4000_1914
    0       R/W PAD_P1_SHDN[2]                  1'b1
    1       R/W AON_PAD_P1_E[2]                 1'b0
    2       R/W AON_PAD_P1_O[2]                 1'b0
    3       R/W PAD_P1_E3[2]                    1'b0
    4       R/W PAD_P1_E2[2]                    1'b0
    5       R/W PAD_P1_PDPUC[2]                 1'b0
    6       R/W AON_PAD_P1_PU[2]                1'b0
    7       R/W AON_PAD_P1_PU_EN[2]             1'b1
    8       R/W PAD_P1_WKPOL[2]                 1'b0
    9       R/W PAD_P1_WKEN[2]                  1'b0
    10      R/W PAD_P1_DEB[2]                   1'b0
    12:11   R/W PAD_P1_AON_MUX[2]               2'b0
    13      R/W PAD_P1_O_EN[2]                  1'b1
    14      R/W PAD_P1_DUMMY0[2]                1'b0
    15      R/W PAD_P1_DUMMY1[2]                1'b0
    16      R/W PAD_P1_SHDN[3]                  1'b1
    17      R/W AON_PAD_P1_E[3]                 1'b0
    18      R/W AON_PAD_P1_O[3]                 1'b0
    19      R/W PAD_P1_E3[3]                    1'b0
    20      R/W PAD_P1_E2[3]                    1'b0
    21      R/W PAD_P1_PDPUC[3]                 1'b0
    22      R/W AON_PAD_P1_PU[3]                1'b0
    23      R/W AON_PAD_P1_PU_EN[3]             1'b1
    24      R/W PAD_P1_WKPOL[3]                 1'b0
    25      R/W PAD_P1_WKEN[3]                  1'b0
    26      R/W PAD_P1_DEB[3]                   1'b0
    28:27   R/W PAD_P1_AON_MUX[3]               2'b0
    29      R/W PAD_P1_O_EN[3]                  1'b1
    30      R/W PAD_P1_DUMMY0[3]                1'b0
    31      R/W PAD_P1_DUMMY1[3]                1'b0
 */
typedef volatile union _AON_NS_P1_2_P1_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P1_SHDN_2: 1;
        uint32_t AON_PAD_P1_E_2: 1;
        uint32_t AON_PAD_P1_O_2: 1;
        uint32_t PAD_P1_E3_2: 1;
        uint32_t PAD_P1_E2_2: 1;
        uint32_t PAD_P1_PDPUC_2: 1;
        uint32_t AON_PAD_P1_PU_2: 1;
        uint32_t AON_PAD_P1_PU_EN_2: 1;
        uint32_t PAD_P1_WKPOL_2: 1;
        uint32_t PAD_P1_WKEN_2: 1;
        uint32_t PAD_P1_DEB_2: 1;
        uint32_t PAD_P1_AON_MUX_2: 2;
        uint32_t PAD_P1_O_EN_2: 1;
        uint32_t PAD_P1_DUMMY0_2: 1;
        uint32_t PAD_P1_DUMMY1_2: 1;
        uint32_t PAD_P1_SHDN_3: 1;
        uint32_t AON_PAD_P1_E_3: 1;
        uint32_t AON_PAD_P1_O_3: 1;
        uint32_t PAD_P1_E3_3: 1;
        uint32_t PAD_P1_E2_3: 1;
        uint32_t PAD_P1_PDPUC_3: 1;
        uint32_t AON_PAD_P1_PU_3: 1;
        uint32_t AON_PAD_P1_PU_EN_3: 1;
        uint32_t PAD_P1_WKPOL_3: 1;
        uint32_t PAD_P1_WKEN_3: 1;
        uint32_t PAD_P1_DEB_3: 1;
        uint32_t PAD_P1_AON_MUX_3: 2;
        uint32_t PAD_P1_O_EN_3: 1;
        uint32_t PAD_P1_DUMMY0_3: 1;
        uint32_t PAD_P1_DUMMY1_3: 1;
    };
} AON_NS_P1_2_P1_3_PAD_CFG_TYPE;

/* 0x1918   0x4000_1918
    0       R/W PAD_P1_SHDN[4]                  1'b1
    1       R/W AON_PAD_P1_E[4]                 1'b0
    2       R/W AON_PAD_P1_O[4]                 1'b0
    3       R/W PAD_P1_E3[4]                    1'b0
    4       R/W PAD_P1_E2[4]                    1'b0
    5       R/W PAD_P1_PDPUC[4]                 1'b0
    6       R/W AON_PAD_P1_PU[4]                1'b0
    7       R/W AON_PAD_P1_PU_EN[4]             1'b1
    8       R/W PAD_P1_WKPOL[4]                 1'b0
    9       R/W PAD_P1_WKEN[4]                  1'b0
    10      R/W PAD_P1_DEB[4]                   1'b0
    12:11   R/W PAD_P1_AON_MUX[4]               2'b0
    13      R/W PAD_P1_O_EN[4]                  1'b1
    14      R/W PAD_P1_DUMMY0[4]                1'b0
    15      R/W PAD_P1_DUMMY1[4]                1'b0
    16      R/W PAD_P1_SHDN[5]                  1'b1
    17      R/W AON_PAD_P1_E[5]                 1'b0
    18      R/W AON_PAD_P1_O[5]                 1'b0
    19      R/W PAD_P1_E3[5]                    1'b0
    20      R/W PAD_P1_E2[5]                    1'b0
    21      R/W PAD_P1_PDPUC[5]                 1'b0
    22      R/W AON_PAD_P1_PU[5]                1'b0
    23      R/W AON_PAD_P1_PU_EN[5]             1'b1
    24      R/W PAD_P1_WKPOL[5]                 1'b0
    25      R/W PAD_P1_WKEN[5]                  1'b0
    26      R/W PAD_P1_DEB[5]                   1'b0
    28:27   R/W PAD_P1_AON_MUX[5]               2'b0
    29      R/W PAD_P1_O_EN[5]                  1'b1
    30      R/W PAD_P1_DUMMY0[5]                1'b0
    31      R/W PAD_P1_DUMMY1[5]                1'b0
 */
typedef volatile union _AON_NS_P1_4_P1_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P1_SHDN_4: 1;
        uint32_t AON_PAD_P1_E_4: 1;
        uint32_t AON_PAD_P1_O_4: 1;
        uint32_t PAD_P1_E3_4: 1;
        uint32_t PAD_P1_E2_4: 1;
        uint32_t PAD_P1_PDPUC_4: 1;
        uint32_t AON_PAD_P1_PU_4: 1;
        uint32_t AON_PAD_P1_PU_EN_4: 1;
        uint32_t PAD_P1_WKPOL_4: 1;
        uint32_t PAD_P1_WKEN_4: 1;
        uint32_t PAD_P1_DEB_4: 1;
        uint32_t PAD_P1_AON_MUX_4: 2;
        uint32_t PAD_P1_O_EN_4: 1;
        uint32_t PAD_P1_DUMMY0_4: 1;
        uint32_t PAD_P1_DUMMY1_4: 1;
        uint32_t PAD_P1_SHDN_5: 1;
        uint32_t AON_PAD_P1_E_5: 1;
        uint32_t AON_PAD_P1_O_5: 1;
        uint32_t PAD_P1_E3_5: 1;
        uint32_t PAD_P1_E2_5: 1;
        uint32_t PAD_P1_PDPUC_5: 1;
        uint32_t AON_PAD_P1_PU_5: 1;
        uint32_t AON_PAD_P1_PU_EN_5: 1;
        uint32_t PAD_P1_WKPOL_5: 1;
        uint32_t PAD_P1_WKEN_5: 1;
        uint32_t PAD_P1_DEB_5: 1;
        uint32_t PAD_P1_AON_MUX_5: 2;
        uint32_t PAD_P1_O_EN_5: 1;
        uint32_t PAD_P1_DUMMY0_5: 1;
        uint32_t PAD_P1_DUMMY1_5: 1;
    };
} AON_NS_P1_4_P1_5_PAD_CFG_TYPE;

/* 0x191C   0x4000_191c
    0       R/W PAD_P1_SHDN[6]                  1'b1
    1       R/W AON_PAD_P1_E[6]                 1'b0
    2       R/W AON_PAD_P1_O[6]                 1'b0
    3       R/W PAD_P1_E3[6]                    1'b0
    4       R/W PAD_P1_E2[6]                    1'b0
    5       R/W PAD_P1_PDPUC[6]                 1'b0
    6       R/W AON_PAD_P1_PU[6]                1'b0
    7       R/W AON_PAD_P1_PU_EN[6]             1'b1
    8       R/W PAD_P1_WKPOL[6]                 1'b0
    9       R/W PAD_P1_WKEN[6]                  1'b0
    10      R/W PAD_P1_DEB[6]                   1'b0
    12:11   R/W PAD_P1_AON_MUX[6]               2'b0
    13      R/W PAD_P1_O_EN[6]                  1'b1
    14      R/W PAD_P1_DUMMY0[6]                1'b0
    15      R/W PAD_P1_DUMMY1[6]                1'b0
    16      R/W PAD_P1_SHDN[7]                  1'b1
    17      R/W AON_PAD_P1_E[7]                 1'b0
    18      R/W AON_PAD_P1_O[7]                 1'b0
    19      R/W PAD_P1_E3[7]                    1'b0
    20      R/W PAD_P1_E2[7]                    1'b0
    21      R/W PAD_P1_PDPUC[7]                 1'b0
    22      R/W AON_PAD_P1_PU[7]                1'b0
    23      R/W AON_PAD_P1_PU_EN[7]             1'b1
    24      R/W PAD_P1_WKPOL[7]                 1'b0
    25      R/W PAD_P1_WKEN[7]                  1'b0
    26      R/W PAD_P1_DEB[7]                   1'b0
    28:27   R/W PAD_P1_AON_MUX[7]               2'b0
    29      R/W PAD_P1_O_EN[7]                  1'b1
    30      R/W PAD_P1_DUMMY0[7]                1'b0
    31      R/W PAD_P1_DUMMY1[7]                1'b0
 */
typedef volatile union _AON_NS_P1_6_P1_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P1_SHDN_6: 1;
        uint32_t AON_PAD_P1_E_6: 1;
        uint32_t AON_PAD_P1_O_6: 1;
        uint32_t PAD_P1_E3_6: 1;
        uint32_t PAD_P1_E2_6: 1;
        uint32_t PAD_P1_PDPUC_6: 1;
        uint32_t AON_PAD_P1_PU_6: 1;
        uint32_t AON_PAD_P1_PU_EN_6: 1;
        uint32_t PAD_P1_WKPOL_6: 1;
        uint32_t PAD_P1_WKEN_6: 1;
        uint32_t PAD_P1_DEB_6: 1;
        uint32_t PAD_P1_AON_MUX_6: 2;
        uint32_t PAD_P1_O_EN_6: 1;
        uint32_t PAD_P1_DUMMY0_6: 1;
        uint32_t PAD_P1_DUMMY1_6: 1;
        uint32_t PAD_P1_SHDN_7: 1;
        uint32_t AON_PAD_P1_E_7: 1;
        uint32_t AON_PAD_P1_O_7: 1;
        uint32_t PAD_P1_E3_7: 1;
        uint32_t PAD_P1_E2_7: 1;
        uint32_t PAD_P1_PDPUC_7: 1;
        uint32_t AON_PAD_P1_PU_7: 1;
        uint32_t AON_PAD_P1_PU_EN_7: 1;
        uint32_t PAD_P1_WKPOL_7: 1;
        uint32_t PAD_P1_WKEN_7: 1;
        uint32_t PAD_P1_DEB_7: 1;
        uint32_t PAD_P1_AON_MUX_7: 2;
        uint32_t PAD_P1_O_EN_7: 1;
        uint32_t PAD_P1_DUMMY0_7: 1;
        uint32_t PAD_P1_DUMMY1_7: 1;
    };
} AON_NS_P1_6_P1_7_PAD_CFG_TYPE;

/* 0x1920   0x4000_1920
    0       R/W PAD_P2_SHDN[0]                  1'b1
    1       R/W AON_PAD_P2_E[0]                 1'b0
    2       R/W AON_PAD_P2_O[0]                 1'b0
    3       R/W PAD_P2_E3[0]                    1'b0
    4       R/W PAD_P2_E2[0]                    1'b0
    5       R/W PAD_P2_PDPUC[0]                 1'b0
    6       R/W AON_PAD_P2_PU[0]                1'b1
    7       R/W AON_PAD_P2_PU_EN[0]             1'b1
    8       R/W PAD_P2_WKPOL[0]                 1'b0
    9       R/W PAD_P2_WKEN[0]                  1'b0
    10      R/W PAD_P2_DEB[0]                   1'b0
    12:11   R/W PAD_P2_AON_MUX[0]               2'b0
    13      R/W PAD_P2_O_EN[0]                  1'b1
    14      R   PAD_P2_0_I                      1'b1
    15      R/W PAD_P2_DUMMY1[0]                1'b0
    16      R/W PAD_P2_SHDN[1]                  1'b1
    17      R/W AON_PAD_P2_E[1]                 1'b0
    18      R/W AON_PAD_P2_O[1]                 1'b0
    19      R/W PAD_P2_E3[1]                    1'b0
    20      R/W PAD_P2_E2[1]                    1'b0
    21      R/W PAD_P2_PDPUC[1]                 1'b0
    22      R/W AON_PAD_P2_PU[1]                1'b1
    23      R/W AON_PAD_P2_PU_EN[1]             1'b1
    24      R/W PAD_P2_WKPOL[1]                 1'b0
    25      R/W PAD_P2_WKEN[1]                  1'b0
    26      R/W PAD_P2_DEB[1]                   1'b0
    28:27   R/W PAD_P2_AON_MUX[1]               2'b0
    29      R/W PAD_P2_O_EN[1]                  1'b1
    30      R/W PAD_P2_DUMMY0[1]                1'b0
    31      R/W PAD_P2_DUMMY1[1]                1'b0
 */
typedef volatile union _AON_NS_P2_0_P2_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P2_SHDN_0: 1;
        uint32_t AON_PAD_P2_E_0: 1;
        uint32_t AON_PAD_P2_O_0: 1;
        uint32_t PAD_P2_E3_0: 1;
        uint32_t PAD_P2_E2_0: 1;
        uint32_t PAD_P2_PDPUC_0: 1;
        uint32_t AON_PAD_P2_PU_0: 1;
        uint32_t AON_PAD_P2_PU_EN_0: 1;
        uint32_t PAD_P2_WKPOL_0: 1;
        uint32_t PAD_P2_WKEN_0: 1;
        uint32_t PAD_P2_DEB_0: 1;
        uint32_t PAD_P2_AON_MUX_0: 2;
        uint32_t PAD_P2_O_EN_0: 1;
        uint32_t PAD_P2_0_I: 1;
        uint32_t PAD_P2_DUMMY1_0: 1;
        uint32_t PAD_P2_SHDN_1: 1;
        uint32_t AON_PAD_P2_E_1: 1;
        uint32_t AON_PAD_P2_O_1: 1;
        uint32_t PAD_P2_E3_1: 1;
        uint32_t PAD_P2_E2_1: 1;
        uint32_t PAD_P2_PDPUC_1: 1;
        uint32_t AON_PAD_P2_PU_1: 1;
        uint32_t AON_PAD_P2_PU_EN_1: 1;
        uint32_t PAD_P2_WKPOL_1: 1;
        uint32_t PAD_P2_WKEN_1: 1;
        uint32_t PAD_P2_DEB_1: 1;
        uint32_t PAD_P2_AON_MUX_1: 2;
        uint32_t PAD_P2_O_EN_1: 1;
        uint32_t PAD_P2_DUMMY0_1: 1;
        uint32_t PAD_P2_DUMMY1_1: 1;
    };
} AON_NS_P2_0_P2_1_PAD_CFG_TYPE;

/* 0x1924   0x4000_1924
    0       R/W PAD_P2_SHDN[2]                  1'b1
    1       R/W AON_PAD_P2_E[2]                 1'b0
    2       R/W AON_PAD_P2_O[2]                 1'b0
    3       R/W PAD_P2_E3[2]                    1'b0
    4       R/W PAD_P2_E2[2]                    1'b0
    5       R/W PAD_P2_PDPUC[2]                 1'b0
    6       R/W AON_PAD_P2_PU[2]                1'b1
    7       R/W AON_PAD_P2_PU_EN[2]             1'b1
    8       R/W PAD_P2_WKPOL[2]                 1'b0
    9       R/W PAD_P2_WKEN[2]                  1'b0
    10      R/W PAD_P2_DEB[2]                   1'b0
    12:11   R/W PAD_P2_AON_MUX[2]               2'b0
    13      R/W PAD_P2_O_EN[2]                  1'b1
    14      R/W PAD_P2_DUMMY0[2]                1'b0
    15      R/W PAD_P2_DUMMY1[2]                1'b0
    16      R/W PAD_P2_SHDN[3]                  1'b1
    17      R/W AON_PAD_P2_E[3]                 1'b0
    18      R/W AON_PAD_P2_O[3]                 1'b0
    19      R/W PAD_P2_E3[3]                    1'b0
    20      R/W PAD_P2_E2[3]                    1'b0
    21      R/W PAD_P2_PDPUC[3]                 1'b0
    22      R/W AON_PAD_P2_PU[3]                1'b1
    23      R/W AON_PAD_P2_PU_EN[3]             1'b1
    24      R/W PAD_P2_WKPOL[3]                 1'b0
    25      R/W PAD_P2_WKEN[3]                  1'b0
    26      R/W PAD_P2_DEB[3]                   1'b0
    28:27   R/W PAD_P2_AON_MUX[3]               2'b0
    29      R/W PAD_P2_O_EN[3]                  1'b1
    30      R/W PAD_P2_DUMMY0[3]                1'b0
    31      R/W PAD_P2_DUMMY1[3]                1'b0
 */
typedef volatile union _AON_NS_P2_2_P2_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P2_SHDN_2: 1;
        uint32_t AON_PAD_P2_E_2: 1;
        uint32_t AON_PAD_P2_O_2: 1;
        uint32_t PAD_P2_E3_2: 1;
        uint32_t PAD_P2_E2_2: 1;
        uint32_t PAD_P2_PDPUC_2: 1;
        uint32_t AON_PAD_P2_PU_2: 1;
        uint32_t AON_PAD_P2_PU_EN_2: 1;
        uint32_t PAD_P2_WKPOL_2: 1;
        uint32_t PAD_P2_WKEN_2: 1;
        uint32_t PAD_P2_DEB_2: 1;
        uint32_t PAD_P2_AON_MUX_2: 2;
        uint32_t PAD_P2_O_EN_2: 1;
        uint32_t PAD_P2_DUMMY0_2: 1;
        uint32_t PAD_P2_DUMMY1_2: 1;
        uint32_t PAD_P2_SHDN_3: 1;
        uint32_t AON_PAD_P2_E_3: 1;
        uint32_t AON_PAD_P2_O_3: 1;
        uint32_t PAD_P2_E3_3: 1;
        uint32_t PAD_P2_E2_3: 1;
        uint32_t PAD_P2_PDPUC_3: 1;
        uint32_t AON_PAD_P2_PU_3: 1;
        uint32_t AON_PAD_P2_PU_EN_3: 1;
        uint32_t PAD_P2_WKPOL_3: 1;
        uint32_t PAD_P2_WKEN_3: 1;
        uint32_t PAD_P2_DEB_3: 1;
        uint32_t PAD_P2_AON_MUX_3: 2;
        uint32_t PAD_P2_O_EN_3: 1;
        uint32_t PAD_P2_DUMMY0_3: 1;
        uint32_t PAD_P2_DUMMY1_3: 1;
    };
} AON_NS_P2_2_P2_3_PAD_CFG_TYPE;

/* 0x1928   0x4000_1928
    0       R/W PAD_P2_SHDN[4]                  1'b1
    1       R/W AON_PAD_P2_E[4]                 1'b0
    2       R/W AON_PAD_P2_O[4]                 1'b0
    3       R/W PAD_P2_E3[4]                    1'b0
    4       R/W PAD_P2_E2[4]                    1'b0
    5       R/W PAD_P2_PDPUC[4]                 1'b0
    6       R/W AON_PAD_P2_PU[4]                1'b1
    7       R/W AON_PAD_P2_PU_EN[4]             1'b1
    8       R/W PAD_P2_WKPOL[4]                 1'b0
    9       R/W PAD_P2_WKEN[4]                  1'b0
    10      R/W PAD_P2_DEB[4]                   1'b0
    12:11   R/W PAD_P2_AON_MUX[4]               2'b0
    13      R/W PAD_P2_O_EN[4]                  1'b1
    14      R/W PAD_P2_DUMMY0[4]                1'b0
    15      R/W PAD_P2_DUMMY1[4]                1'b0
    16      R/W PAD_P2_SHDN[5]                  1'b1
    17      R/W AON_PAD_P2_E[5]                 1'b0
    18      R/W AON_PAD_P2_O[5]                 1'b0
    19      R/W PAD_P2_E3[5]                    1'b0
    20      R/W PAD_P2_E2[5]                    1'b0
    21      R/W PAD_P2_PDPUC[5]                 1'b0
    22      R/W AON_PAD_P2_PU[5]                1'b1
    23      R/W AON_PAD_P2_PU_EN[5]             1'b1
    24      R/W PAD_P2_WKPOL[5]                 1'b0
    25      R/W PAD_P2_WKEN[5]                  1'b0
    26      R/W PAD_P2_DEB[5]                   1'b0
    28:27   R/W PAD_P2_AON_MUX[5]               2'b0
    29      R/W PAD_P2_O_EN[5]                  1'b1
    30      R/W PAD_P2_DUMMY0[5]                1'b0
    31      R/W PAD_P2_DUMMY1[5]                1'b0
 */
typedef volatile union _AON_NS_P2_4_P2_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P2_SHDN_4: 1;
        uint32_t AON_PAD_P2_E_4: 1;
        uint32_t AON_PAD_P2_O_4: 1;
        uint32_t PAD_P2_E3_4: 1;
        uint32_t PAD_P2_E2_4: 1;
        uint32_t PAD_P2_PDPUC_4: 1;
        uint32_t AON_PAD_P2_PU_4: 1;
        uint32_t AON_PAD_P2_PU_EN_4: 1;
        uint32_t PAD_P2_WKPOL_4: 1;
        uint32_t PAD_P2_WKEN_4: 1;
        uint32_t PAD_P2_DEB_4: 1;
        uint32_t PAD_P2_AON_MUX_4: 2;
        uint32_t PAD_P2_O_EN_4: 1;
        uint32_t PAD_P2_DUMMY0_4: 1;
        uint32_t PAD_P2_DUMMY1_4: 1;
        uint32_t PAD_P2_SHDN_5: 1;
        uint32_t AON_PAD_P2_E_5: 1;
        uint32_t AON_PAD_P2_O_5: 1;
        uint32_t PAD_P2_E3_5: 1;
        uint32_t PAD_P2_E2_5: 1;
        uint32_t PAD_P2_PDPUC_5: 1;
        uint32_t AON_PAD_P2_PU_5: 1;
        uint32_t AON_PAD_P2_PU_EN_5: 1;
        uint32_t PAD_P2_WKPOL_5: 1;
        uint32_t PAD_P2_WKEN_5: 1;
        uint32_t PAD_P2_DEB_5: 1;
        uint32_t PAD_P2_AON_MUX_5: 2;
        uint32_t PAD_P2_O_EN_5: 1;
        uint32_t PAD_P2_DUMMY0_5: 1;
        uint32_t PAD_P2_DUMMY1_5: 1;
    };
} AON_NS_P2_4_P2_5_PAD_CFG_TYPE;

/* 0x192C   0x4000_192c
    0       R/W PAD_P2_SHDN[6]                  1'b1
    1       R/W AON_PAD_P2_E[6]                 1'b0
    2       R/W AON_PAD_P2_O[6]                 1'b0
    3       R/W PAD_P2_E3[6]                    1'b0
    4       R/W PAD_P2_E2[6]                    1'b0
    5       R/W PAD_P2_PDPUC[6]                 1'b0
    6       R/W AON_PAD_P2_PU[6]                1'b0
    7       R/W AON_PAD_P2_PU_EN[6]             1'b1
    8       R/W PAD_P2_WKPOL[6]                 1'b0
    9       R/W PAD_P2_WKEN[6]                  1'b0
    10      R/W PAD_P2_DEB[6]                   1'b0
    12:11   R/W PAD_P2_AON_MUX[6]               2'b0
    13      R/W PAD_P2_O_EN[6]                  1'b1
    14      R/W PAD_P2_DUMMY0[6]                1'b0
    15      R/W PAD_P2_DUMMY1[6]                1'b0
    16      R/W PAD_P2_SHDN[7]                  1'b1
    17      R/W AON_PAD_P2_E[7]                 1'b0
    18      R/W AON_PAD_P2_O[7]                 1'b0
    19      R/W PAD_P2_E3[7]                    1'b0
    20      R/W PAD_P2_E2[7]                    1'b0
    21      R/W PAD_P2_PDPUC[7]                 1'b0
    22      R/W AON_PAD_P2_PU[7]                1'b0
    23      R/W AON_PAD_P2_PU_EN[7]             1'b1
    24      R/W PAD_P2_WKPOL[7]                 1'b0
    25      R/W PAD_P2_WKEN[7]                  1'b0
    26      R/W PAD_P2_DEB[7]                   1'b0
    28:27   R/W PAD_P2_AON_MUX[7]               2'b0
    29      R/W PAD_P2_O_EN[7]                  1'b1
    30      R/W PAD_P2_DUMMY0[7]                1'b0
    31      R/W PAD_P2_DUMMY1[7]                1'b0
 */
typedef volatile union _AON_NS_P2_6_P2_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P2_SHDN_6: 1;
        uint32_t AON_PAD_P2_E_6: 1;
        uint32_t AON_PAD_P2_O_6: 1;
        uint32_t PAD_P2_E3_6: 1;
        uint32_t PAD_P2_E2_6: 1;
        uint32_t PAD_P2_PDPUC_6: 1;
        uint32_t AON_PAD_P2_PU_6: 1;
        uint32_t AON_PAD_P2_PU_EN_6: 1;
        uint32_t PAD_P2_WKPOL_6: 1;
        uint32_t PAD_P2_WKEN_6: 1;
        uint32_t PAD_P2_DEB_6: 1;
        uint32_t PAD_P2_AON_MUX_6: 2;
        uint32_t PAD_P2_O_EN_6: 1;
        uint32_t PAD_P2_DUMMY0_6: 1;
        uint32_t PAD_P2_DUMMY1_6: 1;
        uint32_t PAD_P2_SHDN_7: 1;
        uint32_t AON_PAD_P2_E_7: 1;
        uint32_t AON_PAD_P2_O_7: 1;
        uint32_t PAD_P2_E3_7: 1;
        uint32_t PAD_P2_E2_7: 1;
        uint32_t PAD_P2_PDPUC_7: 1;
        uint32_t AON_PAD_P2_PU_7: 1;
        uint32_t AON_PAD_P2_PU_EN_7: 1;
        uint32_t PAD_P2_WKPOL_7: 1;
        uint32_t PAD_P2_WKEN_7: 1;
        uint32_t PAD_P2_DEB_7: 1;
        uint32_t PAD_P2_AON_MUX_7: 2;
        uint32_t PAD_P2_O_EN_7: 1;
        uint32_t PAD_P2_DUMMY0_7: 1;
        uint32_t PAD_P2_DUMMY1_7: 1;
    };
} AON_NS_P2_6_P2_7_PAD_CFG_TYPE;

/* 0x1930   0x4000_1930
    0       R/W PAD_P3_SHDN[0]                  1'b1
    1       R/W AON_PAD_P3_E[0]                 1'b0
    2       R/W AON_PAD_P3_O[0]                 1'b0
    3       R/W PAD_P3_E3[0]                    1'b0
    4       R/W PAD_P3_E2[0]                    1'b0
    5       R/W PAD_P3_PDPUC[0]                 1'b0
    6       R/W AON_PAD_P3_PU[0]                1'b0
    7       R/W AON_PAD_P3_PU_EN[0]             1'b1
    8       R/W PAD_P3_WKPOL[0]                 1'b0
    9       R/W PAD_P3_WKEN[0]                  1'b0
    10      R/W PAD_P3_DEB[0]                   1'b0
    12:11   R/W PAD_P3_AON_MUX[0]               2'b0
    13      R/W PAD_P3_O_EN[0]                  1'b1
    14      R/W PAD_P3_DUMMY0[0]                1'b0
    15      R/W PAD_P3_DUMMY1[0]                1'b0
    16      R/W PAD_P3_SHDN[1]                  1'b1
    17      R/W AON_PAD_P3_E[1]                 1'b0
    18      R/W AON_PAD_P3_O[1]                 1'b0
    19      R/W PAD_P3_E3[1]                    1'b0
    20      R/W PAD_P3_E2[1]                    1'b0
    21      R/W PAD_P3_PDPUC[1]                 1'b0
    22      R/W AON_PAD_P3_PU[1]                1'b0
    23      R/W AON_PAD_P3_PU_EN[1]             1'b1
    24      R/W PAD_P3_WKPOL[1]                 1'b0
    25      R/W PAD_P3_WKEN[1]                  1'b0
    26      R/W PAD_P3_DEB[1]                   1'b0
    28:27   R/W PAD_P3_AON_MUX[1]               2'b0
    29      R/W PAD_P3_O_EN[1]                  1'b1
    30      R/W PAD_P3_DUMMY0[1]                1'b0
    31      R/W PAD_P3_DUMMY1[1]                1'b0
 */
typedef volatile union _AON_NS_P3_0_P3_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P3_SHDN_0: 1;
        uint32_t AON_PAD_P3_E_0: 1;
        uint32_t AON_PAD_P3_O_0: 1;
        uint32_t PAD_P3_E3_0: 1;
        uint32_t PAD_P3_E2_0: 1;
        uint32_t PAD_P3_PDPUC_0: 1;
        uint32_t AON_PAD_P3_PU_0: 1;
        uint32_t AON_PAD_P3_PU_EN_0: 1;
        uint32_t PAD_P3_WKPOL_0: 1;
        uint32_t PAD_P3_WKEN_0: 1;
        uint32_t PAD_P3_DEB_0: 1;
        uint32_t PAD_P3_AON_MUX_0: 2;
        uint32_t PAD_P3_O_EN_0: 1;
        uint32_t PAD_P3_DUMMY0_0: 1;
        uint32_t PAD_P3_DUMMY1_0: 1;
        uint32_t PAD_P3_SHDN_1: 1;
        uint32_t AON_PAD_P3_E_1: 1;
        uint32_t AON_PAD_P3_O_1: 1;
        uint32_t PAD_P3_E3_1: 1;
        uint32_t PAD_P3_E2_1: 1;
        uint32_t PAD_P3_PDPUC_1: 1;
        uint32_t AON_PAD_P3_PU_1: 1;
        uint32_t AON_PAD_P3_PU_EN_1: 1;
        uint32_t PAD_P3_WKPOL_1: 1;
        uint32_t PAD_P3_WKEN_1: 1;
        uint32_t PAD_P3_DEB_1: 1;
        uint32_t PAD_P3_AON_MUX_1: 2;
        uint32_t PAD_P3_O_EN_1: 1;
        uint32_t PAD_P3_DUMMY0_1: 1;
        uint32_t PAD_P3_DUMMY1_1: 1;
    };
} AON_NS_P3_0_P3_1_PAD_CFG_TYPE;

/* 0x1934   0x4000_1934
    0       R/W PAD_P3_SHDN[2]                  1'b1
    1       R/W AON_PAD_P3_E[2]                 1'b0
    2       R/W AON_PAD_P3_O[2]                 1'b0
    3       R/W PAD_P3_E3[2]                    1'b0
    4       R/W PAD_P3_E2[2]                    1'b0
    5       R/W PAD_P3_PDPUC[2]                 1'b0
    6       R/W AON_PAD_P3_PU[2]                1'b1
    7       R/W AON_PAD_P3_PU_EN[2]             1'b1
    8       R/W PAD_P3_WKPOL[2]                 1'b0
    9       R/W PAD_P3_WKEN[2]                  1'b0
    10      R/W PAD_P3_DEB[2]                   1'b0
    12:11   R/W PAD_P3_AON_MUX[2]               2'b0
    13      R/W PAD_P3_O_EN[2]                  1'b1
    14      R/W PAD_P3_HS_MUX[2]                1'b0
    15      R/W PAD_P3_DUMMY1[2]                1'b0
    16      R/W PAD_P3_SHDN[3]                  1'b1
    17      R/W AON_PAD_P3_E[3]                 1'b0
    18      R/W AON_PAD_P3_O[3]                 1'b0
    19      R/W PAD_P3_E3[3]                    1'b0
    20      R/W PAD_P3_E2[3]                    1'b0
    21      R/W PAD_P3_PDPUC[3]                 1'b0
    22      R/W AON_PAD_P3_PU[3]                1'b0
    23      R/W AON_PAD_P3_PU_EN[3]             1'b1
    24      R/W PAD_P3_WKPOL[3]                 1'b0
    25      R/W PAD_P3_WKEN[3]                  1'b0
    26      R/W PAD_P3_DEB[3]                   1'b0
    28:27   R/W PAD_P3_AON_MUX[3]               2'b0
    29      R/W PAD_P3_O_EN[3]                  1'b1
    30      R/W PAD_P3_HS_MUX[3]                1'b0
    31      R/W PAD_P3_DUMMY1[3]                1'b0
 */
typedef volatile union _AON_NS_P3_2_P3_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P3_SHDN_2: 1;
        uint32_t AON_PAD_P3_E_2: 1;
        uint32_t AON_PAD_P3_O_2: 1;
        uint32_t PAD_P3_E3_2: 1;
        uint32_t PAD_P3_E2_2: 1;
        uint32_t PAD_P3_PDPUC_2: 1;
        uint32_t AON_PAD_P3_PU_2: 1;
        uint32_t AON_PAD_P3_PU_EN_2: 1;
        uint32_t PAD_P3_WKPOL_2: 1;
        uint32_t PAD_P3_WKEN_2: 1;
        uint32_t PAD_P3_DEB_2: 1;
        uint32_t PAD_P3_AON_MUX_2: 2;
        uint32_t PAD_P3_O_EN_2: 1;
        uint32_t PAD_P3_HS_MUX_2: 1;
        uint32_t PAD_P3_DUMMY1_2: 1;
        uint32_t PAD_P3_SHDN_3: 1;
        uint32_t AON_PAD_P3_E_3: 1;
        uint32_t AON_PAD_P3_O_3: 1;
        uint32_t PAD_P3_E3_3: 1;
        uint32_t PAD_P3_E2_3: 1;
        uint32_t PAD_P3_PDPUC_3: 1;
        uint32_t AON_PAD_P3_PU_3: 1;
        uint32_t AON_PAD_P3_PU_EN_3: 1;
        uint32_t PAD_P3_WKPOL_3: 1;
        uint32_t PAD_P3_WKEN_3: 1;
        uint32_t PAD_P3_DEB_3: 1;
        uint32_t PAD_P3_AON_MUX_3: 2;
        uint32_t PAD_P3_O_EN_3: 1;
        uint32_t PAD_P3_HS_MUX_3: 1;
        uint32_t PAD_P3_DUMMY1_3: 1;
    };
} AON_NS_P3_2_P3_3_PAD_CFG_TYPE;

/* 0x1938   0x4000_1938
    0       R/W PAD_P3_SHDN[4]                  1'b1
    1       R/W AON_PAD_P3_E[4]                 1'b0
    2       R/W AON_PAD_P3_O[4]                 1'b0
    3       R/W PAD_P3_E3[4]                    1'b0
    4       R/W PAD_P3_E2[4]                    1'b0
    5       R/W PAD_P3_PDPUC[4]                 1'b0
    6       R/W AON_PAD_P3_PU[4]                1'b0
    7       R/W AON_PAD_P3_PU_EN[4]             1'b1
    8       R/W PAD_P3_WKPOL[4]                 1'b0
    9       R/W PAD_P3_WKEN[4]                  1'b0
    10      R/W PAD_P3_DEB[4]                   1'b0
    12:11   R/W PAD_P3_AON_MUX[4]               2'b0
    13      R/W PAD_P3_O_EN[4]                  1'b1
    14      R/W PAD_P3_HS_MUX[4]                1'b0
    15      R/W PAD_P3_DUMMY1[4]                1'b0
    16      R/W PAD_P3_SHDN[5]                  1'b1
    17      R/W AON_PAD_P3_E[5]                 1'b0
    18      R/W AON_PAD_P3_O[5]                 1'b0
    19      R/W PAD_P3_E3[5]                    1'b0
    20      R/W PAD_P3_E2[5]                    1'b0
    21      R/W PAD_P3_PDPUC[5]                 1'b0
    22      R/W AON_PAD_P3_PU[5]                1'b0
    23      R/W AON_PAD_P3_PU_EN[5]             1'b1
    24      R/W PAD_P3_WKPOL[5]                 1'b0
    25      R/W PAD_P3_WKEN[5]                  1'b0
    26      R/W PAD_P3_DEB[5]                   1'b0
    28:27   R/W PAD_P3_AON_MUX[5]               2'b0
    29      R/W PAD_P3_O_EN[5]                  1'b1
    30      R/W PAD_P3_HS_MUX[5]                1'b0
    31      R/W PAD_P3_DUMMY1[5]                1'b0
 */
typedef volatile union _AON_NS_P3_4_P3_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P3_SHDN_4: 1;
        uint32_t AON_PAD_P3_E_4: 1;
        uint32_t AON_PAD_P3_O_4: 1;
        uint32_t PAD_P3_E3_4: 1;
        uint32_t PAD_P3_E2_4: 1;
        uint32_t PAD_P3_PDPUC_4: 1;
        uint32_t AON_PAD_P3_PU_4: 1;
        uint32_t AON_PAD_P3_PU_EN_4: 1;
        uint32_t PAD_P3_WKPOL_4: 1;
        uint32_t PAD_P3_WKEN_4: 1;
        uint32_t PAD_P3_DEB_4: 1;
        uint32_t PAD_P3_AON_MUX_4: 2;
        uint32_t PAD_P3_O_EN_4: 1;
        uint32_t PAD_P3_HS_MUX_4: 1;
        uint32_t PAD_P3_DUMMY1_4: 1;
        uint32_t PAD_P3_SHDN_5: 1;
        uint32_t AON_PAD_P3_E_5: 1;
        uint32_t AON_PAD_P3_O_5: 1;
        uint32_t PAD_P3_E3_5: 1;
        uint32_t PAD_P3_E2_5: 1;
        uint32_t PAD_P3_PDPUC_5: 1;
        uint32_t AON_PAD_P3_PU_5: 1;
        uint32_t AON_PAD_P3_PU_EN_5: 1;
        uint32_t PAD_P3_WKPOL_5: 1;
        uint32_t PAD_P3_WKEN_5: 1;
        uint32_t PAD_P3_DEB_5: 1;
        uint32_t PAD_P3_AON_MUX_5: 2;
        uint32_t PAD_P3_O_EN_5: 1;
        uint32_t PAD_P3_HS_MUX_5: 1;
        uint32_t PAD_P3_DUMMY1_5: 1;
    };
} AON_NS_P3_4_P3_5_PAD_CFG_TYPE;

/* 0x193C   0x4000_193c
    0       R/W PAD_P3_SHDN[6]                  1'b1
    1       R/W AON_PAD_P3_E[6]                 1'b0
    2       R/W AON_PAD_P3_O[6]                 1'b0
    3       R/W PAD_P3_E3[6]                    1'b0
    4       R/W PAD_P3_E2[6]                    1'b0
    5       R/W PAD_P3_PDPUC[6]                 1'b0
    6       R/W AON_PAD_P3_PU[6]                1'b0
    7       R/W AON_PAD_P3_PU_EN[6]             1'b1
    8       R/W PAD_P3_WKPOL[6]                 1'b0
    9       R/W PAD_P3_WKEN[6]                  1'b0
    10      R/W PAD_P3_DEB[6]                   1'b0
    12:11   R/W PAD_P3_AON_MUX[6]               2'b0
    13      R/W PAD_P3_O_EN[6]                  1'b1
    14      R/W PAD_P3_HS_MUX[6]                1'b0
    15      R/W PAD_P3_DUMMY1[6]                1'b0
    16      R/W PAD_P3_SHDN[7]                  1'b1
    17      R/W AON_PAD_P3_E[7]                 1'b0
    18      R/W AON_PAD_P3_O[7]                 1'b0
    19      R/W PAD_P3_E3[7]                    1'b0
    20      R/W PAD_P3_E2[7]                    1'b0
    21      R/W PAD_P3_PDPUC[7]                 1'b0
    22      R/W AON_PAD_P3_PU[7]                1'b0
    23      R/W AON_PAD_P3_PU_EN[7]             1'b1
    24      R/W PAD_P3_WKPOL[7]                 1'b0
    25      R/W PAD_P3_WKEN[7]                  1'b0
    26      R/W PAD_P3_DEB[7]                   1'b0
    28:27   R/W PAD_P3_AON_MUX[7]               2'b0
    29      R/W PAD_P3_O_EN[7]                  1'b1
    30      R/W PAD_P3_HS_MUX[7]                1'b0
    31      R/W PAD_P3_DUMMY1[7]                1'b0
 */
typedef volatile union _AON_NS_P3_6_P3_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P3_SHDN_6: 1;
        uint32_t AON_PAD_P3_E_6: 1;
        uint32_t AON_PAD_P3_O_6: 1;
        uint32_t PAD_P3_E3_6: 1;
        uint32_t PAD_P3_E2_6: 1;
        uint32_t PAD_P3_PDPUC_6: 1;
        uint32_t AON_PAD_P3_PU_6: 1;
        uint32_t AON_PAD_P3_PU_EN_6: 1;
        uint32_t PAD_P3_WKPOL_6: 1;
        uint32_t PAD_P3_WKEN_6: 1;
        uint32_t PAD_P3_DEB_6: 1;
        uint32_t PAD_P3_AON_MUX_6: 2;
        uint32_t PAD_P3_O_EN_6: 1;
        uint32_t PAD_P3_HS_MUX_6: 1;
        uint32_t PAD_P3_DUMMY1_6: 1;
        uint32_t PAD_P3_SHDN_7: 1;
        uint32_t AON_PAD_P3_E_7: 1;
        uint32_t AON_PAD_P3_O_7: 1;
        uint32_t PAD_P3_E3_7: 1;
        uint32_t PAD_P3_E2_7: 1;
        uint32_t PAD_P3_PDPUC_7: 1;
        uint32_t AON_PAD_P3_PU_7: 1;
        uint32_t AON_PAD_P3_PU_EN_7: 1;
        uint32_t PAD_P3_WKPOL_7: 1;
        uint32_t PAD_P3_WKEN_7: 1;
        uint32_t PAD_P3_DEB_7: 1;
        uint32_t PAD_P3_AON_MUX_7: 2;
        uint32_t PAD_P3_O_EN_7: 1;
        uint32_t PAD_P3_HS_MUX_7: 1;
        uint32_t PAD_P3_DUMMY1_7: 1;
    };
} AON_NS_P3_6_P3_7_PAD_CFG_TYPE;

/* 0x1940   0x4000_1940
    0       R/W PAD_P4_SHDN[0]                  1'b1
    1       R/W AON_PAD_P4_E[0]                 1'b0
    2       R/W AON_PAD_P4_O[0]                 1'b0
    3       R/W PAD_P4_E3[0]                    1'b0
    4       R/W PAD_P4_E2[0]                    1'b0
    5       R/W PAD_P4_PDPUC[0]                 1'b0
    6       R/W AON_PAD_P4_PU[0]                1'b0
    7       R/W AON_PAD_P4_PU_EN[0]             1'b1
    8       R/W PAD_P4_WKPOL[0]                 1'b0
    9       R/W PAD_P4_WKEN[0]                  1'b0
    10      R/W PAD_P4_DEB[0]                   1'b0
    12:11   R/W PAD_P4_AON_MUX[0]               2'b0
    13      R/W PAD_P4_O_EN[0]                  1'b1
    14      R/W PAD_P4_HS_MUX[0]                1'b0
    15      R/W PAD_P4_DUMMY1[0]                1'b0
    16      R/W PAD_P4_SHDN[1]                  1'b1
    17      R/W AON_PAD_P4_E[1]                 1'b0
    18      R/W AON_PAD_P4_O[1]                 1'b0
    19      R/W PAD_P4_E3[1]                    1'b0
    20      R/W PAD_P4_E2[1]                    1'b0
    21      R/W PAD_P4_PDPUC[1]                 1'b0
    22      R/W AON_PAD_P4_PU[1]                1'b0
    23      R/W AON_PAD_P4_PU_EN[1]             1'b1
    24      R/W PAD_P4_WKPOL[1]                 1'b0
    25      R/W PAD_P4_WKEN[1]                  1'b0
    26      R/W PAD_P4_DEB[1]                   1'b0
    28:27   R/W PAD_P4_AON_MUX[1]               2'b0
    29      R/W PAD_P4_O_EN[1]                  1'b1
    30      R/W PAD_P4_HS_MUX[1]                1'b0
    31      R/W PAD_P4_DUMMY1[1]                1'b0
 */
typedef volatile union _AON_NS_P4_0_P4_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P4_SHDN_0: 1;
        uint32_t AON_PAD_P4_E_0: 1;
        uint32_t AON_PAD_P4_O_0: 1;
        uint32_t PAD_P4_E3_0: 1;
        uint32_t PAD_P4_E2_0: 1;
        uint32_t PAD_P4_PDPUC_0: 1;
        uint32_t AON_PAD_P4_PU_0: 1;
        uint32_t AON_PAD_P4_PU_EN_0: 1;
        uint32_t PAD_P4_WKPOL_0: 1;
        uint32_t PAD_P4_WKEN_0: 1;
        uint32_t PAD_P4_DEB_0: 1;
        uint32_t PAD_P4_AON_MUX_0: 2;
        uint32_t PAD_P4_O_EN_0: 1;
        uint32_t PAD_P4_HS_MUX_0: 1;
        uint32_t PAD_P4_DUMMY1_0: 1;
        uint32_t PAD_P4_SHDN_1: 1;
        uint32_t AON_PAD_P4_E_1: 1;
        uint32_t AON_PAD_P4_O_1: 1;
        uint32_t PAD_P4_E3_1: 1;
        uint32_t PAD_P4_E2_1: 1;
        uint32_t PAD_P4_PDPUC_1: 1;
        uint32_t AON_PAD_P4_PU_1: 1;
        uint32_t AON_PAD_P4_PU_EN_1: 1;
        uint32_t PAD_P4_WKPOL_1: 1;
        uint32_t PAD_P4_WKEN_1: 1;
        uint32_t PAD_P4_DEB_1: 1;
        uint32_t PAD_P4_AON_MUX_1: 2;
        uint32_t PAD_P4_O_EN_1: 1;
        uint32_t PAD_P4_HS_MUX_1: 1;
        uint32_t PAD_P4_DUMMY1_1: 1;
    };
} AON_NS_P4_0_P4_1_PAD_CFG_TYPE;

/* 0x1944   0x4000_1944
    0       R/W PAD_P4_SHDN[2]                  1'b1
    1       R/W AON_PAD_P4_E[2]                 1'b0
    2       R/W AON_PAD_P4_O[2]                 1'b0
    3       R/W PAD_P4_E3[2]                    1'b0
    4       R/W PAD_P4_E2[2]                    1'b0
    5       R/W PAD_P4_PDPUC[2]                 1'b0
    6       R/W AON_PAD_P4_PU[2]                1'b0
    7       R/W AON_PAD_P4_PU_EN[2]             1'b1
    8       R/W PAD_P4_WKPOL[2]                 1'b0
    9       R/W PAD_P4_WKEN[2]                  1'b0
    10      R/W PAD_P4_DEB[2]                   1'b0
    12:11   R/W PAD_P4_AON_MUX[2]               2'b0
    13      R/W PAD_P4_O_EN[2]                  1'b1
    14      R/W PAD_P4_HS_MUX[2]                1'b0
    15      R/W PAD_P4_DUMMY1[2]                1'b0
    16      R/W PAD_P4_SHDN[3]                  1'b1
    17      R/W AON_PAD_P4_E[3]                 1'b0
    18      R/W AON_PAD_P4_O[3]                 1'b0
    19      R/W PAD_P4_E3[3]                    1'b0
    20      R/W PAD_P4_E2[3]                    1'b0
    21      R/W PAD_P4_PDPUC[3]                 1'b0
    22      R/W AON_PAD_P4_PU[3]                1'b0
    23      R/W AON_PAD_P4_PU_EN[3]             1'b1
    24      R/W PAD_P4_WKPOL[3]                 1'b0
    25      R/W PAD_P4_WKEN[3]                  1'b0
    26      R/W PAD_P4_DEB[3]                   1'b0
    28:27   R/W PAD_P4_AON_MUX[3]               2'b0
    29      R/W PAD_P4_O_EN[3]                  1'b1
    30      R/W PAD_P4_HS_MUX[3]                1'b0
    31      R/W PAD_P4_DUMMY1[3]                1'b0
 */
typedef volatile union _AON_NS_P4_2_P4_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P4_SHDN_2: 1;
        uint32_t AON_PAD_P4_E_2: 1;
        uint32_t AON_PAD_P4_O_2: 1;
        uint32_t PAD_P4_E3_2: 1;
        uint32_t PAD_P4_E2_2: 1;
        uint32_t PAD_P4_PDPUC_2: 1;
        uint32_t AON_PAD_P4_PU_2: 1;
        uint32_t AON_PAD_P4_PU_EN_2: 1;
        uint32_t PAD_P4_WKPOL_2: 1;
        uint32_t PAD_P4_WKEN_2: 1;
        uint32_t PAD_P4_DEB_2: 1;
        uint32_t PAD_P4_AON_MUX_2: 2;
        uint32_t PAD_P4_O_EN_2: 1;
        uint32_t PAD_P4_HS_MUX_2: 1;
        uint32_t PAD_P4_DUMMY1_2: 1;
        uint32_t PAD_P4_SHDN_3: 1;
        uint32_t AON_PAD_P4_E_3: 1;
        uint32_t AON_PAD_P4_O_3: 1;
        uint32_t PAD_P4_E3_3: 1;
        uint32_t PAD_P4_E2_3: 1;
        uint32_t PAD_P4_PDPUC_3: 1;
        uint32_t AON_PAD_P4_PU_3: 1;
        uint32_t AON_PAD_P4_PU_EN_3: 1;
        uint32_t PAD_P4_WKPOL_3: 1;
        uint32_t PAD_P4_WKEN_3: 1;
        uint32_t PAD_P4_DEB_3: 1;
        uint32_t PAD_P4_AON_MUX_3: 2;
        uint32_t PAD_P4_O_EN_3: 1;
        uint32_t PAD_P4_HS_MUX_3: 1;
        uint32_t PAD_P4_DUMMY1_3: 1;
    };
} AON_NS_P4_2_P4_3_PAD_CFG_TYPE;

/* 0x1948   0x4000_1948
    0       R/W PAD_P4_SHDN[4]                  1'b1
    1       R/W AON_PAD_P4_E[4]                 1'b0
    2       R/W AON_PAD_P4_O[4]                 1'b0
    3       R/W PAD_P4_E3[4]                    1'b0
    4       R/W PAD_P4_E2[4]                    1'b0
    5       R/W PAD_P4_PDPUC[4]                 1'b0
    6       R/W AON_PAD_P4_PU[4]                1'b0
    7       R/W AON_PAD_P4_PU_EN[4]             1'b1
    8       R/W PAD_P4_WKPOL[4]                 1'b0
    9       R/W PAD_P4_WKEN[4]                  1'b0
    10      R/W PAD_P4_DEB[4]                   1'b0
    12:11   R/W PAD_P4_AON_MUX[4]               2'b0
    13      R/W PAD_P4_O_EN[4]                  1'b1
    14      R/W PAD_P4_HS_MUX[4]                1'b0
    15      R/W PAD_P4_DUMMY1[4]                1'b0
    16      R/W PAD_P4_SHDN[5]                  1'b1
    17      R/W AON_PAD_P4_E[5]                 1'b0
    18      R/W AON_PAD_P4_O[5]                 1'b0
    19      R/W PAD_P4_E3[5]                    1'b0
    20      R/W PAD_P4_E2[5]                    1'b0
    21      R/W PAD_P4_PDPUC[5]                 1'b0
    22      R/W AON_PAD_P4_PU[5]                1'b0
    23      R/W AON_PAD_P4_PU_EN[5]             1'b1
    24      R/W PAD_P4_WKPOL[5]                 1'b0
    25      R/W PAD_P4_WKEN[5]                  1'b0
    26      R/W PAD_P4_DEB[5]                   1'b0
    28:27   R/W PAD_P4_AON_MUX[5]               2'b0
    29      R/W PAD_P4_O_EN[5]                  1'b1
    30      R/W PAD_P4_HS_MUX[5]                1'b0
    31      R/W PAD_P4_DUMMY1[5]                1'b0
 */
typedef volatile union _AON_NS_P4_4_P4_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P4_SHDN_4: 1;
        uint32_t AON_PAD_P4_E_4: 1;
        uint32_t AON_PAD_P4_O_4: 1;
        uint32_t PAD_P4_E3_4: 1;
        uint32_t PAD_P4_E2_4: 1;
        uint32_t PAD_P4_PDPUC_4: 1;
        uint32_t AON_PAD_P4_PU_4: 1;
        uint32_t AON_PAD_P4_PU_EN_4: 1;
        uint32_t PAD_P4_WKPOL_4: 1;
        uint32_t PAD_P4_WKEN_4: 1;
        uint32_t PAD_P4_DEB_4: 1;
        uint32_t PAD_P4_AON_MUX_4: 2;
        uint32_t PAD_P4_O_EN_4: 1;
        uint32_t PAD_P4_HS_MUX_4: 1;
        uint32_t PAD_P4_DUMMY1_4: 1;
        uint32_t PAD_P4_SHDN_5: 1;
        uint32_t AON_PAD_P4_E_5: 1;
        uint32_t AON_PAD_P4_O_5: 1;
        uint32_t PAD_P4_E3_5: 1;
        uint32_t PAD_P4_E2_5: 1;
        uint32_t PAD_P4_PDPUC_5: 1;
        uint32_t AON_PAD_P4_PU_5: 1;
        uint32_t AON_PAD_P4_PU_EN_5: 1;
        uint32_t PAD_P4_WKPOL_5: 1;
        uint32_t PAD_P4_WKEN_5: 1;
        uint32_t PAD_P4_DEB_5: 1;
        uint32_t PAD_P4_AON_MUX_5: 2;
        uint32_t PAD_P4_O_EN_5: 1;
        uint32_t PAD_P4_HS_MUX_5: 1;
        uint32_t PAD_P4_DUMMY1_5: 1;
    };
} AON_NS_P4_4_P4_5_PAD_CFG_TYPE;

/* 0x194C   0x4000_194c
    0       R/W PAD_P4_SHDN[6]                  1'b1
    1       R/W AON_PAD_P4_E[6]                 1'b0
    2       R/W AON_PAD_P4_O[6]                 1'b0
    3       R/W PAD_P4_E3[6]                    1'b0
    4       R/W PAD_P4_E2[6]                    1'b0
    5       R/W PAD_P4_PDPUC[6]                 1'b0
    6       R/W AON_PAD_P4_PU[6]                1'b0
    7       R/W AON_PAD_P4_PU_EN[6]             1'b1
    8       R/W PAD_P4_WKPOL[6]                 1'b0
    9       R/W PAD_P4_WKEN[6]                  1'b0
    10      R/W PAD_P4_DEB[6]                   1'b0
    12:11   R/W PAD_P4_AON_MUX[6]               2'b0
    13      R/W PAD_P4_O_EN[6]                  1'b1
    14      R/W PAD_P4_HS_MUX[6]                1'b0
    15      R/W PAD_P4_DUMMY1[6]                1'b0
    16      R/W PAD_P4_SHDN[7]                  1'b1
    17      R/W AON_PAD_P4_E[7]                 1'b0
    18      R/W AON_PAD_P4_O[7]                 1'b0
    19      R/W PAD_P4_E3[7]                    1'b0
    20      R/W PAD_P4_E2[7]                    1'b0
    21      R/W PAD_P4_PDPUC[7]                 1'b0
    22      R/W AON_PAD_P4_PU[7]                1'b0
    23      R/W AON_PAD_P4_PU_EN[7]             1'b1
    24      R/W PAD_P4_WKPOL[7]                 1'b0
    25      R/W PAD_P4_WKEN[7]                  1'b0
    26      R/W PAD_P4_DEB[7]                   1'b0
    28:27   R/W PAD_P4_AON_MUX[7]               2'b0
    29      R/W PAD_P4_O_EN[7]                  1'b1
    30      R/W PAD_P4_HS_MUX[7]                1'b0
    31      R/W PAD_P4_DUMMY1[7]                1'b0
 */
typedef volatile union _AON_NS_P4_6_P4_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P4_SHDN_6: 1;
        uint32_t AON_PAD_P4_E_6: 1;
        uint32_t AON_PAD_P4_O_6: 1;
        uint32_t PAD_P4_E3_6: 1;
        uint32_t PAD_P4_E2_6: 1;
        uint32_t PAD_P4_PDPUC_6: 1;
        uint32_t AON_PAD_P4_PU_6: 1;
        uint32_t AON_PAD_P4_PU_EN_6: 1;
        uint32_t PAD_P4_WKPOL_6: 1;
        uint32_t PAD_P4_WKEN_6: 1;
        uint32_t PAD_P4_DEB_6: 1;
        uint32_t PAD_P4_AON_MUX_6: 2;
        uint32_t PAD_P4_O_EN_6: 1;
        uint32_t PAD_P4_HS_MUX_6: 1;
        uint32_t PAD_P4_DUMMY1_6: 1;
        uint32_t PAD_P4_SHDN_7: 1;
        uint32_t AON_PAD_P4_E_7: 1;
        uint32_t AON_PAD_P4_O_7: 1;
        uint32_t PAD_P4_E3_7: 1;
        uint32_t PAD_P4_E2_7: 1;
        uint32_t PAD_P4_PDPUC_7: 1;
        uint32_t AON_PAD_P4_PU_7: 1;
        uint32_t AON_PAD_P4_PU_EN_7: 1;
        uint32_t PAD_P4_WKPOL_7: 1;
        uint32_t PAD_P4_WKEN_7: 1;
        uint32_t PAD_P4_DEB_7: 1;
        uint32_t PAD_P4_AON_MUX_7: 2;
        uint32_t PAD_P4_O_EN_7: 1;
        uint32_t PAD_P4_HS_MUX_7: 1;
        uint32_t PAD_P4_DUMMY1_7: 1;
    };
} AON_NS_P4_6_P4_7_PAD_CFG_TYPE;

/* 0x1950   0x4000_1950
    0       R/W PAD_P5_SHDN[0]                  1'b1
    1       R/W AON_PAD_P5_E[0]                 1'b0
    2       R/W AON_PAD_P5_O[0]                 1'b0
    3       R/W PAD_P5_E3[0]                    1'b0
    4       R/W PAD_P5_E2[0]                    1'b0
    5       R/W PAD_P5_PDPUC[0]                 1'b0
    6       R/W AON_PAD_P5_PU[0]                1'b0
    7       R/W AON_PAD_P5_PU_EN[0]             1'b1
    8       R/W PAD_P5_WKPOL[0]                 1'b0
    9       R/W PAD_P5_WKEN[0]                  1'b0
    10      R/W PAD_P5_DEB[0]                   1'b0
    12:11   R/W PAD_P5_AON_MUX[0]               2'b0
    13      R/W PAD_P5_O_EN[0]                  1'b1
    14      R/W PAD_P5_DUMMY0[0]                1'b0
    15      R/W PAD_P5_DUMMY1[0]                1'b0
    16      R/W PAD_P5_SHDN[1]                  1'b1
    17      R/W AON_PAD_P5_E[1]                 1'b0
    18      R/W AON_PAD_P5_O[1]                 1'b0
    19      R/W PAD_P5_E3[1]                    1'b0
    20      R/W PAD_P5_E2[1]                    1'b0
    21      R/W PAD_P5_PDPUC[1]                 1'b0
    22      R/W AON_PAD_P5_PU[1]                1'b0
    23      R/W AON_PAD_P5_PU_EN[1]             1'b1
    24      R/W PAD_P5_WKPOL[1]                 1'b0
    25      R/W PAD_P5_WKEN[1]                  1'b0
    26      R/W PAD_P5_DEB[1]                   1'b0
    28:27   R/W PAD_P5_AON_MUX[1]               2'b0
    29      R/W PAD_P5_O_EN[1]                  1'b1
    30      R/W PAD_P5_DUMMY0[1]                1'b0
    31      R/W PAD_P5_DUMMY1[1]                1'b0
 */
typedef volatile union _AON_NS_P5_0_P5_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P5_SHDN_0: 1;
        uint32_t AON_PAD_P5_E_0: 1;
        uint32_t AON_PAD_P5_O_0: 1;
        uint32_t PAD_P5_E3_0: 1;
        uint32_t PAD_P5_E2_0: 1;
        uint32_t PAD_P5_PDPUC_0: 1;
        uint32_t AON_PAD_P5_PU_0: 1;
        uint32_t AON_PAD_P5_PU_EN_0: 1;
        uint32_t PAD_P5_WKPOL_0: 1;
        uint32_t PAD_P5_WKEN_0: 1;
        uint32_t PAD_P5_DEB_0: 1;
        uint32_t PAD_P5_AON_MUX_0: 2;
        uint32_t PAD_P5_O_EN_0: 1;
        uint32_t PAD_P5_DUMMY0_0: 1;
        uint32_t PAD_P5_DUMMY1_0: 1;
        uint32_t PAD_P5_SHDN_1: 1;
        uint32_t AON_PAD_P5_E_1: 1;
        uint32_t AON_PAD_P5_O_1: 1;
        uint32_t PAD_P5_E3_1: 1;
        uint32_t PAD_P5_E2_1: 1;
        uint32_t PAD_P5_PDPUC_1: 1;
        uint32_t AON_PAD_P5_PU_1: 1;
        uint32_t AON_PAD_P5_PU_EN_1: 1;
        uint32_t PAD_P5_WKPOL_1: 1;
        uint32_t PAD_P5_WKEN_1: 1;
        uint32_t PAD_P5_DEB_1: 1;
        uint32_t PAD_P5_AON_MUX_1: 2;
        uint32_t PAD_P5_O_EN_1: 1;
        uint32_t PAD_P5_DUMMY0_1: 1;
        uint32_t PAD_P5_DUMMY1_1: 1;
    };
} AON_NS_P5_0_P5_1_PAD_CFG_TYPE;

/* 0x1954   0x4000_1954
    0       R/W PAD_P5_SHDN[2]                  1'b1
    1       R/W AON_PAD_P5_E[2]                 1'b0
    2       R/W AON_PAD_P5_O[2]                 1'b0
    3       R/W PAD_P5_E3[2]                    1'b0
    4       R/W PAD_P5_E2[2]                    1'b0
    5       R/W PAD_P5_PDPUC[2]                 1'b0
    6       R/W AON_PAD_P5_PU[2]                1'b1
    7       R/W AON_PAD_P5_PU_EN[2]             1'b1
    8       R/W PAD_P5_WKPOL[2]                 1'b0
    9       R/W PAD_P5_WKEN[2]                  1'b0
    10      R/W PAD_P5_DEB[2]                   1'b0
    12:11   R/W PAD_P5_AON_MUX[2]               2'b0
    13      R/W PAD_P5_O_EN[2]                  1'b1
    14      R/W PAD_P5_DUMMY0[2]                1'b0
    15      R/W PAD_P5_DUMMY1[2]                1'b0
    16      R/W PAD_P5_SHDN[3]                  1'b1
    17      R/W AON_PAD_P5_E[3]                 1'b0
    18      R/W AON_PAD_P5_O[3]                 1'b0
    19      R/W PAD_P5_E3[3]                    1'b0
    20      R/W PAD_P5_E2[3]                    1'b0
    21      R/W PAD_P5_PDPUC[3]                 1'b0
    22      R/W AON_PAD_P5_PU[3]                1'b1
    23      R/W AON_PAD_P5_PU_EN[3]             1'b1
    24      R/W PAD_P5_WKPOL[3]                 1'b0
    25      R/W PAD_P5_WKEN[3]                  1'b0
    26      R/W PAD_P5_DEB[3]                   1'b0
    28:27   R/W PAD_P5_AON_MUX[3]               2'b0
    29      R/W PAD_P5_O_EN[3]                  1'b1
    30      R/W PAD_P5_DUMMY0[3]                1'b0
    31      R/W PAD_P5_DUMMY1[3]                1'b0
 */
typedef volatile union _AON_NS_P5_2_P5_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P5_SHDN_2: 1;
        uint32_t AON_PAD_P5_E_2: 1;
        uint32_t AON_PAD_P5_O_2: 1;
        uint32_t PAD_P5_E3_2: 1;
        uint32_t PAD_P5_E2_2: 1;
        uint32_t PAD_P5_PDPUC_2: 1;
        uint32_t AON_PAD_P5_PU_2: 1;
        uint32_t AON_PAD_P5_PU_EN_2: 1;
        uint32_t PAD_P5_WKPOL_2: 1;
        uint32_t PAD_P5_WKEN_2: 1;
        uint32_t PAD_P5_DEB_2: 1;
        uint32_t PAD_P5_AON_MUX_2: 2;
        uint32_t PAD_P5_O_EN_2: 1;
        uint32_t PAD_P5_DUMMY0_2: 1;
        uint32_t PAD_P5_DUMMY1_2: 1;
        uint32_t PAD_P5_SHDN_3: 1;
        uint32_t AON_PAD_P5_E_3: 1;
        uint32_t AON_PAD_P5_O_3: 1;
        uint32_t PAD_P5_E3_3: 1;
        uint32_t PAD_P5_E2_3: 1;
        uint32_t PAD_P5_PDPUC_3: 1;
        uint32_t AON_PAD_P5_PU_3: 1;
        uint32_t AON_PAD_P5_PU_EN_3: 1;
        uint32_t PAD_P5_WKPOL_3: 1;
        uint32_t PAD_P5_WKEN_3: 1;
        uint32_t PAD_P5_DEB_3: 1;
        uint32_t PAD_P5_AON_MUX_3: 2;
        uint32_t PAD_P5_O_EN_3: 1;
        uint32_t PAD_P5_DUMMY0_3: 1;
        uint32_t PAD_P5_DUMMY1_3: 1;
    };
} AON_NS_P5_2_P5_3_PAD_CFG_TYPE;

/* 0x1958   0x4000_1958
    0       R/W PAD_P5_SHDN[4]                  1'b1
    1       R/W AON_PAD_P5_E[4]                 1'b0
    2       R/W AON_PAD_P5_O[4]                 1'b0
    3       R/W PAD_P5_E3[4]                    1'b0
    4       R/W PAD_P5_E2[4]                    1'b0
    5       R/W PAD_P5_PDPUC[4]                 1'b0
    6       R/W AON_PAD_P5_PU[4]                1'b0
    7       R/W AON_PAD_P5_PU_EN[4]             1'b1
    8       R/W PAD_P5_WKPOL[4]                 1'b0
    9       R/W PAD_P5_WKEN[4]                  1'b0
    10      R/W PAD_P5_DEB[4]                   1'b0
    12:11   R/W PAD_P5_AON_MUX[4]               2'b0
    13      R/W PAD_P5_O_EN[4]                  1'b1
    14      R/W PAD_P5_DUMMY0[4]                1'b0
    15      R/W PAD_P5_DUMMY1[4]                1'b0
    16      R/W PAD_P5_SHDN[5]                  1'b1
    17      R/W AON_PAD_P5_E[5]                 1'b0
    18      R/W AON_PAD_P5_O[5]                 1'b0
    19      R/W PAD_P5_E3[5]                    1'b0
    20      R/W PAD_P5_E2[5]                    1'b0
    21      R/W PAD_P5_PDPUC[5]                 1'b0
    22      R/W AON_PAD_P5_PU[5]                1'b0
    23      R/W AON_PAD_P5_PU_EN[5]             1'b1
    24      R/W PAD_P5_WKPOL[5]                 1'b0
    25      R/W PAD_P5_WKEN[5]                  1'b0
    26      R/W PAD_P5_DEB[5]                   1'b0
    28:27   R/W PAD_P5_AON_MUX[5]               2'b0
    29      R/W PAD_P5_O_EN[5]                  1'b1
    30      R/W PAD_P5_DUMMY0[5]                1'b0
    31      R/W PAD_P5_DUMMY1[5]                1'b0
 */
typedef volatile union _AON_NS_P5_4_P5_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P5_SHDN_4: 1;
        uint32_t AON_PAD_P5_E_4: 1;
        uint32_t AON_PAD_P5_O_4: 1;
        uint32_t PAD_P5_E3_4: 1;
        uint32_t PAD_P5_E2_4: 1;
        uint32_t PAD_P5_PDPUC_4: 1;
        uint32_t AON_PAD_P5_PU_4: 1;
        uint32_t AON_PAD_P5_PU_EN_4: 1;
        uint32_t PAD_P5_WKPOL_4: 1;
        uint32_t PAD_P5_WKEN_4: 1;
        uint32_t PAD_P5_DEB_4: 1;
        uint32_t PAD_P5_AON_MUX_4: 2;
        uint32_t PAD_P5_O_EN_4: 1;
        uint32_t PAD_P5_DUMMY0_4: 1;
        uint32_t PAD_P5_DUMMY1_4: 1;
        uint32_t PAD_P5_SHDN_5: 1;
        uint32_t AON_PAD_P5_E_5: 1;
        uint32_t AON_PAD_P5_O_5: 1;
        uint32_t PAD_P5_E3_5: 1;
        uint32_t PAD_P5_E2_5: 1;
        uint32_t PAD_P5_PDPUC_5: 1;
        uint32_t AON_PAD_P5_PU_5: 1;
        uint32_t AON_PAD_P5_PU_EN_5: 1;
        uint32_t PAD_P5_WKPOL_5: 1;
        uint32_t PAD_P5_WKEN_5: 1;
        uint32_t PAD_P5_DEB_5: 1;
        uint32_t PAD_P5_AON_MUX_5: 2;
        uint32_t PAD_P5_O_EN_5: 1;
        uint32_t PAD_P5_DUMMY0_5: 1;
        uint32_t PAD_P5_DUMMY1_5: 1;
    };
} AON_NS_P5_4_P5_5_PAD_CFG_TYPE;

/* 0x195C   0x4000_195c
    0       R/W PAD_P5_SHDN[6]                  1'b1
    1       R/W AON_PAD_P5_E[6]                 1'b0
    2       R/W AON_PAD_P5_O[6]                 1'b0
    3       R/W PAD_P5_E3[6]                    1'b0
    4       R/W PAD_P5_E2[6]                    1'b0
    5       R/W PAD_P5_PDPUC[6]                 1'b0
    6       R/W AON_PAD_P5_PU[6]                1'b0
    7       R/W AON_PAD_P5_PU_EN[6]             1'b1
    8       R/W PAD_P5_WKPOL[6]                 1'b0
    9       R/W PAD_P5_WKEN[6]                  1'b0
    10      R/W PAD_P5_DEB[6]                   1'b0
    12:11   R/W PAD_P5_AON_MUX[6]               2'b0
    13      R/W PAD_P5_O_EN[6]                  1'b1
    14      R/W PAD_P5_HS_MUX[6]                1'b0
    15      R/W PAD_P5_DUMMY1[6]                1'b0
    16      R/W PAD_P5_SHDN[7]                  1'b1
    17      R/W AON_PAD_P5_E[7]                 1'b0
    18      R/W AON_PAD_P5_O[7]                 1'b0
    19      R/W PAD_P5_E3[7]                    1'b0
    20      R/W PAD_P5_E2[7]                    1'b0
    21      R/W PAD_P5_PDPUC[7]                 1'b0
    22      R/W AON_PAD_P5_PU[7]                1'b0
    23      R/W AON_PAD_P5_PU_EN[7]             1'b1
    24      R/W PAD_P5_WKPOL[7]                 1'b0
    25      R/W PAD_P5_WKEN[7]                  1'b0
    26      R/W PAD_P5_DEB[7]                   1'b0
    28:27   R/W PAD_P5_AON_MUX[7]               2'b0
    29      R/W PAD_P5_O_EN[7]                  1'b1
    30      R/W PAD_P5_HS_MUX[7]                1'b0
    31      R/W PAD_P5_DUMMY1[7]                1'b0
 */
typedef volatile union _AON_NS_P5_6_P5_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P5_SHDN_6: 1;
        uint32_t AON_PAD_P5_E_6: 1;
        uint32_t AON_PAD_P5_O_6: 1;
        uint32_t PAD_P5_E3_6: 1;
        uint32_t PAD_P5_E2_6: 1;
        uint32_t PAD_P5_PDPUC_6: 1;
        uint32_t AON_PAD_P5_PU_6: 1;
        uint32_t AON_PAD_P5_PU_EN_6: 1;
        uint32_t PAD_P5_WKPOL_6: 1;
        uint32_t PAD_P5_WKEN_6: 1;
        uint32_t PAD_P5_DEB_6: 1;
        uint32_t PAD_P5_AON_MUX_6: 2;
        uint32_t PAD_P5_O_EN_6: 1;
        uint32_t PAD_P5_HS_MUX_6: 1;
        uint32_t PAD_P5_DUMMY1_6: 1;
        uint32_t PAD_P5_SHDN_7: 1;
        uint32_t AON_PAD_P5_E_7: 1;
        uint32_t AON_PAD_P5_O_7: 1;
        uint32_t PAD_P5_E3_7: 1;
        uint32_t PAD_P5_E2_7: 1;
        uint32_t PAD_P5_PDPUC_7: 1;
        uint32_t AON_PAD_P5_PU_7: 1;
        uint32_t AON_PAD_P5_PU_EN_7: 1;
        uint32_t PAD_P5_WKPOL_7: 1;
        uint32_t PAD_P5_WKEN_7: 1;
        uint32_t PAD_P5_DEB_7: 1;
        uint32_t PAD_P5_AON_MUX_7: 2;
        uint32_t PAD_P5_O_EN_7: 1;
        uint32_t PAD_P5_HS_MUX_7: 1;
        uint32_t PAD_P5_DUMMY1_7: 1;
    };
} AON_NS_P5_6_P5_7_PAD_CFG_TYPE;

/* 0x1960   0x4000_1960
    0       R/W PAD_P6_SHDN[0]                  1'b1
    1       R/W AON_PAD_P6_E[0]                 1'b0
    2       R/W AON_PAD_P6_O[0]                 1'b0
    3       R/W PAD_P6_E3[0]                    1'b0
    4       R/W PAD_P6_E2[0]                    1'b0
    5       R/W PAD_P6_PDPUC[0]                 1'b0
    6       R/W AON_PAD_P6_PU[0]                1'b0
    7       R/W AON_PAD_P6_PU_EN[0]             1'b1
    8       R/W PAD_P6_WKPOL[0]                 1'b0
    9       R/W PAD_P6_WKEN[0]                  1'b0
    10      R/W PAD_P6_DEB[0]                   1'b0
    12:11   R/W PAD_P6_AON_MUX[0]               2'b0
    13      R/W PAD_P6_O_EN[0]                  1'b1
    14      R/W PAD_P6_HS_MUX[0]                1'b0
    15      R/W PAD_P6_DUMMY1[0]                1'b0
    16      R/W PAD_P6_SHDN[1]                  1'b1
    17      R/W AON_PAD_P6_E[1]                 1'b0
    18      R/W AON_PAD_P6_O[1]                 1'b0
    19      R/W PAD_P6_E3[1]                    1'b0
    20      R/W PAD_P6_E2[1]                    1'b0
    21      R/W PAD_P6_PDPUC[1]                 1'b0
    22      R/W AON_PAD_P6_PU[1]                1'b0
    23      R/W AON_PAD_P6_PU_EN[1]             1'b1
    24      R/W PAD_P6_WKPOL[1]                 1'b0
    25      R/W PAD_P6_WKEN[1]                  1'b0
    26      R/W PAD_P6_DEB[1]                   1'b0
    28:27   R/W PAD_P6_AON_MUX[1]               2'b0
    29      R/W PAD_P6_O_EN[1]                  1'b1
    30      R/W PAD_P6_HS_MUX[1]                1'b0
    31      R/W PAD_P6_DUMMY1[1]                1'b0
 */
typedef volatile union _AON_NS_P6_0_P6_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P6_SHDN_0: 1;
        uint32_t AON_PAD_P6_E_0: 1;
        uint32_t AON_PAD_P6_O_0: 1;
        uint32_t PAD_P6_E3_0: 1;
        uint32_t PAD_P6_E2_0: 1;
        uint32_t PAD_P6_PDPUC_0: 1;
        uint32_t AON_PAD_P6_PU_0: 1;
        uint32_t AON_PAD_P6_PU_EN_0: 1;
        uint32_t PAD_P6_WKPOL_0: 1;
        uint32_t PAD_P6_WKEN_0: 1;
        uint32_t PAD_P6_DEB_0: 1;
        uint32_t PAD_P6_AON_MUX_0: 2;
        uint32_t PAD_P6_O_EN_0: 1;
        uint32_t PAD_P6_HS_MUX_0: 1;
        uint32_t PAD_P6_DUMMY1_0: 1;
        uint32_t PAD_P6_SHDN_1: 1;
        uint32_t AON_PAD_P6_E_1: 1;
        uint32_t AON_PAD_P6_O_1: 1;
        uint32_t PAD_P6_E3_1: 1;
        uint32_t PAD_P6_E2_1: 1;
        uint32_t PAD_P6_PDPUC_1: 1;
        uint32_t AON_PAD_P6_PU_1: 1;
        uint32_t AON_PAD_P6_PU_EN_1: 1;
        uint32_t PAD_P6_WKPOL_1: 1;
        uint32_t PAD_P6_WKEN_1: 1;
        uint32_t PAD_P6_DEB_1: 1;
        uint32_t PAD_P6_AON_MUX_1: 2;
        uint32_t PAD_P6_O_EN_1: 1;
        uint32_t PAD_P6_HS_MUX_1: 1;
        uint32_t PAD_P6_DUMMY1_1: 1;
    };
} AON_NS_P6_0_P6_1_PAD_CFG_TYPE;

/* 0x1964   0x4000_1964
    0       R/W PAD_P6_SHDN[2]                  1'b1
    1       R/W AON_PAD_P6_E[2]                 1'b0
    2       R/W AON_PAD_P6_O[2]                 1'b0
    3       R/W PAD_P6_E3[2]                    1'b0
    4       R/W PAD_P6_E2[2]                    1'b0
    5       R/W PAD_P6_PDPUC[2]                 1'b0
    6       R/W AON_PAD_P6_PU[2]                1'b0
    7       R/W AON_PAD_P6_PU_EN[2]             1'b1
    8       R/W PAD_P6_WKPOL[2]                 1'b0
    9       R/W PAD_P6_WKEN[2]                  1'b0
    10      R/W PAD_P6_DEB[2]                   1'b0
    12:11   R/W PAD_P6_AON_MUX[2]               2'b0
    13      R/W PAD_P6_O_EN[2]                  1'b1
    14      R/W PAD_P6_HS_MUX[2]                1'b0
    15      R/W PAD_P6_DUMMY1[2]                1'b0
    16      R/W PAD_P6_SHDN[3]                  1'b1
    17      R/W AON_PAD_P6_E[3]                 1'b0
    18      R/W AON_PAD_P6_O[3]                 1'b0
    19      R/W PAD_P6_E3[3]                    1'b0
    20      R/W PAD_P6_E2[3]                    1'b0
    21      R/W PAD_P6_PDPUC[3]                 1'b0
    22      R/W AON_PAD_P6_PU[3]                1'b0
    23      R/W AON_PAD_P6_PU_EN[3]             1'b1
    24      R/W PAD_P6_WKPOL[3]                 1'b0
    25      R/W PAD_P6_WKEN[3]                  1'b0
    26      R/W PAD_P6_DEB[3]                   1'b0
    28:27   R/W PAD_P6_AON_MUX[3]               2'b0
    29      R/W PAD_P6_O_EN[3]                  1'b1
    30      R/W PAD_P6_HS_MUX[3]                1'b0
    31      R/W PAD_P6_DUMMY1[3]                1'b0
 */
typedef volatile union _AON_NS_P6_2_P6_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P6_SHDN_2: 1;
        uint32_t AON_PAD_P6_E_2: 1;
        uint32_t AON_PAD_P6_O_2: 1;
        uint32_t PAD_P6_E3_2: 1;
        uint32_t PAD_P6_E2_2: 1;
        uint32_t PAD_P6_PDPUC_2: 1;
        uint32_t AON_PAD_P6_PU_2: 1;
        uint32_t AON_PAD_P6_PU_EN_2: 1;
        uint32_t PAD_P6_WKPOL_2: 1;
        uint32_t PAD_P6_WKEN_2: 1;
        uint32_t PAD_P6_DEB_2: 1;
        uint32_t PAD_P6_AON_MUX_2: 2;
        uint32_t PAD_P6_O_EN_2: 1;
        uint32_t PAD_P6_HS_MUX_2: 1;
        uint32_t PAD_P6_DUMMY1_2: 1;
        uint32_t PAD_P6_SHDN_3: 1;
        uint32_t AON_PAD_P6_E_3: 1;
        uint32_t AON_PAD_P6_O_3: 1;
        uint32_t PAD_P6_E3_3: 1;
        uint32_t PAD_P6_E2_3: 1;
        uint32_t PAD_P6_PDPUC_3: 1;
        uint32_t AON_PAD_P6_PU_3: 1;
        uint32_t AON_PAD_P6_PU_EN_3: 1;
        uint32_t PAD_P6_WKPOL_3: 1;
        uint32_t PAD_P6_WKEN_3: 1;
        uint32_t PAD_P6_DEB_3: 1;
        uint32_t PAD_P6_AON_MUX_3: 2;
        uint32_t PAD_P6_O_EN_3: 1;
        uint32_t PAD_P6_HS_MUX_3: 1;
        uint32_t PAD_P6_DUMMY1_3: 1;
    };
} AON_NS_P6_2_P6_3_PAD_CFG_TYPE;

/* 0x1968   0x4000_1968
    0       R/W PAD_P6_SHDN[4]                  1'b1
    1       R/W AON_PAD_P6_E[4]                 1'b0
    2       R/W AON_PAD_P6_O[4]                 1'b0
    3       R/W PAD_P6_E3[4]                    1'b0
    4       R/W PAD_P6_E2[4]                    1'b0
    5       R/W PAD_P6_PDPUC[4]                 1'b0
    6       R/W AON_PAD_P6_PU[4]                1'b0
    7       R/W AON_PAD_P6_PU_EN[4]             1'b1
    8       R/W PAD_P6_WKPOL[4]                 1'b0
    9       R/W PAD_P6_WKEN[4]                  1'b0
    10      R/W PAD_P6_DEB[4]                   1'b0
    12:11   R/W PAD_P6_AON_MUX[4]               2'b0
    13      R/W PAD_P6_O_EN[4]                  1'b1
    14      R/W PAD_P6_HS_MUX[4]                1'b0
    15      R/W PAD_P6_DUMMY1[4]                1'b0
    16      R/W PAD_P6_SHDN[5]                  1'b1
    17      R/W AON_PAD_P6_E[5]                 1'b0
    18      R/W AON_PAD_P6_O[5]                 1'b0
    19      R/W PAD_P6_E3[5]                    1'b0
    20      R/W PAD_P6_E2[5]                    1'b0
    21      R/W PAD_P6_PDPUC[5]                 1'b0
    22      R/W AON_PAD_P6_PU[5]                1'b0
    23      R/W AON_PAD_P6_PU_EN[5]             1'b1
    24      R/W PAD_P6_WKPOL[5]                 1'b0
    25      R/W PAD_P6_WKEN[5]                  1'b0
    26      R/W PAD_P6_DEB[5]                   1'b0
    28:27   R/W PAD_P6_AON_MUX[5]               2'b0
    29      R/W PAD_P6_O_EN[5]                  1'b1
    30      R/W PAD_P6_HS_MUX[5]                1'b0
    31      R/W PAD_P6_DUMMY1[5]                1'b0
 */
typedef volatile union _AON_NS_P6_4_P6_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P6_SHDN_4: 1;
        uint32_t AON_PAD_P6_E_4: 1;
        uint32_t AON_PAD_P6_O_4: 1;
        uint32_t PAD_P6_E3_4: 1;
        uint32_t PAD_P6_E2_4: 1;
        uint32_t PAD_P6_PDPUC_4: 1;
        uint32_t AON_PAD_P6_PU_4: 1;
        uint32_t AON_PAD_P6_PU_EN_4: 1;
        uint32_t PAD_P6_WKPOL_4: 1;
        uint32_t PAD_P6_WKEN_4: 1;
        uint32_t PAD_P6_DEB_4: 1;
        uint32_t PAD_P6_AON_MUX_4: 2;
        uint32_t PAD_P6_O_EN_4: 1;
        uint32_t PAD_P6_HS_MUX_4: 1;
        uint32_t PAD_P6_DUMMY1_4: 1;
        uint32_t PAD_P6_SHDN_5: 1;
        uint32_t AON_PAD_P6_E_5: 1;
        uint32_t AON_PAD_P6_O_5: 1;
        uint32_t PAD_P6_E3_5: 1;
        uint32_t PAD_P6_E2_5: 1;
        uint32_t PAD_P6_PDPUC_5: 1;
        uint32_t AON_PAD_P6_PU_5: 1;
        uint32_t AON_PAD_P6_PU_EN_5: 1;
        uint32_t PAD_P6_WKPOL_5: 1;
        uint32_t PAD_P6_WKEN_5: 1;
        uint32_t PAD_P6_DEB_5: 1;
        uint32_t PAD_P6_AON_MUX_5: 2;
        uint32_t PAD_P6_O_EN_5: 1;
        uint32_t PAD_P6_HS_MUX_5: 1;
        uint32_t PAD_P6_DUMMY1_5: 1;
    };
} AON_NS_P6_4_P6_5_PAD_CFG_TYPE;

/* 0x196C   0x4000_196c
    0       R/W PAD_P6_SHDN[6]                  1'b1
    1       R/W AON_PAD_P6_E[6]                 1'b0
    2       R/W AON_PAD_P6_O[6]                 1'b0
    3       R/W PAD_P6_E3[6]                    1'b0
    4       R/W PAD_P6_E2[6]                    1'b0
    5       R/W PAD_P6_PDPUC[6]                 1'b0
    6       R/W AON_PAD_P6_PU[6]                1'b0
    7       R/W AON_PAD_P6_PU_EN[6]             1'b1
    8       R/W PAD_P6_WKPOL[6]                 1'b0
    9       R/W PAD_P6_WKEN[6]                  1'b0
    10      R/W PAD_P6_DEB[6]                   1'b0
    12:11   R/W PAD_P6_AON_MUX[6]               2'b0
    13      R/W PAD_P6_O_EN[6]                  1'b1
    14      R/W PAD_P6_HS_MUX[6]                1'b0
    15      R/W PAD_P6_DUMMY1[6]                1'b0
    16      R/W PAD_P6_SHDN[7]                  1'b1
    17      R/W AON_PAD_P6_E[7]                 1'b0
    18      R/W AON_PAD_P6_O[7]                 1'b0
    19      R/W PAD_P6_E3[7]                    1'b0
    20      R/W PAD_P6_E2[7]                    1'b0
    21      R/W PAD_P6_PDPUC[7]                 1'b0
    22      R/W AON_PAD_P6_PU[7]                1'b0
    23      R/W AON_PAD_P6_PU_EN[7]             1'b1
    24      R/W PAD_P6_WKPOL[7]                 1'b0
    25      R/W PAD_P6_WKEN[7]                  1'b0
    26      R/W PAD_P6_DEB[7]                   1'b0
    28:27   R/W PAD_P6_AON_MUX[7]               2'b0
    29      R/W PAD_P6_O_EN[7]                  1'b1
    30      R/W PAD_P6_HS_MUX[7]                1'b0
    31      R/W PAD_P6_DUMMY1[7]                1'b0
 */
typedef volatile union _AON_NS_P6_6_P6_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P6_SHDN_6: 1;
        uint32_t AON_PAD_P6_E_6: 1;
        uint32_t AON_PAD_P6_O_6: 1;
        uint32_t PAD_P6_E3_6: 1;
        uint32_t PAD_P6_E2_6: 1;
        uint32_t PAD_P6_PDPUC_6: 1;
        uint32_t AON_PAD_P6_PU_6: 1;
        uint32_t AON_PAD_P6_PU_EN_6: 1;
        uint32_t PAD_P6_WKPOL_6: 1;
        uint32_t PAD_P6_WKEN_6: 1;
        uint32_t PAD_P6_DEB_6: 1;
        uint32_t PAD_P6_AON_MUX_6: 2;
        uint32_t PAD_P6_O_EN_6: 1;
        uint32_t PAD_P6_HS_MUX_6: 1;
        uint32_t PAD_P6_DUMMY1_6: 1;
        uint32_t PAD_P6_SHDN_7: 1;
        uint32_t AON_PAD_P6_E_7: 1;
        uint32_t AON_PAD_P6_O_7: 1;
        uint32_t PAD_P6_E3_7: 1;
        uint32_t PAD_P6_E2_7: 1;
        uint32_t PAD_P6_PDPUC_7: 1;
        uint32_t AON_PAD_P6_PU_7: 1;
        uint32_t AON_PAD_P6_PU_EN_7: 1;
        uint32_t PAD_P6_WKPOL_7: 1;
        uint32_t PAD_P6_WKEN_7: 1;
        uint32_t PAD_P6_DEB_7: 1;
        uint32_t PAD_P6_AON_MUX_7: 2;
        uint32_t PAD_P6_O_EN_7: 1;
        uint32_t PAD_P6_HS_MUX_7: 1;
        uint32_t PAD_P6_DUMMY1_7: 1;
    };
} AON_NS_P6_6_P6_7_PAD_CFG_TYPE;

/* 0x1970   0x4000_1970
    0       R/W PAD_P7_SHDN[0]                  1'b1
    1       R/W AON_PAD_P7_E[0]                 1'b0
    2       R/W AON_PAD_P7_O[0]                 1'b0
    3       R/W PAD_P7_E3[0]                    1'b0
    4       R/W PAD_P7_E2[0]                    1'b0
    5       R/W PAD_P7_PDPUC[0]                 1'b0
    6       R/W AON_PAD_P7_PU[0]                1'b0
    7       R/W AON_PAD_P7_PU_EN[0]             1'b1
    8       R/W PAD_P7_WKPOL[0]                 1'b0
    9       R/W PAD_P7_WKEN[0]                  1'b0
    10      R/W PAD_P7_DEB[0]                   1'b0
    12:11   R/W PAD_P7_AON_MUX[0]               2'b0
    13      R/W PAD_P7_O_EN[0]                  1'b1
    14      R/W PAD_P7_HS_MUX[0]                1'b0
    15      R/W PAD_P7_DUMMY1[0]                1'b0
    16      R/W PAD_P7_SHDN[1]                  1'b1
    17      R/W AON_PAD_P7_E[1]                 1'b0
    18      R/W AON_PAD_P7_O[1]                 1'b0
    19      R/W PAD_P7_E3[1]                    1'b0
    20      R/W PAD_P7_E2[1]                    1'b0
    21      R/W PAD_P7_PDPUC[1]                 1'b0
    22      R/W AON_PAD_P7_PU[1]                1'b1
    23      R/W AON_PAD_P7_PU_EN[1]             1'b1
    24      R/W PAD_P7_WKPOL[1]                 1'b0
    25      R/W PAD_P7_WKEN[1]                  1'b0
    26      R/W PAD_P7_DEB[1]                   1'b0
    28:27   R/W PAD_P7_AON_MUX[1]               2'b0
    29      R/W PAD_P7_O_EN[1]                  1'b1
    30      R/W PAD_P7_HS_MUX[1]                1'b0
    31      R/W PAD_P7_DUMMY1[1]                1'b0
 */
typedef volatile union _AON_NS_P7_0_P7_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P7_SHDN_0: 1;
        uint32_t AON_PAD_P7_E_0: 1;
        uint32_t AON_PAD_P7_O_0: 1;
        uint32_t PAD_P7_E3_0: 1;
        uint32_t PAD_P7_E2_0: 1;
        uint32_t PAD_P7_PDPUC_0: 1;
        uint32_t AON_PAD_P7_PU_0: 1;
        uint32_t AON_PAD_P7_PU_EN_0: 1;
        uint32_t PAD_P7_WKPOL_0: 1;
        uint32_t PAD_P7_WKEN_0: 1;
        uint32_t PAD_P7_DEB_0: 1;
        uint32_t PAD_P7_AON_MUX_0: 2;
        uint32_t PAD_P7_O_EN_0: 1;
        uint32_t PAD_P7_HS_MUX_0: 1;
        uint32_t PAD_P7_DUMMY1_0: 1;
        uint32_t PAD_P7_SHDN_1: 1;
        uint32_t AON_PAD_P7_E_1: 1;
        uint32_t AON_PAD_P7_O_1: 1;
        uint32_t PAD_P7_E3_1: 1;
        uint32_t PAD_P7_E2_1: 1;
        uint32_t PAD_P7_PDPUC_1: 1;
        uint32_t AON_PAD_P7_PU_1: 1;
        uint32_t AON_PAD_P7_PU_EN_1: 1;
        uint32_t PAD_P7_WKPOL_1: 1;
        uint32_t PAD_P7_WKEN_1: 1;
        uint32_t PAD_P7_DEB_1: 1;
        uint32_t PAD_P7_AON_MUX_1: 2;
        uint32_t PAD_P7_O_EN_1: 1;
        uint32_t PAD_P7_HS_MUX_1: 1;
        uint32_t PAD_P7_DUMMY1_1: 1;
    };
} AON_NS_P7_0_P7_1_PAD_CFG_TYPE;

/* 0x1974   0x4000_1974
    0       R/W PAD_P7_SHDN[2]                  1'b1
    1       R/W AON_PAD_P7_E[2]                 1'b0
    2       R/W AON_PAD_P7_O[2]                 1'b0
    3       R/W PAD_P7_E3[2]                    1'b0
    4       R/W PAD_P7_E2[2]                    1'b0
    5       R/W PAD_P7_PDPUC[2]                 1'b0
    6       R/W AON_PAD_P7_PU[2]                1'b1
    7       R/W AON_PAD_P7_PU_EN[2]             1'b1
    8       R/W PAD_P7_WKPOL[2]                 1'b0
    9       R/W PAD_P7_WKEN[2]                  1'b0
    10      R/W PAD_P7_DEB[2]                   1'b0
    12:11   R/W PAD_P7_AON_MUX[2]               2'b0
    13      R/W PAD_P7_O_EN[2]                  1'b1
    14      R/W PAD_P7_HS_MUX[2]                1'b0
    15      R/W PAD_P7_DUMMY1[2]                1'b0
    16      R/W PAD_P7_SHDN[3]                  1'b1
    17      R/W AON_PAD_P7_E[3]                 1'b0
    18      R/W AON_PAD_P7_O[3]                 1'b0
    19      R/W PAD_P7_E3[3]                    1'b0
    20      R/W PAD_P7_E2[3]                    1'b0
    21      R/W PAD_P7_PDPUC[3]                 1'b0
    22      R/W AON_PAD_P7_PU[3]                1'b0
    23      R/W AON_PAD_P7_PU_EN[3]             1'b1
    24      R/W PAD_P7_WKPOL[3]                 1'b0
    25      R/W PAD_P7_WKEN[3]                  1'b0
    26      R/W PAD_P7_DEB[3]                   1'b0
    28:27   R/W PAD_P7_AON_MUX[3]               2'b0
    29      R/W PAD_P7_O_EN[3]                  1'b1
    30      R/W PAD_P7_HS_MUX[3]                1'b0
    31      R/W SPIC_MUX_SEL_S1                 1'b0
 */
typedef volatile union _AON_NS_P7_2_P7_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P7_SHDN_2: 1;
        uint32_t AON_PAD_P7_E_2: 1;
        uint32_t AON_PAD_P7_O_2: 1;
        uint32_t PAD_P7_E3_2: 1;
        uint32_t PAD_P7_E2_2: 1;
        uint32_t PAD_P7_PDPUC_2: 1;
        uint32_t AON_PAD_P7_PU_2: 1;
        uint32_t AON_PAD_P7_PU_EN_2: 1;
        uint32_t PAD_P7_WKPOL_2: 1;
        uint32_t PAD_P7_WKEN_2: 1;
        uint32_t PAD_P7_DEB_2: 1;
        uint32_t PAD_P7_AON_MUX_2: 2;
        uint32_t PAD_P7_O_EN_2: 1;
        uint32_t PAD_P7_HS_MUX_2: 1;
        uint32_t PAD_P7_DUMMY1_2: 1;
        uint32_t PAD_P7_SHDN_3: 1;
        uint32_t AON_PAD_P7_E_3: 1;
        uint32_t AON_PAD_P7_O_3: 1;
        uint32_t PAD_P7_E3_3: 1;
        uint32_t PAD_P7_E2_3: 1;
        uint32_t PAD_P7_PDPUC_3: 1;
        uint32_t AON_PAD_P7_PU_3: 1;
        uint32_t AON_PAD_P7_PU_EN_3: 1;
        uint32_t PAD_P7_WKPOL_3: 1;
        uint32_t PAD_P7_WKEN_3: 1;
        uint32_t PAD_P7_DEB_3: 1;
        uint32_t PAD_P7_AON_MUX_3: 2;
        uint32_t PAD_P7_O_EN_3: 1;
        uint32_t PAD_P7_HS_MUX_3: 1;
        uint32_t SPIC_MUX_SEL_S1: 1;
    };
} AON_NS_P7_2_P7_3_PAD_CFG_TYPE;

/* 0x1978   0x4000_1978
    0       R/W PAD_P7_SHDN[4]                  1'b1
    1       R/W AON_PAD_P7_E[4]                 1'b0
    2       R/W AON_PAD_P7_O[4]                 1'b0
    3       R/W PAD_P7_E3[4]                    1'b0
    4       R/W PAD_P7_E2[4]                    1'b0
    5       R/W PAD_P7_PDPUC[4]                 1'b0
    6       R/W AON_PAD_P7_PU[4]                1'b0
    7       R/W AON_PAD_P7_PU_EN[4]             1'b1
    8       R/W PAD_P7_WKPOL[4]                 1'b0
    9       R/W PAD_P7_WKEN[4]                  1'b0
    10      R/W PAD_P7_DEB[4]                   1'b0
    12:11   R/W PAD_P7_AON_MUX[4]               2'b0
    13      R/W PAD_P7_O_EN[4]                  1'b1
    14      R/W PAD_P7_HS_MUX[4]                1'b0
    15      R/W PAD_P7_DUMMY1[4]                1'b0
    16      R/W PAD_P7_SHDN[5]                  1'b1
    17      R/W AON_PAD_P7_E[5]                 1'b0
    18      R/W AON_PAD_P7_O[5]                 1'b0
    19      R/W PAD_P7_E3[5]                    1'b0
    20      R/W PAD_P7_E2[5]                    1'b0
    21      R/W PAD_P7_PDPUC[5]                 1'b0
    22      R/W AON_PAD_P7_PU[5]                1'b0
    23      R/W AON_PAD_P7_PU_EN[5]             1'b1
    24      R/W PAD_P7_WKPOL[5]                 1'b0
    25      R/W PAD_P7_WKEN[5]                  1'b0
    26      R/W PAD_P7_DEB[5]                   1'b0
    28:27   R/W PAD_P7_AON_MUX[5]               2'b0
    29      R/W PAD_P7_O_EN[5]                  1'b1
    30      R/W PAD_P7_HS_MUX[5]                1'b0
    31      R/W PAD_P7_DUMMY1[5]                1'b0
 */
typedef volatile union _AON_NS_P7_4_P7_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P7_SHDN_4: 1;
        uint32_t AON_PAD_P7_E_4: 1;
        uint32_t AON_PAD_P7_O_4: 1;
        uint32_t PAD_P7_E3_4: 1;
        uint32_t PAD_P7_E2_4: 1;
        uint32_t PAD_P7_PDPUC_4: 1;
        uint32_t AON_PAD_P7_PU_4: 1;
        uint32_t AON_PAD_P7_PU_EN_4: 1;
        uint32_t PAD_P7_WKPOL_4: 1;
        uint32_t PAD_P7_WKEN_4: 1;
        uint32_t PAD_P7_DEB_4: 1;
        uint32_t PAD_P7_AON_MUX_4: 2;
        uint32_t PAD_P7_O_EN_4: 1;
        uint32_t PAD_P7_HS_MUX_4: 1;
        uint32_t PAD_P7_DUMMY1_4: 1;
        uint32_t PAD_P7_SHDN_5: 1;
        uint32_t AON_PAD_P7_E_5: 1;
        uint32_t AON_PAD_P7_O_5: 1;
        uint32_t PAD_P7_E3_5: 1;
        uint32_t PAD_P7_E2_5: 1;
        uint32_t PAD_P7_PDPUC_5: 1;
        uint32_t AON_PAD_P7_PU_5: 1;
        uint32_t AON_PAD_P7_PU_EN_5: 1;
        uint32_t PAD_P7_WKPOL_5: 1;
        uint32_t PAD_P7_WKEN_5: 1;
        uint32_t PAD_P7_DEB_5: 1;
        uint32_t PAD_P7_AON_MUX_5: 2;
        uint32_t PAD_P7_O_EN_5: 1;
        uint32_t PAD_P7_HS_MUX_5: 1;
        uint32_t PAD_P7_DUMMY1_5: 1;
    };
} AON_NS_P7_4_P7_5_PAD_CFG_TYPE;

/* 0x197C   0x4000_197c
    0       R/W PAD_P7_SHDN[6]                  1'b1
    1       R/W AON_PAD_P7_E[6]                 1'b0
    2       R/W AON_PAD_P7_O[6]                 1'b0
    3       R/W PAD_P7_E3[6]                    1'b0
    4       R/W PAD_P7_E2[6]                    1'b0
    5       R/W PAD_P7_PDPUC[6]                 1'b0
    6       R/W AON_PAD_P7_PU[6]                1'b0
    7       R/W AON_PAD_P7_PU_EN[6]             1'b1
    8       R/W PAD_P7_WKPOL[6]                 1'b0
    9       R/W PAD_P7_WKEN[6]                  1'b0
    10      R/W PAD_P7_DEB[6]                   1'b0
    12:11   R/W PAD_P7_AON_MUX[6]               2'b0
    13      R/W PAD_P7_O_EN[6]                  1'b1
    14      R/W PAD_P7_HS_MUX[6]                1'b0
    15      R/W PAD_P7_DUMMY1[6]                1'b0
    16      R/W PAD_P7_SHDN[7]                  1'b1
    17      R/W AON_PAD_P7_E[7]                 1'b0
    18      R/W AON_PAD_P7_O[7]                 1'b0
    19      R/W PAD_P7_E3[7]                    1'b0
    20      R/W PAD_P7_E2[7]                    1'b0
    21      R/W PAD_P7_PDPUC[7]                 1'b0
    22      R/W AON_PAD_P7_PU[7]                1'b0
    23      R/W AON_PAD_P7_PU_EN[7]             1'b1
    24      R/W PAD_P7_WKPOL[7]                 1'b0
    25      R/W PAD_P7_WKEN[7]                  1'b0
    26      R/W PAD_P7_DEB[7]                   1'b0
    28:27   R/W PAD_P7_AON_MUX[7]               2'b0
    29      R/W PAD_P7_O_EN[7]                  1'b1
    30      R/W PAD_P7_HS_MUX[7]                1'b0
    31      R/W PAD_P7_DUMMY1[7]                1'b0
 */
typedef volatile union _AON_NS_P7_6_P7_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P7_SHDN_6: 1;
        uint32_t AON_PAD_P7_E_6: 1;
        uint32_t AON_PAD_P7_O_6: 1;
        uint32_t PAD_P7_E3_6: 1;
        uint32_t PAD_P7_E2_6: 1;
        uint32_t PAD_P7_PDPUC_6: 1;
        uint32_t AON_PAD_P7_PU_6: 1;
        uint32_t AON_PAD_P7_PU_EN_6: 1;
        uint32_t PAD_P7_WKPOL_6: 1;
        uint32_t PAD_P7_WKEN_6: 1;
        uint32_t PAD_P7_DEB_6: 1;
        uint32_t PAD_P7_AON_MUX_6: 2;
        uint32_t PAD_P7_O_EN_6: 1;
        uint32_t PAD_P7_HS_MUX_6: 1;
        uint32_t PAD_P7_DUMMY1_6: 1;
        uint32_t PAD_P7_SHDN_7: 1;
        uint32_t AON_PAD_P7_E_7: 1;
        uint32_t AON_PAD_P7_O_7: 1;
        uint32_t PAD_P7_E3_7: 1;
        uint32_t PAD_P7_E2_7: 1;
        uint32_t PAD_P7_PDPUC_7: 1;
        uint32_t AON_PAD_P7_PU_7: 1;
        uint32_t AON_PAD_P7_PU_EN_7: 1;
        uint32_t PAD_P7_WKPOL_7: 1;
        uint32_t PAD_P7_WKEN_7: 1;
        uint32_t PAD_P7_DEB_7: 1;
        uint32_t PAD_P7_AON_MUX_7: 2;
        uint32_t PAD_P7_O_EN_7: 1;
        uint32_t PAD_P7_HS_MUX_7: 1;
        uint32_t PAD_P7_DUMMY1_7: 1;
    };
} AON_NS_P7_6_P7_7_PAD_CFG_TYPE;

/* 0x1980   0x4000_1980
    0       R/W PAD_P8_SHDN[0]                  1'b1
    1       R/W AON_PAD_P8_E[0]                 1'b0
    2       R/W AON_PAD_P8_O[0]                 1'b0
    3       R/W PAD_P8_E3[0]                    1'b0
    4       R/W PAD_P8_E2[0]                    1'b0
    5       R/W PAD_P8_PDPUC[0]                 1'b0
    6       R/W AON_PAD_P8_PU[0]                1'b0
    7       R/W AON_PAD_P8_PU_EN[0]             1'b1
    8       R/W PAD_P8_WKPOL[0]                 1'b0
    9       R/W PAD_P8_WKEN[0]                  1'b0
    10      R/W PAD_P8_DEB[0]                   1'b0
    12:11   R/W PAD_P8_AON_MUX[0]               2'b0
    13      R/W PAD_P8_O_EN[0]                  1'b1
    14      R/W PAD_P8_HS_MUX[0]                1'b0
    15      R/W PAD_P8_DUMMY1[0]                1'b0
    16      R/W PAD_P8_SHDN[1]                  1'b1
    17      R/W AON_PAD_P8_E[1]                 1'b0
    18      R/W AON_PAD_P8_O[1]                 1'b0
    19      R/W PAD_P8_E3[1]                    1'b0
    20      R/W PAD_P8_E2[1]                    1'b0
    21      R/W PAD_P8_PDPUC[1]                 1'b0
    22      R/W AON_PAD_P8_PU[1]                1'b0
    23      R/W AON_PAD_P8_PU_EN[1]             1'b1
    24      R/W PAD_P8_WKPOL[1]                 1'b0
    25      R/W PAD_P8_WKEN[1]                  1'b0
    26      R/W PAD_P8_DEB[1]                   1'b0
    28:27   R/W PAD_P8_AON_MUX[1]               2'b0
    29      R/W PAD_P8_O_EN[1]                  1'b1
    30      R/W PAD_P8_HS_MUX[1]                1'b0
    31      R/W SPIC2_PULL_SEL_SIO3_PULL_CTRL   1'b0
 */
typedef volatile union _AON_NS_P8_0_P8_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P8_SHDN_0: 1;
        uint32_t AON_PAD_P8_E_0: 1;
        uint32_t AON_PAD_P8_O_0: 1;
        uint32_t PAD_P8_E3_0: 1;
        uint32_t PAD_P8_E2_0: 1;
        uint32_t PAD_P8_PDPUC_0: 1;
        uint32_t AON_PAD_P8_PU_0: 1;
        uint32_t AON_PAD_P8_PU_EN_0: 1;
        uint32_t PAD_P8_WKPOL_0: 1;
        uint32_t PAD_P8_WKEN_0: 1;
        uint32_t PAD_P8_DEB_0: 1;
        uint32_t PAD_P8_AON_MUX_0: 2;
        uint32_t PAD_P8_O_EN_0: 1;
        uint32_t PAD_P8_HS_MUX_0: 1;
        uint32_t PAD_P8_DUMMY1_0: 1;
        uint32_t PAD_P8_SHDN_1: 1;
        uint32_t AON_PAD_P8_E_1: 1;
        uint32_t AON_PAD_P8_O_1: 1;
        uint32_t PAD_P8_E3_1: 1;
        uint32_t PAD_P8_E2_1: 1;
        uint32_t PAD_P8_PDPUC_1: 1;
        uint32_t AON_PAD_P8_PU_1: 1;
        uint32_t AON_PAD_P8_PU_EN_1: 1;
        uint32_t PAD_P8_WKPOL_1: 1;
        uint32_t PAD_P8_WKEN_1: 1;
        uint32_t PAD_P8_DEB_1: 1;
        uint32_t PAD_P8_AON_MUX_1: 2;
        uint32_t PAD_P8_O_EN_1: 1;
        uint32_t PAD_P8_HS_MUX_1: 1;
        uint32_t SPIC2_PULL_SEL_SIO3_PULL_CTRL: 1;
    };
} AON_NS_P8_0_P8_1_PAD_CFG_TYPE;

/* 0x1984   0x4000_1984
    0       R/W PAD_P8_SHDN[2]                  1'b1
    1       R/W AON_PAD_P8_E[2]                 1'b0
    2       R/W AON_PAD_P8_O[2]                 1'b0
    3       R/W PAD_P8_E3[2]                    1'b0
    4       R/W PAD_P8_E2[2]                    1'b0
    5       R/W PAD_P8_PDPUC[2]                 1'b0
    6       R/W AON_PAD_P8_PU[2]                1'b0
    7       R/W AON_PAD_P8_PU_EN[2]             1'b1
    8       R/W PAD_P8_WKPOL[2]                 1'b0
    9       R/W PAD_P8_WKEN[2]                  1'b0
    10      R/W PAD_P8_DEB[2]                   1'b0
    12:11   R/W PAD_P8_AON_MUX[2]               2'b0
    13      R/W PAD_P8_O_EN[2]                  1'b1
    14      R/W PAD_P8_HS_MUX[2]                1'b0
    15      R/W SPIC2_PULL_SEL_SIO2_PULL_CTRL   1'b0
    16      R/W PAD_P8_SHDN[3]                  1'b1
    17      R/W AON_PAD_P8_E[3]                 1'b0
    18      R/W AON_PAD_P8_O[3]                 1'b0
    19      R/W PAD_P8_E3[3]                    1'b0
    20      R/W PAD_P8_E2[3]                    1'b0
    21      R/W PAD_P8_PDPUC[3]                 1'b0
    22      R/W AON_PAD_P8_PU[3]                1'b0
    23      R/W AON_PAD_P8_PU_EN[3]             1'b1
    24      R/W PAD_P8_WKPOL[3]                 1'b0
    25      R/W PAD_P8_WKEN[3]                  1'b0
    26      R/W PAD_P8_DEB[3]                   1'b0
    28:27   R/W PAD_P8_AON_MUX[3]               2'b0
    29      R/W PAD_P8_O_EN[3]                  1'b1
    30      R/W PAD_P8_HS_MUX[3]                1'b0
    31      R/W SPIC2_PULL_SEL_SIO1_PULL_CTRL   1'b0
 */
typedef volatile union _AON_NS_P8_2_P8_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P8_SHDN_2: 1;
        uint32_t AON_PAD_P8_E_2: 1;
        uint32_t AON_PAD_P8_O_2: 1;
        uint32_t PAD_P8_E3_2: 1;
        uint32_t PAD_P8_E2_2: 1;
        uint32_t PAD_P8_PDPUC_2: 1;
        uint32_t AON_PAD_P8_PU_2: 1;
        uint32_t AON_PAD_P8_PU_EN_2: 1;
        uint32_t PAD_P8_WKPOL_2: 1;
        uint32_t PAD_P8_WKEN_2: 1;
        uint32_t PAD_P8_DEB_2: 1;
        uint32_t PAD_P8_AON_MUX_2: 2;
        uint32_t PAD_P8_O_EN_2: 1;
        uint32_t PAD_P8_HS_MUX_2: 1;
        uint32_t SPIC2_PULL_SEL_SIO2_PULL_CTRL: 1;
        uint32_t PAD_P8_SHDN_3: 1;
        uint32_t AON_PAD_P8_E_3: 1;
        uint32_t AON_PAD_P8_O_3: 1;
        uint32_t PAD_P8_E3_3: 1;
        uint32_t PAD_P8_E2_3: 1;
        uint32_t PAD_P8_PDPUC_3: 1;
        uint32_t AON_PAD_P8_PU_3: 1;
        uint32_t AON_PAD_P8_PU_EN_3: 1;
        uint32_t PAD_P8_WKPOL_3: 1;
        uint32_t PAD_P8_WKEN_3: 1;
        uint32_t PAD_P8_DEB_3: 1;
        uint32_t PAD_P8_AON_MUX_3: 2;
        uint32_t PAD_P8_O_EN_3: 1;
        uint32_t PAD_P8_HS_MUX_3: 1;
        uint32_t SPIC2_PULL_SEL_SIO1_PULL_CTRL: 1;
    };
} AON_NS_P8_2_P8_3_PAD_CFG_TYPE;

/* 0x1988   0x4000_1988
    0       R/W PAD_P8_SHDN[4]                  1'b1
    1       R/W AON_PAD_P8_E[4]                 1'b0
    2       R/W AON_PAD_P8_O[4]                 1'b0
    3       R/W PAD_P8_E3[4]                    1'b0
    4       R/W PAD_P8_E2[4]                    1'b0
    5       R/W PAD_P8_PDPUC[4]                 1'b0
    6       R/W AON_PAD_P8_PU[4]                1'b0
    7       R/W AON_PAD_P8_PU_EN[4]             1'b1
    8       R/W PAD_P8_WKPOL[4]                 1'b0
    9       R/W PAD_P8_WKEN[4]                  1'b0
    10      R/W PAD_P8_DEB[4]                   1'b0
    12:11   R/W PAD_P8_AON_MUX[4]               2'b0
    13      R/W PAD_P8_O_EN[4]                  1'b1
    14      R/W PAD_P8_HS_MUX[4]                1'b0
    15      R/W SPIC2_PULL_SEL_SIO0_PULL_CTRL   1'b0
    16      R/W PAD_P8_SHDN[5]                  1'b1
    17      R/W AON_PAD_P8_E[5]                 1'b0
    18      R/W AON_PAD_P8_O[5]                 1'b0
    19      R/W PAD_P8_E3[5]                    1'b0
    20      R/W PAD_P8_E2[5]                    1'b0
    21      R/W PAD_P8_PDPUC[5]                 1'b0
    22      R/W AON_PAD_P8_PU[5]                1'b0
    23      R/W AON_PAD_P8_PU_EN[5]             1'b1
    24      R/W PAD_P8_WKPOL[5]                 1'b0
    25      R/W PAD_P8_WKEN[5]                  1'b0
    26      R/W PAD_P8_DEB[5]                   1'b0
    28:27   R/W PAD_P8_AON_MUX[5]               2'b0
    29      R/W PAD_P8_O_EN[5]                  1'b1
    30      R/W PAD_P8_HS_MUX[5]                1'b0
    31      R/W PAD_P8_DUMMY1[5]                1'b0
 */
typedef volatile union _AON_NS_P8_4_P8_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P8_SHDN_4: 1;
        uint32_t AON_PAD_P8_E_4: 1;
        uint32_t AON_PAD_P8_O_4: 1;
        uint32_t PAD_P8_E3_4: 1;
        uint32_t PAD_P8_E2_4: 1;
        uint32_t PAD_P8_PDPUC_4: 1;
        uint32_t AON_PAD_P8_PU_4: 1;
        uint32_t AON_PAD_P8_PU_EN_4: 1;
        uint32_t PAD_P8_WKPOL_4: 1;
        uint32_t PAD_P8_WKEN_4: 1;
        uint32_t PAD_P8_DEB_4: 1;
        uint32_t PAD_P8_AON_MUX_4: 2;
        uint32_t PAD_P8_O_EN_4: 1;
        uint32_t PAD_P8_HS_MUX_4: 1;
        uint32_t SPIC2_PULL_SEL_SIO0_PULL_CTRL: 1;
        uint32_t PAD_P8_SHDN_5: 1;
        uint32_t AON_PAD_P8_E_5: 1;
        uint32_t AON_PAD_P8_O_5: 1;
        uint32_t PAD_P8_E3_5: 1;
        uint32_t PAD_P8_E2_5: 1;
        uint32_t PAD_P8_PDPUC_5: 1;
        uint32_t AON_PAD_P8_PU_5: 1;
        uint32_t AON_PAD_P8_PU_EN_5: 1;
        uint32_t PAD_P8_WKPOL_5: 1;
        uint32_t PAD_P8_WKEN_5: 1;
        uint32_t PAD_P8_DEB_5: 1;
        uint32_t PAD_P8_AON_MUX_5: 2;
        uint32_t PAD_P8_O_EN_5: 1;
        uint32_t PAD_P8_HS_MUX_5: 1;
        uint32_t PAD_P8_DUMMY1_5: 1;
    };
} AON_NS_P8_4_P8_5_PAD_CFG_TYPE;

/* 0x198C   0x4000_198c
    0       R/W PAD_P8_SHDN[6]                  1'b1
    1       R/W AON_PAD_P8_E[6]                 1'b0
    2       R/W AON_PAD_P8_O[6]                 1'b0
    3       R/W PAD_P8_E3[6]                    1'b0
    4       R/W PAD_P8_E2[6]                    1'b0
    5       R/W PAD_P8_PDPUC[6]                 1'b0
    6       R/W AON_PAD_P8_PU[6]                1'b0
    7       R/W AON_PAD_P8_PU_EN[6]             1'b1
    8       R/W PAD_P8_WKPOL[6]                 1'b0
    9       R/W PAD_P8_WKEN[6]                  1'b0
    10      R/W PAD_P8_DEB[6]                   1'b0
    12:11   R/W PAD_P8_AON_MUX[6]               2'b0
    13      R/W PAD_P8_O_EN[6]                  1'b1
    14      R/W PAD_P8_DUMMY0[6]                1'b0
    15      R/W PAD_P8_DUMMY1[6]                1'b0
    16      R/W PAD_P8_SHDN[7]                  1'b1
    17      R/W AON_PAD_P8_E[7]                 1'b0
    18      R/W AON_PAD_P8_O[7]                 1'b0
    19      R/W PAD_P8_E3[7]                    1'b0
    20      R/W PAD_P8_E2[7]                    1'b0
    21      R/W PAD_P8_PDPUC[7]                 1'b0
    22      R/W AON_PAD_P8_PU[7]                1'b1
    23      R/W AON_PAD_P8_PU_EN[7]             1'b1
    24      R/W PAD_P8_WKPOL[7]                 1'b0
    25      R/W PAD_P8_WKEN[7]                  1'b0
    26      R/W PAD_P8_DEB[7]                   1'b0
    28:27   R/W PAD_P8_AON_MUX[7]               2'b0
    29      R/W PAD_P8_O_EN[7]                  1'b1
    30      R/W PAD_P8_DUMMY0[7]                1'b0
    31      R/W PAD_P8_DUMMY1[7]                1'b0
 */
typedef volatile union _AON_NS_P8_6_P8_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P8_SHDN_6: 1;
        uint32_t AON_PAD_P8_E_6: 1;
        uint32_t AON_PAD_P8_O_6: 1;
        uint32_t PAD_P8_E3_6: 1;
        uint32_t PAD_P8_E2_6: 1;
        uint32_t PAD_P8_PDPUC_6: 1;
        uint32_t AON_PAD_P8_PU_6: 1;
        uint32_t AON_PAD_P8_PU_EN_6: 1;
        uint32_t PAD_P8_WKPOL_6: 1;
        uint32_t PAD_P8_WKEN_6: 1;
        uint32_t PAD_P8_DEB_6: 1;
        uint32_t PAD_P8_AON_MUX_6: 2;
        uint32_t PAD_P8_O_EN_6: 1;
        uint32_t PAD_P8_DUMMY0_6: 1;
        uint32_t PAD_P8_DUMMY1_6: 1;
        uint32_t PAD_P8_SHDN_7: 1;
        uint32_t AON_PAD_P8_E_7: 1;
        uint32_t AON_PAD_P8_O_7: 1;
        uint32_t PAD_P8_E3_7: 1;
        uint32_t PAD_P8_E2_7: 1;
        uint32_t PAD_P8_PDPUC_7: 1;
        uint32_t AON_PAD_P8_PU_7: 1;
        uint32_t AON_PAD_P8_PU_EN_7: 1;
        uint32_t PAD_P8_WKPOL_7: 1;
        uint32_t PAD_P8_WKEN_7: 1;
        uint32_t PAD_P8_DEB_7: 1;
        uint32_t PAD_P8_AON_MUX_7: 2;
        uint32_t PAD_P8_O_EN_7: 1;
        uint32_t PAD_P8_DUMMY0_7: 1;
        uint32_t PAD_P8_DUMMY1_7: 1;
    };
} AON_NS_P8_6_P8_7_PAD_CFG_TYPE;

/* 0x1990   0x4000_1990
    0       R/W PAD_P9_SHDN[0]                  1'b1
    1       R/W AON_PAD_P9_E[0]                 1'b0
    2       R/W AON_PAD_P9_O[0]                 1'b0
    3       R/W PAD_P9_E3[0]                    1'b0
    4       R/W PAD_P9_E2[0]                    1'b0
    5       R/W PAD_P9_PDPUC[0]                 1'b0
    6       R/W AON_PAD_P9_PU[0]                1'b0
    7       R/W AON_PAD_P9_PU_EN[0]             1'b1
    8       R/W PAD_P9_WKPOL[0]                 1'b0
    9       R/W PAD_P9_WKEN[0]                  1'b0
    10      R/W PAD_P9_DEB[0]                   1'b0
    12:11   R/W PAD_P9_AON_MUX[0]               2'b0
    13      R/W PAD_P9_O_EN[0]                  1'b1
    14      R/W PAD_P9_DUMMY0[0]                1'b0
    15      R/W PAD_P9_DUMMY1[0]                1'b0
    16      R/W PAD_P9_SHDN[1]                  1'b1
    17      R/W AON_PAD_P9_E[1]                 1'b0
    18      R/W AON_PAD_P9_O[1]                 1'b0
    19      R/W PAD_P9_E3[1]                    1'b0
    20      R/W PAD_P9_E2[1]                    1'b0
    21      R/W PAD_P9_PDPUC[1]                 1'b0
    22      R/W AON_PAD_P9_PU[1]                1'b0
    23      R/W AON_PAD_P9_PU_EN[1]             1'b1
    24      R/W PAD_P9_WKPOL[1]                 1'b0
    25      R/W PAD_P9_WKEN[1]                  1'b0
    26      R/W PAD_P9_DEB[1]                   1'b0
    28:27   R/W PAD_P9_AON_MUX[1]               2'b0
    29      R/W PAD_P9_O_EN[1]                  1'b1
    30      R/W PAD_P9_DUMMY0[1]                1'b0
    31      R/W PAD_P9_DUMMY1[1]                1'b0
 */
typedef volatile union _AON_NS_P9_0_P9_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P9_SHDN_0: 1;
        uint32_t AON_PAD_P9_E_0: 1;
        uint32_t AON_PAD_P9_O_0: 1;
        uint32_t PAD_P9_E3_0: 1;
        uint32_t PAD_P9_E2_0: 1;
        uint32_t PAD_P9_PDPUC_0: 1;
        uint32_t AON_PAD_P9_PU_0: 1;
        uint32_t AON_PAD_P9_PU_EN_0: 1;
        uint32_t PAD_P9_WKPOL_0: 1;
        uint32_t PAD_P9_WKEN_0: 1;
        uint32_t PAD_P9_DEB_0: 1;
        uint32_t PAD_P9_AON_MUX_0: 2;
        uint32_t PAD_P9_O_EN_0: 1;
        uint32_t PAD_P9_DUMMY0_0: 1;
        uint32_t PAD_P9_DUMMY1_0: 1;
        uint32_t PAD_P9_SHDN_1: 1;
        uint32_t AON_PAD_P9_E_1: 1;
        uint32_t AON_PAD_P9_O_1: 1;
        uint32_t PAD_P9_E3_1: 1;
        uint32_t PAD_P9_E2_1: 1;
        uint32_t PAD_P9_PDPUC_1: 1;
        uint32_t AON_PAD_P9_PU_1: 1;
        uint32_t AON_PAD_P9_PU_EN_1: 1;
        uint32_t PAD_P9_WKPOL_1: 1;
        uint32_t PAD_P9_WKEN_1: 1;
        uint32_t PAD_P9_DEB_1: 1;
        uint32_t PAD_P9_AON_MUX_1: 2;
        uint32_t PAD_P9_O_EN_1: 1;
        uint32_t PAD_P9_DUMMY0_1: 1;
        uint32_t PAD_P9_DUMMY1_1: 1;
    };
} AON_NS_P9_0_P9_1_PAD_CFG_TYPE;

/* 0x1994   0x4000_1994
    0       R/W PAD_P9_SHDN[2]                  1'b1
    1       R/W AON_PAD_P9_E[2]                 1'b0
    2       R/W AON_PAD_P9_O[2]                 1'b0
    3       R/W PAD_P9_E3[2]                    1'b0
    4       R/W PAD_P9_E2[2]                    1'b0
    5       R/W PAD_P9_PDPUC[2]                 1'b0
    6       R/W AON_PAD_P9_PU[2]                1'b0
    7       R/W AON_PAD_P9_PU_EN[2]             1'b1
    8       R/W PAD_P9_WKPOL[2]                 1'b0
    9       R/W PAD_P9_WKEN[2]                  1'b0
    10      R/W PAD_P9_DEB[2]                   1'b0
    12:11   R/W PAD_P9_AON_MUX[2]               2'b0
    13      R/W PAD_P9_O_EN[2]                  1'b1
    14      R/W PAD_P9_DUMMY0[2]                1'b0
    15      R/W PAD_P9_DUMMY1[2]                1'b0
    16      R/W PAD_P9_SHDN[3]                  1'b1
    17      R/W AON_PAD_P9_E[3]                 1'b0
    18      R/W AON_PAD_P9_O[3]                 1'b0
    19      R/W PAD_P9_E3[3]                    1'b0
    20      R/W PAD_P9_E2[3]                    1'b0
    21      R/W PAD_P9_PDPUC[3]                 1'b0
    22      R/W AON_PAD_P9_PU[3]                1'b0
    23      R/W AON_PAD_P9_PU_EN[3]             1'b1
    24      R/W PAD_P9_WKPOL[3]                 1'b0
    25      R/W PAD_P9_WKEN[3]                  1'b0
    26      R/W PAD_P9_DEB[3]                   1'b0
    28:27   R/W PAD_P9_AON_MUX[3]               2'b0
    29      R/W PAD_P9_O_EN[3]                  1'b1
    30      R/W PAD_P9_DUMMY0[3]                1'b0
    31      R/W PAD_P9_DUMMY1[3]                1'b0
 */
typedef volatile union _AON_NS_P9_2_P9_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P9_SHDN_2: 1;
        uint32_t AON_PAD_P9_E_2: 1;
        uint32_t AON_PAD_P9_O_2: 1;
        uint32_t PAD_P9_E3_2: 1;
        uint32_t PAD_P9_E2_2: 1;
        uint32_t PAD_P9_PDPUC_2: 1;
        uint32_t AON_PAD_P9_PU_2: 1;
        uint32_t AON_PAD_P9_PU_EN_2: 1;
        uint32_t PAD_P9_WKPOL_2: 1;
        uint32_t PAD_P9_WKEN_2: 1;
        uint32_t PAD_P9_DEB_2: 1;
        uint32_t PAD_P9_AON_MUX_2: 2;
        uint32_t PAD_P9_O_EN_2: 1;
        uint32_t PAD_P9_DUMMY0_2: 1;
        uint32_t PAD_P9_DUMMY1_2: 1;
        uint32_t PAD_P9_SHDN_3: 1;
        uint32_t AON_PAD_P9_E_3: 1;
        uint32_t AON_PAD_P9_O_3: 1;
        uint32_t PAD_P9_E3_3: 1;
        uint32_t PAD_P9_E2_3: 1;
        uint32_t PAD_P9_PDPUC_3: 1;
        uint32_t AON_PAD_P9_PU_3: 1;
        uint32_t AON_PAD_P9_PU_EN_3: 1;
        uint32_t PAD_P9_WKPOL_3: 1;
        uint32_t PAD_P9_WKEN_3: 1;
        uint32_t PAD_P9_DEB_3: 1;
        uint32_t PAD_P9_AON_MUX_3: 2;
        uint32_t PAD_P9_O_EN_3: 1;
        uint32_t PAD_P9_DUMMY0_3: 1;
        uint32_t PAD_P9_DUMMY1_3: 1;
    };
} AON_NS_P9_2_P9_3_PAD_CFG_TYPE;

/* 0x1998   0x4000_1998
    0       R/W PAD_P9_SHDN[4]                  1'b1
    1       R/W AON_PAD_P9_E[4]                 1'b0
    2       R/W AON_PAD_P9_O[4]                 1'b0
    3       R/W PAD_P9_E3[4]                    1'b0
    4       R/W PAD_P9_E2[4]                    1'b0
    5       R/W PAD_P9_PDPUC[4]                 1'b0
    6       R/W AON_PAD_P9_PU[4]                1'b0
    7       R/W AON_PAD_P9_PU_EN[4]             1'b1
    8       R/W PAD_P9_WKPOL[4]                 1'b0
    9       R/W PAD_P9_WKEN[4]                  1'b0
    10      R/W PAD_P9_DEB[4]                   1'b0
    12:11   R/W PAD_P9_AON_MUX[4]               2'b0
    13      R/W PAD_P9_O_EN[4]                  1'b1
    14      R/W PAD_P9_DUMMY0[4]                1'b0
    15      R/W PAD_P9_DUMMY1[4]                1'b0
    16      R/W PAD_P9_SHDN[5]                  1'b1
    17      R/W AON_PAD_P9_E[5]                 1'b0
    18      R/W AON_PAD_P9_O[5]                 1'b0
    19      R/W PAD_P9_E3[5]                    1'b0
    20      R/W PAD_P9_E2[5]                    1'b0
    21      R/W PAD_P9_PDPUC[5]                 1'b0
    22      R/W AON_PAD_P9_PU[5]                1'b0
    23      R/W AON_PAD_P9_PU_EN[5]             1'b1
    24      R/W PAD_P9_WKPOL[5]                 1'b0
    25      R/W PAD_P9_WKEN[5]                  1'b0
    26      R/W PAD_P9_DEB[5]                   1'b0
    28:27   R/W PAD_P9_AON_MUX[5]               2'b0
    29      R/W PAD_P9_O_EN[5]                  1'b1
    30      R/W PAD_P9_DUMMY0[5]                1'b0
    31      R/W PAD_P9_DUMMY1[5]                1'b0
 */
typedef volatile union _AON_NS_P9_4_P9_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P9_SHDN_4: 1;
        uint32_t AON_PAD_P9_E_4: 1;
        uint32_t AON_PAD_P9_O_4: 1;
        uint32_t PAD_P9_E3_4: 1;
        uint32_t PAD_P9_E2_4: 1;
        uint32_t PAD_P9_PDPUC_4: 1;
        uint32_t AON_PAD_P9_PU_4: 1;
        uint32_t AON_PAD_P9_PU_EN_4: 1;
        uint32_t PAD_P9_WKPOL_4: 1;
        uint32_t PAD_P9_WKEN_4: 1;
        uint32_t PAD_P9_DEB_4: 1;
        uint32_t PAD_P9_AON_MUX_4: 2;
        uint32_t PAD_P9_O_EN_4: 1;
        uint32_t PAD_P9_DUMMY0_4: 1;
        uint32_t PAD_P9_DUMMY1_4: 1;
        uint32_t PAD_P9_SHDN_5: 1;
        uint32_t AON_PAD_P9_E_5: 1;
        uint32_t AON_PAD_P9_O_5: 1;
        uint32_t PAD_P9_E3_5: 1;
        uint32_t PAD_P9_E2_5: 1;
        uint32_t PAD_P9_PDPUC_5: 1;
        uint32_t AON_PAD_P9_PU_5: 1;
        uint32_t AON_PAD_P9_PU_EN_5: 1;
        uint32_t PAD_P9_WKPOL_5: 1;
        uint32_t PAD_P9_WKEN_5: 1;
        uint32_t PAD_P9_DEB_5: 1;
        uint32_t PAD_P9_AON_MUX_5: 2;
        uint32_t PAD_P9_O_EN_5: 1;
        uint32_t PAD_P9_DUMMY0_5: 1;
        uint32_t PAD_P9_DUMMY1_5: 1;
    };
} AON_NS_P9_4_P9_5_PAD_CFG_TYPE;

/* 0x199C   0x4000_199c
    0       R/W PAD_P9_SHDN[6]                  1'b1
    1       R/W AON_PAD_P9_E[6]                 1'b0
    2       R/W AON_PAD_P9_O[6]                 1'b0
    3       R/W PAD_P9_E3[6]                    1'b0
    4       R/W PAD_P9_E2[6]                    1'b0
    5       R/W PAD_P9_PDPUC[6]                 1'b0
    6       R/W AON_PAD_P9_PU[6]                1'b0
    7       R/W AON_PAD_P9_PU_EN[6]             1'b1
    8       R/W PAD_P9_WKPOL[6]                 1'b0
    9       R/W PAD_P9_WKEN[6]                  1'b0
    10      R/W PAD_P9_DEB[6]                   1'b0
    12:11   R/W PAD_P9_AON_MUX[6]               2'b0
    13      R/W PAD_P9_O_EN[6]                  1'b1
    14      R/W PAD_P9_DUMMY0[6]                1'b0
    15      R/W PAD_P9_DUMMY1[6]                1'b0
    16      R/W PAD_P9_SHDN[7]                  1'b1
    17      R/W AON_PAD_P9_E[7]                 1'b0
    18      R/W AON_PAD_P9_O[7]                 1'b0
    19      R/W PAD_P9_E3[7]                    1'b0
    20      R/W PAD_P9_E2[7]                    1'b0
    21      R/W PAD_P9_PDPUC[7]                 1'b0
    22      R/W AON_PAD_P9_PU[7]                1'b0
    23      R/W AON_PAD_P9_PU_EN[7]             1'b1
    24      R/W PAD_P9_WKPOL[7]                 1'b0
    25      R/W PAD_P9_WKEN[7]                  1'b0
    26      R/W PAD_P9_DEB[7]                   1'b0
    28:27   R/W PAD_P9_AON_MUX[7]               2'b0
    29      R/W PAD_P9_O_EN[7]                  1'b1
    30      R/W PAD_P9_DUMMY0[7]                1'b0
    31      R/W PAD_P9_DUMMY1[7]                1'b0
 */
typedef volatile union _AON_NS_P9_6_P9_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P9_SHDN_6: 1;
        uint32_t AON_PAD_P9_E_6: 1;
        uint32_t AON_PAD_P9_O_6: 1;
        uint32_t PAD_P9_E3_6: 1;
        uint32_t PAD_P9_E2_6: 1;
        uint32_t PAD_P9_PDPUC_6: 1;
        uint32_t AON_PAD_P9_PU_6: 1;
        uint32_t AON_PAD_P9_PU_EN_6: 1;
        uint32_t PAD_P9_WKPOL_6: 1;
        uint32_t PAD_P9_WKEN_6: 1;
        uint32_t PAD_P9_DEB_6: 1;
        uint32_t PAD_P9_AON_MUX_6: 2;
        uint32_t PAD_P9_O_EN_6: 1;
        uint32_t PAD_P9_DUMMY0_6: 1;
        uint32_t PAD_P9_DUMMY1_6: 1;
        uint32_t PAD_P9_SHDN_7: 1;
        uint32_t AON_PAD_P9_E_7: 1;
        uint32_t AON_PAD_P9_O_7: 1;
        uint32_t PAD_P9_E3_7: 1;
        uint32_t PAD_P9_E2_7: 1;
        uint32_t PAD_P9_PDPUC_7: 1;
        uint32_t AON_PAD_P9_PU_7: 1;
        uint32_t AON_PAD_P9_PU_EN_7: 1;
        uint32_t PAD_P9_WKPOL_7: 1;
        uint32_t PAD_P9_WKEN_7: 1;
        uint32_t PAD_P9_DEB_7: 1;
        uint32_t PAD_P9_AON_MUX_7: 2;
        uint32_t PAD_P9_O_EN_7: 1;
        uint32_t PAD_P9_DUMMY0_7: 1;
        uint32_t PAD_P9_DUMMY1_7: 1;
    };
} AON_NS_P9_6_P9_7_PAD_CFG_TYPE;

/* 0x19A0   0x4000_19a0
    0       R/W PAD_P10_SHDN[0]                 1'b1
    1       R/W AON_PAD_P10_E[0]                1'b0
    2       R/W AON_PAD_P10_O[0]                1'b0
    3       R/W PAD_P10_E3[0]                   1'b0
    4       R/W PAD_P10_E2[0]                   1'b0
    5       R/W PAD_P10_PDPUC[0]                1'b0
    6       R/W AON_PAD_P10_PU[0]               1'b0
    7       R/W AON_PAD_P10_PU_EN[0]            1'b1
    8       R/W PAD_P10_WKPOL[0]                1'b0
    9       R/W PAD_P10_WKEN[0]                 1'b0
    10      R/W PAD_P10_DEB[0]                  1'b0
    12:11   R/W PAD_P10_AON_MUX[0]              2'b0
    13      R/W PAD_P10_O_EN[0]                 1'b1
    14      R/W PAD_P10_HS_MUX[0]               1'b0
    15      R/W PAD_P10_DUMMY1[0]               1'b0
    16      R/W PAD_P10_SHDN[1]                 1'b1
    17      R/W AON_PAD_P10_E[1]                1'b0
    18      R/W AON_PAD_P10_O[1]                1'b0
    19      R/W PAD_P10_E3[1]                   1'b0
    20      R/W PAD_P10_E2[1]                   1'b0
    21      R/W PAD_P10_PDPUC[1]                1'b0
    22      R/W AON_PAD_P10_PU[1]               1'b0
    23      R/W AON_PAD_P10_PU_EN[1]            1'b1
    24      R/W PAD_P10_WKPOL[1]                1'b0
    25      R/W PAD_P10_WKEN[1]                 1'b0
    26      R/W PAD_P10_DEB[1]                  1'b0
    28:27   R/W PAD_P10_AON_MUX[1]              2'b0
    29      R/W PAD_P10_O_EN[1]                 1'b1
    30      R/W PAD_P10_HS_MUX[1]               1'b0
    31      R/W PAD_P10_DUMMY1[1]               1'b0
 */
typedef volatile union _AON_NS_P10_0_P10_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P10_SHDN_0: 1;
        uint32_t AON_PAD_P10_E_0: 1;
        uint32_t AON_PAD_P10_O_0: 1;
        uint32_t PAD_P10_E3_0: 1;
        uint32_t PAD_P10_E2_0: 1;
        uint32_t PAD_P10_PDPUC_0: 1;
        uint32_t AON_PAD_P10_PU_0: 1;
        uint32_t AON_PAD_P10_PU_EN_0: 1;
        uint32_t PAD_P10_WKPOL_0: 1;
        uint32_t PAD_P10_WKEN_0: 1;
        uint32_t PAD_P10_DEB_0: 1;
        uint32_t PAD_P10_AON_MUX_0: 2;
        uint32_t PAD_P10_O_EN_0: 1;
        uint32_t PAD_P10_HS_MUX_0: 1;
        uint32_t PAD_P10_DUMMY1_0: 1;
        uint32_t PAD_P10_SHDN_1: 1;
        uint32_t AON_PAD_P10_E_1: 1;
        uint32_t AON_PAD_P10_O_1: 1;
        uint32_t PAD_P10_E3_1: 1;
        uint32_t PAD_P10_E2_1: 1;
        uint32_t PAD_P10_PDPUC_1: 1;
        uint32_t AON_PAD_P10_PU_1: 1;
        uint32_t AON_PAD_P10_PU_EN_1: 1;
        uint32_t PAD_P10_WKPOL_1: 1;
        uint32_t PAD_P10_WKEN_1: 1;
        uint32_t PAD_P10_DEB_1: 1;
        uint32_t PAD_P10_AON_MUX_1: 2;
        uint32_t PAD_P10_O_EN_1: 1;
        uint32_t PAD_P10_HS_MUX_1: 1;
        uint32_t PAD_P10_DUMMY1_1: 1;
    };
} AON_NS_P10_0_P10_1_PAD_CFG_TYPE;

/* 0x19A4   0x4000_19a4
    0       R/W PAD_P10_SHDN[2]                 1'b1
    1       R/W AON_PAD_P10_E[2]                1'b0
    2       R/W AON_PAD_P10_O[2]                1'b0
    3       R/W PAD_P10_E3[2]                   1'b0
    4       R/W PAD_P10_E2[2]                   1'b0
    5       R/W PAD_P10_PDPUC[2]                1'b0
    6       R/W AON_PAD_P10_PU[2]               1'b0
    7       R/W AON_PAD_P10_PU_EN[2]            1'b1
    8       R/W PAD_P10_WKPOL[2]                1'b0
    9       R/W PAD_P10_WKEN[2]                 1'b0
    10      R/W PAD_P10_DEB[2]                  1'b0
    12:11   R/W PAD_P10_AON_MUX[2]              2'b0
    13      R/W PAD_P10_O_EN[2]                 1'b1
    14      R/W PAD_P10_HS_MUX[2]               1'b0
    15      R/W PAD_P10_DUMMY1[2]               1'b0
    16      R/W PAD_P10_SHDN[3]                 1'b1
    17      R/W AON_PAD_P10_E[3]                1'b0
    18      R/W AON_PAD_P10_O[3]                1'b0
    19      R/W PAD_P10_E3[3]                   1'b0
    20      R/W PAD_P10_E2[3]                   1'b0
    21      R/W PAD_P10_PDPUC[3]                1'b0
    22      R/W AON_PAD_P10_PU[3]               1'b0
    23      R/W AON_PAD_P10_PU_EN[3]            1'b1
    24      R/W PAD_P10_WKPOL[3]                1'b0
    25      R/W PAD_P10_WKEN[3]                 1'b0
    26      R/W PAD_P10_DEB[3]                  1'b0
    28:27   R/W PAD_P10_AON_MUX[3]              2'b0
    29      R/W PAD_P10_O_EN[3]                 1'b1
    30      R/W PAD_P10_HS_MUX[3]               1'b0
    31      R/W PAD_P10_DUMMY1[3]               1'b0
 */
typedef volatile union _AON_NS_P10_2_P10_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P10_SHDN_2: 1;
        uint32_t AON_PAD_P10_E_2: 1;
        uint32_t AON_PAD_P10_O_2: 1;
        uint32_t PAD_P10_E3_2: 1;
        uint32_t PAD_P10_E2_2: 1;
        uint32_t PAD_P10_PDPUC_2: 1;
        uint32_t AON_PAD_P10_PU_2: 1;
        uint32_t AON_PAD_P10_PU_EN_2: 1;
        uint32_t PAD_P10_WKPOL_2: 1;
        uint32_t PAD_P10_WKEN_2: 1;
        uint32_t PAD_P10_DEB_2: 1;
        uint32_t PAD_P10_AON_MUX_2: 2;
        uint32_t PAD_P10_O_EN_2: 1;
        uint32_t PAD_P10_HS_MUX_2: 1;
        uint32_t PAD_P10_DUMMY1_2: 1;
        uint32_t PAD_P10_SHDN_3: 1;
        uint32_t AON_PAD_P10_E_3: 1;
        uint32_t AON_PAD_P10_O_3: 1;
        uint32_t PAD_P10_E3_3: 1;
        uint32_t PAD_P10_E2_3: 1;
        uint32_t PAD_P10_PDPUC_3: 1;
        uint32_t AON_PAD_P10_PU_3: 1;
        uint32_t AON_PAD_P10_PU_EN_3: 1;
        uint32_t PAD_P10_WKPOL_3: 1;
        uint32_t PAD_P10_WKEN_3: 1;
        uint32_t PAD_P10_DEB_3: 1;
        uint32_t PAD_P10_AON_MUX_3: 2;
        uint32_t PAD_P10_O_EN_3: 1;
        uint32_t PAD_P10_HS_MUX_3: 1;
        uint32_t PAD_P10_DUMMY1_3: 1;
    };
} AON_NS_P10_2_P10_3_PAD_CFG_TYPE;

/* 0x19A8   0x4000_19a8
    0       R/W PAD_P10_SHDN[4]                 1'b1
    1       R/W AON_PAD_P10_E[4]                1'b0
    2       R/W AON_PAD_P10_O[4]                1'b0
    3       R/W PAD_P10_E3[4]                   1'b0
    4       R/W PAD_P10_E2[4]                   1'b0
    5       R/W PAD_P10_PDPUC[4]                1'b0
    6       R/W AON_PAD_P10_PU[4]               1'b0
    7       R/W AON_PAD_P10_PU_EN[4]            1'b1
    8       R/W PAD_P10_WKPOL[4]                1'b0
    9       R/W PAD_P10_WKEN[4]                 1'b0
    10      R/W PAD_P10_DEB[4]                  1'b0
    12:11   R/W PAD_P10_AON_MUX[4]              2'b0
    13      R/W PAD_P10_O_EN[4]                 1'b1
    14      R/W PAD_P10_HS_MUX[4]               1'b0
    15      R/W PAD_P10_DUMMY1[4]               1'b0
    16      R/W PAD_P10_SHDN[5]                 1'b1
    17      R/W AON_PAD_P10_E[5]                1'b0
    18      R/W AON_PAD_P10_O[5]                1'b0
    19      R/W PAD_P10_E3[5]                   1'b0
    20      R/W PAD_P10_E2[5]                   1'b0
    21      R/W PAD_P10_PDPUC[5]                1'b0
    22      R/W AON_PAD_P10_PU[5]               1'b0
    23      R/W AON_PAD_P10_PU_EN[5]            1'b1
    24      R/W PAD_P10_WKPOL[5]                1'b0
    25      R/W PAD_P10_WKEN[5]                 1'b0
    26      R/W PAD_P10_DEB[5]                  1'b0
    28:27   R/W PAD_P10_AON_MUX[5]              2'b0
    29      R/W PAD_P10_O_EN[5]                 1'b1
    30      R/W PAD_P10_HS_MUX[5]               1'b0
    31      R/W PAD_P10_DUMMY1[5]               1'b0
 */
typedef volatile union _AON_NS_P10_4_P10_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P10_SHDN_4: 1;
        uint32_t AON_PAD_P10_E_4: 1;
        uint32_t AON_PAD_P10_O_4: 1;
        uint32_t PAD_P10_E3_4: 1;
        uint32_t PAD_P10_E2_4: 1;
        uint32_t PAD_P10_PDPUC_4: 1;
        uint32_t AON_PAD_P10_PU_4: 1;
        uint32_t AON_PAD_P10_PU_EN_4: 1;
        uint32_t PAD_P10_WKPOL_4: 1;
        uint32_t PAD_P10_WKEN_4: 1;
        uint32_t PAD_P10_DEB_4: 1;
        uint32_t PAD_P10_AON_MUX_4: 2;
        uint32_t PAD_P10_O_EN_4: 1;
        uint32_t PAD_P10_HS_MUX_4: 1;
        uint32_t PAD_P10_DUMMY1_4: 1;
        uint32_t PAD_P10_SHDN_5: 1;
        uint32_t AON_PAD_P10_E_5: 1;
        uint32_t AON_PAD_P10_O_5: 1;
        uint32_t PAD_P10_E3_5: 1;
        uint32_t PAD_P10_E2_5: 1;
        uint32_t PAD_P10_PDPUC_5: 1;
        uint32_t AON_PAD_P10_PU_5: 1;
        uint32_t AON_PAD_P10_PU_EN_5: 1;
        uint32_t PAD_P10_WKPOL_5: 1;
        uint32_t PAD_P10_WKEN_5: 1;
        uint32_t PAD_P10_DEB_5: 1;
        uint32_t PAD_P10_AON_MUX_5: 2;
        uint32_t PAD_P10_O_EN_5: 1;
        uint32_t PAD_P10_HS_MUX_5: 1;
        uint32_t PAD_P10_DUMMY1_5: 1;
    };
} AON_NS_P10_4_P10_5_PAD_CFG_TYPE;

/* 0x19AC   0x4000_19ac
    0       R/W PAD_P10_SHDN[6]                 1'b1
    1       R/W AON_PAD_P10_E[6]                1'b0
    2       R/W AON_PAD_P10_O[6]                1'b0
    3       R/W PAD_P10_E3[6]                   1'b0
    4       R/W PAD_P10_E2[6]                   1'b0
    5       R/W PAD_P10_PDPUC[6]                1'b0
    6       R/W AON_PAD_P10_PU[6]               1'b0
    7       R/W AON_PAD_P10_PU_EN[6]            1'b1
    8       R/W PAD_P10_WKPOL[6]                1'b0
    9       R/W PAD_P10_WKEN[6]                 1'b0
    10      R/W PAD_P10_DEB[6]                  1'b0
    12:11   R/W PAD_P10_AON_MUX[6]              2'b0
    13      R/W PAD_P10_O_EN[6]                 1'b1
    14      R/W PAD_P10_DUMMY0[6]               1'b0
    15      R/W PAD_P10_DUMMY1[6]               1'b0
    16      R/W PAD_P10_SHDN[7]                 1'b1
    17      R/W AON_PAD_P10_E[7]                1'b0
    18      R/W AON_PAD_P10_O[7]                1'b0
    19      R/W PAD_P10_E3[7]                   1'b0
    20      R/W PAD_P10_E2[7]                   1'b0
    21      R/W PAD_P10_PDPUC[7]                1'b0
    22      R/W AON_PAD_P10_PU[7]               1'b0
    23      R/W AON_PAD_P10_PU_EN[7]            1'b1
    24      R/W PAD_P10_WKPOL[7]                1'b0
    25      R/W PAD_P10_WKEN[7]                 1'b0
    26      R/W PAD_P10_DEB[7]                  1'b0
    28:27   R/W PAD_P10_AON_MUX[7]              2'b0
    29      R/W PAD_P10_O_EN[7]                 1'b1
    30      R/W PAD_P10_DUMMY0[7]               1'b0
    31      R/W PAD_P10_DUMMY1[7]               1'b0
 */
typedef volatile union _AON_NS_P10_6_P10_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P10_SHDN_6: 1;
        uint32_t AON_PAD_P10_E_6: 1;
        uint32_t AON_PAD_P10_O_6: 1;
        uint32_t PAD_P10_E3_6: 1;
        uint32_t PAD_P10_E2_6: 1;
        uint32_t PAD_P10_PDPUC_6: 1;
        uint32_t AON_PAD_P10_PU_6: 1;
        uint32_t AON_PAD_P10_PU_EN_6: 1;
        uint32_t PAD_P10_WKPOL_6: 1;
        uint32_t PAD_P10_WKEN_6: 1;
        uint32_t PAD_P10_DEB_6: 1;
        uint32_t PAD_P10_AON_MUX_6: 2;
        uint32_t PAD_P10_O_EN_6: 1;
        uint32_t PAD_P10_DUMMY0_6: 1;
        uint32_t PAD_P10_DUMMY1_6: 1;
        uint32_t PAD_P10_SHDN_7: 1;
        uint32_t AON_PAD_P10_E_7: 1;
        uint32_t AON_PAD_P10_O_7: 1;
        uint32_t PAD_P10_E3_7: 1;
        uint32_t PAD_P10_E2_7: 1;
        uint32_t PAD_P10_PDPUC_7: 1;
        uint32_t AON_PAD_P10_PU_7: 1;
        uint32_t AON_PAD_P10_PU_EN_7: 1;
        uint32_t PAD_P10_WKPOL_7: 1;
        uint32_t PAD_P10_WKEN_7: 1;
        uint32_t PAD_P10_DEB_7: 1;
        uint32_t PAD_P10_AON_MUX_7: 2;
        uint32_t PAD_P10_O_EN_7: 1;
        uint32_t PAD_P10_DUMMY0_7: 1;
        uint32_t PAD_P10_DUMMY1_7: 1;
    };
} AON_NS_P10_6_P10_7_PAD_CFG_TYPE;

/* 0x19B0   0x4000_19b0
    0       R/W PAD_P11_SHDN[0]                 1'b1
    1       R/W AON_PAD_P11_E[0]                1'b0
    2       R/W AON_PAD_P11_O[0]                1'b0
    3       R/W PAD_P11_E3[0]                   1'b0
    4       R/W PAD_P11_E2[0]                   1'b0
    5       R/W PAD_P11_PDPUC[0]                1'b0
    6       R/W AON_PAD_P11_PU[0]               1'b0
    7       R/W AON_PAD_P11_PU_EN[0]            1'b1
    8       R/W PAD_P11_WKPOL[0]                1'b0
    9       R/W PAD_P11_WKEN[0]                 1'b0
    10      R/W PAD_P11_DEB[0]                  1'b0
    12:11   R/W PAD_P11_AON_MUX[0]              2'b0
    13      R/W PAD_P11_O_EN[0]                 1'b1
    14      R/W PAD_P11_DUMMY0[0]               1'b0
    15      R/W PAD_P11_DUMMY1[0]               1'b0
    16      R/W PAD_P11_SHDN[1]                 1'b1
    17      R/W AON_PAD_P11_E[1]                1'b0
    18      R/W AON_PAD_P11_O[1]                1'b0
    19      R/W PAD_P11_E3[1]                   1'b0
    20      R/W PAD_P11_E2[1]                   1'b0
    21      R/W PAD_P11_PDPUC[1]                1'b0
    22      R/W AON_PAD_P11_PU[1]               1'b0
    23      R/W AON_PAD_P11_PU_EN[1]            1'b1
    24      R/W PAD_P11_WKPOL[1]                1'b0
    25      R/W PAD_P11_WKEN[1]                 1'b0
    26      R/W PAD_P11_DEB[1]                  1'b0
    28:27   R/W PAD_P11_AON_MUX[1]              2'b0
    29      R/W PAD_P11_O_EN[1]                 1'b1
    30      R/W PAD_P11_DUMMY0[1]               1'b0
    31      R/W PAD_P11_DUMMY1[1]               1'b0
 */
typedef volatile union _AON_NS_P11_0_P11_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P11_SHDN_0: 1;
        uint32_t AON_PAD_P11_E_0: 1;
        uint32_t AON_PAD_P11_O_0: 1;
        uint32_t PAD_P11_E3_0: 1;
        uint32_t PAD_P11_E2_0: 1;
        uint32_t PAD_P11_PDPUC_0: 1;
        uint32_t AON_PAD_P11_PU_0: 1;
        uint32_t AON_PAD_P11_PU_EN_0: 1;
        uint32_t PAD_P11_WKPOL_0: 1;
        uint32_t PAD_P11_WKEN_0: 1;
        uint32_t PAD_P11_DEB_0: 1;
        uint32_t PAD_P11_AON_MUX_0: 2;
        uint32_t PAD_P11_O_EN_0: 1;
        uint32_t PAD_P11_DUMMY0_0: 1;
        uint32_t PAD_P11_DUMMY1_0: 1;
        uint32_t PAD_P11_SHDN_1: 1;
        uint32_t AON_PAD_P11_E_1: 1;
        uint32_t AON_PAD_P11_O_1: 1;
        uint32_t PAD_P11_E3_1: 1;
        uint32_t PAD_P11_E2_1: 1;
        uint32_t PAD_P11_PDPUC_1: 1;
        uint32_t AON_PAD_P11_PU_1: 1;
        uint32_t AON_PAD_P11_PU_EN_1: 1;
        uint32_t PAD_P11_WKPOL_1: 1;
        uint32_t PAD_P11_WKEN_1: 1;
        uint32_t PAD_P11_DEB_1: 1;
        uint32_t PAD_P11_AON_MUX_1: 2;
        uint32_t PAD_P11_O_EN_1: 1;
        uint32_t PAD_P11_DUMMY0_1: 1;
        uint32_t PAD_P11_DUMMY1_1: 1;
    };
} AON_NS_P11_0_P11_1_PAD_CFG_TYPE;

/* 0x19B4   0x4000_19b4
    0       R/W PAD_P11_SHDN[2]                 1'b1
    1       R/W AON_PAD_P11_E[2]                1'b0
    2       R/W AON_PAD_P11_O[2]                1'b0
    3       R/W PAD_P11_E3[2]                   1'b0
    4       R/W PAD_P11_E2[2]                   1'b0
    5       R/W PAD_P11_PDPUC[2]                1'b0
    6       R/W AON_PAD_P11_PU[2]               1'b0
    7       R/W AON_PAD_P11_PU_EN[2]            1'b1
    8       R/W PAD_P11_WKPOL[2]                1'b0
    9       R/W PAD_P11_WKEN[2]                 1'b0
    10      R/W PAD_P11_DEB[2]                  1'b0
    12:11   R/W PAD_P11_AON_MUX[2]              2'b0
    13      R/W PAD_P11_O_EN[2]                 1'b1
    14      R/W PAD_P11_HS_MUX[2]               1'b0
    15      R/W PAD_P11_DUMMY1[2]               1'b0
    16      R/W PAD_P11_SHDN[3]                 1'b1
    17      R/W AON_PAD_P11_E[3]                1'b0
    18      R/W AON_PAD_P11_O[3]                1'b0
    19      R/W PAD_P11_E3[3]                   1'b0
    20      R/W PAD_P11_E2[3]                   1'b0
    21      R/W PAD_P11_PDPUC[3]                1'b0
    22      R/W AON_PAD_P11_PU[3]               1'b0
    23      R/W AON_PAD_P11_PU_EN[3]            1'b1
    24      R/W PAD_P11_WKPOL[3]                1'b0
    25      R/W PAD_P11_WKEN[3]                 1'b0
    26      R/W PAD_P11_DEB[3]                  1'b0
    28:27   R/W PAD_P11_AON_MUX[3]              2'b0
    29      R/W PAD_P11_O_EN[3]                 1'b1
    30      R/W PAD_P11_HS_MUX[3]               1'b0
    31      R/W PAD_P11_DUMMY1[3]               1'b0
 */
typedef volatile union _AON_NS_P11_2_P11_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P11_SHDN_2: 1;
        uint32_t AON_PAD_P11_E_2: 1;
        uint32_t AON_PAD_P11_O_2: 1;
        uint32_t PAD_P11_E3_2: 1;
        uint32_t PAD_P11_E2_2: 1;
        uint32_t PAD_P11_PDPUC_2: 1;
        uint32_t AON_PAD_P11_PU_2: 1;
        uint32_t AON_PAD_P11_PU_EN_2: 1;
        uint32_t PAD_P11_WKPOL_2: 1;
        uint32_t PAD_P11_WKEN_2: 1;
        uint32_t PAD_P11_DEB_2: 1;
        uint32_t PAD_P11_AON_MUX_2: 2;
        uint32_t PAD_P11_O_EN_2: 1;
        uint32_t PAD_P11_HS_MUX_2: 1;
        uint32_t PAD_P11_DUMMY1_2: 1;
        uint32_t PAD_P11_SHDN_3: 1;
        uint32_t AON_PAD_P11_E_3: 1;
        uint32_t AON_PAD_P11_O_3: 1;
        uint32_t PAD_P11_E3_3: 1;
        uint32_t PAD_P11_E2_3: 1;
        uint32_t PAD_P11_PDPUC_3: 1;
        uint32_t AON_PAD_P11_PU_3: 1;
        uint32_t AON_PAD_P11_PU_EN_3: 1;
        uint32_t PAD_P11_WKPOL_3: 1;
        uint32_t PAD_P11_WKEN_3: 1;
        uint32_t PAD_P11_DEB_3: 1;
        uint32_t PAD_P11_AON_MUX_3: 2;
        uint32_t PAD_P11_O_EN_3: 1;
        uint32_t PAD_P11_HS_MUX_3: 1;
        uint32_t PAD_P11_DUMMY1_3: 1;
    };
} AON_NS_P11_2_P11_3_PAD_CFG_TYPE;

/* 0x19B8   0x4000_19b8
    0       R/W PAD_P11_SHDN[4]                 1'b1
    1       R/W AON_PAD_P11_E[4]                1'b0
    2       R/W AON_PAD_P11_O[4]                1'b0
    3       R/W PAD_P11_E3[4]                   1'b0
    4       R/W PAD_P11_E2[4]                   1'b0
    5       R/W PAD_P11_PDPUC[4]                1'b0
    6       R/W AON_PAD_P11_PU[4]               1'b0
    7       R/W AON_PAD_P11_PU_EN[4]            1'b1
    8       R/W PAD_P11_WKPOL[4]                1'b0
    9       R/W PAD_P11_WKEN[4]                 1'b0
    10      R/W PAD_P11_DEB[4]                  1'b0
    12:11   R/W PAD_P11_AON_MUX[4]              2'b0
    13      R/W PAD_P11_O_EN[4]                 1'b1
    14      R/W PAD_P11_HS_MUX[4]               1'b0
    15      R/W PAD_P11_DUMMY1[4]               1'b0
    16      R/W PAD_P11_SHDN[5]                 1'b1
    17      R/W AON_PAD_P11_E[5]                1'b0
    18      R/W AON_PAD_P11_O[5]                1'b0
    19      R/W PAD_P11_E3[5]                   1'b0
    20      R/W PAD_P11_E2[5]                   1'b0
    21      R/W PAD_P11_PDPUC[5]                1'b0
    22      R/W AON_PAD_P11_PU[5]               1'b0
    23      R/W AON_PAD_P11_PU_EN[5]            1'b1
    24      R/W PAD_P11_WKPOL[5]                1'b0
    25      R/W PAD_P11_WKEN[5]                 1'b0
    26      R/W PAD_P11_DEB[5]                  1'b0
    28:27   R/W PAD_P11_AON_MUX[5]              2'b0
    29      R/W PAD_P11_O_EN[5]                 1'b1
    30      R/W PAD_P11_HS_MUX[5]               1'b0
    31      R/W PAD_P11_DUMMY1[5]               1'b0
 */
typedef volatile union _AON_NS_P11_4_P11_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P11_SHDN_4: 1;
        uint32_t AON_PAD_P11_E_4: 1;
        uint32_t AON_PAD_P11_O_4: 1;
        uint32_t PAD_P11_E3_4: 1;
        uint32_t PAD_P11_E2_4: 1;
        uint32_t PAD_P11_PDPUC_4: 1;
        uint32_t AON_PAD_P11_PU_4: 1;
        uint32_t AON_PAD_P11_PU_EN_4: 1;
        uint32_t PAD_P11_WKPOL_4: 1;
        uint32_t PAD_P11_WKEN_4: 1;
        uint32_t PAD_P11_DEB_4: 1;
        uint32_t PAD_P11_AON_MUX_4: 2;
        uint32_t PAD_P11_O_EN_4: 1;
        uint32_t PAD_P11_HS_MUX_4: 1;
        uint32_t PAD_P11_DUMMY1_4: 1;
        uint32_t PAD_P11_SHDN_5: 1;
        uint32_t AON_PAD_P11_E_5: 1;
        uint32_t AON_PAD_P11_O_5: 1;
        uint32_t PAD_P11_E3_5: 1;
        uint32_t PAD_P11_E2_5: 1;
        uint32_t PAD_P11_PDPUC_5: 1;
        uint32_t AON_PAD_P11_PU_5: 1;
        uint32_t AON_PAD_P11_PU_EN_5: 1;
        uint32_t PAD_P11_WKPOL_5: 1;
        uint32_t PAD_P11_WKEN_5: 1;
        uint32_t PAD_P11_DEB_5: 1;
        uint32_t PAD_P11_AON_MUX_5: 2;
        uint32_t PAD_P11_O_EN_5: 1;
        uint32_t PAD_P11_HS_MUX_5: 1;
        uint32_t PAD_P11_DUMMY1_5: 1;
    };
} AON_NS_P11_4_P11_5_PAD_CFG_TYPE;

/* 0x19BC   0x4000_19bc
    0       R/W PAD_P11_SHDN[6]                 1'b1
    1       R/W AON_PAD_P11_E[6]                1'b0
    2       R/W AON_PAD_P11_O[6]                1'b0
    3       R/W PAD_P11_E3[6]                   1'b0
    4       R/W PAD_P11_E2[6]                   1'b0
    5       R/W PAD_P11_PDPUC[6]                1'b0
    6       R/W AON_PAD_P11_PU[6]               1'b0
    7       R/W AON_PAD_P11_PU_EN[6]            1'b1
    8       R/W PAD_P11_WKPOL[6]                1'b0
    9       R/W PAD_P11_WKEN[6]                 1'b0
    10      R/W PAD_P11_DEB[6]                  1'b0
    12:11   R/W PAD_P11_AON_MUX[6]              2'b0
    13      R/W PAD_P11_O_EN[6]                 1'b1
    14      R/W PAD_P11_HS_MUX[6]               1'b0
    15      R/W PAD_P11_DUMMY1[6]               1'b0
    16      R/W PAD_P11_SHDN[7]                 1'b1
    17      R/W AON_PAD_P11_E[7]                1'b0
    18      R/W AON_PAD_P11_O[7]                1'b0
    19      R/W PAD_P11_E3[7]                   1'b0
    20      R/W PAD_P11_E2[7]                   1'b0
    21      R/W PAD_P11_PDPUC[7]                1'b0
    22      R/W AON_PAD_P11_PU[7]               1'b0
    23      R/W AON_PAD_P11_PU_EN[7]            1'b1
    24      R/W PAD_P11_WKPOL[7]                1'b0
    25      R/W PAD_P11_WKEN[7]                 1'b0
    26      R/W PAD_P11_DEB[7]                  1'b0
    28:27   R/W PAD_P11_AON_MUX[7]              2'b0
    29      R/W PAD_P11_O_EN[7]                 1'b1
    30      R/W PAD_P11_HS_MUX[7]               1'b0
    31      R/W PAD_P11_DUMMY1[7]               1'b0
 */
typedef volatile union _AON_NS_P11_6_P11_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P11_SHDN_6: 1;
        uint32_t AON_PAD_P11_E_6: 1;
        uint32_t AON_PAD_P11_O_6: 1;
        uint32_t PAD_P11_E3_6: 1;
        uint32_t PAD_P11_E2_6: 1;
        uint32_t PAD_P11_PDPUC_6: 1;
        uint32_t AON_PAD_P11_PU_6: 1;
        uint32_t AON_PAD_P11_PU_EN_6: 1;
        uint32_t PAD_P11_WKPOL_6: 1;
        uint32_t PAD_P11_WKEN_6: 1;
        uint32_t PAD_P11_DEB_6: 1;
        uint32_t PAD_P11_AON_MUX_6: 2;
        uint32_t PAD_P11_O_EN_6: 1;
        uint32_t PAD_P11_HS_MUX_6: 1;
        uint32_t PAD_P11_DUMMY1_6: 1;
        uint32_t PAD_P11_SHDN_7: 1;
        uint32_t AON_PAD_P11_E_7: 1;
        uint32_t AON_PAD_P11_O_7: 1;
        uint32_t PAD_P11_E3_7: 1;
        uint32_t PAD_P11_E2_7: 1;
        uint32_t PAD_P11_PDPUC_7: 1;
        uint32_t AON_PAD_P11_PU_7: 1;
        uint32_t AON_PAD_P11_PU_EN_7: 1;
        uint32_t PAD_P11_WKPOL_7: 1;
        uint32_t PAD_P11_WKEN_7: 1;
        uint32_t PAD_P11_DEB_7: 1;
        uint32_t PAD_P11_AON_MUX_7: 2;
        uint32_t PAD_P11_O_EN_7: 1;
        uint32_t PAD_P11_HS_MUX_7: 1;
        uint32_t PAD_P11_DUMMY1_7: 1;
    };
} AON_NS_P11_6_P11_7_PAD_CFG_TYPE;

/* 0x19C0   0x4000_19c0
    0       R/W PAD_P12_SHDN[0]                 1'b1
    1       R/W AON_PAD_P12_E[0]                1'b0
    2       R/W AON_PAD_P12_O[0]                1'b0
    3       R/W PAD_P12_E3[0]                   1'b0
    4       R/W PAD_P12_E2[0]                   1'b0
    5       R/W PAD_P12_PDPUC[0]                1'b0
    6       R/W AON_PAD_P12_PU[0]               1'b1
    7       R/W AON_PAD_P12_PU_EN[0]            1'b1
    8       R/W PAD_P12_WKPOL[0]                1'b0
    9       R/W PAD_P12_WKEN[0]                 1'b0
    10      R/W PAD_P12_DEB[0]                  1'b0
    12:11   R/W PAD_P12_AON_MUX[0]              2'b0
    13      R/W PAD_P12_O_EN[0]                 1'b1
    14      R/W PAD_P12_HS_MUX[0]               1'b0
    15      R/W PAD_P12_DUMMY1[0]               1'b0
    16      R/W PAD_P12_SHDN[1]                 1'b1
    17      R/W AON_PAD_P12_E[1]                1'b0
    18      R/W AON_PAD_P12_O[1]                1'b0
    19      R/W PAD_P12_E3[1]                   1'b0
    20      R/W PAD_P12_E2[1]                   1'b0
    21      R/W PAD_P12_PDPUC[1]                1'b0
    22      R/W AON_PAD_P12_PU[1]               1'b1
    23      R/W AON_PAD_P12_PU_EN[1]            1'b1
    24      R/W PAD_P12_WKPOL[1]                1'b0
    25      R/W PAD_P12_WKEN[1]                 1'b0
    26      R/W PAD_P12_DEB[1]                  1'b0
    28:27   R/W PAD_P12_AON_MUX[1]              2'b0
    29      R/W PAD_P12_O_EN[1]                 1'b1
    30      R/W PAD_P12_HS_MUX[1]               1'b0
    31      R/W PAD_P12_DUMMY1[1]               1'b0
 */
typedef volatile union _AON_NS_P12_0_P12_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P12_SHDN_0: 1;
        uint32_t AON_PAD_P12_E_0: 1;
        uint32_t AON_PAD_P12_O_0: 1;
        uint32_t PAD_P12_E3_0: 1;
        uint32_t PAD_P12_E2_0: 1;
        uint32_t PAD_P12_PDPUC_0: 1;
        uint32_t AON_PAD_P12_PU_0: 1;
        uint32_t AON_PAD_P12_PU_EN_0: 1;
        uint32_t PAD_P12_WKPOL_0: 1;
        uint32_t PAD_P12_WKEN_0: 1;
        uint32_t PAD_P12_DEB_0: 1;
        uint32_t PAD_P12_AON_MUX_0: 2;
        uint32_t PAD_P12_O_EN_0: 1;
        uint32_t PAD_P12_HS_MUX_0: 1;
        uint32_t PAD_P12_DUMMY1_0: 1;
        uint32_t PAD_P12_SHDN_1: 1;
        uint32_t AON_PAD_P12_E_1: 1;
        uint32_t AON_PAD_P12_O_1: 1;
        uint32_t PAD_P12_E3_1: 1;
        uint32_t PAD_P12_E2_1: 1;
        uint32_t PAD_P12_PDPUC_1: 1;
        uint32_t AON_PAD_P12_PU_1: 1;
        uint32_t AON_PAD_P12_PU_EN_1: 1;
        uint32_t PAD_P12_WKPOL_1: 1;
        uint32_t PAD_P12_WKEN_1: 1;
        uint32_t PAD_P12_DEB_1: 1;
        uint32_t PAD_P12_AON_MUX_1: 2;
        uint32_t PAD_P12_O_EN_1: 1;
        uint32_t PAD_P12_HS_MUX_1: 1;
        uint32_t PAD_P12_DUMMY1_1: 1;
    };
} AON_NS_P12_0_P12_1_PAD_CFG_TYPE;

/* 0x19C4   0x4000_19c4
    0       R/W PAD_P12_SHDN[2]                 1'b1
    1       R/W AON_PAD_P12_E[2]                1'b0
    2       R/W AON_PAD_P12_O[2]                1'b0
    3       R/W PAD_P12_E3[2]                   1'b0
    4       R/W PAD_P12_E2[2]                   1'b0
    5       R/W PAD_P12_PDPUC[2]                1'b0
    6       R/W AON_PAD_P12_PU[2]               1'b0
    7       R/W AON_PAD_P12_PU_EN[2]            1'b1
    8       R/W PAD_P12_WKPOL[2]                1'b0
    9       R/W PAD_P12_WKEN[2]                 1'b0
    10      R/W PAD_P12_DEB[2]                  1'b0
    12:11   R/W PAD_P12_AON_MUX[2]              2'b0
    13      R/W PAD_P12_O_EN[2]                 1'b1
    14      R/W PAD_P12_HS_MUX[2]               1'b0
    15      R/W PAD_P12_DUMMY1[2]               1'b0
    16      R/W PAD_P12_SHDN[3]                 1'b1
    17      R/W AON_PAD_P12_E[3]                1'b0
    18      R/W AON_PAD_P12_O[3]                1'b0
    19      R/W PAD_P12_E3[3]                   1'b0
    20      R/W PAD_P12_E2[3]                   1'b0
    21      R/W PAD_P12_PDPUC[3]                1'b0
    22      R/W AON_PAD_P12_PU[3]               1'b0
    23      R/W AON_PAD_P12_PU_EN[3]            1'b1
    24      R/W PAD_P12_WKPOL[3]                1'b0
    25      R/W PAD_P12_WKEN[3]                 1'b0
    26      R/W PAD_P12_DEB[3]                  1'b0
    28:27   R/W PAD_P12_AON_MUX[3]              2'b0
    29      R/W PAD_P12_O_EN[3]                 1'b1
    30      R/W PAD_P12_HS_MUX[3]               1'b0
    31      R/W SPIC3_PULL_SEL_SIO0_PULL_CTRL   1'b0
 */
typedef volatile union _AON_NS_P12_2_P12_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P12_SHDN_2: 1;
        uint32_t AON_PAD_P12_E_2: 1;
        uint32_t AON_PAD_P12_O_2: 1;
        uint32_t PAD_P12_E3_2: 1;
        uint32_t PAD_P12_E2_2: 1;
        uint32_t PAD_P12_PDPUC_2: 1;
        uint32_t AON_PAD_P12_PU_2: 1;
        uint32_t AON_PAD_P12_PU_EN_2: 1;
        uint32_t PAD_P12_WKPOL_2: 1;
        uint32_t PAD_P12_WKEN_2: 1;
        uint32_t PAD_P12_DEB_2: 1;
        uint32_t PAD_P12_AON_MUX_2: 2;
        uint32_t PAD_P12_O_EN_2: 1;
        uint32_t PAD_P12_HS_MUX_2: 1;
        uint32_t PAD_P12_DUMMY1_2: 1;
        uint32_t PAD_P12_SHDN_3: 1;
        uint32_t AON_PAD_P12_E_3: 1;
        uint32_t AON_PAD_P12_O_3: 1;
        uint32_t PAD_P12_E3_3: 1;
        uint32_t PAD_P12_E2_3: 1;
        uint32_t PAD_P12_PDPUC_3: 1;
        uint32_t AON_PAD_P12_PU_3: 1;
        uint32_t AON_PAD_P12_PU_EN_3: 1;
        uint32_t PAD_P12_WKPOL_3: 1;
        uint32_t PAD_P12_WKEN_3: 1;
        uint32_t PAD_P12_DEB_3: 1;
        uint32_t PAD_P12_AON_MUX_3: 2;
        uint32_t PAD_P12_O_EN_3: 1;
        uint32_t PAD_P12_HS_MUX_3: 1;
        uint32_t SPIC3_PULL_SEL_SIO0_PULL_CTRL: 1;
    };
} AON_NS_P12_2_P12_3_PAD_CFG_TYPE;

/* 0x19C8   0x4000_19c8
    0       R/W PAD_P12_SHDN[4]                 1'b1
    1       R/W AON_PAD_P12_E[4]                1'b0
    2       R/W AON_PAD_P12_O[4]                1'b0
    3       R/W PAD_P12_E3[4]                   1'b0
    4       R/W PAD_P12_E2[4]                   1'b0
    5       R/W PAD_P12_PDPUC[4]                1'b0
    6       R/W AON_PAD_P12_PU[4]               1'b0
    7       R/W AON_PAD_P12_PU_EN[4]            1'b1
    8       R/W PAD_P12_WKPOL[4]                1'b0
    9       R/W PAD_P12_WKEN[4]                 1'b0
    10      R/W PAD_P12_DEB[4]                  1'b0
    12:11   R/W PAD_P12_AON_MUX[4]              2'b0
    13      R/W PAD_P12_O_EN[4]                 1'b1
    14      R/W PAD_P12_HS_MUX[4]               1'b0
    15      R/W SPIC3_PULL_SEL_SIO1_PULL_CTRL   1'b0
    16      R/W PAD_P12_SHDN[5]                 1'b1
    17      R/W AON_PAD_P12_E[5]                1'b0
    18      R/W AON_PAD_P12_O[5]                1'b0
    19      R/W PAD_P12_E3[5]                   1'b0
    20      R/W PAD_P12_E2[5]                   1'b0
    21      R/W PAD_P12_PDPUC[5]                1'b0
    22      R/W AON_PAD_P12_PU[5]               1'b0
    23      R/W AON_PAD_P12_PU_EN[5]            1'b1
    24      R/W PAD_P12_WKPOL[5]                1'b0
    25      R/W PAD_P12_WKEN[5]                 1'b0
    26      R/W PAD_P12_DEB[5]                  1'b0
    28:27   R/W PAD_P12_AON_MUX[5]              2'b0
    29      R/W PAD_P12_O_EN[5]                 1'b1
    30      R/W PAD_P12_HS_MUX[5]               1'b0
    31      R/W SPIC3_PULL_SEL_SIO2_PULL_CTRL   1'b0
 */
typedef volatile union _AON_NS_P12_4_P12_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P12_SHDN_4: 1;
        uint32_t AON_PAD_P12_E_4: 1;
        uint32_t AON_PAD_P12_O_4: 1;
        uint32_t PAD_P12_E3_4: 1;
        uint32_t PAD_P12_E2_4: 1;
        uint32_t PAD_P12_PDPUC_4: 1;
        uint32_t AON_PAD_P12_PU_4: 1;
        uint32_t AON_PAD_P12_PU_EN_4: 1;
        uint32_t PAD_P12_WKPOL_4: 1;
        uint32_t PAD_P12_WKEN_4: 1;
        uint32_t PAD_P12_DEB_4: 1;
        uint32_t PAD_P12_AON_MUX_4: 2;
        uint32_t PAD_P12_O_EN_4: 1;
        uint32_t PAD_P12_HS_MUX_4: 1;
        uint32_t SPIC3_PULL_SEL_SIO1_PULL_CTRL: 1;
        uint32_t PAD_P12_SHDN_5: 1;
        uint32_t AON_PAD_P12_E_5: 1;
        uint32_t AON_PAD_P12_O_5: 1;
        uint32_t PAD_P12_E3_5: 1;
        uint32_t PAD_P12_E2_5: 1;
        uint32_t PAD_P12_PDPUC_5: 1;
        uint32_t AON_PAD_P12_PU_5: 1;
        uint32_t AON_PAD_P12_PU_EN_5: 1;
        uint32_t PAD_P12_WKPOL_5: 1;
        uint32_t PAD_P12_WKEN_5: 1;
        uint32_t PAD_P12_DEB_5: 1;
        uint32_t PAD_P12_AON_MUX_5: 2;
        uint32_t PAD_P12_O_EN_5: 1;
        uint32_t PAD_P12_HS_MUX_5: 1;
        uint32_t SPIC3_PULL_SEL_SIO2_PULL_CTRL: 1;
    };
} AON_NS_P12_4_P12_5_PAD_CFG_TYPE;

/* 0x19CC   0x4000_19cc
    0       R/W PAD_P12_SHDN[6]                 1'b1
    1       R/W AON_PAD_P12_E[6]                1'b0
    2       R/W AON_PAD_P12_O[6]                1'b0
    3       R/W PAD_P12_E3[6]                   1'b0
    4       R/W PAD_P12_E2[6]                   1'b0
    5       R/W PAD_P12_PDPUC[6]                1'b0
    6       R/W AON_PAD_P12_PU[6]               1'b0
    7       R/W AON_PAD_P12_PU_EN[6]            1'b1
    8       R/W PAD_P12_WKPOL[6]                1'b0
    9       R/W PAD_P12_WKEN[6]                 1'b0
    10      R/W PAD_P12_DEB[6]                  1'b0
    12:11   R/W PAD_P12_AON_MUX[6]              2'b0
    13      R/W PAD_P12_O_EN[6]                 1'b1
    14      R/W PAD_P12_HS_MUX[6]               1'b0
    15      R/W SPIC3_PULL_SEL_SIO3_PULL_CTRL   1'b0
    16      R/W PAD_P12_SHDN[7]                 1'b1
    17      R/W AON_PAD_P12_E[7]                1'b0
    18      R/W AON_PAD_P12_O[7]                1'b0
    19      R/W PAD_P12_E3[7]                   1'b0
    20      R/W PAD_P12_E2[7]                   1'b0
    21      R/W PAD_P12_PDPUC[7]                1'b0
    22      R/W AON_PAD_P12_PU[7]               1'b0
    23      R/W AON_PAD_P12_PU_EN[7]            1'b1
    24      R/W PAD_P12_WKPOL[7]                1'b0
    25      R/W PAD_P12_WKEN[7]                 1'b0
    26      R/W PAD_P12_DEB[7]                  1'b0
    28:27   R/W PAD_P12_AON_MUX[7]              2'b0
    29      R/W PAD_P12_O_EN[7]                 1'b1
    30      R/W PAD_P12_HS_MUX[7]               1'b0
    31      R/W PAD_P12_DUMMY1[7]               1'b0
 */
typedef volatile union _AON_NS_P12_6_P12_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P12_SHDN_6: 1;
        uint32_t AON_PAD_P12_E_6: 1;
        uint32_t AON_PAD_P12_O_6: 1;
        uint32_t PAD_P12_E3_6: 1;
        uint32_t PAD_P12_E2_6: 1;
        uint32_t PAD_P12_PDPUC_6: 1;
        uint32_t AON_PAD_P12_PU_6: 1;
        uint32_t AON_PAD_P12_PU_EN_6: 1;
        uint32_t PAD_P12_WKPOL_6: 1;
        uint32_t PAD_P12_WKEN_6: 1;
        uint32_t PAD_P12_DEB_6: 1;
        uint32_t PAD_P12_AON_MUX_6: 2;
        uint32_t PAD_P12_O_EN_6: 1;
        uint32_t PAD_P12_HS_MUX_6: 1;
        uint32_t SPIC3_PULL_SEL_SIO3_PULL_CTRL: 1;
        uint32_t PAD_P12_SHDN_7: 1;
        uint32_t AON_PAD_P12_E_7: 1;
        uint32_t AON_PAD_P12_O_7: 1;
        uint32_t PAD_P12_E3_7: 1;
        uint32_t PAD_P12_E2_7: 1;
        uint32_t PAD_P12_PDPUC_7: 1;
        uint32_t AON_PAD_P12_PU_7: 1;
        uint32_t AON_PAD_P12_PU_EN_7: 1;
        uint32_t PAD_P12_WKPOL_7: 1;
        uint32_t PAD_P12_WKEN_7: 1;
        uint32_t PAD_P12_DEB_7: 1;
        uint32_t PAD_P12_AON_MUX_7: 2;
        uint32_t PAD_P12_O_EN_7: 1;
        uint32_t PAD_P12_HS_MUX_7: 1;
        uint32_t PAD_P12_DUMMY1_7: 1;
    };
} AON_NS_P12_6_P12_7_PAD_CFG_TYPE;

/* 0x19D0   0x4000_19d0
    0       R/W PAD_P13_SHDN[0]                 1'b1
    1       R/W AON_PAD_P13_E[0]                1'b0
    2       R/W AON_PAD_P13_O[0]                1'b0
    3       R/W PAD_P13_E3[0]                   1'b0
    4       R/W PAD_P13_E2[0]                   1'b0
    5       R/W PAD_P13_PDPUC[0]                1'b0
    6       R/W AON_PAD_P13_PU[0]               1'b0
    7       R/W AON_PAD_P13_PU_EN[0]            1'b1
    8       R/W PAD_P13_WKPOL[0]                1'b0
    9       R/W PAD_P13_WKEN[0]                 1'b0
    10      R/W PAD_P13_DEB[0]                  1'b0
    12:11   R/W PAD_P13_AON_MUX[0]              2'b0
    13      R/W PAD_P13_O_EN[0]                 1'b1
    14      R/W PAD_P13_HS_MUX[0]               1'b0
    15      R/W PAD_P13_DUMMY1[0]               1'b0
    16      R/W PAD_P13_SHDN[1]                 1'b1
    17      R/W AON_PAD_P13_E[1]                1'b0
    18      R/W AON_PAD_P13_O[1]                1'b0
    19      R/W PAD_P13_E3[1]                   1'b0
    20      R/W PAD_P13_E2[1]                   1'b0
    21      R/W PAD_P13_PDPUC[1]                1'b0
    22      R/W AON_PAD_P13_PU[1]               1'b0
    23      R/W AON_PAD_P13_PU_EN[1]            1'b1
    24      R/W PAD_P13_WKPOL[1]                1'b0
    25      R/W PAD_P13_WKEN[1]                 1'b0
    26      R/W PAD_P13_DEB[1]                  1'b0
    28:27   R/W PAD_P13_AON_MUX[1]              2'b0
    29      R/W PAD_P13_O_EN[1]                 1'b1
    30      R/W PAD_P13_HS_MUX[1]               1'b0
    31      R/W PAD_P13_DUMMY1[1]               1'b0
 */
typedef volatile union _AON_NS_P13_0_P13_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P13_SHDN_0: 1;
        uint32_t AON_PAD_P13_E_0: 1;
        uint32_t AON_PAD_P13_O_0: 1;
        uint32_t PAD_P13_E3_0: 1;
        uint32_t PAD_P13_E2_0: 1;
        uint32_t PAD_P13_PDPUC_0: 1;
        uint32_t AON_PAD_P13_PU_0: 1;
        uint32_t AON_PAD_P13_PU_EN_0: 1;
        uint32_t PAD_P13_WKPOL_0: 1;
        uint32_t PAD_P13_WKEN_0: 1;
        uint32_t PAD_P13_DEB_0: 1;
        uint32_t PAD_P13_AON_MUX_0: 2;
        uint32_t PAD_P13_O_EN_0: 1;
        uint32_t PAD_P13_HS_MUX_0: 1;
        uint32_t PAD_P13_DUMMY1_0: 1;
        uint32_t PAD_P13_SHDN_1: 1;
        uint32_t AON_PAD_P13_E_1: 1;
        uint32_t AON_PAD_P13_O_1: 1;
        uint32_t PAD_P13_E3_1: 1;
        uint32_t PAD_P13_E2_1: 1;
        uint32_t PAD_P13_PDPUC_1: 1;
        uint32_t AON_PAD_P13_PU_1: 1;
        uint32_t AON_PAD_P13_PU_EN_1: 1;
        uint32_t PAD_P13_WKPOL_1: 1;
        uint32_t PAD_P13_WKEN_1: 1;
        uint32_t PAD_P13_DEB_1: 1;
        uint32_t PAD_P13_AON_MUX_1: 2;
        uint32_t PAD_P13_O_EN_1: 1;
        uint32_t PAD_P13_HS_MUX_1: 1;
        uint32_t PAD_P13_DUMMY1_1: 1;
    };
} AON_NS_P13_0_P13_1_PAD_CFG_TYPE;

/* 0x19D4   0x4000_19d4
    0       R/W PAD_P13_SHDN[2]                 1'b1
    1       R/W AON_PAD_P13_E[2]                1'b0
    2       R/W AON_PAD_P13_O[2]                1'b0
    3       R/W PAD_P13_E3[2]                   1'b0
    4       R/W PAD_P13_E2[2]                   1'b0
    5       R/W PAD_P13_PDPUC[2]                1'b0
    6       R/W AON_PAD_P13_PU[2]               1'b0
    7       R/W AON_PAD_P13_PU_EN[2]            1'b1
    8       R/W PAD_P13_WKPOL[2]                1'b0
    9       R/W PAD_P13_WKEN[2]                 1'b0
    10      R/W PAD_P13_DEB[2]                  1'b0
    12:11   R/W PAD_P13_AON_MUX[2]              2'b0
    13      R/W PAD_P13_O_EN[2]                 1'b1
    14      R/W PAD_P13_HS_MUX[2]               1'b0
    15      R/W PAD_P13_DUMMY1[2]               1'b0
    16      R/W PAD_P13_SHDN[3]                 1'b1
    17      R/W AON_PAD_P13_E[3]                1'b0
    18      R/W AON_PAD_P13_O[3]                1'b0
    19      R/W PAD_P13_E3[3]                   1'b0
    20      R/W PAD_P13_E2[3]                   1'b0
    21      R/W PAD_P13_PDPUC[3]                1'b0
    22      R/W AON_PAD_P13_PU[3]               1'b0
    23      R/W AON_PAD_P13_PU_EN[3]            1'b1
    24      R/W PAD_P13_WKPOL[3]                1'b0
    25      R/W PAD_P13_WKEN[3]                 1'b0
    26      R/W PAD_P13_DEB[3]                  1'b0
    28:27   R/W PAD_P13_AON_MUX[3]              2'b0
    29      R/W PAD_P13_O_EN[3]                 1'b1
    30      R/W PAD_P13_HS_MUX[3]               1'b0
    31      R/W PAD_P13_DUMMY1[3]               1'b0
 */
typedef volatile union _AON_NS_P13_2_P13_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P13_SHDN_2: 1;
        uint32_t AON_PAD_P13_E_2: 1;
        uint32_t AON_PAD_P13_O_2: 1;
        uint32_t PAD_P13_E3_2: 1;
        uint32_t PAD_P13_E2_2: 1;
        uint32_t PAD_P13_PDPUC_2: 1;
        uint32_t AON_PAD_P13_PU_2: 1;
        uint32_t AON_PAD_P13_PU_EN_2: 1;
        uint32_t PAD_P13_WKPOL_2: 1;
        uint32_t PAD_P13_WKEN_2: 1;
        uint32_t PAD_P13_DEB_2: 1;
        uint32_t PAD_P13_AON_MUX_2: 2;
        uint32_t PAD_P13_O_EN_2: 1;
        uint32_t PAD_P13_HS_MUX_2: 1;
        uint32_t PAD_P13_DUMMY1_2: 1;
        uint32_t PAD_P13_SHDN_3: 1;
        uint32_t AON_PAD_P13_E_3: 1;
        uint32_t AON_PAD_P13_O_3: 1;
        uint32_t PAD_P13_E3_3: 1;
        uint32_t PAD_P13_E2_3: 1;
        uint32_t PAD_P13_PDPUC_3: 1;
        uint32_t AON_PAD_P13_PU_3: 1;
        uint32_t AON_PAD_P13_PU_EN_3: 1;
        uint32_t PAD_P13_WKPOL_3: 1;
        uint32_t PAD_P13_WKEN_3: 1;
        uint32_t PAD_P13_DEB_3: 1;
        uint32_t PAD_P13_AON_MUX_3: 2;
        uint32_t PAD_P13_O_EN_3: 1;
        uint32_t PAD_P13_HS_MUX_3: 1;
        uint32_t PAD_P13_DUMMY1_3: 1;
    };
} AON_NS_P13_2_P13_3_PAD_CFG_TYPE;

/* 0x19D8   0x4000_19d8
    0       R/W PAD_P13_SHDN[4]                 1'b1
    1       R/W AON_PAD_P13_E[4]                1'b0
    2       R/W AON_PAD_P13_O[4]                1'b0
    3       R/W PAD_P13_E3[4]                   1'b0
    4       R/W PAD_P13_E2[4]                   1'b0
    5       R/W PAD_P13_PDPUC[4]                1'b0
    6       R/W AON_PAD_P13_PU[4]               1'b0
    7       R/W AON_PAD_P13_PU_EN[4]            1'b1
    8       R/W PAD_P13_WKPOL[4]                1'b0
    9       R/W PAD_P13_WKEN[4]                 1'b0
    10      R/W PAD_P13_DEB[4]                  1'b0
    12:11   R/W PAD_P13_AON_MUX[4]              2'b0
    13      R/W PAD_P13_O_EN[4]                 1'b1
    14      R/W PAD_P13_HS_MUX[4]               1'b0
    15      R/W PAD_P13_DUMMY1[4]               1'b0
    16      R/W PAD_P13_SHDN[5]                 1'b1
    17      R/W AON_PAD_P13_E[5]                1'b0
    18      R/W AON_PAD_P13_O[5]                1'b0
    19      R/W PAD_P13_E3[5]                   1'b0
    20      R/W PAD_P13_E2[5]                   1'b0
    21      R/W PAD_P13_PDPUC[5]                1'b0
    22      R/W AON_PAD_P13_PU[5]               1'b0
    23      R/W AON_PAD_P13_PU_EN[5]            1'b1
    24      R/W PAD_P13_WKPOL[5]                1'b0
    25      R/W PAD_P13_WKEN[5]                 1'b0
    26      R/W PAD_P13_DEB[5]                  1'b0
    28:27   R/W PAD_P13_AON_MUX[5]              2'b0
    29      R/W PAD_P13_O_EN[5]                 1'b1
    30      R/W PAD_P13_DUMMY0[5]               1'b0
    31      R/W PAD_P13_DUMMY1[5]               1'b0
 */
typedef volatile union _AON_NS_P13_4_P13_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P13_SHDN_4: 1;
        uint32_t AON_PAD_P13_E_4: 1;
        uint32_t AON_PAD_P13_O_4: 1;
        uint32_t PAD_P13_E3_4: 1;
        uint32_t PAD_P13_E2_4: 1;
        uint32_t PAD_P13_PDPUC_4: 1;
        uint32_t AON_PAD_P13_PU_4: 1;
        uint32_t AON_PAD_P13_PU_EN_4: 1;
        uint32_t PAD_P13_WKPOL_4: 1;
        uint32_t PAD_P13_WKEN_4: 1;
        uint32_t PAD_P13_DEB_4: 1;
        uint32_t PAD_P13_AON_MUX_4: 2;
        uint32_t PAD_P13_O_EN_4: 1;
        uint32_t PAD_P13_HS_MUX_4: 1;
        uint32_t PAD_P13_DUMMY1_4: 1;
        uint32_t PAD_P13_SHDN_5: 1;
        uint32_t AON_PAD_P13_E_5: 1;
        uint32_t AON_PAD_P13_O_5: 1;
        uint32_t PAD_P13_E3_5: 1;
        uint32_t PAD_P13_E2_5: 1;
        uint32_t PAD_P13_PDPUC_5: 1;
        uint32_t AON_PAD_P13_PU_5: 1;
        uint32_t AON_PAD_P13_PU_EN_5: 1;
        uint32_t PAD_P13_WKPOL_5: 1;
        uint32_t PAD_P13_WKEN_5: 1;
        uint32_t PAD_P13_DEB_5: 1;
        uint32_t PAD_P13_AON_MUX_5: 2;
        uint32_t PAD_P13_O_EN_5: 1;
        uint32_t PAD_P13_DUMMY0_5: 1;
        uint32_t PAD_P13_DUMMY1_5: 1;
    };
} AON_NS_P13_4_P13_5_PAD_CFG_TYPE;

/* 0x19DC   0x4000_19dc
    0       R/W PAD_P13_SHDN[6]                 1'b1
    1       R/W AON_PAD_P13_E[6]                1'b0
    2       R/W AON_PAD_P13_O[6]                1'b0
    3       R/W PAD_P13_E3[6]                   1'b0
    4       R/W PAD_P13_E2[6]                   1'b0
    5       R/W PAD_P13_PDPUC[6]                1'b0
    6       R/W AON_PAD_P13_PU[6]               1'b0
    7       R/W AON_PAD_P13_PU_EN[6]            1'b1
    8       R/W PAD_P13_WKPOL[6]                1'b0
    9       R/W PAD_P13_WKEN[6]                 1'b0
    10      R/W PAD_P13_DEB[6]                  1'b0
    12:11   R/W PAD_P13_AON_MUX[6]              2'b0
    13      R/W PAD_P13_O_EN[6]                 1'b1
    14      R/W PAD_P13_DUMMY0[6]               1'b0
    15      R/W PAD_P13_DUMMY1[6]               1'b0
    16      R/W PAD_P13_SHDN[7]                 1'b1
    17      R/W AON_PAD_P13_E[7]                1'b0
    18      R/W AON_PAD_P13_O[7]                1'b0
    19      R/W PAD_P13_E3[7]                   1'b0
    20      R/W PAD_P13_E2[7]                   1'b0
    21      R/W PAD_P13_PDPUC[7]                1'b0
    22      R/W AON_PAD_P13_PU[7]               1'b1
    23      R/W AON_PAD_P13_PU_EN[7]            1'b1
    24      R/W PAD_P13_WKPOL[7]                1'b0
    25      R/W PAD_P13_WKEN[7]                 1'b0
    26      R/W PAD_P13_DEB[7]                  1'b0
    28:27   R/W PAD_P13_AON_MUX[7]              2'b0
    29      R/W PAD_P13_O_EN[7]                 1'b1
    30      R/W PAD_P13_DUMMY0[7]               1'b0
    31      R/W PAD_P13_DUMMY1[7]               1'b0
 */
typedef volatile union _AON_NS_P13_6_P13_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P13_SHDN_6: 1;
        uint32_t AON_PAD_P13_E_6: 1;
        uint32_t AON_PAD_P13_O_6: 1;
        uint32_t PAD_P13_E3_6: 1;
        uint32_t PAD_P13_E2_6: 1;
        uint32_t PAD_P13_PDPUC_6: 1;
        uint32_t AON_PAD_P13_PU_6: 1;
        uint32_t AON_PAD_P13_PU_EN_6: 1;
        uint32_t PAD_P13_WKPOL_6: 1;
        uint32_t PAD_P13_WKEN_6: 1;
        uint32_t PAD_P13_DEB_6: 1;
        uint32_t PAD_P13_AON_MUX_6: 2;
        uint32_t PAD_P13_O_EN_6: 1;
        uint32_t PAD_P13_DUMMY0_6: 1;
        uint32_t PAD_P13_DUMMY1_6: 1;
        uint32_t PAD_P13_SHDN_7: 1;
        uint32_t AON_PAD_P13_E_7: 1;
        uint32_t AON_PAD_P13_O_7: 1;
        uint32_t PAD_P13_E3_7: 1;
        uint32_t PAD_P13_E2_7: 1;
        uint32_t PAD_P13_PDPUC_7: 1;
        uint32_t AON_PAD_P13_PU_7: 1;
        uint32_t AON_PAD_P13_PU_EN_7: 1;
        uint32_t PAD_P13_WKPOL_7: 1;
        uint32_t PAD_P13_WKEN_7: 1;
        uint32_t PAD_P13_DEB_7: 1;
        uint32_t PAD_P13_AON_MUX_7: 2;
        uint32_t PAD_P13_O_EN_7: 1;
        uint32_t PAD_P13_DUMMY0_7: 1;
        uint32_t PAD_P13_DUMMY1_7: 1;
    };
} AON_NS_P13_6_P13_7_PAD_CFG_TYPE;

/* 0x19E0   0x4000_19e0
    0       R/W PAD_P14_SHDN[0]                 1'b1
    1       R/W AON_PAD_P14_E[0]                1'b0
    2       R/W AON_PAD_P14_O[0]                1'b0
    3       R/W PAD_P14_E3[0]                   1'b0
    4       R/W PAD_P14_E2[0]                   1'b0
    5       R/W PAD_P14_PDPUC[0]                1'b0
    6       R/W AON_PAD_P14_PU[0]               1'b0
    7       R/W AON_PAD_P14_PU_EN[0]            1'b1
    8       R/W PAD_P14_WKPOL[0]                1'b0
    9       R/W PAD_P14_WKEN[0]                 1'b0
    10      R/W PAD_P14_DEB[0]                  1'b0
    12:11   R/W PAD_P14_AON_MUX[0]              2'b0
    13      R/W PAD_P14_O_EN[0]                 1'b1
    14      R/W PAD_P14_DUMMY0[0]               1'b0
    15      R/W PAD_P14_DUMMY1[0]               1'b0
    16      R/W PAD_P14_SHDN[1]                 1'b1
    17      R/W AON_PAD_P14_E[1]                1'b0
    18      R/W AON_PAD_P14_O[1]                1'b0
    19      R/W PAD_P14_E3[1]                   1'b0
    20      R/W PAD_P14_E2[1]                   1'b0
    21      R/W PAD_P14_PDPUC[1]                1'b0
    22      R/W AON_PAD_P14_PU[1]               1'b0
    23      R/W AON_PAD_P14_PU_EN[1]            1'b1
    24      R/W PAD_P14_WKPOL[1]                1'b0
    25      R/W PAD_P14_WKEN[1]                 1'b0
    26      R/W PAD_P14_DEB[1]                  1'b0
    28:27   R/W PAD_P14_AON_MUX[1]              2'b0
    29      R/W PAD_P14_O_EN[1]                 1'b1
    30      R/W PAD_P14_DUMMY0[1]               1'b0
    31      R/W PAD_P14_DUMMY1[1]               1'b0
 */
typedef volatile union _AON_NS_P14_0_P14_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P14_SHDN_0: 1;
        uint32_t AON_PAD_P14_E_0: 1;
        uint32_t AON_PAD_P14_O_0: 1;
        uint32_t PAD_P14_E3_0: 1;
        uint32_t PAD_P14_E2_0: 1;
        uint32_t PAD_P14_PDPUC_0: 1;
        uint32_t AON_PAD_P14_PU_0: 1;
        uint32_t AON_PAD_P14_PU_EN_0: 1;
        uint32_t PAD_P14_WKPOL_0: 1;
        uint32_t PAD_P14_WKEN_0: 1;
        uint32_t PAD_P14_DEB_0: 1;
        uint32_t PAD_P14_AON_MUX_0: 2;
        uint32_t PAD_P14_O_EN_0: 1;
        uint32_t PAD_P14_DUMMY0_0: 1;
        uint32_t PAD_P14_DUMMY1_0: 1;
        uint32_t PAD_P14_SHDN_1: 1;
        uint32_t AON_PAD_P14_E_1: 1;
        uint32_t AON_PAD_P14_O_1: 1;
        uint32_t PAD_P14_E3_1: 1;
        uint32_t PAD_P14_E2_1: 1;
        uint32_t PAD_P14_PDPUC_1: 1;
        uint32_t AON_PAD_P14_PU_1: 1;
        uint32_t AON_PAD_P14_PU_EN_1: 1;
        uint32_t PAD_P14_WKPOL_1: 1;
        uint32_t PAD_P14_WKEN_1: 1;
        uint32_t PAD_P14_DEB_1: 1;
        uint32_t PAD_P14_AON_MUX_1: 2;
        uint32_t PAD_P14_O_EN_1: 1;
        uint32_t PAD_P14_DUMMY0_1: 1;
        uint32_t PAD_P14_DUMMY1_1: 1;
    };
} AON_NS_P14_0_P14_1_PAD_CFG_TYPE;

/* 0x19E4   0x4000_19e4
    0       R/W PAD_P14_SHDN[2]                 1'b1
    1       R/W AON_PAD_P14_E[2]                1'b0
    2       R/W AON_PAD_P14_O[2]                1'b0
    3       R/W PAD_P14_E3[2]                   1'b0
    4       R/W PAD_P14_E2[2]                   1'b0
    5       R/W PAD_P14_PDPUC[2]                1'b0
    6       R/W AON_PAD_P14_PU[2]               1'b0
    7       R/W AON_PAD_P14_PU_EN[2]            1'b1
    8       R/W PAD_P14_WKPOL[2]                1'b0
    9       R/W PAD_P14_WKEN[2]                 1'b0
    10      R/W PAD_P14_DEB[2]                  1'b0
    12:11   R/W PAD_P14_AON_MUX[2]              2'b0
    13      R/W PAD_P14_O_EN[2]                 1'b1
    14      R/W PAD_P14_HS_MUX[2]               1'b0
    15      R/W PAD_P14_DUMMY1[2]               1'b0
    16      R/W PAD_P14_SHDN[3]                 1'b1
    17      R/W AON_PAD_P14_E[3]                1'b0
    18      R/W AON_PAD_P14_O[3]                1'b0
    19      R/W PAD_P14_E3[3]                   1'b0
    20      R/W PAD_P14_E2[3]                   1'b0
    21      R/W PAD_P14_PDPUC[3]                1'b0
    22      R/W AON_PAD_P14_PU[3]               1'b0
    23      R/W AON_PAD_P14_PU_EN[3]            1'b1
    24      R/W PAD_P14_WKPOL[3]                1'b0
    25      R/W PAD_P14_WKEN[3]                 1'b0
    26      R/W PAD_P14_DEB[3]                  1'b0
    28:27   R/W PAD_P14_AON_MUX[3]              2'b0
    29      R/W PAD_P14_O_EN[3]                 1'b1
    30      R/W PAD_P14_HS_MUX[3]               1'b0
    31      R/W PAD_P14_DUMMY1[3]               1'b0
 */
typedef volatile union _AON_NS_P14_2_P14_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P14_SHDN_2: 1;
        uint32_t AON_PAD_P14_E_2: 1;
        uint32_t AON_PAD_P14_O_2: 1;
        uint32_t PAD_P14_E3_2: 1;
        uint32_t PAD_P14_E2_2: 1;
        uint32_t PAD_P14_PDPUC_2: 1;
        uint32_t AON_PAD_P14_PU_2: 1;
        uint32_t AON_PAD_P14_PU_EN_2: 1;
        uint32_t PAD_P14_WKPOL_2: 1;
        uint32_t PAD_P14_WKEN_2: 1;
        uint32_t PAD_P14_DEB_2: 1;
        uint32_t PAD_P14_AON_MUX_2: 2;
        uint32_t PAD_P14_O_EN_2: 1;
        uint32_t PAD_P14_HS_MUX_2: 1;
        uint32_t PAD_P14_DUMMY1_2: 1;
        uint32_t PAD_P14_SHDN_3: 1;
        uint32_t AON_PAD_P14_E_3: 1;
        uint32_t AON_PAD_P14_O_3: 1;
        uint32_t PAD_P14_E3_3: 1;
        uint32_t PAD_P14_E2_3: 1;
        uint32_t PAD_P14_PDPUC_3: 1;
        uint32_t AON_PAD_P14_PU_3: 1;
        uint32_t AON_PAD_P14_PU_EN_3: 1;
        uint32_t PAD_P14_WKPOL_3: 1;
        uint32_t PAD_P14_WKEN_3: 1;
        uint32_t PAD_P14_DEB_3: 1;
        uint32_t PAD_P14_AON_MUX_3: 2;
        uint32_t PAD_P14_O_EN_3: 1;
        uint32_t PAD_P14_HS_MUX_3: 1;
        uint32_t PAD_P14_DUMMY1_3: 1;
    };
} AON_NS_P14_2_P14_3_PAD_CFG_TYPE;

/* 0x19E8   0x4000_19e8
    0       R/W PAD_P14_SHDN[4]                 1'b1
    1       R/W AON_PAD_P14_E[4]                1'b0
    2       R/W AON_PAD_P14_O[4]                1'b0
    3       R/W PAD_P14_E3[4]                   1'b0
    4       R/W PAD_P14_E2[4]                   1'b0
    5       R/W PAD_P14_PDPUC[4]                1'b0
    6       R/W AON_PAD_P14_PU[4]               1'b0
    7       R/W AON_PAD_P14_PU_EN[4]            1'b1
    8       R/W PAD_P14_WKPOL[4]                1'b0
    9       R/W PAD_P14_WKEN[4]                 1'b0
    10      R/W PAD_P14_DEB[4]                  1'b0
    12:11   R/W PAD_P14_AON_MUX[4]              2'b0
    13      R/W PAD_P14_O_EN[4]                 1'b1
    14      R/W PAD_P14_HS_MUX[4]               1'b0
    15      R/W PAD_P14_DUMMY1[4]               1'b0
    16      R/W PAD_P14_SHDN[5]                 1'b1
    17      R/W AON_PAD_P14_E[5]                1'b0
    18      R/W AON_PAD_P14_O[5]                1'b0
    19      R/W PAD_P14_E3[5]                   1'b0
    20      R/W PAD_P14_E2[5]                   1'b0
    21      R/W PAD_P14_PDPUC[5]                1'b0
    22      R/W AON_PAD_P14_PU[5]               1'b0
    23      R/W AON_PAD_P14_PU_EN[5]            1'b1
    24      R/W PAD_P14_WKPOL[5]                1'b0
    25      R/W PAD_P14_WKEN[5]                 1'b0
    26      R/W PAD_P14_DEB[5]                  1'b0
    28:27   R/W PAD_P14_AON_MUX[5]              2'b0
    29      R/W PAD_P14_O_EN[5]                 1'b1
    30      R/W PAD_P14_HS_MUX[5]               1'b0
    31      R/W PAD_P14_DUMMY1[5]               1'b0
 */
typedef volatile union _AON_NS_P14_4_P14_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P14_SHDN_4: 1;
        uint32_t AON_PAD_P14_E_4: 1;
        uint32_t AON_PAD_P14_O_4: 1;
        uint32_t PAD_P14_E3_4: 1;
        uint32_t PAD_P14_E2_4: 1;
        uint32_t PAD_P14_PDPUC_4: 1;
        uint32_t AON_PAD_P14_PU_4: 1;
        uint32_t AON_PAD_P14_PU_EN_4: 1;
        uint32_t PAD_P14_WKPOL_4: 1;
        uint32_t PAD_P14_WKEN_4: 1;
        uint32_t PAD_P14_DEB_4: 1;
        uint32_t PAD_P14_AON_MUX_4: 2;
        uint32_t PAD_P14_O_EN_4: 1;
        uint32_t PAD_P14_HS_MUX_4: 1;
        uint32_t PAD_P14_DUMMY1_4: 1;
        uint32_t PAD_P14_SHDN_5: 1;
        uint32_t AON_PAD_P14_E_5: 1;
        uint32_t AON_PAD_P14_O_5: 1;
        uint32_t PAD_P14_E3_5: 1;
        uint32_t PAD_P14_E2_5: 1;
        uint32_t PAD_P14_PDPUC_5: 1;
        uint32_t AON_PAD_P14_PU_5: 1;
        uint32_t AON_PAD_P14_PU_EN_5: 1;
        uint32_t PAD_P14_WKPOL_5: 1;
        uint32_t PAD_P14_WKEN_5: 1;
        uint32_t PAD_P14_DEB_5: 1;
        uint32_t PAD_P14_AON_MUX_5: 2;
        uint32_t PAD_P14_O_EN_5: 1;
        uint32_t PAD_P14_HS_MUX_5: 1;
        uint32_t PAD_P14_DUMMY1_5: 1;
    };
} AON_NS_P14_4_P14_5_PAD_CFG_TYPE;

/* 0x19EC   0x4000_19ec
    0       R/W PAD_P14_SHDN[6]                 1'b1
    1       R/W AON_PAD_P14_E[6]                1'b0
    2       R/W AON_PAD_P14_O[6]                1'b0
    3       R/W PAD_P14_E3[6]                   1'b0
    4       R/W PAD_P14_E2[6]                   1'b0
    5       R/W PAD_P14_PDPUC[6]                1'b0
    6       R/W AON_PAD_P14_PU[6]               1'b0
    7       R/W AON_PAD_P14_PU_EN[6]            1'b1
    8       R/W PAD_P14_WKPOL[6]                1'b0
    9       R/W PAD_P14_WKEN[6]                 1'b0
    10      R/W PAD_P14_DEB[6]                  1'b0
    12:11   R/W PAD_P14_AON_MUX[6]              2'b0
    13      R/W PAD_P14_O_EN[6]                 1'b1
    14      R/W PAD_P14_HS_MUX[6]               1'b0
    15      R/W PAD_P14_DUMMY1[6]               1'b0
    16      R/W PAD_P14_SHDN[7]                 1'b1
    17      R/W AON_PAD_P14_E[7]                1'b0
    18      R/W AON_PAD_P14_O[7]                1'b0
    19      R/W PAD_P14_E3[7]                   1'b0
    20      R/W PAD_P14_E2[7]                   1'b0
    21      R/W PAD_P14_PDPUC[7]                1'b0
    22      R/W AON_PAD_P14_PU[7]               1'b0
    23      R/W AON_PAD_P14_PU_EN[7]            1'b1
    24      R/W PAD_P14_WKPOL[7]                1'b0
    25      R/W PAD_P14_WKEN[7]                 1'b0
    26      R/W PAD_P14_DEB[7]                  1'b0
    28:27   R/W PAD_P14_AON_MUX[7]              2'b0
    29      R/W PAD_P14_O_EN[7]                 1'b1
    30      R/W PAD_P14_HS_MUX[7]               1'b0
    31      R/W PAD_P14_DUMMY1[7]               1'b0
 */
typedef volatile union _AON_NS_P14_6_P14_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P14_SHDN_6: 1;
        uint32_t AON_PAD_P14_E_6: 1;
        uint32_t AON_PAD_P14_O_6: 1;
        uint32_t PAD_P14_E3_6: 1;
        uint32_t PAD_P14_E2_6: 1;
        uint32_t PAD_P14_PDPUC_6: 1;
        uint32_t AON_PAD_P14_PU_6: 1;
        uint32_t AON_PAD_P14_PU_EN_6: 1;
        uint32_t PAD_P14_WKPOL_6: 1;
        uint32_t PAD_P14_WKEN_6: 1;
        uint32_t PAD_P14_DEB_6: 1;
        uint32_t PAD_P14_AON_MUX_6: 2;
        uint32_t PAD_P14_O_EN_6: 1;
        uint32_t PAD_P14_HS_MUX_6: 1;
        uint32_t PAD_P14_DUMMY1_6: 1;
        uint32_t PAD_P14_SHDN_7: 1;
        uint32_t AON_PAD_P14_E_7: 1;
        uint32_t AON_PAD_P14_O_7: 1;
        uint32_t PAD_P14_E3_7: 1;
        uint32_t PAD_P14_E2_7: 1;
        uint32_t PAD_P14_PDPUC_7: 1;
        uint32_t AON_PAD_P14_PU_7: 1;
        uint32_t AON_PAD_P14_PU_EN_7: 1;
        uint32_t PAD_P14_WKPOL_7: 1;
        uint32_t PAD_P14_WKEN_7: 1;
        uint32_t PAD_P14_DEB_7: 1;
        uint32_t PAD_P14_AON_MUX_7: 2;
        uint32_t PAD_P14_O_EN_7: 1;
        uint32_t PAD_P14_HS_MUX_7: 1;
        uint32_t PAD_P14_DUMMY1_7: 1;
    };
} AON_NS_P14_6_P14_7_PAD_CFG_TYPE;

/* 0x19F0   0x4000_19f0
    0       R/W PAD_P15_SHDN[0]                 1'b1
    1       R/W AON_PAD_P15_E[0]                1'b0
    2       R/W AON_PAD_P15_O[0]                1'b0
    3       R/W PAD_P15_E3[0]                   1'b0
    4       R/W PAD_P15_E2[0]                   1'b0
    5       R/W PAD_P15_PDPUC[0]                1'b0
    6       R/W AON_PAD_P15_PU[0]               1'b0
    7       R/W AON_PAD_P15_PU_EN[0]            1'b1
    8       R/W PAD_P15_WKPOL[0]                1'b0
    9       R/W PAD_P15_WKEN[0]                 1'b0
    10      R/W PAD_P15_DEB[0]                  1'b0
    12:11   R/W PAD_P15_AON_MUX[0]              2'b0
    13      R/W PAD_P15_O_EN[0]                 1'b1
    14      R/W PAD_P15_HS_MUX[0]               1'b0
    15      R/W PAD_P15_DUMMY1[0]               1'b0
    16      R/W PAD_P15_SHDN[1]                 1'b1
    17      R/W AON_PAD_P15_E[1]                1'b0
    18      R/W AON_PAD_P15_O[1]                1'b0
    19      R/W PAD_P15_E3[1]                   1'b0
    20      R/W PAD_P15_E2[1]                   1'b0
    21      R/W PAD_P15_PDPUC[1]                1'b0
    22      R/W AON_PAD_P15_PU[1]               1'b0
    23      R/W AON_PAD_P15_PU_EN[1]            1'b1
    24      R/W PAD_P15_WKPOL[1]                1'b0
    25      R/W PAD_P15_WKEN[1]                 1'b0
    26      R/W PAD_P15_DEB[1]                  1'b0
    28:27   R/W PAD_P15_AON_MUX[1]              2'b0
    29      R/W PAD_P15_O_EN[1]                 1'b1
    30      R/W PAD_P15_HS_MUX[1]               1'b0
    31      R/W PAD_P15_DUMMY1[1]               1'b0
 */
typedef volatile union _AON_NS_P15_0_P15_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P15_SHDN_0: 1;
        uint32_t AON_PAD_P15_E_0: 1;
        uint32_t AON_PAD_P15_O_0: 1;
        uint32_t PAD_P15_E3_0: 1;
        uint32_t PAD_P15_E2_0: 1;
        uint32_t PAD_P15_PDPUC_0: 1;
        uint32_t AON_PAD_P15_PU_0: 1;
        uint32_t AON_PAD_P15_PU_EN_0: 1;
        uint32_t PAD_P15_WKPOL_0: 1;
        uint32_t PAD_P15_WKEN_0: 1;
        uint32_t PAD_P15_DEB_0: 1;
        uint32_t PAD_P15_AON_MUX_0: 2;
        uint32_t PAD_P15_O_EN_0: 1;
        uint32_t PAD_P15_HS_MUX_0: 1;
        uint32_t PAD_P15_DUMMY1_0: 1;
        uint32_t PAD_P15_SHDN_1: 1;
        uint32_t AON_PAD_P15_E_1: 1;
        uint32_t AON_PAD_P15_O_1: 1;
        uint32_t PAD_P15_E3_1: 1;
        uint32_t PAD_P15_E2_1: 1;
        uint32_t PAD_P15_PDPUC_1: 1;
        uint32_t AON_PAD_P15_PU_1: 1;
        uint32_t AON_PAD_P15_PU_EN_1: 1;
        uint32_t PAD_P15_WKPOL_1: 1;
        uint32_t PAD_P15_WKEN_1: 1;
        uint32_t PAD_P15_DEB_1: 1;
        uint32_t PAD_P15_AON_MUX_1: 2;
        uint32_t PAD_P15_O_EN_1: 1;
        uint32_t PAD_P15_HS_MUX_1: 1;
        uint32_t PAD_P15_DUMMY1_1: 1;
    };
} AON_NS_P15_0_P15_1_PAD_CFG_TYPE;

/* 0x19F4   0x4000_19f4
    0       R/W PAD_P15_SHDN[2]                 1'b1
    1       R/W AON_PAD_P15_E[2]                1'b0
    2       R/W AON_PAD_P15_O[2]                1'b0
    3       R/W PAD_P15_E3[2]                   1'b0
    4       R/W PAD_P15_E2[2]                   1'b0
    5       R/W PAD_P15_PDPUC[2]                1'b0
    6       R/W AON_PAD_P15_PU[2]               1'b0
    7       R/W AON_PAD_P15_PU_EN[2]            1'b1
    8       R/W PAD_P15_WKPOL[2]                1'b0
    9       R/W PAD_P15_WKEN[2]                 1'b0
    10      R/W PAD_P15_DEB[2]                  1'b0
    12:11   R/W PAD_P15_AON_MUX[2]              2'b0
    13      R/W PAD_P15_O_EN[2]                 1'b1
    14      R/W PAD_P15_HS_MUX[2]               1'b0
    15      R/W PAD_P15_DUMMY1[2]               1'b0
    16      R/W PAD_P15_SHDN[3]                 1'b1
    17      R/W AON_PAD_P15_E[3]                1'b0
    18      R/W AON_PAD_P15_O[3]                1'b0
    19      R/W PAD_P15_E3[3]                   1'b0
    20      R/W PAD_P15_E2[3]                   1'b0
    21      R/W PAD_P15_PDPUC[3]                1'b0
    22      R/W AON_PAD_P15_PU[3]               1'b0
    23      R/W AON_PAD_P15_PU_EN[3]            1'b1
    24      R/W PAD_P15_WKPOL[3]                1'b0
    25      R/W PAD_P15_WKEN[3]                 1'b0
    26      R/W PAD_P15_DEB[3]                  1'b0
    28:27   R/W PAD_P15_AON_MUX[3]              2'b0
    29      R/W PAD_P15_O_EN[3]                 1'b1
    30      R/W PAD_P15_HS_MUX[3]               1'b0
    31      R/W PAD_P15_DUMMY1[3]               1'b0
 */
typedef volatile union _AON_NS_P15_2_P15_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P15_SHDN_2: 1;
        uint32_t AON_PAD_P15_E_2: 1;
        uint32_t AON_PAD_P15_O_2: 1;
        uint32_t PAD_P15_E3_2: 1;
        uint32_t PAD_P15_E2_2: 1;
        uint32_t PAD_P15_PDPUC_2: 1;
        uint32_t AON_PAD_P15_PU_2: 1;
        uint32_t AON_PAD_P15_PU_EN_2: 1;
        uint32_t PAD_P15_WKPOL_2: 1;
        uint32_t PAD_P15_WKEN_2: 1;
        uint32_t PAD_P15_DEB_2: 1;
        uint32_t PAD_P15_AON_MUX_2: 2;
        uint32_t PAD_P15_O_EN_2: 1;
        uint32_t PAD_P15_HS_MUX_2: 1;
        uint32_t PAD_P15_DUMMY1_2: 1;
        uint32_t PAD_P15_SHDN_3: 1;
        uint32_t AON_PAD_P15_E_3: 1;
        uint32_t AON_PAD_P15_O_3: 1;
        uint32_t PAD_P15_E3_3: 1;
        uint32_t PAD_P15_E2_3: 1;
        uint32_t PAD_P15_PDPUC_3: 1;
        uint32_t AON_PAD_P15_PU_3: 1;
        uint32_t AON_PAD_P15_PU_EN_3: 1;
        uint32_t PAD_P15_WKPOL_3: 1;
        uint32_t PAD_P15_WKEN_3: 1;
        uint32_t PAD_P15_DEB_3: 1;
        uint32_t PAD_P15_AON_MUX_3: 2;
        uint32_t PAD_P15_O_EN_3: 1;
        uint32_t PAD_P15_HS_MUX_3: 1;
        uint32_t PAD_P15_DUMMY1_3: 1;
    };
} AON_NS_P15_2_P15_3_PAD_CFG_TYPE;

/* 0x19F8   0x4000_19f8
    0       R/W PAD_P15_SHDN[4]                 1'b1
    1       R/W AON_PAD_P15_E[4]                1'b0
    2       R/W AON_PAD_P15_O[4]                1'b0
    3       R/W PAD_P15_E3[4]                   1'b0
    4       R/W PAD_P15_E2[4]                   1'b0
    5       R/W PAD_P15_PDPUC[4]                1'b0
    6       R/W AON_PAD_P15_PU[4]               1'b0
    7       R/W AON_PAD_P15_PU_EN[4]            1'b1
    8       R/W PAD_P15_WKPOL[4]                1'b0
    9       R/W PAD_P15_WKEN[4]                 1'b0
    10      R/W PAD_P15_DEB[4]                  1'b0
    12:11   R/W PAD_P15_AON_MUX[4]              2'b0
    13      R/W PAD_P15_O_EN[4]                 1'b1
    14      R/W PAD_P15_HS_MUX[4]               1'b0
    15      R/W PAD_P15_DUMMY1[4]               1'b0
    16      R/W PAD_P15_SHDN[5]                 1'b1
    17      R/W AON_PAD_P15_E[5]                1'b0
    18      R/W AON_PAD_P15_O[5]                1'b0
    19      R/W PAD_P15_E3[5]                   1'b0
    20      R/W PAD_P15_E2[5]                   1'b0
    21      R/W PAD_P15_PDPUC[5]                1'b0
    22      R/W AON_PAD_P15_PU[5]               1'b0
    23      R/W AON_PAD_P15_PU_EN[5]            1'b1
    24      R/W PAD_P15_WKPOL[5]                1'b0
    25      R/W PAD_P15_WKEN[5]                 1'b0
    26      R/W PAD_P15_DEB[5]                  1'b0
    28:27   R/W PAD_P15_AON_MUX[5]              2'b0
    29      R/W PAD_P15_O_EN[5]                 1'b1
    30      R/W PAD_P15_HS_MUX[5]               1'b0
    31      R/W PAD_P15_DUMMY1[5]               1'b0
 */
typedef volatile union _AON_NS_P15_4_P15_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P15_SHDN_4: 1;
        uint32_t AON_PAD_P15_E_4: 1;
        uint32_t AON_PAD_P15_O_4: 1;
        uint32_t PAD_P15_E3_4: 1;
        uint32_t PAD_P15_E2_4: 1;
        uint32_t PAD_P15_PDPUC_4: 1;
        uint32_t AON_PAD_P15_PU_4: 1;
        uint32_t AON_PAD_P15_PU_EN_4: 1;
        uint32_t PAD_P15_WKPOL_4: 1;
        uint32_t PAD_P15_WKEN_4: 1;
        uint32_t PAD_P15_DEB_4: 1;
        uint32_t PAD_P15_AON_MUX_4: 2;
        uint32_t PAD_P15_O_EN_4: 1;
        uint32_t PAD_P15_HS_MUX_4: 1;
        uint32_t PAD_P15_DUMMY1_4: 1;
        uint32_t PAD_P15_SHDN_5: 1;
        uint32_t AON_PAD_P15_E_5: 1;
        uint32_t AON_PAD_P15_O_5: 1;
        uint32_t PAD_P15_E3_5: 1;
        uint32_t PAD_P15_E2_5: 1;
        uint32_t PAD_P15_PDPUC_5: 1;
        uint32_t AON_PAD_P15_PU_5: 1;
        uint32_t AON_PAD_P15_PU_EN_5: 1;
        uint32_t PAD_P15_WKPOL_5: 1;
        uint32_t PAD_P15_WKEN_5: 1;
        uint32_t PAD_P15_DEB_5: 1;
        uint32_t PAD_P15_AON_MUX_5: 2;
        uint32_t PAD_P15_O_EN_5: 1;
        uint32_t PAD_P15_HS_MUX_5: 1;
        uint32_t PAD_P15_DUMMY1_5: 1;
    };
} AON_NS_P15_4_P15_5_PAD_CFG_TYPE;

/* 0x19FC   0x4000_19fc
    0       R/W PAD_P15_SHDN[6]                 1'b1
    1       R/W AON_PAD_P15_E[6]                1'b0
    2       R/W AON_PAD_P15_O[6]                1'b0
    3       R/W PAD_P15_E3[6]                   1'b0
    4       R/W PAD_P15_E2[6]                   1'b0
    5       R/W PAD_P15_PDPUC[6]                1'b0
    6       R/W AON_PAD_P15_PU[6]               1'b0
    7       R/W AON_PAD_P15_PU_EN[6]            1'b1
    8       R/W PAD_P15_WKPOL[6]                1'b0
    9       R/W PAD_P15_WKEN[6]                 1'b0
    10      R/W PAD_P15_DEB[6]                  1'b0
    12:11   R/W PAD_P15_AON_MUX[6]              2'b0
    13      R/W PAD_P15_O_EN[6]                 1'b1
    14      R/W PAD_P15_HS_MUX[6]               1'b0
    15      R/W PAD_P15_DUMMY1[6]               1'b0
    16      R/W PAD_P15_SHDN[7]                 1'b1
    17      R/W AON_PAD_P15_E[7]                1'b0
    18      R/W AON_PAD_P15_O[7]                1'b0
    19      R/W PAD_P15_E3[7]                   1'b0
    20      R/W PAD_P15_E2[7]                   1'b0
    21      R/W PAD_P15_PDPUC[7]                1'b0
    22      R/W AON_PAD_P15_PU[7]               1'b0
    23      R/W AON_PAD_P15_PU_EN[7]            1'b1
    24      R/W PAD_P15_WKPOL[7]                1'b0
    25      R/W PAD_P15_WKEN[7]                 1'b0
    26      R/W PAD_P15_DEB[7]                  1'b0
    28:27   R/W PAD_P15_AON_MUX[7]              2'b0
    29      R/W PAD_P15_O_EN[7]                 1'b1
    30      R/W PAD_P15_HS_MUX[7]               1'b0
    31      R/W PAD_P15_DUMMY1[7]               1'b0
 */
typedef volatile union _AON_NS_P15_6_P15_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P15_SHDN_6: 1;
        uint32_t AON_PAD_P15_E_6: 1;
        uint32_t AON_PAD_P15_O_6: 1;
        uint32_t PAD_P15_E3_6: 1;
        uint32_t PAD_P15_E2_6: 1;
        uint32_t PAD_P15_PDPUC_6: 1;
        uint32_t AON_PAD_P15_PU_6: 1;
        uint32_t AON_PAD_P15_PU_EN_6: 1;
        uint32_t PAD_P15_WKPOL_6: 1;
        uint32_t PAD_P15_WKEN_6: 1;
        uint32_t PAD_P15_DEB_6: 1;
        uint32_t PAD_P15_AON_MUX_6: 2;
        uint32_t PAD_P15_O_EN_6: 1;
        uint32_t PAD_P15_HS_MUX_6: 1;
        uint32_t PAD_P15_DUMMY1_6: 1;
        uint32_t PAD_P15_SHDN_7: 1;
        uint32_t AON_PAD_P15_E_7: 1;
        uint32_t AON_PAD_P15_O_7: 1;
        uint32_t PAD_P15_E3_7: 1;
        uint32_t PAD_P15_E2_7: 1;
        uint32_t PAD_P15_PDPUC_7: 1;
        uint32_t AON_PAD_P15_PU_7: 1;
        uint32_t AON_PAD_P15_PU_EN_7: 1;
        uint32_t PAD_P15_WKPOL_7: 1;
        uint32_t PAD_P15_WKEN_7: 1;
        uint32_t PAD_P15_DEB_7: 1;
        uint32_t PAD_P15_AON_MUX_7: 2;
        uint32_t PAD_P15_O_EN_7: 1;
        uint32_t PAD_P15_HS_MUX_7: 1;
        uint32_t PAD_P15_DUMMY1_7: 1;
    };
} AON_NS_P15_6_P15_7_PAD_CFG_TYPE;

/* 0x1A00   0x4000_1a00
    0       R/W PAD_P16_SHDN[0]                 1'b1
    1       R/W AON_PAD_P16_E[0]                1'b0
    2       R/W AON_PAD_P16_O[0]                1'b0
    3       R/W PAD_P16_E3[0]                   1'b0
    4       R/W PAD_P16_E2[0]                   1'b0
    5       R/W PAD_P16_PDPUC[0]                1'b0
    6       R/W AON_PAD_P16_PU[0]               1'b0
    7       R/W AON_PAD_P16_PU_EN[0]            1'b1
    8       R/W PAD_P16_WKPOL[0]                1'b0
    9       R/W PAD_P16_WKEN[0]                 1'b0
    10      R/W PAD_P16_DEB[0]                  1'b0
    12:11   R/W PAD_P16_AON_MUX[0]              2'b0
    13      R/W PAD_P16_O_EN[0]                 1'b1
    14      R/W PAD_P16_HS_MUX[0]               1'b0
    15      R/W PAD_P16_DUMMY1[0]               1'b0
    16      R/W PAD_P16_SHDN[1]                 1'b1
    17      R/W AON_PAD_P16_E[1]                1'b0
    18      R/W AON_PAD_P16_O[1]                1'b0
    19      R/W PAD_P16_E3[1]                   1'b0
    20      R/W PAD_P16_E2[1]                   1'b0
    21      R/W PAD_P16_PDPUC[1]                1'b0
    22      R/W AON_PAD_P16_PU[1]               1'b0
    23      R/W AON_PAD_P16_PU_EN[1]            1'b1
    24      R/W PAD_P16_WKPOL[1]                1'b0
    25      R/W PAD_P16_WKEN[1]                 1'b0
    26      R/W PAD_P16_DEB[1]                  1'b0
    28:27   R/W PAD_P16_AON_MUX[1]              2'b0
    29      R/W PAD_P16_O_EN[1]                 1'b1
    30      R/W PAD_P16_HS_MUX[1]               1'b0
    31      R/W PAD_P16_DUMMY1[1]               1'b0
 */
typedef volatile union _AON_NS_P16_0_P16_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P16_SHDN_0: 1;
        uint32_t AON_PAD_P16_E_0: 1;
        uint32_t AON_PAD_P16_O_0: 1;
        uint32_t PAD_P16_E3_0: 1;
        uint32_t PAD_P16_E2_0: 1;
        uint32_t PAD_P16_PDPUC_0: 1;
        uint32_t AON_PAD_P16_PU_0: 1;
        uint32_t AON_PAD_P16_PU_EN_0: 1;
        uint32_t PAD_P16_WKPOL_0: 1;
        uint32_t PAD_P16_WKEN_0: 1;
        uint32_t PAD_P16_DEB_0: 1;
        uint32_t PAD_P16_AON_MUX_0: 2;
        uint32_t PAD_P16_O_EN_0: 1;
        uint32_t PAD_P16_HS_MUX_0: 1;
        uint32_t PAD_P16_DUMMY1_0: 1;
        uint32_t PAD_P16_SHDN_1: 1;
        uint32_t AON_PAD_P16_E_1: 1;
        uint32_t AON_PAD_P16_O_1: 1;
        uint32_t PAD_P16_E3_1: 1;
        uint32_t PAD_P16_E2_1: 1;
        uint32_t PAD_P16_PDPUC_1: 1;
        uint32_t AON_PAD_P16_PU_1: 1;
        uint32_t AON_PAD_P16_PU_EN_1: 1;
        uint32_t PAD_P16_WKPOL_1: 1;
        uint32_t PAD_P16_WKEN_1: 1;
        uint32_t PAD_P16_DEB_1: 1;
        uint32_t PAD_P16_AON_MUX_1: 2;
        uint32_t PAD_P16_O_EN_1: 1;
        uint32_t PAD_P16_HS_MUX_1: 1;
        uint32_t PAD_P16_DUMMY1_1: 1;
    };
} AON_NS_P16_0_P16_1_PAD_CFG_TYPE;

/* 0x1A04   0x4000_1a04
    0       R/W PAD_P16_SHDN[2]                 1'b1
    1       R/W AON_PAD_P16_E[2]                1'b0
    2       R/W AON_PAD_P16_O[2]                1'b0
    3       R/W PAD_P16_E3[2]                   1'b0
    4       R/W PAD_P16_E2[2]                   1'b0
    5       R/W PAD_P16_PDPUC[2]                1'b0
    6       R/W AON_PAD_P16_PU[2]               1'b0
    7       R/W AON_PAD_P16_PU_EN[2]            1'b1
    8       R/W PAD_P16_WKPOL[2]                1'b0
    9       R/W PAD_P16_WKEN[2]                 1'b0
    10      R/W PAD_P16_DEB[2]                  1'b0
    12:11   R/W PAD_P16_AON_MUX[2]              2'b0
    13      R/W PAD_P16_O_EN[2]                 1'b1
    14      R/W PAD_P16_HS_MUX[2]               1'b0
    15      R/W PAD_P16_DUMMY1[2]               1'b0
    16      R/W PAD_P16_SHDN[3]                 1'b1
    17      R/W AON_PAD_P16_E[3]                1'b0
    18      R/W AON_PAD_P16_O[3]                1'b0
    19      R/W PAD_P16_E3[3]                   1'b0
    20      R/W PAD_P16_E2[3]                   1'b0
    21      R/W PAD_P16_PDPUC[3]                1'b0
    22      R/W AON_PAD_P16_PU[3]               1'b0
    23      R/W AON_PAD_P16_PU_EN[3]            1'b1
    24      R/W PAD_P16_WKPOL[3]                1'b0
    25      R/W PAD_P16_WKEN[3]                 1'b0
    26      R/W PAD_P16_DEB[3]                  1'b0
    28:27   R/W PAD_P16_AON_MUX[3]              2'b0
    29      R/W PAD_P16_O_EN[3]                 1'b1
    30      R/W PAD_P16_HS_MUX[3]               1'b0
    31      R/W PAD_P16_DUMMY1[3]               1'b0
 */
typedef volatile union _AON_NS_P16_2_P16_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P16_SHDN_2: 1;
        uint32_t AON_PAD_P16_E_2: 1;
        uint32_t AON_PAD_P16_O_2: 1;
        uint32_t PAD_P16_E3_2: 1;
        uint32_t PAD_P16_E2_2: 1;
        uint32_t PAD_P16_PDPUC_2: 1;
        uint32_t AON_PAD_P16_PU_2: 1;
        uint32_t AON_PAD_P16_PU_EN_2: 1;
        uint32_t PAD_P16_WKPOL_2: 1;
        uint32_t PAD_P16_WKEN_2: 1;
        uint32_t PAD_P16_DEB_2: 1;
        uint32_t PAD_P16_AON_MUX_2: 2;
        uint32_t PAD_P16_O_EN_2: 1;
        uint32_t PAD_P16_HS_MUX_2: 1;
        uint32_t PAD_P16_DUMMY1_2: 1;
        uint32_t PAD_P16_SHDN_3: 1;
        uint32_t AON_PAD_P16_E_3: 1;
        uint32_t AON_PAD_P16_O_3: 1;
        uint32_t PAD_P16_E3_3: 1;
        uint32_t PAD_P16_E2_3: 1;
        uint32_t PAD_P16_PDPUC_3: 1;
        uint32_t AON_PAD_P16_PU_3: 1;
        uint32_t AON_PAD_P16_PU_EN_3: 1;
        uint32_t PAD_P16_WKPOL_3: 1;
        uint32_t PAD_P16_WKEN_3: 1;
        uint32_t PAD_P16_DEB_3: 1;
        uint32_t PAD_P16_AON_MUX_3: 2;
        uint32_t PAD_P16_O_EN_3: 1;
        uint32_t PAD_P16_HS_MUX_3: 1;
        uint32_t PAD_P16_DUMMY1_3: 1;
    };
} AON_NS_P16_2_P16_3_PAD_CFG_TYPE;

/* 0x1A08   0x4000_1a08
    0       R/W PAD_P16_SHDN[4]                 1'b1
    1       R/W AON_PAD_P16_E[4]                1'b0
    2       R/W AON_PAD_P16_O[4]                1'b0
    3       R/W PAD_P16_E3[4]                   1'b0
    4       R/W PAD_P16_E2[4]                   1'b0
    5       R/W PAD_P16_PDPUC[4]                1'b0
    6       R/W AON_PAD_P16_PU[4]               1'b0
    7       R/W AON_PAD_P16_PU_EN[4]            1'b1
    8       R/W PAD_P16_WKPOL[4]                1'b0
    9       R/W PAD_P16_WKEN[4]                 1'b0
    10      R/W PAD_P16_DEB[4]                  1'b0
    12:11   R/W PAD_P16_AON_MUX[4]              2'b0
    13      R/W PAD_P16_O_EN[4]                 1'b1
    14      R/W PAD_P16_HS_MUX[4]               1'b0
    15      R/W PAD_P16_DUMMY1[4]               1'b0
    16      R/W PAD_P16_SHDN[5]                 1'b1
    17      R/W AON_PAD_P16_E[5]                1'b0
    18      R/W AON_PAD_P16_O[5]                1'b0
    19      R/W PAD_P16_E3[5]                   1'b0
    20      R/W PAD_P16_E2[5]                   1'b0
    21      R/W PAD_P16_PDPUC[5]                1'b0
    22      R/W AON_PAD_P16_PU[5]               1'b0
    23      R/W AON_PAD_P16_PU_EN[5]            1'b1
    24      R/W PAD_P16_WKPOL[5]                1'b0
    25      R/W PAD_P16_WKEN[5]                 1'b0
    26      R/W PAD_P16_DEB[5]                  1'b0
    28:27   R/W PAD_P16_AON_MUX[5]              2'b0
    29      R/W PAD_P16_O_EN[5]                 1'b1
    30      R/W PAD_P16_HS_MUX[5]               1'b0
    31      R/W PAD_P16_DUMMY1[5]               1'b0
 */
typedef volatile union _AON_NS_P16_4_P16_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P16_SHDN_4: 1;
        uint32_t AON_PAD_P16_E_4: 1;
        uint32_t AON_PAD_P16_O_4: 1;
        uint32_t PAD_P16_E3_4: 1;
        uint32_t PAD_P16_E2_4: 1;
        uint32_t PAD_P16_PDPUC_4: 1;
        uint32_t AON_PAD_P16_PU_4: 1;
        uint32_t AON_PAD_P16_PU_EN_4: 1;
        uint32_t PAD_P16_WKPOL_4: 1;
        uint32_t PAD_P16_WKEN_4: 1;
        uint32_t PAD_P16_DEB_4: 1;
        uint32_t PAD_P16_AON_MUX_4: 2;
        uint32_t PAD_P16_O_EN_4: 1;
        uint32_t PAD_P16_HS_MUX_4: 1;
        uint32_t PAD_P16_DUMMY1_4: 1;
        uint32_t PAD_P16_SHDN_5: 1;
        uint32_t AON_PAD_P16_E_5: 1;
        uint32_t AON_PAD_P16_O_5: 1;
        uint32_t PAD_P16_E3_5: 1;
        uint32_t PAD_P16_E2_5: 1;
        uint32_t PAD_P16_PDPUC_5: 1;
        uint32_t AON_PAD_P16_PU_5: 1;
        uint32_t AON_PAD_P16_PU_EN_5: 1;
        uint32_t PAD_P16_WKPOL_5: 1;
        uint32_t PAD_P16_WKEN_5: 1;
        uint32_t PAD_P16_DEB_5: 1;
        uint32_t PAD_P16_AON_MUX_5: 2;
        uint32_t PAD_P16_O_EN_5: 1;
        uint32_t PAD_P16_HS_MUX_5: 1;
        uint32_t PAD_P16_DUMMY1_5: 1;
    };
} AON_NS_P16_4_P16_5_PAD_CFG_TYPE;

/* 0x1A0C   0x4000_1a0c
    0       R/W PAD_SPIC0_CSN_SHDN              1'b1
    1       R/W AON_PAD_SPIC0_CSN_E             1'b0
    2       R/W AON_PAD_SPIC0_CSN_O             1'b0
    3       R/W PAD_SPIC0_CSN_E3                1'b0
    4       R/W PAD_SPIC0_CSN_E2                1'b0
    5       R/W PAD_SPIC0_CSN_PDPUC             1'b0
    6       R/W AON_PAD_SPIC0_CSN_PU            1'b1
    7       R/W AON_PAD_SPIC0_CSN_PU_EN         1'b1
    8       R/W PAD_SPIC0_CSN_WKPOL             1'b0
    9       R/W PAD_SPIC0_CSN_WKEN              1'b0
    10      R/W PAD_SPIC0_CSN_DEB               1'b0
    12:11   R/W PAD_SPIC0_CSN_DUMMY0            2'b0
    13      R/W PAD_SPIC0_CSN_O_EN              1'b1
    14      R/W PAD_SPIC0_CSN_HS_MUX            1'b0
    15      R/W PAD_SPIC0_CSN_DUMMY1            1'b0
    16      R/W PAD_SPIC0_CLK_SHDN              1'b1
    17      R/W AON_PAD_SPIC0_CLK_E             1'b0
    18      R/W AON_PAD_SPIC0_CLK_O             1'b0
    19      R/W PAD_SPIC0_CLK_E3                1'b0
    20      R/W PAD_SPIC0_CLK_E2                1'b0
    21      R/W PAD_SPIC0_CLK_PDPUC             1'b0
    22      R/W AON_PAD_SPIC0_CLK_PU            1'b1
    23      R/W AON_PAD_SPIC0_CLK_PU_EN         1'b1
    24      R/W PAD_SPIC0_CLK_WKPOL             1'b0
    25      R/W PAD_SPIC0_CLK_WKEN              1'b0
    26      R/W PAD_SPIC0_CLK_DEB               1'b0
    28:27   R/W PAD_SPIC0_CLK_DUMMY0            2'b0
    29      R/W PAD_SPIC0_CLK_O_EN              1'b1
    30      R/W PAD_SPIC0_CLK_HS_MUX            1'b0
    31      R/W PAD_SPIC0_CLK_DUMMY1            1'b0
 */
typedef volatile union _AON_NS_SPIC0_PAD_CFG0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_SPIC0_CSN_SHDN: 1;
        uint32_t AON_PAD_SPIC0_CSN_E: 1;
        uint32_t AON_PAD_SPIC0_CSN_O: 1;
        uint32_t PAD_SPIC0_CSN_E3: 1;
        uint32_t PAD_SPIC0_CSN_E2: 1;
        uint32_t PAD_SPIC0_CSN_PDPUC: 1;
        uint32_t AON_PAD_SPIC0_CSN_PU: 1;
        uint32_t AON_PAD_SPIC0_CSN_PU_EN: 1;
        uint32_t PAD_SPIC0_CSN_WKPOL: 1;
        uint32_t PAD_SPIC0_CSN_WKEN: 1;
        uint32_t PAD_SPIC0_CSN_DEB: 1;
        uint32_t PAD_SPIC0_CSN_DUMMY0: 2;
        uint32_t PAD_SPIC0_CSN_O_EN: 1;
        uint32_t PAD_SPIC0_CSN_HS_MUX: 1;
        uint32_t PAD_SPIC0_CSN_DUMMY1: 1;
        uint32_t PAD_SPIC0_CLK_SHDN: 1;
        uint32_t AON_PAD_SPIC0_CLK_E: 1;
        uint32_t AON_PAD_SPIC0_CLK_O: 1;
        uint32_t PAD_SPIC0_CLK_E3: 1;
        uint32_t PAD_SPIC0_CLK_E2: 1;
        uint32_t PAD_SPIC0_CLK_PDPUC: 1;
        uint32_t AON_PAD_SPIC0_CLK_PU: 1;
        uint32_t AON_PAD_SPIC0_CLK_PU_EN: 1;
        uint32_t PAD_SPIC0_CLK_WKPOL: 1;
        uint32_t PAD_SPIC0_CLK_WKEN: 1;
        uint32_t PAD_SPIC0_CLK_DEB: 1;
        uint32_t PAD_SPIC0_CLK_DUMMY0: 2;
        uint32_t PAD_SPIC0_CLK_O_EN: 1;
        uint32_t PAD_SPIC0_CLK_HS_MUX: 1;
        uint32_t PAD_SPIC0_CLK_DUMMY1: 1;
    };
} AON_NS_SPIC0_PAD_CFG0_TYPE;

/* 0x1A10   0x4000_1a10
    0       R/W PAD_SPIC0_SIO0_SHDN             1'b1
    1       R/W AON_PAD_SPIC0_SIO0_E            1'b0
    2       R/W AON_PAD_SPIC0_SIO0_O            1'b0
    3       R/W PAD_SPIC0_SIO0_E3               1'b0
    4       R/W PAD_SPIC0_SIO0_E2               1'b0
    5       R/W PAD_SPIC0_SIO0_PDPUC            1'b0
    6       R/W AON_PAD_SPIC0_SIO0_PU           1'b1
    7       R/W AON_PAD_SPIC0_SIO0_PU_EN        1'b1
    8       R/W PAD_SPIC0_SIO0_WKPOL            1'b0
    9       R/W PAD_SPIC0_SIO0_WKEN             1'b0
    10      R/W PAD_SPIC0_SIO0_DEB              1'b0
    12:11   R/W PAD_SPIC0_SIO0_DUMMY0           2'b0
    13      R/W PAD_SPIC0_SIO0_O_EN             1'b1
    14      R/W PAD_SPIC0_SIO0_HS_MUX           1'b0
    15      R/W SPIC0_PULL_SEL_SIO0_PULL_CTRL   1'b0
    16      R/W PAD_SPIC0_SIO1_SHDN             1'b1
    17      R/W AON_PAD_SPIC0_SIO1_E            1'b0
    18      R/W AON_PAD_SPIC0_SIO1_O            1'b0
    19      R/W PAD_SPIC0_SIO1_E3               1'b0
    20      R/W PAD_SPIC0_SIO1_E2               1'b0
    21      R/W PAD_SPIC0_SIO1_PDPUC            1'b0
    22      R/W AON_PAD_SPIC0_SIO1_PU           1'b1
    23      R/W AON_PAD_SPIC0_SIO1_PU_EN        1'b1
    24      R/W PAD_SPIC0_SIO1_WKPOL            1'b0
    25      R/W PAD_SPIC0_SIO1_WKEN             1'b0
    26      R/W PAD_SPIC0_SIO1_DEB              1'b0
    28:27   R/W PAD_SPIC0_SIO1_DUMMY0           2'b0
    29      R/W PAD_SPIC0_SIO1_O_EN             1'b1
    30      R/W PAD_SPIC0_SIO1_HS_MUX           1'b0
    31      R/W SPIC0_PULL_SEL_SIO1_PULL_CTRL   1'b0
 */
typedef volatile union _AON_NS_SPIC0_PAD_CFG1_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_SPIC0_SIO0_SHDN: 1;
        uint32_t AON_PAD_SPIC0_SIO0_E: 1;
        uint32_t AON_PAD_SPIC0_SIO0_O: 1;
        uint32_t PAD_SPIC0_SIO0_E3: 1;
        uint32_t PAD_SPIC0_SIO0_E2: 1;
        uint32_t PAD_SPIC0_SIO0_PDPUC: 1;
        uint32_t AON_PAD_SPIC0_SIO0_PU: 1;
        uint32_t AON_PAD_SPIC0_SIO0_PU_EN: 1;
        uint32_t PAD_SPIC0_SIO0_WKPOL: 1;
        uint32_t PAD_SPIC0_SIO0_WKEN: 1;
        uint32_t PAD_SPIC0_SIO0_DEB: 1;
        uint32_t PAD_SPIC0_SIO0_DUMMY0: 2;
        uint32_t PAD_SPIC0_SIO0_O_EN: 1;
        uint32_t PAD_SPIC0_SIO0_HS_MUX: 1;
        uint32_t SPIC0_PULL_SEL_SIO0_PULL_CTRL: 1;
        uint32_t PAD_SPIC0_SIO1_SHDN: 1;
        uint32_t AON_PAD_SPIC0_SIO1_E: 1;
        uint32_t AON_PAD_SPIC0_SIO1_O: 1;
        uint32_t PAD_SPIC0_SIO1_E3: 1;
        uint32_t PAD_SPIC0_SIO1_E2: 1;
        uint32_t PAD_SPIC0_SIO1_PDPUC: 1;
        uint32_t AON_PAD_SPIC0_SIO1_PU: 1;
        uint32_t AON_PAD_SPIC0_SIO1_PU_EN: 1;
        uint32_t PAD_SPIC0_SIO1_WKPOL: 1;
        uint32_t PAD_SPIC0_SIO1_WKEN: 1;
        uint32_t PAD_SPIC0_SIO1_DEB: 1;
        uint32_t PAD_SPIC0_SIO1_DUMMY0: 2;
        uint32_t PAD_SPIC0_SIO1_O_EN: 1;
        uint32_t PAD_SPIC0_SIO1_HS_MUX: 1;
        uint32_t SPIC0_PULL_SEL_SIO1_PULL_CTRL: 1;
    };
} AON_NS_SPIC0_PAD_CFG1_TYPE;

/* 0x1A14   0x4000_1a14
    0       R/W PAD_SPIC0_SIO2_SHDN             1'b1
    1       R/W AON_PAD_SPIC0_SIO2_E            1'b0
    2       R/W AON_PAD_SPIC0_SIO2_O            1'b0
    3       R/W PAD_SPIC0_SIO2_E3               1'b0
    4       R/W PAD_SPIC0_SIO2_E2               1'b0
    5       R/W PAD_SPIC0_SIO2_PDPUC            1'b0
    6       R/W AON_PAD_SPIC0_SIO2_PU           1'b1
    7       R/W AON_PAD_SPIC0_SIO2_PU_EN        1'b1
    8       R/W PAD_SPIC0_SIO2_WKPOL            1'b0
    9       R/W PAD_SPIC0_SIO2_WKEN             1'b0
    10      R/W PAD_SPIC0_SIO2_DEB              1'b0
    12:11   R/W PAD_SPIC0_SIO2_DUMMY0           2'b0
    13      R/W PAD_SPIC0_SIO2_O_EN             1'b1
    14      R/W PAD_SPIC0_SIO2_HS_MUX           1'b0
    15      R/W SPIC0_PULL_SEL_SIO2_PULL_CTRL   1'b0
    16      R/W PAD_SPIC0_SIO3_SHDN             1'b1
    17      R/W AON_PAD_SPIC0_SIO3_E            1'b0
    18      R/W AON_PAD_SPIC0_SIO3_O            1'b0
    19      R/W PAD_SPIC0_SIO3_E3               1'b0
    20      R/W PAD_SPIC0_SIO3_E2               1'b0
    21      R/W PAD_SPIC0_SIO3_PDPUC            1'b0
    22      R/W AON_PAD_SPIC0_SIO3_PU           1'b1
    23      R/W AON_PAD_SPIC0_SIO3_PU_EN        1'b1
    24      R/W PAD_SPIC0_SIO3_WKPOL            1'b0
    25      R/W PAD_SPIC0_SIO3_WKEN             1'b0
    26      R/W PAD_SPIC0_SIO3_DEB              1'b0
    28:27   R/W PAD_SPIC0_SIO3_DUMMY0           2'b0
    29      R/W PAD_SPIC0_SIO3_O_EN             1'b1
    30      R/W PAD_SPIC0_SIO3_HS_MUX           1'b0
    31      R/W SPIC0_PULL_SEL_SIO3_PULL_CTRL   1'b0
 */
typedef volatile union _AON_NS_SPIC0_PAD_CFG2_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_SPIC0_SIO2_SHDN: 1;
        uint32_t AON_PAD_SPIC0_SIO2_E: 1;
        uint32_t AON_PAD_SPIC0_SIO2_O: 1;
        uint32_t PAD_SPIC0_SIO2_E3: 1;
        uint32_t PAD_SPIC0_SIO2_E2: 1;
        uint32_t PAD_SPIC0_SIO2_PDPUC: 1;
        uint32_t AON_PAD_SPIC0_SIO2_PU: 1;
        uint32_t AON_PAD_SPIC0_SIO2_PU_EN: 1;
        uint32_t PAD_SPIC0_SIO2_WKPOL: 1;
        uint32_t PAD_SPIC0_SIO2_WKEN: 1;
        uint32_t PAD_SPIC0_SIO2_DEB: 1;
        uint32_t PAD_SPIC0_SIO2_DUMMY0: 2;
        uint32_t PAD_SPIC0_SIO2_O_EN: 1;
        uint32_t PAD_SPIC0_SIO2_HS_MUX: 1;
        uint32_t SPIC0_PULL_SEL_SIO2_PULL_CTRL: 1;
        uint32_t PAD_SPIC0_SIO3_SHDN: 1;
        uint32_t AON_PAD_SPIC0_SIO3_E: 1;
        uint32_t AON_PAD_SPIC0_SIO3_O: 1;
        uint32_t PAD_SPIC0_SIO3_E3: 1;
        uint32_t PAD_SPIC0_SIO3_E2: 1;
        uint32_t PAD_SPIC0_SIO3_PDPUC: 1;
        uint32_t AON_PAD_SPIC0_SIO3_PU: 1;
        uint32_t AON_PAD_SPIC0_SIO3_PU_EN: 1;
        uint32_t PAD_SPIC0_SIO3_WKPOL: 1;
        uint32_t PAD_SPIC0_SIO3_WKEN: 1;
        uint32_t PAD_SPIC0_SIO3_DEB: 1;
        uint32_t PAD_SPIC0_SIO3_DUMMY0: 2;
        uint32_t PAD_SPIC0_SIO3_O_EN: 1;
        uint32_t PAD_SPIC0_SIO3_HS_MUX: 1;
        uint32_t SPIC0_PULL_SEL_SIO3_PULL_CTRL: 1;
    };
} AON_NS_SPIC0_PAD_CFG2_TYPE;

/* 0x1A18   0x4000_1a18
    0       R/W PAD_MIC3_N_DUMMY3               1'b0
    1       R/W AON_PAD_MIC3_N_E                1'b0
    2       R/W AON_PAD_MIC3_N_O                1'b0
    3       R/W PAD_MIC3_N_E3                   1'b0
    4       R/W PAD_MIC3_N_E2                   1'b0
    5       R/W PAD_MIC3_N_PDPUC                1'b0
    6       R/W AON_PAD_MIC3_N_PU               1'b0
    7       R/W AON_PAD_MIC3_N_PU_EN            1'b1
    8       R/W PAD_MIC3_N_WKPOL                1'b0
    9       R/W PAD_MIC3_N_WKEN                 1'b0
    10      R/W PAD_MIC3_N_ANA_MODE             1'b0
    12:11   R/W PAD_MIC3_N_AON_MUX              2'b0
    13      R/W PAD_MIC3_N_DUMMY0               1'b0
    14      R/W PAD_MIC3_N_DUMMY1               1'b0
    15      R/W PAD_MIC3_N_DUMMY2               1'b0
    16      R/W PAD_MIC3_P_DUMMY3               1'b0
    17      R/W AON_PAD_MIC3_P_E                1'b0
    18      R/W AON_PAD_MIC3_P_O                1'b0
    19      R/W PAD_MIC3_P_E3                   1'b0
    20      R/W PAD_MIC3_P_E2                   1'b0
    21      R/W PAD_MIC3_P_PDPUC                1'b0
    22      R/W AON_PAD_MIC3_P_PU               1'b0
    23      R/W AON_PAD_MIC3_P_PU_EN            1'b1
    24      R/W PAD_MIC3_P_WKPOL                1'b0
    25      R/W PAD_MIC3_P_WKEN                 1'b0
    26      R/W PAD_MIC3_P_ANA_MODE             1'b0
    28:27   R/W PAD_MIC3_P_AON_MUX              2'b0
    29      R/W PAD_MIC3_P_DUMMY0               1'b0
    30      R/W PAD_MIC3_P_DUMMY1               1'b0
    31      R/W PAD_MIC3_P_DUMMY2               1'b0
 */
typedef volatile union _AON_NS_Codec_MIC3_N_P_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_MIC3_N_DUMMY3: 1;
        uint32_t AON_PAD_MIC3_N_E: 1;
        uint32_t AON_PAD_MIC3_N_O: 1;
        uint32_t PAD_MIC3_N_E3: 1;
        uint32_t PAD_MIC3_N_E2: 1;
        uint32_t PAD_MIC3_N_PDPUC: 1;
        uint32_t AON_PAD_MIC3_N_PU: 1;
        uint32_t AON_PAD_MIC3_N_PU_EN: 1;
        uint32_t PAD_MIC3_N_WKPOL: 1;
        uint32_t PAD_MIC3_N_WKEN: 1;
        uint32_t PAD_MIC3_N_ANA_MODE: 1;
        uint32_t PAD_MIC3_N_AON_MUX: 2;
        uint32_t PAD_MIC3_N_DUMMY0: 1;
        uint32_t PAD_MIC3_N_DUMMY1: 1;
        uint32_t PAD_MIC3_N_DUMMY2: 1;
        uint32_t PAD_MIC3_P_DUMMY3: 1;
        uint32_t AON_PAD_MIC3_P_E: 1;
        uint32_t AON_PAD_MIC3_P_O: 1;
        uint32_t PAD_MIC3_P_E3: 1;
        uint32_t PAD_MIC3_P_E2: 1;
        uint32_t PAD_MIC3_P_PDPUC: 1;
        uint32_t AON_PAD_MIC3_P_PU: 1;
        uint32_t AON_PAD_MIC3_P_PU_EN: 1;
        uint32_t PAD_MIC3_P_WKPOL: 1;
        uint32_t PAD_MIC3_P_WKEN: 1;
        uint32_t PAD_MIC3_P_ANA_MODE: 1;
        uint32_t PAD_MIC3_P_AON_MUX: 2;
        uint32_t PAD_MIC3_P_DUMMY0: 1;
        uint32_t PAD_MIC3_P_DUMMY1: 1;
        uint32_t PAD_MIC3_P_DUMMY2: 1;
    };
} AON_NS_Codec_MIC3_N_P_PAD_CFG_TYPE;

/* 0x1A1C   0x4000_1a1c
    0       R/W PAD_MIC2_N_DUMMY3               1'b0
    1       R/W AON_PAD_MIC2_N_E                1'b0
    2       R/W AON_PAD_MIC2_N_O                1'b0
    3       R/W PAD_MIC2_N_E3                   1'b0
    4       R/W PAD_MIC2_N_E2                   1'b0
    5       R/W PAD_MIC2_N_PDPUC                1'b0
    6       R/W AON_PAD_MIC2_N_PU               1'b0
    7       R/W AON_PAD_MIC2_N_PU_EN            1'b1
    8       R/W PAD_MIC2_N_WKPOL                1'b0
    9       R/W PAD_MIC2_N_WKEN                 1'b0
    10      R/W PAD_MIC2_N_ANA_MODE             1'b0
    12:11   R/W PAD_MIC2_N_AON_MUX              2'b0
    13      R/W PAD_MIC2_N_DUMMY0               1'b0
    14      R/W PAD_MIC2_N_DUMMY1               1'b0
    15      R/W PAD_MIC2_N_DUMMY2               1'b0
    16      R/W PAD_MIC2_P_DUMMY3               1'b0
    17      R/W AON_PAD_MIC2_P_E                1'b0
    18      R/W AON_PAD_MIC2_P_O                1'b0
    19      R/W PAD_MIC2_P_E3                   1'b0
    20      R/W PAD_MIC2_P_E2                   1'b0
    21      R/W PAD_MIC2_P_PDPUC                1'b0
    22      R/W AON_PAD_MIC2_P_PU               1'b0
    23      R/W AON_PAD_MIC2_P_PU_EN            1'b1
    24      R/W PAD_MIC2_P_WKPOL                1'b0
    25      R/W PAD_MIC2_P_WKEN                 1'b0
    26      R/W PAD_MIC2_P_ANA_MODE             1'b0
    28:27   R/W PAD_MIC2_P_AON_MUX              2'b0
    29      R/W PAD_MIC2_P_DUMMY0               1'b0
    30      R/W PAD_MIC2_P_DUMMY1               1'b0
    31      R/W PAD_MIC2_P_DUMMY2               1'b0
 */
typedef volatile union _AON_NS_Codec_MIC2_N_P_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_MIC2_N_DUMMY3: 1;
        uint32_t AON_PAD_MIC2_N_E: 1;
        uint32_t AON_PAD_MIC2_N_O: 1;
        uint32_t PAD_MIC2_N_E3: 1;
        uint32_t PAD_MIC2_N_E2: 1;
        uint32_t PAD_MIC2_N_PDPUC: 1;
        uint32_t AON_PAD_MIC2_N_PU: 1;
        uint32_t AON_PAD_MIC2_N_PU_EN: 1;
        uint32_t PAD_MIC2_N_WKPOL: 1;
        uint32_t PAD_MIC2_N_WKEN: 1;
        uint32_t PAD_MIC2_N_ANA_MODE: 1;
        uint32_t PAD_MIC2_N_AON_MUX: 2;
        uint32_t PAD_MIC2_N_DUMMY0: 1;
        uint32_t PAD_MIC2_N_DUMMY1: 1;
        uint32_t PAD_MIC2_N_DUMMY2: 1;
        uint32_t PAD_MIC2_P_DUMMY3: 1;
        uint32_t AON_PAD_MIC2_P_E: 1;
        uint32_t AON_PAD_MIC2_P_O: 1;
        uint32_t PAD_MIC2_P_E3: 1;
        uint32_t PAD_MIC2_P_E2: 1;
        uint32_t PAD_MIC2_P_PDPUC: 1;
        uint32_t AON_PAD_MIC2_P_PU: 1;
        uint32_t AON_PAD_MIC2_P_PU_EN: 1;
        uint32_t PAD_MIC2_P_WKPOL: 1;
        uint32_t PAD_MIC2_P_WKEN: 1;
        uint32_t PAD_MIC2_P_ANA_MODE: 1;
        uint32_t PAD_MIC2_P_AON_MUX: 2;
        uint32_t PAD_MIC2_P_DUMMY0: 1;
        uint32_t PAD_MIC2_P_DUMMY1: 1;
        uint32_t PAD_MIC2_P_DUMMY2: 1;
    };
} AON_NS_Codec_MIC2_N_P_PAD_CFG_TYPE;

/* 0x1A20   0x4000_1a20
    0       R/W PAD_MIC1_N_DUMMY3               1'b0
    1       R/W AON_PAD_MIC1_N_E                1'b0
    2       R/W AON_PAD_MIC1_N_O                1'b0
    3       R/W PAD_MIC1_N_E3                   1'b0
    4       R/W PAD_MIC1_N_E2                   1'b0
    5       R/W PAD_MIC1_N_PDPUC                1'b0
    6       R/W AON_PAD_MIC1_N_PU               1'b0
    7       R/W AON_PAD_MIC1_N_PU_EN            1'b1
    8       R/W PAD_MIC1_N_WKPOL                1'b0
    9       R/W PAD_MIC1_N_WKEN                 1'b0
    10      R/W PAD_MIC1_N_ANA_MODE             1'b0
    12:11   R/W PAD_MIC1_N_AON_MUX              2'b0
    13      R/W PAD_MIC1_N_DUMMY0               1'b0
    14      R/W PAD_MIC1_N_DUMMY1               1'b0
    15      R/W PAD_MIC1_N_DUMMY2               1'b0
    16      R/W PAD_MIC1_P_DUMMY3               1'b0
    17      R/W AON_PAD_MIC1_P_E                1'b0
    18      R/W AON_PAD_MIC1_P_O                1'b0
    19      R/W PAD_MIC1_P_E3                   1'b0
    20      R/W PAD_MIC1_P_E2                   1'b0
    21      R/W PAD_MIC1_P_PDPUC                1'b0
    22      R/W AON_PAD_MIC1_P_PU               1'b0
    23      R/W AON_PAD_MIC1_P_PU_EN            1'b1
    24      R/W PAD_MIC1_P_WKPOL                1'b0
    25      R/W PAD_MIC1_P_WKEN                 1'b0
    26      R/W PAD_MIC1_P_ANA_MODE             1'b0
    28:27   R/W PAD_MIC1_P_AON_MUX              2'b0
    29      R/W PAD_MIC1_P_DUMMY0               1'b0
    30      R/W PAD_MIC1_P_DUMMY1               1'b0
    31      R/W PAD_MIC1_P_DUMMY2               1'b0
 */
typedef volatile union _AON_NS_Codec_MIC1_N_P_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_MIC1_N_DUMMY3: 1;
        uint32_t AON_PAD_MIC1_N_E: 1;
        uint32_t AON_PAD_MIC1_N_O: 1;
        uint32_t PAD_MIC1_N_E3: 1;
        uint32_t PAD_MIC1_N_E2: 1;
        uint32_t PAD_MIC1_N_PDPUC: 1;
        uint32_t AON_PAD_MIC1_N_PU: 1;
        uint32_t AON_PAD_MIC1_N_PU_EN: 1;
        uint32_t PAD_MIC1_N_WKPOL: 1;
        uint32_t PAD_MIC1_N_WKEN: 1;
        uint32_t PAD_MIC1_N_ANA_MODE: 1;
        uint32_t PAD_MIC1_N_AON_MUX: 2;
        uint32_t PAD_MIC1_N_DUMMY0: 1;
        uint32_t PAD_MIC1_N_DUMMY1: 1;
        uint32_t PAD_MIC1_N_DUMMY2: 1;
        uint32_t PAD_MIC1_P_DUMMY3: 1;
        uint32_t AON_PAD_MIC1_P_E: 1;
        uint32_t AON_PAD_MIC1_P_O: 1;
        uint32_t PAD_MIC1_P_E3: 1;
        uint32_t PAD_MIC1_P_E2: 1;
        uint32_t PAD_MIC1_P_PDPUC: 1;
        uint32_t AON_PAD_MIC1_P_PU: 1;
        uint32_t AON_PAD_MIC1_P_PU_EN: 1;
        uint32_t PAD_MIC1_P_WKPOL: 1;
        uint32_t PAD_MIC1_P_WKEN: 1;
        uint32_t PAD_MIC1_P_ANA_MODE: 1;
        uint32_t PAD_MIC1_P_AON_MUX: 2;
        uint32_t PAD_MIC1_P_DUMMY0: 1;
        uint32_t PAD_MIC1_P_DUMMY1: 1;
        uint32_t PAD_MIC1_P_DUMMY2: 1;
    };
} AON_NS_Codec_MIC1_N_P_PAD_CFG_TYPE;

/* 0x1A24   0x4000_1a24
    0       R/W PAD_DAC2_N_DUMMY3               1'b0
    1       R/W AON_PAD_DAC2_N_E                1'b0
    2       R/W AON_PAD_DAC2_N_O                1'b0
    3       R/W PAD_DAC2_N_E3                   1'b0
    4       R/W PAD_DAC2_N_E2                   1'b0
    5       R/W PAD_DAC2_N_PDPUC                1'b0
    6       R/W AON_PAD_DAC2_N_PU               1'b0
    7       R/W AON_PAD_DAC2_N_PU_EN            1'b1
    8       R/W PAD_DAC2_N_WKPOL                1'b0
    9       R/W PAD_DAC2_N_WKEN                 1'b0
    10      R/W PAD_DAC2_N_ANA_MODE             1'b0
    12:11   R/W PAD_DAC2_N_AON_MUX              2'b0
    13      R/W PAD_DAC2_N_DUMMY0               1'b0
    14      R/W PAD_DAC2_N_DUMMY1               1'b0
    15      R/W PAD_DAC2_N_DUMMY2               1'b0
    16      R/W PAD_DAC2_P_DUMMY3               1'b0
    17      R/W AON_PAD_DAC2_P_E                1'b0
    18      R/W AON_PAD_DAC2_P_O                1'b0
    19      R/W PAD_DAC2_P_E3                   1'b0
    20      R/W PAD_DAC2_P_E2                   1'b0
    21      R/W PAD_DAC2_P_PDPUC                1'b0
    22      R/W AON_PAD_DAC2_P_PU               1'b0
    23      R/W AON_PAD_DAC2_P_PU_EN            1'b1
    24      R/W PAD_DAC2_P_WKPOL                1'b0
    25      R/W PAD_DAC2_P_WKEN                 1'b0
    26      R/W PAD_DAC2_P_ANA_MODE             1'b0
    28:27   R/W PAD_DAC2_P_AON_MUX              2'b0
    29      R/W PAD_DAC2_P_DUMMY0               1'b0
    30      R/W PAD_DAC2_P_DUMMY1               1'b0
    31      R/W PAD_DAC2_P_DUMMY2               1'b0
 */
typedef volatile union _AON_NS_Codec_DAC2_N_P_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_DAC2_N_DUMMY3: 1;
        uint32_t AON_PAD_DAC2_N_E: 1;
        uint32_t AON_PAD_DAC2_N_O: 1;
        uint32_t PAD_DAC2_N_E3: 1;
        uint32_t PAD_DAC2_N_E2: 1;
        uint32_t PAD_DAC2_N_PDPUC: 1;
        uint32_t AON_PAD_DAC2_N_PU: 1;
        uint32_t AON_PAD_DAC2_N_PU_EN: 1;
        uint32_t PAD_DAC2_N_WKPOL: 1;
        uint32_t PAD_DAC2_N_WKEN: 1;
        uint32_t PAD_DAC2_N_ANA_MODE: 1;
        uint32_t PAD_DAC2_N_AON_MUX: 2;
        uint32_t PAD_DAC2_N_DUMMY0: 1;
        uint32_t PAD_DAC2_N_DUMMY1: 1;
        uint32_t PAD_DAC2_N_DUMMY2: 1;
        uint32_t PAD_DAC2_P_DUMMY3: 1;
        uint32_t AON_PAD_DAC2_P_E: 1;
        uint32_t AON_PAD_DAC2_P_O: 1;
        uint32_t PAD_DAC2_P_E3: 1;
        uint32_t PAD_DAC2_P_E2: 1;
        uint32_t PAD_DAC2_P_PDPUC: 1;
        uint32_t AON_PAD_DAC2_P_PU: 1;
        uint32_t AON_PAD_DAC2_P_PU_EN: 1;
        uint32_t PAD_DAC2_P_WKPOL: 1;
        uint32_t PAD_DAC2_P_WKEN: 1;
        uint32_t PAD_DAC2_P_ANA_MODE: 1;
        uint32_t PAD_DAC2_P_AON_MUX: 2;
        uint32_t PAD_DAC2_P_DUMMY0: 1;
        uint32_t PAD_DAC2_P_DUMMY1: 1;
        uint32_t PAD_DAC2_P_DUMMY2: 1;
    };
} AON_NS_Codec_DAC2_N_P_PAD_CFG_TYPE;

/* 0x1A28   0x4000_1a28
    0       R/W PAD_DAC1_N_DUMMY3               1'b0
    1       R/W AON_PAD_DAC1_N_E                1'b0
    2       R/W AON_PAD_DAC1_N_O                1'b0
    3       R/W PAD_DAC1_N_E3                   1'b0
    4       R/W PAD_DAC1_N_E2                   1'b0
    5       R/W PAD_DAC1_N_PDPUC                1'b0
    6       R/W AON_PAD_DAC1_N_PU               1'b0
    7       R/W AON_PAD_DAC1_N_PU_EN            1'b1
    8       R/W PAD_DAC1_N_WKPOL                1'b0
    9       R/W PAD_DAC1_N_WKEN                 1'b0
    10      R/W PAD_DAC1_N_ANA_MODE             1'b0
    12:11   R/W PAD_DAC1_N_AON_MUX              2'b0
    13      R/W PAD_DAC1_N_DUMMY0               1'b0
    14      R/W PAD_DAC1_N_DUMMY1               1'b0
    15      R/W PAD_DAC1_N_DUMMY2               1'b0
    16      R/W PAD_DAC1_P_DUMMY3               1'b0
    17      R/W AON_PAD_DAC1_P_E                1'b0
    18      R/W AON_PAD_DAC1_P_O                1'b0
    19      R/W PAD_DAC1_P_E3                   1'b0
    20      R/W PAD_DAC1_P_E2                   1'b0
    21      R/W PAD_DAC1_P_PDPUC                1'b0
    22      R/W AON_PAD_DAC1_P_PU               1'b0
    23      R/W AON_PAD_DAC1_P_PU_EN            1'b1
    24      R/W PAD_DAC1_P_WKPOL                1'b0
    25      R/W PAD_DAC1_P_WKEN                 1'b0
    26      R/W PAD_DAC1_P_ANA_MODE             1'b0
    28:27   R/W PAD_DAC1_P_AON_MUX              2'b0
    29      R/W PAD_DAC1_P_DUMMY0               1'b0
    30      R/W PAD_DAC1_P_DUMMY1               1'b0
    31      R/W PAD_DAC1_P_DUMMY2               1'b0
 */
typedef volatile union _AON_NS_Codec_DAC1_N_P_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_DAC1_N_DUMMY3: 1;
        uint32_t AON_PAD_DAC1_N_E: 1;
        uint32_t AON_PAD_DAC1_N_O: 1;
        uint32_t PAD_DAC1_N_E3: 1;
        uint32_t PAD_DAC1_N_E2: 1;
        uint32_t PAD_DAC1_N_PDPUC: 1;
        uint32_t AON_PAD_DAC1_N_PU: 1;
        uint32_t AON_PAD_DAC1_N_PU_EN: 1;
        uint32_t PAD_DAC1_N_WKPOL: 1;
        uint32_t PAD_DAC1_N_WKEN: 1;
        uint32_t PAD_DAC1_N_ANA_MODE: 1;
        uint32_t PAD_DAC1_N_AON_MUX: 2;
        uint32_t PAD_DAC1_N_DUMMY0: 1;
        uint32_t PAD_DAC1_N_DUMMY1: 1;
        uint32_t PAD_DAC1_N_DUMMY2: 1;
        uint32_t PAD_DAC1_P_DUMMY3: 1;
        uint32_t AON_PAD_DAC1_P_E: 1;
        uint32_t AON_PAD_DAC1_P_O: 1;
        uint32_t PAD_DAC1_P_E3: 1;
        uint32_t PAD_DAC1_P_E2: 1;
        uint32_t PAD_DAC1_P_PDPUC: 1;
        uint32_t AON_PAD_DAC1_P_PU: 1;
        uint32_t AON_PAD_DAC1_P_PU_EN: 1;
        uint32_t PAD_DAC1_P_WKPOL: 1;
        uint32_t PAD_DAC1_P_WKEN: 1;
        uint32_t PAD_DAC1_P_ANA_MODE: 1;
        uint32_t PAD_DAC1_P_AON_MUX: 2;
        uint32_t PAD_DAC1_P_DUMMY0: 1;
        uint32_t PAD_DAC1_P_DUMMY1: 1;
        uint32_t PAD_DAC1_P_DUMMY2: 1;
    };
} AON_NS_Codec_DAC1_N_P_PAD_CFG_TYPE;

/* 0x1A2C   0x4000_1a2c
    0       R/W PAD_G0_SMT                      1'b1
    1       R/W PAD_G0_H3L1                     1'b1
    2       R/W PAD_G1_SMT                      1'b1
    3       R/W PAD_G1_H3L1                     1'b0
    4       R/W PAD_G1_POC_CORE                 1'b1
    5       R/W PAD_G2_SMT                      1'b1
    6       R/W PAD_G2_H3L1                     1'b0
    7       R/W PAD_G2_POC_CORE                 1'b1
    8       R/W PAD_G3_SMT                      1'b1
    9       R/W PAD_G3_H3L1                     1'b0
    10      R/W PAD_G3_POC_CORE                 1'b1
    11      R/W PAD_G4_SMT                      1'b1
    12      R/W PAD_G4_H3L1                     1'b0
    13      R/W PAD_G4_POC_CORE                 1'b1
    14      R/W PAD_SPIC0_SMT                   1'b1
    15      R/W PAD_SPIC0_H3L1                  1'b0
    16      R/W PAD_SPIC0_POC_CORE              1'b1
    17      R/W PAD_HYBRID_SMT                  1'b1
    18      R/W PAD_G1_HS_POC_CORE              1'b1
    19      R/W PAD_G3_HS_POC_CORE              1'b1
    20      R/W PAD_G4_HS_POC_CORE              1'b1
    21      R/W PAD_GROUP_CFG0_DUMMY3           1'b1
    22      R/W PAD_ADC_GROUP_SHDN              1'b1
    23      R/W PAD_P1_GROUP_SHDN               1'b1
    24      R/W PAD_P2_GROUP_SHDN               1'b1
    25      R/W PAD_P3_GROUP_SHDN               1'b1
    26      R/W PAD_P4_GROUP_SHDN               1'b1
    27      R/W PAD_P5_GROUP_SHDN               1'b1
    28      R/W PAD_P6_GROUP_SHDN               1'b1
    29      R/W PAD_P7_GROUP_SHDN               1'b1
    30      R/W PAD_P8_GROUP_SHDN               1'b1
    31      R/W PAD_P9_GROUP_SHDN               1'b1
 */
typedef volatile union _AON_NS_PAD_Group_CFG0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_G0_SMT: 1;
        uint32_t PAD_G0_H3L1: 1;
        uint32_t PAD_G1_SMT: 1;
        uint32_t PAD_G1_H3L1: 1;
        uint32_t PAD_G1_POC_CORE: 1;
        uint32_t PAD_G2_SMT: 1;
        uint32_t PAD_G2_H3L1: 1;
        uint32_t PAD_G2_POC_CORE: 1;
        uint32_t PAD_G3_SMT: 1;
        uint32_t PAD_G3_H3L1: 1;
        uint32_t PAD_G3_POC_CORE: 1;
        uint32_t PAD_G4_SMT: 1;
        uint32_t PAD_G4_H3L1: 1;
        uint32_t PAD_G4_POC_CORE: 1;
        uint32_t PAD_SPIC0_SMT: 1;
        uint32_t PAD_SPIC0_H3L1: 1;
        uint32_t PAD_SPIC0_POC_CORE: 1;
        uint32_t PAD_HYBRID_SMT: 1;
        uint32_t PAD_G1_HS_POC_CORE: 1;
        uint32_t PAD_G3_HS_POC_CORE: 1;
        uint32_t PAD_G4_HS_POC_CORE: 1;
        uint32_t PAD_GROUP_CFG0_DUMMY3: 1;
        uint32_t PAD_ADC_GROUP_SHDN: 1;
        uint32_t PAD_P1_GROUP_SHDN: 1;
        uint32_t PAD_P2_GROUP_SHDN: 1;
        uint32_t PAD_P3_GROUP_SHDN: 1;
        uint32_t PAD_P4_GROUP_SHDN: 1;
        uint32_t PAD_P5_GROUP_SHDN: 1;
        uint32_t PAD_P6_GROUP_SHDN: 1;
        uint32_t PAD_P7_GROUP_SHDN: 1;
        uint32_t PAD_P8_GROUP_SHDN: 1;
        uint32_t PAD_P9_GROUP_SHDN: 1;
    };
} AON_NS_PAD_Group_CFG0_TYPE;

/* 0x1A30   0x4000_1a30
    0       R/W PAD_P10_GROUP_SHDN              1'b1
    1       R/W PAD_P11_GROUP_SHDN              1'b1
    2       R/W PAD_P12_GROUP_SHDN              1'b1
    3       R/W PAD_P13_GROUP_SHDN              1'b1
    4       R/W PAD_P14_GROUP_SHDN              1'b1
    5       R/W PAD_P15_GROUP_SHDN              1'b1
    6       R/W PAD_P16_GROUP_SHDN              1'b1
    7       R/W PAD_P17_GROUP_SHDN              1'b1
    8       R/W PAD_P18_GROUP_SHDN              1'b1
    9       R/W PAD_P19_GROUP_SHDN              1'b1
    10      R/W PAD_P20_GROUP_SHDN              1'b1
    31:11   R/W PAD_GROUP_CFG1_DUMMY[20:0]      21'b0
 */
typedef volatile union _AON_NS_PAD_Group_CFG1_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P10_GROUP_SHDN: 1;
        uint32_t PAD_P11_GROUP_SHDN: 1;
        uint32_t PAD_P12_GROUP_SHDN: 1;
        uint32_t PAD_P13_GROUP_SHDN: 1;
        uint32_t PAD_P14_GROUP_SHDN: 1;
        uint32_t PAD_P15_GROUP_SHDN: 1;
        uint32_t PAD_P16_GROUP_SHDN: 1;
        uint32_t PAD_P17_GROUP_SHDN: 1;
        uint32_t PAD_P18_GROUP_SHDN: 1;
        uint32_t PAD_P19_GROUP_SHDN: 1;
        uint32_t PAD_P20_GROUP_SHDN: 1;
        uint32_t PAD_GROUP_CFG1_DUMMY_20_0: 21;
    };
} AON_NS_PAD_Group_CFG1_TYPE;

/* 0x1A34   0x4000_1a34
    4:0     R/W rtc_in_sel                      5'b0
    9:5     R/W PAD_AON_PINMUX_CFG0_DUMMY       5'b0
    13:10   R/W mclk2_out_sel                   4'b0
    17:14   R/W qdph0_in_sel                    4'b0
    21:18   R/W qdph1_in_sel                    4'b0
    23:22   R/W kr0_cjtag_tckc_in_sel           2'b0
    25:24   R/W kr0_cjtag_tmsc_io_sel           2'b0
    27:26   R/W PAD_AON_PINMUX_CFG0_DUMMY1      2'b0
    29:28   R/W kr0_jtag_tdi_in_sel             2'b0
    31:30   R/W kr0_jtag_tdo_out_sel            2'b0
 */
typedef volatile union _AON_NS_PAD_AON_PINMUX_CFG0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t rtc_in_sel: 5;
        uint32_t PAD_AON_PINMUX_CFG0_DUMMY: 5;
        uint32_t mclk2_out_sel: 4;
        uint32_t qdph0_in_sel: 4;
        uint32_t qdph1_in_sel: 4;
        uint32_t kr0_cjtag_tckc_in_sel: 2;
        uint32_t kr0_cjtag_tmsc_io_sel: 2;
        uint32_t PAD_AON_PINMUX_CFG0_DUMMY1: 2;
        uint32_t kr0_jtag_tdi_in_sel: 2;
        uint32_t kr0_jtag_tdo_out_sel: 2;
    };
} AON_NS_PAD_AON_PINMUX_CFG0_TYPE;

/* 0x1A38   0x4000_1a38
    0       R/W PAD_P16_SHDN[6]                 1'b1
    1       R/W AON_PAD_P16_E[6]                1'b0
    2       R/W AON_PAD_P16_O[6]                1'b0
    3       R/W PAD_P16_E3[6]                   1'b0
    4       R/W PAD_P16_E2[6]                   1'b0
    5       R/W PAD_P16_PDPUC[6]                1'b0
    6       R/W AON_PAD_P16_PU[6]               1'b0
    7       R/W AON_PAD_P16_PU_EN[6]            1'b1
    8       R/W PAD_P16_WKPOL[6]                1'b0
    9       R/W PAD_P16_WKEN[6]                 1'b0
    10      R/W PAD_P16_DEB[6]                  1'b0
    12:11   R/W PAD_P16_AON_MUX[6]              2'b0
    13      R/W PAD_P16_O_EN[6]                 1'b1
    14      R/W PAD_P16_HS_MUX[6]               1'b0
    15      R/W PAD_P16_DUMMY1[6]               1'b0
    16      R/W PAD_P16_SHDN[7]                 1'b1
    17      R/W AON_PAD_P16_E[7]                1'b0
    18      R/W AON_PAD_P16_O[7]                1'b0
    19      R/W PAD_P16_E3[7]                   1'b0
    20      R/W PAD_P16_E2[7]                   1'b0
    21      R/W PAD_P16_PDPUC[7]                1'b0
    22      R/W AON_PAD_P16_PU[7]               1'b0
    23      R/W AON_PAD_P16_PU_EN[7]            1'b1
    24      R/W PAD_P16_WKPOL[7]                1'b0
    25      R/W PAD_P16_WKEN[7]                 1'b0
    26      R/W PAD_P16_DEB[7]                  1'b0
    28:27   R/W PAD_P16_AON_MUX[7]              2'b0
    29      R/W PAD_P16_O_EN[7]                 1'b1
    30      R/W PAD_P16_HS_MUX[7]               1'b0
    31      R/W PAD_P16_DUMMY1[7]               1'b0
 */
typedef volatile union _AON_NS_P16_6_P16_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P16_SHDN_6: 1;
        uint32_t AON_PAD_P16_E_6: 1;
        uint32_t AON_PAD_P16_O_6: 1;
        uint32_t PAD_P16_E3_6: 1;
        uint32_t PAD_P16_E2_6: 1;
        uint32_t PAD_P16_PDPUC_6: 1;
        uint32_t AON_PAD_P16_PU_6: 1;
        uint32_t AON_PAD_P16_PU_EN_6: 1;
        uint32_t PAD_P16_WKPOL_6: 1;
        uint32_t PAD_P16_WKEN_6: 1;
        uint32_t PAD_P16_DEB_6: 1;
        uint32_t PAD_P16_AON_MUX_6: 2;
        uint32_t PAD_P16_O_EN_6: 1;
        uint32_t PAD_P16_HS_MUX_6: 1;
        uint32_t PAD_P16_DUMMY1_6: 1;
        uint32_t PAD_P16_SHDN_7: 1;
        uint32_t AON_PAD_P16_E_7: 1;
        uint32_t AON_PAD_P16_O_7: 1;
        uint32_t PAD_P16_E3_7: 1;
        uint32_t PAD_P16_E2_7: 1;
        uint32_t PAD_P16_PDPUC_7: 1;
        uint32_t AON_PAD_P16_PU_7: 1;
        uint32_t AON_PAD_P16_PU_EN_7: 1;
        uint32_t PAD_P16_WKPOL_7: 1;
        uint32_t PAD_P16_WKEN_7: 1;
        uint32_t PAD_P16_DEB_7: 1;
        uint32_t PAD_P16_AON_MUX_7: 2;
        uint32_t PAD_P16_O_EN_7: 1;
        uint32_t PAD_P16_HS_MUX_7: 1;
        uint32_t PAD_P16_DUMMY1_7: 1;
    };
} AON_NS_P16_6_P16_7_PAD_CFG_TYPE;

/* 0x1A3C   0x4000_1a3c
    0       R/W PAD_P17_SHDN[0]                 1'b1
    1       R/W AON_PAD_P17_E[0]                1'b0
    2       R/W AON_PAD_P17_O[0]                1'b0
    3       R/W PAD_P17_E3[0]                   1'b0
    4       R/W PAD_P17_E2[0]                   1'b0
    5       R/W PAD_P17_PDPUC[0]                1'b0
    6       R/W AON_PAD_P17_PU[0]               1'b0
    7       R/W AON_PAD_P17_PU_EN[0]            1'b1
    8       R/W PAD_P17_WKPOL[0]                1'b0
    9       R/W PAD_P17_WKEN[0]                 1'b0
    10      R/W PAD_P17_DEB[0]                  1'b0
    12:11   R/W PAD_P17_AON_MUX[0]              2'b0
    13      R/W PAD_P17_O_EN[0]                 1'b1
    14      R/W PAD_P17_HS_MUX[0]               1'b0
    15      R/W PAD_P17_DUMMY1[0]               1'b0
    16      R/W PAD_P17_SHDN[1]                 1'b1
    17      R/W AON_PAD_P17_E[1]                1'b0
    18      R/W AON_PAD_P17_O[1]                1'b0
    19      R/W PAD_P17_E3[1]                   1'b0
    20      R/W PAD_P17_E2[1]                   1'b0
    21      R/W PAD_P17_PDPUC[1]                1'b0
    22      R/W AON_PAD_P17_PU[1]               1'b0
    23      R/W AON_PAD_P17_PU_EN[1]            1'b1
    24      R/W PAD_P17_WKPOL[1]                1'b0
    25      R/W PAD_P17_WKEN[1]                 1'b0
    26      R/W PAD_P17_DEB[1]                  1'b0
    28:27   R/W PAD_P17_AON_MUX[1]              2'b0
    29      R/W PAD_P17_O_EN[1]                 1'b1
    30      R/W PAD_P17_HS_MUX[1]               1'b0
    31      R/W PAD_P17_DUMMY1[1]               1'b0
 */
typedef volatile union _AON_NS_P17_0_P17_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P17_SHDN_0: 1;
        uint32_t AON_PAD_P17_E_0: 1;
        uint32_t AON_PAD_P17_O_0: 1;
        uint32_t PAD_P17_E3_0: 1;
        uint32_t PAD_P17_E2_0: 1;
        uint32_t PAD_P17_PDPUC_0: 1;
        uint32_t AON_PAD_P17_PU_0: 1;
        uint32_t AON_PAD_P17_PU_EN_0: 1;
        uint32_t PAD_P17_WKPOL_0: 1;
        uint32_t PAD_P17_WKEN_0: 1;
        uint32_t PAD_P17_DEB_0: 1;
        uint32_t PAD_P17_AON_MUX_0: 2;
        uint32_t PAD_P17_O_EN_0: 1;
        uint32_t PAD_P17_HS_MUX_0: 1;
        uint32_t PAD_P17_DUMMY1_0: 1;
        uint32_t PAD_P17_SHDN_1: 1;
        uint32_t AON_PAD_P17_E_1: 1;
        uint32_t AON_PAD_P17_O_1: 1;
        uint32_t PAD_P17_E3_1: 1;
        uint32_t PAD_P17_E2_1: 1;
        uint32_t PAD_P17_PDPUC_1: 1;
        uint32_t AON_PAD_P17_PU_1: 1;
        uint32_t AON_PAD_P17_PU_EN_1: 1;
        uint32_t PAD_P17_WKPOL_1: 1;
        uint32_t PAD_P17_WKEN_1: 1;
        uint32_t PAD_P17_DEB_1: 1;
        uint32_t PAD_P17_AON_MUX_1: 2;
        uint32_t PAD_P17_O_EN_1: 1;
        uint32_t PAD_P17_HS_MUX_1: 1;
        uint32_t PAD_P17_DUMMY1_1: 1;
    };
} AON_NS_P17_0_P17_1_PAD_CFG_TYPE;

/* 0x1A40   0x4000_1a40
    0       R/W PAD_P17_SHDN[2]                 1'b1
    1       R/W AON_PAD_P17_E[2]                1'b0
    2       R/W AON_PAD_P17_O[2]                1'b0
    3       R/W PAD_P17_E3[2]                   1'b0
    4       R/W PAD_P17_E2[2]                   1'b0
    5       R/W PAD_P17_PDPUC[2]                1'b0
    6       R/W AON_PAD_P17_PU[2]               1'b0
    7       R/W AON_PAD_P17_PU_EN[2]            1'b1
    8       R/W PAD_P17_WKPOL[2]                1'b0
    9       R/W PAD_P17_WKEN[2]                 1'b0
    10      R/W PAD_P17_DEB[2]                  1'b0
    12:11   R/W PAD_P17_AON_MUX[2]              2'b0
    13      R/W PAD_P17_O_EN[2]                 1'b1
    14      R/W PAD_P17_HS_MUX[2]               1'b0
    15      R/W PAD_P17_DUMMY1[2]               1'b0
    16      R/W PAD_P17_SHDN[3]                 1'b1
    17      R/W AON_PAD_P17_E[3]                1'b0
    18      R/W AON_PAD_P17_O[3]                1'b0
    19      R/W PAD_P17_E3[3]                   1'b0
    20      R/W PAD_P17_E2[3]                   1'b0
    21      R/W PAD_P17_PDPUC[3]                1'b0
    22      R/W AON_PAD_P17_PU[3]               1'b0
    23      R/W AON_PAD_P17_PU_EN[3]            1'b1
    24      R/W PAD_P17_WKPOL[3]                1'b0
    25      R/W PAD_P17_WKEN[3]                 1'b0
    26      R/W PAD_P17_DEB[3]                  1'b0
    28:27   R/W PAD_P17_AON_MUX[3]              2'b0
    29      R/W PAD_P17_O_EN[3]                 1'b1
    30      R/W PAD_P17_HS_MUX[3]               1'b0
    31      R/W PAD_P17_DUMMY1[3]               1'b0
 */
typedef volatile union _AON_NS_P17_2_P17_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P17_SHDN_2: 1;
        uint32_t AON_PAD_P17_E_2: 1;
        uint32_t AON_PAD_P17_O_2: 1;
        uint32_t PAD_P17_E3_2: 1;
        uint32_t PAD_P17_E2_2: 1;
        uint32_t PAD_P17_PDPUC_2: 1;
        uint32_t AON_PAD_P17_PU_2: 1;
        uint32_t AON_PAD_P17_PU_EN_2: 1;
        uint32_t PAD_P17_WKPOL_2: 1;
        uint32_t PAD_P17_WKEN_2: 1;
        uint32_t PAD_P17_DEB_2: 1;
        uint32_t PAD_P17_AON_MUX_2: 2;
        uint32_t PAD_P17_O_EN_2: 1;
        uint32_t PAD_P17_HS_MUX_2: 1;
        uint32_t PAD_P17_DUMMY1_2: 1;
        uint32_t PAD_P17_SHDN_3: 1;
        uint32_t AON_PAD_P17_E_3: 1;
        uint32_t AON_PAD_P17_O_3: 1;
        uint32_t PAD_P17_E3_3: 1;
        uint32_t PAD_P17_E2_3: 1;
        uint32_t PAD_P17_PDPUC_3: 1;
        uint32_t AON_PAD_P17_PU_3: 1;
        uint32_t AON_PAD_P17_PU_EN_3: 1;
        uint32_t PAD_P17_WKPOL_3: 1;
        uint32_t PAD_P17_WKEN_3: 1;
        uint32_t PAD_P17_DEB_3: 1;
        uint32_t PAD_P17_AON_MUX_3: 2;
        uint32_t PAD_P17_O_EN_3: 1;
        uint32_t PAD_P17_HS_MUX_3: 1;
        uint32_t PAD_P17_DUMMY1_3: 1;
    };
} AON_NS_P17_2_P17_3_PAD_CFG_TYPE;

/* 0x1A44   0x4000_1a44
    0       R/W PAD_P17_SHDN[4]                 1'b1
    1       R/W AON_PAD_P17_E[4]                1'b0
    2       R/W AON_PAD_P17_O[4]                1'b0
    3       R/W PAD_P17_E3[4]                   1'b0
    4       R/W PAD_P17_E2[4]                   1'b0
    5       R/W PAD_P17_PDPUC[4]                1'b0
    6       R/W AON_PAD_P17_PU[4]               1'b1
    7       R/W AON_PAD_P17_PU_EN[4]            1'b1
    8       R/W PAD_P17_WKPOL[4]                1'b0
    9       R/W PAD_P17_WKEN[4]                 1'b0
    10      R/W PAD_P17_DEB[4]                  1'b0
    12:11   R/W PAD_P17_AON_MUX[4]              2'b0
    13      R/W PAD_P17_O_EN[4]                 1'b1
    14      R/W PAD_P17_HS_MUX[4]               1'b0
    15      R/W PAD_P17_DUMMY1[4]               1'b0
    16      R/W PAD_P17_SHDN[5]                 1'b1
    17      R/W AON_PAD_P17_E[5]                1'b0
    18      R/W AON_PAD_P17_O[5]                1'b0
    19      R/W PAD_P17_E3[5]                   1'b0
    20      R/W PAD_P17_E2[5]                   1'b0
    21      R/W PAD_P17_PDPUC[5]                1'b0
    22      R/W AON_PAD_P17_PU[5]               1'b1
    23      R/W AON_PAD_P17_PU_EN[5]            1'b1
    24      R/W PAD_P17_WKPOL[5]                1'b0
    25      R/W PAD_P17_WKEN[5]                 1'b0
    26      R/W PAD_P17_DEB[5]                  1'b0
    28:27   R/W PAD_P17_AON_MUX[5]              2'b0
    29      R/W PAD_P17_O_EN[5]                 1'b1
    30      R/W PAD_P17_HS_MUX[5]               1'b0
    31      R/W PAD_P17_DUMMY1[5]               1'b0
 */
typedef volatile union _AON_NS_P17_4_P17_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P17_SHDN_4: 1;
        uint32_t AON_PAD_P17_E_4: 1;
        uint32_t AON_PAD_P17_O_4: 1;
        uint32_t PAD_P17_E3_4: 1;
        uint32_t PAD_P17_E2_4: 1;
        uint32_t PAD_P17_PDPUC_4: 1;
        uint32_t AON_PAD_P17_PU_4: 1;
        uint32_t AON_PAD_P17_PU_EN_4: 1;
        uint32_t PAD_P17_WKPOL_4: 1;
        uint32_t PAD_P17_WKEN_4: 1;
        uint32_t PAD_P17_DEB_4: 1;
        uint32_t PAD_P17_AON_MUX_4: 2;
        uint32_t PAD_P17_O_EN_4: 1;
        uint32_t PAD_P17_HS_MUX_4: 1;
        uint32_t PAD_P17_DUMMY1_4: 1;
        uint32_t PAD_P17_SHDN_5: 1;
        uint32_t AON_PAD_P17_E_5: 1;
        uint32_t AON_PAD_P17_O_5: 1;
        uint32_t PAD_P17_E3_5: 1;
        uint32_t PAD_P17_E2_5: 1;
        uint32_t PAD_P17_PDPUC_5: 1;
        uint32_t AON_PAD_P17_PU_5: 1;
        uint32_t AON_PAD_P17_PU_EN_5: 1;
        uint32_t PAD_P17_WKPOL_5: 1;
        uint32_t PAD_P17_WKEN_5: 1;
        uint32_t PAD_P17_DEB_5: 1;
        uint32_t PAD_P17_AON_MUX_5: 2;
        uint32_t PAD_P17_O_EN_5: 1;
        uint32_t PAD_P17_HS_MUX_5: 1;
        uint32_t PAD_P17_DUMMY1_5: 1;
    };
} AON_NS_P17_4_P17_5_PAD_CFG_TYPE;

/* 0x1A48   0x4000_1a48
    0       R/W PAD_P17_SHDN[6]                 1'b1
    1       R/W AON_PAD_P17_E[6]                1'b0
    2       R/W AON_PAD_P17_O[6]                1'b0
    3       R/W PAD_P17_E3[6]                   1'b0
    4       R/W PAD_P17_E2[6]                   1'b0
    5       R/W PAD_P17_PDPUC[6]                1'b0
    6       R/W AON_PAD_P17_PU[6]               1'b0
    7       R/W AON_PAD_P17_PU_EN[6]            1'b1
    8       R/W PAD_P17_WKPOL[6]                1'b0
    9       R/W PAD_P17_WKEN[6]                 1'b0
    10      R/W PAD_P17_DEB[6]                  1'b0
    12:11   R/W PAD_P17_AON_MUX[6]              2'b0
    13      R/W PAD_P17_O_EN[6]                 1'b1
    14      R/W PAD_P17_HS_MUX[6]               1'b0
    15      R/W PAD_P17_DUMMY1[6]               1'b0
    16      R/W PAD_P17_SHDN[7]                 1'b1
    17      R/W AON_PAD_P17_E[7]                1'b0
    18      R/W AON_PAD_P17_O[7]                1'b0
    19      R/W PAD_P17_E3[7]                   1'b0
    20      R/W PAD_P17_E2[7]                   1'b0
    21      R/W PAD_P17_PDPUC[7]                1'b0
    22      R/W AON_PAD_P17_PU[7]               1'b0
    23      R/W AON_PAD_P17_PU_EN[7]            1'b1
    24      R/W PAD_P17_WKPOL[7]                1'b0
    25      R/W PAD_P17_WKEN[7]                 1'b0
    26      R/W PAD_P17_DEB[7]                  1'b0
    28:27   R/W PAD_P17_AON_MUX[7]              2'b0
    29      R/W PAD_P17_O_EN[7]                 1'b1
    30      R/W PAD_P17_HS_MUX[7]               1'b0
    31      R/W PAD_P17_DUMMY1[7]               1'b0
 */
typedef volatile union _AON_NS_P17_6_P17_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P17_SHDN_6: 1;
        uint32_t AON_PAD_P17_E_6: 1;
        uint32_t AON_PAD_P17_O_6: 1;
        uint32_t PAD_P17_E3_6: 1;
        uint32_t PAD_P17_E2_6: 1;
        uint32_t PAD_P17_PDPUC_6: 1;
        uint32_t AON_PAD_P17_PU_6: 1;
        uint32_t AON_PAD_P17_PU_EN_6: 1;
        uint32_t PAD_P17_WKPOL_6: 1;
        uint32_t PAD_P17_WKEN_6: 1;
        uint32_t PAD_P17_DEB_6: 1;
        uint32_t PAD_P17_AON_MUX_6: 2;
        uint32_t PAD_P17_O_EN_6: 1;
        uint32_t PAD_P17_HS_MUX_6: 1;
        uint32_t PAD_P17_DUMMY1_6: 1;
        uint32_t PAD_P17_SHDN_7: 1;
        uint32_t AON_PAD_P17_E_7: 1;
        uint32_t AON_PAD_P17_O_7: 1;
        uint32_t PAD_P17_E3_7: 1;
        uint32_t PAD_P17_E2_7: 1;
        uint32_t PAD_P17_PDPUC_7: 1;
        uint32_t AON_PAD_P17_PU_7: 1;
        uint32_t AON_PAD_P17_PU_EN_7: 1;
        uint32_t PAD_P17_WKPOL_7: 1;
        uint32_t PAD_P17_WKEN_7: 1;
        uint32_t PAD_P17_DEB_7: 1;
        uint32_t PAD_P17_AON_MUX_7: 2;
        uint32_t PAD_P17_O_EN_7: 1;
        uint32_t PAD_P17_HS_MUX_7: 1;
        uint32_t PAD_P17_DUMMY1_7: 1;
    };
} AON_NS_P17_6_P17_7_PAD_CFG_TYPE;

/* 0x1A4C   0x4000_1a4c
    0       R/W PAD_P18_SHDN[0]                 1'b1
    1       R/W AON_PAD_P18_E[0]                1'b0
    2       R/W AON_PAD_P18_O[0]                1'b0
    3       R/W PAD_P18_E3[0]                   1'b0
    4       R/W PAD_P18_E2[0]                   1'b0
    5       R/W PAD_P18_PDPUC[0]                1'b0
    6       R/W AON_PAD_P18_PU[0]               1'b0
    7       R/W AON_PAD_P18_PU_EN[0]            1'b1
    8       R/W PAD_P18_WKPOL[0]                1'b0
    9       R/W PAD_P18_WKEN[0]                 1'b0
    10      R/W PAD_P18_DEB[0]                  1'b0
    12:11   R/W PAD_P18_AON_MUX[0]              2'b0
    13      R/W PAD_P18_O_EN[0]                 1'b1
    14      R/W PAD_P18_DUMMY0[0]               1'b0
    15      R/W PAD_P18_DUMMY1[0]               1'b0
    16      R/W PAD_P18_SHDN[1]                 1'b1
    17      R/W AON_PAD_P18_E[1]                1'b0
    18      R/W AON_PAD_P18_O[1]                1'b0
    19      R/W PAD_P18_E3[1]                   1'b0
    20      R/W PAD_P18_E2[1]                   1'b0
    21      R/W PAD_P18_PDPUC[1]                1'b0
    22      R/W AON_PAD_P18_PU[1]               1'b1
    23      R/W AON_PAD_P18_PU_EN[1]            1'b1
    24      R/W PAD_P18_WKPOL[1]                1'b0
    25      R/W PAD_P18_WKEN[1]                 1'b0
    26      R/W PAD_P18_DEB[1]                  1'b0
    28:27   R/W PAD_P18_AON_MUX[1]              2'b0
    29      R/W PAD_P18_O_EN[1]                 1'b1
    30      R/W PAD_P18_DUMMY0[1]               1'b0
    31      R/W PAD_P18_DUMMY1[1]               1'b0
 */
typedef volatile union _AON_NS_P18_0_P18_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P18_SHDN_0: 1;
        uint32_t AON_PAD_P18_E_0: 1;
        uint32_t AON_PAD_P18_O_0: 1;
        uint32_t PAD_P18_E3_0: 1;
        uint32_t PAD_P18_E2_0: 1;
        uint32_t PAD_P18_PDPUC_0: 1;
        uint32_t AON_PAD_P18_PU_0: 1;
        uint32_t AON_PAD_P18_PU_EN_0: 1;
        uint32_t PAD_P18_WKPOL_0: 1;
        uint32_t PAD_P18_WKEN_0: 1;
        uint32_t PAD_P18_DEB_0: 1;
        uint32_t PAD_P18_AON_MUX_0: 2;
        uint32_t PAD_P18_O_EN_0: 1;
        uint32_t PAD_P18_DUMMY0_0: 1;
        uint32_t PAD_P18_DUMMY1_0: 1;
        uint32_t PAD_P18_SHDN_1: 1;
        uint32_t AON_PAD_P18_E_1: 1;
        uint32_t AON_PAD_P18_O_1: 1;
        uint32_t PAD_P18_E3_1: 1;
        uint32_t PAD_P18_E2_1: 1;
        uint32_t PAD_P18_PDPUC_1: 1;
        uint32_t AON_PAD_P18_PU_1: 1;
        uint32_t AON_PAD_P18_PU_EN_1: 1;
        uint32_t PAD_P18_WKPOL_1: 1;
        uint32_t PAD_P18_WKEN_1: 1;
        uint32_t PAD_P18_DEB_1: 1;
        uint32_t PAD_P18_AON_MUX_1: 2;
        uint32_t PAD_P18_O_EN_1: 1;
        uint32_t PAD_P18_DUMMY0_1: 1;
        uint32_t PAD_P18_DUMMY1_1: 1;
    };
} AON_NS_P18_0_P18_1_PAD_CFG_TYPE;

/* 0x1A50   0x4000_1a50
    0       R/W PAD_P18_SHDN[2]                 1'b1
    1       R/W AON_PAD_P18_E[2]                1'b0
    2       R/W AON_PAD_P18_O[2]                1'b0
    3       R/W PAD_P18_E3[2]                   1'b0
    4       R/W PAD_P18_E2[2]                   1'b0
    5       R/W PAD_P18_PDPUC[2]                1'b0
    6       R/W AON_PAD_P18_PU[2]               1'b0
    7       R/W AON_PAD_P18_PU_EN[2]            1'b1
    8       R/W PAD_P18_WKPOL[2]                1'b0
    9       R/W PAD_P18_WKEN[2]                 1'b0
    10      R/W PAD_P18_DEB[2]                  1'b0
    12:11   R/W PAD_P18_AON_MUX[2]              2'b0
    13      R/W PAD_P18_O_EN[2]                 1'b1
    14      R/W PAD_P18_DUMMY0[2]               1'b0
    15      R/W PAD_P18_DUMMY1[2]               1'b0
    16      R/W PAD_P18_SHDN[3]                 1'b1
    17      R/W AON_PAD_P18_E[3]                1'b0
    18      R/W AON_PAD_P18_O[3]                1'b0
    19      R/W PAD_P18_E3[3]                   1'b0
    20      R/W PAD_P18_E2[3]                   1'b0
    21      R/W PAD_P18_PDPUC[3]                1'b0
    22      R/W AON_PAD_P18_PU[3]               1'b0
    23      R/W AON_PAD_P18_PU_EN[3]            1'b1
    24      R/W PAD_P18_WKPOL[3]                1'b0
    25      R/W PAD_P18_WKEN[3]                 1'b0
    26      R/W PAD_P18_DEB[3]                  1'b0
    28:27   R/W PAD_P18_AON_MUX[3]              2'b0
    29      R/W PAD_P18_O_EN[3]                 1'b1
    30      R/W PAD_P18_DUMMY0[3]               1'b0
    31      R/W PAD_P18_DUMMY1[3]               1'b0
 */
typedef volatile union _AON_NS_P18_2_P18_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P18_SHDN_2: 1;
        uint32_t AON_PAD_P18_E_2: 1;
        uint32_t AON_PAD_P18_O_2: 1;
        uint32_t PAD_P18_E3_2: 1;
        uint32_t PAD_P18_E2_2: 1;
        uint32_t PAD_P18_PDPUC_2: 1;
        uint32_t AON_PAD_P18_PU_2: 1;
        uint32_t AON_PAD_P18_PU_EN_2: 1;
        uint32_t PAD_P18_WKPOL_2: 1;
        uint32_t PAD_P18_WKEN_2: 1;
        uint32_t PAD_P18_DEB_2: 1;
        uint32_t PAD_P18_AON_MUX_2: 2;
        uint32_t PAD_P18_O_EN_2: 1;
        uint32_t PAD_P18_DUMMY0_2: 1;
        uint32_t PAD_P18_DUMMY1_2: 1;
        uint32_t PAD_P18_SHDN_3: 1;
        uint32_t AON_PAD_P18_E_3: 1;
        uint32_t AON_PAD_P18_O_3: 1;
        uint32_t PAD_P18_E3_3: 1;
        uint32_t PAD_P18_E2_3: 1;
        uint32_t PAD_P18_PDPUC_3: 1;
        uint32_t AON_PAD_P18_PU_3: 1;
        uint32_t AON_PAD_P18_PU_EN_3: 1;
        uint32_t PAD_P18_WKPOL_3: 1;
        uint32_t PAD_P18_WKEN_3: 1;
        uint32_t PAD_P18_DEB_3: 1;
        uint32_t PAD_P18_AON_MUX_3: 2;
        uint32_t PAD_P18_O_EN_3: 1;
        uint32_t PAD_P18_DUMMY0_3: 1;
        uint32_t PAD_P18_DUMMY1_3: 1;
    };
} AON_NS_P18_2_P18_3_PAD_CFG_TYPE;

/* 0x1A54   0x4000_1a54
    0       R/W PAD_P18_SHDN[4]                 1'b1
    1       R/W AON_PAD_P18_E[4]                1'b0
    2       R/W AON_PAD_P18_O[4]                1'b0
    3       R/W PAD_P18_E3[4]                   1'b0
    4       R/W PAD_P18_E2[4]                   1'b0
    5       R/W PAD_P18_PDPUC[4]                1'b0
    6       R/W AON_PAD_P18_PU[4]               1'b0
    7       R/W AON_PAD_P18_PU_EN[4]            1'b1
    8       R/W PAD_P18_WKPOL[4]                1'b0
    9       R/W PAD_P18_WKEN[4]                 1'b0
    10      R/W PAD_P18_DEB[4]                  1'b0
    12:11   R/W PAD_P18_AON_MUX[4]              2'b0
    13      R/W PAD_P18_O_EN[4]                 1'b1
    14      R/W PAD_P18_DUMMY0[4]               1'b0
    15      R/W PAD_P18_DUMMY1[4]               1'b0
    16      R/W PAD_P18_SHDN[5]                 1'b1
    17      R/W AON_PAD_P18_E[5]                1'b0
    18      R/W AON_PAD_P18_O[5]                1'b0
    19      R/W PAD_P18_E3[5]                   1'b0
    20      R/W PAD_P18_E2[5]                   1'b0
    21      R/W PAD_P18_PDPUC[5]                1'b0
    22      R/W AON_PAD_P18_PU[5]               1'b0
    23      R/W AON_PAD_P18_PU_EN[5]            1'b1
    24      R/W PAD_P18_WKPOL[5]                1'b0
    25      R/W PAD_P18_WKEN[5]                 1'b0
    26      R/W PAD_P18_DEB[5]                  1'b0
    28:27   R/W PAD_P18_AON_MUX[5]              2'b0
    29      R/W PAD_P18_O_EN[5]                 1'b1
    30      R/W PAD_P18_DUMMY0[5]               1'b0
    31      R/W PAD_P18_DUMMY1[5]               1'b0
 */
typedef volatile union _AON_NS_P18_4_P18_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P18_SHDN_4: 1;
        uint32_t AON_PAD_P18_E_4: 1;
        uint32_t AON_PAD_P18_O_4: 1;
        uint32_t PAD_P18_E3_4: 1;
        uint32_t PAD_P18_E2_4: 1;
        uint32_t PAD_P18_PDPUC_4: 1;
        uint32_t AON_PAD_P18_PU_4: 1;
        uint32_t AON_PAD_P18_PU_EN_4: 1;
        uint32_t PAD_P18_WKPOL_4: 1;
        uint32_t PAD_P18_WKEN_4: 1;
        uint32_t PAD_P18_DEB_4: 1;
        uint32_t PAD_P18_AON_MUX_4: 2;
        uint32_t PAD_P18_O_EN_4: 1;
        uint32_t PAD_P18_DUMMY0_4: 1;
        uint32_t PAD_P18_DUMMY1_4: 1;
        uint32_t PAD_P18_SHDN_5: 1;
        uint32_t AON_PAD_P18_E_5: 1;
        uint32_t AON_PAD_P18_O_5: 1;
        uint32_t PAD_P18_E3_5: 1;
        uint32_t PAD_P18_E2_5: 1;
        uint32_t PAD_P18_PDPUC_5: 1;
        uint32_t AON_PAD_P18_PU_5: 1;
        uint32_t AON_PAD_P18_PU_EN_5: 1;
        uint32_t PAD_P18_WKPOL_5: 1;
        uint32_t PAD_P18_WKEN_5: 1;
        uint32_t PAD_P18_DEB_5: 1;
        uint32_t PAD_P18_AON_MUX_5: 2;
        uint32_t PAD_P18_O_EN_5: 1;
        uint32_t PAD_P18_DUMMY0_5: 1;
        uint32_t PAD_P18_DUMMY1_5: 1;
    };
} AON_NS_P18_4_P18_5_PAD_CFG_TYPE;

/* 0x1A58   0x4000_1a58
    0       R/W PAD_P18_SHDN[6]                 1'b1
    1       R/W AON_PAD_P18_E[6]                1'b0
    2       R/W AON_PAD_P18_O[6]                1'b0
    3       R/W PAD_P18_E3[6]                   1'b0
    4       R/W PAD_P18_E2[6]                   1'b0
    5       R/W PAD_P18_PDPUC[6]                1'b0
    6       R/W AON_PAD_P18_PU[6]               1'b0
    7       R/W AON_PAD_P18_PU_EN[6]            1'b1
    8       R/W PAD_P18_WKPOL[6]                1'b0
    9       R/W PAD_P18_WKEN[6]                 1'b0
    10      R/W PAD_P18_DEB[6]                  1'b0
    12:11   R/W PAD_P18_AON_MUX[6]              2'b0
    13      R/W PAD_P18_O_EN[6]                 1'b1
    14      R/W PAD_P18_DUMMY0[6]               1'b0
    15      R/W PAD_P18_DUMMY1[6]               1'b0
    16      R/W PAD_P18_SHDN[7]                 1'b1
    17      R/W AON_PAD_P18_E[7]                1'b0
    18      R/W AON_PAD_P18_O[7]                1'b0
    19      R/W PAD_P18_E3[7]                   1'b0
    20      R/W PAD_P18_E2[7]                   1'b0
    21      R/W PAD_P18_PDPUC[7]                1'b0
    22      R/W AON_PAD_P18_PU[7]               1'b0
    23      R/W AON_PAD_P18_PU_EN[7]            1'b1
    24      R/W PAD_P18_WKPOL[7]                1'b0
    25      R/W PAD_P18_WKEN[7]                 1'b0
    26      R/W PAD_P18_DEB[7]                  1'b0
    28:27   R/W PAD_P18_AON_MUX[7]              2'b0
    29      R/W PAD_P18_O_EN[7]                 1'b1
    30      R/W PAD_P18_DUMMY0[7]               1'b0
    31      R/W PAD_P18_DUMMY1[7]               1'b0
 */
typedef volatile union _AON_NS_P18_6_P18_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P18_SHDN_6: 1;
        uint32_t AON_PAD_P18_E_6: 1;
        uint32_t AON_PAD_P18_O_6: 1;
        uint32_t PAD_P18_E3_6: 1;
        uint32_t PAD_P18_E2_6: 1;
        uint32_t PAD_P18_PDPUC_6: 1;
        uint32_t AON_PAD_P18_PU_6: 1;
        uint32_t AON_PAD_P18_PU_EN_6: 1;
        uint32_t PAD_P18_WKPOL_6: 1;
        uint32_t PAD_P18_WKEN_6: 1;
        uint32_t PAD_P18_DEB_6: 1;
        uint32_t PAD_P18_AON_MUX_6: 2;
        uint32_t PAD_P18_O_EN_6: 1;
        uint32_t PAD_P18_DUMMY0_6: 1;
        uint32_t PAD_P18_DUMMY1_6: 1;
        uint32_t PAD_P18_SHDN_7: 1;
        uint32_t AON_PAD_P18_E_7: 1;
        uint32_t AON_PAD_P18_O_7: 1;
        uint32_t PAD_P18_E3_7: 1;
        uint32_t PAD_P18_E2_7: 1;
        uint32_t PAD_P18_PDPUC_7: 1;
        uint32_t AON_PAD_P18_PU_7: 1;
        uint32_t AON_PAD_P18_PU_EN_7: 1;
        uint32_t PAD_P18_WKPOL_7: 1;
        uint32_t PAD_P18_WKEN_7: 1;
        uint32_t PAD_P18_DEB_7: 1;
        uint32_t PAD_P18_AON_MUX_7: 2;
        uint32_t PAD_P18_O_EN_7: 1;
        uint32_t PAD_P18_DUMMY0_7: 1;
        uint32_t PAD_P18_DUMMY1_7: 1;
    };
} AON_NS_P18_6_P18_7_PAD_CFG_TYPE;

/* 0x1A5C   0x4000_1a5c
    0       R/W PAD_P19_SHDN[0]                 1'b1
    1       R/W AON_PAD_P19_E[0]                1'b0
    2       R/W AON_PAD_P19_O[0]                1'b0
    3       R/W PAD_P19_E3[0]                   1'b0
    4       R/W PAD_P19_E2[0]                   1'b0
    5       R/W PAD_P19_PDPUC[0]                1'b0
    6       R/W AON_PAD_P19_PU[0]               1'b0
    7       R/W AON_PAD_P19_PU_EN[0]            1'b1
    8       R/W PAD_P19_WKPOL[0]                1'b0
    9       R/W PAD_P19_WKEN[0]                 1'b0
    10      R/W PAD_P19_DEB[0]                  1'b0
    12:11   R/W PAD_P19_AON_MUX[0]              2'b0
    13      R/W PAD_P19_O_EN[0]                 1'b1
    14      R/W PAD_P19_HS_MUX[0]               1'b0
    15      R/W PAD_P19_DUMMY1[0]               1'b0
    16      R/W PAD_P19_SHDN[1]                 1'b1
    17      R/W AON_PAD_P19_E[1]                1'b0
    18      R/W AON_PAD_P19_O[1]                1'b0
    19      R/W PAD_P19_E3[1]                   1'b0
    20      R/W PAD_P19_E2[1]                   1'b0
    21      R/W PAD_P19_PDPUC[1]                1'b0
    22      R/W AON_PAD_P19_PU[1]               1'b0
    23      R/W AON_PAD_P19_PU_EN[1]            1'b1
    24      R/W PAD_P19_WKPOL[1]                1'b0
    25      R/W PAD_P19_WKEN[1]                 1'b0
    26      R/W PAD_P19_DEB[1]                  1'b0
    28:27   R/W PAD_P19_AON_MUX[1]              2'b0
    29      R/W PAD_P19_O_EN[1]                 1'b1
    30      R/W PAD_P19_HS_MUX[1]               1'b0
    31      R/W PAD_P19_DUMMY1[1]               1'b0
 */
typedef volatile union _AON_NS_P19_0_P19_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P19_SHDN_0: 1;
        uint32_t AON_PAD_P19_E_0: 1;
        uint32_t AON_PAD_P19_O_0: 1;
        uint32_t PAD_P19_E3_0: 1;
        uint32_t PAD_P19_E2_0: 1;
        uint32_t PAD_P19_PDPUC_0: 1;
        uint32_t AON_PAD_P19_PU_0: 1;
        uint32_t AON_PAD_P19_PU_EN_0: 1;
        uint32_t PAD_P19_WKPOL_0: 1;
        uint32_t PAD_P19_WKEN_0: 1;
        uint32_t PAD_P19_DEB_0: 1;
        uint32_t PAD_P19_AON_MUX_0: 2;
        uint32_t PAD_P19_O_EN_0: 1;
        uint32_t PAD_P19_HS_MUX_0: 1;
        uint32_t PAD_P19_DUMMY1_0: 1;
        uint32_t PAD_P19_SHDN_1: 1;
        uint32_t AON_PAD_P19_E_1: 1;
        uint32_t AON_PAD_P19_O_1: 1;
        uint32_t PAD_P19_E3_1: 1;
        uint32_t PAD_P19_E2_1: 1;
        uint32_t PAD_P19_PDPUC_1: 1;
        uint32_t AON_PAD_P19_PU_1: 1;
        uint32_t AON_PAD_P19_PU_EN_1: 1;
        uint32_t PAD_P19_WKPOL_1: 1;
        uint32_t PAD_P19_WKEN_1: 1;
        uint32_t PAD_P19_DEB_1: 1;
        uint32_t PAD_P19_AON_MUX_1: 2;
        uint32_t PAD_P19_O_EN_1: 1;
        uint32_t PAD_P19_HS_MUX_1: 1;
        uint32_t PAD_P19_DUMMY1_1: 1;
    };
} AON_NS_P19_0_P19_1_PAD_CFG_TYPE;

/* 0x1A60   0x4000_1a60
    0       R/W PAD_P19_SHDN[2]                 1'b1
    1       R/W AON_PAD_P19_E[2]                1'b0
    2       R/W AON_PAD_P19_O[2]                1'b0
    3       R/W PAD_P19_E3[2]                   1'b0
    4       R/W PAD_P19_E2[2]                   1'b0
    5       R/W PAD_P19_PDPUC[2]                1'b0
    6       R/W AON_PAD_P19_PU[2]               1'b0
    7       R/W AON_PAD_P19_PU_EN[2]            1'b1
    8       R/W PAD_P19_WKPOL[2]                1'b0
    9       R/W PAD_P19_WKEN[2]                 1'b0
    10      R/W PAD_P19_DEB[2]                  1'b0
    12:11   R/W PAD_P19_AON_MUX[2]              2'b0
    13      R/W PAD_P19_O_EN[2]                 1'b1
    14      R/W PAD_P19_HS_MUX[2]               1'b0
    15      R/W PAD_P19_DUMMY1[2]               1'b0
    16      R/W PAD_P19_SHDN[3]                 1'b1
    17      R/W AON_PAD_P19_E[3]                1'b0
    18      R/W AON_PAD_P19_O[3]                1'b0
    19      R/W PAD_P19_E3[3]                   1'b0
    20      R/W PAD_P19_E2[3]                   1'b0
    21      R/W PAD_P19_PDPUC[3]                1'b0
    22      R/W AON_PAD_P19_PU[3]               1'b0
    23      R/W AON_PAD_P19_PU_EN[3]            1'b1
    24      R/W PAD_P19_WKPOL[3]                1'b0
    25      R/W PAD_P19_WKEN[3]                 1'b0
    26      R/W PAD_P19_DEB[3]                  1'b0
    28:27   R/W PAD_P19_AON_MUX[3]              2'b0
    29      R/W PAD_P19_O_EN[3]                 1'b1
    30      R/W PAD_P19_HS_MUX[3]               1'b0
    31      R/W PAD_P19_DUMMY1[3]               1'b0
 */
typedef volatile union _AON_NS_P19_2_P19_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P19_SHDN_2: 1;
        uint32_t AON_PAD_P19_E_2: 1;
        uint32_t AON_PAD_P19_O_2: 1;
        uint32_t PAD_P19_E3_2: 1;
        uint32_t PAD_P19_E2_2: 1;
        uint32_t PAD_P19_PDPUC_2: 1;
        uint32_t AON_PAD_P19_PU_2: 1;
        uint32_t AON_PAD_P19_PU_EN_2: 1;
        uint32_t PAD_P19_WKPOL_2: 1;
        uint32_t PAD_P19_WKEN_2: 1;
        uint32_t PAD_P19_DEB_2: 1;
        uint32_t PAD_P19_AON_MUX_2: 2;
        uint32_t PAD_P19_O_EN_2: 1;
        uint32_t PAD_P19_HS_MUX_2: 1;
        uint32_t PAD_P19_DUMMY1_2: 1;
        uint32_t PAD_P19_SHDN_3: 1;
        uint32_t AON_PAD_P19_E_3: 1;
        uint32_t AON_PAD_P19_O_3: 1;
        uint32_t PAD_P19_E3_3: 1;
        uint32_t PAD_P19_E2_3: 1;
        uint32_t PAD_P19_PDPUC_3: 1;
        uint32_t AON_PAD_P19_PU_3: 1;
        uint32_t AON_PAD_P19_PU_EN_3: 1;
        uint32_t PAD_P19_WKPOL_3: 1;
        uint32_t PAD_P19_WKEN_3: 1;
        uint32_t PAD_P19_DEB_3: 1;
        uint32_t PAD_P19_AON_MUX_3: 2;
        uint32_t PAD_P19_O_EN_3: 1;
        uint32_t PAD_P19_HS_MUX_3: 1;
        uint32_t PAD_P19_DUMMY1_3: 1;
    };
} AON_NS_P19_2_P19_3_PAD_CFG_TYPE;

/* 0x1A64   0x4000_1a64
    0       R/W PAD_P19_SHDN[4]                 1'b1
    1       R/W AON_PAD_P19_E[4]                1'b0
    2       R/W AON_PAD_P19_O[4]                1'b0
    3       R/W PAD_P19_E3[4]                   1'b0
    4       R/W PAD_P19_E2[4]                   1'b0
    5       R/W PAD_P19_PDPUC[4]                1'b0
    6       R/W AON_PAD_P19_PU[4]               1'b0
    7       R/W AON_PAD_P19_PU_EN[4]            1'b1
    8       R/W PAD_P19_WKPOL[4]                1'b0
    9       R/W PAD_P19_WKEN[4]                 1'b0
    10      R/W PAD_P19_DEB[4]                  1'b0
    12:11   R/W PAD_P19_AON_MUX[4]              2'b0
    13      R/W PAD_P19_O_EN[4]                 1'b1
    14      R/W PAD_P19_HS_MUX[4]               1'b0
    15      R/W PAD_P19_DUMMY1[4]               1'b0
    16      R/W PAD_P19_SHDN[5]                 1'b1
    17      R/W AON_PAD_P19_E[5]                1'b0
    18      R/W AON_PAD_P19_O[5]                1'b0
    19      R/W PAD_P19_E3[5]                   1'b0
    20      R/W PAD_P19_E2[5]                   1'b0
    21      R/W PAD_P19_PDPUC[5]                1'b0
    22      R/W AON_PAD_P19_PU[5]               1'b0
    23      R/W AON_PAD_P19_PU_EN[5]            1'b1
    24      R/W PAD_P19_WKPOL[5]                1'b0
    25      R/W PAD_P19_WKEN[5]                 1'b0
    26      R/W PAD_P19_DEB[5]                  1'b0
    28:27   R/W PAD_P19_AON_MUX[5]              2'b0
    29      R/W PAD_P19_O_EN[5]                 1'b1
    30      R/W PAD_P19_HS_MUX[5]               1'b0
    31      R/W PAD_P19_DUMMY1[5]               1'b0
 */
typedef volatile union _AON_NS_P19_4_P19_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P19_SHDN_4: 1;
        uint32_t AON_PAD_P19_E_4: 1;
        uint32_t AON_PAD_P19_O_4: 1;
        uint32_t PAD_P19_E3_4: 1;
        uint32_t PAD_P19_E2_4: 1;
        uint32_t PAD_P19_PDPUC_4: 1;
        uint32_t AON_PAD_P19_PU_4: 1;
        uint32_t AON_PAD_P19_PU_EN_4: 1;
        uint32_t PAD_P19_WKPOL_4: 1;
        uint32_t PAD_P19_WKEN_4: 1;
        uint32_t PAD_P19_DEB_4: 1;
        uint32_t PAD_P19_AON_MUX_4: 2;
        uint32_t PAD_P19_O_EN_4: 1;
        uint32_t PAD_P19_HS_MUX_4: 1;
        uint32_t PAD_P19_DUMMY1_4: 1;
        uint32_t PAD_P19_SHDN_5: 1;
        uint32_t AON_PAD_P19_E_5: 1;
        uint32_t AON_PAD_P19_O_5: 1;
        uint32_t PAD_P19_E3_5: 1;
        uint32_t PAD_P19_E2_5: 1;
        uint32_t PAD_P19_PDPUC_5: 1;
        uint32_t AON_PAD_P19_PU_5: 1;
        uint32_t AON_PAD_P19_PU_EN_5: 1;
        uint32_t PAD_P19_WKPOL_5: 1;
        uint32_t PAD_P19_WKEN_5: 1;
        uint32_t PAD_P19_DEB_5: 1;
        uint32_t PAD_P19_AON_MUX_5: 2;
        uint32_t PAD_P19_O_EN_5: 1;
        uint32_t PAD_P19_HS_MUX_5: 1;
        uint32_t PAD_P19_DUMMY1_5: 1;
    };
} AON_NS_P19_4_P19_5_PAD_CFG_TYPE;

/* 0x1A68   0x4000_1a68
    0       R/W PAD_P19_SHDN[6]                 1'b1
    1       R/W AON_PAD_P19_E[6]                1'b0
    2       R/W AON_PAD_P19_O[6]                1'b0
    3       R/W PAD_P19_E3[6]                   1'b0
    4       R/W PAD_P19_E2[6]                   1'b0
    5       R/W PAD_P19_PDPUC[6]                1'b0
    6       R/W AON_PAD_P19_PU[6]               1'b0
    7       R/W AON_PAD_P19_PU_EN[6]            1'b1
    8       R/W PAD_P19_WKPOL[6]                1'b0
    9       R/W PAD_P19_WKEN[6]                 1'b0
    10      R/W PAD_P19_DEB[6]                  1'b0
    12:11   R/W PAD_P19_AON_MUX[6]              2'b0
    13      R/W PAD_P19_O_EN[6]                 1'b1
    14      R/W PAD_P19_HS_MUX[6]               1'b0
    15      R/W PAD_P19_DUMMY1[6]               1'b0
    16      R/W PAD_P19_SHDN[7]                 1'b1
    17      R/W AON_PAD_P19_E[7]                1'b0
    18      R/W AON_PAD_P19_O[7]                1'b0
    19      R/W PAD_P19_E3[7]                   1'b0
    20      R/W PAD_P19_E2[7]                   1'b0
    21      R/W PAD_P19_PDPUC[7]                1'b0
    22      R/W AON_PAD_P19_PU[7]               1'b0
    23      R/W AON_PAD_P19_PU_EN[7]            1'b1
    24      R/W PAD_P19_WKPOL[7]                1'b0
    25      R/W PAD_P19_WKEN[7]                 1'b0
    26      R/W PAD_P19_DEB[7]                  1'b0
    28:27   R/W PAD_P19_AON_MUX[7]              2'b0
    29      R/W PAD_P19_O_EN[7]                 1'b1
    30      R/W PAD_P19_HS_MUX[7]               1'b0
    31      R/W PAD_P19_DUMMY1[7]               1'b0
 */
typedef volatile union _AON_NS_P19_6_P19_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P19_SHDN_6: 1;
        uint32_t AON_PAD_P19_E_6: 1;
        uint32_t AON_PAD_P19_O_6: 1;
        uint32_t PAD_P19_E3_6: 1;
        uint32_t PAD_P19_E2_6: 1;
        uint32_t PAD_P19_PDPUC_6: 1;
        uint32_t AON_PAD_P19_PU_6: 1;
        uint32_t AON_PAD_P19_PU_EN_6: 1;
        uint32_t PAD_P19_WKPOL_6: 1;
        uint32_t PAD_P19_WKEN_6: 1;
        uint32_t PAD_P19_DEB_6: 1;
        uint32_t PAD_P19_AON_MUX_6: 2;
        uint32_t PAD_P19_O_EN_6: 1;
        uint32_t PAD_P19_HS_MUX_6: 1;
        uint32_t PAD_P19_DUMMY1_6: 1;
        uint32_t PAD_P19_SHDN_7: 1;
        uint32_t AON_PAD_P19_E_7: 1;
        uint32_t AON_PAD_P19_O_7: 1;
        uint32_t PAD_P19_E3_7: 1;
        uint32_t PAD_P19_E2_7: 1;
        uint32_t PAD_P19_PDPUC_7: 1;
        uint32_t AON_PAD_P19_PU_7: 1;
        uint32_t AON_PAD_P19_PU_EN_7: 1;
        uint32_t PAD_P19_WKPOL_7: 1;
        uint32_t PAD_P19_WKEN_7: 1;
        uint32_t PAD_P19_DEB_7: 1;
        uint32_t PAD_P19_AON_MUX_7: 2;
        uint32_t PAD_P19_O_EN_7: 1;
        uint32_t PAD_P19_HS_MUX_7: 1;
        uint32_t PAD_P19_DUMMY1_7: 1;
    };
} AON_NS_P19_6_P19_7_PAD_CFG_TYPE;

/* 0x1A6C   0x4000_1a6c
    0       R/W PAD_BOOT_SEL_SHDN               1'b1
    1       R/W AON_PAD_BOOT_SEL_E              1'b0
    2       R/W AON_PAD_BOOT_SEL_O              1'b0
    3       R/W PAD_BOOT_SEL_E3                 1'b0
    4       R/W PAD_BOOT_SEL_E2                 1'b0
    5       R/W PAD_BOOT_SEL_PDPUC              1'b0
    6       R/W AON_PAD_BOOT_SEL_PU             1'b1
    7       R/W AON_PAD_BOOT_SEL_PU_EN          1'b1
    8       R/W PAD_BOOT_SEL_WKPOL              1'b0
    9       R/W PAD_BOOT_SEL_WKEN               1'b0
    10      R/W PAD_BOOT_SEL_DEB                1'b0
    12:11   R/W PAD_BOOT_SEL_DUMMY0[1:0]        2'b0
    13      R/W PAD_BOOT_SEL_O_EN               1'b1
    14      R   PAD_BOOT_SEL_I                  1'b1
    15      R/W PAD_BOOT_SEL_DUMMY2             1'b0
    31:16   R/W AON_PAD_DUMMY[15:0]             16'b0
 */
typedef volatile union _AON_NS_P_BOOT_SEL_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_BOOT_SEL_SHDN: 1;
        uint32_t AON_PAD_BOOT_SEL_E: 1;
        uint32_t AON_PAD_BOOT_SEL_O: 1;
        uint32_t PAD_BOOT_SEL_E3: 1;
        uint32_t PAD_BOOT_SEL_E2: 1;
        uint32_t PAD_BOOT_SEL_PDPUC: 1;
        uint32_t AON_PAD_BOOT_SEL_PU: 1;
        uint32_t AON_PAD_BOOT_SEL_PU_EN: 1;
        uint32_t PAD_BOOT_SEL_WKPOL: 1;
        uint32_t PAD_BOOT_SEL_WKEN: 1;
        uint32_t PAD_BOOT_SEL_DEB: 1;
        uint32_t PAD_BOOT_SEL_DUMMY0_1_0: 2;
        uint32_t PAD_BOOT_SEL_O_EN: 1;
        uint32_t PAD_BOOT_SEL_I: 1;
        uint32_t PAD_BOOT_SEL_DUMMY2: 1;
        uint32_t AON_PAD_DUMMY_15_0: 16;
    };
} AON_NS_P_BOOT_SEL_PAD_CFG_TYPE;

/* 0x1A70   0x4000_1a70
    0       R/W kr0_digi_debug0_out_sel         1'b0
    1       R/W kr0_digi_debug1_out_sel         1'b0
    2       R/W kr0_digi_debug2_out_sel         1'b0
    3       R/W kr0_digi_debug3_out_sel         1'b0
    4       R/W kr0_digi_debug4_out_sel         1'b0
    5       R/W kr0_digi_debug5_out_sel         1'b0
    6       R/W kr0_digi_debug6_out_sel         1'b0
    7       R/W kr0_digi_debug7_out_sel         1'b0
    8       R/W kr0_digi_debug8_out_sel         1'b0
    9       R/W kr0_digi_debug9_out_sel         1'b0
    10      R/W kr0_digi_debug10_out_sel        1'b0
    11      R/W kr0_digi_debug11_out_sel        1'b0
    12      R/W kr0_digi_debug12_out_sel        1'b0
    13      R/W kr0_digi_debug13_out_sel        1'b0
    14      R/W kr0_digi_debug14_out_sel        1'b0
    15      R/W kr0_digi_debug15_out_sel        1'b0
    16      R/W kr0_digi_debug16_out_sel        1'b0
    17      R/W kr0_digi_debug17_out_sel        1'b0
    18      R/W kr0_digi_debug18_out_sel        1'b0
    19      R/W kr0_digi_debug19_out_sel        1'b0
    20      R/W kr0_digi_debug20_out_sel        1'b0
    21      R/W kr0_digi_debug21_out_sel        1'b0
    22      R/W kr0_digi_debug22_out_sel        1'b0
    23      R/W kr0_digi_debug23_out_sel        1'b0
    24      R/W kr0_digi_debug24_out_sel        1'b0
    25      R/W kr0_digi_debug25_out_sel        1'b0
    26      R/W kr0_digi_debug26_out_sel        1'b0
    27      R/W kr0_digi_debug27_out_sel        1'b0
    28      R/W kr0_digi_debug28_out_sel        1'b0
    29      R/W kr0_digi_debug29_out_sel        1'b0
    30      R/W kr0_digi_debug30_out_sel        1'b0
    31      R/W kr0_digi_debug31_out_sel        1'b0
 */
typedef volatile union _AON_NS_PAD_AON_PINMUX_CFG1_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t kr0_digi_debug0_out_sel: 1;
        uint32_t kr0_digi_debug1_out_sel: 1;
        uint32_t kr0_digi_debug2_out_sel: 1;
        uint32_t kr0_digi_debug3_out_sel: 1;
        uint32_t kr0_digi_debug4_out_sel: 1;
        uint32_t kr0_digi_debug5_out_sel: 1;
        uint32_t kr0_digi_debug6_out_sel: 1;
        uint32_t kr0_digi_debug7_out_sel: 1;
        uint32_t kr0_digi_debug8_out_sel: 1;
        uint32_t kr0_digi_debug9_out_sel: 1;
        uint32_t kr0_digi_debug10_out_sel: 1;
        uint32_t kr0_digi_debug11_out_sel: 1;
        uint32_t kr0_digi_debug12_out_sel: 1;
        uint32_t kr0_digi_debug13_out_sel: 1;
        uint32_t kr0_digi_debug14_out_sel: 1;
        uint32_t kr0_digi_debug15_out_sel: 1;
        uint32_t kr0_digi_debug16_out_sel: 1;
        uint32_t kr0_digi_debug17_out_sel: 1;
        uint32_t kr0_digi_debug18_out_sel: 1;
        uint32_t kr0_digi_debug19_out_sel: 1;
        uint32_t kr0_digi_debug20_out_sel: 1;
        uint32_t kr0_digi_debug21_out_sel: 1;
        uint32_t kr0_digi_debug22_out_sel: 1;
        uint32_t kr0_digi_debug23_out_sel: 1;
        uint32_t kr0_digi_debug24_out_sel: 1;
        uint32_t kr0_digi_debug25_out_sel: 1;
        uint32_t kr0_digi_debug26_out_sel: 1;
        uint32_t kr0_digi_debug27_out_sel: 1;
        uint32_t kr0_digi_debug28_out_sel: 1;
        uint32_t kr0_digi_debug29_out_sel: 1;
        uint32_t kr0_digi_debug30_out_sel: 1;
        uint32_t kr0_digi_debug31_out_sel: 1;
    };
} AON_NS_PAD_AON_PINMUX_CFG1_TYPE;

/* 0x1A74   0x4000_1a74
    12:0    R/W rtc_out_sel                     13'b0
    31:13   R/W PAD_AON_PINMUX_CFG2_DUMMY       19'b0
 */
typedef volatile union _AON_NS_PAD_AON_PINMUX_CFG2_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t rtc_out_sel: 13;
        uint32_t PAD_AON_PINMUX_CFG2_DUMMY: 19;
    };
} AON_NS_PAD_AON_PINMUX_CFG2_TYPE;

/* 0x1A78   0x4000_1a78
    0       R/W PAD_P20_SHDN[0]                 1'b1
    1       R/W AON_PAD_P20_E[0]                1'b0
    2       R/W AON_PAD_P20_O[0]                1'b0
    3       R/W PAD_P20_E3[0]                   1'b0
    4       R/W PAD_P20_E2[0]                   1'b0
    5       R/W PAD_P20_PDPUC[0]                1'b0
    6       R/W AON_PAD_P20_PU[0]               1'b1
    7       R/W AON_PAD_P20_PU_EN[0]            1'b1
    8       R/W PAD_P20_WKPOL[0]                1'b0
    9       R/W PAD_P20_WKEN[0]                 1'b0
    10      R/W PAD_P20_DEB[0]                  1'b0
    12:11   R/W PAD_P20_AON_MUX[0]              2'b0
    13      R/W PAD_P20_O_EN[0]                 1'b1
    14      R/W PAD_P20_HS_MUX[0]               1'b0
    15      R/W PAD_P20_DUMMY1[0]               1'b0
    16      R/W PAD_P20_SHDN[1]                 1'b1
    17      R/W AON_PAD_P20_E[1]                1'b0
    18      R/W AON_PAD_P20_O[1]                1'b0
    19      R/W PAD_P20_E3[1]                   1'b0
    20      R/W PAD_P20_E2[1]                   1'b0
    21      R/W PAD_P20_PDPUC[1]                1'b0
    22      R/W AON_PAD_P20_PU[1]               1'b0
    23      R/W AON_PAD_P20_PU_EN[1]            1'b1
    24      R/W PAD_P20_WKPOL[1]                1'b0
    25      R/W PAD_P20_WKEN[1]                 1'b0
    26      R/W PAD_P20_DEB[1]                  1'b0
    28:27   R/W PAD_P20_AON_MUX[1]              2'b0
    29      R/W PAD_P20_O_EN[1]                 1'b1
    30      R/W PAD_P20_HS_MUX[1]               1'b0
    31      R/W PAD_P20_DUMMY1[1]               1'b0
 */
typedef volatile union _AON_NS_P20_0_P20_1_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P20_SHDN_0: 1;
        uint32_t AON_PAD_P20_E_0: 1;
        uint32_t AON_PAD_P20_O_0: 1;
        uint32_t PAD_P20_E3_0: 1;
        uint32_t PAD_P20_E2_0: 1;
        uint32_t PAD_P20_PDPUC_0: 1;
        uint32_t AON_PAD_P20_PU_0: 1;
        uint32_t AON_PAD_P20_PU_EN_0: 1;
        uint32_t PAD_P20_WKPOL_0: 1;
        uint32_t PAD_P20_WKEN_0: 1;
        uint32_t PAD_P20_DEB_0: 1;
        uint32_t PAD_P20_AON_MUX_0: 2;
        uint32_t PAD_P20_O_EN_0: 1;
        uint32_t PAD_P20_HS_MUX_0: 1;
        uint32_t PAD_P20_DUMMY1_0: 1;
        uint32_t PAD_P20_SHDN_1: 1;
        uint32_t AON_PAD_P20_E_1: 1;
        uint32_t AON_PAD_P20_O_1: 1;
        uint32_t PAD_P20_E3_1: 1;
        uint32_t PAD_P20_E2_1: 1;
        uint32_t PAD_P20_PDPUC_1: 1;
        uint32_t AON_PAD_P20_PU_1: 1;
        uint32_t AON_PAD_P20_PU_EN_1: 1;
        uint32_t PAD_P20_WKPOL_1: 1;
        uint32_t PAD_P20_WKEN_1: 1;
        uint32_t PAD_P20_DEB_1: 1;
        uint32_t PAD_P20_AON_MUX_1: 2;
        uint32_t PAD_P20_O_EN_1: 1;
        uint32_t PAD_P20_HS_MUX_1: 1;
        uint32_t PAD_P20_DUMMY1_1: 1;
    };
} AON_NS_P20_0_P20_1_PAD_CFG_TYPE;

/* 0x1A7C   0x4000_1a7c
    0       R/W PAD_P20_SHDN[2]                 1'b1
    1       R/W AON_PAD_P20_E[2]                1'b0
    2       R/W AON_PAD_P20_O[2]                1'b0
    3       R/W PAD_P20_E3[2]                   1'b0
    4       R/W PAD_P20_E2[2]                   1'b0
    5       R/W PAD_P20_PDPUC[2]                1'b0
    6       R/W AON_PAD_P20_PU[2]               1'b0
    7       R/W AON_PAD_P20_PU_EN[2]            1'b1
    8       R/W PAD_P20_WKPOL[2]                1'b0
    9       R/W PAD_P20_WKEN[2]                 1'b0
    10      R/W PAD_P20_DEB[2]                  1'b0
    12:11   R/W PAD_P20_AON_MUX[2]              2'b0
    13      R/W PAD_P20_O_EN[2]                 1'b1
    14      R/W PAD_P20_HS_MUX[2]               1'b0
    15      R/W PAD_P20_DUMMY1[2]               1'b0
    16      R/W PAD_P20_SHDN[3]                 1'b1
    17      R/W AON_PAD_P20_E[3]                1'b0
    18      R/W AON_PAD_P20_O[3]                1'b0
    19      R/W PAD_P20_E3[3]                   1'b0
    20      R/W PAD_P20_E2[3]                   1'b0
    21      R/W PAD_P20_PDPUC[3]                1'b0
    22      R/W AON_PAD_P20_PU[3]               1'b0
    23      R/W AON_PAD_P20_PU_EN[3]            1'b1
    24      R/W PAD_P20_WKPOL[3]                1'b0
    25      R/W PAD_P20_WKEN[3]                 1'b0
    26      R/W PAD_P20_DEB[3]                  1'b0
    28:27   R/W PAD_P20_AON_MUX[3]              2'b0
    29      R/W PAD_P20_O_EN[3]                 1'b1
    30      R/W PAD_P20_HS_MUX[3]               1'b0
    31      R/W PAD_P20_DUMMY1[3]               1'b0
 */
typedef volatile union _AON_NS_P20_2_P20_3_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P20_SHDN_2: 1;
        uint32_t AON_PAD_P20_E_2: 1;
        uint32_t AON_PAD_P20_O_2: 1;
        uint32_t PAD_P20_E3_2: 1;
        uint32_t PAD_P20_E2_2: 1;
        uint32_t PAD_P20_PDPUC_2: 1;
        uint32_t AON_PAD_P20_PU_2: 1;
        uint32_t AON_PAD_P20_PU_EN_2: 1;
        uint32_t PAD_P20_WKPOL_2: 1;
        uint32_t PAD_P20_WKEN_2: 1;
        uint32_t PAD_P20_DEB_2: 1;
        uint32_t PAD_P20_AON_MUX_2: 2;
        uint32_t PAD_P20_O_EN_2: 1;
        uint32_t PAD_P20_HS_MUX_2: 1;
        uint32_t PAD_P20_DUMMY1_2: 1;
        uint32_t PAD_P20_SHDN_3: 1;
        uint32_t AON_PAD_P20_E_3: 1;
        uint32_t AON_PAD_P20_O_3: 1;
        uint32_t PAD_P20_E3_3: 1;
        uint32_t PAD_P20_E2_3: 1;
        uint32_t PAD_P20_PDPUC_3: 1;
        uint32_t AON_PAD_P20_PU_3: 1;
        uint32_t AON_PAD_P20_PU_EN_3: 1;
        uint32_t PAD_P20_WKPOL_3: 1;
        uint32_t PAD_P20_WKEN_3: 1;
        uint32_t PAD_P20_DEB_3: 1;
        uint32_t PAD_P20_AON_MUX_3: 2;
        uint32_t PAD_P20_O_EN_3: 1;
        uint32_t PAD_P20_HS_MUX_3: 1;
        uint32_t PAD_P20_DUMMY1_3: 1;
    };
} AON_NS_P20_2_P20_3_PAD_CFG_TYPE;

/* 0x1A80   0x4000_1a80
    0       R/W PAD_P20_SHDN[4]                 1'b1
    1       R/W AON_PAD_P20_E[4]                1'b0
    2       R/W AON_PAD_P20_O[4]                1'b0
    3       R/W PAD_P20_E3[4]                   1'b0
    4       R/W PAD_P20_E2[4]                   1'b0
    5       R/W PAD_P20_PDPUC[4]                1'b0
    6       R/W AON_PAD_P20_PU[4]               1'b0
    7       R/W AON_PAD_P20_PU_EN[4]            1'b1
    8       R/W PAD_P20_WKPOL[4]                1'b0
    9       R/W PAD_P20_WKEN[4]                 1'b0
    10      R/W PAD_P20_DEB[4]                  1'b0
    12:11   R/W PAD_P20_AON_MUX[4]              2'b0
    13      R/W PAD_P20_O_EN[4]                 1'b1
    14      R/W PAD_P20_DUMMY0[4]               1'b0
    15      R/W PAD_P20_DUMMY1[4]               1'b0
    16      R/W PAD_P20_SHDN[5]                 1'b1
    17      R/W AON_PAD_P20_E[5]                1'b0
    18      R/W AON_PAD_P20_O[5]                1'b0
    19      R/W PAD_P20_E3[5]                   1'b0
    20      R/W PAD_P20_E2[5]                   1'b0
    21      R/W PAD_P20_PDPUC[5]                1'b0
    22      R/W AON_PAD_P20_PU[5]               1'b0
    23      R/W AON_PAD_P20_PU_EN[5]            1'b1
    24      R/W PAD_P20_WKPOL[5]                1'b0
    25      R/W PAD_P20_WKEN[5]                 1'b0
    26      R/W PAD_P20_DEB[5]                  1'b0
    28:27   R/W PAD_P20_AON_MUX[5]              2'b0
    29      R/W PAD_P20_O_EN[5]                 1'b1
    30      R/W PAD_P20_DUMMY0[5]               1'b0
    31      R/W PAD_P20_DUMMY1[5]               1'b0
 */
typedef volatile union _AON_NS_P20_4_P20_5_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P20_SHDN_4: 1;
        uint32_t AON_PAD_P20_E_4: 1;
        uint32_t AON_PAD_P20_O_4: 1;
        uint32_t PAD_P20_E3_4: 1;
        uint32_t PAD_P20_E2_4: 1;
        uint32_t PAD_P20_PDPUC_4: 1;
        uint32_t AON_PAD_P20_PU_4: 1;
        uint32_t AON_PAD_P20_PU_EN_4: 1;
        uint32_t PAD_P20_WKPOL_4: 1;
        uint32_t PAD_P20_WKEN_4: 1;
        uint32_t PAD_P20_DEB_4: 1;
        uint32_t PAD_P20_AON_MUX_4: 2;
        uint32_t PAD_P20_O_EN_4: 1;
        uint32_t PAD_P20_DUMMY0_4: 1;
        uint32_t PAD_P20_DUMMY1_4: 1;
        uint32_t PAD_P20_SHDN_5: 1;
        uint32_t AON_PAD_P20_E_5: 1;
        uint32_t AON_PAD_P20_O_5: 1;
        uint32_t PAD_P20_E3_5: 1;
        uint32_t PAD_P20_E2_5: 1;
        uint32_t PAD_P20_PDPUC_5: 1;
        uint32_t AON_PAD_P20_PU_5: 1;
        uint32_t AON_PAD_P20_PU_EN_5: 1;
        uint32_t PAD_P20_WKPOL_5: 1;
        uint32_t PAD_P20_WKEN_5: 1;
        uint32_t PAD_P20_DEB_5: 1;
        uint32_t PAD_P20_AON_MUX_5: 2;
        uint32_t PAD_P20_O_EN_5: 1;
        uint32_t PAD_P20_DUMMY0_5: 1;
        uint32_t PAD_P20_DUMMY1_5: 1;
    };
} AON_NS_P20_4_P20_5_PAD_CFG_TYPE;

/* 0x1A84   0x4000_1a84
    0       R/W PAD_P20_SHDN[6]                 1'b1
    1       R/W AON_PAD_P20_E[6]                1'b0
    2       R/W AON_PAD_P20_O[6]                1'b0
    3       R/W PAD_P20_E3[6]                   1'b0
    4       R/W PAD_P20_E2[6]                   1'b0
    5       R/W PAD_P20_PDPUC[6]                1'b0
    6       R/W AON_PAD_P20_PU[6]               1'b0
    7       R/W AON_PAD_P20_PU_EN[6]            1'b1
    8       R/W PAD_P20_WKPOL[6]                1'b0
    9       R/W PAD_P20_WKEN[6]                 1'b0
    10      R/W PAD_P20_DEB[6]                  1'b0
    12:11   R/W PAD_P20_AON_MUX[6]              2'b0
    13      R/W PAD_P20_O_EN[6]                 1'b1
    14      R/W PAD_P20_DUMMY0[6]               1'b0
    15      R/W PAD_P20_DUMMY1[6]               1'b0
    16      R/W PAD_P20_SHDN[7]                 1'b1
    17      R/W AON_PAD_P20_E[7]                1'b0
    18      R/W AON_PAD_P20_O[7]                1'b0
    19      R/W PAD_P20_E3[7]                   1'b0
    20      R/W PAD_P20_E2[7]                   1'b0
    21      R/W PAD_P20_PDPUC[7]                1'b0
    22      R/W AON_PAD_P20_PU[7]               1'b0
    23      R/W AON_PAD_P20_PU_EN[7]            1'b1
    24      R/W PAD_P20_WKPOL[7]                1'b0
    25      R/W PAD_P20_WKEN[7]                 1'b0
    26      R/W PAD_P20_DEB[7]                  1'b0
    28:27   R/W PAD_P20_AON_MUX[7]              2'b0
    29      R/W PAD_P20_O_EN[7]                 1'b1
    30      R/W PAD_P20_DUMMY0[7]               1'b0
    31      R/W PAD_P20_DUMMY1[7]               1'b0
 */
typedef volatile union _AON_NS_P20_6_P20_7_PAD_CFG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P20_SHDN_6: 1;
        uint32_t AON_PAD_P20_E_6: 1;
        uint32_t AON_PAD_P20_O_6: 1;
        uint32_t PAD_P20_E3_6: 1;
        uint32_t PAD_P20_E2_6: 1;
        uint32_t PAD_P20_PDPUC_6: 1;
        uint32_t AON_PAD_P20_PU_6: 1;
        uint32_t AON_PAD_P20_PU_EN_6: 1;
        uint32_t PAD_P20_WKPOL_6: 1;
        uint32_t PAD_P20_WKEN_6: 1;
        uint32_t PAD_P20_DEB_6: 1;
        uint32_t PAD_P20_AON_MUX_6: 2;
        uint32_t PAD_P20_O_EN_6: 1;
        uint32_t PAD_P20_DUMMY0_6: 1;
        uint32_t PAD_P20_DUMMY1_6: 1;
        uint32_t PAD_P20_SHDN_7: 1;
        uint32_t AON_PAD_P20_E_7: 1;
        uint32_t AON_PAD_P20_O_7: 1;
        uint32_t PAD_P20_E3_7: 1;
        uint32_t PAD_P20_E2_7: 1;
        uint32_t PAD_P20_PDPUC_7: 1;
        uint32_t AON_PAD_P20_PU_7: 1;
        uint32_t AON_PAD_P20_PU_EN_7: 1;
        uint32_t PAD_P20_WKPOL_7: 1;
        uint32_t PAD_P20_WKEN_7: 1;
        uint32_t PAD_P20_DEB_7: 1;
        uint32_t PAD_P20_AON_MUX_7: 2;
        uint32_t PAD_P20_O_EN_7: 1;
        uint32_t PAD_P20_DUMMY0_7: 1;
        uint32_t PAD_P20_DUMMY1_7: 1;
    };
} AON_NS_P20_6_P20_7_PAD_CFG_TYPE;

/* 0x1AA0   0x4000_1aa0
    0       w1c PAD_ADC_STS[0]                  1'b1
    1       w1c PAD_ADC_STS[1]                  1'b1
    2       w1c PAD_ADC_STS[2]                  1'b1
    3       w1c PAD_ADC_STS[3]                  1'b1
    4       w1c PAD_ADC_STS[4]                  1'b1
    5       w1c PAD_ADC_STS[5]                  1'b1
    6       w1c PAD_ADC_STS[6]                  1'b1
    7       w1c PAD_ADC_STS[7]                  1'b1
    8       w1c PAD_P1_STS[0]                   1'b1
    9       w1c PAD_P1_STS[1]                   1'b1
    10      w1c PAD_P1_STS[2]                   1'b1
    11      w1c PAD_P1_STS[3]                   1'b1
    12      w1c PAD_P1_STS[4]                   1'b1
    13      w1c PAD_P1_STS[5]                   1'b1
    14      w1c PAD_P1_STS[6]                   1'b1
    15      w1c PAD_P1_STS[7]                   1'b1
    16      w1c PAD_P2_STS[0]                   1'b1
    17      w1c PAD_P2_STS[1]                   1'b1
    18      w1c PAD_P2_STS[2]                   1'b1
    19      w1c PAD_P2_STS[3]                   1'b1
    20      w1c PAD_P2_STS[4]                   1'b1
    21      w1c PAD_P2_STS[5]                   1'b1
    22      w1c PAD_P2_STS[6]                   1'b1
    23      w1c PAD_P2_STS[7]                   1'b1
    24      w1c PAD_P3_STS[0]                   1'b1
    25      w1c PAD_P3_STS[1]                   1'b1
    26      w1c PAD_P3_STS[2]                   1'b1
    27      w1c PAD_P3_STS[3]                   1'b1
    28      w1c PAD_P3_STS[4]                   1'b1
    29      w1c PAD_P3_STS[5]                   1'b1
    30      w1c PAD_P3_STS[6]                   1'b1
    31      w1c PAD_P3_STS[7]                   1'b1
 */
typedef volatile union _AON_NS_PAD_Status_0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_ADC_STS_0: 1;
        uint32_t PAD_ADC_STS_1: 1;
        uint32_t PAD_ADC_STS_2: 1;
        uint32_t PAD_ADC_STS_3: 1;
        uint32_t PAD_ADC_STS_4: 1;
        uint32_t PAD_ADC_STS_5: 1;
        uint32_t PAD_ADC_STS_6: 1;
        uint32_t PAD_ADC_STS_7: 1;
        uint32_t PAD_P1_STS_0: 1;
        uint32_t PAD_P1_STS_1: 1;
        uint32_t PAD_P1_STS_2: 1;
        uint32_t PAD_P1_STS_3: 1;
        uint32_t PAD_P1_STS_4: 1;
        uint32_t PAD_P1_STS_5: 1;
        uint32_t PAD_P1_STS_6: 1;
        uint32_t PAD_P1_STS_7: 1;
        uint32_t PAD_P2_STS_0: 1;
        uint32_t PAD_P2_STS_1: 1;
        uint32_t PAD_P2_STS_2: 1;
        uint32_t PAD_P2_STS_3: 1;
        uint32_t PAD_P2_STS_4: 1;
        uint32_t PAD_P2_STS_5: 1;
        uint32_t PAD_P2_STS_6: 1;
        uint32_t PAD_P2_STS_7: 1;
        uint32_t PAD_P3_STS_0: 1;
        uint32_t PAD_P3_STS_1: 1;
        uint32_t PAD_P3_STS_2: 1;
        uint32_t PAD_P3_STS_3: 1;
        uint32_t PAD_P3_STS_4: 1;
        uint32_t PAD_P3_STS_5: 1;
        uint32_t PAD_P3_STS_6: 1;
        uint32_t PAD_P3_STS_7: 1;
    };
} AON_NS_PAD_Status_0_TYPE;

/* 0x1AA4   0x4000_1aa4
    0       w1c PAD_P4_STS[0]                   1'b1
    1       w1c PAD_P4_STS[1]                   1'b1
    2       w1c PAD_P4_STS[2]                   1'b1
    3       w1c PAD_P4_STS[3]                   1'b1
    4       w1c PAD_P4_STS[4]                   1'b1
    5       w1c PAD_P4_STS[5]                   1'b1
    6       w1c PAD_P4_STS[6]                   1'b1
    7       w1c PAD_P4_STS[7]                   1'b1
    8       w1c PAD_P5_STS[0]                   1'b1
    9       w1c PAD_P5_STS[1]                   1'b1
    10      w1c PAD_P5_STS[2]                   1'b1
    11      w1c PAD_P5_STS[3]                   1'b1
    12      w1c PAD_P5_STS[4]                   1'b1
    13      w1c PAD_P5_STS[5]                   1'b1
    14      w1c PAD_P5_STS[6]                   1'b1
    15      w1c PAD_P5_STS[7]                   1'b1
    16      w1c PAD_P6_STS[0]                   1'b1
    17      w1c PAD_P6_STS[1]                   1'b1
    18      w1c PAD_P6_STS[2]                   1'b1
    19      w1c PAD_P6_STS[3]                   1'b1
    20      w1c PAD_P6_STS[4]                   1'b1
    21      w1c PAD_P6_STS[5]                   1'b1
    22      w1c PAD_P6_STS[6]                   1'b1
    23      w1c PAD_P6_STS[7]                   1'b1
    24      w1c PAD_P7_STS[0]                   1'b1
    25      w1c PAD_P7_STS[1]                   1'b1
    26      w1c PAD_P7_STS[2]                   1'b1
    27      w1c PAD_P7_STS[3]                   1'b1
    28      w1c PAD_P7_STS[4]                   1'b1
    29      w1c PAD_P7_STS[5]                   1'b1
    30      w1c PAD_P7_STS[6]                   1'b1
    31      w1c PAD_P7_STS[7]                   1'b1
 */
typedef volatile union _AON_NS_PAD_Status_1_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P4_STS_0: 1;
        uint32_t PAD_P4_STS_1: 1;
        uint32_t PAD_P4_STS_2: 1;
        uint32_t PAD_P4_STS_3: 1;
        uint32_t PAD_P4_STS_4: 1;
        uint32_t PAD_P4_STS_5: 1;
        uint32_t PAD_P4_STS_6: 1;
        uint32_t PAD_P4_STS_7: 1;
        uint32_t PAD_P5_STS_0: 1;
        uint32_t PAD_P5_STS_1: 1;
        uint32_t PAD_P5_STS_2: 1;
        uint32_t PAD_P5_STS_3: 1;
        uint32_t PAD_P5_STS_4: 1;
        uint32_t PAD_P5_STS_5: 1;
        uint32_t PAD_P5_STS_6: 1;
        uint32_t PAD_P5_STS_7: 1;
        uint32_t PAD_P6_STS_0: 1;
        uint32_t PAD_P6_STS_1: 1;
        uint32_t PAD_P6_STS_2: 1;
        uint32_t PAD_P6_STS_3: 1;
        uint32_t PAD_P6_STS_4: 1;
        uint32_t PAD_P6_STS_5: 1;
        uint32_t PAD_P6_STS_6: 1;
        uint32_t PAD_P6_STS_7: 1;
        uint32_t PAD_P7_STS_0: 1;
        uint32_t PAD_P7_STS_1: 1;
        uint32_t PAD_P7_STS_2: 1;
        uint32_t PAD_P7_STS_3: 1;
        uint32_t PAD_P7_STS_4: 1;
        uint32_t PAD_P7_STS_5: 1;
        uint32_t PAD_P7_STS_6: 1;
        uint32_t PAD_P7_STS_7: 1;
    };
} AON_NS_PAD_Status_1_TYPE;

/* 0x1AA8   0x4000_1aa8
    0       w1c PAD_P8_STS[0]                   1'b1
    1       w1c PAD_P8_STS[1]                   1'b1
    2       w1c PAD_P8_STS[2]                   1'b1
    3       w1c PAD_P8_STS[3]                   1'b1
    4       w1c PAD_P8_STS[4]                   1'b1
    5       w1c PAD_P8_STS[5]                   1'b1
    6       w1c PAD_P8_STS[6]                   1'b1
    7       w1c PAD_P8_STS[7]                   1'b1
    8       w1c PAD_P9_STS[0]                   1'b1
    9       w1c PAD_P9_STS[1]                   1'b1
    10      w1c PAD_P9_STS[2]                   1'b1
    11      w1c PAD_P9_STS[3]                   1'b1
    12      w1c PAD_P9_STS[4]                   1'b1
    13      w1c PAD_P9_STS[5]                   1'b1
    14      w1c PAD_P9_STS[6]                   1'b1
    15      w1c PAD_P9_STS[7]                   1'b1
    16      w1c PAD_P10_STS[0]                  1'b1
    17      w1c PAD_P10_STS[1]                  1'b1
    18      w1c PAD_P10_STS[2]                  1'b1
    19      w1c PAD_P10_STS[3]                  1'b1
    20      w1c PAD_P10_STS[4]                  1'b1
    21      w1c PAD_P10_STS[5]                  1'b1
    22      w1c PAD_P10_STS[6]                  1'b1
    23      w1c PAD_P10_STS[7]                  1'b1
    24      w1c PAD_P11_STS[0]                  1'b1
    25      w1c PAD_P11_STS[1]                  1'b1
    26      w1c PAD_P11_STS[2]                  1'b1
    27      w1c PAD_P11_STS[3]                  1'b1
    28      w1c PAD_P11_STS[4]                  1'b1
    29      w1c PAD_P11_STS[5]                  1'b1
    30      w1c PAD_P11_STS[6]                  1'b1
    31      w1c PAD_P11_STS[7]                  1'b1
 */
typedef volatile union _AON_NS_PAD_Status_2_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P8_STS_0: 1;
        uint32_t PAD_P8_STS_1: 1;
        uint32_t PAD_P8_STS_2: 1;
        uint32_t PAD_P8_STS_3: 1;
        uint32_t PAD_P8_STS_4: 1;
        uint32_t PAD_P8_STS_5: 1;
        uint32_t PAD_P8_STS_6: 1;
        uint32_t PAD_P8_STS_7: 1;
        uint32_t PAD_P9_STS_0: 1;
        uint32_t PAD_P9_STS_1: 1;
        uint32_t PAD_P9_STS_2: 1;
        uint32_t PAD_P9_STS_3: 1;
        uint32_t PAD_P9_STS_4: 1;
        uint32_t PAD_P9_STS_5: 1;
        uint32_t PAD_P9_STS_6: 1;
        uint32_t PAD_P9_STS_7: 1;
        uint32_t PAD_P10_STS_0: 1;
        uint32_t PAD_P10_STS_1: 1;
        uint32_t PAD_P10_STS_2: 1;
        uint32_t PAD_P10_STS_3: 1;
        uint32_t PAD_P10_STS_4: 1;
        uint32_t PAD_P10_STS_5: 1;
        uint32_t PAD_P10_STS_6: 1;
        uint32_t PAD_P10_STS_7: 1;
        uint32_t PAD_P11_STS_0: 1;
        uint32_t PAD_P11_STS_1: 1;
        uint32_t PAD_P11_STS_2: 1;
        uint32_t PAD_P11_STS_3: 1;
        uint32_t PAD_P11_STS_4: 1;
        uint32_t PAD_P11_STS_5: 1;
        uint32_t PAD_P11_STS_6: 1;
        uint32_t PAD_P11_STS_7: 1;
    };
} AON_NS_PAD_Status_2_TYPE;

/* 0x1AAC   0x4000_1aac
    0       w1c PAD_P12_STS[0]                  1'b1
    1       w1c PAD_P12_STS[1]                  1'b1
    2       w1c PAD_P12_STS[2]                  1'b1
    3       w1c PAD_P12_STS[3]                  1'b1
    4       w1c PAD_P12_STS[4]                  1'b1
    5       w1c PAD_P12_STS[5]                  1'b1
    6       w1c PAD_P12_STS[6]                  1'b1
    7       w1c PAD_P12_STS[7]                  1'b1
    8       w1c PAD_P13_STS[0]                  1'b1
    9       w1c PAD_P13_STS[1]                  1'b1
    10      w1c PAD_P13_STS[2]                  1'b1
    11      w1c PAD_P13_STS[3]                  1'b1
    12      w1c PAD_P13_STS[4]                  1'b1
    13      w1c PAD_P13_STS[5]                  1'b1
    14      w1c PAD_P13_STS[6]                  1'b1
    15      w1c PAD_P13_STS[7]                  1'b1
    16      w1c PAD_P14_STS[0]                  1'b1
    17      w1c PAD_P14_STS[1]                  1'b1
    18      w1c PAD_P14_STS[2]                  1'b1
    19      w1c PAD_P14_STS[3]                  1'b1
    20      w1c PAD_P14_STS[4]                  1'b1
    21      w1c PAD_P14_STS[5]                  1'b1
    22      w1c PAD_P14_STS[6]                  1'b1
    23      w1c PAD_P14_STS[7]                  1'b1
    24      w1c PAD_P15_STS[0]                  1'b1
    25      w1c PAD_P15_STS[1]                  1'b1
    26      w1c PAD_P15_STS[2]                  1'b1
    27      w1c PAD_P15_STS[3]                  1'b1
    28      w1c PAD_P15_STS[4]                  1'b1
    29      w1c PAD_P15_STS[5]                  1'b1
    30      w1c PAD_P15_STS[6]                  1'b1
    31      w1c PAD_P15_STS[7]                  1'b1
 */
typedef volatile union _AON_NS_PAD_Status_3_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P12_STS_0: 1;
        uint32_t PAD_P12_STS_1: 1;
        uint32_t PAD_P12_STS_2: 1;
        uint32_t PAD_P12_STS_3: 1;
        uint32_t PAD_P12_STS_4: 1;
        uint32_t PAD_P12_STS_5: 1;
        uint32_t PAD_P12_STS_6: 1;
        uint32_t PAD_P12_STS_7: 1;
        uint32_t PAD_P13_STS_0: 1;
        uint32_t PAD_P13_STS_1: 1;
        uint32_t PAD_P13_STS_2: 1;
        uint32_t PAD_P13_STS_3: 1;
        uint32_t PAD_P13_STS_4: 1;
        uint32_t PAD_P13_STS_5: 1;
        uint32_t PAD_P13_STS_6: 1;
        uint32_t PAD_P13_STS_7: 1;
        uint32_t PAD_P14_STS_0: 1;
        uint32_t PAD_P14_STS_1: 1;
        uint32_t PAD_P14_STS_2: 1;
        uint32_t PAD_P14_STS_3: 1;
        uint32_t PAD_P14_STS_4: 1;
        uint32_t PAD_P14_STS_5: 1;
        uint32_t PAD_P14_STS_6: 1;
        uint32_t PAD_P14_STS_7: 1;
        uint32_t PAD_P15_STS_0: 1;
        uint32_t PAD_P15_STS_1: 1;
        uint32_t PAD_P15_STS_2: 1;
        uint32_t PAD_P15_STS_3: 1;
        uint32_t PAD_P15_STS_4: 1;
        uint32_t PAD_P15_STS_5: 1;
        uint32_t PAD_P15_STS_6: 1;
        uint32_t PAD_P15_STS_7: 1;
    };
} AON_NS_PAD_Status_3_TYPE;

/* 0x1AB0   0x4000_1ab0
    0       w1c PAD_P16_STS[0]                  1'b1
    1       w1c PAD_P16_STS[1]                  1'b1
    2       w1c PAD_P16_STS[2]                  1'b1
    3       w1c PAD_P16_STS[3]                  1'b1
    4       w1c PAD_P16_STS[4]                  1'b1
    5       w1c PAD_P16_STS[5]                  1'b1
    6       w1c PAD_P16_STS[6]                  1'b1
    7       w1c PAD_P16_STS[7]                  1'b1
    8       w1c PAD_P17_STS[0]                  1'b1
    9       w1c PAD_P17_STS[1]                  1'b1
    10      w1c PAD_P17_STS[2]                  1'b1
    11      w1c PAD_P17_STS[3]                  1'b1
    12      w1c PAD_P17_STS[4]                  1'b1
    13      w1c PAD_P17_STS[5]                  1'b1
    14      w1c PAD_P17_STS[6]                  1'b1
    15      w1c PAD_P17_STS[7]                  1'b1
    16      w1c PAD_P18_STS[0]                  1'b1
    17      w1c PAD_P18_STS[1]                  1'b1
    18      w1c PAD_P18_STS[2]                  1'b1
    19      w1c PAD_P18_STS[3]                  1'b1
    20      w1c PAD_P18_STS[4]                  1'b1
    21      w1c PAD_P18_STS[5]                  1'b1
    22      w1c PAD_P18_STS[6]                  1'b1
    23      w1c PAD_P18_STS[7]                  1'b1
    24      w1c PAD_P19_STS[0]                  1'b1
    25      w1c PAD_P19_STS[1]                  1'b1
    26      w1c PAD_P19_STS[2]                  1'b1
    27      w1c PAD_P19_STS[3]                  1'b1
    28      w1c PAD_P19_STS[4]                  1'b1
    29      w1c PAD_P19_STS[5]                  1'b1
    30      w1c PAD_P19_STS[6]                  1'b1
    31      w1c PAD_P19_STS[7]                  1'b1
 */
typedef volatile union _AON_NS_PAD_Status_4_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_P16_STS_0: 1;
        uint32_t PAD_P16_STS_1: 1;
        uint32_t PAD_P16_STS_2: 1;
        uint32_t PAD_P16_STS_3: 1;
        uint32_t PAD_P16_STS_4: 1;
        uint32_t PAD_P16_STS_5: 1;
        uint32_t PAD_P16_STS_6: 1;
        uint32_t PAD_P16_STS_7: 1;
        uint32_t PAD_P17_STS_0: 1;
        uint32_t PAD_P17_STS_1: 1;
        uint32_t PAD_P17_STS_2: 1;
        uint32_t PAD_P17_STS_3: 1;
        uint32_t PAD_P17_STS_4: 1;
        uint32_t PAD_P17_STS_5: 1;
        uint32_t PAD_P17_STS_6: 1;
        uint32_t PAD_P17_STS_7: 1;
        uint32_t PAD_P18_STS_0: 1;
        uint32_t PAD_P18_STS_1: 1;
        uint32_t PAD_P18_STS_2: 1;
        uint32_t PAD_P18_STS_3: 1;
        uint32_t PAD_P18_STS_4: 1;
        uint32_t PAD_P18_STS_5: 1;
        uint32_t PAD_P18_STS_6: 1;
        uint32_t PAD_P18_STS_7: 1;
        uint32_t PAD_P19_STS_0: 1;
        uint32_t PAD_P19_STS_1: 1;
        uint32_t PAD_P19_STS_2: 1;
        uint32_t PAD_P19_STS_3: 1;
        uint32_t PAD_P19_STS_4: 1;
        uint32_t PAD_P19_STS_5: 1;
        uint32_t PAD_P19_STS_6: 1;
        uint32_t PAD_P19_STS_7: 1;
    };
} AON_NS_PAD_Status_4_TYPE;

/* 0x1AB4   0x4000_1ab4
    5:0     R/W debIO_cnt_div18                 6'h1F
    6       R/W debIO_wakeup_en18               1'b0
    7       W1C PAD_P_debIO_wakeup_STS[18]      1'b1
    15:8    R/W debIO_cnt_lmt18                 8'h0
    21:16   R/W debIO_cnt_div19                 6'h1F
    22      R/W debIO_wakeup_en19               1'b0
    23      W1C PAD_P_debIO_wakeup_STS[19]      1'b1
    31:24   R/W debIO_cnt_lmt19                 8'h0
 */
typedef volatile union _AON_NS_REG_DEBIO_CNT_19_18_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t debIO_cnt_div18: 6;
        uint32_t debIO_wakeup_en18: 1;
        uint32_t PAD_P_debIO_wakeup_STS_18: 1;
        uint32_t debIO_cnt_lmt18: 8;
        uint32_t debIO_cnt_div19: 6;
        uint32_t debIO_wakeup_en19: 1;
        uint32_t PAD_P_debIO_wakeup_STS_19: 1;
        uint32_t debIO_cnt_lmt19: 8;
    };
} AON_NS_REG_DEBIO_CNT_19_18_TYPE;

/* 0x1AB8   0x4000_1ab8
    5:0     R/W debIO_cnt_div16                 6'h1F
    6       R/W debIO_wakeup_en16               1'b0
    7       W1C PAD_P_debIO_wakeup_STS[16]      1'b1
    15:8    R/W debIO_cnt_lmt16                 8'h0
    21:16   R/W debIO_cnt_div17                 6'h1F
    22      R/W debIO_wakeup_en17               1'b0
    23      W1C PAD_P_debIO_wakeup_STS[17]      1'b1
    31:24   R/W debIO_cnt_lmt17                 8'h0
 */
typedef volatile union _AON_NS_REG_DEBIO_CNT_17_16_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t debIO_cnt_div16: 6;
        uint32_t debIO_wakeup_en16: 1;
        uint32_t PAD_P_debIO_wakeup_STS_16: 1;
        uint32_t debIO_cnt_lmt16: 8;
        uint32_t debIO_cnt_div17: 6;
        uint32_t debIO_wakeup_en17: 1;
        uint32_t PAD_P_debIO_wakeup_STS_17: 1;
        uint32_t debIO_cnt_lmt17: 8;
    };
} AON_NS_REG_DEBIO_CNT_17_16_TYPE;

/* 0x1ABC   0x4000_1abc
    5:0     R/W debIO_cnt_div14                 6'h1F
    6       R/W debIO_wakeup_en14               1'b0
    7       W1C PAD_P_debIO_wakeup_STS[14]      1'b1
    15:8    R/W debIO_cnt_lmt14                 8'h0
    21:16   R/W debIO_cnt_div15                 6'h1F
    22      R/W debIO_wakeup_en15               1'b0
    23      W1C PAD_P_debIO_wakeup_STS[15]      1'b1
    31:24   R/W debIO_cnt_lmt15                 8'h0
 */
typedef volatile union _AON_NS_REG_DEBIO_CNT_15_14_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t debIO_cnt_div14: 6;
        uint32_t debIO_wakeup_en14: 1;
        uint32_t PAD_P_debIO_wakeup_STS_14: 1;
        uint32_t debIO_cnt_lmt14: 8;
        uint32_t debIO_cnt_div15: 6;
        uint32_t debIO_wakeup_en15: 1;
        uint32_t PAD_P_debIO_wakeup_STS_15: 1;
        uint32_t debIO_cnt_lmt15: 8;
    };
} AON_NS_REG_DEBIO_CNT_15_14_TYPE;

/* 0x1AC0   0x4000_1ac0
    5:0     R/W debIO_cnt_div12                 6'h1F
    6       R/W debIO_wakeup_en12               1'b0
    7       W1C PAD_P_debIO_wakeup_STS[12]      1'b1
    15:8    R/W debIO_cnt_lmt12                 8'h0
    21:16   R/W debIO_cnt_div13                 6'h1F
    22      R/W debIO_wakeup_en13               1'b0
    23      W1C PAD_P_debIO_wakeup_STS[13]      1'b1
    31:24   R/W debIO_cnt_lmt13                 8'h0
 */
typedef volatile union _AON_NS_REG_DEBIO_CNT_13_12_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t debIO_cnt_div12: 6;
        uint32_t debIO_wakeup_en12: 1;
        uint32_t PAD_P_debIO_wakeup_STS_12: 1;
        uint32_t debIO_cnt_lmt12: 8;
        uint32_t debIO_cnt_div13: 6;
        uint32_t debIO_wakeup_en13: 1;
        uint32_t PAD_P_debIO_wakeup_STS_13: 1;
        uint32_t debIO_cnt_lmt13: 8;
    };
} AON_NS_REG_DEBIO_CNT_13_12_TYPE;

/* 0x1AC4   0x4000_1ac4
    5:0     R/W debIO_cnt_div10                 6'h1F
    6       R/W debIO_wakeup_en10               1'b0
    7       W1C PAD_P_debIO_wakeup_STS[10]      1'b1
    15:8    R/W debIO_cnt_lmt10                 8'h0
    21:16   R/W debIO_cnt_div11                 6'h1F
    22      R/W debIO_wakeup_en11               1'b0
    23      W1C PAD_P_debIO_wakeup_STS[11]      1'b1
    31:24   R/W debIO_cnt_lmt11                 8'h0
 */
typedef volatile union _AON_NS_REG_DEBIO_CNT_11_10_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t debIO_cnt_div10: 6;
        uint32_t debIO_wakeup_en10: 1;
        uint32_t PAD_P_debIO_wakeup_STS_10: 1;
        uint32_t debIO_cnt_lmt10: 8;
        uint32_t debIO_cnt_div11: 6;
        uint32_t debIO_wakeup_en11: 1;
        uint32_t PAD_P_debIO_wakeup_STS_11: 1;
        uint32_t debIO_cnt_lmt11: 8;
    };
} AON_NS_REG_DEBIO_CNT_11_10_TYPE;

/* 0x1AC8   0x4000_1ac8
    5:0     R/W debIO_cnt_div8                  6'h1F
    6       R/W debIO_wakeup_en8                1'b0
    7       W1C PAD_P_debIO_wakeup_STS[8]       1'b1
    15:8    R/W debIO_cnt_lmt8                  8'h0
    21:16   R/W debIO_cnt_div9                  6'h1F
    22      R/W debIO_wakeup_en9                1'b0
    23      W1C PAD_P_debIO_wakeup_STS[9]       1'b1
    31:24   R/W debIO_cnt_lmt9                  8'h0
 */
typedef volatile union _AON_NS_REG_DEBIO_CNT_09_08_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t debIO_cnt_div8: 6;
        uint32_t debIO_wakeup_en8: 1;
        uint32_t PAD_P_debIO_wakeup_STS_8: 1;
        uint32_t debIO_cnt_lmt8: 8;
        uint32_t debIO_cnt_div9: 6;
        uint32_t debIO_wakeup_en9: 1;
        uint32_t PAD_P_debIO_wakeup_STS_9: 1;
        uint32_t debIO_cnt_lmt9: 8;
    };
} AON_NS_REG_DEBIO_CNT_09_08_TYPE;

/* 0x1ACC   0x4000_1acc
    5:0     R/W debIO_cnt_div6                  6'h1F
    6       R/W debIO_wakeup_en6                1'b0
    7       W1C PAD_P_debIO_wakeup_STS[6]       1'b1
    15:8    R/W debIO_cnt_lmt6                  8'h0
    21:16   R/W debIO_cnt_div7                  6'h1F
    22      R/W debIO_wakeup_en7                1'b0
    23      W1C PAD_P_debIO_wakeup_STS[7]       1'b1
    31:24   R/W debIO_cnt_lmt7                  8'h0
 */
typedef volatile union _AON_NS_REG_DEBIO_CNT_07_06_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t debIO_cnt_div6: 6;
        uint32_t debIO_wakeup_en6: 1;
        uint32_t PAD_P_debIO_wakeup_STS_6: 1;
        uint32_t debIO_cnt_lmt6: 8;
        uint32_t debIO_cnt_div7: 6;
        uint32_t debIO_wakeup_en7: 1;
        uint32_t PAD_P_debIO_wakeup_STS_7: 1;
        uint32_t debIO_cnt_lmt7: 8;
    };
} AON_NS_REG_DEBIO_CNT_07_06_TYPE;

/* 0x1AD0   0x4000_1ad0
    5:0     R/W debIO_cnt_div4                  6'h1F
    6       R/W debIO_wakeup_en4                1'b0
    7       W1C PAD_P_debIO_wakeup_STS[4]       1'b1
    15:8    R/W debIO_cnt_lmt4                  8'h0
    21:16   R/W debIO_cnt_div5                  6'h1F
    22      R/W debIO_wakeup_en5                1'b0
    23      W1C PAD_P_debIO_wakeup_STS[5]       1'b1
    31:24   R/W debIO_cnt_lmt5                  8'h0
 */
typedef volatile union _AON_NS_REG_DEBIO_CNT_05_04_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t debIO_cnt_div4: 6;
        uint32_t debIO_wakeup_en4: 1;
        uint32_t PAD_P_debIO_wakeup_STS_4: 1;
        uint32_t debIO_cnt_lmt4: 8;
        uint32_t debIO_cnt_div5: 6;
        uint32_t debIO_wakeup_en5: 1;
        uint32_t PAD_P_debIO_wakeup_STS_5: 1;
        uint32_t debIO_cnt_lmt5: 8;
    };
} AON_NS_REG_DEBIO_CNT_05_04_TYPE;

/* 0x1AD4   0x4000_1ad4
    5:0     R/W debIO_cnt_div2                  6'h1F
    6       R/W debIO_wakeup_en2                1'b0
    7       W1C PAD_P_debIO_wakeup_STS[2]       1'b1
    15:8    R/W debIO_cnt_lmt2                  8'h0
    21:16   R/W debIO_cnt_div3                  6'h1F
    22      R/W debIO_wakeup_en3                1'b0
    23      W1C PAD_P_debIO_wakeup_STS[3]       1'b1
    31:24   R/W debIO_cnt_lmt3                  8'h0
 */
typedef volatile union _AON_NS_REG_DEBIO_CNT_03_02_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t debIO_cnt_div2: 6;
        uint32_t debIO_wakeup_en2: 1;
        uint32_t PAD_P_debIO_wakeup_STS_2: 1;
        uint32_t debIO_cnt_lmt2: 8;
        uint32_t debIO_cnt_div3: 6;
        uint32_t debIO_wakeup_en3: 1;
        uint32_t PAD_P_debIO_wakeup_STS_3: 1;
        uint32_t debIO_cnt_lmt3: 8;
    };
} AON_NS_REG_DEBIO_CNT_03_02_TYPE;

/* 0x1AD8   0x4000_1ad8
    5:0     R/W debIO_cnt_div0                  6'h1F
    6       R/W debIO_wakeup_en0                1'b0
    7       W1C PAD_P_debIO_wakeup_STS[0]       1'b1
    15:8    R/W debIO_cnt_lmt0                  8'h0
    21:16   R/W debIO_cnt_div1                  6'h1F
    22      R/W debIO_wakeup_en1                1'b0
    23      W1C PAD_P_debIO_wakeup_STS[1]       1'b1
    31:24   R/W debIO_cnt_lmt1                  8'h0
 */
typedef volatile union _AON_NS_REG_DEBIO_CNT_01_00_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t debIO_cnt_div0: 6;
        uint32_t debIO_wakeup_en0: 1;
        uint32_t PAD_P_debIO_wakeup_STS_0: 1;
        uint32_t debIO_cnt_lmt0: 8;
        uint32_t debIO_cnt_div1: 6;
        uint32_t debIO_wakeup_en1: 1;
        uint32_t PAD_P_debIO_wakeup_STS_1: 1;
        uint32_t debIO_cnt_lmt1: 8;
    };
} AON_NS_REG_DEBIO_CNT_01_00_TYPE;

/* 0x1ADC   0x4000_1adc
    0       w1c PAD_MIC1_N_STS                  1'b1
    1       w1c PAD_MIC1_P_STS                  1'b1
    2       w1c PAD_MIC2_N_STS                  1'b1
    3       w1c PAD_MIC2_P_STS                  1'b1
    4       w1c PAD_MIC3_N_STS                  1'b1
    5       w1c PAD_MIC3_P_STS                  1'b1
    6       w1c PAD_DAC1_N_STS                  1'b1
    7       w1c PAD_DAC1_P_STS                  1'b1
    8       w1c PAD_DAC2_N_STS                  1'b1
    9       w1c PAD_DAC2_P_STS                  1'b1
    10      w1c PAD_P20_STS[0]                  1'b1
    11      w1c PAD_P20_STS[1]                  1'b1
    12      w1c PAD_P20_STS[2]                  1'b1
    13      w1c PAD_P20_STS[3]                  1'b1
    14      w1c PAD_P20_STS[4]                  1'b1
    15      w1c PAD_P20_STS[5]                  1'b1
    16      w1c PAD_P20_STS[6]                  1'b1
    17      w1c PAD_P20_STS[7]                  1'b1
    18      w1c PAD_STS_DUMMY0[8]               1'b1
    19      w1c PAD_STS_DUMMY0[9]               1'b1
    20      w1c PAD_STS_DUMMY0[10]              1'b1
    21      w1c PAD_STS_DUMMY0[11]              1'b1
    22      w1c PAD_STS_DUMMY0[12]              1'b1
    23      w1c PAD_STS_DUMMY0[13]              1'b1
    24      w1c PAD_STS_DUMMY0[14]              1'b1
    25      w1c PAD_STS_DUMMY0[15]              1'b1
    26      w1c PAD_STS_DUMMY0[16]              1'b1
    27      w1c PAD_STS_DUMMY0[17]              1'b1
    28      w1c PAD_STS_DUMMY0[18]              1'b1
    29      w1c PAD_STS_DUMMY0[19]              1'b1
    30      w1c PAD_STS_DUMMY0[20]              1'b1
    31      w1c PAD_STS_DUMMY0[21]              1'b1
 */
typedef volatile union _AON_NS_PAD_Status_5_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PAD_MIC1_N_STS: 1;
        uint32_t PAD_MIC1_P_STS: 1;
        uint32_t PAD_MIC2_N_STS: 1;
        uint32_t PAD_MIC2_P_STS: 1;
        uint32_t PAD_MIC3_N_STS: 1;
        uint32_t PAD_MIC3_P_STS: 1;
        uint32_t PAD_DAC1_N_STS: 1;
        uint32_t PAD_DAC1_P_STS: 1;
        uint32_t PAD_DAC2_N_STS: 1;
        uint32_t PAD_DAC2_P_STS: 1;
        uint32_t PAD_P20_STS_0: 1;
        uint32_t PAD_P20_STS_1: 1;
        uint32_t PAD_P20_STS_2: 1;
        uint32_t PAD_P20_STS_3: 1;
        uint32_t PAD_P20_STS_4: 1;
        uint32_t PAD_P20_STS_5: 1;
        uint32_t PAD_P20_STS_6: 1;
        uint32_t PAD_P20_STS_7: 1;
        uint32_t PAD_STS_DUMMY0_8: 1;
        uint32_t PAD_STS_DUMMY0_9: 1;
        uint32_t PAD_STS_DUMMY0_10: 1;
        uint32_t PAD_STS_DUMMY0_11: 1;
        uint32_t PAD_STS_DUMMY0_12: 1;
        uint32_t PAD_STS_DUMMY0_13: 1;
        uint32_t PAD_STS_DUMMY0_14: 1;
        uint32_t PAD_STS_DUMMY0_15: 1;
        uint32_t PAD_STS_DUMMY0_16: 1;
        uint32_t PAD_STS_DUMMY0_17: 1;
        uint32_t PAD_STS_DUMMY0_18: 1;
        uint32_t PAD_STS_DUMMY0_19: 1;
        uint32_t PAD_STS_DUMMY0_20: 1;
        uint32_t PAD_STS_DUMMY0_21: 1;
    };
} AON_NS_PAD_Status_5_TYPE;

/* 0x1AE0   0x4000_1ae0
    31:0    R/W FW_APP_0X                       32'h0
 */
typedef volatile union _AON_NS_REG0X_APP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_APP_0X;
    };
} AON_NS_REG0X_APP_TYPE;

/* 0x1AE4   0x4000_1ae4
    31:0    R/W FW_APP_1X                       32'h0
 */
typedef volatile union _AON_NS_REG1X_APP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_APP_1X;
    };
} AON_NS_REG1X_APP_TYPE;

/* 0x1AE8   0x4000_1ae8
    31:0    R/W FW_APP_2X                       32'h0
 */
typedef volatile union _AON_NS_REG2X_APP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_APP_2X;
    };
} AON_NS_REG2X_APP_TYPE;

/* 0x1AEC   0x4000_1aec
    31:0    R/W FW_APP_3X                       32'h0
 */
typedef volatile union _AON_NS_REG3X_APP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_APP_3X;
    };
} AON_NS_REG3X_APP_TYPE;

/* 0x1AF0   0x4000_1af0
    31:0    R/W FW_APP_4X                       32'h0
 */
typedef volatile union _AON_NS_REG4X_APP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_APP_4X;
    };
} AON_NS_REG4X_APP_TYPE;

/* 0x1AF4   0x4000_1af4
    31:0    R/W FW_APP_5X                       32'h0
 */
typedef volatile union _AON_NS_REG5X_APP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_APP_5X;
    };
} AON_NS_REG5X_APP_TYPE;

/* 0x1AF8   0x4000_1af8
    31:0    R/W FW_APP_6X                       32'h0
 */
typedef volatile union _AON_NS_REG6X_APP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_APP_6X;
    };
} AON_NS_REG6X_APP_TYPE;

/* 0x1AFC   0x4000_1afc
    31:0    R/W FW_APP_7X                       32'h0
 */
typedef volatile union _AON_NS_REG7X_APP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_APP_7X;
    };
} AON_NS_REG7X_APP_TYPE;

/* 0x1B00   0x4000_1b00
    31:0    R/W FW_APP_8X                       32'h0
 */
typedef volatile union _AON_NS_REG8X_APP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_APP_8X;
    };
} AON_NS_REG8X_APP_TYPE;

/* 0x1B04   0x4000_1b04
    31:0    R/W FW_APP_9X                       32'h0
 */
typedef volatile union _AON_NS_REG9X_APP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_APP_9X;
    };
} AON_NS_REG9X_APP_TYPE;

/* 0x1B08   0x4000_1b08
    31:0    R/W FW_APP_10X                      32'h0
 */
typedef volatile union _AON_NS_REG10X_APP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_APP_10X;
    };
} AON_NS_REG10X_APP_TYPE;

/* 0x1B0C   0x4000_1b0c
    31:0    R/W FW_APP_11X                      32'h0
 */
typedef volatile union _AON_NS_REG11X_APP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_APP_11X;
    };
} AON_NS_REG11X_APP_TYPE;

/* 0x1B10   0x4000_1b10
    31:0    R/W FW_APP_12X                      32'h0
 */
typedef volatile union _AON_NS_REG12X_APP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_APP_12X;
    };
} AON_NS_REG12X_APP_TYPE;

/* 0x1B14   0x4000_1b14
    31:0    R/W FW_APP_13X                      32'h0
 */
typedef volatile union _AON_NS_REG13X_APP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_APP_13X;
    };
} AON_NS_REG13X_APP_TYPE;

/* 0x1B18   0x4000_1b18
    31:0    R/W FW_APP_14X                      32'h0
 */
typedef volatile union _AON_NS_REG14X_APP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_APP_14X;
    };
} AON_NS_REG14X_APP_TYPE;

/* 0x1B1C   0x4000_1b1c
    31:0    R/W FW_APP_15X                      32'h0
 */
typedef volatile union _AON_NS_REG15X_APP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_APP_15X;
    };
} AON_NS_REG15X_APP_TYPE;

/* 0x1B60   0x4000_1b60
    15:0    R/W AON_WDG_WP                      16'h0
    31:16   R/W RSVD                            16'h0
 */
typedef volatile union _AON_NS_AON_WDG_WP0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t AON_WDG_WP: 16;
        uint32_t RSVD: 16;
    };
} AON_NS_AON_WDG_WP0_TYPE;

/* 0x1B64   0x4000_1b64
    15:0    R/W AON_WDG_CLK_DIV_FACTOR          16'hC80
    27:16   R/W AON_WDG_CNT_LIMIT               12'h6E
    28      R/W AON_WDG_MODE                    1'b0
    29      R/W AON_WDG_CNT_CTL                 1'b0
    30      R/W AON_WDG_CNT_RELOAD              1'b0
    31      R/W AON_WDG_ENABLE                  1'b0
 */
typedef volatile union _AON_NS_AON_WDG_CONFIG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t AON_WDG_CLK_DIV_FACTOR: 16;
        uint32_t AON_WDG_CNT_LIMIT: 12;
        uint32_t AON_WDG_MODE: 1;
        uint32_t AON_WDG_CNT_CTL: 1;
        uint32_t AON_WDG_CNT_RELOAD: 1;
        uint32_t AON_WDG_ENABLE: 1;
    };
} AON_NS_AON_WDG_CONFIG_TYPE;

/* 0x1B68   0x4000_1b68
    15:0    R/WACAON_WDG_CNT_RESET               16'h0
    31:16   R/WACRSVD                            16'h0
 */
typedef volatile union _AON_NS_AON_WDG_CNT_RESET0_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t AON_WDG_CNT_RESET: 16;
        uint32_t RSVD: 16;
    };
} AON_NS_AON_WDG_CNT_RESET0_TYPE;

/* 0x1B6C   0x4000_1b6c
    0       R/W AON_WDG_WP_SEC                  1'b0
    1       R/W AON_WDG_CONFIG_SEC              1'b0
    2       R/W AON_WDG_RESET_SEC               1'b0
    31:3    R/W RSVD                            29'b0
 */
typedef volatile union _AON_NS_AON_WDG_SEC_CTL_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t AON_WDG_WP_SEC: 1;
        uint32_t AON_WDG_CONFIG_SEC: 1;
        uint32_t AON_WDG_RESET_SEC: 1;
        uint32_t RSVD: 29;
    };
} AON_NS_AON_WDG_SEC_CTL_TYPE;

/* 0x1B90   0x4000_1b90
    0       R/W AUXADC_POW_ADC                  1'b0
    1       R/W AUXADC_POW_REF                  1'b0
    2       R/W AUXADC_SEL_CLK                  1'b0
    3       R/W REG0X_AUXADC_DUMMY0             1'b0
    5:4     R/W AUXADC_SEL_VREF                 2'b01
    6       R/W AUXADC_CK_DATA_REVERSE          1'b0
    8:7     R/W AUXADC_SEL_CMPDEC               2'b00
    9       R/W AUXADC_EN_META                  1'b0
    10      R/W AUXADC_EN_LN                    1'b1
    11      R/W AUXADC_EN_LNA                   1'b1
    13:12   R/W AUXADC_VCM_SEL                  2'b11
    15:14   R/W REG0X_AUXADC_DUMMY1             2'b00
    23:16   R/W AUXADC_EN_BYPASS_MODE[7:0]      8'b11111111
    24      R/W AUXADC_EN_TG                    1'b0
    26:25   R/W AUXADC_SEL_LDO08_REF            2'b01
    27      R/W AUXADC_EN_LDO_VPULSE            1'b0
    28      R/W AUXADC_SEL_LDO_MODE             1'b1
    29      R/W REG1X_AUXADC_DUMMY2             1'b0
    30      R/W AUXADC_LDO_dummy_load           1'b0
    31      R/W REG1X_AUXADC_DUMMY3             1'b0
 */
typedef volatile union _AON_NS_REG0X_AUXADC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t AUXADC_POW_ADC: 1;
        uint32_t AUXADC_POW_REF: 1;
        uint32_t AUXADC_SEL_CLK: 1;
        uint32_t REG0X_AUXADC_DUMMY0: 1;
        uint32_t AUXADC_SEL_VREF: 2;
        uint32_t AUXADC_CK_DATA_REVERSE: 1;
        uint32_t AUXADC_SEL_CMPDEC: 2;
        uint32_t AUXADC_EN_META: 1;
        uint32_t AUXADC_EN_LN: 1;
        uint32_t AUXADC_EN_LNA: 1;
        uint32_t AUXADC_VCM_SEL: 2;
        uint32_t REG0X_AUXADC_DUMMY1: 2;
        uint32_t AUXADC_EN_BYPASS_MODE_7_0: 8;
        uint32_t AUXADC_EN_TG: 1;
        uint32_t AUXADC_SEL_LDO08_REF: 2;
        uint32_t AUXADC_EN_LDO_VPULSE: 1;
        uint32_t AUXADC_SEL_LDO_MODE: 1;
        uint32_t REG1X_AUXADC_DUMMY2: 1;
        uint32_t AUXADC_LDO_dummy_load: 1;
        uint32_t REG1X_AUXADC_DUMMY3: 1;
    };
} AON_NS_REG0X_AUXADC_TYPE;

/* 0x1B94   0x4000_1b94
    0       R/W AUXADC_EN_LDO33_PC              1'b0
    2:1     R/W AUXADC_SEL_LDO33_REF            2'b10
    3       R/W AUXADC_EN_LDO08_PC              1'b0
    4       R/W AUXADC_POW_SD1                  1'b0
    5       R/W AUXADC_EN_SD1_POSEDGE           1'b1
    8:6     R/W AUXADC_SEL_SD1_CH               3'b111
    9       R/W AUXADC_POW_SD2                  1'b0
    10      R/W AUXADC_EN_SD2_POSEDGE           1'b1
    13:11   R/W AUXADC_SEL_SD2_CH               3'b111
    14      R/W AUXADC_LPC_DIV1                 1'b1
    15      R/W AUXADC_LPC_DIV2                 1'b1
    23:16   R/W AUXADC_EN_BYPASS_MODE[15:8]     8'b11111111
    24      R/W POWER_CUT_DVDD_ALON             1'b0
    31:25   R/W REG2X_AUXADC_DUMMY0             7'b0
 */
typedef volatile union _AON_NS_REG2X_AUXADC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t AUXADC_EN_LDO33_PC: 1;
        uint32_t AUXADC_SEL_LDO33_REF: 2;
        uint32_t AUXADC_EN_LDO08_PC: 1;
        uint32_t AUXADC_POW_SD1: 1;
        uint32_t AUXADC_EN_SD1_POSEDGE: 1;
        uint32_t AUXADC_SEL_SD1_CH: 3;
        uint32_t AUXADC_POW_SD2: 1;
        uint32_t AUXADC_EN_SD2_POSEDGE: 1;
        uint32_t AUXADC_SEL_SD2_CH: 3;
        uint32_t AUXADC_LPC_DIV1: 1;
        uint32_t AUXADC_LPC_DIV2: 1;
        uint32_t AUXADC_EN_BYPASS_MODE_15_8: 8;
        uint32_t POWER_CUT_DVDD_ALON: 1;
        uint32_t REG2X_AUXADC_DUMMY0: 7;
    };
} AON_NS_REG2X_AUXADC_TYPE;

/* 0x1B98   0x4000_1b98
    15:0    R   I<15:0>                         16'b0
    31:16   R   E2<15:0>                        16'b0
 */
typedef volatile union _AON_NS_REG4X_AUXADC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t I_15_0: 16;
        uint32_t E2_15_0: 16;
    };
} AON_NS_REG4X_AUXADC_TYPE;

/* 0x1B9C   0x4000_1b9c
    15:0    R   E<15:0>                         16'b0
    31:16   R   PD<15:0>                        16'hffff
 */
typedef volatile union _AON_NS_REG6X_AUXADC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t E_15_0: 16;
        uint32_t PD_15_0: 16;
    };
} AON_NS_REG6X_AUXADC_TYPE;

/* 0x1BA0   0x4000_1ba0
    15:0    R   PU<15:0>                        16'b0
    31:16   R   SHDN<15:0>                      16'hffff
 */
typedef volatile union _AON_NS_REG8X_AUXADC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t PU_15_0: 16;
        uint32_t SHDN_15_0: 16;
    };
} AON_NS_REG8X_AUXADC_TYPE;

/* 0x1BA4   0x4000_1ba4
    15:0    R   SMT<15:0>                       16'hffff
    31:16   R   PUPDC<15:0>                     16'b0
 */
typedef volatile union _AON_NS_REG10X_AUXADC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t SMT_15_0: 16;
        uint32_t PUPDC_15_0: 16;
    };
} AON_NS_REG10X_AUXADC_TYPE;

/* 0x1BA8   0x4000_1ba8
    15:0    R   E3<15:0>                        16'b0
    31:16   R   H3L1<15:0>                      16'hffff
 */
typedef volatile union _AON_NS_REG12X_AUXADC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t E3_15_0: 16;
        uint32_t H3L1_15_0: 16;
    };
} AON_NS_REG12X_AUXADC_TYPE;

/* 0x1BD0   0x4000_1bd0
    1:0     R/W X_INITIAL_PHASE                 2'b0
    2       R/W X_SET_INITAL_PHASE              1'b0
    3       R/W X_CNT_PAUSE                     1'b0
    4       R/W X_CNT_SCALE                     1'b0
    5       R/W X_ILLEGAL_INT_EN                1'b0
    6       R/W X_CNT_INT_EN                    1'b0
    7       R/W ILLEGAL_INT_MASK                1'b1
    8       R/W CNT_INT_MASK                    1'b1
    16:9    R/W X_DEBOUNCE_CNT                  8'b0
    21:17   R/W REG_CONFIG_DUMMY                5'b0
    22      R/W X_DEBOUNCE_EN                   1'b0
    23      R/W X_WAKE_AON_MASK                 1'b1
    24      R/W X_INT_MASK                      1'b1
    28:25   R/W REG_CONFIG_DUMMY1               4'b0
    29      R/W X_RST                           1'b0
    30      R/WACX_FSM_EN                        1'b0
    31      R/W X_AXIS_EN                       1'b0
 */
typedef volatile union _AON_NS_REG_CONFIG_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t X_INITIAL_PHASE: 2;
        uint32_t X_SET_INITAL_PHASE: 1;
        uint32_t X_CNT_PAUSE: 1;
        uint32_t X_CNT_SCALE: 1;
        uint32_t X_ILLEGAL_INT_EN: 1;
        uint32_t X_CNT_INT_EN: 1;
        uint32_t ILLEGAL_INT_MASK: 1;
        uint32_t CNT_INT_MASK: 1;
        uint32_t X_DEBOUNCE_CNT: 8;
        uint32_t REG_CONFIG_DUMMY: 5;
        uint32_t X_DEBOUNCE_EN: 1;
        uint32_t X_WAKE_AON_MASK: 1;
        uint32_t X_INT_MASK: 1;
        uint32_t REG_CONFIG_DUMMY1: 4;
        uint32_t X_RST: 1;
        uint32_t X_FSM_EN: 1;
        uint32_t X_AXIS_EN: 1;
    };
} AON_NS_REG_CONFIG_TYPE;

/* 0x1BD4   0x4000_1bd4
    15:0    R   ACC_CNT                         1'b0
    16      R/W1CCNT_OF_FLG                      1'b0
    17      R/W1CCNT_UF_FLG                      1'b0
    18      R/W1CCNT_INT_STA                     1'b0
    19      R/W1CILLEGAL_INT_STA                 1'b0
    20      R   CNT_DIR                         1'b0
    21      R/W REG_SR_X_DUMMY                  1'b0
    23:22   R   debug_state_x                   1'b0
    31:24   R   debug_illegal_counter_x         1'b0
 */
typedef volatile union _AON_NS_REG_SR_X_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t ACC_CNT: 16;
        uint32_t CNT_OF_FLG: 1;
        uint32_t CNT_UF_FLG: 1;
        uint32_t CNT_INT_STA: 1;
        uint32_t ILLEGAL_INT_STA: 1;
        uint32_t CNT_DIR: 1;
        uint32_t REG_SR_X_DUMMY: 1;
        uint32_t debug_state_x: 2;
        uint32_t debug_illegal_counter_x: 8;
    };
} AON_NS_REG_SR_X_TYPE;

/* 0x1BD8   0x4000_1bd8
    0       R/WACACC_CNT_CLR                     1'b0
    1       R/WACCNT_INT_CLR                     1'b0
    2       R/WACOF_FLG_CLR                      1'b0
    3       R/WACUF_FLG_CLR                      1'b0
    4       R/WACILLEGAL_INT_CLR                 1'b0
    5       R/WACILLEGAL_CNT_CLR                 1'b0
    31:6    R/W INT_CLR_DUMMY                   26'b0
 */
typedef volatile union _AON_NS_INT_CLR_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t ACC_CNT_CLR: 1;
        uint32_t CNT_INT_CLR: 1;
        uint32_t OF_FLG_CLR: 1;
        uint32_t UF_FLG_CLR: 1;
        uint32_t ILLEGAL_INT_CLR: 1;
        uint32_t ILLEGAL_CNT_CLR: 1;
        uint32_t INT_CLR_DUMMY: 26;
    };
} AON_NS_INT_CLR_TYPE;

/* 0x1C00   0x4000_1c00
    31:0    R   r_km4_core_wdt_lat_km4_pc_value 32'b0
 */
typedef volatile union _AON_NS_REG30_CORE_KM4_PC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_core_wdt_lat_km4_pc_value;
    };
} AON_NS_REG30_CORE_KM4_PC_TYPE;

/* 0x1C04   0x4000_1c04
    31:0    R   r_km4_core_wdt_lat_km4_lr       32'b0
 */
typedef volatile union _AON_NS_REG34_CORE_KM4_LR_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_core_wdt_lat_km4_lr;
    };
} AON_NS_REG34_CORE_KM4_LR_TYPE;

/* 0x1C08   0x4000_1c08
    31:0    R   r_km4_core_wdt_lat_km4_pc_ex    32'b0
 */
typedef volatile union _AON_NS_REG38_CORE_KM4_PC_EX_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_core_wdt_lat_km4_pc_ex;
    };
} AON_NS_REG38_CORE_KM4_PC_EX_TYPE;

/* 0x1C0C   0x4000_1c0c
    31:0    R   r_km4_core_wdt_lat_km4_xpsr_r   32'b0
 */
typedef volatile union _AON_NS_REG3C_CORE_KM4_XPSR_R_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_core_wdt_lat_km4_xpsr_r;
    };
} AON_NS_REG3C_CORE_KM4_XPSR_R_TYPE;

/* 0x1C10   0x4000_1c10
    31:0    R   r_km4_core_wdt_lat_km4_msp_s    32'b0
 */
typedef volatile union _AON_NS_REG40_CORE_KM4_MSP_S_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_core_wdt_lat_km4_msp_s;
    };
} AON_NS_REG40_CORE_KM4_MSP_S_TYPE;

/* 0x1C14   0x4000_1c14
    31:0    R   r_km4_core_wdt_lat_km4_psp_s    32'b0
 */
typedef volatile union _AON_NS_REG44_CORE_KM4_PSP_S_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_core_wdt_lat_km4_psp_s;
    };
} AON_NS_REG44_CORE_KM4_PSP_S_TYPE;

/* 0x1C18   0x4000_1c18
    31:0    R   r_km4_core_wdt_lat_km4_msp_ns   32'b0
 */
typedef volatile union _AON_NS_REG48_CORE_KM4_MSP_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_core_wdt_lat_km4_msp_ns;
    };
} AON_NS_REG48_CORE_KM4_MSP_NS_TYPE;

/* 0x1C1C   0x4000_1c1c
    31:0    R   r_km4_core_wdt_lat_km4_psp_ns   32'b0
 */
typedef volatile union _AON_NS_REG4C_CORE_KM4_PSP_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_core_wdt_lat_km4_psp_ns;
    };
} AON_NS_REG4C_CORE_KM4_PSP_NS_TYPE;

/* 0x1C20   0x4000_1c20
    31:0    R   r_km4_aon_wdt_lat_km4_pc_value  32'b0
 */
typedef volatile union _AON_NS_REG50_AON_KM4_PC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_aon_wdt_lat_km4_pc_value;
    };
} AON_NS_REG50_AON_KM4_PC_TYPE;

/* 0x1C24   0x4000_1c24
    31:0    R   r_km4_aon_wdt_lat_km4_lr        32'b0
 */
typedef volatile union _AON_NS_REG54_AON_KM4_LR_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_aon_wdt_lat_km4_lr;
    };
} AON_NS_REG54_AON_KM4_LR_TYPE;

/* 0x1C28   0x4000_1c28
    31:0    R   r_km4_aon_wdt_lat_km4_pc_ex     32'b0
 */
typedef volatile union _AON_NS_REG58_AON_KM4_PC_EX_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_aon_wdt_lat_km4_pc_ex;
    };
} AON_NS_REG58_AON_KM4_PC_EX_TYPE;

/* 0x1C2C   0x4000_1c2c
    31:0    R   r_km4_aon_wdt_lat_km4_xpsr_r    32'b0
 */
typedef volatile union _AON_NS_REG5C_AON_KM4_XPSR_R_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_aon_wdt_lat_km4_xpsr_r;
    };
} AON_NS_REG5C_AON_KM4_XPSR_R_TYPE;

/* 0x1C30   0x4000_1c30
    31:0    R   r_km4_aon_wdt_lat_km4_msp_s     32'b0
 */
typedef volatile union _AON_NS_REG60_AON_KM4_MSP_S_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_aon_wdt_lat_km4_msp_s;
    };
} AON_NS_REG60_AON_KM4_MSP_S_TYPE;

/* 0x1C34   0x4000_1c34
    31:0    R   r_km4_aon_wdt_lat_km4_psp_s     32'b0
 */
typedef volatile union _AON_NS_REG64_AON_KM4_PSP_S_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_aon_wdt_lat_km4_psp_s;
    };
} AON_NS_REG64_AON_KM4_PSP_S_TYPE;

/* 0x1C38   0x4000_1c38
    31:0    R   r_km4_aon_wdt_lat_km4_msp_ns    32'b0
 */
typedef volatile union _AON_NS_REG68_AON_KM4_MSP_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_aon_wdt_lat_km4_msp_ns;
    };
} AON_NS_REG68_AON_KM4_MSP_NS_TYPE;

/* 0x1C3C   0x4000_1c3c
    31:0    R   r_km4_aon_wdt_lat_km4_psp_ns    32'b0
 */
typedef volatile union _AON_NS_REG6C_AON_KM4_PSP_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_aon_wdt_lat_km4_psp_ns;
    };
} AON_NS_REG6C_AON_KM4_PSP_NS_TYPE;

/* 0x1C40   0x4000_1c40
    31:0    R   r_kr0_aon_wdt_lat_km4_pc_value  32'b0
 */
typedef volatile union _AON_NS_REG70_KR0_WDT_KM4_PC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_aon_wdt_lat_km4_pc_value;
    };
} AON_NS_REG70_KR0_WDT_KM4_PC_TYPE;

/* 0x1C44   0x4000_1c44
    31:0    R   r_kr0_aon_wdt_lat_km4_lr        32'b0
 */
typedef volatile union _AON_NS_REG74_KR0_WDT_KM4_LR_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_aon_wdt_lat_km4_lr;
    };
} AON_NS_REG74_KR0_WDT_KM4_LR_TYPE;

/* 0x1C48   0x4000_1c48
    31:0    R   r_kr0_aon_wdt_lat_km4_pc_ex     32'b0
 */
typedef volatile union _AON_NS_REG78_KR0_WDT_KM4_PC_EX_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_aon_wdt_lat_km4_pc_ex;
    };
} AON_NS_REG78_KR0_WDT_KM4_PC_EX_TYPE;

/* 0x1C4C   0x4000_1c4c
    31:0    R   r_kr0_aon_wdt_lat_km4_xpsr_r    32'b0
 */
typedef volatile union _AON_NS_REG7C_KR0_WDT_KM4_XPSR_R_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_aon_wdt_lat_km4_xpsr_r;
    };
} AON_NS_REG7C_KR0_WDT_KM4_XPSR_R_TYPE;

/* 0x1C50   0x4000_1c50
    31:0    R   r_kr0_aon_wdt_lat_km4_msp_s     32'b0
 */
typedef volatile union _AON_NS_REG80_KR0_WDT_KM4_MSP_S_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_aon_wdt_lat_km4_msp_s;
    };
} AON_NS_REG80_KR0_WDT_KM4_MSP_S_TYPE;

/* 0x1C54   0x4000_1c54
    31:0    R   r_kr0_aon_wdt_lat_km4_psp_s     32'b0
 */
typedef volatile union _AON_NS_REG84_KR0_WDT_KM4_PSP_S_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_aon_wdt_lat_km4_psp_s;
    };
} AON_NS_REG84_KR0_WDT_KM4_PSP_S_TYPE;

/* 0x1C58   0x4000_1c58
    31:0    R   r_kr0_aon_wdt_lat_km4_msp_ns    32'b0
 */
typedef volatile union _AON_NS_REG88_KR0_WDT_KM4_MSP_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_aon_wdt_lat_km4_msp_ns;
    };
} AON_NS_REG88_KR0_WDT_KM4_MSP_NS_TYPE;

/* 0x1C5C   0x4000_1c5c
    31:0    R   r_kr0_aon_wdt_lat_km4_psp_ns    32'b0
 */
typedef volatile union _AON_NS_REG8C_KR0_WDT_KM4_PSP_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_aon_wdt_lat_km4_psp_ns;
    };
} AON_NS_REG8C_KR0_WDT_KM4_PSP_NS_TYPE;

/* 0x1C60   0x4000_1c60
    31:0    R   r_kr0_wdt_lat_kr0_pc_value      32'b0
 */
typedef volatile union _AON_NS_REG90_KR0_WDT_KR0_PC_VALUE_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_wdt_lat_kr0_pc_value;
    };
} AON_NS_REG90_KR0_WDT_KR0_PC_VALUE_TYPE;

/* 0x1C64   0x4000_1c64
    31:0    R   r_kr0_wdt_lat_kr0_gpr_ra        32'b0
 */
typedef volatile union _AON_NS_REG94_KR0_WDT_KR0_GPR_RA_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_wdt_lat_kr0_gpr_ra;
    };
} AON_NS_REG94_KR0_WDT_KR0_GPR_RA_TYPE;

/* 0x1C68   0x4000_1c68
    31:0    R   r_kr0_wdt_lat_kr0_gpr_sp        32'b0
 */
typedef volatile union _AON_NS_REG98_KR0_WDT_KR0_GPR_SP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_wdt_lat_kr0_gpr_sp;
    };
} AON_NS_REG98_KR0_WDT_KR0_GPR_SP_TYPE;

/* 0x1C6C   0x4000_1c6c
    31:0    R   r_kr0_wdt_lat_kr0_gpr_tp        32'b0
 */
typedef volatile union _AON_NS_REG9C_KR0_WDT_KR0_GPR_TP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_wdt_lat_kr0_gpr_tp;
    };
} AON_NS_REG9C_KR0_WDT_KR0_GPR_TP_TYPE;

/* 0x1C70   0x4000_1c70
    31:0    R   r_aon_wdt_lat_kr0_pc_value      32'b0
 */
typedef volatile union _AON_NS_REGA0_AON_WDT_KR0_PC_VALUE_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_aon_wdt_lat_kr0_pc_value;
    };
} AON_NS_REGA0_AON_WDT_KR0_PC_VALUE_TYPE;

/* 0x1C74   0x4000_1c74
    31:0    R   r_aon_wdt_lat_kr0_gpr_ra        32'b0
 */
typedef volatile union _AON_NS_REGA4_KR0_WDT_KR0_GPR_RA_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_aon_wdt_lat_kr0_gpr_ra;
    };
} AON_NS_REGA4_KR0_WDT_KR0_GPR_RA_TYPE;

/* 0x1C78   0x4000_1c78
    31:0    R   r_aon_wdt_lat_kr0_gpr_sp        32'b0
 */
typedef volatile union _AON_NS_REGA8_KR0_WDT_KR0_GPR_SP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_aon_wdt_lat_kr0_gpr_sp;
    };
} AON_NS_REGA8_KR0_WDT_KR0_GPR_SP_TYPE;

/* 0x1C7C   0x4000_1c7c
    31:0    R   r_aon_wdt_lat_kr0_gpr_tp        32'b0
 */
typedef volatile union _AON_NS_REGAC_KR0_WDT_KR0_GPR_TP_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_aon_wdt_lat_kr0_gpr_tp;
    };
} AON_NS_REGAC_KR0_WDT_KR0_GPR_TP_TYPE;

/* 0x1C80   0x4000_1c80
    31:0    R   r_km4_wdt_lat_km0_pc_value      32'b0
 */
typedef volatile union _AON_NS_REGB0_KM4_WDT_KM0_PC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_wdt_lat_km0_pc_value;
    };
} AON_NS_REGB0_KM4_WDT_KM0_PC_TYPE;

/* 0x1C84   0x4000_1c84
    31:0    R   r_km4_wdt_lat_km0_lr            32'b0
 */
typedef volatile union _AON_NS_REGB4_KM4_WDT_KM0_LR_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_wdt_lat_km0_lr;
    };
} AON_NS_REGB4_KM4_WDT_KM0_LR_TYPE;

/* 0x1C88   0x4000_1c88
    31:0    R   r_km4_wdt_lat_km0_pc_ex         32'b0
 */
typedef volatile union _AON_NS_REGB8_KM4_WDT_KM0_EX_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_wdt_lat_km0_pc_ex;
    };
} AON_NS_REGB8_KM4_WDT_KM0_EX_TYPE;

/* 0x1C8C   0x4000_1c8c
    31:0    R   r_km4_wdt_lat_km0_xpsr_r        32'b0
 */
typedef volatile union _AON_NS_REGBC_KM4_WDT_KM0_XPSR_R_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_wdt_lat_km0_xpsr_r;
    };
} AON_NS_REGBC_KM4_WDT_KM0_XPSR_R_TYPE;

/* 0x1C90   0x4000_1c90
    31:0    R   r_km4_wdt_lat_km0_msp_ns        32'b0
 */
typedef volatile union _AON_NS_REGC0_KM4_WDT_KM0_MSP_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_wdt_lat_km0_msp_ns;
    };
} AON_NS_REGC0_KM4_WDT_KM0_MSP_NS_TYPE;

/* 0x1C94   0x4000_1c94
    31:0    R   r_km4_wdt_lat_km0_psp_ns        32'b0
 */
typedef volatile union _AON_NS_REGC4_KM4_WDT_KM0_PSP_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_wdt_lat_km0_psp_ns;
    };
} AON_NS_REGC4_KM4_WDT_KM0_PSP_NS_TYPE;

/* 0x1C98   0x4000_1c98
    31:0    R   r_km0_wdt_lat_km0_pc_value      32'b0
 */
typedef volatile union _AON_NS_REGC8_KM0_WDT_KM0_PC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km0_wdt_lat_km0_pc_value;
    };
} AON_NS_REGC8_KM0_WDT_KM0_PC_TYPE;

/* 0x1C9C   0x4000_1c9c
    31:0    R   r_km0_wdt_lat_km0_lr            32'b0
 */
typedef volatile union _AON_NS_REGCC_KM0_WDT_KM0_LR_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km0_wdt_lat_km0_lr;
    };
} AON_NS_REGCC_KM0_WDT_KM0_LR_TYPE;

/* 0x1CA0   0x4000_1ca0
    31:0    R   r_km0_wdt_lat_km0_pc_ex         32'b0
 */
typedef volatile union _AON_NS_REGD0_KM0_WDT_KM0_EX_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km0_wdt_lat_km0_pc_ex;
    };
} AON_NS_REGD0_KM0_WDT_KM0_EX_TYPE;

/* 0x1CA4   0x4000_1ca4
    31:0    R   r_km0_wdt_lat_km0_xpsr_r        32'b0
 */
typedef volatile union _AON_NS_REGD4_KM0_WDT_KM0_XPSR_R_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km0_wdt_lat_km0_xpsr_r;
    };
} AON_NS_REGD4_KM0_WDT_KM0_XPSR_R_TYPE;

/* 0x1CA8   0x4000_1ca8
    31:0    R   r_km0_wdt_lat_km0_msp_ns        32'b0
 */
typedef volatile union _AON_NS_REGD8_KM0_WDT_KM0_MSP_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km0_wdt_lat_km0_msp_ns;
    };
} AON_NS_REGD8_KM0_WDT_KM0_MSP_NS_TYPE;

/* 0x1CAC   0x4000_1cac
    31:0    R   r_km0_wdt_lat_km0_psp_ns        32'b0
 */
typedef volatile union _AON_NS_REGDC_KM0_WDT_KM0_PSP_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km0_wdt_lat_km0_psp_ns;
    };
} AON_NS_REGDC_KM0_WDT_KM0_PSP_NS_TYPE;

/* 0x1CB0   0x4000_1cb0
    31:0    R   r_kr0_wdt_lat_km0_pc_value      32'b0
 */
typedef volatile union _AON_NS_REGE0_KR0_WDT_KM0_PC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_wdt_lat_km0_pc_value;
    };
} AON_NS_REGE0_KR0_WDT_KM0_PC_TYPE;

/* 0x1CB4   0x4000_1cb4
    31:0    R   r_kr0_wdt_lat_km0_lr            32'b0
 */
typedef volatile union _AON_NS_REGE4_KR0_WDT_KM0_LR_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_wdt_lat_km0_lr;
    };
} AON_NS_REGE4_KR0_WDT_KM0_LR_TYPE;

/* 0x1CB8   0x4000_1cb8
    31:0    R   r_kr0_wdt_lat_km0_pc_ex         32'b0
 */
typedef volatile union _AON_NS_REGE8_KR0_WDT_KM0_EX_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_wdt_lat_km0_pc_ex;
    };
} AON_NS_REGE8_KR0_WDT_KM0_EX_TYPE;

/* 0x1CBC   0x4000_1cbc
    31:0    R   r_kr0_wdt_lat_km0_xpsr_r        32'b0
 */
typedef volatile union _AON_NS_REGEC_KR0_WDT_KM0_XPSR_R_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_wdt_lat_km0_xpsr_r;
    };
} AON_NS_REGEC_KR0_WDT_KM0_XPSR_R_TYPE;

/* 0x1CC0   0x4000_1cc0
    31:0    R   r_kr0_wdt_lat_km0_msp_ns        32'b0
 */
typedef volatile union _AON_NS_REGF0_KR0_WDT_KM0_MSP_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_wdt_lat_km0_msp_ns;
    };
} AON_NS_REGF0_KR0_WDT_KM0_MSP_NS_TYPE;

/* 0x1CC4   0x4000_1cc4
    31:0    R   r_kr0_wdt_lat_km0_psp_ns        32'b0
 */
typedef volatile union _AON_NS_REGF4_KR0_WDT_KM0_PSP_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_wdt_lat_km0_psp_ns;
    };
} AON_NS_REGF4_KR0_WDT_KM0_PSP_NS_TYPE;

/* 0x1CC8   0x4000_1cc8
    31:0    R   r_aon_wdt_lat_km0_pc_value      32'b0
 */
typedef volatile union _AON_NS_REGF8_AON_WDT_KM0_PC_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_aon_wdt_lat_km0_pc_value;
    };
} AON_NS_REGF8_AON_WDT_KM0_PC_TYPE;

/* 0x1CCC   0x4000_1ccc
    31:0    R   r_aon_wdt_lat_km0_lr            32'b0
 */
typedef volatile union _AON_NS_REGFC_AON_WDT_KM0_LR_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_aon_wdt_lat_km0_lr;
    };
} AON_NS_REGFC_AON_WDT_KM0_LR_TYPE;

/* 0x1CD0   0x4000_1cd0
    31:0    R   r_aon_wdt_lat_km0_pc_ex         32'b0
 */
typedef volatile union _AON_NS_REG100_AON_WDT_KM0_EX_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_aon_wdt_lat_km0_pc_ex;
    };
} AON_NS_REG100_AON_WDT_KM0_EX_TYPE;

/* 0x1CD4   0x4000_1cd4
    31:0    R   r_aon_wdt_lat_km0_xpsr_r        32'b0
 */
typedef volatile union _AON_NS_REG104_AON_WDT_KM0_XPSR_R_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_aon_wdt_lat_km0_xpsr_r;
    };
} AON_NS_REG104_AON_WDT_KM0_XPSR_R_TYPE;

/* 0x1CD8   0x4000_1cd8
    31:0    R   r_aon_wdt_lat_km0_msp_ns        32'b0
 */
typedef volatile union _AON_NS_REG108_AON_WDT_KM0_MSP_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_aon_wdt_lat_km0_msp_ns;
    };
} AON_NS_REG108_AON_WDT_KM0_MSP_NS_TYPE;

/* 0x1CDC   0x4000_1cdc
    31:0    R   r_aon_wdt_lat_km0_psp_ns        32'b0
 */
typedef volatile union _AON_NS_REG10C_AON_WDT_KM0_PSP_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_aon_wdt_lat_km0_psp_ns;
    };
} AON_NS_REG10C_AON_WDT_KM0_PSP_NS_TYPE;

/* 0x1CE0   0x4000_1ce0
    1:0     R   r_aon_wdt_mode                  2'b0
    2       R   r_aon_wdt_timeout_flag          1'b0
    31:3    R   RSVD                            29'b0
 */
typedef volatile union _AON_NS_REG10C_AON_WDT_MODE_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_aon_wdt_mode: 2;
        uint32_t r_aon_wdt_timeout_flag: 1;
        uint32_t RSVD: 29;
    };
} AON_NS_REG10C_AON_WDT_MODE_TYPE;

/* 0x1CE4   0x4000_1ce4
    1:0     R   r_km0_wdt_mode                  2'b0
    2       R   r_km0_wdt_timeout_flag          1'b0
    31:3    R   RSVD                            29'b0
 */
typedef volatile union _AON_NS_REG110_KM0_WDT_MODE_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km0_wdt_mode: 2;
        uint32_t r_km0_wdt_timeout_flag: 1;
        uint32_t RSVD: 29;
    };
} AON_NS_REG110_KM0_WDT_MODE_TYPE;

/* 0x1CE8   0x4000_1ce8
    1:0     R   r_km4_wdt_mode                  2'b0
    2       R   r_km4_wdt_timeout_flag          1'b0
    31:3    R   RSVD                            29'b0
 */
typedef volatile union _AON_NS_REG110_KM4_WDT_MODE_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_km4_wdt_mode: 2;
        uint32_t r_km4_wdt_timeout_flag: 1;
        uint32_t RSVD: 29;
    };
} AON_NS_REG110_KM4_WDT_MODE_TYPE;

/* 0x1CEC   0x4000_1cec
    1:0     R   r_kr0_wdt_mode                  2'b0
    2       R   r_kr0_wdt_timeout_flag          1'b0
    31:3    R   RSVD                            29'b0
 */
typedef volatile union _AON_NS_REG110_KR0_WDT_MODE_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t r_kr0_wdt_mode: 2;
        uint32_t r_kr0_wdt_timeout_flag: 1;
        uint32_t RSVD: 29;
    };
} AON_NS_REG110_KR0_WDT_MODE_TYPE;

/* 0x1D00   0x4000_1d00
    0       R/W kr0_aon_boot_done               1'b0
    1       R/W kr0_non_aon_boot_done           1'b0
    2       R/W is_pf_rtc_clk_32000Hz           1'b0
    3       R/W is_cus_rtc_clk_32000Hz          1'b0
    4       R/W is_btmac_clk_32000Hz            1'b0
    5       R/W is_aon_clk_32000Hz              1'b0
    31:6    R/W kr0_boot_rsvd                   26'h0
 */
typedef volatile union _AON_NS_REG0X_FW_GENERAL_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t kr0_aon_boot_done: 1;
        uint32_t kr0_non_aon_boot_done: 1;
        uint32_t is_pf_rtc_clk_32000Hz: 1;
        uint32_t is_cus_rtc_clk_32000Hz: 1;
        uint32_t is_btmac_clk_32000Hz: 1;
        uint32_t is_aon_clk_32000Hz: 1;
        uint32_t kr0_boot_rsvd: 26;
    };
} AON_NS_REG0X_FW_GENERAL_NS_TYPE;

/* 0x1D04   0x4000_1d04
    0       R/W km4_aon_boot_done               1'b0
    1       R/W km4_sram_boot_done              1'b0
    2       R/W km4_dvfs_normal_vdd_mode        1'b0
    3       R/W km4_sensor_mode                 1'b0
    31:4    R/W km4_boot_rsvd                   28'h0
 */
typedef volatile union _AON_NS_REG2X_FW_GENERAL_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t km4_aon_boot_done: 1;
        uint32_t km4_sram_boot_done: 1;
        uint32_t km4_dvfs_normal_vdd_mode: 1;
        uint32_t km4_sensor_mode: 1;
        uint32_t km4_boot_rsvd: 28;
    };
} AON_NS_REG2X_FW_GENERAL_NS_TYPE;

/* 0x1D08   0x4000_1d08
    0       R/W km0_aon_boot_done               1'b0
    1       R/W km0_sram_boot_done              1'b0
    31:2    R/W km0_boot_rsvd                   30'h0
 */
typedef volatile union _AON_NS_REG4X_FW_GENERAL_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t km0_aon_boot_done: 1;
        uint32_t km0_sram_boot_done: 1;
        uint32_t km0_boot_rsvd: 30;
    };
} AON_NS_REG4X_FW_GENERAL_NS_TYPE;

/* 0x1D0C   0x4000_1d0c
    15:0    R/W FW_GENERAL_NS_REG6X             16'h0
    31:16   R/W FW_GENERAL_NS_REG7X             16'h0
 */
typedef volatile union _AON_NS_REG6X_FW_GENERAL_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_GENERAL_NS_REG6X: 16;
        uint32_t FW_GENERAL_NS_REG7X: 16;
    };
} AON_NS_REG6X_FW_GENERAL_NS_TYPE;

/* 0x1D10   0x4000_1d10
    0       R/W ota_mode                        1'b0
    1       R/W is_ft_mode                      1'b0
    15:2    R/W rsvd                            14'h0
    31:16   R/W FW_GENERAL_NS_REG9X             16'h0
 */
typedef volatile union _AON_NS_REG8X_FW_GENERAL_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t ota_mode: 1;
        uint32_t is_ft_mode: 1;
        uint32_t rsvd: 14;
        uint32_t FW_GENERAL_NS_REG9X: 16;
    };
} AON_NS_REG8X_FW_GENERAL_NS_TYPE;

/* 0x1D14   0x4000_1d14
    15:0    R/W FW_GENERAL_NS_REG10X            16'h0
    31:16   R/W FW_GENERAL_NS_REG11X            16'h0
 */
typedef volatile union _AON_NS_REG10X_FW_GENERAL_NS_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t FW_GENERAL_NS_REG10X: 16;
        uint32_t FW_GENERAL_NS_REG11X: 16;
    };
} AON_NS_REG10X_FW_GENERAL_NS_TYPE;

/* 0x1D40   0x4000_1d40
    3:0     R/W REG_LOAD_SEL                    4'h0
    4       R/W REG_COMP_INT_ADC                1'b0
    8:5     R/W REG_LDO_TUNE                    4'b0111
    9       R/W REG_LDO_PREC_START              1'b0
    10      R/W REG_LDO_PREC_MODE               1'b0
    11      R/W REG_LDO_POW                     1'b0
    12      R/W REG_LDO_DISCHARGE               1'b0
    13      R/W RG0X_CODEC_DUMMY                1'b0
    14      R/W REG_LDO_COMP_INT                1'b0
    15      R/W REG_LDO_ADC_POW                 1'b0
    16      R/W REG_LDO_LV_PC                   1'b0
    17      R/W REG_LDO_PREC_AVCC               1'b0
    18      R/W REG_EN_OFF30MV                  1'b0
    19      R/W REG_EN_ADP_PC_CTRL              1'b0
    20      R/W REG_EN_DUMMY                    1'b0
    23:21   R/W REG_DIG_VRSEL_LDODIG            3'b0
    26:24   R/W REG_AVCC_DMY_SEL                3'b0
    29:27   R/W RG1X_CODEC_DUMMY                3'b0
    30      R/W REG_LDO_LV_SEL                  1'b1
    31      R/W REG_L2L_EN                      1'b0
 */
typedef volatile union _AON_NS_RG0X_CODEC_LDO_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t REG_LOAD_SEL: 4;
        uint32_t REG_COMP_INT_ADC: 1;
        uint32_t REG_LDO_TUNE: 4;
        uint32_t REG_LDO_PREC_START: 1;
        uint32_t REG_LDO_PREC_MODE: 1;
        uint32_t REG_LDO_POW: 1;
        uint32_t REG_LDO_DISCHARGE: 1;
        uint32_t RG0X_CODEC_DUMMY: 1;
        uint32_t REG_LDO_COMP_INT: 1;
        uint32_t REG_LDO_ADC_POW: 1;
        uint32_t REG_LDO_LV_PC: 1;
        uint32_t REG_LDO_PREC_AVCC: 1;
        uint32_t REG_EN_OFF30MV: 1;
        uint32_t REG_EN_ADP_PC_CTRL: 1;
        uint32_t REG_EN_DUMMY: 1;
        uint32_t REG_DIG_VRSEL_LDODIG: 3;
        uint32_t REG_AVCC_DMY_SEL: 3;
        uint32_t RG1X_CODEC_DUMMY: 3;
        uint32_t REG_LDO_LV_SEL: 1;
        uint32_t REG_L2L_EN: 1;
    };
} AON_NS_RG0X_CODEC_LDO_TYPE;

/* 0x1D44   0x4000_1d44
    15:0    R/W REG_LDO_AVCC_DRV                16'b0011111010110000
    31:16   R/W REG_AON_CODEC_RESERVE           16'b0
 */
typedef volatile union _AON_NS_RG2X_CODEC_LDO_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t REG_LDO_AVCC_DRV: 16;
        uint32_t REG_AON_CODEC_RESERVE: 16;
    };
} AON_NS_RG2X_CODEC_LDO_TYPE;

/* 0x1D48   0x4000_1d48
    0       R/W REG_ENB_1B10U_CDOEC_LDO         1'b0
    1       R/W REG_CDOEC_MBIAS_POW             1'b0
    4:2     R/W REG_BIAS_10UA_IQ_SEL            3'b0
    7:5     R/W REG_LPBG_FT_TEMP                3'b100
    8       R/W REG_VCMBUF_POW                  1'b0
    9       R/W REG_VCMBUF_ISEL                 1'b0
    10      R/W REG_VCMBUF_BYPASS               1'b0
    11      R/W REG_LDO_POW_ADC_2P8V            1'b0
    12      R/W REG_LDO_COMP_INT_2P8V           1'b1
    15:13   R/W RG4X_CODEC_DUMMY                3'b0
    24:16   R/W REG_CODE_MBIAS_BG_DUMMY         9'b0
    31:25   R/W RG5X_CODEC_DUMMY                7'b0
 */
typedef volatile union _AON_NS_RG4X_CODEC_LDO_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t REG_ENB_1B10U_CDOEC_LDO: 1;
        uint32_t REG_CDOEC_MBIAS_POW: 1;
        uint32_t REG_BIAS_10UA_IQ_SEL: 3;
        uint32_t REG_LPBG_FT_TEMP: 3;
        uint32_t REG_VCMBUF_POW: 1;
        uint32_t REG_VCMBUF_ISEL: 1;
        uint32_t REG_VCMBUF_BYPASS: 1;
        uint32_t REG_LDO_POW_ADC_2P8V: 1;
        uint32_t REG_LDO_COMP_INT_2P8V: 1;
        uint32_t RG4X_CODEC_DUMMY: 3;
        uint32_t REG_CODE_MBIAS_BG_DUMMY: 9;
        uint32_t RG5X_CODEC_DUMMY: 7;
    };
} AON_NS_RG4X_CODEC_LDO_TYPE;

/* 0x1D4C   0x4000_1d4c
    0       R/W REG_MICBIAS_POW                 1'b0
    1       R/W REG_MICBIAS_ENCHX               1'b1
    2       R/W REG_MICBIAS_ENCOMP              1'b0
    3       R/W REG_MICBIAS_POWSHDT             1'b0
    5:4     R/W REG_MICBIAS_OCSEL               2'b01
    6       R/W REG_MICBIAS_SW1                 1'b1
    7       R/W REG_MICBIAS_SW2                 1'b0
    12:8    R/W REG_MICBIAS_VSET                5'b00010
    15:13   R/W REG_MICBIAS_RESERVE             3'b0
    31:16   R/W RG7X_CODEC_DUMMY                16'b0
 */
typedef volatile union _AON_NS_RG6X_CODEC_LDO_TYPE
{
    uint32_t d32;
    struct
    {
        uint32_t REG_MICBIAS_POW: 1;
        uint32_t REG_MICBIAS_ENCHX: 1;
        uint32_t REG_MICBIAS_ENCOMP: 1;
        uint32_t REG_MICBIAS_POWSHDT: 1;
        uint32_t REG_MICBIAS_OCSEL: 2;
        uint32_t REG_MICBIAS_SW1: 1;
        uint32_t REG_MICBIAS_SW2: 1;
        uint32_t REG_MICBIAS_VSET: 5;
        uint32_t REG_MICBIAS_RESERVE: 3;
        uint32_t RG7X_CODEC_DUMMY: 16;
    };
} AON_NS_RG6X_CODEC_LDO_TYPE;

#define AON_REG_BASE 0x40000000

#define AON_REG_READ(Offset)                                            \
    ((uint32_t)*((volatile uint32_t*)(AON_REG_BASE+(Offset))))

#define AON_REG_WRITE(Offset, Value)                                    \
    ((*((volatile uint32_t*)(AON_REG_BASE + (Offset)))) = (Value))

#define AON_REG_UPDATE(Offset, Mask, Value)                             \
    do {                                                                \
        uint32_t temp;                                                  \
        temp = AON_REG_READ(Offset) & ~(Mask);                          \
        AON_REG_WRITE(Offset, (temp | ((Value) & (Mask))));             \
    } while(0)

#define AON_REG_READ_BITFIELD(Offset, Bitfield)                         \
    (((Offset##_TYPE)AON_REG_READ(Offset)).Bitfield)

#define AON_REG_WRITE_BITFIELD(Offset, Bitfield, Value)                 \
    do {                                                                \
        Offset##_TYPE temp = {.d32 = AON_REG_READ(Offset)};             \
        temp.Bitfield = Value;                                          \
        AON_REG_WRITE(Offset, temp.d32);                                \
    } while(0)


#ifdef  __cplusplus
}
#endif /* __cplusplus */
#endif /* RTL876X_AON_REG_H */