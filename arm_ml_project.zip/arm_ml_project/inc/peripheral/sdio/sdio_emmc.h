#ifndef SDIO_EMMC_H
#define SDIO_EMMC_H

#include "sdio_driver.h"
#include "sdio_app_api.h"



//// All the following APIs must run in task environment.
SdEmmcRes_t Emmc_Init(SDIO_TypeDef *Sdio, const SdEmmcInitParm_t *pParm);
// A block is always set to 512 bytes.
SdEmmcRes_t Emmc_Read(SDIO_TypeDef *Sdio, uint32_t StartBlock, uint32_t BlockCnt, void *pBuf);
SdEmmcRes_t Emmc_Write(SDIO_TypeDef *Sdio, uint32_t StartBlock, uint32_t BlockCnt,
                       const void *pBuf);
uint32_t Emmc_GetBlockCnt(SDIO_TypeDef *Sdio);


#endif // SDIO_EMMC_H

