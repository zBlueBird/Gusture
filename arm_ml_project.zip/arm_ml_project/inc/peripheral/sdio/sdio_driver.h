#ifndef SDIO_DRIVER_H
#define SDIO_DRIVER_H

#include <stdint.h>
#include <stdbool.h>
#include "rtl_sdio_reg.h"
#include "sdio_app_api.h"



typedef enum
{
    SDIORES_OK = 0,

    SDIORES_HARDWARE_LOCKED_ERROR, // 1
    SDIORES_RESPONSE_ERROR,
    SDIORES_RESPONSE_CRC_ERROR,
    SDIORES_RESPONSE_TIMEOUT,

    SDIORES_DATA_CRC_ERROR, // 5
    SDIORES_DATA_READ_TIMEOUT,
    SDIORES_DATA_START_BIT_ERROR,
    SDIORES_DATA_END_BIT_ERROR,
    SDIORES_WRITE_NO_CRC, // 9

    SDIORES_FATAL_BUS_ERROR,
    SDIORES_DESCRIPTOR_UNAVAILABLE,
    SDIORES_CARD_ERROR, // 12

    SDIORES_WAIT_DATA0_IDLE_TIMEOUT,
} SdioRes_t;


typedef struct
{
    // 0 ~ 63
    uint8_t CmdIdx;
    uint32_t CmdArg;

    // Such as CMD0.
    bool IsResetCmd;
    // Such as CMD12.
    bool IsStopCmd;

    // CMD0, CMD4, CMD15... have no response.
    bool IsRspExpected;
    // R2 is long response.
    bool IsR2Rsp;
    // Some CMD do not have CRC, such as ACMD41 for eMMC and CMD8 for SD.
    bool CheckRspCrc;
} CmdInfo_t;


typedef struct
{
    // Bytes per block.
    uint32_t BlockSize;
    // Block counts you want to Tx/Rx.
    uint32_t BlockCount;
    // If set, stop cmd (CMD12) will be sent automatically after data transfer.
    bool SendAutoStop;
} DataInfo_t;




// All the APIs must run in task environment.

// pParm is shallow copied, and must keep valid during the whole SDIO session.
void Sdio_InitPad(SDIO_TypeDef *Sdio, DataWidth_t DataWidth);
void Sdio_DeInitPad(SDIO_TypeDef *Sdio, DataWidth_t DataWidth);

void Sdio_Init(SDIO_TypeDef *Sdio);
void Sdio_DeInit(SDIO_TypeDef *Sdio);

uint32_t Sdio_SetClkOutFreq(SDIO_TypeDef *Sdio, uint32_t Freq_kHz);
uint32_t Sdio_GetClkOutFreq_kHz(SDIO_TypeDef *Sdio);

void Sdio_SetHostDataWidth(SDIO_TypeDef *Sdio, DataWidth_t Width);

SdioRes_t Sdio_SendNoDataCmd(SDIO_TypeDef *Sdio, const CmdInfo_t *pCmdInfo, void *pRspBuf);

// At most (DESC_CNT * MAX_BLOCK_PER_DESC * BYTES_PER_BLOCK) bytes can be send per transfer.
SdioRes_t Sdio_SendCmdWithRxData(SDIO_TypeDef *Sdio,
                                 const CmdInfo_t *pCmdInfo, void *pRspBuf,
                                 const DataInfo_t *pDataInfo, void *pRxDataBuf);
SdioRes_t Sdio_SendCmdWithTxData(SDIO_TypeDef *Sdio,
                                 const CmdInfo_t *pCmdInfo, void *pRspBuf,
                                 const DataInfo_t *pDataInfo, const void *pDataToTx);

SdioRes_t Sdio_WaitData0Idle(SDIO_TypeDef *Sdio, uint32_t Timeout_ms);

#define DESC_CNT  4
// TODO: It seems that the maximum can only be set to 16. why?
#define MAX_BLOCK_PER_DESC  16

#define MAX_BYTES_PER_DESC  (MAX_BLOCK_PER_DESC * BYTES_PER_BLOCK)
#define MAX_BLOCK_PER_XFER  (MAX_BLOCK_PER_DESC * DESC_CNT)
#define MAX_BYTES_PER_XFER  (MAX_BYTES_PER_DESC * DESC_CNT)


/* The asynchronous API may not be needed because if it is,
   you can build a separate  task to do it using the synchronous API. */







#endif // SDIO_DRIVER_H
