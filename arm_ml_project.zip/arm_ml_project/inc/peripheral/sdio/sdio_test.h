#ifndef SDIO_TEST_H
#define SDIO_TEST_H

#include "sdio_sdcard.h"
#include "sdio_emmc.h"
#include "os_mem.h"
#include <string.h>
#include "trace.h"

#if 1
#define Init        Sd_Init
#define Read        Sd_Read
#define Write       Sd_Write
#define GetBlockCnt Sd_GetBlockCnt
#define SDIO_Demo   SDIO0

#define START_BLOCK  113

static const SdEmmcInitParm_t Parm =
{
    .CardType = CARDTYPE_SD,
    .DataWidth = DATAWIDTH_4BIT,
    .ClkOutFreq_kHz = 50 * 1000,
};
#else
#define Init        Emmc_Init
#define Read        Emmc_Read
#define Write       Emmc_Write
#define GetBlockCnt Emmc_GetBlockCnt
#define SDIO_Demo   SDIO0

#define START_BLOCK  113

static const SdEmmcInitParm_t Parm =
{
    .CardType = CARDTYPE_EMMC,
    /* TODO: DDR still has problems. Capturing the waveform diagram to see
             how the PHY register is matched. Donot rule out the driver code
             may also have problems. The DDR code in sdio_test.c is available
             on the FPGA. driver code is moved directly from sdio_test.c */
    .DataWidth = DATAWIDTH_8BIT_DDR,
    .ClkOutFreq_kHz = 52 * 1000,
};
#endif

#define BLOCK_CNT  121
#define BUF_BYTES  (512 * BLOCK_CNT)

void Sdio_Test(void);


#endif // SDIO_TEST_H
