#ifndef SDIO_APP_API_H
#define SDIO_APP_API_H

#include <stdint.h>
#include <stdbool.h>
#include "rtl_sdio_reg.h"


#define BYTES_PER_BLOCK  512


typedef enum
{
    SDEMMCRES_OK = 0,

    SDEMMCRES_ILLEGAL_PARM,

    SDEMMCRES_CMD0_ERROR,
    SDEMMCRES_CMD8_ERROR, // 3
    SDEMMCRES_CMD55_ERROR,
    SDEMMCRES_ACMD41_ERROR,
    SDEMMCRES_ACMD41_TIMEOUT, // 6
    SDEMMCRES_CMD2_ERROR,
    SDEMMCRES_CMD3_ERROR,
    SDEMMCRES_CMD7_ERROR, // 9
    SDEMMCRES_CMD9_ERROR,
    SDEMMCRES_CMD13_ERROR,
    SDEMMCRES_ACMD6_ERROR, // 12
    SDEMMCRES_CMD16_ERROR,
    SDEMMCRES_ACMD42_ERROR,
    SDEMMCRES_CMD18_ERROR, // 15
    SDEMMCRES_CMD13_TIMEOUT,
    SDEMMCRES_ACMD51_ERROR,
    SDEMMCRES_CMD6_ERROR,  // 18
    SDEMMCRES_CMD25_ERROR,
    SDEMMCRES_CMD1_ERROR,
    SDEMMCRES_CMD1_TIMEOUT, // 21
    SDEMMCRES_CMD6_TIMEOUT,

    SDEMMCRES_WRITE_TIMEOUT,
    SDEMMCRES_MALLOC_FAILED, // 24
} SdEmmcRes_t;

typedef enum
{
    CARDTYPE_SD = 1,
    CARDTYPE_EMMC,
} CardType_t;

typedef enum
{
    DATAWIDTH_1BIT,
    DATAWIDTH_4BIT,
    DATAWIDTH_8BIT,
    DATAWIDTH_4BIT_DDR,
    DATAWIDTH_8BIT_DDR,
} DataWidth_t;

typedef struct
{
    // Pin group.
    // Power enable pin and active level.

    // Enter DLPS callback;
    // Power on/off callback;
    // Auto power off;
    // ...

    CardType_t CardType;
    DataWidth_t DataWidth;
    uint32_t ClkOutFreq_kHz;
} SdEmmcInitParm_t;


//** All the following APIs must run in task environment.
SdEmmcRes_t SdEmmc_Init(SDIO_TypeDef *Sdio, const SdEmmcInitParm_t *pParm);
// A block is always set to 512 bytes.
SdEmmcRes_t SdEmmc_Read(SDIO_TypeDef *Sdio, uint32_t StartBlock, uint32_t BlockCnt, void *pBuf);
SdEmmcRes_t SdEmmc_Write(SDIO_TypeDef *Sdio, uint32_t StartBlock, uint32_t BlockCnt,
                         const void *pBuf);
uint32_t SdEmmc_GetBlockCnt(SDIO_TypeDef *Sdio);



#endif // SDIO_APP_API_H



