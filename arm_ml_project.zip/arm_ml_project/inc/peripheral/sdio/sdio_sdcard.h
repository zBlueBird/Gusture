#ifndef SDIO_SDCARD_H
#define SDIO_SDCARD_H

#include "sdio_driver.h"
#include "sdio_app_api.h"



//// All the following APIs must run in task environment.
SdEmmcRes_t Sd_Init(SDIO_TypeDef *Sdio, const SdEmmcInitParm_t *pParm);
// A block is always set to 512 bytes.
SdEmmcRes_t Sd_Read(SDIO_TypeDef *Sdio, uint32_t StartBlock, uint32_t BlockCnt, void *pBuf);
SdEmmcRes_t Sd_Write(SDIO_TypeDef *Sdio, uint32_t StartBlock, uint32_t BlockCnt, const void *pBuf);
uint32_t Sd_GetBlockCnt(SDIO_TypeDef *Sdio);



#endif // SDIO_SDCARD_H

