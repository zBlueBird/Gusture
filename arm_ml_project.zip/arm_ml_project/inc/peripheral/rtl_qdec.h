/**
*********************************************************************************************************
*               Copyright(c) 2016, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* \file     rtl_qdec.h
* \brief    The header file of the peripheral QDECODER driver.
* \details  This file provides all QDECODER firmware functions.
* \author   grace_yan
* \date     2023-02-14
* \version  v1.0
* *********************************************************************************************************
*/


#ifndef RTL_QDEC_H
#define RTL_QDEC_H

#ifdef __cplusplus
extern "C" {
#endif


/**
 * \addtogroup  IO          Peripheral Drivers
 * \defgroup    QDEC        QDEC
 *
 * \brief       Manage the QDEC peripheral functions.
 *
 * \ingroup     IO
 */

/*============================================================================*
 *                         Includes
 *============================================================================*/
#include "rtl876x.h"
#include "rtl_alias.h"
#include "rtl_qdec_reg.h"

/*============================================================================*
 *                         Constants
 *============================================================================*/

/**
 * \defgroup    QDEC_Exported_Constants     Macro Definitions
 *
 * \ingroup     QDEC
 */

#define IS_QDEC_PERIPH(PERIPH) ((PERIPH) == QDEC)

/** \defgroup   QDEC_Axis   QDEC Axis
* \{
* \ingroup     QDEC_Exported_Types
*/

#define QDEC_AXIS_X                              BIT0
#define QDEC_AXIS_Y                              BIT2
#define QDEC_AXIS_Z                              BIT3
/** \} */

/*============================================================================*
 *                         Types
 *============================================================================*/

/** \defgroup   QDEC_Axis_counter_Scale     QDEC Axis Counter
* \{
* \ingroup     QDEC_Exported_Types
*/
typedef enum
{
    CounterScale_1_Phase = 0x00,
    CounterScale_2_Phase = 0x01,
} QDEC_AXIS_CNT_SCALE_T;
#define IS_QDEC_AXIS_CNT_SCALE_TYPE(TYPE) ((TYPE) <= 0x01)
/** \} */

/** \defgroup   Qdec_Init_Phase     Qdec Init Phase
 * \{
 * \ingroup     QDEC_Exported_Types
 */
typedef enum
{
    phaseMode0 = 0x00,//phase 00
    phaseMode1 = 0x01,//phase 01
    phaseMode2 = 0x02,//phase 10
    phaseMode3 = 0x03,//phase 11
} QDEC_INIT_PHASE_T;
#define IS_QDEC_INIT_PHASE_TYPE(TYPE) ((TYPE) <= 0x03)
/** \} */

/** \defgroup   QDEC_Axis_Direction     QDEC Axis Direction
 * \{
 * \ingroup     QDEC_Exported_Types
 */
#define QDEC_AXIS_DIR_DOWN   0x00
#define QDEC_AXIS_DIR_UP     0x01
#define IS_QDEC_AXIS_DIR(QDEC_AXIS)     ((QDEC_AXIS == QDEC_AXIS_DIR_UP) || (QDEC_AXIS == QDEC_AXIS_DIR_DOWN))

/** \} */

/** \defgroup   QDEC_Clr_Flag   Qdec Clr Flag
 * \{
 * \ingroup     QDEC_Exported_Types
 */
#define QDEC_CLR_ILLEGAL_CT_X                   BIT20
#define QDEC_CLR_ILLEGAL_CT_Y                   BIT21
#define QDEC_CLR_ILLEGAL_CT_Z                   BIT22

#define QDEC_CLR_ACC_CT_X                       BIT16
#define QDEC_CLR_ACC_CT_Y                       BIT17
#define QDEC_CLR_ACC_CT_Z                       BIT18

#define QDEC_CLR_ILLEGAL_INT_X                  BIT12
#define QDEC_CLR_ILLEGAL_INT_Y                  BIT13
#define QDEC_CLR_ILLEGAL_INT_Z                  BIT14

#define QDEC_CLR_UNDERFLOW_X                    BIT8
#define QDEC_CLR_UNDERFLOW_Y                    BIT9
#define QDEC_CLR_UNDERFLOW_Z                    BIT10

#define QDEC_CLR_OVERFLOW_X                     BIT4
#define QDEC_CLR_OVERFLOW_Y                     BIT5
#define QDEC_CLR_OVERFLOW_Z                     BIT6

#define QDEC_CLR_NEW_CT_X                       BIT0
#define QDEC_CLR_NEW_CT_Y                       BIT1
#define QDEC_CLR_NEW_CT_Z                       BIT2
/** \} */

#define IS_QDEC_INT_CLR_CONFIG(CONFIG) (((CONFIG) == QDEC_CLR_ACC_CT_X) || ((CONFIG) == QDEC_CLR_ACC_CT_Y)\
                                        || ((CONFIG) == QDEC_CLR_ACC_CT_Z) || ((CONFIG) == QDEC_CLR_ILLEGAL_INT_Y)\
                                        || ((CONFIG) == QDEC_CLR_ILLEGAL_INT_Z) || ((CONFIG) == QDEC_CLR_UNDERFLOW_X)\
                                        || ((CONFIG) == QDEC_CLR_UNDERFLOW_Y) || ((CONFIG) == QDEC_CLR_UNDERFLOW_Z)\
                                        || ((CONFIG) == QDEC_CLR_OVERFLOW_X) || ((CONFIG) == QDEC_CLR_OVERFLOW_Y)\
                                        || ((CONFIG) == QDEC_CLR_OVERFLOW_Z) || ((CONFIG) == QDEC_CLR_NEW_CT_X)\
                                        || ((CONFIG) == QDEC_CLR_NEW_CT_Y) || ((CONFIG) == QDEC_CLR_NEW_CT_Z))

/** \defgroup   QDEC_Flag QDEC Flag
 * \{
 * \ingroup     QDEC_Exported_Types
 */

#define QDEC_FLAG_NEW_CT_STATUS_X                BIT0
#define QDEC_FLAG_NEW_CT_STATUS_Y                BIT1
#define QDEC_FLAG_NEW_CT_STATUS_Z                BIT2
#define QDEC_FLAG_OVERFLOW_X                     BIT3
#define QDEC_FLAG_OVERFLOW_Y                     BIT4
#define QDEC_FLAG_OVERFLOW_Z                     BIT5
#define QDEC_FLAG_UNDERFLOW_X                    BIT6
#define QDEC_FLAG_UNDERFLOW_Y                    BIT7
#define QDEC_FLAG_UNDERFLOW_Z                    BIT8
#define QDEC_FLAG_AUTO_STATUS_X                  BIT9
#define QDEC_FLAG_AUTO_STATUS_Y                  BIT10
#define QDEC_FLAG_AUTO_STATUS_Z                  BIT11
#define QDEC_FLAG_ILLEGAL_STATUS_X               BIT12
#define QDEC_FLAG_ILLEGAL_STATUS_Y               BIT13
#define QDEC_FLAG_ILLEGAL_STATUS_Z               BIT14
/** \} */

#define IS_QDEC_INT_STATUS(INT) (((INT) == QDEC_FLAG_ILLEGAL_STATUS_X) || ((INT) == QDEC_FLAG_ILLEGAL_STATUS_Y)\
                                 || ((INT) == QDEC_FLAG_ILLEGAL_STATUS_Z) || ((INT) == QDEC_FLAG_NEW_CT_STATUS_X)\
                                 || ((INT) == QDEC_FLAG_NEW_CT_STATUS_Y) || ((INT) == QDEC_FLAG_NEW_CT_STATUS_Z)\
                                 || ((INT) == QDEC_FLAG_OVERFLOW_X) || ((INT) == QDEC_FLAG_OVERFLOW_Y)\
                                 || ((INT) == QDEC_FLAG_OVERFLOW_Z) || ((INT) == QDEC_FLAG_UNDERFLOW_X)\
                                 || ((INT) == QDEC_FLAG_UNDERFLOW_Y) || ((INT) == QDEC_FLAG_UNDERFLOW_Z)\
                                 || ((INT) == QDEC_FLAG_AUTO_STATUS_X) || ((INT) == QDEC_FLAG_AUTO_STATUS_Y)\
                                 || ((INT) == QDEC_FLAG_AUTO_STATUS_Z))

/**
 * \defgroup    QDEC_Exported_Constants     Macro Definitions
 *
 * \ingroup     QDEC
 */

#define IS_QDEC_PERIPH(PERIPH) ((PERIPH) == QDEC)

/** \defgroup   QDEC_Interrupts_Definition  QDEC Interrupts Definition
 * \{
 * \ingroup     QDEC_Exported_Constants
 */
#define QDEC_X_INT_NEW_DATA           BIT0//get New data and state change
#define QDEC_X_INT_ILLEAGE            BIT1//illeage
#define QDEC_Y_INT_NEW_DATA           BIT2//get New data and state change
#define QDEC_Y_INT_ILLEAGE            BIT3//illeage
#define QDEC_Z_INT_NEW_DATA           BIT4//get New data and state change
#define QDEC_Z_INT_ILLEAGE            BIT5//illeage
/** \} */

#define IS_QDEC_INT_CONFIG(CONFIG) (((CONFIG) == QDEC_X_INT_NEW_DATA) || ((CONFIG) == QDEC_X_INT_ILLEAGE)\
                                    || ((CONFIG) == QDEC_Y_INT_NEW_DATA) || ((CONFIG) == QDEC_Y_INT_ILLEAGE)\
                                    || ((CONFIG) == QDEC_Z_INT_NEW_DATA) || ((CONFIG) == QDEC_Z_INT_ILLEAGE))

/** \defgroup   QDEC_Interrupts_Mask    QDEC Interrupts Mask
 * \{
 * \ingroup     QDEC_Exported_Constants
 */
#define QDEC_X_CT_INT_MASK            BIT0//get New data and state change
#define QDEC_X_ILLEAGE_INT_MASK       BIT4//illeage
#define QDEC_Y_CT_INT_MASK            BIT1//get New data and state change
#define QDEC_Y_ILLEAGE_INT_MASK       BIT5//illeage
#define QDEC_Z_CT_INT_MASK            BIT2//get New data and state change
#define QDEC_Z_ILLEAGE_INT_MASK       BIT6//illeage
/** \} */

#define IS_QDEC_INT_MASK_CONFIG(CONFIG) (((CONFIG) == QDEC_X_CT_INT_MASK) || ((CONFIG) == QDEC_X_ILLEAGE_INT_MASK)\
                                         || ((CONFIG) == QDEC_Y_CT_INT_MASK) || ((CONFIG) == QDEC_Y_ILLEAGE_INT_MASK)\
                                         || ((CONFIG) == QDEC_Z_CT_INT_MASK) || ((CONFIG) == QDEC_Z_ILLEAGE_INT_MASK))

/** \defgroup   QDEC_Immediate_Number_definition     QDEC Immediate Number definition
 * \{
 * \ingroup     QDEC_Exported_Types
 */
#define QDEC_0X00_CNT_PAUSE         BIT3
#define QDEC_0X08_CNT_DIR           BIT16
#define QDEC_0X04_AXIS_EN           BIT31


/**
 * \defgroup    QDEC_Exported_Types Init Params Struct
 *
 * \ingroup     QDEC
 */

/**
 * \brief       Qdecoder init structure definition.
 *
 * \ingroup     QDEC_Exported_Types
 */
typedef struct
{
    uint16_t QDEC_ScanClockDiv;                 /*!< Specifies DIV for Scan clock. */
    uint16_t QDEC_DebounceClockDiv;             /*!< Specifies DEB_DIV for debounce clock. */
    uint8_t QDEC_AxisConfigX;                   /*!< Specifies the axis X function.
                                                This parameter can be a value of ENABLE or DISABLE */
    uint8_t QDEC_AxisConfigY;                   /*!< Specifies the axis Y function.
                                                This parameter can be a value of ENABLE or DISABLE */
    uint8_t QDEC_AxisConfigZ;                   /*!< Specifies the axis Z function.
                                                This parameter can be a value of ENABLE or DISABLE */
    FunctionalState QDEC_ManualLoadInitPhase;   /*!< Specifies manual-load Initphase function .
                                                This parameter can be a value of ENABLE or DISABLE */
    QDEC_AXIS_CNT_SCALE_T QDEC_CounterScaleX;   /*!< Specifies the axis X conter scale. */
    FunctionalState QDEC_DebounceEnableX;       /*!< Specifies the axis X debounce.
                                                This parameter can be a value of ENABLE or DISABLE */
    uint16_t QDEC_DebounceTimeX;                /*!< Specifies the axis X debounce time. */
    QDEC_INIT_PHASE_T QDEC_InitPhaseX;          /*!< Specifies the axis X function. */
    QDEC_AXIS_CNT_SCALE_T QDEC_CounterScaleY;   /*!< Specifies the axis Y conter scale. */
    FunctionalState QDEC_DebounceEnableY;       /*!< Specifies the axis Y debounce.
                                                This parameter can be a value of ENABLE or DISABLE */
    uint16_t QDEC_DebounceTimeY;                /*!< Specifies the axis Y debounce time. */
    QDEC_INIT_PHASE_T QDEC_InitPhaseY;          /*!< Specifies the axis Y function. */
    QDEC_AXIS_CNT_SCALE_T QDEC_CounterScaleZ;   /*!< Specifies the axis Z conter scale. */
    FunctionalState QDEC_DebounceEnableZ;       /*!< Specifies the axis Z debounce.
                                                This parameter can be a value of ENABLE or DISABLE */
    uint16_t QDEC_DebounceTimeZ;                /*!< Specifies the axis Z debounce time. */
    QDEC_INIT_PHASE_T QDEC_InitPhaseZ;          /*!< Specifies the axis Z function. */
} QDEC_InitTypeDef;


/*============================================================================*
 *                         Functions
 *============================================================================*/

/**
 * \defgroup    QDEC_Exported_Functions Peripheral APIs
 * \{
 * \ingroup     QDEC
 */

/**
 * \brief   Deinitializes the Qdecoder peripheral registers to their default reset values(turn off Qdecoder clock).
 * \param[in] QDECx: Selected Qdecoder peripheral.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_qdec_init(void)
 * {
 *     QDEC_DeInit();
 * }
 * \endcode
 */
void QDEC_DeInit(QDEC_TypeDef *QDECx);

/**
 * \brief   Initializes the Qdecoder peripheral according to the specified
 *          parameters in the QDEC_InitStruct
 * \param[in]  QDECx: Selected Qdecoder peripheral.
 * \param[in]  QDEC_InitStruct: Pointer to a QDEC_InitStruct structure that
 *                              contains the configuration information for the specified Qdecoder peripheral
 * \return None.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_qdec_init(void)
 * {
 *     QDEC_DeInit(QDEC);
 *     RCC_PeriphClockCmd(APBPeriph_QDEC, APBPeriph_QDEC_CLOCK, ENABLE);
 *
 *     QDEC_InitTypeDef QDEC_InitStruct;
 *     QDEC_StructInit(&QDEC_InitStruct);
 *     QDEC_InitStruct.axisConfigY       = ENABLE;
 *     QDEC_InitStruct.debounceEnableY   = Debounce_Enable;
 *     QDEC_Init(QDEC, &QDEC_InitStruct);
 *
 *     QDEC_Cmd(QDEC, QDEC_AXIS_Y, ENABLE);
 * }
 * \endcode
 */
void QDEC_Init(QDEC_TypeDef *QDECx, QDEC_InitTypeDef *QDEC_InitStruct);

/**
 * \brief  Fills each QDEC_InitStruct member with its default value.
 * \param[in]  QDEC_InitStruct: Pointer to an QDEC_InitStruct structure which will be initialized.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_qdec_init(void)
 * {
 *     QDEC_DeInit(QDEC);
 *     RCC_PeriphClockCmd(APBPeriph_QDEC, APBPeriph_QDEC_CLOCK, ENABLE);
 *
 *     QDEC_InitTypeDef QDEC_InitStruct;
 *     QDEC_StructInit(&QDEC_InitStruct);
 *     QDEC_InitStruct.axisConfigY       = ENABLE;
 *     QDEC_InitStruct.debounceEnableY   = Debounce_Enable;
 *     QDEC_Init(QDEC, &QDEC_InitStruct);
 *
 *     QDEC_Cmd(QDEC, QDEC_AXIS_Y, ENABLE);
 * }
 * \endcode
 */
void QDEC_StructInit(QDEC_InitTypeDef *QDEC_InitStruct);

/**
 * \brief  Enables or disables the specified Qdecoder interrupt source.
 * \param[in]  QDECx: Selected Qdecoder peripheral.
 * \param[in]  QDEC_IT: Specifies the QDECODER interrupts sources to be enabled or disabled.
 *      This parameter parameter can be one of the following values:
 *      \arg  QDEC_X_INT_NEW_DATA: The counter interrupt for X axis.
 *      \arg  QDEC_X_INT_ILLEAGE: The illegal interrupt for X axis.
 *      \arg  QDEC_Y_INT_NEW_DATA: The counter interrupt for Y axis.
 *      \arg  QDEC_Y_INT_ILLEAGE: The illegal interrupt for Y axis.
 *      \arg  QDEC_Z_INT_NEW_DATA: The counter interrupt for Z axis.
 *      \arg  QDEC_Z_INT_ILLEAGE: The illegal interrupt for Z axis.
 * \param[in]  NewState: New state of the specified QDECODER interrupt.
 *      This parameter parameter can be: ENABLE or DISABLE.
 * \return None.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_qdec_init(void)
 * {
 *     QDEC_INTConfig(QDEC, QDEC_Y_INT_NEW_DATA, ENABLE);
 * }
 * \endcode
 */
void QDEC_INTConfig(QDEC_TypeDef *QDECx, uint32_t QDEC_IT, FunctionalState NewState);

/**
 * \brief  Check whether the specified Qdecoder flag is set.
 * \param[in]  QDECx: Selected Qdecoder peripheral.
 * \param[in]  QDEC_FLAG: Specifies the flag to check.
 *      This parameter can be one of the following values:
 *      \arg QDEC_FLAG_NEW_CT_STATUS_X: Status of the counter interrupt for X axis.
 *      \arg QDEC_FLAG_NEW_CT_STATUS_Y: Status of the counter interrupt for Y axis.
 *      \arg QDEC_FLAG_NEW_CT_STATUS_Z: Status of the counter interrupt for Z axis.
 *      \arg QDEC_FLAG_ILLEGAL_STATUS_X: Status of the illegal interrupt for X axis.
 *      \arg QDEC_FLAG_ILLEGAL_STATUS_Y: Status of the illegal interrupt for Y axis.
 *      \arg QDEC_FLAG_ILLEGAL_STATUS_Z: Status of the illegal interrupt for Z axis.
 *      \arg QDEC_FLAG_OVERFLOW_X: The overflow flag for x-axis accumulation counter.
 *      \arg QDEC_FLAG_OVERFLOW_Y: The overflow flag for y-axis accumulation counter.
 *      \arg QDEC_FLAG_OVERFLOW_Z: The overflow flag for z-axis accumulation counter.
 *      \arg QDEC_FLAG_UNDERFLOW_X: The underflow flag for x-axis accumulation counter.
 *      \arg QDEC_FLAG_UNDERFLOW_Y: The underflow flag for y-axis accumulation counter.
 *      \arg QDEC_FLAG_UNDERFLOW_Z: The underflow flag for z-axis accumulation counter.
 * \retval The new state of QDEC_FLAG (SET or RESET).
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void qdec_demo(void)
 * {
 *     FlagStatus flag_status = QDEC_GetFlagState(QDEC, QDEC_Y_INT_NEW_DATA, ENABLE);
 * }
 * \endcode
 */
FlagStatus QDEC_GetFlagState(QDEC_TypeDef *QDECx, uint32_t QDEC_FLAG);

/**
 * \brief  Enables or disables mask the specified Qdecoder axis interrupts.
 * \param[in]  QDECx: Selected Qdecoder peripheral.
 * \param[in]  QDEC_AXIS: Specifies the Qdecoder axis.
 *      This parameter can be one or logical OR of the following values:
 *      \arg  QDEC_X_CT_INT_MASK: The x-axis counter interrupt mask.
 *      \arg  QDEC_X_ILLEAGE_INT_MASK: The x-axis illegal interrupt mask.
 *      \arg  QDEC_Y_CT_INT_MASK: The y-axis counter interrupt mask.
 *      \arg  QDEC_Y_ILLEAGE_INT_MASK: The y-axis illegal interrupt mask.
 *      \arg  QDEC_Z_CNT_INT_MASK: The z-axis counter interrupt mask.
 *      \arg  QDEC_Z_ILLEAGE_INT_MASK: The z-axis illegal interrupt mask.
 * \param[in]  NewState: New state of the specified Qdecoder interrupts mask.
 *      This parameter can be: ENABLE or DISABLE.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void qdec_demo(void)
 * {
 *
 *     QDEC_INTMask(QDEC, QDEC_X_CT_INT_MASK, ENABLE);
 *
 * }
 * \endcode
 */
void QDEC_INTMask(QDEC_TypeDef *QDECx, uint32_t QDEC_AXIS, FunctionalState NewState);

/**
 * \brief  Enable or disable the selected Qdecoder axis(x/y/z).
 * \param[in]  QDECx: Selected Qdecoder peripheral.
 * \param[in]  QDEC_AXIS: Specifies the Qdecoder axis.
 *      This parameter can be one of the following values:
 *      \arg  QDEC_AXIS_X: The qdecoder X axis.
 *      \arg  QDEC_AXIS_Y: The qdecoder Y axis.
 *      \arg  QDEC_AXIS_Z: The qdecoder Z axis.
 * \param[in]  NewState: New state of the selected Qdecoder axis.
 *      This parameter can be : ENABLE or DISABLE.
 * \retturn The count of the axis.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void qdec_demo(void)
 * {
 *     QDEC_Cmd(QDEC, QDEC_AXIS_X, ENABLE);
 * }
 * \endcode
 */
void QDEC_Cmd(QDEC_TypeDef *QDECx, uint32_t QDEC_AXIS,
              FunctionalState NewState);

/**
 * \brief   Clear Qdecoder interrupt pending bit.
 * \param[in]  QDECx: Selected Qdecoder peripheral.
 * \param[in]  QDEC_FLAG: Specifies the flag to clear.
 *      This parameter parameter can be one of the following values:
 *      \arg  QDEC_CLR_OVERFLOW_X: The overflow flag for x-axis accumulation counter.
 *      \arg  QDEC_CLR_OVERFLOW_Y: The overflow flag for y-axis accumulation counter.
 *      \arg  QDEC_CLR_OVERFLOW_Z: The overflow flag for z-axis accumulation counter.
 *      \arg  QDEC_CLR_ILLEGAL_INT_X: The illegal interrupt for X axis.
 *      \arg  QDEC_CLR_ILLEGAL_INT_Y: The illegal interrupt for Y axis.
 *      \arg  QDEC_CLR_ILLEGAL_INT_Z: The illegal interrupt for Z axis.
 *      \arg  QDEC_CLR_UNDERFLOW_X: The underflow flag for x-axis accumulation counter.
 *      \arg  QDEC_CLR_UNDERFLOW_Y: The underflow flag for y-axis accumulation counter.
 *      \arg  QDEC_CLR_UNDERFLOW_Z: The underflow flag for z-axis accumulation counter.
 *      \arg  QDEC_CLR_NEW_CT_X: The counter interrupt for X axis.
 *      \arg  QDEC_CLR_NEW_CT_Y: The counter interrupt for Y axis.
 *      \arg  QDEC_CLR_NEW_CT_Z: The counter interrupt for Z axis.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void qdec_demo(void)
 * {
 *     QDEC_ClearINTPendingBit(QDEC, QDEC_CLR_OVERFLOW_X);
 * }
 * \endcode
 */
__STATIC_INLINE void QDEC_ClearINTPendingBit(QDEC_TypeDef *QDECx, uint32_t QDEC_CLR_INT)
{
    /* Check the parameters */
    assert_param(IS_QDEC_PERIPH(QDECx));
    assert_param(IS_QDEC_CLR_INT_STATUS(QDEC_CLR_INT));

    QDECx->QDEC_INT_CLR |= QDEC_CLR_INT;

    return;
}

/**
 * \brief  Get Qdecoder Axis(x/y/z) direction.
 * \param[in]  QDECx: Selected Qdecoder peripheral.
 * \param[in]  QDEC_AXIS: Specifies the Qdecoder axis.
 *      This parameter parameter can be one of the following values:
 *      \arg  QDEC_AXIS_X: The qdecoder X axis.
 *      \arg  QDEC_AXIS_Y: The qdecoder Y axis.
 *      \arg  QDEC_AXIS_Z: The qdecoder Z axis.
 * \return The direction of the axis.
 *      This parameter parameter can be one of the following values:
 *     \retval QDEC_AXIS_DIR_UP: The axis is rolling up.
 *     \retval QDEC_AXIS_DIR_DOWN: The axis is rolling down.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void qdec_demo(void)
 * {
 *     uint16_t dir = QDEC_GetAxisDirection(QDEC, QDEC_AXIS_X);
 * }
 * \endcode
 */
__STATIC_INLINE uint16_t QDEC_GetAxisDirection(QDEC_TypeDef *QDECx, uint32_t QDEC_AXIS)
{
    /* Check the parameters */
    assert_param(IS_QDEC_PERIPH(QDECx));
    assert_param(IS_QDEC_AXIS_DIR(QDEC_AXIS));

    return ((*((volatile uint32_t *)(&QDECx->QDEC_SR_X) + QDEC_AXIS / 2) &
             QDEC_0X08_CNT_DIR) == QDEC_0X08_CNT_DIR);
}

/**
 * \brief  Get Qdecoder Axis(x/y/z) count.
 * \param[in]  QDECx: Selected Qdecoder peripheral.
 * \param[in]  QDEC_AXIS: Specifies the Qdecoder axis.
 *      This parameter parameter can be one of the following values:
 *      \arg  QDEC_AXIS_X: The qdecoder X axis.
 *      \arg  QDEC_AXIS_Y: The qdecoder Y axis.
 *      \arg  QDEC_AXIS_Z: The qdecoder Z axis.
 * \return The count of the axis.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void qdec_demo(void)
 * {
 *     uint16_t counter = QDEC_GetAxisCount(QDEC, QDEC_AXIS_X);
 * }
 * \endcode
 */
__STATIC_INLINE uint16_t QDEC_GetAxisCount(QDEC_TypeDef *QDECx, uint32_t QDEC_AXIS)
{
    /* Check the parameters */
    assert_param(IS_QDEC_PERIPH(QDECx));
    assert_param(IS_QDEC_AXIS_DIR(QDEC_AXIS));

    return ((uint16_t)(*((volatile uint32_t *)(&QDECx->QDEC_SR_X) + QDEC_AXIS / 2)));
}

/**
 * \brief  Pause or resume Qdecoder Axis(x/y/z).
 * \param[in]  QDECx: Selected Qdecoder peripheral.
 * \param[in]  QDEC_AXIS: Specifies the Qdecoder axis.
 *      This parameter parameter can be one of the following values:
 *      \arg  QDEC_AXIS_X: The qdecoder X axis.
 *      \arg  QDEC_AXIS_Y: The qdecoder Y axis.
 *      \arg  QDEC_AXIS_Z: The qdecoder Z axis.
 * \param[in]  NewState: New state of the specified Qdecoder Axis.
 *      This parameter parameter can be one of the following values:
 *      \arg  ENABLE: Pause.
 *      \arg  DISABLE: Resume.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void qdec_demo(void)
 * {
 *     QDEC_CounterPauseCmd(QDEC, QDEC_AXIS_X, ENABLE);
 * }
 * \endcode
 */
__STATIC_INLINE void QDEC_CounterPauseCmd(QDEC_TypeDef *QDECx, uint32_t QDEC_AXIS,
                                          FunctionalState NewState)
{
    /* Check the parameters */
    assert_param(IS_QDEC_PERIPH(QDECx));
    assert_param(IS_QDEC_AXIS_DIR(QDEC_AXIS));

    if (NewState == ENABLE)
    {
        *((volatile uint32_t *)(&QDECx->QDEC_CR_X) + QDEC_AXIS / 2) |= QDEC_0X00_CNT_PAUSE;
    }
    else
    {
        *((volatile uint32_t *)(&QDECx->QDEC_CR_X) + QDEC_AXIS / 2) &= ~QDEC_0X00_CNT_PAUSE;
    }
}

/** \} */ /* End of group QDEC_Exported_Functions */

#ifdef __cplusplus
}
#endif

#endif /* RTL_QDEC_H */


/******************* (C) COPYRIGHT 2016 Realtek Semiconductor *****END OF FILE****/

