/**
*********************************************************************************************************
*               Copyright(c) 2021, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* \file     rtl876x_enh_tim.h
* \brief    The header file of the peripheral Enhance ENHTIMER driver.
* \details  This file provides all Enhance ENHTIMER firmware functions.
* \author   Echo
* \date     2022-06-16
* \version  v1.0.0
* *********************************************************************************************************
*/

#ifndef _RTL876X_ENH_TIM_H_
#define _RTL876X_ENH_TIM_H_

#ifdef __cplusplus
extern "C" {
#endif

/**
 * \addtogroup  IO          Peripheral Drivers
 * \defgroup    ENHTIM      ENHTIM
 * \brief       Manage the ENHTIM peripheral functions.
 * \ingroup     IO
 */

/*============================================================================*
 *                         Includes
 *============================================================================*/
#include "rtl876x.h"

/* ================================================================================ */
/* ================      ENH_TIM Registers Structures Section      ================ */
/* ================================================================================ */
/**
  * @brief ENHTIMER
  */
typedef struct
{
    __O  uint32_t CUR_CNT;          /*!< 0x00*/
    __O  uint32_t LATCH_CNT0;       /*!< 0x04*/
    __O  uint32_t LATCH_CNT1;       /*!< 0x08*/
    __O  uint32_t LATCH_CNT2;       /*!< 0x0C*/
    __IO uint32_t CR;               /*!< 0x10*/
    __IO uint32_t MAX_CNT;          /*!< 0x14*/
    __IO uint32_t CCR;              /*!< 0x18*/
    __IO uint32_t CCR_FIFO;         /*!< 0x1C*/
} ENHTIM_TypeDef;

/**
  * @brief ENHTIMER
  */
typedef struct
{
    __O  uint32_t FIFO_SR0;         /*!< 0x00*/
    __O  uint32_t FIFO_SR1;         /*!< 0x04*/
    __O  uint32_t FIFO_SR2;         /*!< 0x08*/
    __IO uint32_t FIFO_CLR;         /*!< 0x0C*/
    __IO uint32_t CMD;              /*!< 0x10*/
    __IO uint32_t INT_CMD;          /*!< 0x14*/
    __IO uint32_t INT_SR;           /*!< 0x18*/
    __O  uint32_t MASK_INT_SR;      /*!< 0x1C*/
    __IO uint32_t LC_INT_CMD0;      /*!< 0x20*/
    __IO uint32_t RSVD1;            /*!< 0x24*/
    __IO uint32_t LC_INT_CMD2;      /*!< 0x28*/
    __IO uint32_t RSVD2;            /*!< 0x2C*/
    __O  uint32_t LC_FIFO_LEVEL0;   /*!< 0x30*/
    __O  uint32_t LC_FIFO_LEVEL1;   /*!< 0x34*/
    __O  uint32_t LC_FIFO_LEVEL2;   /*!< 0x38*/
    __O  uint32_t LC_FIFO_LEVEL3;   /*!< 0x3C*/
    __O  uint32_t LC_FIFO_LEVEL4;   /*!< 0x40*/
    __O  uint32_t LC_FIFO_LEVEL5;   /*!< 0x44*/
    __O  uint32_t LC_FIFO_LEVEL6;   /*!< 0x48*/
    __O  uint32_t LC_FIFO_LEVEL7;   /*!< 0x4C*/
    __O  uint32_t TOGGLE_SR;        /*!< 0x50*/
} ENHTIM_ShareTypeDef;

/**
  * @brief ENHTIMER
  */
typedef struct
{
    __IO uint32_t CR;               /*!< 0x00*/
} ENHPWM_TypeDef;

/* ================================================================================ */
/* ================      ENH_TIM Registers Structures Section      ================ */
/* ================================================================================ */
#define ENH_TIM0                        ((ENHTIM_TypeDef           *) ENHANCED_TIMER0_REG_BASE)
#define ENH_TIM1                        ((ENHTIM_TypeDef           *) ENHANCED_TIMER1_REG_BASE)
#define ENH_TIM2                        ((ENHTIM_TypeDef           *) ENHANCED_TIMER2_REG_BASE)
#define ENH_TIM3                        ((ENHTIM_TypeDef           *) ENHANCED_TIMER3_REG_BASE)
#define ENH_TIM4                        ((ENHTIM_TypeDef           *) ENHANCED_TIMER4_REG_BASE)
#define ENH_TIM5                        ((ENHTIM_TypeDef           *) ENHANCED_TIMER5_REG_BASE)
#define ENH_TIM6                        ((ENHTIM_TypeDef           *) ENHANCED_TIMER6_REG_BASE)
#define ENH_TIM7                        ((ENHTIM_TypeDef           *) ENHANCED_TIMER7_REG_BASE)
#define ENH_TIM_SHARE                   ((ENHTIM_ShareTypeDef      *) ENHTIM_SHARE_REG_BASE)
#define ENH_TIM0_PWM                    ((ENHPWM_TypeDef           *) ENHTIM0_PWM_REG_BASE)
#define ENH_TIM1_PWM                    ((ENHPWM_TypeDef           *) ENHTIM1_PWM_REG_BASE)
#define ENH_TIM2_PWM                    ((ENHPWM_TypeDef           *) ENHTIM2_PWM_REG_BASE)
#define ENH_TIM3_PWM                    ((ENHPWM_TypeDef           *) ENHTIM3_PWM_REG_BASE)
#define ENH_TIM4_PWM                    ((ENHPWM_TypeDef           *) ENHTIM4_PWM_REG_BASE)
#define ENH_TIM5_PWM                    ((ENHPWM_TypeDef           *) ENHTIM5_PWM_REG_BASE)
#define ENH_TIM6_PWM                    ((ENHPWM_TypeDef           *) ENHTIM6_PWM_REG_BASE)
#define ENH_TIM7_PWM                    ((ENHPWM_TypeDef           *) ENHTIM7_PWM_REG_BASE)
#define ENH_TIM8_PWM                    ((ENHPWM_TypeDef           *) ENHTIM8_PWM_REG_BASE)

/*============================================================================*
 *                         Constants
 *============================================================================*/

/**
 * \defgroup    ENHTIM_Exported_Constants Macro Definitions
 * \ingroup     ENHTIM
 */
#define IS_ENHTIM_ALL_PERIPH(PERIPH) (((PERIPH) == ENH_ENHTIM0) || \
                                      ((PERIPH) == ENH_ENHTIM1)|| \
                                      ((PERIPH) == ENH_ENHTIM2)|| \
                                      ((PERIPH) == ENH_ENHTIM3)|| \
                                      ((PERIPH) == ENH_ENHTIM4)|| \
                                      ((PERIPH) == ENH_ENHTIM5)|| \
                                      ((PERIPH) == ENH_ENHTIM6)|| \
                                      ((PERIPH) == ENH_ENHTIM7))

/**
 * \defgroup    ENHTIM_Clock_Source ENHTIM Clock Source
 * \{
 * \ingroup     ENHTIM_Exported_Constants
 */
#define ENHTIM_SOURCE_CLOCK_PLL1               ((uint16_t)0x7)
#define ENHTIM_SOURCE_CLOCK_PLL2               ((uint16_t)0x3)
#define ENHTIM_SOURCE_CLOCK_PLL4               ((uint16_t)0x1)
#define ENHTIM_SOURCE_CLOCK_40M                ((uint16_t)0x0)
/** \} */
#define IS_ENHTIM_CLOCK_SOURCE(src) (((src) == ENHTIM_SOURCE_CLOCK_40M) || \
                                     ((src) == ENHTIM_SOURCE_CLOCK_PLL4)|| \\
                                     ((src) == ENHTIM_SOURCE_CLOCK_PLL2)|| \\
                                     ((src) == ENHTIM_SOURCE_CLOCK_PLL1))


/**
 * \defgroup    ENHTIM_DMA_En ENHTIM DMA Enable
 * \{
 * \ingroup     ENHTIM_Exported_Constants
 */
#define ENHTIM_DMA_ENABLE          ((uint16_t)0x1)
#define ENHTIM_DMA_DISABLE         ((uint16_t)0x0)
/** \} */
#define IS_ENHTIM_DMA_En(mode) (((mode) == ENHTIM_DMA_ENABLE) || \
                                ((mode) == ENHTIM_DMA_DISABLE))

/**
 * \defgroup    ENHTIM_DMA_CTRL_MODE ENHTIM DMA Control Mode
 * \{
 * \ingroup     ENHTIM_Exported_Constants
 */
#define ENHTIM_FLOW_CONTROL              ((uint16_t)0x1)
#define ENHTIM_DMAC_FLOW_CONTROL         ((uint16_t)0x0)
/** \} */
#define IS_ENHTIM_DMA_CTRL_MODE (mode) (((mode) == ENHTIM_DMAC_FLOW_CONTROL) || \
                                        ((mode) == ENHTIM_FLOW_CONTROL))

/**
 * \defgroup    ENHTIM_DMA_TARGET ENHTIM DMA TARGET
 * \{
 * \ingroup     ENHTIM_Exported_Constants
 */
#define ENHTIM_DMA_LC_FIFO          ((uint16_t)0x1)
#define ENHTIM_DMA_CCR_FIFO         ((uint16_t)0x0)
/** \} */
#define IS_ENHTIM_DMA_TARGET(mode) (((mode) == ENHTIM_DMA_CCR_FIFO) || \
                                    ((mode) == ENHTIM_DMA_LC_FIFO))


/**
 * \defgroup    ENHTIM_Latch_Count_En ENHTIM Latch Count Enable
 * \{
 * \ingroup     ENHTIM_Exported_Constants
 */
#define ENHTIM_LATCH_COUNT_ENABLE          ((uint16_t)0x1)
#define ENHTIM_LATCH_COUNT_DISABLE         ((uint16_t)0x0)
/** \} */
#define IS_ENHTIM_LATCH_COUNT_En(mode) (((mode) == ENHTIM_LATCH_COUNT_ENABLE) || \
                                        ((mode) == ENHTIM_LATCH_COUNT_DISABLE))

/**
 * \defgroup    ENHTIM_Latch_Trigger_Mode ENHTIM Latch Trigger Mode
 * \{
 * \ingroup     ENHTIM_Exported_Constants
 */
#define ENHTIM_LATCH_TRIGGER_BOTH_EDGE      ((uint16_t)0x02)
#define ENHTIM_LATCH_TRIGGER_FALLING_EDGE   ((uint16_t)0x01)
#define ENHTIM_LATCH_TRIGGER_RISING_EDGE    ((uint16_t)0x00)
/** \} */
#define IS_ENHTIM_LATCH_TRIGGER_Mode(mode) (((mode) == ENHTIM_LATCH_TRIGGER_BOTH_EDGE) || \
                                            ((mode) == ENHTIM_LATCH_TRIGGER_FALLING_EDGE) || \
                                            ((mode) == ENHTIM_LATCH_TRIGGER_RISING_EDGE))

/**
 * \defgroup    ENHTIM_PWM_En ENHTIM PWM Output Enable
 * \{
 * \ingroup     ENHTIM_Exported_Constants
 */
#define ENHTIM_PWM_ENABLE                   ((uint16_t)0x08)
#define ENHTIM_PWM_DISABLE                  ((uint16_t)0x00)
/** \} */
#define IS_ENHTIM_PWM_En(mode) (((mode) == ENHTIM_PWM_ENABLE) || \
                                ((mode) == ENHTIM_PWM_DISABLE))


/**
 * \defgroup    ENHTIM_PWM_Polarity ENHTIM PWM Polarity
 * \{
 * \ingroup     ENHTIM_Exported_Constants
 */
#define ENHTIM_PWM_START_WITH_HIGH          ((uint16_t)0x04)
#define ENHTIM_PWM_START_WITH_LOW           ((uint16_t)0x00)
/** \} */
#define IS_ENHTIM_PWM_POLARITY(pola) (((pola) == ENHTIM_PWM_START_WITH_HIGH) || \
                                      ((pola) == ENHTIM_PWM_START_WITH_LOW))

/**
 * \defgroup    ENHTIM_Mode ENHTIM Mode
 * \{
 * \ingroup     ENHTIM_Exported_Constants
 */
#define ENHTIM_MODE_PWM_MANUAL              ((uint16_t)0x02) /*!< User define pwm manual mode. */
#define ENHTIM_MODE_PWM_AUTO                ((uint16_t)0x01) /*!< User define pwm auto mode. */
#define ENHTIM_MODE_FreeRun                 ((uint16_t)0x00) /*!< User define freerun mode. */
/** \} */
#define IS_ENHTIM_MODE(mode) (((mode) == ENHTIM_MODE_PWM_MANUAL) || \
                              ((mode) == ENHTIM_MODE_PWM_AUTO) || \
                              ((mode) == ENHTIM_MODE_UserDefine))

/**
 * \defgroup    ENHTIM_Interrupts_Definition ENHTIM Interrupts Definition
 * \{
 * \ingroup     ENHTIM_Exported_Constants
 */
#define ENHTIM_INT_TIM                            (0x00)
#define ENHTIM_INT_LATCH_CNT_FIFO_FULL           (0x40)
#define ENHTIM_INT_LATCH_CNT_FIFO_THD            (0x42)

/** \} */

#define IS_ENHTIM_INT(INT) (((INT) == ENHTIM_INT_TIM) || \
                            ((INT) == ENHTIM_INT_LATCH_CNT_FIFO_FULL) || \
                            ((INT) == ENHTIM_INT_LATCH_CNT_FIFO_THD))

/**
 * \defgroup    ENHTIM_FIFO_Flag ENHTIM FIFO Flag
 * \{
 * \ingroup     ENHTIM_Exported_Constants
 */



#define ENHTIM_FLAG_TIM7_LC_FIFO_EMPTY         BIT(15)
#define ENHTIM_FLAG_TIM7_LC_FIFO_FULL          BIT(14)
#define ENHTIM_FLAG_TIM6_LC_FIFO_EMPTY         BIT(13)
#define ENHTIM_FLAG_TIM6_LC_FIFO_FULL          BIT(12)
#define ENHTIM_FLAG_TIM5_LC_FIFO_EMPTY         BIT(11)
#define ENHTIM_FLAG_TIM5_LC_FIFO_FULL          BIT(10)
#define ENHTIM_FLAG_TIM4_LC_FIFO_EMPTY         BIT(9)
#define ENHTIM_FLAG_TIM4_LC_FIFO_FULL          BIT(8)
#define ENHTIM_FLAG_TIM3_LC_FIFO_EMPTY         BIT(7)
#define ENHTIM_FLAG_TIM3_LC_FIFO_FULL          BIT(6)
#define ENHTIM_FLAG_TIM2_LC_FIFO_EMPTY         BIT(5)
#define ENHTIM_FLAG_TIM2_LC_FIFO_FULL          BIT(4)
#define ENHTIM_FLAG_TIM1_LC_FIFO_EMPTY         BIT(3)
#define ENHTIM_FLAG_TIM1_LC_FIFO_FULL          BIT(2)
#define ENHTIM_FLAG_TIM0_LC_FIFO_EMPTY         BIT(1)
#define ENHTIM_FLAG_TIM0_LC_FIFO_FULL          BIT(0)


#define ENHTIM_FLAG_TIM7_CCR_FIFO_EMPTY         BIT(15)
#define ENHTIM_FLAG_TIM7_CCR_FIFO_FULL          BIT(14)
#define ENHTIM_FLAG_TIM6_CCR_FIFO_EMPTY         BIT(13)
#define ENHTIM_FLAG_TIM6_CCR_FIFO_FULL          BIT(12)
#define ENHTIM_FLAG_TIM5_CCR_FIFO_EMPTY         BIT(11)
#define ENHTIM_FLAG_TIM5_CCR_FIFO_FULL          BIT(10)
#define ENHTIM_FLAG_TIM4_CCR_FIFO_EMPTY         BIT(9)
#define ENHTIM_FLAG_TIM4_CCR_FIFO_FULL          BIT(8)
#define ENHTIM_FLAG_TIM3_CCR_FIFO_EMPTY         BIT(7)
#define ENHTIM_FLAG_TIM3_CCR_FIFO_FULL          BIT(6)
#define ENHTIM_FLAG_TIM2_CCR_FIFO_EMPTY         BIT(5)
#define ENHTIM_FLAG_TIM2_CCR_FIFO_FULL          BIT(4)
#define ENHTIM_FLAG_TIM1_CCR_FIFO_EMPTY         BIT(3)
#define ENHTIM_FLAG_TIM1_CCR_FIFO_FULL          BIT(2)
#define ENHTIM_FLAG_TIM0_CCR_FIFO_EMPTY         BIT(1)
#define ENHTIM_FLAG_TIM0_CCR_FIFO_FULL          BIT(0)
/** \} */
#define IS_ENHTIM_CCR_FIFO_FLAG(flag) (((flag) == ENHTIM_FLAG_TIM1_LC_FIFO_EMPTY) || \
                                       ((flag) == ENHTIM_FLAG_TIM0_LC_FIFO_FULL) || \
                                       ((flag) == ENHTIM_FLAG_TIM0_LC_FIFO_EMPTY) || \
                                       ((flag) == ENHTIM_FLAG_TIM2_CCR_FIFO_EMPTY)|| \
                                       ((flag) == ENHTIM_FLAG_TIM2_CCR_FIFO_FULL) || \
                                       ((flag) == ENHTIM_FLAG_TIM1_CCR_FIFO_EMPTY) || \
                                       ((flag) == ENHTIM_FLAG_TIM1_CCR_FIFO_FULL) || \
                                       ((flag) == ENHTIM_FLAG_TIM0_CCR_FIFO_EMPTY) || \
                                       ((flag) == ENHTIM_FLAG_TIM0_CCR_FIFO_FULL) ))

/**
 * \defgroup    PWM_DeadZone_En PWM DeadZone enable
 * \{
 * \ingroup     ENHTIM_Exported_Constants
 */
#define ENHTIM_PWM_DEADZONE_ENABLE          ((uint16_t)0x1)
#define ENHTIM_PWM_DEADZONE_DISABLE         ((uint16_t)0x0)
/** \} */
#define IS_ENHTIM_PWM_DEADZONE_EN(mode) (((mode) == ENHTIM_PWM_DEADZONE_ENABLE) || \
                                         ((mode) == ENHTIM_PWM_DEADZONE_DISABLE))

/**
 * \defgroup    ENHTIM_PWM_DeadZone_Clock_Source ENHTIM PWM DeadZone Clock Source
 * \{
 * \ingroup     ENHTIM_Exported_Constants
 */
#define ENHTIM_PWM_DZCLKSRCE_ENHTIM         ((uint16_t)0x0)
#define ENHTIM_PWM_DZCLKSRCE_32K            ((uint16_t)0x1)
/** \} */
#define IS_ENHTIM_PWM_DEADZONE_EN(mode) (((mode) == ENHTIM_PWM_DEADZONE_ENABLE) || \
                                         ((mode) == ENHTIM_PWM_DEADZONE_DISABLE))

/**
 * \defgroup    ENHTIM_PWM_DeadZone_Stop_State ENHTIM PWM DeadZone Stop State
 * \{
 * \ingroup     ENHTIM_Exported_Constants
 */
#define ENHTIM_PWM_STOP_AT_HIGH             ((uint16_t)0x1)
#define ENHTIM_PWM_STOP_AT_LOW              ((uint16_t)0x0)
/** \} */

/**
 * \defgroup    ENHTIM_FIFO_Clear_Flag ENHTIM FIFO Clear Flag
 * \{
 * \ingroup     ENHTIM_Exported_Constants
 */
#define ENHTIM_FIFO_CLR_CCR                 (0)
#define ENHTIM_FIFO_CLR_CNT0                (24)
/** \} */

/**
 * \defgroup    ENHTIM_Clock_Divider ENHTIM Clock Divider
 * \{
 * \ingroup     ENHTIM_Exported_Constants
 */
typedef enum
{
    ENHTIM_CLOCK_DIVIDER_1   = 0x0,
    ENHTIM_CLOCK_DIVIDER_2   = 0x1,
    ENHTIM_CLOCK_DIVIDER_4   = 0x2,
    ENHTIM_CLOCK_DIVIDER_8   = 0x3,
    ENHTIM_CLOCK_DIVIDER_16  = 0x4,
    ENHTIM_CLOCK_DIVIDER_32  = 0x5,
    ENHTIM_CLOCK_DIVIDER_40  = 0x6,
    ENHTIM_CLOCK_DIVIDER_64  = 0x7,
} E_ENHTIM_CLKDIV;
/** \} */

/**
 * \defgroup    ENHTIM_Latch_Channel_Count ENHTIM Latch Channel Order Number
 * \{
 * \ingroup     ENHTIM_Exported_Constants
 */
typedef enum
{
    LATCH_CNT_0 = 0,
} E_ENHTIM_LATCHCNT;
/** \} */

/*============================================================================*
 *                         Types
 *============================================================================*/

/**
 * \defgroup    ENHTIM_Exported_Types Init Params Struct
 *
 * \ingroup     ENHTIM
 */

/**
 * \brief       ENHTIM init structure definition.
 *
 * \ingroup     ENHTIM_Exported_Types
 */
typedef struct
{
    uint16_t ENHTIM_ClockSource;            /*!< Specifies the ENHTIM clock source.
                                                   This parameter can be a value of \ref ENHTIM_Clock_Source*/
    uint16_t ENHTIM_ClockDiv_En;            /*!< Specifies enable ENHTIM clock source divider .
                                                   This parameter can be a value of DISABLE or ENABLE*/
    E_ENHTIM_CLKDIV ENHTIM_ClockDiv;        /*!< Specifies the ENHTIM clock source div.
                                                 This parameter can be a value of \ref ENHTIM_Clock_Divider*/
    uint16_t ENHTIM_Mode;                   /*!< Specifies the counter mode.
                                                 This parameter can be a value of \ref ENHTIM_Mode. */
    uint16_t ENHTIM_PWMOutputEn;            /*!< Specifies enable Enhtimer PWM oupput.
                                                 This parameter can be a value of DISABLE or ENABLE */
    uint16_t ENHTIM_PWMStartPolarity;       /*!< Specifies the enhtimer toggle output polarity for user-define PWM mode.
                                                  This parameter can be a value of \ref ENHTIM_PWM_Polarity.*/
    uint16_t ENHTIM_LatchCountEn;           /*!< Specifies enbale EnhtimerN Latch_cnt.
                                                 This parameter can be a value of DISABLE or ENABLE */
    uint16_t ENHTIM_LatchCountTrigger;      /*!< Specifies EnhtimerN counter latch trigger mode.
                                                 This parameter can be a value of \ref ENHTIM_Latch_Trigger_Mode */
    uint16_t ENHTIM_LatchCountThd;         /*!< Specifies EnhtimerN latched counter fifo threshold.
                                                 This parameter can be value of  0~0x1F. */
    uint16_t ENHTIM_LatchTriggerPad;        /*!< Specifies the PWM mode.
                                                 This parameter can be a value of P0_0 to P19_0 */
    uint32_t ENHTIM_MaxCount;               /*!< Specifies the Enhtimer max counter value for user-define PWM mode.
                                                 This parameter leagel value range is from 0 ~ 2^32-2. */
    uint32_t ENHTIM_CCValue;                /*!< Specifies the Enhtimer capture/compare value for user-define PWM mode.
                                                     This parameter leagel value range is from 0 ~ 2^32-2*/
    uint16_t ENHTIM_PWMDeadZoneEn;          /*!< Specifies the Enhtimer PWM Deadzone enable.
                                                 This parameter can be a value of ENABLE or DISABLE. */
    uint16_t ENHTIM_PWMDeadZoneClockSource; /*!< Specifies ENHTIM PWM Deadzone Clock Source.
                                                 This parameter can be a value of ENHTIM_PWM_DeadZone_Clock_Source. */
    E_ENHTIM_CLKDIV ENHTIM_PWMDeadZone_ClockDiv;/*!< Specifies ENHTIM PWM Deadzone Clock Source Divider.
                                                 This parameter can be a value of \ref E_ENHTIM_CLKDIV. */
    uint16_t ENHTIM_PWMStopStateP;          /*!< Specifies the ENHTIM PWM P stop state.
                                                 This parameter can be a value of \ref ENHTIM_PWM_DeadZone_Stop_State. */
    uint16_t ENHTIM_PWMStopStateN;          /*!< Specifies the PWM N stop state.
                                                 This parameter can be a value of \ref ENHTIM_PWMDeadZone_Stop_state. */
    uint32_t ENHTIM_DeadZoneSize;           /*!< Specifies the Size of deadzone time, DeadzoneTime=deadzonesize/32000 or 32768.
                                                 This parameter must range from 1 to 0xff. */
    uint16_t ENHTIM_DmaEn;                  /*!< Specifies enable Enhtimer DMA.
                                                 This parameter can be a value of DISABLE or ENABLE. */
//    uint16_t ENHTIM_DmaCtrlMode;            /*!< Specifies Enhtimer DMA Mode.
//                                                 This parameter can be a value of DISABLE or ENABLE. */
    uint16_t ENHTIM_DmaTragget;             /*!< Specifies Enhtimer DMA target.
                                                 This parameter can be a value of \ref ENHTIM_DMA_TARGET. */

} ENHTIM_InitTypeDef;

/*============================================================================*
 *                         Functions
 *============================================================================*/
/**
 * \defgroup    ENHTIM_Exported_Functions  Peripheral APIs
 * \{
 * \ingroup     ENHTIM
 */

/**
 * \brief     Initialize the ENHTIMx unit peripheral according to
 *            the specified parameters in ENHTIM_InitStruct.
 * \param[in] ENHTIMx: Where x can be 0 to 1 to select the ENHTIM peripheral.
 * \param[in] ENHTIM_InitStruct: pointer to a ENHTIM_InitTypeDef structure
  *           that contains the configuration information for the specified ENHTIM peripheral.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_enhance_timer_init(void)
 * {
 *     RCC_PeriphClockCmd(APBPeriph_TIMER, APBPeriph_TIMER_CLOCK, ENABLE);
 *
 *     ENHTIM_InitTypeDef ENHTIM_InitStruct;
 *     ENHTIM_StructInit(&ENHTIM_InitStruct);
 *
 *     ENHTIM_InitStruct.ENHTIM_PWM_En = PWM_DISABLE;
 *     ENHTIM_InitStruct.ENHTIM_Period = 1000000 - 1 ;
 *     ENHTIM_InitStruct.ENHTIM_Mode = ENHTIM_Mode_UserDefine;
 *     ENHTIM_Init(ENHTIMER_NUM, &ENHTIM_InitStruct);
 * }
 * \endcode
 */
void ENHTIM_Init(ENHTIM_TypeDef *ENHTIMx, ENHTIM_InitTypeDef *ENHTIM_TimeBaseInitStruct);
/**
 * \brief       Fills each ENHTIM_InitStruct member with its default value.
 * \param[in]   ENHTIM_TimeBaseInitStruct: Pointer to a ENHTIM_TimeBaseInitTypeDef structure which will be initialized.
 * \return      None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_enhance_timer_init(void)
 * {
 *     RCC_PeriphClockCmd(APBPeriph_ENHTIMER, APBPeriph_ENHTIMER_CLOCK, ENABLE);
 *
 *     ENHTIM_TimeBaseInitTypeDef ENHTIM_InitStruct;
 *     ENHTIM_StructInit(&ENHTIM_InitStruct);
 *
 *     ENHTIM_InitStruct.ENHTIM_PWM_En = PWM_DISABLE;
 *     ENHTIM_InitStruct.ENHTIM_Period = 1000000 - 1;
 *     ENHTIM_InitStruct.ENHTIM_Mode = ENHTIM_Mode_UserDefine;
 *     ENHTIM_TimeBaseInit(ENH_TIM0, &ENHTIM_InitStruct);
 * }
 * \endcode
 */
void ENHTIM_StructInit(ENHTIM_InitTypeDef *ENHTIM_InitStruct);
/**
 * \brief     Enables or disables the specified ENHTIM peripheral.
 * \param[in] ENHTIMx: Where x can be 0 to 1 to select the ENHTIMx peripheral.
 * \param[in] NewState: New state of the ENHTIMx peripheral.
 *            This parameter can be: ENABLE or DISABLE.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_enhance_timer_init(void)
 * {
 *     RCC_PeriphClockCmd(APBPeriph_ENHTIMER, APBPeriph_ENHTIMER_CLOCK, ENABLE);
 *
 *     ENHTIM_InitTypeDef ENHTIM_InitStruct;
 *     ENHTIM_StructInit(&ENHTIM_InitStruct);
 *
 *     ENHTIM_InitStruct.ENHTIM_PWM_En = PWM_DISABLE;
 *     ENHTIM_InitStruct.ENHTIM_Period = 1000000 - 1;
 *     ENHTIM_InitStruct.ENHTIM_Mode = ENHTIM_Mode_UserDefine;
 *     ENHTIM_Init(ENH_TIM0, &ENHTIM_InitStruct);
 *     ENHTIM_Cmd(ENH_TIM0, ENABLE);
 * }
 * \endcode
 */
void ENHTIM_Cmd(ENHTIM_TypeDef *ENHTIMx, FunctionalState NewState);
/**
 * \brief     Enables or disables ENHTIMx interrupt.
 * \param[in] ENHTIMx: Where x can be 0 to 1 to select the ENHTIMx peripheral.
 * \param[in] ENHTIM_INT: Specifies the ENHTIMx interrupt source which to be enabled or disabled.
 *            This parameter can be one of the following values:
 *            \arg ENHTIM_INT_TIM: Enhance Timer interrupt source.
 *            \arg ENHTIM_INT_LATCH_CNT2_FIFO_FULL: Enhance Timer latch count2 fifo full interrupt source.
 *            \arg ENHTIM_INT_LATCH_CNT2_FIFO_EMPTY: Enhance Timer latch count2 fifo empty interrupt source.
 *            \arg ENHTIM_INT_LATCH_CNT2_FIFO_THD: Enhance Timer latch count2 fifo threshold interrupt source.
 * \param[in] NewState: New state of the ENHTIMx peripheral.
 *            This parameter can be: ENABLE or DISABLE.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_enhance_timer_init(void)
 * {
 *     RCC_PeriphClockCmd(APBPeriph_TIMER, APBPeriph_TIMER_CLOCK, ENABLE);
 *
 *     ENHTIM_InitTypeDef ENHTIM_InitStruct;
 *     ENHTIM_StructInit(&ENHTIM_InitStruct);
 *
 *     ENHTIM_InitStruct.ENHTIM_PWM_En = PWM_DISABLE;
 *     ENHTIM_InitStruct.ENHTIM_Period = 1000000 - 1;
 *     ENHTIM_InitStruct.ENHTIM_Mode = ENHTIM_Mode_UserDefine;
 *     ENHTIM_Init(ENH_TIM0, &ENHTIM_InitStruct);
 *     ENHTIM_ClearINT(ENH_TIM0);
 *     ENHTIM_INTConfig(ENH_TIM0, ENABLE);
 */
void ENHTIM_INTConfig(ENHTIM_TypeDef *ENHTIMx, uint8_t ENHTIM_INT, FunctionalState NewState);
/**
 * \brief     Get ENHTIMx current value when timer is running.
 * \param[in] ENHTIMx: where x can be 0 to 1 to select the ENHTIMx peripheral.
 * \return    The counter value.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     uint32_t cur_value = ENHTIM_GetCurrentValue(ENH_TIM0);
 * }
 * \endcode
 */

/**
* \brief     Read ENHTIMx latch counter2 fifo data.
* \param[in] ENHTIMx: Where x can be 0 to 1 to select the ENHTIMx peripheral.
* \param[in] length: Latch count2 fifo length, max 4.
* \pBuf[out] pBuf: FIFO data out buffer.
* \return    None.
*
* <b>Example usage</b>
* \code{.c}
*
* void enhance_timer_demo(void)
* {
*     uint8_t length = ENHTIM_GetLatchCount0FIFOLength(ENH_TIM0);
* }
* \endcode
*/
void ENHTIM_ReadLatchCountFIFO(ENHTIM_TypeDef *ENHTIMx, uint32_t *pBuf, uint8_t length);

/**
 * \brief     Check whether the ENHTIM interrupt has occurred or not.
 * \param[in] ENHTIMx: Where x can be 0 to 1 to select the ENHTIMx peripheral.
 * \param[in] ENHTIM_INT: Specifies the ENHTIMx interrupt source which to be enabled or disabled.
 *            This parameter can be one of the following values:
 *            \arg ENHTIM_INT_TIM: Enhance Timer interrupt source.
 *            \arg ENHTIM_INT_LATCH_CNT2_FIFO_FULL: Enhance Timer latch count2 fifo full interrupt source.
 *            \arg ENHTIM_INT_LATCH_CNT2_FIFO_EMPTY: Enhance Timer latch count2 fifo empty interrupt source.
 *            \arg ENHTIM_INT_LATCH_CNT2_FIFO_THD: Enhance Timer latch count2 fifo threshold interrupt source.
 * \return    The new state of the ENHTIM_INT(SET or RESET).
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     ENHTIM_GetINTStatus(ENH_TIM0, ENHTIM_INT_TIM);
 * }
 * \endcode
 */
ITStatus ENHTIM_GetINTStatus(ENHTIM_TypeDef *ENHTIMx, uint8_t ENHTIM_INT);

/**
 * \brief     Clear ENHTIMx interrupt.
 * \param[in] ENHTIMx: Where x can be 0 to 1 to select the ENHTIMx peripheral.
 * \param[in] ENHTIM_INT: Specifies the ENHTIMx interrupt source which to be enabled or disabled.
 *            This parameter can be one of the following values:
 *            \arg ENHTIM_INT_TIM: Enhance Timer interrupt source.
 *            \arg ENHTIM_INT_LATCH_CNT2_FIFO_FULL: Enhance Timer latch count2 fifo full interrupt source.
 *            \arg ENHTIM_INT_LATCH_CNT2_FIFO_THD: Enhance Timer latch count2 fifo threshold interrupt source.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     ENHTIM_ClearINTPendingBit(ENH_TIM0, ENHTIM_INT_TIM);
 * }
 * \endcode
 */
void ENHTIM_ClearINTPendingBit(ENHTIM_TypeDef *ENHTIMx, uint8_t ENHTIM_INT);

/**
 * \brief     Get ENHTIMx toggle state.
 * \param[in] ENHTIMx: Where x can be 0 to 1 to select the ENHTIMx peripheral.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     bool State=ENHTIM_GetToggleState(ENHTIM0);
 * }
 * \endcode
 */
bool ENHTIM_GetToggleState(ENHTIM_TypeDef *ENHTIMx);


__STATIC_INLINE uint32_t ENHTIM_GetCurrentCount(ENHTIM_TypeDef *ENHTIMx)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

    return ENHTIMx->CUR_CNT;
}

/**
 * \brief     Set Max Count value.
 * \param[in] ENHTIMx: Where x can be 0 to 1 to select the ENHTIMx peripheral.
 * \param[in] count: .
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     ENHTIM_SetMaxCount(ENH_TIM0, 0x10000);
 * }
 * \endcode
 */
__STATIC_INLINE void ENHTIM_SetMaxCount(ENHTIM_TypeDef *ENHTIMx, uint32_t count)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

    ENHTIMx->MAX_CNT = count & 0xFFFFFFFE;
}

/**
 * \brief     Set ENHTIMx capture/compare value for user-define PWM manual mode.
 * \param[in] ENHTIMx: Where x can be 0 to 1 to select the ENHTIMx peripheral.
 * \param[in] value: .
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     ENHTIM_SetCCValue(ENH_TIM0, 0x1000);
 * }
 * \endcode
 */
__STATIC_INLINE void ENHTIM_SetCCValue(ENHTIM_TypeDef *ENHTIMx, uint32_t value)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

    ENHTIMx->CCR = value;
}

/**
 * \brief     Set ENHTIMx capture/compare value for user-define PWM auto mode.
 * \param[in] ENHTIMx: Where x can be 0 to 1 to select the ENHTIMx peripheral.
 * \param[in] value: .
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     ENHTIM_WriteCCFIFO(ENH_TIM0,0x10000);
 * }
 * \endcode
 */
__STATIC_INLINE void ENHTIM_WriteCCFIFO(ENHTIM_TypeDef *ENHTIMx, uint32_t value)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

    ENHTIMx->CCR_FIFO = value;
}


__STATIC_INLINE FlagStatus ENHTIM_GetCCRFIFOFlagStatus(uint32_t ENHTIM_CCR_FLAG)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_FIFO_FLAG(ENHTIM_CCR_FLAG));

    FlagStatus bitstatus = RESET;

    if (ENH_TIM_SHARE->FIFO_SR2 & ENHTIM_CCR_FLAG)
    {
        bitstatus = SET;
    }

    return bitstatus;
}
__STATIC_INLINE FlagStatus ENHTIM_GetLCFIFOFlagStatus(uint32_t ENHTIM_LC_FLAG)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_FIFO_FLAG(ENHTIM_LC_FLAG));

    FlagStatus bitstatus = RESET;

    if (ENH_TIM_SHARE->FIFO_SR1 & ENHTIM_LC_FLAG)
    {
        bitstatus = SET;
    }

    return bitstatus;
}
/**
 * \brief     Enable ENHTIMx latch counter.
 * \param[in] ENHTIMx: where x can be 0 to 1 to select the ENHTIMx peripheral.
 * \param[in] LatchCntIdx: E_ENHTIM_LATCHCNT enum value.
 *            This parameter can be one of follow.
 *            \arg LATCH_COUNT_0: Enhance timer latch count 0.
 *            \arg LATCH_COUNT_1: Enhance timer latch count 1.
 *            \arg LATCH_COUNT_2: Enhance timer latch count 2.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     uint32_t cur_value = ENHTIM_LatchCountEnable(ENH_TIM0, LATCH_COUNT_2);
 * }
 * \endcode
 */
__STATIC_INLINE void ENHTIM_LatchCountEnable(ENHTIM_TypeDef *ENHTIMx, E_ENHTIM_LATCHCNT LatchCntIdx)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

    ENHTIMx->CR |= BIT(LatchCntIdx + 10);
}

/**
 * \brief     Disable ENHTIMx latch counter.
 * \param[in] ENHTIMx: where x can be 0 to 1 to select the ENHTIMx peripheral.
 * \param[in] LatchCntIdx: E_ENHTIM_LATCHCNT enum value.
 *            This parameter can be one of follow.
 *            \arg LATCH_COUNT_0: Enhance timer latch count 0.
 *            \arg LATCH_COUNT_1: Enhance timer latch count 1.
 *            \arg LATCH_COUNT_2: Enhance timer latch count 2.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     uint32_t cur_value = ENHTIM_LatchCountDisable(ENH_TIM0, LATCH_COUNT_2);
 * }
 * \endcode
 */
__STATIC_INLINE void ENHTIM_LatchCountDisable(ENHTIM_TypeDef *ENHTIMx,
                                              E_ENHTIM_LATCHCNT LatchCntIdx)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

    ENHTIMx->CR &= ~BIT(LatchCntIdx + 10);
}

/**
 * \brief     Get ENHTIMx latch count value.
 * \param[in] ENHTIMx: Where x can be 0 to 1 to select the ENHTIMx peripheral.
 * \param[in] LatchCntIdx: E_ENHTIM_LATCHCNT enum value.
 *            This parameter can be one of follow.
 *            \arg LATCH_COUNT_0: Enhance timer latch count 0.
 *            \arg LATCH_COUNT_1: Enhance timer latch count 1.
 *            \arg LATCH_COUNT_2: Enhance timer latch count 2.
 * \return    The latch counter value.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     uint32_t count_value = ENHTIM_GetLatchCountValue(ENH_TIM0, LATCH_COUNT_0);
 * }
 * \endcode
 */
__STATIC_INLINE uint32_t ENHTIM_GetLatchCount(ENHTIM_TypeDef *ENHTIMx,
                                              E_ENHTIM_LATCHCNT LatchCntIdx)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

    uint32_t count = 0;
    count = *(volatile uint32_t *)(&(ENHTIMx->LATCH_CNT0) + LatchCntIdx);
    return count;
}

/**
 * \brief     Get ENHTIMx latch counter2 fifo length.
 * \param[in] ENHTIMx: where x can be 0 to 1 to select the ENHTIMx peripheral.
 * \return    FIFO data length.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     uint8_t length = ENHTIM_GetLatchCount2FIFOLength(ENH_TIM0);
 * }
 * \endcode
 */
__STATIC_INLINE uint8_t ENHTIM_GetLatchCountFIFOLength(ENHTIM_TypeDef *ENHTIMx)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

    uint32_t enhtim_id = ((uint32_t)ENHTIMx - (uint32_t)ENH_TIM0) / 0X24;

    return (uint8_t)(((*((volatile uint32_t *)(&(ENH_TIM_SHARE->LC_FIFO_LEVEL0) + enhtim_id)))) &
                     0xF);
}

/**
 * \brief     Clear capture/compare or latch count2 fifo.
 * \param[in] ENHTIMx: Where x can be 0 to 1 to select the ENHTIMx peripheral.
 * \param[in] FIFO_CLR: Specifies the FIFO type which to be clear.
 *            This parameter can be one of the following values:
 *            \arg ENHTIM_FIFO_CLR_CCR: Enhance Timer CCR FIFO clear flag.
 *            \arg ENHTIM_FIFO_CLR_CNT2: Enhance Timer latch count2 FIFO clear flag.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     ENHTIM_ClearFIFO(ENH_TIM0, ENHTIM_FIFO_CLR_CCR);
 * }
 * \endcode
 */
__STATIC_INLINE void ENHTIM_ClearFIFO(ENHTIM_TypeDef *ENHTIMx, uint8_t FIFO_CLR)
{
    /* Check the parameters */
    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

    uint32_t enhtim_id = ((uint32_t)ENHTIMx - (uint32_t)ENH_TIM0) / 0X24;

    ENH_TIM_SHARE->FIFO_CLR |= (BIT(FIFO_CLR + enhtim_id));
}

/**
 * \brief   ENHTIM PWM complementary output emergency stop.
 * \param   None.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     ENHTIM_PWMDeadZoneEMStop();
 * }
 * \endcode
 */
__STATIC_INLINE void ENHTIM_PWMDeadZoneEMStop(ENHTIM_TypeDef *ENHTIMx)
{
    uint32_t enhtim_id = ((uint32_t)ENHTIMx - (uint32_t)ENH_TIM0) / 0X24;
    if (enhtim_id == 0)
    {
        ENH_TIM0_PWM->CR |= BIT(8);
    }
    else if (enhtim_id == 1)
    {
        ENH_TIM1_PWM->CR |= BIT(8);
    }
    else if (enhtim_id == 2)
    {
        ENH_TIM2_PWM->CR |= BIT(8);
    }
    else if (enhtim_id == 3)
    {
        ENH_TIM3_PWM->CR |= BIT(8);
    }
    else if (enhtim_id == 4)
    {
        ENH_TIM4_PWM->CR |= BIT(8);
    }
    else if (enhtim_id == 5)
    {
        ENH_TIM5_PWM->CR |= BIT(8);
    }
    else if (enhtim_id == 6)
    {
        ENH_TIM6_PWM->CR |= BIT(8);
    }
    else if (enhtim_id == 7)
    {
        ENH_TIM7_PWM->CR |= BIT(8);
    }

}

///**
// * \brief     Get ENHTIM PWM output status.
// * \param[in] ENHTIMx: Where x can be 0 to 1 to select the ENHTIMx peripheral.
// * \return    ENHTIM PWM output status(SET or RESET).
// *
// * <b>Example usage</b>
// * \code{.c}
// *
// * void enhance_timer_demo(void)
// * {
// *     FlagStatus status = ENHTIM_GetPWMOutputState(ENH_TIM0);
// * }
// * \endcode
// */
//__STATIC_INLINE FlagStatus ENHTIM_GetPWMOutputState(ENHTIM_TypeDef *ENHTIMx)
//{
//    /* Check the parameters */
//    assert_param(IS_ENHTIM_ALL_PERIPH(ENHTIMx));

//    uint32_t enhtim_id = ((uint32_t)ENHTIMx - (uint32_t)ENH_TIM0) / 0X24;
//
////    uint32_t status = ENHTIM_LATCH_COUNT_CR & (0x1 << (enhtim_id + 6));
////    return (FlagStatus)(status >> (enhtim_id + 6));
//}

/**
 * \brief     Check whether the ENHTIM interrupt has occurred or not.
 * \param[in] ENHTIMx: Where x can be 0 to 1 to select the ENHTIMx peripheral.
 * \return    The new state of the ENHTIM_IT(SET or RESET).
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void enhance_timer_demo(void)
 * {
 *     ITStatus int_status = ENHTIM_GetINTStatus(ENH_TIM0);
 * }
 * \endcode
 */
__STATIC_INLINE uint32_t ENHTIM_GetAllINTStatus(void)
{
    return ENH_TIM_SHARE->MASK_INT_SR;
}

/** \} */ /* End of group ENHTIM_Exported_Functions */

#ifdef __cplusplus
}
#endif


#endif /*_RTL876X_ENH_TIM_H_*/
