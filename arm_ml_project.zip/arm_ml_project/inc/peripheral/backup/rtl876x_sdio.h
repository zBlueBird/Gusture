/**
*********************************************************************************************************
*               Copyright(c) 2017, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      rtl876x_sdio.h
* @brief     header file of sdio driver.
* @details
* @author   elliot chen
* @date     2017-01-03
* @version   v1.0
* *********************************************************************************************************
*/

#ifndef _RTL876x_SDIO_H_
#define _RTL876x_SDIO_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "rtl876x.h"
#include "rtl_sdio_reg.h"

/* SDIO Registers Structures Section  ----------------------------------------*/
#define SDIO_CTRL_CONTROLLER_RESET                 ((uint32_t)(1 << 0))
#define SDIO_CTRL_FIFO_RESET                       ((uint32_t)(1 << 1))
#define SDIO_CTRL_DMA_RESET                        ((uint32_t)(1 << 2))
#define SDIO_CTRL_INT_ENABLE                       ((uint32_t)(1 << 4))
#define SDIO_CTRL_DMA_ENABLE                       ((uint32_t)(1 << 5))

//#define SDIO_CLKSRC_DIV0                           0x00
//#define SDIO_CLKSRC_DIV1                           0x01
//#define SDIO_CLKSRC_DIV2                           0x02
//#define SDIO_CLKSRC_DIV3                           0x03

#define CMD0_GO_IDLE_STATE                      (0u)   /*!< Resets the SD memory card.                                                               */
#define CMD1_SEND_OP_COND                       (1u)   /*!< Sends host capacity support information and activates the card's initialization process. */
#define CMD2_ALL_SEND_CID                       (2u)   /*!< Asks any card connected to the host to send the CID numbers on the CMD line.             */
#define CMD3_SEND_RELATIVE_ADDR                 (3u)   /*!< Asks the card to publish a new relative address (RCA).                                   */
#define CMD_SET_DSR                             (4u)   /*!< Programs the DSR of all cards.                                                           */
#define CMD_SDMMC_SEN_OP_COND                   (5u)   /*!< Sends host capacity support information (HCS) and asks the accessed card to send its
                                                            operating condition register (OCR) content in the response on the CMD line.              */

//*******************bee3 pro use***/
#define SDIO_CMD_START_CMD               ((uint32_t)1 << 31)
#define SDIO_CMD_USE_HOLD_REG            ((uint32_t)1 << 29)
#define SDIO_CMD_VOLT_SWITCH             ((uint32_t)1 << 28)
#define SDIO_CMD_BOOT_MODE               ((uint32_t)1 << 27)
#define SDIO_CMD_DISABLE_BOOT            ((uint32_t)1 << 26)
#define SDIO_CMD_EXPECT_BOOT_ACK         ((uint32_t)1 << 25)
#define SDIO_CMD_ENABLE_BOOT             ((uint32_t)1 << 24)
#define SDIO_CMD_CCS_EXPECTED            ((uint32_t)1 << 23)
#define SDIO_CMD_READ_CEATA_DEVICE       ((uint32_t)1 << 22)
#define SDIO_CMD_UP_CLK_REG_ONLY         ((uint32_t)1 << 21)
#define SDIO_CMD_SEND_INITIALIZATION     ((uint32_t)1 << 15)
#define SDIO_CMD_STOP_ABORT_CMD          ((uint32_t)1 << 14)
#define SDIO_CMD_WAIT_PRVDATA_COMPLETE   ((uint32_t)1 << 13)
#define SDIO_CMD_SEND_AUTO_STOP          ((uint32_t)1 << 12)
#define SDIO_CMD_TRANSFER_MODE           ((uint32_t)1 << 11)
#define SDIO_CMD_READ_WRITE              ((uint32_t)1 << 10)
#define SDIO_CMD_DATA_EXPECT             ((uint32_t)1 << 9)
#define SDIO_CMD_CHECK_RESP_CRC          ((uint32_t)1 << 8)
#define SDIO_CMD_RESP_LENGTH             ((uint32_t)1 << 7)
#define SDIO_CMD_RESP_EXPECT             ((uint32_t)1 << 6)

#define SDIO_RINTSTS_EBE                 BIT(15) /*end bit errror*/
#define SDIO_RINTSTS_ACD                 BIT(14) /**/
#define SDIO_RINTSTS_SBE                 BIT(13)
#define SDIO_RINTSTS_BCI                 BIT(13)
#define SDIO_RINTSTS_HLE                 BIT(12)
#define SDIO_RINTSTS_FRUN                BIT(11)
#define SDIO_RINTSTS_HTO                 BIT(10)
#define SDIO_RINTSTS_DRTO                BIT(9)
#define SDIO_RINTSTS_BDS                 BIT(9)
#define SDIO_RINTSTS_RTO                 BIT(8)
#define SDIO_RINTSTS_BAR                 BIT(8)
#define SDIO_RINTSTS_DCRC                BIT(7)
#define SDIO_RINTSTS_RCRC                BIT(6)
#define SDIO_RINTSTS_RXDR                BIT(5)
#define SDIO_RINTSTS_TXDR                BIT(4)
#define SDIO_RINTSTS_DTO                 BIT(3)
#define SDIO_RINTSTS_CD                  BIT(2)
#define SDIO_RINTSTS_RE                  BIT(1)
#define SDIO_RINTSTS_CDT                 BIT(0)
typedef struct rtk_sdmmc_resp_card_status
{
    uint32_t    RESERVE1            : 3;    ///< RESERVE
    uint32_t    AKE_SEQ_ERROR       : 1;    ///< Error in the sequence of the authentication process
    uint32_t    RESERVE2            : 1;    ///< RESERVE
uint32_t    EXPECT_ACMD         :
    1;    ///< The card will expect ACMD, or an indication that the command has been interpreted as ACMD
    uint32_t    RESERVE3            : 2;    ///< RESERVE
    uint32_t    READY_FOR_DATA      : 1;    ///< Corresponds to buffer empty signaling on the bus
    uint32_t    CURRENT_STATE       : 4;    ///< The state of the card when receiving the command.

uint32_t    ERASE_RESET         :
    1;    ///< An erase sequence was cleared before executing because an out of erase sequence command was received
uint32_t    CARD_ECC_DISABLE    :
    1;    ///< The command has been executed without using the internal ECC.
uint32_t    WP_ERASE_SKIP       :
    1;    ///< Set when only partial address space was erased due to existing write protected blocks or the temporary or permanent write protected card was erased.
uint32_t    CSD_OVERWRITE       :
    1;    ///< - The read only section of the CSD does not match the card content.
    ///< - An attempt to reverse the copy (set as original) or permanent WP (unprotected) bits was made.
    uint32_t    RESERVE4            : 2;    ///< RESERVE
uint32_t    ERRORR              :
    1;    ///< A general or an unknown error occurred during the operation.
    uint32_t    CC_ERROR            : 1;    ///< Internal card controller error
uint32_t    CARD_ECC_FAIL       :
    1;    ///< Card internal ECC was applied but failed to correct the data.
    uint32_t    ILLEGAL_CMD         : 1;    ///< Command not legal for the card state
    uint32_t    COM_CRC_ERROR       : 1;    ///< The CRC check of the previous command failed.
uint32_t    LOCK_UNLOCK_FAIL    :
    1;    ///< Set when a sequence or password error has been detected in lock/unlock card command.
    uint32_t    CARD_IS_LOCKED      : 1;    ///< When set, signals that the card is locked by the host
uint32_t    WP_VIOLATION        :
    1;    ///< Set when the host attempts to write to a protected block or to the temporary or permanent write protected card.
uint32_t    ERASE_PARAM         :
    1;    ///< An invalid selection of write-blocks for erase occurred.
    uint32_t    ERASE_SEQ_ERR       : 1;    ///< An error in the sequence of erase commands occurred.
uint32_t    BLOCK_LEN_ERR       :
    1;    ///< The transferred block length is not allowed for this card, or the number of transferred bytes does not match the block length.
uint32_t    ADDRESS_ERROR       :
    1;    ///< A misaligned address which did not match the block length was used in the command.
uint32_t    OUT_OF_RANGE        :
    1;    ///< The command's argument was out of the allowed range for this card.
} rtk_sdmmc_resp_card_status_t;

/** @defgroup SDIO_BusWide SDIO bus Wide
  * @{
  */

#define SDIO_BusWide_1b                     ((uint32_t)0x00)
#define SDIO_BusWide_4b                     ((uint32_t)0x02)

#define IS_SDIO_BUS_WIDE(WIDE) (((WIDE) == SDIO_BusWide_1b) || ((WIDE) == SDIO_BusWide_4b))

/** End of group SDIO_BusWide
  * @}
  */

#if 0
/* Peripheral: SDIO */
/* Description: SDIO register defines */

/* Register: TF_MODE --------------------------------------------------*/
/* Description: Transfer mode Register. Offset: 0x0C. Address: 0x4005C00CUL. */
/* TF_MODE[5] :SDIO_MULTI_BLOCK. */
#define SDIO_MULTI_BLOCK_EN                 BIT(5)
#define SDIO_AUTO_CMD12_EN                  BIT(2)
#define SDIO_BLOCK_COUNT_EN                 BIT(1)

/* Register: PRESENT_STATE --------------------------------------------------*/
/* Description: Present State Register. Offset: 0x24. Address: 0x4005C024UL. */
/* PRESENT_STATE[1] :SDIO_DAT_INHIBIT. */
#define SDIO_DAT_INHIBIT                    BIT(1)
/* PRESENT_STATE[0] :SDIO_CMD_INHIBIT. */
#define SDIO_CMD_INHIBIT                    BIT(0)

/* Register: PWR_CTRL ------------------------------------------------------*/
/* Description: Power control register. Offset: 0x29. Address: 0x4005C029UL. */
/* PWR_CTRL[3:1] :SDIO_BUS_VOLTAGE. */
#define SDIO_BUS_VOLTAGE_POS                (1UL)
#define SDIO_BUS_VOLTAGE_MASK               (0x1UL << SDIO_BUS_VOLTAGE_POS)
#define SDIO_BUS_VOLTAGE_CLR                (~SDIO_BUS_VOLTAGE_MASK)
#define SDIO_VOLT_3_3V                      ((uint32_t)7 << SDIO_BUS_VOLTAGE_POS)
#define SDIO_VOLT_3_0V                      ((uint32_t)6 << SDIO_BUS_VOLTAGE_POS)
#define SDIO_VOLT_1_8V                      ((uint32_t)5 << SDIO_BUS_VOLTAGE_POS)
/* PWR_CTRL[0] :SDIO_BUS_PWR. 0x1: Power on. 0x0: Power down. */
#define SDIO_BUS_PWR_POS                    (0UL)
#define SDIO_BUS_PWR_MASK                   (0x1UL << SDIO_BUS_PWR_POS)
#define SDIO_BUS_PWR_CLR                    (~SDIO_BUS_PWR_MASK)

/* Register: CLK_CTRL -------------------------------------------------------*/
/* Description: clock control register. Offset: 0x2C. Address: 0x4005C02CUL. */
/* CLK_CTRL[1] :SDIO_INTERNAL_CLOCK_STABLE. 0x1: Enable. 0x0: Disable. */
#define SDIO_INTERNAL_CLK_STABLE_POS        (1UL)
#define SDIO_INTERNAL_CLK_STABLE_MASK       (0x1UL << SDIO_INTERNAL_CLK_STABLE_POS)
#define SDIO_INTERNAL_CLK_STABLE_CLR        (~SDIO_INTERNAL_CLK_STABLE_MASK)
/* CLK_CTRL[0] :SDIO_INTERNAL_CLOCK. 0x1: Enable. 0x0: Disable. */
#define SDIO_INTERNAL_CLOCK_POS             (0UL)
#define SDIO_INTERNAL_CLOCK_MASK            (0x1UL << SDIO_INTERNAL_CLOCK_POS)
#define SDIO_INTERNAL_CLOCK_CLR             (~SDIO_INTERNAL_CLOCK_MASK)

/* Register: SW_RESET -------------------------------------------------------*/
/* Description: Software reset register. Offset: 0x2F. Address: 0x4005C02FUL. */
/* SW_RESET[0] :SDIO_SF_RESET. 0x1: Reset. 0x0: Work. */
#define SDIO_SF_RESET_POS                   (0UL)
#define SDIO_SF_RESET_MASK                  (0x1UL << SDIO_SF_RESET_POS)
#define SDIO_SF_RESET_CLR                   (~SDIO_SF_RESET_MASK)

/* Register: CAPABILITIES_L ---------------------------------------------------*/
/* Description: Capabilities Register. Offset: 0x40. Address: 0x4005C040UL. */
#define SDIO_CAPA_TIMEOUT_CLK_UNIT          BIT(7)
#define SDIO_CAPA_ADMA2_SUPPORT             BIT(19)
#define SDIO_CAPA_HIGH_SPEED_SUPPORT        BIT(21)
#define SDIO_CAPA_VOLT_SUPPORT_33V          BIT(24)
#define SDIO_CAPA_VOLT_SUPPORT_30V          BIT(25)
#define SDIO_CAPA_VOLT_SUPPORT_18V          BIT(26)


/** @addtogroup SDIO SDIO
  * @brief SDIO driver module
  * @{
  */

/*============================================================================*
 *                         Types
 *============================================================================*/
#endif
/** @defgroup SDIO_Exported_Types SDIO Exported Types
  * @{
  */

/**
 * @brief SDIO initialize parameters
 *
 *
 */
typedef struct
{
    uint32_t SDIO_ClockDiv;         /*!< Specifies the clock frequency of the SDIO controller.
                                    This parameter can be a value of @ref SDIO_ClockDiv*/

    uint32_t SDIO_TimeOut;          /*!< Specifies whether the SDIO time out.
                                    This parameter must range from 0 to 14. */

    uint32_t SDIO_BusWide;          /*!< Specifies the SDIO bus width. */

    uint32_t DMA_en;          /*!< Specifies the DMA is enable. */

} SDIO_InitTypeDef;

/**
 * @brief SDIO command initialize parameters
 *
 *
 */
typedef struct
{
    uint32_t SDIO_Argument;         /*!< Specifies the command argument */

    uint32_t SDIO_CmdIndex;         /*!< Specifies the command number.
                                    This parameter can be a value of 0 to 63*/

    uint32_t SDIO_Use_Hold_Reg;    /*!< Specifies data/cmd sent to card through the hold reg .
                                    This parameter can be a value of ENABLE or DISABLE*/

    uint32_t SDIO_Send_Initialzation;          /*!< Specifies send initialization sequence(80 clk of 1) before cmd .
                                    This parameter can be a value of ENABLE or DISABLE*/

    uint32_t SDIO_Send_Auto_Stop;    /*!< Specifies send stop cmd at end of data transfer.
                                    This parameter can be a value of ENABLE or DISABLE*/

    uint32_t SDIO_Transfer_mode;    /*!< Specifies Block data or Stream data transfer cmd.
                                    This parameter can be a value of @ref Transfer_mode*/

    uint32_t SDIO_Read_Write;    /*!< Specifies data transfer is read or write.
                                    This parameter can be a value of @ref Read_Write*/

    uint32_t SDIO_DataExpect;      /*!< Specifies data tansfer expect.
                                    This parameter can be a value of @ref DATA_Expect_SEL*/

    uint32_t SDIO_Check_Response_Crc;      /*!< Specifies check response crc.
                                    This parameter can be a value of ENABLE or DISABLE*/

    uint32_t SDIO_Responce_Length;    /*!< Specifies Long or short response expect from card.
                                    This parameter can be a value of @ref SDIO_RSP_LENGTH*/

    uint32_t SDIO_ResponseExpect;    /*!< Specifies response expect from card.
                                    This parameter can be a value of @ref Response_Expect_SEL*/

} SDIO_CmdInitTypeDef;

typedef enum
{
    NO_DATA,
    WITH_DATA
} DATA_Expect_SEL;

typedef enum
{
    BLOCK_DATA,
    STREAM_DATA
} Transfer_mode;

typedef enum
{
    DATA_READ,
    DATA_WRITE
} Read_Write;

typedef enum
{
    NO_RESPONSE,
    WITH_RESPONSE
} Response_Expect_SEL;

typedef enum
{
    RSP_LEN_SHORT,
    RSP_LEN_LONG,
} SDIO_RSP_LENGTH;

typedef enum
{
    Fsm_Idle,
    Send_init_sequence,
    Tx_cmd_start_bit,
    Tx_cmd_tx_bit,
    Tx_cmd_index_arg,
    Tx_cmd_crc7,
    Tx_cmd_end_bit,
    Rx_resp_start_bit,
    Rx_resp_irq_response,
    RX_resp_tx_bit,
    Rx_resp_cmd_idx,
    Rx_resp_data,
    Rx_resp_crc7,
    Rx_resp_end_bit,
    Cmd_path_wait_ncc,
    Cmd_resp_turnround,
} SdFsmStatus;


#define SDIO_RSP0                          ((uint32_t)0x00000000)
#define SDIO_RSP1                          ((uint32_t)0x00000004)
#define SDIO_RSP2                          ((uint32_t)0x00000008)
#define SDIO_RSP3                          ((uint32_t)0x0000000C)
#if 0

/**
 * @brief SDIO data transmission initialize parameters
 *
 *
 */
typedef struct
{
    uint32_t SDIO_Address;      /*!< Specifies the start address of the Descriptor table.
                                    This parameter can be a value 4 aligned address */

    uint32_t SDIO_BlockSize;    /*!< Specifies the block size of data trnasfers for CMD17,
                                    CMD18, CMD24, CMD25 and CMD53, in the case of high capacity
                                    memory card, the size of data block is fixed to 512 bytes.
                                    This parameter can be a value of 0 to 0x800 */

    uint32_t SDIO_BlockCount;   /*!< Specifies the block count for current transfer.
                                    This parameter can be a value of 0 to 0xffff */

    uint32_t SDIO_TransferDir;  /*!< Specifies the data transfer direction of DAT line data transfers.
                                    This parameter can be a value of @ref IS_SDIO_TRANSFER_DIR*/

    uint32_t SDIO_TransferMode; /*!< Specifies the transfer mode. */

    uint32_t SDIO_DMAEn;        /*!< Specifies whether to enable dma functionlity.
                                    This parameter can be a value of ENABLE or DISABLE */

} SDIO_DataInitTypeDef;

/**
 * @brief ADMA2 descriptor attribute initialize parameters
 *
 *
 */
typedef struct
{
    uint16_t SDIO_Valid: 1;
    uint16_t SDIO_End: 1;
    uint16_t SDIO_Int: 1;
    uint16_t SDIO_Rsvd1: 1;
    uint16_t SDIO_Act1: 1;
    uint16_t SDIO_Act2: 1;
    uint16_t SDIO_Rsvd2: 10;
} ADMA2_AttrTypedef;

/**
 * @brief ADMA2 descriptor table initialize parameters
 *
 *
 */
typedef struct
{
    ADMA2_AttrTypedef SDIO_Attribute;
    uint16_t SDIO_Length;
    uint32_t SDIO_Address;
} SDIO_ADMA2TypeDef;

/** End of group SDIO_Exported_Types
  * @}
  */

/*============================================================================*
 *                         Constants
 *============================================================================*/

/** @defgroup SDIO_Exported_Constants SDIO Exported Constants
  * @{
  */

#define IS_SDIO_PERIPH(PERIPH) ((PERIPH) == SDIO)

/** @defgroup SDIO_Pin_Group SDIO Pin Group
  * @{
  */

#define SDIO_PinGroup_0                     ((uint32_t)0x00000000)
#define SDIO_PinGroup_1                     ((uint32_t)0x00000001)

#define IS_SDIO_PINGROUP_IDX(IDX) (((IDX) == SDIO_PinGroup_0) || ((IDX) == SDIO_PinGroup_1))

/** End of group SDIO_Pin_Group
  * @}
  */

/** @defgroup SDIO_Power_State SDIO Power state
  * @{
  */

#define SDIO_PowerState_OFF                 ((uint32_t)0x00000000)
#define SDIO_PowerState_ON                  ((uint32_t)0x00000001)

#define IS_SDIO_POWER_STATE(STATE) (((STATE) == SDIO_PowerState_OFF) || ((STATE) == SDIO_PowerState_ON))

/** End of group SDIO_Power_State
  * @}
  */

/** @defgroup SDIO_ClockDiv SDIO ClockDiv
  * @{
  */

#define SDIO_CLOCK_DIV_1                    ((uint32_t)((0x0) << 8))
#define SDIO_CLOCK_DIV_2                    ((uint32_t)((0x1) << 8))
#define SDIO_CLOCK_DIV_4                    ((uint32_t)((0x2) << 8))
#define SDIO_CLOCK_DIV_8                    ((uint32_t)((0x4) << 8))
#define SDIO_CLOCK_DIV_16                   ((uint32_t)((0x8) << 8))
#define SDIO_CLOCK_DIV_32                   ((uint32_t)((0x10) << 8))
#define SDIO_CLOCK_DIV_64                   ((uint32_t)((0x20) << 8))
#define SDIO_CLOCK_DIV_128                  ((uint32_t)((0x40) << 8))
#define SDIO_CLOCK_DIV_256                  ((uint32_t)((0x80) << 8))

#define IS_SDIO_CLOCK_DIV(CTRL)         (((CTRL) == SDIO_CLOCK_DIV_1) || \
                                         ((CTRL) == SDIO_CLOCK_DIV_2) || \
                                         ((CTRL) == SDIO_CLOCK_DIV_4) || \
                                         ((CTRL) == SDIO_CLOCK_DIV_8) || \
                                         ((CTRL) == SDIO_CLOCK_DIV_16) || \
                                         ((CTRL) == SDIO_CLOCK_DIV_32) || \
                                         ((CTRL) == SDIO_CLOCK_DIV_64) || \
                                         ((CTRL) == SDIO_CLOCK_DIV_128) || \
                                         ((CTRL) == SDIO_CLOCK_DIV_256))

/** End of group SDIO_ClockDiv
  * @}
  */

/** @defgroup SDIO_BusWide SDIO bus Wide
  * @{
  */

#define SDIO_BusWide_1b                     ((uint32_t)0x00)
#define SDIO_BusWide_4b                     ((uint32_t)0x02)

#define IS_SDIO_BUS_WIDE(WIDE) (((WIDE) == SDIO_BusWide_1b) || ((WIDE) == SDIO_BusWide_4b))

/** End of group SDIO_BusWide
  * @}
  */

/** @defgroup SDIO_TimeOut SDIO TimeOut
  * @{
  */

#define IS_SDIO_TIME_OUT(TIME) ((TIME) <= 0x0E)

/** End of group SDIO_TimeOut
  * @}
  */

/** @defgroup SDIO_Block_Size SDIO Block Size
  * @{
  */

#define IS_SDIO_BLOCK_SIZE(SIZE)            ((SIZE) <= 0x800)

/** End of group SDIO_Block_Size
  * @}
  */

/** @defgroup SDIO_Block_COUNT SDIO Block Count
  * @{
  */

#define IS_SDIO_BLOCK_COUNT(COUNT)          ((COUNT) <= 0xFFFF)

/** End of group SDIO_Block_COUNT
  * @}
  */

/** @defgroup SDIO_Transfer_Direction
  * @{
  */

#define SDIO_TransferDir_READ               ((uint32_t)1 << 4)
#define SDIO_TransferDir_WRITE              ((uint32_t)0x00)
#define IS_SDIO_TRANSFER_DIR(DIR) (((DIR) == SDIO_TransferDir_READ) || \
                                   ((DIR) == SDIO_TransferDir_WRITE))
/** End of group SDIO_Transfer_Direction
  * @}
  */

/** @defgroup SDIO_Command_Index
  * @{
  */

#define IS_SDIO_CMD_INDEX(INDEX)            ((INDEX) < 0x40)

/** End of group SDIO_Command_Index
  * @}
  */

/** @defgroup SDIO_RSP_TYPE
  * @{
  */

typedef enum
{
    NORMAL,
    SUSPEND,
    RESUME,
    ABORT
} SDIO_CMD_TYPE;

/** End of group SDIO_RSP_TYPE
  * @}
  */

/** @defgroup SDIO_RSP_TYPE
  * @{
  */


/** End of group SDIO_RSP_TYPE
  * @}
  */

/** @defgroup SDIO_RSP_TYPE
  * @{
  */

typedef enum
{
    SDIO_Response_No,
    RSP_LEN_136,
    RSP_LEN_48,
    RSP_LEN_48_CHK_BUSY
} SDIO_RSP_TYPE;

/** End of group SDIO_RSP_TYPE
  * @}
  */

/** @defgroup SDIO_Interrupts_definition SDIO Interrupt Definition
  * @{
  */
#define SDIO_INT_ERROR                      ((uint32_t)1 << 15)
#define SDIO_INT_CARD                       ((uint32_t)1 << 8)
#define SDIO_CARD_REMOVAL                   ((uint32_t)1 << 7)
#define SDIO_CARD_INSERT                    ((uint32_t)1 << 6)
#define SDIO_BUF_READ_RDY                   ((uint32_t)1 << 5)
#define SDIO_BUF_WRITE_RDY                  ((uint32_t)1 << 4)
#define SDIO_INT_DMA                        ((uint32_t)1 << 3)
#define SDIO_BLOCK_GAP_EVENT                ((uint32_t)1 << 2)
#define SDIO_INT_TF_CMPL                    ((uint32_t)1 << 1)
#define SDIO_INT_CMD_CMPL                   ((uint32_t)1 << 0)

#define IS_SDIO_INT(INT) (((INT)  == SDIO_INT_ERROR)        || \
                          ((INT)  == SDIO_INT_CARD)       || \
                          ((INT)  == SDIO_INT_DMA)        || \
                          ((INT)  == SDIO_INT_TF_CMPL)    || \
                          ((INT)  == SDIO_INT_CMD_CMPL))

/** End of group SDIO_Interrupts_definition
  * @}
  */

/** @defgroup SDIO_Interrupts_definition SDIO Interrupt Definition
  * @{
  */
#define SDIO_INT_VENDOR_SPECIFIC_ERR        ((uint32_t)0xF << 12)
#define SDIO_INT_ADMA_ERR                   ((uint32_t)1 << 9)
#define SDIO_INT_AUTO_CMD12_ERR             ((uint32_t)1 << 8)
#define SDIO_INT_CURRENT_LIMIT_ERR          ((uint32_t)1 << 7)
#define SDIO_INT_DAT_END_BIT_ERR            ((uint32_t)1 << 6)
#define SDIO_INT_DAT_CRC_ERR                ((uint32_t)1 << 5)
#define SDIO_INT_DAT_TIMEOUT_ERR            ((uint32_t)1 << 4)
#define SDIO_INT_CMD_INDEX_ERR              ((uint32_t)1 << 3)
#define SDIO_INT_CMD_END_BIT_ERR            ((uint32_t)1 << 2)
#define SDIO_INT_CMD_CRC_ERR                ((uint32_t)1 << 1)
#define SDIO_INT_CMD_TIMEOUT_ERR            ((uint32_t)1 << 0)

#define IS_SDIO_ERR_INT(INT) (((INT)  == SDIO_INT_VENDOR_SPECIFIC_ERR)  || \
                              ((INT)  == SDIO_INT_ADMA_ERR)           || \
                              ((INT)  == SDIO_INT_AUTO_CMD12_ERR)     || \
                              ((INT)  == SDIO_INT_CURRENT_LIMIT_ERR)  || \
                              ((INT)  == SDIO_INT_DAT_END_BIT_ERR)    || \
                              ((INT)  == SDIO_INT_DAT_CRC_ERR)        || \
                              ((INT)  == SDIO_INT_DAT_TIMEOUT_ERR)    || \
                              ((INT)  == SDIO_INT_CMD_INDEX_ERR)      || \
                              ((INT)  == SDIO_INT_CMD_END_BIT_ERR)    || \
                              ((INT)  == SDIO_INT_CMD_CRC_ERR)        || \
                              ((INT)  == SDIO_INT_CMD_TIMEOUT_ERR))

/** End of group SDIO_Interrupts_definition
  * @}
  */

/** @defgroup SDIO_Wake_Up_definition SDIO Wake Up Definition
  * @{
  */

#define SDIO_WAKE_UP_SDCARD_REMOVAL         ((uint32_t)1 << 2)
#define SDIO_WAKE_UP_SDCARD_INSERT          ((uint32_t)1 << 1)
#define SDIO_WAKE_UP_SDCARD_INTR            ((uint32_t)1 << 0)


#define IS_SDIO_WAKE_UP(EVT) (((EVT)  == SDIO_WAKE_UP_SDCARD_REMOVAL)   || \
                              ((EVT)  == SDIO_WAKE_UP_SDCARD_INSERT)  || \
                              ((EVT)  == SDIO_WAKE_UP_SDCARD_INTR))

/** End of group SDIO_Wake_Up_definition
  * @}
  */

/** @defgroup SDIO_Flag SDIO Flag
  * @{
  */

#define SDIO_FLAG_BUF_READ_EN               ((uint32_t)1 << 11)
#define SDIO_FLAG_WRITE_BUF_EN              ((uint32_t)1 << 10)
#define SDIO_FLAG_READ_TF_ACTIVE            ((uint32_t)1 << 9)
#define SDIO_FLAG_WRITE_TF_ACTIVE           ((uint32_t)1 << 8)
#define SDIO_FLAG_DAT_LINE_ACTIVE           ((uint32_t)1 << 2)
#define SDIO_FLAG_CMD_DAT_INHIBIT           ((uint32_t)1 << 1)
#define SDIO_FLAG_CMD_INHIBIT               ((uint32_t)1 << 0)

#define IS_SDIO_FLAG(FLAG) (((FLAG)  == SDIO_FLAG_BUF_READ_EN)      || \
                            ((FLAG)  == SDIO_FLAG_WRITE_BUF_EN)     || \
                            ((FLAG)  == SDIO_FLAG_READ_TF_ACTIVE)   || \
                            ((FLAG)  == SDIO_FLAG_WRITE_TF_ACTIVE)  || \
                            ((FLAG)  == SDIO_FLAG_DAT_LINE_ACTIVE)  || \
                            ((FLAG)  == SDIO_FLAG_CMD_DAT_INHIBIT)  || \
                            ((FLAG)  == SDIO_FLAG_CMD_INHIBIT))

/** End of group SDIO_Flag
  * @}
  */

/** @defgroup SDIO_RSP_REG SDIO Response Register
  * @{
  */


/** End of group SDIO_RSP_REG
  * @}
  */

/** End of group SDIO_Exported_Constants
  * @}
  */

/*============================================================================*
 *                         Functions
 *============================================================================*/

/** @defgroup SDIO_Exported_Functions SDIO Exported Functions
  * @{
  */

/**
  * @brief  Enables or disables the SDIO output pin.
  * @param  NewState: new state of the SDIO output pin.
  *   This parameter can be the following values:
  *     @arg ENABLE:  enable sdio pin output.
  *     @arg DISABLE: disable sdio pin output.
  * @retval None
  */
void SDIO_PinOutputCmd(FunctionalState NewState);

/**
  * @brief  Select the SDIO output pin group.
  * @param  SDIO_PinGroupType:
  *  This parameter can be one of the following values:
  *  @arg SDIO_PinGroup_0
  *  @arg SDIO_PinGroup_1
  * @retval None
  */
void SDIO_PinGroupConfig(uint32_t SDIO_PinGroupType);

/**
  * @brief  Select the SDIO data bus pin.
  * @param  SDIO_BusWide:
    This parameter can be one of the following values:
  *  @arg SDIO_BusWide_1b
  *  @arg SDIO_BusWide_4b
  * @param  NewState: new state of the SDIO data pin.
    This parameter can be: ENABLE or DISABLE.
  * @retval None
  */
void SDIO_DataPinConfig(uint32_t SDIO_BusWide, FunctionalState NewState);

/**
  * @brief  Software reset host controller.
  * @param  void
  * @retval None
  */
void SDIO_SoftwareReset(void);

/**
  * @brief  Enables or disables the SDIO internal Clock.
  * @param  NewState: new state of the SDIO internal Clock.
  *   This parameter can be the following values:
  *     @arg ENABLE:  enable sdio internal clock.
  *     @arg DISABLE: disable sdio internal clock.
  * @retval None
  */
void SDIO_InternalClockCmd(FunctionalState NewState);

/**
  * @brief  Get Software reset status.
  * @param  void
  * @retval The new state of sdio software reset progress status(SET or RESET).
  */
FlagStatus SDIO_GetSoftwareResetStatus(void);

/**
  * @brief  Get internal clock stable or not.
  * @param  void
  * @retval The new state of sdio internal clock ready status(SET or RESET).
  */
FlagStatus SDIO_GetInternalClockStatus(void);


/**
  * @brief  Sets the SD bus power status of the controller.
  * @param  SDIO_PowerState: new state of the Power state.
  *   This parameter can be one of the following values:
  *   - SDIO_PowerState_OFF
  *   - SDIO_PowerState_ON
  * @param  voltage: bus voltage value.
  *   This parameter can be one of the following values:
  *   - SDIO_VOLT_3_3V
  *   - SDIO_VOLT_3_0V
  *   - SDIO_VOLT_1_8V
  * @retval None
  */
void SDIO_SetBusPower(uint32_t SDIO_PowerState, uint32_t voltage);
#endif
/**
  * @brief Initializes the SDIO peripheral according to the specified
  *   parameters in the SDIO_InitStruct.
  * @param  SDIO_InitStruct: pointer to a SDIO_InitTypeDef structure that
  *   contains the configuration information for the specified SDIO peripheral.
  * @retval None
  */
void SDIO_Init_XX(SDIO_TypeDef *SDIOx);
void SDIO_SetDmaDescAddress(SDIO_TypeDef *SDIOx, uint32_t data_arr, uint16_t blockNum);
void SDIO_SetBlkNum(SDIO_TypeDef *SDIOx, uint32_t blknum);
#if 0
/**
  * @brief  Fills each SDIO_InitStruct member with its default value.
  * @param  SDIO_InitStruct: pointer to an SDIO_InitTypeDef structure which will be initialized.
  * @retval None
  */
void SDIO_StructInit(SDIO_InitTypeDef *SDIO_InitStruct);

/**
  * @brief  Initializes the SDIO data path according to the specified
  *      parameters in the SDIO_DataInitStruct.
  * @param  SDIO_DataInitStruct : pointer to a SDIO_DataInitTypeDef
  *   structure that contains the configuration information for the SDIO command.
  * @retval None
  */
void SDIO_DataConfig(SDIO_DataInitTypeDef *SDIO_DataInitStruct);

/**
  * @brief  Fills each SDIO_DataInitStruct member with its default value.
  * @param  SDIO_DataInitStruct: pointer to an SDIO_DataInitTypeDef structure which
  *         will be initialized.
  * @retval None
*/
void SDIO_DataStructInit(SDIO_DataInitTypeDef *SDIO_DataInitStruct);

/**
 * @brief  Configure SD clock.
 * @param  clock_div: value of SDIO clock divider.
 * @retval none.
 */
void SDIO_SetClock(uint32_t clock_div);

/**
  * @brief  Configure SDIO clock.
  * @param SDIO_BusWide: value of SDIO bus wide.
  *   This parameter can be the following values:
  *   @arg SDIO_BusWide_1b: 1-bit mode.
  *   @arg SDIO_BusWide_4b: 4-bit mode.
  * @retval none.
  */
void SDIO_SetBusWide(uint32_t SDIO_BusWide);

/**
  * @brief  Set start address of the descriptor table.
  * @param address: start address of the descriptor table.
  * @retval none.
  */
void SDIO_SetSystemAddress(uint32_t address);

/**
  * @brief  Set block size.
  * @param BlockSize:  block size.
  * @retval none.
  */
void SDIO_SetBlockSize(uint32_t BlockSize);

/**
  * @brief  Set block count.
  * @param BlockCount:  block count.
  * @retval none.
  */
void SDIO_SetBlockCount(uint32_t BlockCount);


/**
  * @brief  Read data through the SDIO peripheral.
  * @param  void
  * @retval  The value of the received data.
  */
uint32_t SDIO_ReadData(void);

/**
  * @brief  Write data through the SDIO peripheral.
  * @param  Data: Data to be transmitted.
  * @retval  none.
  */
void SDIO_WriteData(uint32_t Data);

/**
  * @brief  Enables or disables the specified SDIO interrupt status.
  * @param  SDIO_INTStatus: specifies the IR interrupt status to be enabled or disabled.
  *   This parameter can be the following values:
  *      @arg SDIO_INT_CARD: card interrupt status.
  *      @arg SDIO_INT_DMA: DMA interrupt status.
  *      @arg SDIO_INT_TF_CMPL: transfer complete interrupt status.
  *      @arg SDIO_INT_CMD_CMPL: command complete interrupt status.
  * @param  newState: new state of the specified SDIO interrupt status.
  *   This parameter can be: ENABLE or DISABLE.
  * @retval None
  */
void SDIO_INTStatusConfig(uint32_t SDIO_INTStatus, FunctionalState newState);

/**
  * @brief  Enables or disables the specified SDIO interrupts.
  * @param  SDIO_INT: specifies the IR interrupts sources to be enabled or disabled.
  *   This parameter can be the following values:
  *      @arg SDIO_INT_ERROR: Error interrupt signal caused by any type error in error interrupt status register
  *           which can trigger interrupt to NVIC.
  *      @arg SDIO_INT_CARD: card interrupt signal which can trigger interrupt to NVIC.
  *      @arg SDIO_INT_DMA: DMA interrupt signal which can trigger interrupt to NVIC.
  *      @arg SDIO_INT_TF_CMPL: transfer interrupt interrupt signal which can trigger interrupt to NVIC.
  *      @arg SDIO_INT_CMD_CMPL: command complete signal interrupt which can trigger interrupt to NVIC.
  * @param  newState: new state of the specified SDIO interrupts.
  *   This parameter can be: ENABLE or DISABLE.
  * @retval None
  */
void SDIO_INTConfig(uint32_t SDIO_INT, FunctionalState newState);

/**
  * @brief  Enables or disables the specified SDIO error interrupt status.
  * @param  SDIO_INTStatus: specifies the SDIO error interrupts status to be enabled or disabled.
  *   This parameter can be the following values:
  *      @arg SDIO_INT_VENDOR_SPECIFIC_ERR:
  *      @arg SDIO_INT_ADMA_ERR: Set when the host controller detects errors during ADMA based data transfer.
  *      @arg SDIO_INT_AUTO_CMD12_ERR: Set when detecting that one of this bits D00-D04 in Auto CMD12 Error Status register
  *           has changed from 0 to 1.
  *      @arg SDIO_INT_CURRENT_LIMIT_ERR:
  *      @arg SDIO_INT_DAT_END_BIT_ERR: Set when detecting 0 at the end bit position of read data which uses the DAT line or at
  *           the end bit position of the CRC Status.
  *      @arg SDIO_INT_DAT_CRC_ERR:
  *      @arg SDIO_INT_DAT_TIMEOUT_ERR:
  *      @arg SDIO_INT_CMD_INDEX_ERR:
  *      @arg SDIO_INT_CMD_END_BIT_ERR:
  *      @arg SDIO_INT_CMD_CRC_ERR:
  *      @arg SDIO_INT_CMD_TIMEOUT_ERR:
  * @param  newState: new state of the specified SDIO error interrupt status.
  *   This parameter can be: ENABLE or DISABLE.
  * @retval None
  */
void SDIO_ErrrorINTStatusConfig(uint32_t SDIO_INTStatus, FunctionalState newState);

/**
  * @brief  Enables or disables the specified SDIO error interrupts.
  * @param  SDIO_INT: specifies the SDIO error interrupts sources to be enabled or disabled.
  *   This parameter can be the following values:
  *      @arg SDIO_INT_VENDOR_SPECIFIC_ERR:
  *      @arg SDIO_INT_ADMA_ERR:
  *      @arg SDIO_INT_AUTO_CMD12_ERR:
  *      @arg SDIO_INT_CURRENT_LIMIT_ERR:
  *      @arg SDIO_INT_DAT_END_BIT_ERR:
  *      @arg SDIO_INT_DAT_CRC_ERR:
  *      @arg SDIO_INT_DAT_TIMEOUT_ERR:
  *      @arg SDIO_INT_CMD_INDEX_ERR:
  *      @arg SDIO_INT_CMD_END_BIT_ERR:
  *      @arg SDIO_INT_CMD_CRC_ERR:
  *      @arg SDIO_INT_CMD_TIMEOUT_ERR:
  * @param  newState: new state of the specified SDIO error interrupts.
  *   This parameter can be: ENABLE or DISABLE.
  * @retval None
  */
void SDIO_ErrrorINTConfig(uint32_t SDIO_INT, FunctionalState newState);

/**
  * @brief  Enables or disables the specified SDIO wake up event.
  * @param  SDIO_WakeUp: specifies the SDIO wake up sources to be enabled or disabled.
  *   This parameter can be the following values:
  *      @arg SDIO_WAKE_UP_SDCARD_REMOVAL:
  *      @arg SDIO_WAKE_UP_SDCARD_INSERT:
  *      @arg SDIO_WAKE_UP_SDCARD_INTR:
  * @param  newState: new state of the specified SDIO wake up event.
  *   This parameter can be: ENABLE or DISABLE.
  * @retval None
  */
void SDIO_WakeUpConfig(uint32_t SDIO_WakeUp, FunctionalState newState);




/**
  * @brief  Checks whether the specified SDIO error interrupt is set or not.
  * @param  SDIO_INT: specifies the error interrupt to check.
  *   This parameter can be one of the following values:
  *     @arg SDIO_INT_VENDOR_SPECIFIC_ERR:
  *     @arg SDIO_INT_ADMA_ERR:
  *     @arg SDIO_INT_AUTO_CMD12_ERR:
  *     @arg SDIO_INT_CURRENT_LIMIT_ERR:
  *     @arg SDIO_INT_DAT_END_BIT_ERR:
  *     @arg SDIO_INT_DAT_CRC_ERR:
  *     @arg SDIO_INT_DAT_TIMEOUT_ERR:
  *     @arg SDIO_INT_CMD_INDEX_ERR:
  *     @arg SDIO_INT_CMD_END_BIT_ERR:
  *     @arg SDIO_INT_CMD_CRC_ERR:
  *     @arg SDIO_INT_CMD_TIMEOUT_ERR:
  * @retval The new state of ITStatus (SET or RESET).
  */
ITStatus SDIO_GetErrorINTStatus(uint32_t SDIO_INT);


/**
  * @brief  Clears the SDIO error interrupt pending bits.
  * @param SDIO_INT: specifies the error interrupt pending bit to clear.
  *   This parameter can be any combination of the following values:
  *     @arg SDIO_INT_VENDOR_SPECIFIC_ERR:
  *     @arg SDIO_INT_ADMA_ERR:
  *     @arg SDIO_INT_AUTO_CMD12_ERR:
  *     @arg SDIO_INT_CURRENT_LIMIT_ERR:
  *     @arg SDIO_INT_DAT_END_BIT_ERR:
  *     @arg SDIO_INT_DAT_CRC_ERR:
  *     @arg SDIO_INT_DAT_TIMEOUT_ERR:
  *     @arg SDIO_INT_CMD_INDEX_ERR:
  *     @arg SDIO_INT_CMD_END_BIT_ERR:
  *     @arg SDIO_INT_CMD_CRC_ERR:
  *     @arg SDIO_INT_CMD_TIMEOUT_ERR:
  * @retval None
  */
void SDIO_ClearErrorINTPendingBit(uint32_t SDIO_INT);

#endif


/**
  * @brief  Checks whether the specified SDIO flag is set or not.
  * @param  SDIO_FLAG: specifies the flag to check.
  *   This parameter can be one of the following values:
  *       @arg SDIO_FLAG_BUF_READ_EN:This status is used for non-DMA read transfer.
  *              SET: Have data in buffer when block data is ready in the buffer.
  *              RESET:  No Data.
  *              Supplement: A change of this bit from 0 to 1 occurs when block data is ready
  *              in the buffer and generates the Buffer Read Interrupt.
  *       @arg SDIO_FLAG_WRITE_BUF_EN:This status is used for non-DMA write transfer.
  *              SET: can write in non-DMA write transfers.
  *              RESET:  can not write in non-DMA write transfers.
  *              Supplement: A change of this bit from 0 to 1 occurs when top of block data can be written to the buffer
  *              and generates the Buffer Write Ready Interrupt.
  *       @arg SDIO_FLAG_READ_TF_ACTIVE:
  *              SET: Transferring data in a read transfer.
  *              RESET:  No valid data in a read transfer.
  *       @arg SDIO_FLAG_WRITE_TF_ACTIVE:
  *              SET: Transferring data in a write transfer.
  *              RESET:  No valid data in a write transfer.
  *       @arg SDIO_FLAG_DAT_LINE_ACTIVE:
  *              SET: DAT line active
  *              RESET:  DAT line inactive
  *       @arg SDIO_FLAG_CMD_DAT_INHIBIT:
  *              SET: Can not issue command which uses the DAT line
  *              RESET: Can issue command which uses the DAT line
  *       @arg SDIO_FLAG_CMD_INHIBIT
  *              SET: Can not issue command
  *              RESET: Can issue command using only CMD line
  * @retval The new state of SDIO_FLAG (SET or RESET).
  */
FlagStatus SDIO_GetFlagStatus(SDIO_TypeDef *SDIOx, uint32_t SDIO_FLAG);
/**
  * @brief  Checks whether the specified SDIO interrupt is set or not.
  * @param  SDIO_INT: specifies the interrupt to check.
  *   This parameter can be one of the following values:
  *       @arg SDIO_INT_ERROR: Set when any of bits in the Error interrupt status register are set.
  *       @arg SDIO_INT_CARD: Set when generate card interrupt.
  *       @arg SDIO_INT_DMA: In case of ADMA, by setting int field in the descriptor table, host controller generates this interrupt.
  *       @arg SDIO_BLOCK_GAP_EVENT: Set when stop at Block Gap Request is set.
  *       @arg SDIO_INT_TF_CMPL: Set when a read/write transfer and a command with busy is complete.
  *       @arg SDIO_INT_CMD_CMPL: Set when get the end bit of command response(Except Auto CMD12).
  * @retval The new state of ITStatus (SET or RESET).
  */
ITStatus SDIO_GetINTStatus(SDIO_TypeDef *SDIOx, uint32_t SDIO_INT);
/**
  * @brief  Initializes the SDIO Command according to the specified
  *         parameters in the SDIO_CmdInitStruct and send the command.
  * @param  SDIO_CmdInitStruct : pointer to a SDIO_CmdInitTypeDef
  *         structure that contains the configuration information for the SDIO command.
  * @retval None
  */
void SDIO_SendCommand(SDIO_TypeDef *SDIOx, SDIO_CmdInitTypeDef *SDIO_CmdInitStruct);


/**
  * @brief  Clears the SDIO interrupt pending bits.
  * @param  SDIO_INT: specifies the interrupt pending bit to clear.
  *   This parameter can be any combination of the following values:
  *     @arg SDIO_INT_ERROR:
  *     @arg SDIO_INT_CARD:
  *     @arg SDIO_INT_DMA:
  *     @arg SDIO_INT_TF_CMPL:
  *     @arg SDIO_INT_CMD_CMPL:Clear command complete interrupt.
  * @retval None
  */
void SDIO_ClearINTPendingBit(SDIO_TypeDef *SDIOx, uint32_t SDIO_INT);

SdFsmStatus SDIO_GetFsmStatus(SDIO_TypeDef *SDIOx);

/**
 * @brief  Returns response received from the card for the last command.
 * @param  SDIO_RESP: Specifies the SDIO response register.
 *   This parameter can be one of the following values:
 *       @arg SDIO_RSP0: Response Register 0
 *       @arg SDIO_RSP2: Response Register 1
 *       @arg SDIO_RSP4: Response Register 2
 *       @arg SDIO_RSP6: Response Register 3
 * @retval value of SDIO_RESP.
 */
uint32_t SDIO_GetResponse(SDIO_TypeDef *SDIOx, uint32_t SDIO_RSP);
/**
  * @brief  Fills each SDIO_CmdInitStruct member with its default value.
  * @param  SDIO_CmdInitStruct: pointer to an SDIO_CmdInitTypeDef structure which
  *         will be initialized.
  * @retval None
*/
void SDIO_CmdStructInit(SDIO_CmdInitTypeDef *SDIO_CmdInitStruct);
void SDIO_StructInit(SDIO_InitTypeDef *SDIO_InitStruct);
#ifdef __cplusplus
}
#endif

#endif /* _RTL876x_SDIO_H_ */

/** @} */ /* End of group SDIO_Exported_Functions */
/** @} */ /* End of group SDIO */

/******************* (C) COPYRIGHT 2017 Realtek Semiconductor Corporation *****END OF FILE****/

