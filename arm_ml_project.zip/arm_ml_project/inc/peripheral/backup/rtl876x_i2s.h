/**
*********************************************************************************************************
*               Copyright(c) 2017, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* \file     rtl876x_i2s.h
* \brief    The header file of the peripheral I2S driver.
* \details  This file provides all I2S firmware functions.
* \author   echo gao
* \date     2022-3-08
* \version  v1.0
* *********************************************************************************************************
*/


#ifndef _RTL876x_I2S_H
#define _RTL876x_I2S_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * \addtogroup  IO          Peripheral Drivers
 * \defgroup    I2S         I2S
 *
 * \brief       Manage the I2S peripheral functions.
 *
 * \ingroup     IO
 */

/*============================================================================*
 *                         Includes
 *============================================================================*/
#include "rtl876x.h"
#include "string.h"
//#include "sport_reg.h"

/* ================================================================================ */
/* ================       I2S Registers Structures Section        ================= */
/* ================================================================================ */
/**
  * @brief I2S
  */
typedef struct
{
    __O uint32_t TX_DR;               /*!< 0x00 */
    __IO uint32_t CTRL0;              /*!< 0x04 */
    __IO uint32_t CTRL1;              /*!< 0x08 */
    __IO uint32_t DSP_INT_CR;         /*!< 0x0C */
    __I uint32_t RX_DR;               /*!< 0x10 */
    __I uint32_t FIFO_SR;             /*!< 0x14 */
    __IO uint32_t ERROR_CNT_SR;       /*!< 0x18 */
    __IO uint32_t BCLK_DIV;           /*!< 0x1C */
    __IO uint32_t DMA_TRDLR;          /*!< 0x20 */
    __I uint32_t SR;                  /*!< 0x24 */
    __IO uint32_t CTL_REG2;           /*!< 0x28 */
    __IO uint32_t RX_BCLK;            /*!< 0x2C */
    __IO uint32_t INT_CLR_1;          /*!< 0x30 */ /* rsvd for dsp */
    __IO uint32_t READ_CNT;           /*!< 0x34 */ /* rsvd for dsp */
    __IO uint32_t RX_BCLK_DIV;        /*!< 0x38 */
    __IO uint32_t TX_DIR_SEL;         /*!< 0x3C */
    __IO uint32_t TX_FIFO_1_WR;       /*!< 0x40 */
    __IO uint32_t RX_CTL_1;           /*!< 0x44 */
    __IO uint32_t DIR_EN1;            /*!< 0x48 */
    __IO uint32_t DIR_OUT_0;          /*!< 0x4C */
    __IO uint32_t RX_FIFO_1_RD;       /*!< 0x50 */
    __IO uint32_t RX_FIFO_REG0;       /*!< 0x54 */
    __IO uint32_t RX_FIFO_REG1;       /*!< 0x58 */
    __IO uint32_t RX_FIFO_DEPTH;      /*!< 0x5C */
    __IO uint32_t SPORT_REG_0x60;     /*!< 0x60 */
    __IO uint32_t SPORT_DEPTH_CNT_LATCH; /*! <0x64 */
} I2S_TypeDef;

/* ================================================================================ */
/* ================                I2S Declaration                ================= */
/* ================================================================================ */
#define I2S0                            ((I2S_TypeDef              *) I2S0_REG_BASE)
#define I2S1                            ((I2S_TypeDef              *) I2S1_REG_BASE)
#define I2S2                            ((I2S_TypeDef              *) I2S2_REG_BASE)
#define I2S3                            ((I2S_TypeDef              *) I2S3_REG_BASE)


#define GET_CH_REG_SEL(x)           (x & I2S_CH_REG_SEL)
#define GET_CH_NUM_OFFSET(x)        (x & I2S_CH_NUM_OFFSET_MASK)

#define I2S_TX_CH_DATA_SEL_LEN    4
#define I2S_DIRECT_REG_LEN        6
#define I2S_DEFAULT_CH_LEN        32

#define I2S_CH_NUM_OFFSET_MASK    0x3
#define I2S_TX_CH_DATA_SEL_MASK   0xF
#define I2S_RX_FIFO_CH_MASK       0x1F
#define I2S_DIRECT_REG_MASK       0x1F
#define I2S_DIRECT_OUT_MASK       0xFF

#define I2S_RX_FIFO_CH_OFS        3
#define I2S_DIRECT_OUT_OFS        24

#define I2S_RESET_EN              BIT0
#define I2S_CH_REG_SEL            BIT2
#define I2S_DIRECT_REG_EN         BIT5

#define SPORT0_DSPBUS_REG_BASE             0x50300000UL
#define SPORT1_DSPBUS_REG_BASE             0x50304000UL
#define SPORT2_DSPBUS_REG_BASE             0x50308000UL
#define SPORT3_DSPBUS_REG_BASE             0x5030C000UL

#define PERI_ON_VCORE3_BASE                0x400E2000UL
#define SOC_0x900                          0x900
#define SOC_0x908                          0x908
#define SOC_0x900_clk               (*((volatile uint32_t *)0x400E2900UL))
#define SOC_0x908_CLK               (*((volatile uint32_t *)0x400E2908UL))


/* Register: TX_FIFO_0_WR_ADDR ------------------------------------------------------------*/
/* Description: SPORT fifo write register. Offset: 0x0800 */
#define TX_FIFO_0_WR_ADDR_OFFSET        0x0800
/* Register: RX_FIFO_0_RD_ADDR ------------------------------------------------------------*/
/* Description: SPORT fifo read register. Offset: 0x1800 */
#define RX_FIFO_0_RD_ADDR_OFFSET        0x1800
/* Register: TX_FIFO_1_WR_ADDR ------------------------------------------------------------*/
/* Description: SPORT fifo read register. Offset: 0x2800 */
#define TX_FIFO_1_WR_ADDR_OFFSET        0x2800
/* Register: RX_FIFO_1_RD_ADDR ------------------------------------------------------------*/
/* Description: SPORT fifo read register. Offset: 0x3800 */
#define RX_FIFO_1_RD_ADDR_OFFSET        0x3800
/*============================================================================*
 *                         Types
 *============================================================================*/

#define I2S0_TX_ADDR              I2S0_REG_BASE + TX_FIFO_0_WR_ADDR_OFFSET
#define I2S0_RX_ADDR              I2S0_REG_BASE + RX_FIFO_0_RD_ADDR_OFFSET
#define I2S0_FIFO1_TX_ADDR        I2S0_REG_BASE + TX_FIFO_1_WR_ADDR_OFFSET
#define I2S0_FIFO1_RX_ADDR        I2S0_REG_BASE + RX_FIFO_1_RD_ADDR_OFFSET

#define I2S1_TX_ADDR              I2S1_REG_BASE + TX_FIFO_0_WR_ADDR_OFFSET
#define I2S1_RX_ADDR              I2S1_REG_BASE + RX_FIFO_0_RD_ADDR_OFFSET
#define I2S1_FIFO1_TX_ADDR        I2S1_REG_BASE + TX_FIFO_1_WR_ADDR_OFFSET
#define I2S1_FIFO1_RX_ADDR        I2S1_REG_BASE + RX_FIFO_1_RD_ADDR_OFFSET

#define I2S2_TX_ADDR              I2S2_REG_BASE + TX_FIFO_0_WR_ADDR_OFFSET
#define I2S2_RX_ADDR              I2S2_REG_BASE + RX_FIFO_0_RD_ADDR_OFFSET
#define I2S2_FIFO1_TX_ADDR        I2S2_REG_BASE + TX_FIFO_1_WR_ADDR_OFFSET
#define I2S2_FIFO1_RX_ADDR        I2S2_REG_BASE + RX_FIFO_1_RD_ADDR_OFFSET

#define I2S3_TX_ADDR              I2S3_REG_BASE + TX_FIFO_0_WR_ADDR_OFFSET
#define I2S3_RX_ADDR              I2S3_REG_BASE + RX_FIFO_0_RD_ADDR_OFFSET
#define I2S3_FIFO1_TX_ADDR        I2S3_REG_BASE + TX_FIFO_1_WR_ADDR_OFFSET
#define I2S3_FIFO1_RX_ADDR        I2S3_REG_BASE + RX_FIFO_1_RD_ADDR_OFFSET




/*============================================================================*
 *                         Types
 *============================================================================*/

/**
 * \defgroup    I2S_Exported_Types Inti Params Struct
 *
 * \ingroup     I2S
 */

/**
 * \brief       I2S initialize parameters.
 *
 * \ingroup     I2S_Exported_Types
 */
typedef struct
{
//    uint32_t I2S_DspCtrolMode;       /*!< Specifies the I2S clock source.
//                                            This parameter can be a value of \ref I2S_Clock_Source*/
//    uint32_t I2S_Scheme;             /*!< Specifies the I2S clock source.
//                                              This parameter can be a value of \ref I2S_Scheme_Select*/
    uint32_t I2S_ClockSource;       /*!< Specifies the I2S clock source.
                                            This parameter can be a value of \ref I2S_Clock_Source*/
    uint32_t I2S_BClockMi;          /*!< Specifies the BLCK clock speed. BCLK = 40MHz*(I2S_BClockNi/I2S_BClockMi).
                                                                                  This parameter must range from 1 to 0xffff */
    uint32_t I2S_BClockNi;          /*!< Specifies the BLCK clock speed.
                                                                                  This parameter must range from 1 to 0x7FFF */
    uint32_t I2S_BClockDiv;
    uint32_t I2S_DeviceMode;        /*!< Specifies the I2S device mode.
                                            This parameter can be a value of \ref I2S_device_mode*/
    uint32_t I2S_TxChannelType;       /*!< Specifies the channel type used for the I2S communication.
                                            This parameter can be a value of \ref I2S_Channel_Type */
    uint32_t I2S_RxChannelType;       /*!< Specifies the channel type used for the I2S communication.
                                            This parameter can be a value of \ref I2S_Channel_Type */
    uint32_t I2S_TxChSequence;      /*!< Specifies the transmission channel seqence used for the I2S communication.
                                            This parameter can be a value of \ref I2S_Tx_Ch_Sequence*/
    uint32_t I2S_RxChSequence;      /*!< Specifies the receiving channel seqence used for the I2S communication.
                                            This parameter can be a value of \ref I2S_Rx_Ch_Sequence*/
    uint32_t I2S_TxDataFormat;        /*!< Specifies the I2S Data format mode.
                                            This parameter can be a value of \ref I2S_Format_Mode*/
    uint32_t I2S_RxDataFormat;        /*!< Specifies the I2S Data format mode.
                                            This parameter can be a value of \ref I2S_Format_Mode*/
    uint32_t I2S_TxBitSequence;     /*!< Specifies the I2S Data bits sequences.
                                            This parameter can be a value of \ref I2S_Tx_Bit_Sequence*/
    uint32_t I2S_RxBitSequence;     /*!< Specifies the I2S Data bits sequences.
                                            This parameter can be a value of \ref I2S_Rx_Bit_Sequence*/
    uint32_t I2S_TxDataWidth;         /*!< Specifies the I2S Data width.
                                            This parameter can be a value of \ref I2S_Data_Width */
    uint32_t I2S_RxDataWidth;         /*!< Specifies the I2S Data width.
                                            This parameter can be a value of \ref I2S_Data_Width */
    uint32_t I2S_TxChannelWidth;
    uint32_t I2S_RxChannelWidth;
    uint32_t I2S_TxFifoUsed;
    uint32_t I2S_RxFifoUsed;
    uint32_t I2S_TxTdmMode;
    uint32_t I2S_RxTdmMode;

//    uint32_t I2S_MCLKOutput;        /*!< Specifies the I2S MCLK output freqency.
//                                            This parameter can be a value of \ref I2S_MCLK_Output */
    uint32_t I2S_DMACmd;            /*!< Specifies the I2S DMA control.
                                            This parameter can be a value of \ref FunctionalState */
    uint32_t I2S_TxWaterlevel;      /*!< Specifies the dma watermark level in transmit mode.
                                            This parameter must range from 1 to 63 */
    uint32_t I2S_RxWaterlevel;      /*!< Specifies the dma watermark level in receive mode.
                                            This parameter must range from 1 to 63 */
} I2S_InitTypeDef;

typedef struct
{
    uint8_t direct_mode;
    uint8_t direct_out_en; // bit map, T_SPORT_DIRECT_OUT_EN
    uint8_t tx_channel_map[8];
    uint8_t rx_fifo_map[8];
} I2S_DataSelTypeDef;


/*============================================================================*
 *                         Register Defines
 *============================================================================*/

/* Peripheral: I2S */
/* Description: I2S register defines */

/* Register: CTRL0 -------------------------------------------------------*/
/* Description: Control register 0. Offset: 0x04. */

/* CTRL0[31:30]: I2S_MCLK_SEL. */
#define I2S_MCLK_SEL_POS                (30)
#define I2S_MCLK_SEL_MSK                (0x11 << I2S_MCLK_SEL_POS)
#define I2S_MCLK_SEL_CLR                (~I2S_MCLK_SEL_MSK)
/* CTRL0[29:28]: I2S_RX_CH_SEQ. */
#define I2S_RX_CH_SEQ_POS               (28)
#define I2S_RX_CH_SEQ_MSK               (0x1 << I2S_RX_CH_SEQ_POS)
#define I2S_RX_CH_SEQ_CLR               (~I2S_RX_CH_SEQ_MSK)
/* CTRL0[27:26]: I2S_TX_CH_SEQ. */
#define I2S_TX_CH_SEQ_POS               (26)
#define I2S_TX_CH_SEQ_MSK               (0x1 << I2S_TX_CH_SEQ_POS)
#define I2S_TX_CH_SEQ_CLR               (~I2S_TX_CH_SEQ_MSK)
/* CTRL0[25]: I2S_START_RX. */
#define I2S_START_RX_POS                (25)
#define I2S_START_RX_MSK                (0x1 << I2S_START_RX_POS)
#define I2S_START_RX_CLR                (~I2S_START_RX_MSK)
/* CTRL0[24]: I2S_RX_DISABLE. */
#define I2S_RX_DISABLE_POS              (24)
#define I2S_RX_DISABLE_MSK              (0x1 << I2S_RX_DISABLE_POS)
#define I2S_RX_DISABLE_CLR              (~I2S_RX_DISABLE_MSK)
/* CTRL0[23]: I2S_RX_LSB_FIRST. */
#define I2S_RX_LSB_FIRST_POS            (23)
#define I2S_RX_LSB_FIRST_MSK            (0x1 << I2S_RX_LSB_FIRST_POS)
#define I2S_RX_LSB_FIRST_CLR            (~I2S_RX_LSB_FIRST_MSK)
/* CTRL0[22]: I2S_TX_LSB_FIRST. */
#define I2S_TX_LSB_FIRST_POS            (22)
#define I2S_TX_LSB_FIRST_MSK            (0x1 << I2S_TX_LSB_FIRST_POS)
#define I2S_TX_LSB_FIRST_CLR            (~I2S_TX_LSB_FIRST_MSK)
/* CTRL0[21:20]: I2S_TDM_RX_SEL. */
#define I2S_TDM_RX_SEL_POS               (20)
#define I2S_TDM_RX_SEL_MSK               (0x1 << I2S_TDM_RX_SEL_POS)
#define I2S_TDM_RX_SEL_CLR               (~I2S_TDM_RX_SEL_MSK)
/* CTRL0[19:18]: I2S_TDM_TX_SEL. */
#define I2S_TDM_TX_SEL_POS               (20)
#define I2S_TDM_TX_SEL_MSK               (0x1 << I2S_TDM_TX_SEL_POS)
#define I2S_TDM_TX_SEL_CLR               (~I2S_TDM_TX_SEL_MSK)
/* CTRL0[17]: I2S_START_TX. */
#define I2S_START_TX_POS                (17)
#define I2S_START_TX_MSK                (0x1 << I2S_START_TX_POS)
#define I2S_START_TX_CLR                (~I2S_START_TX_MSK)
/* CTRL0[16]: I2S_TX_DISABLE. */
#define I2S_TX_DISABLE_POS              (16)
#define I2S_TX_DISABLE_MSK              (0x1 << I2S_TX_DISABLE_POS)
#define I2S_TX_DISABLE_CLR              (~I2S_TX_DISABLE_MSK)
/* CTRL0[14:12]: I2S_DATA_WIDTH. */
#define I2S_DATA_WIDTH_POS              (12)
#define I2S_DATA_WIDTH_MSK              (0x3 << I2S_DATA_WIDTH_POS)
#define I2S_DATA_WIDTH_CLR              (~I2S_DATA_WIDTH_MSK)
/* CTRL0[11]: I2S_CHANNEL_TYPE. */
#define I2S_CHANNEL_TYPE_POS            (11)
#define I2S_CHANNEL_TYPE_MSK            (0x1 << I2S_CHANNEL_TYPE_POS)
#define I2S_CHANNEL_TYPE_CLR            (~I2S_CHANNEL_TYPE_MSK)
/* CTRL0[10]: I2S_CLK_INV. */
#define I2S_CLK_INV_POS            (10)
#define I2S_CLK_INV_MSK            (0x1 << I2S_CLK_INV_POS)
#define I2S_CLK_INV_CLR            (~I2S_CLK_INV_MSK)
/* CTRL0[9:8]: I2S_DATA_FORMAT. */
#define I2S_DATA_FORMAT_POS             (8)
#define I2S_DATA_FORMAT_MSK             (0x3 << I2S_DATA_FORMAT_POS)
#define I2S_DATA_FORMAT_CLR             (~I2S_DATA_FORMAT_MSK)
/* CTRL0[7]: I2S_CTRL_MODE. */
#define I2S_CTRL_MODE_POS              (7)
#define I2S_CTRL_MODE_MSK              (0x1 << I2S_CTRL_MODE_POS)
#define I2S_CTRL_MODE_CLR              (~I2S_CTRL_MODE_MSK)
/* CTRL0[6]: I2S_LOOKBACK. */
#define I2S_LOOKBACK_POS               (6)
#define I2S_LOOKBACK_MSK              (0x1 << I2S_LOOKBACK_POS)
#define I2S_LOOKBACK_CLR              (~I2S_LOOKBACK_MSK)
/* CTRL0[5]: I2S_WCLK_TX_INV. */
#define I2S_WCLK_TX_INV_POS             (5)
#define I2S_WCLK_TX_INV_MSK              (0x1 << I2S_WCLK_TX_INV_POS)
#define I2S_WCLK_TX_INV_CLR              (~I2S_WCLK_TX_INV_MSK)
/* CTRL0[4]: I2S_SLAVE_DATA_SEL. */
#define I2S_SLAVE_DATA_SEL_POS          (4)
#define I2S_SLAVE_DATA_SEL_MSK          (0x1 << I2S_SLAVE_DATA_SEL_POS)
#define I2S_SLAVE_DATA_SEL_CLR          (~I2S_SLAVE_DATA_SEL_MSK)
/* CTRL0[3]: I2S_SLAVE_CLK_SEL. */
#define I2S_SLAVE_CLK_SEL_POS           (3)
#define I2S_SLAVE_CLK_SEL_MSK           (0x1 << I2S_SLAVE_CLK_SEL_POS)
#define I2S_SLAVE_CLK_SEL_CLR           (~I2S_SLAVE_CLK_SEL_MSK)
/* CTRL0[2]: I2S_SCLK_RX_INV. */
#define I2S_SCLK_RX_INV_POS           (2)
#define I2S_SCLK_RX_INV_MSK           (0x1 << I2S_SCLK_RX_INV_POS)
#define I2S_SCLK_RX_INV_CLR           (~I2S_SCLK_RX_INV_MSK)
/* CTRL0[1]: I2S_SCLK_TX_INV. */
#define I2S_SCLK_TX_INV_POS           (1)
#define I2S_SCLK_TX_INV_MSK           (0x1 << I2S_SCLK_TX_INV_POS)
#define I2S_SCLK_TX_INV_CLR           (~I2S_SCLK_TX_INV_MSK)
/* CTRL0[0]: I2S_RESET. */
#define I2S_RESET_POS                   (0)
#define I2S_RESET_MSK                   (0x1 << I2S_RESET_POS)
#define I2S_RESET_CLR                   (~I2S_RESET_MSK)

/* Register: CTRL1 -------------------------------------------------------*/
/* Description: Control register 1. Offset: 0x08. */
/* CTRL1[31]: I2S_RX_FIFO1_REG1_EN. */
#define I2S_RX_FIFO1_REG1_EN_POS          (31)
#define I2S_RX_FIFO1_REG1_EN_MSK          (0x1 << I2S_RX_FIFO1_REG1_EN_POS)
#define I2S_RX_FIFO1_REG1_EN_CLR          (~I2S_RX_FIFO1_REG1_EN_MSK)
/* CTRL1[30]: I2S_RX_FIFO1_REG0_EN. */
#define I2S_RX_FIFO1_REG0_EN_POS          (30)
#define I2S_RX_FIFO1_REG0_EN_MSK          (0x1 << I2S_RX_FIFO1_REG0_EN_POS)
#define I2S_RX_FIFO1_REG0_EN_CLR          (~I2S_RX_FIFO1_REG0_EN_MSK)
/* CTRL1[29]: I2S_RX_FIFO0_REG1_EN. */
#define I2S_RX_FIFO0_REG1_EN_POS          (29)
#define I2S_RX_FIFO0_REG1_EN_MSK          (0x1 << I2S_RX_FIFO0_REG1_EN_POS)
#define I2S_RX_FIFO0_REG1_EN_CLR          (~I2S_RX_FIFO0_REG1_EN_MSK)
/* CTRL1[28]: I2S_RX_FIFO0_REG0_EN. */
#define I2S_RX_FIFO0_REG0_EN_POS          (28)
#define I2S_RX_FIFO0_REG0_EN_MSK          (0x1 << I2S_RX_FIFO0_REG0_EN_POS)
#define I2S_RX_FIFO0_REG0_EN_CLR          (~I2S_RX_FIFO0_REG0_EN_MSK)
/* CTRL1[27]: I2S_TX_FIFO1_REG1_EN. */
#define I2S_TX_FIFO1_REG1_EN_POS          (27)
#define I2S_TX_FIFO1_REG1_EN_MSK          (0x1 << I2S_TX_FIFO1_REG1_EN_POS)
#define I2S_TX_FIFO1_REG1_EN_CLR          (~I2S_TX_FIFO1_REG1_EN_MSK)
/* CTRL1[26]: I2S_TX_FIFO1_REG0_EN. */
#define I2S_TX_FIFO1_REG0_EN_POS          (26)
#define I2S_TX_FIFO1_REG0_EN_MSK          (0x1 << I2S_TX_FIFO1_REG0_EN_POS)
#define I2S_TX_FIFO1_REG0_EN_CLR          (~I2S_TX_FIFO1_REG0_EN_MSK)
/* CTRL1[25]: I2S_TX_FIFO0_REG1_EN. */
#define I2S_TX_FIFO0_REG1_EN_POS          (25)
#define I2S_TX_FIFO0_REG1_EN_MSK          (0x1 << I2S_TX_FIFO0_REG1_EN_POS)
#define I2S_TX_FIFO0_REG1_EN_CLR          (~I2S_TX_FIFO0_REG1_EN_MSK)
/* CTRL1[24]: I2S_TX_FIFO0_REG0_EN. */
#define I2S_TX_FIFO0_REG0_EN_POS          (24)
#define I2S_TX_FIFO0_REG0_EN_MSK          (0x1 << I2S_TX_FIFO0_REG0_EN_POS)
#define I2S_TX_FIFO0_REG0_EN_CLR          (~I2S_TX_FIFO0_REG0_EN_MSK)
/* CTRL1[23]: I2S_RX_SNK_LR_SWAP. */
#define I2S_RX_SNK_LR_SWAP_POS          (23)
#define I2S_RX_SNK_LR_SWAP_MSK          (0x1 << I2S_RX_SNK_LR_SWAP_POS)
#define I2S_RX_SNK_LR_SWAP_CLR          (~I2S_RX_SNK_LR_SWAP_MSK)
/* CTRL1[22]: I2S_RX_SNK_BYTE_SWAP. */
#define I2S_RX_SNK_BYTE_SWAP_POS        (22)
#define I2S_RX_SNK_BYTE_SWAP_MSK        (0x1 << I2S_RX_SNK_BYTE_SWAP_POS)
#define I2S_RX_SNK_BYTE_SWAP_CLR        (~I2S_RX_SNK_BYTE_SWAP_MSK)
/* CTRL1[21]: I2S_TX_SRC_LR_SWAP. */
#define I2S_TX_SRC_LR_SWAP_POS          (21)
#define I2S_TX_SRC_LR_SWAP_MSK          (0x1 << I2S_TX_SRC_LR_SWAP_POS)
#define I2S_TX_SRC_LR_SWAP_CLR          (~I2S_TX_SRC_LR_SWAP_MSK)
/* CTRL1[20]: I2S_TX_SRC_BYTE_SWAP. */
#define I2S_TX_SRC_BYTE_SWAP_POS        (20)
#define I2S_TX_SRC_BYTE_SWAP_MSK        (0x1 << I2S_TX_SRC_BYTE_SWAP_POS)
#define I2S_TX_SRC_BYTE_SWAP_CLR        (~I2S_TX_SRC_BYTE_SWAP_MSK)
/* CTRL1[19]: I2S_DIRECT_MODE_EN. */
#define I2S_DIRECT_MODE_EN_POS        (19)
#define I2S_DIRECT_MODE_EN_MSK        (0x1 << I2S_DIRECT_MODE_EN_POS)
#define I2S_DIRECT_MODE_EN_CLR        (~I2S_DIRECT_MODE_EN_MSK)
/* CTRL1[18:17]: I2S_DIRECT_SRC_SEL. */
#define I2S_DIRECT_SRC_SEL_POS        (17)
#define I2S_DIRECT_SRC_SEL_MSK        (0x11 << I2S_DIRECT_MODE_EN_POS)
#define I2S_DIRECT_SRC_SEL_CLR        (~I2S_DIRECT_MODE_EN_MSK)
/* CTRL1[16]: I2S_ERR_CNT_SAT_SET. */
#define I2S_ERR_CNT_SAT_SET_POS        (16)
#define I2S_ERR_CNT_SAT_SET_MSK        (0x1 << I2S_ERR_CNT_SAT_SET_POS)
#define I2S_ERR_CNT_SAT_SET_CLR        (~I2S_ERR_CNT_SAT_SET_MSK)
/* CTRL1[15:14]: I2S_SPORT_CLK_SEL. */
#define I2S_SPORT_CLK_SEL_POS        (14)
#define I2S_SPORT_CLK_SEL_MSK        (0x11 << I2S_SPORT_CLK_SEL_POS)
#define I2S_SPORT_CLK_SEL_CLR        (~I2S_SPORT_CLK_SEL_MSK)
/* CTRL1[13]: I2S_CLR_RX_ERR_CNT. */
#define I2S_CLR_RX_ERR_CNT_POS          (13)
#define I2S_CLR_RX_ERR_CNT_MSK          (0x1 << I2S_CLR_RX_ERR_CNT_POS)
#define I2S_CLR_RX_ERR_CNT_CLR          (~I2S_CLR_RX_ERR_CNT_MSK)
/* CTRL1[12]: I2S_CLR_TX_ERR_CNT. */
#define I2S_CLR_TX_ERR_CNT_POS          (12)
#define I2S_CLR_TX_ERR_CNT_MSK          (0x1 << I2S_CLR_TX_ERR_CNT_POS)
#define I2S_CLR_TX_ERR_CNT_CLR          (~I2S_CLR_TX_ERR_CNT_MSK)
/* CTRL1[11]: I2S_ENABLE_MCLK. */
#define I2S_ENABLE_MCLK_POS              (11)
#define I2S_ENABLE_MCLK_MSK              (0x1 << I2S_ENABLE_MCLK_POS)
#define I2S_ENABLE_MCLK_CLR              (~I2S_ENABLE_MCLK_MSK)
/* CTRL1[7]: I2S_WS_FORCE_VAL. */
#define I2S_WS_FORCE_VAL_POS             (7)
#define I2S_WS_FORCE_VAL_MSK           (0x1 << I2S_WS_FORCE_VAL_POS)
#define I2S_WS_FORCE_VAL_CLR           (~I2S_WS_FORCE_VAL_MSK)
/* CTRL1[6]: I2S_WS_FORCE_SEL. */
#define I2S_WS_FORCE_SEL_POS           (6)
#define I2S_WS_FORCE_SEL_MSK           (0x1 << I2S_WS_FORCE_SEL_POS)
#define I2S_WS_FORCE_SEL_CLR           (~I2S_WS_FORCE_SEL_MSK)
/* CTRL1[5]: I2S_BCLK_RESET. */
#define I2S_BCLK_RESET_POS             (5)
#define I2S_BCLK_RESET_MSK             (0x1 << I2S_BCLK_RESET_POS)
#define I2S_BCLK_RESET_CLR             (~I2S_BCLK_RESET_MSK)
/* CTRL1[4]: I2S_BCLK_PULL_ZERO. */
#define I2S_BCLK_PULL_ZERO_POS         (4)
#define I2S_BCLK_PULL_ZERO_MSK         (0x1 << I2S_BCLK_PULL_ZERO_POS)
#define I2S_BCLK_PULL_ZERO_CLR         (~I2S_BCLK_PULL_ZERO_MSK)
/* CTRL1[3]: I2S_RX_FIFO_EN. */
#define I2S_RX_FIFO_EN_POS            (3)
#define I2S_RX_FIFO_EN_MSK            (0x1 << I2S_RX_FIFO_EN_POS)
#define I2S_RX_FIFO_EN_CLR            (~I2S_RX_FIFO_EN_MSK)
/* CTRL1[2]: I2S_TX_FIFO_EN. */
#define I2S_TX_FIFO_EN_POS            (2)
#define I2S_TX_FIFO_EN_MSK            (0x1 << I2S_TX_FIFO_EN_POS)
#define I2S_TX_FIFO_EN_CLR            (~I2S_TX_FIFO_EN_MSK)
/* CTRL1[1]: I2S_TX_FIFO_FILL_ZERO. */
#define I2S_TX_FIFO_FILL_ZERO_POS     (1)
#define I2S_TX_FIFO_FILL_ZERO_MSK     (0x1 << I2S_TX_FIFO_FILL_ZERO_POS)
#define I2S_TX_FIFO_FILL_ZERO_CLR     (~I2S_TX_FIFO_FILL_ZERO_MSK)
/* CTRL1[0]: I2S_REST_SMOOTH. */
#define I2S_REST_SMOOTH_POS            (0)
#define I2S_REST_SMOOTH_MSK            (0x1 << I2S_REST_SMOOTH_POS)
#define I2S_REST_SMOOTH_CLR            (~I2S_REST_SMOOTH_MSK)


///* CTRL1[7:0]: I2S_FRAME_SYNC_OFFSET. */
//#define I2S_FRAME_SYNC_OFFSET_POS       (0)
//#define I2S_FRAME_SYNC_OFFSET_MSK       (0xFF << I2S_FRAME_SYNC_OFFSET_POS)
//#define I2S_FRAME_SYNC_OFFSET_CLR       (~I2S_FRAME_SYNC_OFFSET_MSK)
//#define I2S_FRAME_SYNC_OFFSET_DEFAULT   (0x81 << I2S_FRAME_SYNC_OFFSET_POS)

/* Register: DSP_INT_CR -------------------------------------------------------*/
/* Description:Interrupt clearregister. Offset: 0x0C. */

/* DSP_INT_CR[30]: I2S_TX_IDLE_1. */
#define I2S_TX_IDLE_1_POS                 (30)
#define I2S_TX_IDLE_1_MSK                 (0x1 << I2S_TX_IDLE_1_POS)
#define I2S_TX_IDLE_1_CLR                 (~I2S_TX_IDLE_1_MSK)
/* DSP_INT_CR[29]: I2S_RF_EMPTY_1. */
#define I2S_RF_EMPTY_1_POS                (29)
#define I2S_RF_EMPTY_1_MSK                (0x1 << I2S_RF_EMPTY_1_POS)
#define I2S_RF_EMPTY_1_CLR                (~I2S_RF_EMPTY_1_MSK)
/* DSP_INT_CR[28]: I2S_TF_EMPTY_1. */
#define I2S_TF_EMPTY_1_POS                (28)
#define I2S_TF_EMPTY_1_MSK                (0x1 << I2S_TF_EMPTY_1_POS)
#define I2S_TF_EMPTY_1_CLR                (~I2S_TF_EMPTY_1_MSK)
/* DSP_INT_CR[27]: I2S_RX_FULL_1. */
#define I2S_RX_FULL_1_POS                 (27)
#define I2S_RX_FULL_1_MSK                 (0x1 << I2S_RX_FULL_1_POS)
#define I2S_RX_FULL_1_CLR                 (~I2S_RX_FULL_1_MSK)
/* DSP_INT_CR[26]: I2S_TX_FULL_1. */
#define I2S_TX_FULL_1_POS                 (26)
#define I2S_TX_FULL_1_MSK                 (0x1 << I2S_TX_FULL_1_POS)
#define I2S_TX_FULL_1_CLR                 (~I2S_TX_FULL_1_MSK)
/* DSP_INT_CR[25]: I2S_READY_TO_RX_1. */
#define I2S_READY_TO_RX_1_POS             (25)
#define I2S_READY_TO_RX_1_MSK             (0x1 << I2S_READY_TO_RX_1_POS)
#define I2S_READY_TO_RX_1_CLR             (~I2S_READY_TO_RX_1_MSK)
/* DSP_INT_CR[24]: I2S_READY_TO_TX_1. */
#define I2S_READY_TO_TX_1_POS             (24)
#define I2S_READY_TO_TX_1_MSK             (0x1 << I2S_READY_TO_TX_1_POS)
#define I2S_READY_TO_TX_1_CLR             (~I2S_READY_TO_TX_1_MSK)
/* DSP_INT_CR[22]: I2S_TX_IDLE_0. */
#define I2S_TX_IDLE_0_POS                 (22)
#define I2S_TX_IDLE_0_MSK                 (0x1 << I2S_TX_IDLE_0_POS)
#define I2S_TX_IDLE_0_CLR                 (~I2S_TX_IDLE_1_MSK)
/* DSP_INT_CR[21]: I2S_RF_EMPTY_0. */
#define I2S_RF_EMPTY_0_POS                (21)
#define I2S_RF_EMPTY_0_MSK                (0x1 << I2S_RF_EMPTY_0_POS)
#define I2S_RF_EMPTY_0_CLR                (~I2S_RF_EMPTY_0_MSK)
/* DSP_INT_CR[20]: I2S_TF_EMPTY_0. */
#define I2S_TF_EMPTY_0_POS                (20)
#define I2S_TF_EMPTY_0_MSK                (0x1 << I2S_TF_EMPTY_0_POS)
#define I2S_TF_EMPTY_0_CLR                (~I2S_TF_EMPTY_0_MSK)
/* DSP_INT_CR[19]: I2S_RX_FULL_0. */
#define I2S_RX_FULL_0_POS                 (19)
#define I2S_RX_FULL_0_MSK                 (0x1 << I2S_RX_FULL_0_POS)
#define I2S_RX_FULL_0_CLR                 (~I2S_RX_FULL_0_MSK)
/* DSP_INT_CR[18]: I2S_TX_FULL_0. */
#define I2S_TX_FULL_0_POS                 (18)
#define I2S_TX_FULL_0_MSK                 (0x1 << I2S_TX_FULL_0_POS)
#define I2S_TX_FULL_0_CLR                 (~I2S_TX_FULL_0_MSK)
/* DSP_INT_CR[17]: I2S_READY_TO_RX_0. */
#define I2S_READY_TO_RX_0_POS             (17)
#define I2S_READY_TO_RX_0_MSK             (0x1 << I2S_READY_TO_RX_0_POS)
#define I2S_READY_TO_RX_0_CLR             (~I2S_READY_TO_RX_0_MSK)
/* DSP_INT_CR[16]: I2S_READY_TO_TX_0. */
#define I2S_READY_TO_TX_0_POS             (16)
#define I2S_READY_TO_TX_0_MSK             (0x1 << I2S_READY_TO_TX_0_POS)
#define I2S_READY_TO_TX_0_CLR             (~I2S_READY_TO_TX_0_MSK)

/* DSP_INT_CR[12]: I2S_RX_FIFO_EMPTY_CLEAR_INT_1. */
#define I2S_RX_FIFO_EMPTY_CLEAR_INT_1_POS  (12)
#define I2S_RX_FIFO_EMPTY_CLEAR_INT_1_MSK  (0x1 << I2S_RX_FIFO_EMPTY_CLEAR_INT_1_POS)
#define I2S_RX_FIFO_EMPTY_CLEAR_INT_1_CLR  (~I2S_RX_FIFO_EMPTY_CLEAR_INT_1_MSK)
/* DSP_INT_CR[11]: I2S_TX_FIFO_EMPTY_CLEAR_INT_1. */
#define I2S_TX_FIFO_EMPTY_CLEAR_INT_1_POS  (11)
#define I2S_TX_FIFO_EMPTY_CLEAR_INT_1_MSK  (0x1 << I2S_TX_FIFO_EMPTY_CLEAR_INT_1_POS)
#define I2S_TX_FIFO_EMPTY_CLEAR_INT_1_CLR  (~I2S_TX_FIFO_EMPTY_CLEAR_INT_1_MSK)
/* DSP_INT_CR[10]: I2S_RX_FIFO_FULL_CLEAR_INT_1. */
#define I2S_RX_FIFO_FULL_CLEAR_INT_1_POS  (10)
#define I2S_RX_FIFO_FULL_CLEAR_INT_1_MSK  (0x1 << I2S_RX_FIFO_FULL_CLEAR_INT_1_POS)
#define I2S_RX_FIFO_FULL_CLEAR_INT_1_CLR  (~I2S_RX_FIFO_FULL_CLEAR_INT_1_MSK)
/* DSP_INT_CR[9]: I2S_TX_FIFO_FULL_CLEAR_INT_1. */
#define I2S_TX_FIFO_FULL_CLEAR_INT_1_POS  (9)
#define I2S_TX_FIFO_FULL_CLEAR_INT_1_MSK  (0x1 << I2S_TX_FIFO_FULL_CLEAR_INT_1_POS)
#define I2S_TX_FIFO_FULL_CLEAR_INT_1_CLR  (~I2S_TX_FIFO_FULL_CLEAR_INT_1_MSK)

/* DSP_INT_CR[8]: I2S_RX_CLEAR_INT_1. */
#define I2S_RX_CLEAR_INT_1_POS            (8)
#define I2S_RX_CLEAR_INT_1_MSK            (0x1 << I2S_RX_CLEAR_INT_1_POS)
#define I2S_RX_CLEAR_INT_1_CLR            (~I2S_RX_CLEAR_INT_1_MSK)
/* DSP_INT_CR[7]: I2S_TX_CLEAR_INT_1. */
#define I2S_TX_CLEAR_INT_1_POS            (7)
#define I2S_TX_CLEAR_INT_1_MSK            (0x1 << I2S_TX_CLEAR_INT_1_POS)
#define I2S_TX_CLEAR_INT_1_CLR            (~I2S_TX_CLEAR_INT_1_MSK)

/* DSP_INT_CR[5]: I2S_RX_FIFO_EMPTY_CLEAR_INT_0. */
#define I2S_RX_FIFO_EMPTY_CLEAR_INT_0_POS  (5)
#define I2S_RX_FIFO_EMPTY_CLEAR_INT_0_MSK  (0x1 << I2S_RX_FIFO_EMPTY_CLEAR_INT_0_POS)
#define I2S_RX_FIFO_EMPTY_CLEAR_INT_0_CLR  (~I2S_RX_FIFO_EMPTY_CLEAR_INT_0_MSK)
/* DSP_INT_CR[4]: I2S_TX_FIFO_EMPTY_CLEAR_INT_0. */
#define I2S_TX_FIFO_EMPTY_CLEAR_INT_0_POS  (4)
#define I2S_TX_FIFO_EMPTY_CLEAR_INT_0_MSK  (0x1 << I2S_TX_FIFO_EMPTY_CLEAR_INT_0_POS)
#define I2S_TX_FIFO_EMPTY_CLEAR_INT_0_CLR  (~I2S_TX_FIFO_EMPTY_CLEAR_INT_0_MSK)
/* DSP_INT_CR[3]: I2S_RX_FIFO_FULL_CLEAR_INT_0. */
#define I2S_RX_FIFO_FULL_CLEAR_INT_0_POS  (3)
#define I2S_RX_FIFO_FULL_CLEAR_INT_0_MSK  (0x1 << I2S_RX_FIFO_FULL_CLEAR_INT_0_POS)
#define I2S_RX_FIFO_FULL_CLEAR_INT_0_CLR  (~I2S_RX_FIFO_FULL_CLEAR_INT_0_MSK)
/* DSP_INT_CR[2]: I2S_TX_FIFO_FULL_CLEAR_INT_0. */
#define I2S_TX_FIFO_FULL_CLEAR_INT_0_POS  (2)
#define I2S_TX_FIFO_FULL_CLEAR_INT_0_MSK  (0x1 << I2S_TX_FIFO_FULL_CLEAR_INT_0_POS)
#define I2S_TX_FIFO_FULL_CLEAR_INT_0_CLR  (~I2S_TX_FIFO_FULL_CLEAR_INT_0_MSK)

/* DSP_INT_CR[1]: I2S_RX_CLEAR_INT_0. */
#define I2S_RX_CLEAR_INT_0_POS            (1)
#define I2S_RX_CLEAR_INT_0_MSK            (0x1 << I2S_RX_CLEAR_INT_0_POS)
#define I2S_RX_CLEAR_INT_0_CLR            (~I2S_RX_CLEAR_INT_0_MSK)
/* DSP_INT_CR[0]: I2S_TX_CLEAR_INT_0. */
#define I2S_TX_CLEAR_INT_0_POS            (0)
#define I2S_TX_CLEAR_INT_0_MSK            (0x1 << I2S_TX_CLEAR_INT_0_POS)
#define I2S_TX_CLEAR_INT_0_CLR            (~I2S_TX_CLEAR_INT_0_MSK)

/* Register: FIFO_SR -------------------------------------------------------*/
/* Description: FIFO status register. Offset: 0x14. */

/* FIFO_SR[31]: I2S_SP_RESET_STATE. */
#define I2S_SP_RESET_STATE_POS       (24)
#define I2S_SP_RESET_STATE_MSK       (0x1 << I2S_SP_RESET_STATE_POS)
#define I2S_SP_RESET_STATE_CLR       (~I2S_SP_RESET_STATE_MSK)

/* FIFO_SR[29:24]: I2S_RX_FIFO_DEPTH_CNT_1. */
#define I2S_RX_FIFO_DEPTH_CNT_1_POS       (24)
#define I2S_RX_FIFO_DEPTH_CNT_1_MSK       (0x3F << I2S_RX_FIFO_DEPTH_CNT_1_POS)
#define I2S_RX_FIFO_DEPTH_CNT_1_CLR       (~I2S_RX_FIFO_DEPTH_CNT_1_MSK)
/* FIFO_SR[21:16]: I2S_TX_FIFO_DEPTH_CNT_1. */
#define I2S_TX_FIFO_DEPTH_CNT_1_POS       (16)
#define I2S_TX_FIFO_DEPTH_CNT_1_MSK       (0x3F << I2S_TX_FIFO_DEPTH_CNT_1_POS)
#define I2S_TX_FIFO_DEPTH_CNT_1_CLR       (~I2S_TX_FIFO_DEPTH_CNT_1_MSK)

/* FIFO_SR[13:8]: I2S_RX_FIFO_DEPTH_CNT_0. */
#define I2S_RX_FIFO_DEPTH_CNT_0_POS       (8)
#define I2S_RX_FIFO_DEPTH_CNT_0_MSK       (0x3F << I2S_RX_FIFO_DEPTH_CNT_0_POS)
#define I2S_RX_FIFO_DEPTH_CNT_0_CLR       (~I2S_RX_FIFO_DEPTH_CNT_0_MSK)
/* FIFO_SR[5:0]: I2S_TX_FIFO_DEPTH_CNT_0. */
#define I2S_TX_FIFO_DEPTH_CNT_0_POS       (0)
#define I2S_TX_FIFO_DEPTH_CNT_0_MSK       (0x3F << I2S_TX_FIFO_DEPTH_CNT_0_POS)
#define I2S_TX_FIFO_DEPTH_CNT_0_CLR       (~I2S_TX_FIFO_DEPTH_CNT_0_MSK)

/* Register: ERROR_CNT_SR -------------------------------------------------------*/
/* Description: Error counter status register. Offset: 0x18. */

/* ERROR_CNT_SR[15:8]: I2S_RX_ERR_CNT. */
#define I2S_RX_ERR_CNT_POS              (8)
#define I2S_RX_ERR_CNT_MSK              (0xFF << I2S_RX_ERR_CNT_POS)
#define I2S_RX_ERR_CNT_CLR              (~I2S_RX_ERR_CNT_MSK)
/* ERROR_CNT_SR[7:0]: I2S_TX_ERR_CNT. */
#define I2S_TX_ERR_CNT_POS              (0)
#define I2S_TX_ERR_CNT_MSK              (0xFF << I2S_TX_ERR_CNT_POS)
#define I2S_TX_ERR_CNT_CLR              (~I2S_TX_ERR_CNT_MSK)

/* Register: BCLK_DIV_TX -------------------------------------------------------*/
/* Description: TX BCLK divider register. Offset: 0x1C. */

/* BCLK_DIV_TX[31]: I2S_TX_MI_NI_UPDATE. */
#define I2S_MI_NI_UPDATE_POS        (31)
#define I2S_MI_NI_UPDATE_MSK        ((uint32_t)0x1 << I2S_MI_NI_UPDATE_POS)
#define I2S_MI_NI_UPDATE_CLR        (~I2S_MI_NI_UPDATE_MSK)
/* BCLK_DIV_TX[30:16]: I2S_TX_BCLK_NI. */
#define I2S_TX_BCLK_NI_POS             (16)
#define I2S_TX_BCLK_NI_MSK             (0x7FFF << I2S_TX_BCLK_NI_POS)
#define I2S_TX_BCLK_NI_CLR             (~I2S_TX_BCLK_NI_MSK)
/* BCLK_DIV_TX[15:0]: I2S_TX_BCLK_MI. */
#define I2S_TX_BCLK_MI_POS             (0)
#define I2S_TX_BCLK_MI_MSK             (0xFFFF << I2S_TX_BCLK_MI_POS)
#define I2S_TX_BCLK_MI_CLR             (~I2S_TX_BCLK_MI_MSK)


/* Register: DMA_TRDLR -------------------------------------------------------*/
/* Description: DMA transmit receive data level register. Offset: 0x20. */
/* DMA_TRDLR[31:24]: I2S_RX_BCLK_DIV_RATIO. */
#define I2S_RX_BCLK_DIV_RATIO_POS   (16)
#define I2S_RX_BCLK_DIV_RATIO_MSK   (0xFF << I2S_RX_BCLK_DIV_RATIO_POS)
#define I2S_RX_BCLK_DIV_RATIO_CLR   (~I2S_RX_BCLK_DIV_RATIO_MSK)

/* DMA_TRDLR[23:16]: I2S_TX_BCLK_DIV_RATIO. */
#define I2S_TX_BCLK_DIV_RATIO_POS   (16)
#define I2S_TX_BCLK_DIV_RATIO_MSK   (0xFF << I2S_TX_BCLK_DIV_RATIO_POS)
#define I2S_TX_BCLK_DIV_RATIO_CLR   (~I2S_TX_BCLK_DIV_RATIO_MSK)

/* DMA_TRDLR[5:0]: I2S_TX_DMA_BURST_SIZE. */
#define I2S_TX_DMA_BURST_SIZE_POS   (0)
#define I2S_TX_DMA_BURST_SIZE_MSK   (0x3F << I2S_TX_DMA_BURST_SIZE_POS)
#define I2S_TX_DMA_BURST_SIZE_CLR   (~I2S_TX_DMA_BURST_SIZE_MSK)
/* DMA_TRDLR[13:8]: I2S_RX_DMA_BURST_SIZE. */
#define I2S_RX_DMA_BURST_SIZE_POS   (8)
#define I2S_RX_DMA_BURST_SIZE_MSK   (0x3F << I2S_RX_DMA_BURST_SIZE_POS)
#define I2S_RX_DMA_BURST_SIZE_CLR   (~I2S_RX_DMA_BURST_SIZE_MSK)

/* Register: BCLK_DIV_RX -------------------------------------------------------*/
/* Description: RX BCLK divider register. Offset: 0x2C. */
/* BCLK_DIV_RX[31]: I2S_RX_MI_NI_UPDATE. */
#define I2S_RX_MI_NI_UPDATE_POS        (31)
#define I2S_RX_MI_NI_UPDATE_MSK        ((uint32_t)0x1 << I2S_RX_MI_NI_UPDATE_POS)
#define I2S_RX_MI_NI_UPDATE_CLR        (~I2S_RX_MI_NI_UPDATE_MSK)
/* BCLK_DIV_RX[30:16]: I2S_RX_BCLK_NI. */
#define I2S_RX_BCLK_NI_POS             (16)
#define I2S_RX_BCLK_NI_MSK             (0x7FFF << I2S_RX_BCLK_NI_POS)
#define I2S_RX_BCLK_NI_CLR             (~I2S_RX_BCLK_NI_MSK)
/* BCLK_DIV_RX[15:0]: I2S_RX_BCLK_MI. */
#define I2S_RX_BCLK_MI_POS             (0)
#define I2S_RX_BCLK_MI_MSK             (0xFFFF << I2S_RX_BCLK_MI_POS)
#define I2S_RX_BCLK_MI_CLR             (~I2S_RX_BCLK_MI_MSK)

///* Register: PERIPH_AUDIO_CLK_224 -------------------------------------------------------*/
///* Description: peri on register. address: 0x40000224. */
//#define PERIPH_AUDIO_CLK_224        0x40000224
///* PERIPH_AUDIO_CLK_224[3]: I2S0_EXT_CODEC. */
//#define I2S0_EXT_CODEC_POS         (3)
//#define I2S0_EXT_CODEC_MSK         (0x1 << I2S0_EXT_CODEC_POS)
//#define I2S0_EXT_CODEC_CLR         (~I2S0_EXT_CODEC_MSK)

///* Register: PERIPH_AUDIO_CLK_228 -------------------------------------------------------*/
///* Description: peri on register. address: 0x40000228. */
//#define PERIPH_AUDIO_CLK_228        0x40000228
///* PERIPH_AUDIO_CLK_228[4]: I2S_MCLK_OUTPUT. */
//#define I2S_MCLK_OUTPUT_POS         (4)
//#define I2S_MCLK_OUTPUT_MSK         (0x1 << I2S_MCLK_OUTPUT_POS)
//#define I2S_MCLK_OUTPUT_CLR         (~I2S_MCLK_OUTPUT_MSK)


/*============================================================================*
 *                         Constants
 *============================================================================*/

/**
 * \defgroup    I2S_Exported_Constants  Macro Defines
 *
 * \ingroup     I2S
 */

#define IS_I2S_ALL_PERIPH(PERIPH) (((PERIPH) == I2S0) || \
                                   ((PERIPH) == I2S1))

/**
 * \defgroup    I2S_Clock_Source I2S Clock Source
 * \{
 * \ingroup     I2S_Exported_Constants
 */
#define I2S_CLK_XTAL                                 (0x0)
#define I2S_CLK_PLL                                  (0x1)

/** \} */

#define IS_I2S_CLK_SOURCE(CLK) (((CLK) == I2S_CLK_XTAL) || \
                                ((CLK) == I2S_CLK_PLL) || \
                                ((CLK) == I2S_CLK_256fs))

/**
 * \defgroup    I2S_Device_Mode I2S Device Mode
 * \{
 * \ingroup     I2S_Exported_Constants
 */

#define I2S_DeviceMode_Master                       ((uint32_t)0x00)
#define I2S_DeviceMode_Slave                        (I2S_SLAVE_DATA_SEL_MSK )//| I2S_SLAVE_CLK_SEL_MSK)
/** \} */

#define IS_I2S_DEVICE_MODE(DEVICE)      (((DEVICE) == I2S_DeviceMode_Master) || ((DEVICE) == I2S_DeviceMode_Slave))

/**
 * \defgroup    I2S_Mode I2S Mode
 * \{
 * \ingroup     I2S_Exported_Constants
 */
#define I2S_MODE_TX                                 (I2S_START_TX_MSK)
#define I2S_MODE_RX                                 (I2S_START_RX_MSK)
/** \} */

#define IS_I2S_MODE(MODE)               (((MODE) == I2S_MODE_TX) || ((MODE) == I2S_MODE_RX))

/**
 * \defgroup    I2S_Channel_Type I2S Channel Type
 * \{
 * \ingroup     I2S_Exported_Constants
 */
#define I2S_Channel_Mono                            ((uint32_t)(0x1))
#define I2S_Channel_stereo                          ((uint32_t)(0x0))
/** \} */

#define IS_I2S_CHANNEL_TYPE(TYPE)       (((TYPE) == I2S_Channel_Mono) || ((TYPE) == I2S_Channel_stereo))

/**
 * \defgroup    I2S_Tx_Ch_Sequence I2S Transmission Channel Sequence
 * \{
 * \ingroup     I2S_Exported_Constants
 */
#define I2S_TX_CH_L_R                           (0)
#define I2S_TX_CH_R_L                           ((uint32_t)0x01 << I2S_TX_CH_SEQ_POS)
#define I2S_TX_CH_L_L                           ((uint32_t)0x02 << I2S_TX_CH_SEQ_POS)
#define I2S_TX_CH_R_R                           ((uint32_t)0x03 << I2S_TX_CH_SEQ_POS)
/** \} */

#define IS_I2S_TX_CH_SEQ(SEQ)       (((SEQ) == I2S_TX_CH_L_R) || ((SEQ) == I2S_TX_CH_R_L) || \
                                     ((SEQ) == I2S_TX_CH_L_L) || ((SEQ) == I2S_TX_CH_R_R))

/**
 * \defgroup    I2S_Rx_Ch_Sequence I2S Receiving Channel Sequence
 * \{
 * \ingroup     I2S_Exported_Constants
 */
#define I2S_RX_CH_L_R                           (0)
#define I2S_RX_CH_R_L                           ((uint32_t)0x01 << I2S_RX_CH_SEQ_POS)
#define I2S_RX_CH_L_L                           ((uint32_t)0x02 << I2S_RX_CH_SEQ_POS)
#define I2S_RX_CH_R_R                           ((uint32_t)0x03 << I2S_RX_CH_SEQ_POS)
/** \} */

#define IS_I2S_RX_CH_SEQ(SEQ)       (((SEQ) == I2S_RX_CH_L_R) || ((SEQ) == I2S_RX_CH_R_L) || \
                                     ((SEQ) == I2S_RX_CH_L_L) || ((SEQ) == I2S_RX_CH_R_R))

/**
 * \defgroup    I2S_Format_Mode I2S Format Mode
 * \{
 * \ingroup     I2S_Exported_Constants
 */
#define I2S_Mode                                    (uint32_t)0x00
#define Left_Justified_Mode                         (uint32_t)0x01
#define PCM_Mode_A                                  (uint32_t)0x02
#define PCM_Mode_B                                  (uint32_t)0x03
/** \} */

#define IS_I2S_DATA_FORMAT(FORMAT)      (((FORMAT) == I2S_Mode) || ((FORMAT) == Left_Justified_Mode) || \
                                         ((FORMAT) == PCM_Mode_A) || ((FORMAT) == PCM_Mode_B))

/**
 * \defgroup    I2S_Tx_Bit_Sequence I2S Tx Bit Sequence
 * \{
 * \ingroup     I2S_Exported_Constants
 */
#define I2S_TX_MSB_First                            ((uint32_t)0x0)
#define I2S_TX_LSB_First                            (I2S_TX_LSB_FIRST_MSK)
/** \} */

#define IS_I2S_TX_BIT_SEQ(SEQ)      (((SEQ) == I2S_TX_MSB_First) || ((SEQ) == I2S_TX_LSB_First))

/**
 * \defgroup    I2S_Rx_Bit_Sequence I2S Rx Bit Sequence
 * \{
 * \ingroup     I2S_Exported_Constants
 */
#define I2S_RX_MSB_First                            ((uint32_t)0x0)
#define I2S_RX_LSB_First                            (I2S_RX_LSB_FIRST_MSK)
/** \} */

#define IS_I2S_RX_BIT_SEQ(SEQ)      (((SEQ) == I2S_RX_MSB_First) || ((SEQ) == I2S_RX_LSB_First))

/**
 * \defgroup    I2S_Data_Width I2S Data Width
 * \{
 * \ingroup     I2S_Exported_Constants
 */

#define I2S_Width_16Bits                            (uint32_t) (0x00 )
#define I2S_Width_20Bits                            (uint32_t) (0x01 )
#define I2S_Width_24Bits                            (uint32_t) (0x02 )
#define I2S_Width_8Bits                             (uint32_t) (0x03 )
#define I2S_Width_32Bits                            (uint32_t) (0x04 )
/** \} */

#define IS_I2S_DATA_WIDTH(WIDTH)        (((WIDTH) == I2S_Width_16Bits) || \
                                         ((WIDTH) == I2S_Width_24Bits) || \
                                         ((WIDTH) == I2S_Width_8Bits))

/**
 * \defgroup    I2S_DMA_Cmd I2S DMA Cmd
 * \{
 * \ingroup     I2S_Exported_Constants
 */
#define I2S_DMA_ENABLE                              ((uint32_t)0x0)
#define I2S_DMA_DISABLE                             (I2S_CTRL_MODE_MSK)
/** \} */

#define IS_I2S_DMA_CMD(CMD)       (((CMD) == I2S_DMA_ENABLE) || ((CMD) == I2S_DMA_DISABLE))

/**
 * \defgroup    I2S_Interrupt_Definition   I2S Interrupt Definition
 * \{
 * \ingroup     I2S_Exported_Constants
 */
#define I2S_INT_TX_IDLE                             I2S_TX_IDLE_0_MSK
#define I2S_INT_RF_EMPTY                            I2S_RF_EMPTY_0_MSK
#define I2S_INT_TF_EMPTY                            I2S_TF_EMPTY_0_MSK
#define I2S_INT_RF_FULL                             I2S_RX_FULL_0_MSK
#define I2S_INT_TF_FULL                             I2S_TX_FULL_0_MSK
#define I2S_INT_RX_READY                            I2S_READY_TO_RX_0_MSK
#define I2S_INT_TX_READY                            I2S_READY_TO_TX_0_MSK
/** \} */

#define IS_I2S_INT_CONFIG(INT)          (((INT) == I2S_INT_TX_IDLE) || ((INT) == I2S_INT_RF_EMPTY) || \
                                         ((INT) == I2S_INT_TF_EMPTY) || ((INT) == I2S_INT_RF_FULL) || \
                                         ((INT) == I2S_INT_TF_FULL) || ((INT) == I2S_INT_RX_READY) || \
                                         ((INT) == I2S_INT_TX_READY) )

#define I2S_MCU_INT_TX_VALID                            BIT7//(I2S_TX_IDLE_MSK)
#define I2S_MCU_INT_TX_IDLE                             BIT6//(I2S_TX_IDLE_MSK)
#define I2S_MCU_INT_RF_EMPTY                            BIT5//(I2S_RF_EMPTY_MSK)
#define I2S_MCU_INT_TF_EMPTY                            BIT4// (I2S_TF_EMPTY_MSK)
#define I2S_MCU_INT_RF_FULL                             BIT3// (I2S_RX_FULL_MSK)
#define I2S_MCU_INT_TF_FULL                             BIT2// (I2S_TX_FULL_MSK)
#define I2S_MCU_INT_RX_READY                            BIT1// (I2S_READY_TO_RX_MSK)
#define I2S_MCU_INT_TX_READY                            BIT0// (I2S_READY_TO_TX_MSK)

#define IS_I2S_MCU_INT_CONFIG(INT)          (((INT) == I2S_MCU_INT_TX_IDLE) || ((INT) == I2S_MCU_INT_RF_EMPTY) || \
                                             ((INT) == I2S_MCU_INT_TF_EMPTY) || ((INT) == I2S_MCU_INT_RF_FULL) || \
                                             ((INT) == I2S_MCU_INT_TF_FULL) || ((INT) == I2S_MCU_INT_RX_READY) || \
                                             ((INT) == I2S_MCU_INT_TX_READY) )

/**
 * \defgroup   I2S_Clear_Interrupt_Definition     I2S Clear Interrupt Definition
 * \{
 * \ingroup     I2S_Exported_Constants
 */
#define I2S_CLEAR_INT_RX_READY                      (I2S_RX_CLEAR_INT_MSK)
#define I2S_CLEAR_INT_TX_READY                      (I2S_TX_CLEAR_INT_MSK)
//#define I2S_CLEAR_INT_RX_READY                      (I2S_RX_CLEAR_INT__MSK)
//#define I2S_CLEAR_INT_TX_READY                      (I2S_TX_CLEAR_INT_MSK)
/** \} */

#define IS_I2S_CLEAR_INT(CLEAR)          (((CLEAR) == I2S_CLEAR_INT_RX_READY) || \
                                          ((CLEAR) == I2S_CLEAR_INT_TX_READY) || \
                                          (CLEAR) == I2S_CLEAR_INT_RX_READY) || \
((CLEAR) == I2S_CLEAR_INT_TX_READY) )


/**
 * \defgroup   I2S_Tdm_Mode_Definition     I2S Tdm Mode Definition
 * \{
 * \ingroup     I2S_Exported_Constants
 */
#define    I2S_TDM_DISABLE                                                     0x00
#define    I2S_TDM_MODE_4                                                      0x01
#define    I2S_TDM_MODE_6                                                      0x02
#define    I2S_TDM_MODE_8                                                  0x03

#define IS_I2S_TDM_MODE(MODE)             (((MODE) == I2S_TDM_DISABLE) || \
                                           ((MODE) == I2S_TDM_MODE_4) || \
                                           (MODE) ==  I2S_TDM_MODE_6) || \
((MODE) == I2S_TDM_MODE_8) )

/** \} */


#define    I2S_FIFO_USE_0_REG_0         BIT0
#define    I2S_FIFO_USE_0_REG_1         BIT1|BIT0
#define    I2S_FIFO_USE_1_REG_0         BIT2
#define    I2S_FIFO_USE_1_REG_1         BIT3|BIT2

//#define    I2S_SCHEME_DEPENDENT         0x0
//#define    I2S_SCHEME_SEPARATE          0x1


#define    I2S_DIRECT_MODE_DISABLE     0x00
#define    I2S_DIRECT_MODE_SRC_SPORT0  0x04
#define    I2S_DIRECT_MODE_SRC_SPORT1  0x05
#define    I2S_DIRECT_MODE_SRC_SPORT2  0x06
#define    I2S_DIRECT_MODE_SRC_SPORT3  0x07

#define    I2S_DIRECT_OUT_NONE     0x0
#define    I2S_DIRECT_OUT_EN_0     BIT0
#define    I2S_DIRECT_OUT_EN_1     BIT1
#define    I2S_DIRECT_OUT_EN_2     BIT2
#define    I2S_DIRECT_OUT_EN_3     BIT3
#define    I2S_DIRECT_OUT_EN_4     BIT4
#define    I2S_DIRECT_OUT_EN_5     BIT5
#define    I2S_DIRECT_OUT_EN_6     BIT6
#define    I2S_DIRECT_OUT_EN_7     BIT7


typedef enum t_sport_tx_sel
{
    I2S_TX_FIFO_0_REG_0_L,                        // 0
    I2S_TX_FIFO_0_REG_0_R,                        // 1
    I2S_TX_FIFO_0_REG_1_L,                        // 2
    I2S_TX_FIFO_0_REG_1_R,                        // 3
    I2S_TX_FIFO_1_REG_0_L,                        // 4
    I2S_TX_FIFO_1_REG_0_R,                        // 5
    I2S_TX_FIFO_1_REG_1_L,                        // 6
    I2S_TX_FIFO_1_REG_1_R,                        // 7
    I2S_TX_DIRECT_REG,                            // 8

    I2S_TX_DIRECT_IN_A0 = I2S_TX_DIRECT_REG,    // 8
    I2S_TX_DIRECT_IN_A1,                          // 9
    I2S_TX_DIRECT_IN_A2,                          // 10
    I2S_TX_DIRECT_IN_A3,                          // 11
    I2S_TX_DIRECT_IN_A4,                          // 12
    I2S_TX_DIRECT_IN_A5,                          // 13
    I2S_TX_DIRECT_IN_A6,                          // 14
    I2S_TX_DIRECT_IN_A7,                          // 15
    I2S_TX_DIRECT_IN_B0,                          // 16
    I2S_TX_DIRECT_IN_B1,                          // 17
    I2S_TX_DIRECT_IN_B2,                          // 18
    I2S_TX_DIRECT_IN_B3,                          // 19
    I2S_TX_DIRECT_IN_B4,                          // 20
    I2S_TX_DIRECT_IN_B5,                          // 21
    I2S_TX_DIRECT_IN_B6,                          // 22
    I2S_TX_DIRECT_IN_B7,                          // 23
    I2S_TX_DIRECT_IN_C0,                          // 24
    I2S_TX_DIRECT_IN_C1,                          // 25
    I2S_TX_DIRECT_IN_C2,                          // 26
    I2S_TX_DIRECT_IN_C3,                          // 27
    I2S_TX_DIRECT_IN_C4,                          // 28
    I2S_TX_DIRECT_IN_C5,                          // 29
    I2S_TX_DIRECT_IN_C6,                          // 30
    I2S_TX_DIRECT_IN_C7,                          // 31
    I2S_TX_SEL_MAX,
} T_I2S_TX_SEL;

typedef enum t_sport_rx_sel
{
    I2S_RX_CHANNEL_0,                             // 0
    I2S_RX_CHANNEL_1,                             // 1
    I2S_RX_CHANNEL_2,                             // 2
    I2S_RX_CHANNEL_3,                             // 3
    I2S_RX_CHANNEL_4,                             // 4
    I2S_RX_CHANNEL_5,                             // 5
    I2S_RX_CHANNEL_6,                             // 6
    I2S_RX_CHANNEL_7,                             // 7
    I2S_RX_DIRECT_IN_A0,                          // 8
    I2S_RX_DIRECT_IN_A1,                          // 9
    I2S_RX_DIRECT_IN_A2,                          // 10
    I2S_RX_DIRECT_IN_A3,                          // 11
    I2S_RX_DIRECT_IN_A4,                          // 12
    I2S_RX_DIRECT_IN_A5,                          // 13
    I2S_RX_DIRECT_IN_A6,                          // 14
    I2S_RX_DIRECT_IN_A7,                          // 15
    I2S_RX_DIRECT_IN_B0,                          // 16
    I2S_RX_DIRECT_IN_B1,                          // 17
    I2S_RX_DIRECT_IN_B2,                          // 18
    I2S_RX_DIRECT_IN_B3,                          // 19
    I2S_RX_DIRECT_IN_B4,                          // 20
    I2S_RX_DIRECT_IN_B5,                          // 21
    I2S_RX_DIRECT_IN_B6,                          // 22
    I2S_RX_DIRECT_IN_B7,                          // 23
    I2S_RX_DIRECT_IN_C0,                          // 24
    I2S_RX_DIRECT_IN_C1,                          // 25
    I2S_RX_DIRECT_IN_C2,                          // 26
    I2S_RX_DIRECT_IN_C3,                          // 27
    I2S_RX_DIRECT_IN_C4,                          // 28
    I2S_RX_DIRECT_IN_C5,                          // 29
    I2S_RX_DIRECT_IN_C6,                          // 30
    I2S_RX_DIRECT_IN_C7,                          // 31
    I2S_RX_SEL_MAX,
} T_I2S_RX_SEL;

/*============================================================================*
 *                         Functions
 *============================================================================*/

/**
 * \defgroup    I2S_Exported_Functions Peripheral APIs
 * \{
 * \ingroup     I2S
 */

/**
 * \brief   Deinitializes the I2S peripheral registers to their default values.
 * \param   None.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_i2s_init(void)
 * {
 *     I2S_DeInit(I2S0);
 * }
 * \endcode
 */
void I2S_DeInit(I2S_TypeDef *I2Sx);

/**
 * \brief   Initializes the I2S peripheral according to the specified
 *          parameters in the I2S_InitStruct
 * \param[in] I2Sx: Selected I2S peripheral.
 * \param[in] I2S_InitStruct: Pointer to a I2S_InitTypeDef structure that
 *            contains the configuration information for the specified I2S peripheral
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_i2s_init(void)
 * {
 *     RCC_PeriphClockCmd(APB_I2S, APB_I2S_CLOCK, ENABLE);
 *
 *     I2S_InitTypeDef I2S_InitStruct;
 *
 *     I2S_StructInit(&I2S_InitStruct);
 *     I2S_InitStruct.I2S_ClockSource      = I2S_CLK_40M;
 *     I2S_InitStruct.I2S_BClockMi         = 0x271;
 *     I2S_InitStruct.I2S_BClockNi         = 0x10;
 *     I2S_InitStruct.I2S_DeviceMode       = I2S_DeviceMode_Master;
 *     I2S_InitStruct.I2S_ChannelType      = I2S_Channel_stereo;
 *     I2S_InitStruct.I2S_DataWidth        = I2S_Width_16Bits;
 *     I2S_InitStruct.I2S_DataFormat       = I2S_Mode;
 *     I2S_InitStruct.I2S_DMACmd           = I2S_DMA_DISABLE;
 *     I2S_Init(I2S0, &I2S_InitStruct);
 *     I2S_Cmd(I2S0, I2S_MODE_TX, ENABLE);
 * }
 * \endcode
 */
void I2S_Init(I2S_TypeDef *I2Sx, I2S_InitTypeDef *I2S_InitStruct);
void I2S_DataSelInit(I2S_TypeDef *I2Sx, I2S_DataSelTypeDef *I2S_DataSelect);
/**
 * \brief   Fills each I2S_InitStruct member with its default value.
 * \param[in] I2S_InitStruct: Pointer to an I2S_InitTypeDef structure which will be initialized.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_i2s_init(void)
 * {
 *     RCC_PeriphClockCmd(APB_I2S, APB_I2S_CLOCK, ENABLE);
 *
 *     I2S_InitTypeDef I2S_InitStruct;
 *
 *     I2S_StructInit(&I2S_InitStruct);
 *     I2S_InitStruct.I2S_ClockSource      = I2S_CLK_40M;
 *     I2S_InitStruct.I2S_BClockMi         = 0x271;
 *     I2S_InitStruct.I2S_BClockNi         = 0x10;
 *     I2S_InitStruct.I2S_DeviceMode       = I2S_DeviceMode_Master;
 *     I2S_InitStruct.I2S_ChannelType      = I2S_Channel_stereo;
 *     I2S_InitStruct.I2S_DataWidth        = I2S_Width_16Bits;
 *     I2S_InitStruct.I2S_DataFormat       = I2S_Mode;
 *     I2S_InitStruct.I2S_DMACmd           = I2S_DMA_DISABLE;
 *     I2S_Init(I2S0, &I2S_InitStruct);
 *     I2S_Cmd(I2S0, I2S_MODE_TX, ENABLE);
 * }
 * \endcode
 */
void I2S_StructInit(I2S_InitTypeDef *I2S_InitStruct);
void I2S_DataSelStructInit(I2S_DataSelTypeDef *I2S_DataSelect);
/**
 * \brief   Enable or disable the selected I2S mode.
 * \param[in] I2Sx: Selected I2S peripheral.
 * \param[in] mode: Selected I2S operation mode.
 *      This parameter can be the following values:
 *      \arg I2S_MODE_TX: Transmission mode.
 *      \arg I2S_MODE_RX: Receiving mode.
 * \param[in] NewState: New state of the operation mode.
 *      This parameter can be: ENABLE or DISABLE.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_i2s_init(void)
 * {
 *     RCC_PeriphClockCmd(APB_I2S, APB_I2S_CLOCK, ENABLE);
 *
 *     I2S_InitTypeDef I2S_InitStruct;
 *
 *     I2S_StructInit(&I2S_InitStruct);
 *     I2S_InitStruct.I2S_ClockSource      = I2S_CLK_40M;
 *     I2S_InitStruct.I2S_BClockMi         = 0x271;
 *     I2S_InitStruct.I2S_BClockNi         = 0x10;
 *     I2S_InitStruct.I2S_DeviceMode       = I2S_DeviceMode_Master;
 *     I2S_InitStruct.I2S_ChannelType      = I2S_Channel_stereo;
 *     I2S_InitStruct.I2S_DataWidth        = I2S_Width_16Bits;
 *     I2S_InitStruct.I2S_DataFormat       = I2S_Mode;
 *     I2S_InitStruct.I2S_DMACmd           = I2S_DMA_DISABLE;
 *     I2S_Init(I2S_NUM, &I2S_InitStruct);
 *     I2S_Cmd(I2S_NUM, I2S_MODE_TX, ENABLE);
 * }
 * \endcode
 */
void I2S_Cmd(I2S_TypeDef *I2Sx, uint32_t mode, FunctionalState NewState);

/**
 * \brief   Enable or disable the specified I2S interrupt source.
 * \param[in] I2S_INT: Specifies the I2S interrupt source to be enable or disable.
 *      This parameter can be the following values:
 *      \arg I2S_INT_TX_IDLE: Transmit idle interrupt source.
 *      \arg I2S_INT_RF_EMPTY: Receive FIFO empty interrupt source.
 *      \arg I2S_INT_TF_EMPTY: Transmit FIFO empty interrupt source.
 *      \arg I2S_INT_RF_FULL: Receive FIFO full interrupt source.
 *      \arg I2S_INT_TF_FULL: Transmit FIFO full interrupt source.
 *      \arg I2S_INT_RX_READY: Ready to receive interrupt source.
 *      \arg I2S_INT_TX_READY: Ready to transmit interrupt source.
 * \param[in]  NewState: New state of the specified I2S interrupt.
 *      This parameter can be: ENABLE or DISABLE.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void i2s_demo(void)
 * {
 *     I2S_INTConfig(I2S0, I2S_INT_TF_EMPTY, ENABLE);
 * }
 * \endcode
 */
void I2S_INTConfig(I2S_TypeDef *I2Sx, uint32_t I2S_INT, FunctionalState newState);
void I2S_MCU_INTConfig(I2S_TypeDef *I2Sx, uint32_t I2S_MCU_INT, FunctionalState NewState);
/**
 * \brief   Get the specified I2S interrupt status.
 * \param[in] I2S_INT: the specified I2S interrupt.
 *      This parameter can be one of the following values:
 *      \arg I2S_INT_TX_IDLE: Transmit idle interrupt.
 *      \arg I2S_INT_RF_EMPTY: Receive FIFO empty interrupt.
 *      \arg I2S_INT_TF_EMPTY: Transmit FIFO empty interrupt.
 *      \arg I2S_INT_RF_FULL: Receive FIFO full interrupt.
 *      \arg I2S_INT_TF_FULL: Transmit FIFO full interrupt.
 *      \arg I2S_INT_RX_READY: Ready to receive interrupt.
 *      \arg I2S_INT_TX_READY: Ready to transmit interrupt.
 * \retval The new state of I2S_INT (SET or RESET).
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void i2s_demo(void)
 * {
 *     ITStatus int_status = I2S_GetINTStatus(I2S0, I2S_INT_TF_EMPTY);
 * }
 * \endcode
 */
ITStatus I2S_GetINTStatus(I2S_TypeDef *I2Sx, uint32_t I2S_INT);

/**
 * \brief  Clear the I2S interrupt pending bit.
 * \param[in] I2S_CLEAR_INT: Specifies the interrupt pending bit to clear.
 *      This parameter can be any combination of the following values:
 *      \arg I2S_CLEAR_INT_RX_READY: Clear ready to receive interrupt.
 *      \arg I2S_CLEAR_INT_TX_READY: Clear ready to transmit interrupt.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void i2s_demo(void)
 * {
 *     I2S_ClearINTPendingBit(I2S0, I2S_CLEAR_INT_RX_READY);
 * }
 * \endcode
 */
void I2S_ClearINTPendingBit(I2S_TypeDef *I2Sx, uint32_t I2S_CLEAR_INT);

/*
 * @brief  Select I2S connect to external codec or internal codec.
 * \param[in]  NewState: New state of the specified I2S interrupt.
 *      This parameter can be: ENABLE or DISABLE.
 * @retval None
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void i2s_demo(void)
 * {
 *     I2S_CodecSelInternal(I2S0, ENABLE);
 * }
 * \endcode
 */
void I2S_CodecSelInternal(I2S_TypeDef *I2Sx, FunctionalState newState);
/**
 * \brief   Transmits a data through the SPIx/I2Sx peripheral.
 * \param[in] I2Sx: To select the I2Sx peripheral, x can be 0 or 1.
 * \param[in] Data: Data to be transmitted.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void i2s_demo(void)
 * {
 *     I2S_SendData(I2S0, 0x02);
 * }
 * \endcode
 */
__STATIC_INLINE void I2S_SendData(I2S_TypeDef *I2Sx, uint32_t Data)
{
    /* Check the parameters */
    assert_param(IS_I2S_ALL_PERIPH(I2Sx));
    if (I2Sx == I2S0)
    {
//            *((volatile uint32_t *)I2S0_TX_ADDR) = Data;
        (*((volatile uint32_t *)0x40300800)) = Data;

    }
    else if (I2Sx == I2S1)
    {
//            (*((volatile uint32_t *)I2S1_TX_ADDR)) = Data;
        (*((volatile uint32_t *)0x40304800)) = Data;
    }
    else if (I2Sx == I2S2)
    {
//            (*((volatile uint32_t *)I2S2_TX_ADDR)) = Data;
        (*((volatile uint32_t *)0x40308800)) = Data;
    }
    else if (I2Sx == I2S3)
    {
//            (*((volatile uint32_t *)I2S3_TX_ADDR)) = Data;
        (*((volatile uint32_t *)0x4030C800)) = Data;

    }

}


/**
 * \brief  Received data by the I2Sx peripheral.
 * \param[in] I2Sx: To select I2Sx peripheral, where x can be: 0 or 1.
 * \return Return the most recent received data.
 * \
 * <b>Example usage</b>
 * \code{.c}
 *
 * void i2s_demo(void)
 * {
 *     uint32_t data = I2S_ReceiveData(I2S0);
 * }
 * \endcode
 */
//__STATIC_INLINE uint32_t I2S_ReceiveData(I2S_TypeDef *I2Sx)
//{
//    /* Check the parameters */
//    assert_param(IS_I2S_ALL_PERIPH(I2Sx));

//    return I2Sx->RX_DR;
//}


__STATIC_INLINE uint32_t I2S_ReceiveFIFOData(I2S_TypeDef *I2Sx)
{
    /* Check the parameters */
    assert_param(IS_I2S_ALL_PERIPH(I2Sx));

    if (I2Sx == I2S0)
    {
        return (*((volatile uint32_t *)I2S0_RX_ADDR));
    }
    else if (I2Sx == I2S1)
    {
        return (*((volatile uint32_t *)I2S1_RX_ADDR));
    }
    else if (I2Sx == I2S2)
    {
        return (*((volatile uint32_t *)I2S2_RX_ADDR));
    }
    else if (I2Sx == I2S3)
    {
        return (*((volatile uint32_t *)I2S3_RX_ADDR));
    }

    return I2Sx->RX_DR;
}

/**
 * \brief   Get transmit FIFO free length by the I2Sx peripheral.
 * \param[in] I2Sx: To select I2Sx peripheral, where x can be: 0 or 1.
 * \retval  Return the transmit FIFO free length.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void i2s_demo(void)
 * {
 *     uint8_t data_len = I2S_GetTxFIFOFreeLen(I2S0);
 * }
 * \endcode
 */
__STATIC_INLINE uint8_t I2S_GetTxFIFOFreeLen(I2S_TypeDef *I2Sx)
{
    /* Check the parameters */
    assert_param(IS_I2S_ALL_PERIPH(I2Sx));

    return ((I2Sx->FIFO_SR & I2S_TX_FIFO_DEPTH_CNT_0_MSK) >> I2S_TX_FIFO_DEPTH_CNT_0_POS);
}

__STATIC_INLINE uint8_t I2S_GetTxFIFO1FreeLen(I2S_TypeDef *I2Sx)
{
    /* Check the parameters */
    assert_param(IS_I2S_ALL_PERIPH(I2Sx));

    return ((I2Sx->FIFO_SR & I2S_TX_FIFO_DEPTH_CNT_1_MSK) >> I2S_TX_FIFO_DEPTH_CNT_1_POS);
}
/**
 * \brief   Get receive FIFO data length by the I2Sx peripheral.
 * \param[in] I2Sx: To select I2Sx peripheral, where x can be: 0 or 1.
 * \return  The data length of the receive FIFO.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void i2s_demo(void)
 * {
 *     uint8_t data_len = I2S_GetRxFIFOLen(I2S0);
 * }
 * \endcode
 */
__STATIC_INLINE uint8_t I2S_GetRxFIFOLen(I2S_TypeDef *I2Sx)
{
    /* Check the parameters */
    assert_param(IS_I2S_ALL_PERIPH(I2Sx));

    return ((I2Sx->FIFO_SR & I2S_RX_FIFO_DEPTH_CNT_0_MSK) >> I2S_RX_FIFO_DEPTH_CNT_0_POS);
}

__STATIC_INLINE uint8_t I2S_GetRxFIFO1Len(I2S_TypeDef *I2Sx)
{
    /* Check the parameters */
    assert_param(IS_I2S_ALL_PERIPH(I2Sx));

    return ((I2Sx->FIFO_SR & I2S_RX_FIFO_DEPTH_CNT_1_MSK) >> I2S_RX_FIFO_DEPTH_CNT_1_POS);
}
/**
 * \brief   Get the send error counter value by the I2Sx peripheral.
 * \param[in]  I2Sx: To select I2Sx peripheral, where x can be: 0 or 1.
 * \return  The send error counter value .
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void i2s_demo(void)
 * {
 *     uint8_t conter = I2S_GetTxErrCnt(I2S0);
 * }
 * \endcode
 */
__STATIC_INLINE uint8_t I2S_GetTxErrCnt(I2S_TypeDef *I2Sx)
{
    /* Check the parameters */
    assert_param(IS_I2S_ALL_PERIPH(I2Sx));

    return ((I2Sx->ERROR_CNT_SR & I2S_TX_ERR_CNT_MSK) >> I2S_TX_ERR_CNT_POS);
}

/**
 * \brief  Get the reception error counter value by the I2Sx peripheral.
 * \param[in] I2Sx: To select I2Sx peripheral, where x can be: 0 or 1.
 * \retval  The reception error counter value .
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void i2s_demo(void)
 * {
 *     uint8_t conter = I2S_GetRxErrCnt(I2S0);
 * }
 * \endcode
 */
__STATIC_INLINE uint8_t I2S_GetRxErrCnt(I2S_TypeDef *I2Sx)
{
    /* Check the parameters */
    assert_param(IS_I2S_ALL_PERIPH(I2Sx));

    return ((I2Sx->ERROR_CNT_SR & I2S_RX_ERR_CNT_MSK) >> I2S_RX_ERR_CNT_POS);
}

/**
 * \brief   Swap audio data bytes sequence which sent by the I2Sx peripheral.
 * \param[in] I2Sx: To select I2Sx peripheral, where x can be: 0 or 1.
 * \param[in] NewState: New state of the bytes sequence.
 *      This parameter can be: ENABLE or DISABLE.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void i2s_demo(void)
 * {
 *     I2S_SwapBytesForSend(I2S0, ENABLE);
 * }
 * \endcode
 */
__STATIC_INLINE void I2S_SwapBytesForSend(I2S_TypeDef *I2Sx, FunctionalState NewState)
{
    /* Check the parameters */
    assert_param(IS_I2S_ALL_PERIPH(I2Sx));

    if (NewState == ENABLE)
    {
        I2Sx->CTRL1 |= I2S_TX_SRC_BYTE_SWAP_MSK;
    }
    else
    {
        I2Sx->CTRL1 &= I2S_TX_SRC_BYTE_SWAP_CLR;
    }
}

/**
 * \brief   Swap audio data bytes sequence which read by the I2Sx peripheral.
 * \param[in] I2Sx: To select I2Sx peripheral, where x can be: 0 or 1.
 * \param[in] NewState: New state of the bytes sequence.
 *      This parameter can be: ENABLE or DISABLE.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void i2s_demo(void)
 * {
 *     I2S_SwapBytesForRead(I2S0, ENABLE);
 * }
 * \endcode
 */
__STATIC_INLINE void I2S_SwapBytesForRead(I2S_TypeDef *I2Sx, FunctionalState NewState)
{
    /* Check the parameters */
    assert_param(IS_I2S_ALL_PERIPH(I2Sx));

    if (NewState == ENABLE)
    {
        I2Sx->CTRL1 |= I2S_RX_SNK_BYTE_SWAP_MSK;
    }
    else
    {
        I2Sx->CTRL1 &= I2S_RX_SNK_BYTE_SWAP_CLR;
    }
}

/**
 * \brief  Swap audio channel data which sent by the I2Sx peripheral..
 * \param[in] I2Sx: To select I2Sx peripheral, where x can be: 0 or 1.
 * \param[in] NewState: New state of the left and right channel data sequence.
 *      This parameter can be: ENABLE or DISABLE.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void i2s_demo(void)
 * {
 *     I2S_SwapLRChDataForSend(I2S0, ENABLE);
 * }
 * \endcode
 */
__STATIC_INLINE void I2S_SwapLRChDataForSend(I2S_TypeDef *I2Sx, FunctionalState NewState)
{
    /* Check the parameters */
    assert_param(IS_I2S_ALL_PERIPH(I2Sx));

    if (NewState == ENABLE)
    {
        I2Sx->CTRL1 |= I2S_TX_SRC_LR_SWAP_MSK;
    }
    else
    {
        I2Sx->CTRL1 &= I2S_TX_SRC_LR_SWAP_CLR;
    }
}

/**
 * \brief   Swap audio channel data which read by the I2Sx peripheral.
 * \param[in] I2Sx: To select I2Sx peripheral, where x can be: 0 or 1.
 * \param[in] NewState: New state of the left and right channel data sequence.
 *      This parameter can be: ENABLE or DISABLE.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void i2s_demo(void)
 * {
 *     I2S_SwapLRChDataForRead(I2S0, ENABLE);
 * }
 * \endcode
 */
__STATIC_INLINE void I2S_SwapLRChDataForRead(I2S_TypeDef *I2Sx, FunctionalState NewState)
{
    /* Check the parameters */
    assert_param(IS_I2S_ALL_PERIPH(I2Sx));

    if (NewState == ENABLE)
    {
        I2Sx->CTRL1 |= I2S_RX_SNK_LR_SWAP_MSK;
    }
    else
    {
        I2Sx->CTRL1 &= I2S_RX_SNK_LR_SWAP_CLR;
    }
}

/**
 * \brief   MCLK output selection which can be from I2S0 or I2S1.
 * \param[in] I2Sx: To select I2Sx peripheral, where x can be: 0 or 1.
 * \param[in] NewState: New state of MCLK output.
 *      This parameter can be: ENABLE or DISABLE.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void i2s_demo(void)
 * {
 *     I2S_MCLKOutputSelectCmd(I2S0);
 * }
 * \endcode
 */
//__STATIC_INLINE void I2S_MCLKOutputSelectCmd(I2S_TypeDef *I2Sx)
//{
//    /* Check the parameters */
//    assert_param(IS_I2S_ALL_PERIPH(I2Sx));

//    if (I2Sx == I2S0)
//    {
//        *((volatile uint32_t *)PERIPH_AUDIO_CLK_228) |= I2S_MCLK_OUTPUT_MSK;
//    }
//    else
//    {
//        if (I2Sx == I2S1)
//        {
//            *((volatile uint32_t *)PERIPH_AUDIO_CLK_228) &= I2S_MCLK_OUTPUT_CLR;
//        }
//    }
//}

/**
 * \brief   I2S0 communication selection which can be from intrnal codec or external codec.
 * \param[in] NewState: new state of I2S0 communication selection.
 *      This parameter can be: ENABLE or DISABLE.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void i2s_demo(void)
 * {
 *     I2S0_WithExtCodecCmd(ENABLE);
 * }
 * \endcode
 */
//__STATIC_INLINE void I2S0_WithExtCodecCmd(FunctionalState NewState)
//{
//    /* Check the parameters */
//    assert_param(IS_FUNCTIONAL_STATE(NewState));

//    if (NewState == ENABLE)
//    {
//        *((volatile uint32_t *)PERIPH_AUDIO_CLK_224) |= I2S0_EXT_CODEC_MSK;
//    }
//    else
//    {
//        *((volatile uint32_t *)PERIPH_AUDIO_CLK_224) &= I2S0_EXT_CODEC_CLR;
//    }
//}

/**
 * \brief   Config BClk clock.
 * \param[in] I2Sx: To select I2Sx peripheral, where x can be: 0 or 1.
 * \param[in] I2S_BClockMi: Mi parameter.
 * \param[in] I2S_BClockNi: Ni parameter.
 * \return  Execution status.
 * \retval  SET: Success.
 * \retval  RESET: Failure.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void i2s_demo(void)
 * {
 *     FlagStatus status = I2S_UpdateBClk(I2S0, 0x271, 0x10);
 * }
 * \endcode
 */
__STATIC_INLINE FlagStatus I2S_UpdateBClk(I2S_TypeDef *I2Sx, uint32_t dir, uint16_t I2S_BClockMi,
                                          uint16_t I2S_BClockNi)
{
    /* Check the parameters */
    assert_param(IS_I2S_ALL_PERIPH(I2Sx));

    if (dir & I2S_MODE_TX)
    {
        if (!(I2Sx->BCLK_DIV & I2S_MI_NI_UPDATE_MSK))
        {
            I2Sx->BCLK_DIV = I2S_BClockMi | (I2S_TX_BCLK_NI_MSK & (I2S_BClockNi << I2S_TX_BCLK_NI_POS)) |
                             I2S_MI_NI_UPDATE_MSK;
            return SET;
        }
    }
    else if (dir & I2S_MODE_RX)
    {
        if (!(I2Sx->RX_BCLK_DIV & I2S_MI_NI_UPDATE_MSK))
        {
            I2Sx->RX_BCLK_DIV = I2S_BClockMi | (I2S_RX_BCLK_NI_MSK & (I2S_BClockNi << I2S_RX_BCLK_NI_POS)) |
                                I2S_MI_NI_UPDATE_MSK;
            return SET;
        }
    }
    return RESET;
}

/**
 * \brief   Get BClk clock status.
 * \param[in] I2Sx: To select I2Sx peripheral, where x can be: 0 or 1.
 * \return  Execution status.
 * \retval  SET: BLCK is updating.
 * \retval  RESET: BLCK update is done.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void i2s_demo(void)
 * {
 *     FlagStatus status = I2S_GetBClkStatus(I2S0);
 * }
 * \endcode
 */
__STATIC_INLINE FlagStatus I2S_GetBClkStatus(I2S_TypeDef *I2Sx)
{
    /* Check the parameters */
    assert_param(IS_I2S_ALL_PERIPH(I2Sx));

    if (I2Sx->BCLK_DIV & I2S_MI_NI_UPDATE_MSK)
    {
        return SET;
    }

    return RESET;
}

__STATIC_INLINE void I2S_SetTdmMode(I2S_TypeDef *I2Sx, uint32_t dir, uint8_t tdm_mode)
{
    /* Check the parameters */
    assert_param(IS_I2S_ALL_PERIPH(I2Sx));

    if (dir & I2S_MODE_TX)
    {
        I2Sx->CTRL0 &= ~(0x3 << 18);
        I2Sx->CTRL0 |= tdm_mode;
    }
    if (dir & I2S_MODE_RX)
    {
        I2Sx->CTRL0 &= ~(0x3 << 20);
        I2Sx->CTRL0 |= tdm_mode;
    }
}

__STATIC_INLINE void I2S_SetDataFormat(I2S_TypeDef *I2Sx, uint32_t dir, uint8_t data_format)
{
    /* Check the parameters */
    assert_param(IS_I2S_ALL_PERIPH(I2Sx));

    if (dir & I2S_MODE_TX)
    {
        I2Sx->CTRL0 &= ~(0x3 << 8);
        I2Sx->CTRL0 |= data_format << 8;
    }
    if (dir & I2S_MODE_RX)
    {
        I2Sx->CTL_REG2 &= ~(0x3 << 8);
        I2Sx->CTL_REG2 |= data_format << 8;
    }
}

__STATIC_INLINE void I2S_SetChannelMode(I2S_TypeDef *I2Sx, uint32_t dir, uint8_t mode)
{

    if (dir & I2S_MODE_TX)
    {
        I2Sx->CTRL0 |= mode << 11;
    }
    if (dir & I2S_MODE_RX)
    {
        I2Sx->CTL_REG2 |= mode << 11;
    }

}

__STATIC_INLINE void I2S_SetDataLen(I2S_TypeDef *I2Sx, uint32_t dir, uint8_t data_length)
{

    if (dir & I2S_MODE_TX)
    {
        I2Sx->CTRL0 &= ~(0x7 << 12);
        I2Sx->CTRL0 |= data_length << 12;
    }
    if (dir & I2S_MODE_RX)
    {
        I2Sx->CTL_REG2 &= ~(0x7 << 12);
        I2Sx->CTL_REG2 |= data_length << 12;
    }
}

__STATIC_INLINE void I2S_SetChannelLen(I2S_TypeDef *I2Sx, uint32_t dir, uint8_t channel_length)
{

    if (dir & I2S_MODE_TX)
    {
        I2Sx->CTL_REG2 &= ~(0x7 << 24);
        I2Sx->CTL_REG2 |= channel_length << 24;
    }
    if (dir & I2S_MODE_RX)
    {
        I2Sx->CTL_REG2 &= ~(0x7 << 28);
        I2Sx->CTL_REG2 |= channel_length << 28;
    }
}

__STATIC_INLINE void I2S_SetTxFifoNum(I2S_TypeDef *I2Sx, uint8_t fifo_used)
{

    I2Sx->CTRL1 |= (fifo_used  & I2S_FIFO_USE_0_REG_0) >> 24;
    I2Sx->CTRL1 |= (fifo_used & I2S_FIFO_USE_0_REG_1) >> 25;
    I2Sx->CTRL1 |= (fifo_used & I2S_FIFO_USE_1_REG_0) >> 26;
    I2Sx->CTRL1 |= (fifo_used & I2S_FIFO_USE_1_REG_1) >> 27;

}

__STATIC_INLINE void I2S_SetRxFifoNum(I2S_TypeDef *I2Sx, uint8_t fifo_used)
{


    I2Sx->CTRL1 |= (fifo_used &  I2S_FIFO_USE_0_REG_0) >> 28;
    I2Sx->CTRL1 |= (fifo_used & I2S_FIFO_USE_0_REG_1) >> 29;
    I2Sx->CTRL1 |= (fifo_used & I2S_FIFO_USE_1_REG_0) >> 30;
    I2Sx->CTRL1 |= (fifo_used & I2S_FIFO_USE_1_REG_1) >> 31;
}

//__STATIC_INLINE uint32_t I2S_convert_sample_rate(uint8_t p_sample_rate)
//{
//    uint32_t clk_rate_sport = 0x80100271; // 16K by default

//    switch (p_sample_rate)
//    {
//    case I2S_SR_8K:
//        clk_rate_sport = 0x80080271;
//        break;

//    case I2S_SR_16K:
//        clk_rate_sport = 0x80100271;
//        break;

//    case I2S_SR_32K:
//        clk_rate_sport = 0x80200271;
//        break;

//    case I2S_SR_44K:
//        clk_rate_sport = 0x81B9186A;
//        break;

//    case I2S_SR_48K:
//        clk_rate_sport = 0x80300271;
//        break;

//    case I2S_SR_88K:
//        clk_rate_sport = 0x81B90C35;
//        break;

//    case I2S_SR_96K:
//        clk_rate_sport = 0x80600271;
//        break;

//    case I2S_SR_192K:
//        clk_rate_sport = 0x80C00271;
//        break;

//    case I2S_SR_12K:
//        clk_rate_sport = 0x800C0271;
//        break;

//    case I2S_SR_24K:
//        clk_rate_sport = 0x80180271;
//        break;

//    case I2S_SR_11K:
//        clk_rate_sport = 0x81B961A8;
//        break;

//    case I2S_SR_22K:
//        clk_rate_sport = 0x81B930D4;
//        break;

//    default:
//        break;
//    }

//    return clk_rate_sport;
//}

__STATIC_INLINE void I2S_ConfigBclkDiv(I2S_TypeDef *I2Sx, uint32_t dir, uint8_t div_ratio)
{

    if (dir & I2S_MODE_TX)
    {
        I2Sx->DMA_TRDLR &= ~(0xFF << 16);
        I2Sx->DMA_TRDLR |= div_ratio << 16;
    }
    else if (dir & I2S_MODE_RX)
    {
        I2Sx->DMA_TRDLR &= ~(0xFF << 24);
        I2Sx->DMA_TRDLR |= div_ratio << 24;
    }

}



__STATIC_INLINE void I2S_SetRxFifoCh(I2S_TypeDef *I2Sx, uint8_t *rx_fifo_map)
{

    I2Sx->RX_FIFO_REG0 |= rx_fifo_map[0] << 0 |
                          rx_fifo_map[1] << 8 |
                          rx_fifo_map[2] << 16 |
                          rx_fifo_map[3] << 24    ;
    I2Sx->RX_FIFO_REG1 |= rx_fifo_map[4] << 0 |
                          rx_fifo_map[5] << 8 |
                          rx_fifo_map[6] << 16 |
                          rx_fifo_map[7] << 24    ;

}
__STATIC_INLINE void I2S_SetTxDataSelect(I2S_TypeDef *I2Sx, uint8_t ch_num, uint8_t ch_from)
{
    uint8_t bit_offset = ch_num * I2S_TX_CH_DATA_SEL_LEN;
    I2Sx->TX_DIR_SEL = ((I2Sx->TX_DIR_SEL & (~(I2S_TX_CH_DATA_SEL_MASK << bit_offset))) |
                        (ch_from << bit_offset));
}

__STATIC_INLINE void I2S_SetDirectReg(I2S_TypeDef *I2Sx, uint8_t ch_num, uint8_t ch_from)
{
    uint8_t bit_offset = 0;
    uint8_t direct_reg_setting = ch_from | I2S_DIRECT_REG_EN;

    if (GET_CH_REG_SEL(ch_num))
    {
        bit_offset = GET_CH_NUM_OFFSET(ch_num) * I2S_DIRECT_REG_LEN;
        I2Sx->DIR_OUT_0 = ((I2Sx->DIR_OUT_0 & ~(I2S_DIRECT_REG_MASK << bit_offset)) |
                           (direct_reg_setting << bit_offset));
    }
    else
    {
        bit_offset = GET_CH_NUM_OFFSET(ch_num) * I2S_DIRECT_REG_LEN;
        I2Sx->DIR_EN1 = ((I2Sx->DIR_EN1 & ~(I2S_DIRECT_REG_MASK << bit_offset)) |
                         (direct_reg_setting << bit_offset));
    }
}

/** \} */ /*End of group I2S_Exported_Functions */

#ifdef __cplusplus
}
#endif

#endif /* _RTL876x_I2S_H_ */




/******************* (C) COPYRIGHT 2017 Realtek Semiconductor Corporation *****END OF FILE****/

