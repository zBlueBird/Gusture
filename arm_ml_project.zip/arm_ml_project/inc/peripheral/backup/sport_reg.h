#ifndef _SPORT_REG_H_
#define _SPORT_REG_H_

#include <stdint.h>
#include <stdbool.h>
#include "rtl876x.h"

#ifdef  __cplusplus
extern "C" {
#endif /* __cplusplus */

typedef union t_sport_0x00_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t sp_reg_mux: 32;
    };
} T_SPORT_0x00_TYPE;

typedef union t_sport_0x04_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t sp_reset: 1;                   // [0]
        uint32_t tx_inv_i2s_sclk: 1;            // [1]
        uint32_t rx_inv_i2s_sclk: 1;            // [2]
        uint32_t slave_clk_sel: 1;              // [3]
        uint32_t slave_data_sel: 1;             // [4]
        uint32_t sp_wclk_tx_inverse: 1;         // [5]
        uint32_t sp_loopback: 1;                // [6]
        uint32_t dsp_ctrl_mode: 1;              // [7]
        uint32_t sp_data_format_sel_tx: 2;      // [9:8]
        uint32_t sp_inv_i2s_sclk: 1;            // [10]
        uint32_t sp_en_i2s_mono_tx_0: 1;        // [11]
        uint32_t sp_data_len_sel_tx_0: 3;       // [14:12]
        uint32_t sp_i2s_self_lpbk_en: 1;        // [15]
        uint32_t sp_tx_disable: 1;              // [16]
        uint32_t sp_start_tx: 1;                // [17]
        uint32_t sp_tdm_mode_sel_tx: 2;         // [19:18]
        uint32_t sp_tdm_mode_sel_rx: 2;         // [21:20]
        uint32_t tx_lsb_first_0: 1;             // [22]
        uint32_t rx_lsb_first_0: 1;             // [23]
        uint32_t sp_rx_disable: 1;              // [24]
        uint32_t sp_start_rx: 1;                // [25]
        uint32_t sp_sel_i2s_tx_ch: 2;           // [27:26]
        uint32_t sp_sel_i2s_rx_ch: 2;           // [29:28]
        uint32_t mclk_sel: 2;                   // [31:30]
    };
} T_SPORT_0x04_TYPE;


typedef union t_sport_0x08_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t sp_reset_smooth: 1;            // [0]
        uint32_t tx_fifo_fill_zero: 1;          // [1]
        uint32_t tx_fifo_en: 1;                 // [2]
        uint32_t rx_fifo_en: 1;                 // [3]
        uint32_t bclk_pull_zero: 1;             // [4]
        uint32_t bclk_reset: 1;                 // [5]
        uint32_t ws_force: 1;                   // [6]
        uint32_t ws_force_val: 1;               // [7]
        uint32_t debug_bus_sel: 3;              // [10:8]
        uint32_t enable_mclk: 1;                // [11]
        uint32_t clear_tx_err_cnt: 1;           // [12]
        uint32_t clear_rx_err_cnt: 1;           // [13]
        uint32_t sport_clk_sel: 2;              // [15:14]
        uint32_t err_cnt_sat_set: 1;            // [16]
        uint32_t sp_direct_src_sel: 2;          // [18:17]
        uint32_t direct_mode_en: 1;             // [19]
        uint32_t tx_src_byte_swap_0: 1;         // [20]
        uint32_t tx_src_lr_swap_0: 1;           // [21]
        uint32_t rx_snk_byte_swap_0: 1;         // [22]
        uint32_t rx_snk_lr_swap_0: 1;           // [23]
        uint32_t tx_fifo_0_reg_0_en: 1;         // [24]
        uint32_t tx_fifo_0_reg_1_en: 1;         // [25]
        uint32_t tx_fifo_1_reg_0_en: 1;         // [26]
        uint32_t tx_fifo_1_reg_1_en: 1;         // [27]
        uint32_t rx_fifo_0_reg_0_en: 1;         // [28]
        uint32_t rx_fifo_0_reg_1_en: 1;         // [29]
        uint32_t rx_fifo_1_reg_0_en: 1;         // [30]
        uint32_t rx_fifo_1_reg_1_en: 1;         // [31]
    };
} T_SPORT_0x08_TYPE;


typedef union t_sport_0x0C_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t tx_dsp_clear_int_0: 1;
        uint32_t rx_dsp_clear_int_0: 1;
        uint32_t intr_clr_0: 5;
        uint32_t tx_dsp_clear_int_1: 1;
        uint32_t rx_dsp_clear_int_1: 1;
        uint32_t intr_clr_1: 5;
        uint32_t tx_fifo_data_valid_intr_clr: 1;
        uint32_t reserved: 1;
        uint32_t int_enable_dsp_0: 8;
        uint32_t int_enable_dsp_1: 8;
    };
} T_SPORT_0x0C_TYPE;

typedef union t_sport_0x14_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t tx_depth_cnt_0: 6;
        uint32_t reserved_0: 2;
        uint32_t rx_depth_cnt_0: 6;
        uint32_t reserved_1: 2;
        uint32_t tx_depth_cnt_1: 6;
        uint32_t reserved_2: 2;
        uint32_t rx_depth_cnt_1: 6;
        uint32_t reserved_3: 1;
        uint32_t sp_reset_state: 1;
    };
} T_SPORT_0x14_TYPE;

typedef union t_sport_0x18_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t tx_err_cnt: 16;                // [15:0]
        uint32_t rx_err_cnt: 16;                // [31:16]
    };
} T_SPORT_0x18_TYPE;

typedef union t_sport_0x1C_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t tx_mi: 16;                     // [15:0]
        uint32_t tx_ni: 15;                     // [30:16]
        uint32_t tx_mi_ni_update: 1;            // [31]
    };
} T_SPORT_0x1C_TYPE;



typedef union t_sport_0x20_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t txdma_burstsize: 6;
        uint32_t reserved_0: 2;
        uint32_t rxdma_burstsize: 6;
        uint32_t reserved_1: 2;
        uint32_t tx_bclk_div_ratio: 8;
        uint32_t rx_bclk_div_ratio: 8;
    };
} T_SPORT_0x20_TYPE;


typedef union t_sport_0x24_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t sp_ready_to_tx_0: 1;
        uint32_t sp_ready_to_rx_0: 1;
        uint32_t tx_fifo_full_intr_0: 1;
        uint32_t rx_fifo_full_intr_0: 1;
        uint32_t tx_fifo_empty_intr_0: 1;
        uint32_t rx_fifo_empty_intr_0: 1;
        uint32_t tx_i2s_idle_0: 1;
        uint32_t sp_ready_to_tx_1: 1;
        uint32_t sp_ready_to_rx_1: 1;
        uint32_t tx_fifo_full_intr_1: 1;
        uint32_t rx_fifo_full_intr_1: 1;
        uint32_t tx_fifo_empty_intr_1: 1;
        uint32_t rx_fifo_empty_intr_1: 1;
        uint32_t tx_i2s_idle_1: 1;
        uint32_t reserved_0: 2;
        uint32_t tx_fifo_data_valid_intr: 1;
        uint32_t reserved_1: 7;
        uint32_t tx_fifo_full_1: 1;
        uint32_t rx_fifo_full_1: 1;
        uint32_t tx_fifo_empty_1: 1;
        uint32_t rx_fifo_empty_1: 1;
        uint32_t tx_fifo_full_0: 1;
        uint32_t rx_fifo_full_0: 1;
        uint32_t tx_fifo_empty_0: 1;
        uint32_t rx_fifo_empty_0: 1;
    };
} T_SPORT_0x24_TYPE;

typedef union t_sport_0x28_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t trx_same_fs: 1;                // [0]
        uint32_t trx_same_ch: 1;                // [1]
        uint32_t trx_same_length: 1;            // [2]
        uint32_t sck_out_inverse: 1;            // [3]
        uint32_t reserved_0: 1;                 // [4]
        uint32_t sp_wclk_rx_inverse: 1;         // [5]
        uint32_t fixed_bclk_sel: 1;             // [6]
        uint32_t fixed_bclk: 1;                 // [7]
        uint32_t sp_data_format_sel_rx: 2;      // [9:8]
        uint32_t trx_same_lrc: 1;               // [10]
        uint32_t sp_en_i2s_mono_rx_0: 1;        // [11]
        uint32_t sp_data_len_sel_rx_0: 3;       // [14:12]
        uint32_t rsvd0: 1;                      // [15]
        uint32_t tx_ideal_len: 3;               // [18:16]
        uint32_t tx_ideal_len_en: 1;            // [19]
        uint32_t rx_ideal_en: 3;                // [22:20]
        uint32_t rx_idel_len_en: 1;             // [23]
        uint32_t sp_ch_len_sel_tx: 3;           // [26:24]
        uint32_t rsvd1: 1;                      // [27]
        uint32_t sp_ch_len_sel_rx: 3;           // [30:28]
        uint32_t trx_same_ch_len: 1;            // [31]
    };
} T_SPORT_0x28_TYPE;


typedef union t_sport_0x2C_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t rx_mi: 16;                     // [15:0]
        uint32_t rx_ni: 15;                     // [30:16]
        uint32_t rx_mi_ni_update: 1;            // [31]
    };
} T_SPORT_0x2C_TYPE;

typedef union t_sport_0x30_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t tx_sport_compare_val: 27;      // [26:0]
        uint32_t rsvd0: 2;                       // [28:27]
        uint32_t en_fs_phase_latch: 1;           // [29]
        uint32_t en_tx_sport_interrupt: 1;       // [30]
        uint32_t clr_rx_sport_rdy: 1;            // [31]
    };
} T_SPORT_0x30_TYPE;

typedef union t_sport_0x34_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t tx_fs_phase_rpt: 5;            // [4:0]
        uint32_t tx_sport_counter: 27;          // [31:5]
    };
} T_SPORT_0x34_TYPE;

typedef union t_sport_0x38_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t tx_direct_ws_div_sel: 2;
        uint32_t tx_direct_ws_div_en: 1;
        uint32_t rx_direct_ws_div_sel: 2;
        uint32_t rx_direct_ws_div_en: 1;
        uint32_t sck_in_direct_div_ratio: 4;
        uint32_t sck_in_direct_div_en: 1;
        uint32_t rsvd0: 1;
        uint32_t tx_ch0_mix_data_sel: 3;
        uint32_t tx_ch0_mix_sat_sel: 1;
        uint32_t tx_ch1_mix_data_sel: 3;
        uint32_t rsvd1: 1;
        uint32_t tx_ch1_mix_sat_sel: 1;
        uint32_t tx_ch0_mix_en: 1;
        uint32_t tx_ch1_mix_en: 1;
        uint32_t rsvd2: 9;
    };
} T_SPORT_0x38_TYPE;

typedef union t_sport_0x3C_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t tx_ch0_data_sel: 4;            // [3:0]
        uint32_t tx_ch1_data_sel: 4;            // [7:4]
        uint32_t tx_ch2_data_sel: 4;            // [11:8]
        uint32_t tx_ch3_data_sel: 4;            // [15:12]
        uint32_t tx_ch4_data_sel: 4;            // [19:16]
        uint32_t tx_ch5_data_sel: 4;            // [23:20]
        uint32_t tx_ch6_data_sel: 4;            // [27:24]
        uint32_t tx_ch7_data_sel: 4;            // [31:28]
    };
} T_SPORT_0x3C_TYPE;


typedef union t_sport_0x44_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t int_enable_mcu_0: 8;           // [7:0]
        uint32_t int_enable_mcu_1: 8;           // [15:8]
        uint32_t reserved_0: 10;                // [25:16]
        uint32_t tx_src_byte_swap_1: 1;         // [26]
        uint32_t tx_src_lr_swap_1: 1;           // [27]
        uint32_t rx_snk_byte_swap_1: 1;         // [28]
        uint32_t rx_snk_lr_swap_1: 1;           // [29]
        uint32_t tx_lsb_first_1: 1;             // [30]
        uint32_t rx_lsb_first_1: 1;             // [31]
    };
} T_SPORT_0x44_TYPE;

typedef union t_sport_0x48_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t direct_reg_0_sel: 5;           // [4:0]
        uint32_t direct_reg_0_en: 1;            // [5]
        uint32_t direct_reg_1_sel: 5;           // [10:6]
        uint32_t direct_reg_1_en: 1;            // [11]
        uint32_t direct_reg_2_sel: 5;           // [16:12]
        uint32_t direct_reg_2_en: 1;            // [17]
        uint32_t direct_reg_3_sel: 5;           // [22:18]
        uint32_t direct_reg_3_en: 1;            // [23]
        uint32_t sp_data_len_sel_tx_1: 3;       // [26:24]
        uint32_t sp_en_i2s_mono_tx_1: 1;        // [27]
        uint32_t sp_data_len_sel_rx_1: 3;       // [30:28]
        uint32_t sp_en_i2s_mono_rx_1: 1;        // [31]
    };
} T_SPORT_0x48_TYPE;


typedef union t_sport_0x4C_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t direct_reg_4_sel: 5;           // [4:0]
        uint32_t direct_reg_4_en: 1;            // [5]
        uint32_t direct_reg_5_sel: 5;           // [10:6]
        uint32_t direct_reg_5_en: 1;            // [11]
        uint32_t direct_reg_6_sel: 5;           // [16:12]
        uint32_t direct_reg_6_en: 1;            // [17]
        uint32_t direct_reg_7_sel: 5;           // [22:18]
        uint32_t direct_reg_7_en: 1;            // [23]
        uint32_t sp_direct_out_0_en: 1;         // [24]
        uint32_t sp_direct_out_1_en: 1;         // [25]
        uint32_t sp_direct_out_2_en: 1;         // [26]
        uint32_t sp_direct_out_3_en: 1;         // [27]
        uint32_t sp_direct_out_4_en: 1;         // [28]
        uint32_t sp_direct_out_5_en: 1;         // [29]
        uint32_t sp_direct_out_6_en: 1;         // [30]
        uint32_t sp_direct_out_7_en: 1;         // [31]
    };
} T_SPORT_0x4C_TYPE;


typedef union t_sport_0x54_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t rx_fifo_0_reg_0_l_sel: 5;      // [4:0]
        uint32_t reserved_0: 3;                 // [7:5]
        uint32_t rx_fifo_0_reg_0_r_sel: 5;      // [12:8]
        uint32_t reserved_1: 3;                 // [15:13]
        uint32_t rx_fifo_0_reg_1_l_sel: 5;      // [20:16]
        uint32_t reserved_2: 3;                 // [23:21]
        uint32_t rx_fifo_0_reg_1_r_sel: 5;      // [28:24]
        uint32_t reserved_3: 3;                 // [31:29]
    };
} T_SPORT_0x54_TYPE;


typedef union t_sport_0x58_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t rx_fifo_1_reg_0_l_sel: 5;      // [4:0]
        uint32_t reserved_0: 3;                 // [7:5]
        uint32_t rx_fifo_1_reg_0_r_sel: 5;      // [12:8]
        uint32_t reserved_1: 3;                 // [15:13]
        uint32_t rx_fifo_1_reg_1_l_sel: 5;      // [20:16]
        uint32_t reserved_2: 3;                 // [23:21]
        uint32_t rx_fifo_1_reg_1_r_sel: 5;      // [28:24]
        uint32_t reserved_3: 3;                 // [31:29]
    };
} T_SPORT_0x58_TYPE;

typedef union t_sport_0x5C_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t rx_sport_compare_val: 27;
        uint32_t reserved_0: 3;
        uint32_t en_rx_sport_interrupt: 1;
        uint32_t clr_rx_sport_rdy: 1;
    };
} T_SPORT_0x5C_TYPE;

typedef union t_sport_0x60_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t rx_fs_phase_rpt: 5;
        uint32_t rx_sport_counter: 27;
    };
} T_SPORT_0x60_TYPE;

typedef union t_sport_0x64_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t tx_depth_cnt_latch: 6;
        uint32_t rsvd0: 2;
        uint32_t rx_depth_cnt_latch: 6;
        uint32_t rsvd1: 18;
    };
} T_SPORT_0x64_TYPE;

// for BBPRO2
typedef union t_soc_0x220_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t r_PON_FEN_AUDIO: 1;            // [0]
        uint32_t r_PON_FEN_SPORT0: 1;           // [1]
        uint32_t r_PON_FEN_SPORT1: 1;           // [2]
        uint32_t rsvd0: 1;                      // [3]
        uint32_t r_CLK_EN_AUDIO: 1;             // [4]
        uint32_t r_CLK_EN_SPORT0: 1;            // [5]
        uint32_t r_CLK_EN_SPORT1: 1;            // [6]
        uint32_t rsvd1: 1;                      // [7]
        uint32_t r_CLK_EN_SPORT_40M: 1;         // [8]
        uint32_t r_CLK_EN_AUDIO_REG: 1;         // [9]
        uint32_t r_PON_FEN_SPORT2: 1;           // [10]
        uint32_t r_PON_FEN_SPORT3: 1;           // [11]
        uint32_t r_CLK_EN_SPORT2: 1;            // [12]
        uint32_t r_CLK_EN_SPORT3: 1;            // [13]
        uint32_t rsvd2: 18;                     // [31:14]
    };
} T_SOC_0x220_TYPE;

typedef union t_soc_0x224_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t r_SPORT0_PLL_CLK_SEL: 3;       // [2:0]
        uint32_t r_SPORT0_EXT_CODEC: 1;         // [3]
        uint32_t r_SPORT1_PLL_CLK_SEL: 3;       // [6:4]
        uint32_t r_CODEC_STANDALONE: 1;         // [7]
        uint32_t r_PLL_DIV0_SETTING: 8;         // [15:8]
        uint32_t r_PLL_DIV1_SETTING: 8;         // [23:16]
        uint32_t r_PLL_DIV2_SETTING: 8;         // [31:24]
    };
} T_SOC_0x224_TYPE;

typedef union t_soc_0x228_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t rsvd0: 3;                      // [2:0]
        uint32_t r_SPORT0_MCLK_OUT: 1;          // [3]
        uint32_t r_SPORT1_MCLK_OUT: 1;          // [4]
        uint32_t r_SPORT2_MCLK_OUT: 1;          // [5]
        uint32_t r_SPORT3_MCLK_OUT: 1;          // [6]
        uint32_t r_AUDIO_CLK_FROM_PLL: 1;       // [7]
        uint32_t r_SPORT1_EXT_CODEC: 1;         // [8]
        uint32_t r_SPORT0_PLL_1_2_SEL: 1;       // [9]
        uint32_t r_SPORT1_PLL_1_2_SEL: 1;       // [10]
        uint32_t r_SPORT2_PLL_1_2_SEL: 1;       // [11]
        uint32_t r_SPORT3_PLL_1_2_SEL: 1;       // [12]
        uint32_t r_SPORT2_PLL_CLK_SEL: 3;       // [15:13]
        uint32_t r_SPORT3_PLL_CLK_SEL: 3;       // [18:16]
        uint32_t rsvd1: 5;                      // [23:19]
        uint32_t r_PLL_DIV3_SETTING: 8;         // [31:24]
    };
} T_SOC_0x228_TYPE;

#define SPORT_ON_DSP_BUS    1

/* Register: TX_FIFO_0_WR_ADDR ------------------------------------------------------------*/
/* Description: SPORT fifo write register. Offset: 0x0080 */
#define TX_FIFO_0_WR_ADDR_OFFSET        0x0080
/* Register: RX_FIFO_0_RD_ADDR ------------------------------------------------------------*/
/* Description: SPORT fifo read register. Offset: 0x0180 */
#define RX_FIFO_0_RD_ADDR_OFFSET        0x0180
/* Register: TX_FIFO_1_WR_ADDR ------------------------------------------------------------*/
/* Description: SPORT fifo read register. Offset: 0x0280 */
#define TX_FIFO_1_WR_ADDR_OFFSET        0x0280
/* Register: RX_FIFO_1_RD_ADDR ------------------------------------------------------------*/
/* Description: SPORT fifo read register. Offset: 0x3800 */
#define RX_FIFO_1_RD_ADDR_OFFSET        0x0380
/*============================================================================*
 *                         Types
 *============================================================================*/

typedef union t_sport_0x080_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t TX_FIFO_0_WR_ADDR;
    };
} T_SPORT_0x080_TYPE;

typedef union t_sport_0x0180_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t RX_FIFO_0_RD_ADDR;
    };
} T_SPORT_0x0180_TYPE;


typedef union t_sport_0x0280_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t TX_FIFO_1_WR_ADDR;
    };
} T_SPORT_0x0280_TYPE;

typedef union t_sport_0x0380_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t RX_FIFO_1_RD_ADDR;
    };
} T_SPORT_0x0380_TYPE;


#define SPORT0_TX_ADDR              SPORT0_REG_BASE + TX_FIFO_0_WR_ADDR_OFFSET
#define SPORT0_RX_ADDR              SPORT0_REG_BASE + RX_FIFO_0_RD_ADDR_OFFSET
#define SPORT0_FIFO1_TX_ADDR        SPORT0_REG_BASE + TX_FIFO_1_WR_ADDR_OFFSET
#define SPORT0_FIFO1_RX_ADDR        SPORT0_REG_BASE + RX_FIFO_1_RD_ADDR_OFFSET

#define SPORT1_TX_ADDR              SPORT1_REG_BASE + TX_FIFO_0_WR_ADDR_OFFSET
#define SPORT1_RX_ADDR              SPORT1_REG_BASE + RX_FIFO_0_RD_ADDR_OFFSET
#define SPORT1_FIFO1_TX_ADDR        SPORT1_REG_BASE + TX_FIFO_1_WR_ADDR_OFFSET
#define SPORT1_FIFO1_RX_ADDR        SPORT1_REG_BASE + RX_FIFO_1_RD_ADDR_OFFSET

#define SPORT2_TX_ADDR              SPORT2_REG_BASE + TX_FIFO_0_WR_ADDR_OFFSET
#define SPORT2_RX_ADDR              SPORT2_REG_BASE + RX_FIFO_0_RD_ADDR_OFFSET
#define SPORT2_FIFO1_TX_ADDR        SPORT2_REG_BASE + TX_FIFO_1_WR_ADDR_OFFSET
#define SPORT2_FIFO1_RX_ADDR        SPORT2_REG_BASE + RX_FIFO_1_RD_ADDR_OFFSET

#define SPORT3_TX_ADDR              SPORT3_REG_BASE + TX_FIFO_0_WR_ADDR_OFFSET
#define SPORT3_RX_ADDR              SPORT3_REG_BASE + RX_FIFO_0_RD_ADDR_OFFSET
#define SPORT3_FIFO1_TX_ADDR        SPORT3_REG_BASE + TX_FIFO_1_WR_ADDR_OFFSET
#define SPORT3_FIFO1_RX_ADDR        SPORT3_REG_BASE + RX_FIFO_1_RD_ADDR_OFFSET



/* Peripheral: SPORT */
/* Description: SPORT register defines */
#define SPORT_GDMA_TX_CH_NUM        11
#define SPORT_GDMA_RX_CH_NUM        12
#define SPORT_GDMA_TX_CH            GDMA_Channel11
#define SPORT_GDMA_RX_CH            GDMA_Channel12
#define SPORT_GDMA_TX_CH_VECTOR     GDMA0_Channel11_VECTORn
#define SPORT_GDMA_RX_CH_VECTOR     GDMA0_Channel12_VECTORn
#define SPORT_GDMA_TX_CH_IRQ        GDMA0_Channel11_IRQn
#define SPORT_GDMA_RX_CH_IRQ        GDMA0_Channel12_IRQn

#define SPORT0_TX_VECTOR            SPORT0_TX_VECTORn
#define SPORT0_RX_VECTOR            SPORT0_RX_VECTORn
#define SPORT0_TX_IRQ               SPORT0_TX_IRQn
#define SPORT0_RX_IRQ               SPORT0_RX_IRQn

#define SPORT_TX_CH_DATA_SEL_LEN    4
#define SPORT_DIRECT_REG_LEN        6
#define SPORT_DEFAULT_CH_LEN        32

#define SPORT_CH_NUM_OFFSET_MASK    0x3
#define SPORT_TX_CH_DATA_SEL_MASK   0xF
#define SPORT_RX_FIFO_CH_MASK       0x1F
#define SPORT_DIRECT_REG_MASK       0x1F
#define SPORT_DIRECT_OUT_MASK       0xFF
#define SPORT_BCLK_MI_MASK          0xFFFF

#define SPORT_RX_FIFO_CH_OFS        3
#define SPORT_DIRECT_OUT_OFS        24
#define SPORT_BCLK_NI_OFS           16

#define SPORT_RESET_EN              BIT0
#define SPORT_MCU_SP_READY_TO_TX    BIT0
#define SPORT_MCU_SP_READY_TO_RX    BIT1
#define SPORT_CH_REG_SEL            BIT2
#define SPORT_DIRECT_REG_EN         BIT5
#define SPORT_BCLK_UPDATE           BIT31

#define SPORT_MI_DEFAULT_SETTING    0x271

#define SPORT_40M_CLK               40000

//typedef struct
//{
//    __IO uint32_t SP_REG_MUX;            /**<0x00 */
//    __IO uint32_t CTL_REG1;      /**<0x04 */
//    __IO uint32_t FIFO_REG;      /**<0x08 */
//    __IO uint32_t INT_CLR;       /**<0x0C */
//    __IO uint32_t RX_FIFO_0_RD;  /**<0x10 */         /* rsvd for dsp */
//    __IO uint32_t DEPTH_CNT;     /**<0x14 */
//    __IO uint32_t ERR_CNT;       /**<0x18 */
//    __IO uint32_t BCLK;          /**<0x1C */
//    __IO uint32_t BCLK_DIV;      /**<0x20 */
//    __IO uint32_t STATUS;        /**<0x24 */
//    __IO uint32_t CTL_REG2;      /**<0x28 */
//    __IO uint32_t RX_BCLK;       /**<0x2C */
//    __IO uint32_t INT_CLR_1;     /**<0x30 */         /* rsvd for dsp */
//    __IO uint32_t READ_CNT;      /**<0x34 */         /* rsvd for dsp */
//    __IO uint32_t RX_BCLK_DIV;   /**<0x38 */
//    __IO uint32_t TX_DIR_SEL;    /**<0x3C */
//    __IO uint32_t TX_FIFO_1_WR;  /**<0x40 */
//    __IO uint32_t RX_CTL_1;      /**<0x44 */
//    __IO uint32_t DIR_EN1;       /**<0x48 */
//    __IO uint32_t DIR_OUT_0;     /**<0x4C */
//    __IO uint32_t RX_FIFO_1_RD;  /**<0x50 */
//    __IO uint32_t RX_FIFO_REG0;  /**<0x54 */
//    __IO uint32_t RX_FIFO_REG1;  /**<0x58 */
//    __IO uint32_t RX_FIFO_DEPTH; /**<0x5C */
//    __IO uint32_t SPORT_REG_0x60; /**<0x60 */
//    __IO uint32_t SPORT_DEPTH_CNT_LATCH; /**<0x64 */
//} SPORT_Typedef;

//extern SPORT_Typedef *SPORT0;
//extern SPORT_Typedef *SPORT1;
//extern SPORT_Typedef *SPORT2;
//extern SPORT_Typedef *SPORT3;

#ifdef  __cplusplus
}
#endif /* __cplusplus */

#endif /* _SPORT_REG_H_ */

