/**
*********************************************************************************************************
*               Copyright(c) 2019, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* \file     rtl876x_codec.h
* \brief    The header file of the peripheral CODEC driver.
* \details  This file provides all CODEC firmware functions.
* \author   elliot chen
* \date     2019-10-25
* \version  v2.1.0
* *********************************************************************************************************
*/

#ifndef _RTL876X_CODEC_H_
#define _RTL876X_CODEC_H_

#ifdef __cplusplus
extern "C" {
#endif
#include "codec_reg.h"

#define AD_POWER_MODE            0// 0: normal mode 1: low power mode, for AMIC1,2
#define AD_SNR_MODE              0// 0: normal mode 1: HSNR mode, for AMIC3,4


/**
 * \addtogroup  IO          Peripheral Drivers
 * \defgroup    CODEC       CODEC
 *
 * \brief       Manage the CODEC peripheral functions.
 *
 * \ingroup     IO
 */

/*============================================================================*
 *                         Includes
 *============================================================================*/
#include "rtl876x.h"

/* ================================================================================ */
/* ================       CODEC Registers Structures Section       ================ */
/* ================================================================================ */
typedef struct
{
    union
    {
        __IO uint32_t AON_CODEC_CR0;
        struct
        {
            __IO uint32_t REG_LOAD_SEL: 4;
            __IO uint32_t REG_COMP_INT_ADC: 1;
            __IO uint32_t REG_LDO_TUNE: 4;
            __IO uint32_t REG_LDO_PREC_START: 1;
            __IO uint32_t REG_LDO_PREC_MODE: 1;
            __IO uint32_t REG_LDO_POW: 1;
            __IO uint32_t REG_LDO_DISCHARGE: 1;
            __IO uint32_t RG0X_CODEC_DUMMY: 1;
            __IO uint32_t REG_LDO_COMP_INT: 1;
            __IO uint32_t REG_LDO_ADC_POW: 1;
            __IO uint32_t REG_LDO_LV_PC: 1;
            __IO uint32_t REG_LDO_PREC_AVCC: 1;
            __IO uint32_t REG_EN_OFF30MV: 1;
            __IO uint32_t REG_EB_ADP_PC_CTRL: 1;
            __IO uint32_t REG_EN_DUMMY: 1;
            __IO uint32_t REG_DIG_VESEL_LDODIG: 3;
            __IO uint32_t REG_AVCC_DMY_SEL: 3;
            __IO uint32_t RG1X_CODEC_DUMMY: 3;
            __IO uint32_t REG_LDO_LV_SEL: 1;
            __IO uint32_t REG_L2L_EN: 1;
        } BITS_D50;
    } u_D50;

    union
    {
        __IO uint32_t AON_CODEC_CR1;
        struct
        {
            __IO uint32_t REG_LDO_AVCC_DRV: 16;
            __IO uint32_t REG_AON_CODEC_RESERVE: 16;
        } BITS_D54;
    } u_D54;

    union
    {
        __IO uint32_t AON_CODEC_CR2;
        struct
        {
            __IO uint32_t REG_ENB_1B10U_CDOEC_LDO: 1;
            __IO uint32_t REG_CDOEC_MBIAS_POW: 1;
            __IO uint32_t REG_BIAS_10UA_IQ_SEL: 3;
            __IO uint32_t REG_LPBG_FT_TEMP: 3;
            __IO uint32_t REG_VCMBUF_POW: 1;
            __IO uint32_t REG_VCMBUF_ISEL: 1;
            __IO uint32_t REG_VCMBUF_BYPASS: 1;
            __IO uint32_t REG_LDO_POW_ADC_2P8V: 1;
            __IO uint32_t REG_LDO_COMP_INT_2P8V: 1;
            __IO uint32_t RG4X_CODEC_DUMMY: 17;
        } BITS_D58;
    } u_D58;

} AON_CODEC_TypeDef;

/* ================================================================================ */
/* ================               CODEC Declaration                ================ */
/* ================================================================================ */
#define AON_CODEC                       ((AON_CODEC_TypeDef        *) AON_CODEC_BASE)

/*============================================================================*
 *                         Types
 *============================================================================*/
#define CODEC_DRV_ADC_DIG_GAIN_MAX_HEX  0x10F        // 84 dB
#define CODEC_DRV_ADC_DIG_GAIN_MIN_HEX  0x00        // -17.625 dB
/**
 * \defgroup    CODEC_Exported_Types    Init Params Struct
 *
 * \ingroup     CODEC
 */
typedef enum t_codec_ad_src_sel
{
    AD_SRC_DMIC,
    AD_SRC_AMIC,
    AD_SRC_MAX,
} T_CODEC_MIC_TYPE_SEL;

typedef enum t_codec_input_dev
{
    INPUT_DEV_NONE,
    INPUT_DEV_MIC,
    INPUT_DEV_AUX,
    INPUT_DEV_MAX,
} T_CODEC_INPUT_DEV;

typedef enum t_codec_eq_sel
{
    CODEC_EQ_ADC0,
    CODEC_EQ_ADC1,
    CODEC_EQ_PATH_ADC2,
    CODEC_EQ_PATH_ADC3,
    CODEC_EQ_PATH_ADC4,
    CODEC_EQ_PATH_ADC5,
    CODEC_EQ_PATH_DAC_L,
    CODEC_EQ_PATH_DAC_R,
} T_CODEC_EQ_SEL;

typedef enum t_codec_i2s_channel_sel
{
    I2S_CHANNEL_0,
    I2S_CHANNEL_1,
    I2S_CHANNEL_2,
    I2S_CHANNEL_3,      // Rx only
    I2S_CHANNEL_MAX,
} T_CODEC_I2S_CHANNEL_SEL;


typedef enum t_codec_dac_channel_sel
{
    DAC_CHANNEL_L,
    DAC_CHANNEL_R,
    DAC_CHANNEL_2,
} T_CODEC_DAC_CHANNEL_SEL;

typedef enum t_codec_i2s_datalen_sel
{
    I2S_DATALEN_16,
    I2S_DATALEN_32,
    I2S_DATALEN_24,
    I2S_DATALEN_8,
    I2S_DATALEN_MAX,
} T_CODEC_I2S_DATALEN_SEL;

typedef enum t_codec_i2s_channellen_sel
{
    I2S_CHANNELLEN_16,
    I2S_CHANNELLEN_32,
    I2S_CHANNELLEN_24,
    I2S_CHANNELLEN_8,
    I2S_CHANNELLEN_MAX,
} T_CODEC_I2S_CHANNELLEN_SEL;

typedef enum t_sport_data_format_sel
{
    FORMAT_I2S,
    FORMAT_LEFT_JUSTIFY,
    FORMAT_PCM_MODE_A,
    FORMAT_PCM_MODE_B,
    FORMAT_MAX,
} T_CODEC_DATA_FORMAT_SEL;

typedef enum t_dac_da_dither_sel
{
    DAC_DA_DITHER_DISABLE = 0,
    DAC_DA_DITHER_LSB = 1,
    DAC_DA_DITHER_LSB_PLUS_1 = 2,
    DAC_DA_DITHER_LSB_PLUS_2 = 3,
} T_DAC_DA_DITHER_SEL;


typedef enum t_codec_i2s_tx_ch_sel
{
    I2S_TX_CH_SEL_L_R,
    I2S_TX_CH_SEL_R_L,
    I2S_TX_CH_SEL_L_L,
    I2S_TX_CH_SEL_R_R,
    I2S_TX_CH_SEL_MAX,
} T_CODEC_I2S_CH_Sequence_SEL;

typedef enum t_codec_i2s_rx_ch_sel
{
    I2S_RX_CH_SEL_ADC0,
    I2S_RX_CH_SEL_ADC1,
    I2S_RX_CH_SEL_ADC2,
    I2S_RX_CH_SEL_ADC3,
    I2S_RX_CH_SEL_ADC4,
    I2S_RX_CH_SEL_ADC5,
    I2S_RX_CH_SEL_ADC6,
    I2S_RX_CH_SEL_ADC7,
    I2S_RX_CH_SEL_MAX,
} T_CODEC_I2S_RX_CH_SEL;



typedef enum t_codec_i2s_rx_ch
{
    I2S_RX_CH_0,
    I2S_RX_CH_1,
    I2S_RX_CH_2,
    I2S_RX_CH_3,
    I2S_RX_CH_4,
    I2S_RX_CH_5,
    I2S_RX_CH_6,
    I2S_RX_CH_7,
    I2S_RX_CH_MAX,
} T_CODEC_I2S_RX_CH;

typedef enum t_sport_tdm_mode_sel
{
    TDM_2_CHANNEL,
    TDM_4_CHANNEL,
    TDM_6_CHANNEL,
    TDM_8_CHANNEL,
    TDM_CHANNEL_MAX,
} T_CODEC_SPORT_TDM_MODE_SEL;


typedef enum t_codec_sample_rate
{
    CODEC_SAMPLE_RATE_48K,      // 0: 48KHz
    CODEC_SAMPLE_RATE_96K,      // 1: 96KHz
    CODEC_SAMPLE_RATE_192K,     // 2: 192KHz
    CODEC_SAMPLE_RATE_32K,      // 3: 32KHz
    CODEC_SAMPLE_RATE_176K,     // 4: 176.4KHz
    CODEC_SAMPLE_RATE_16K,      // 5: 16KHz
    CODEC_SAMPLE_RATE_RSV_1,
    CODEC_SAMPLE_RATE_8K,       // 7: 8KHz
    CODEC_SAMPLE_RATE_44_1K,    // 8: 44.1KHz
    CODEC_SAMPLE_RATE_88_2K,    // 9: 88.2KHz
    CODEC_SAMPLE_RATE_24K,      // 10: 24KHz
    CODEC_SAMPLE_RATE_12K,      // 11: 12KHz
    CODEC_SAMPLE_RATE_22_05K,   // 12: 22.05KHz
    CODEC_SAMPLE_RATE_11_025K,  // 13: 11.025KHz
    CODEC_SAMPLE_RATE_NUM,
} T_CODEC_SAMPLE_RATE;


typedef enum t_codec_sample_rate_src
{
    SAMPLE_RATE_SRC0 = 0,
    SAMPLE_RATE_SRC1 = 1,
    SAMPLE_RATE_SRC2 = 2,
    SAMPLE_RATE_SRC3_AD = 3,
    SAMPLE_RATE_SRC3_DA = 4,
    SAMPLE_RATE_SRC_MAX = 5,
} T_CODEC_SAMPLE_RATE_SRC;


typedef enum t_codec_dmic_clk_sel
{
    DMIC_CLK_5MHZ,
    DMIC_CLK_2P5MHZ,
    DMIC_CLK_1P25MHZ,
    DMIC_CLK_625kHZ,
    DMIC_CLK_312P5kHZ,
    DMIC_CLK_RSV_1,
    DMIC_CLK_RSV_2,
    DMIC_CLK_769P2kHZ,
    DMIC_CLK_SEL_MAX,
} T_CODEC_DMIC_CLK_SEL;

typedef enum t_codec_dmic_channel_sel
{
    DMIC_CHANNEL1,
    DMIC_CHANNEL2,
    DMIC_CHANNEL3,
    DMIC_CHANNEL4,
    DMIC_CHANNEL_MAX,
} T_CODEC_DMIC_CHANNEL_SEL;

typedef enum t_codec_amic_channel_sel
{
    AMIC_CHANNEL1,
    AMIC_CHANNEL2,
    AMIC_CHANNEL3,
    AMIC_CHANNEL_MAX,
} T_CODEC_AMIC_CHANNEL_SEL;

//typedef enum t_codec_input_dev
//{
//    INPUT_DEV_NONE,
//    INPUT_DEV_MIC,
//    INPUT_DEV_AUX,
//    INPUT_DEV_MAX,
//} T_CODEC_INPUT_DEV;

typedef enum t_codec_dac_ana_gain
{
    CODEC_DAC_ANA_GAIN_0,       // 0,      0dB
    CODEC_DAC_ANA_GAIN_0P5,     // 1,   -0.5dB
    CODEC_DAC_ANA_GAIN_1,       // 2,     -1dB
    CODEC_DAC_ANA_GAIN_1P5,     // 3,   -1.5dB
    CODEC_DAC_ANA_GAIN_2,       // 4,     -2dB
    CODEC_DAC_ANA_GAIN_2P5,     // 5,   -2.5dB
    CODEC_DAC_ANA_GAIN_3,       // 6,     -3dB
    CODEC_DAC_ANA_GAIN_3P5,     // 7,   -3.5dB
    CODEC_DAC_ANA_GAIN_4,       // 8,     -4dB
    CODEC_DAC_ANA_GAIN_4P5,     // 9,   -4.5dB
    CODEC_DAC_ANA_GAIN_5,       // 10,    -5dB
    CODEC_DAC_ANA_GAIN_5P5,     // 11,  -5.5dB
    CODEC_DAC_ANA_GAIN_6,       // 12,    -6dB
    CODEC_DAC_ANA_GAIN_6P5,     // 13,  -6.5dB
    CODEC_DAC_ANA_GAIN_7,       // 14,    -7dB
    CODEC_DAC_ANA_GAIN_7P5,     // 15,  -7.5dB
    CODEC_DAC_ANA_GAIN_8,       // 16,    -8dB
    CODEC_DAC_ANA_GAIN_8P5,     // 17,  -8.5dB
    CODEC_DAC_ANA_GAIN_9,       // 18,    -9dB
    CODEC_DAC_ANA_GAIN_9P5,     // 19,  -9.5dB
    CODEC_DAC_ANA_GAIN_10,      // 20,   -10dB
    CODEC_DAC_ANA_GAIN_10P5,    // 21, -10.5dB
    CODEC_DAC_ANA_GAIN_11,      // 22,   -11dB
    CODEC_DAC_ANA_GAIN_11P5,    // 23, -11.5dB
    CODEC_DAC_ANA_GAIN_12,      // 24,   -12dB
    CODEC_DAC_ANA_GAIN_12P5,    // 25, -12.5dB
    CODEC_DAC_ANA_GAIN_13,      // 26,   -13dB
    CODEC_DAC_ANA_GAIN_13P5,    // 27, -13.5dB
    CODEC_DAC_ANA_GAIN_14,      // 28,   -14dB
    CODEC_DAC_ANA_GAIN_14P5,    // 29, -14.5dB
    CODEC_DAC_ANA_GAIN_15,      // 30,   -15dB
    CODEC_DAC_ANA_GAIN_15P5,    // 31, -15.5dB
    CODEC_DAC_ANA_GAIN_MAX,
} T_CODEC_DAC_ANA_GAIN;

typedef enum t_codec_adc_ana_gain
{
    CODEC_ADC_ANA_GAIN_0,       // 0dB
    CODEC_ADC_ANA_GAIN_3,       // 3dB
    CODEC_ADC_ANA_GAIN_6,       // 6dB
    CODEC_ADC_ANA_GAIN_9,       // 9dB
    CODEC_ADC_ANA_GAIN_12,      // 12dB
    CODEC_ADC_ANA_GAIN_18,      // 18dB
    CODEC_ADC_ANA_GAIN_24,      // 24dB
    CODEC_ADC_ANA_GAIN_30,      // 30dB
    CODEC_ADC_ANA_GAIN_MAX,
} T_CODEC_ADC_ANA_GAIN;

#define      CODEC_DACL_DACR  0x0
#define    CODEC_DACL_DAC2  0x2
#define      CODEC_DACR_DAC2  0x6
#define      CODEC_DACR_DACL  0x8

typedef struct
{
    /* I2S  section */
    T_CODEC_I2S_CHANNEL_SEL           CODEC_I2S_Channel;
    T_CODEC_DATA_FORMAT_SEL
    CODEC_I2S_Format;           /*!< Specifies the I2S Tx/Rx format of codec port. */

    T_CODEC_I2S_DATALEN_SEL
    CODEC_I2S_DataLen;        /*!< Specifies the I2S Tx/Rx data width of codec port. */
    T_CODEC_I2S_CHANNELLEN_SEL
    CODEC_I2S_ChannelLen;        /*!< Specifies the I2S Tx/Rx data width of codec port. */
    T_CODEC_I2S_CH_Sequence_SEL
    CODEC_I2S_ChSequence;       /*!< Specifies the I2S Tx/Rx channel sequence. */
    T_CODEC_SPORT_TDM_MODE_SEL        CODEC_I2S_Rx_TDM_Mode;
    uint8_t                           CODEC_I2S_SameLrcEn;

    uint8_t                           CODEC_I2S_RX_CHEn[I2S_RX_CH_MAX];
    T_CODEC_I2S_RX_CH_SEL             CODEC_I2S_RX_CHSel[I2S_RX_CH_MAX];

} CODEC_I2S_InitTypeDef;



typedef struct
{
//    T_CODEC_INPUT_DEV                      CODEC_Input_Dev;
    /* Sample rate section */
    T_CODEC_SAMPLE_RATE_SRC              CODEC_SampleRateSrc;
    T_CODEC_SAMPLE_RATE                  CODEC_SampleRate;    /*!< Specifies the sample rate. */
    T_CODEC_I2S_CHANNEL_SEL              CODEC_I2SChannel;
    /* DMIC  initialization parameters section */
    T_CODEC_DMIC_CLK_SEL
    CODEC_DmicClkSel[DMIC_CHANNEL_MAX];       /*!< Specifies the dmic clock. */
    T_CODEC_MIC_TYPE_SEL
    CODEC_MicType;          /*!< Specifies the  mic type, which can be dmic or amic. */
    uint32_t
    CODEC_Mute;                        /*!< Specifies the  dmic mute status. */
    uint32_t
    CODEC_DmicSRC;         /*!< Specifies the  dmic data latch type.0: DMIC1 rising, 1: DMIC1 falling, 2: DMIC2 rising, 3: DMIC2 falling  4: DMIC3 rising, 5: DMIC3 falling, 6: DMIC4 falling   */
    uint32_t
    CODEC_AmicSRC;         /* Channel  ANA ADC source selection 3'd0: ADC1 3'd1: ADC2  3'd2: ADC3  */
    uint32_t
    CODEC_AdGain;           /*!< Specifies the   ADC digital volume. */
    uint32_t
    CODEC_ZeroDetTimeout;   /*!< Specifies the  zero detection timeout mode control. */

} CODEC_ADC_InitTypeDef;

typedef struct
{
    /* AMIC  initialization parameters section */
    uint8_t                                CODEC_AmicType;        // 0: single-end, 1: differential
    T_CODEC_ADC_ANA_GAIN                   CODEC_AnaGain;
//    T_CODEC_INPUT_DEV                      CODEC_InputDev;
    T_CODEC_AMIC_CHANNEL_SEL               CODEC_MicSel;
} CODEC_AMIC_InitTypeDef;


typedef struct
{
    /* Sample rate section */
    T_CODEC_DAC_CHANNEL_SEL              CODEC_DAC_Channel;
    T_CODEC_SAMPLE_RATE_SRC              CODEC_SampleRate_Src;
    T_CODEC_SAMPLE_RATE                  CODEC_SampleRate;    /*!< Specifies the sample rate. */
    uint8_t
    CODEC_LR_Align_En;   /**If 1, L/R using the same setting; "sample rate source selection" and "i2s source selection" of R channel are useless. */
    T_CODEC_I2S_CHANNEL_SEL              CODEC_I2S_Channel;
    T_CODEC_DAC_ANA_GAIN                 CODEC_DaGain;
    uint16_t                             CODEC_DownLinkCtrol;

    T_DAC_DA_DITHER_SEL                  CODEC_DaC_Dither;
    uint8_t                              CODEC_MusicMuteEn;
    uint8_t                              CODEC_AncMuteEn;

} CODEC_DAC_InitTypeDef;

/**
 * \brief       CODEC EQ part initialize parameters.
 *
 * \ingroup     CODEC_Exported_Types
 */
typedef struct
{
    uint32_t          CODEC_EQChCmd;             /*!< Specifies the EQ channel status */
    uint32_t
    CODEC_EQCoefH0;            /*!< Specifies the EQ coef.h0. This value can be 0 to 0x7FFFF,
                                                 whose physical meaning represents a range of-8 to 7.99 */
    uint32_t
    CODEC_EQCoefB1;            /*!< Specifies the EQ coef.b1. This value can be 0 to 0x7FFFF,
                                                 whose physical meaning represents a range of-8 to 7.99 */
    uint32_t
    CODEC_EQCoefB2;            /*!< Specifies the EQ coef.b2. This value can be 0 to 0x7FFFF,
                                                 whose physical meaning represents a range of-8 to 7.99 */
    uint32_t
    CODEC_EQCoefA1;            /*!< Specifies the EQ coef.a1. This value can be 0 to 0x7FFFF,
                                                 whose physical meaning represents a range of-8 to 7.99 */
    uint32_t
    CODEC_EQCoefA2;            /*!< Specifies the EQ coef.a2. This value can be 0 to 0x7FFFF,
                                                 whose physical meaning represents a range of-8 to 7.99 */
} CODEC_EQInitTypeDef;

void CODEC_AnalogCircuitInit(void);
void CODEC_DAC_StructInit(CODEC_DAC_InitTypeDef *CODEC_DAC_InitStruct);
void CODEC_DAC_Init(CODEC_DAC_InitTypeDef *CODEC_DAC_InitStruct,
                    T_CODEC_DAC_CHANNEL_SEL CODEC_DAC_Channel);
void CODEC_ADC_Init(CODEC_ADC_TypeDef *CODEC_ADCx, CODEC_ADC_InitTypeDef *CODEC_ADC_InitStruct);
void CODEC_ADC_Init(CODEC_ADC_TypeDef *CODEC_ADCx, CODEC_ADC_InitTypeDef *CODEC_ADC_InitStruct);
void CODEC_ADC_StructInit(CODEC_ADC_InitTypeDef *CODEC_ADC_InitStruct);
void CODEC_I2S_Init(CODEC_I2S_InitTypeDef *CODEC_I2S_InitStruct);
void CODEC_I2S_StructInit(CODEC_I2S_InitTypeDef *CODEC_I2S_InitStruct);
/** \} */ /* End of group CODEC_Exported_Functions */

#ifdef __cplusplus
}
#endif

#endif /* _RTL876X_CODEC_H_ */
