/**
 * @file codec_reg.h
 * @author
 * @brief
 *      2020-11-09  first define the Physical Codec State Machine
 *      audio_register_20201029.xlsx
 * @version 0.0.1
 * @date 2020-11-09
 *
 * @copyright Copyright (c) 2020
 *
 */
#ifndef _CODEC_REG_H_
#define _CODEC_REG_H_

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "rtl876x.h"
#include "trace.h"



#ifdef  __cplusplus
extern "C" {
#endif /* __cplusplus */


//=== start of page 0x00 ===
typedef union t_codec_page0_0x00_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t MCU_WR_MASK               : 32;  //u(32, 0f), start@0x00
    };
} T_CODEC_PAGE0_0x00_TYPE;

typedef union t_codec_page0_0x04_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t DSP1_WR_MASK              : 32;  //u(32, 0f), start@0x04
    };
} T_CODEC_PAGE0_0x04_TYPE;

typedef union t_codec_page0_0x08_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t DSP2_WR_MASK              : 32;  //u(32, 0f), start@0x08
    };
} T_CODEC_PAGE0_0x08_TYPE;

typedef union t_codec_page0_0x0c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t vad_clk_en                : 1;   //u( 1, 0f), start@0x0c
        uint32_t rsvd0: 30;                         // [31:1]
    };
} T_CODEC_PAGE0_0x0C_TYPE;

typedef union t_codec_page0_0x10_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t REG_POWADDACK: 1;                  // [0]
        uint32_t REG_DAC_CKXEN: 1;                  // [1]
        uint32_t REG_DAC_CKXSEL: 1;                 // [2]
        uint32_t REG_DAC_L_POW: 1;                  // [3]
        uint32_t REG_DAC_R_POW: 1;                  // [4]
        uint32_t rsvd0: 4;                          // [8:5]
        uint32_t REG_MBIAS_POW: 1;                  // [9]
        uint32_t REG_DAC_OFFSETN_EN_L: 1;           // [10]
        uint32_t REG_DAC_OFFSETN_EN_R: 1;           // [11]
        uint32_t REG_DAC_OFFSETP_EN_L: 1;           // [12]
        uint32_t REG_DAC_OFFSETP_EN_R: 1;           // [13]
        uint32_t REG_ADDA_BYPASS: 1;                // [14]
        uint32_t REG_ADDA_BYPASS_ADSEL: 1;          // [15]
        uint32_t rsvd1: 3;                          // [18:16]
        uint32_t REG_DAC_CKINX2: 1;                 // [19]
        uint32_t rsvd2: 12;                         // [31:20]
    };
} T_CODEC_PAGE0_0x10_TYPE;



typedef union t_codec_page0_0x14_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t rsvd0: 16;                          // [15:0]
        uint32_t CODEC_rsvd0: 16;                    // [31:16]
    };
} T_CODEC_PAGE0_0x14_TYPE;

typedef union t_codec_page0_0x18_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t REG_DTSDM1_POW: 1;                  // [0] (ADC1)
        uint32_t rsvd0: 1;                           // [1]
        uint32_t REG_DTSDM1_CKXEN: 1;                // [2]
        uint32_t REG_DTSDM1_CKXSEL: 1;               // [3]
        uint32_t REG_DTSDM1_CR: 2;                   // [5:4]
        uint32_t REG_DTSDM1_DITHER_EN: 1;            // [6]
        uint32_t rsvd1: 1;                           // [7]
        uint32_t REG_DTSDM1_HSNR_MODE: 1;            // [8]
        uint32_t REG_DTSDM1_LP_MODE: 1;              // [9]
        uint32_t REG_DTSDM1_CKIN_OSRX2: 1;           // [10]
        uint32_t rsvd2: 5;                           // [15:11]
        uint32_t REG_DTSDM2_POW: 1;                  // [16] (ADC2)
        uint32_t rsvd3: 1;                           // [7]
        uint32_t REG_DTSDM2_CKXEN: 1;                // [18]
        uint32_t REG_DTSDM2_CKXSEL: 1;               // [19]
        uint32_t REG_DTSDM2_CR: 2;                   // [21:20]
        uint32_t REG_DTSDM2_DITHER_EN: 1;            // [22]
        uint32_t rsvd4: 1;                           // [23]
        uint32_t REG_DTSDM2_HSNR_MODE: 1;            // [24]
        uint32_t REG_DTSDM2_LP_MODE: 1;              // [25]
        uint32_t REG_DTSDM2_CKIN_OSRX2: 1;           // [26]
        uint32_t rsvd5: 5;                           // [31:27]
    };
} T_CODEC_PAGE0_0x18_TYPE;

typedef union t_codec_page0_0x1c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t REG_DTSDM3_POW: 1;                  // [0] (ADC3)
        uint32_t rsvd0: 5;                           // [5:1]
        uint32_t REG_DTSDM3_DITHER_EN: 1;            // [6]
        uint32_t rsvd1: 25;                          // [31:7]
    };
} T_CODEC_PAGE0_0x1C_TYPE;

typedef union t_codec_page0_0x20_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t rsvd0: 3;                          // [2:0]
        uint32_t REG_MBIAS_ISEL_DAC: 3;             // [5:3]
        uint32_t rsvd1: 26;                         // [8:6]
    };
} T_CODEC_PAGE0_0x20_TYPE;

typedef union t_codec_page0_0x24_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t REG_MBIAS_ISEL_DTSDM1_INT1: 3;   // [2:0]
        uint32_t rsvd0: 3;                        // [5:3]
        uint32_t REG_MBIAS_ISEL_DTSDM1: 3;        // [8:6]
        uint32_t rsvd1: 3;                        // [11:9]
        uint32_t REG_MBIAS_ISEL_DTSDM2_INT1: 3;   // [14:12]
        uint32_t rsvd2: 3;                        // [17:15]
        uint32_t REG_MBIAS_ISEL_DTSDM2: 3;        // [20:18]
        uint32_t rsvd3: 11;                       // [31:21]

    };
} T_CODEC_PAGE0_0x24_TYPE;

typedef union t_codec_page0_0x28_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t REG_MBIAS_ISEL_DTSDM3_INT1: 3;   // [2:0]
        uint32_t rsvd0: 3;                        // [5:3]
        uint32_t REG_MBIAS_ISEL_DTSDM3: 3;        // [8:6]
        uint32_t rsvd1: 23;                       // [31:9]
    };
} T_CODEC_PAGE0_0x28_TYPE;

typedef union t_codec_page0_0x2c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t REG_MBIAS_ISEL_MICBIAS: 3;         // [2:0]
        uint32_t REG_MBIAS_ISEL_MICBST1: 3;         // [5:3]
        uint32_t rsvd0: 3;                          // [8:6]
        uint32_t REG_MBIAS_ISEL_MICBST2: 3;         // [11:9]
        uint32_t rsvd1: 3;                          // [14:12]
        uint32_t REG_MBIAS_ISEL_MICBST3: 3;         // [17:15]
        uint32_t rsvd2: 14;                         // [31:18]
    };
} T_CODEC_PAGE0_0x2C_TYPE;

typedef union t_codec_page0_0x30_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t REG_MICBIAS_POW: 1;            // [0]
        uint32_t REG_MICBIAS_ENCHX: 1;          // [1]
        uint32_t REG_MICBIAS_OP_COMP: 1;        // [2]
        uint32_t REG_MICBIAS_POWSHDT: 1;        // [3]
        uint32_t REG_MICBIAS_COUNT: 2;          // [5:4]
        uint32_t REG_MICBIAS_OCSEL: 2;          // [7:6]
        uint32_t REG_MICBIAS_VSET: 5;           // [12:8]
        uint32_t REG_MICBIAS_RESERVE: 3;        // [15:13]
        uint32_t REG_MICBIAS_ENCOMP: 1;         // [16]
        uint32_t rsvd0: 15;                     // [31:17]
    };
} T_CODEC_PAGE0_0x30_TYPE;

typedef union t_codec_page0_0x34_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t REG_MICBST1_LINE: 2;              // [1:0]
        uint32_t rsvd0: 2;                           // [3:2]
        uint32_t REG_MICBST1_MUTE: 2;                // [5:4]
        uint32_t rsvd1: 2;                           // [7:6]
        uint32_t REG_MICBST1_GSEL: 4;                // [11:8]
        uint32_t rsvd2: 4;                           // [15:12]
        uint32_t REG_MICBST1_POW: 1;                 // [16]
        uint32_t rsvd3: 1;                           // [17]
        uint32_t REG_MICBST1_CALL: 2;                // [19:18]
        uint32_t REG_MICBST1_CALPHASE: 2;            // [21:20]
        uint32_t rsvd4: 4;                           // [25:22]
        uint32_t REG_MICBST1_EN10K: 1;               // [26]
        uint32_t rsvd5: 4;                           // [27]
        uint32_t REG_MICBST1_ENDF: 1;                // [28]
        uint32_t rsvd6: 3;                           // [31:29]
    };
} T_CODEC_PAGE0_0x34_TYPE;

typedef union t_codec_page0_0x38_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t REG_MICBST2_LINE: 2;                // [1:0]
        uint32_t rsvd0: 2;                           // [3:2]
        uint32_t REG_MICBST2_MUTE: 1;                // [4]
        uint32_t rsvd1: 3;                           // [5:7]
        uint32_t REG_MICBST2_GSEL:  4;               // [11:8]
        uint32_t rsvd2: 4;                           // [15:12]
        uint32_t REG_MICBST2_POW: 1;                 // [16]
        uint32_t rsvd3: 1;                           // [17]
        uint32_t REG_MICBST2_CAL1: 2;                // [19:18]
        uint32_t REG_MICBST2_CALPHASE1: 2;           // [21:20]
        uint32_t rsvd4: 4;                           // [25:22]
        uint32_t REG_MICBST2_EN10K1: 1;              // [26]
        uint32_t rsvd5: 4;                           // [27]
        uint32_t REG_MICBST2_ENDF: 1;                // [28]
        uint32_t rsvd6: 3;                           // [31:29]
    };
} T_CODEC_PAGE0_0x38_TYPE;

typedef union t_codec_page0_0x3c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t REG_MICBST3_LINE: 2;                // [1:0]
        uint32_t rsvd0: 2;                           // [3:2]
        uint32_t REG_MICBST3_MUTE: 1;                // [4]
        uint32_t rsvd1: 3;                           // [5:7]
        uint32_t REG_MICBST3_GSEL:  4;               // [11:8]
        uint32_t rsvd2: 4;                           // [15:12]
        uint32_t REG_MICBST3_POW: 1;                 // [16]
        uint32_t rsvd3: 1;                           // [17]
        uint32_t REG_MICBST3_CAL1: 2;                // [19:18]
        uint32_t REG_MICBST3_CALPHASE1: 2;           // [21:20]
        uint32_t rsvd4: 4;                           // [25:22]
        uint32_t REG_MICBST3_EN10K1: 1;              // [26]
        uint32_t rsvd5: 4;                           // [27]
        uint32_t REG_MICBST3_ENDF: 1;                // [28]
        uint32_t rsvd6: 3;                           // [31:29]
    };
} T_CODEC_PAGE0_0x3C_TYPE;

typedef union t_codec_page0_0x40_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t rsvd0: 32;                  // [31:0]
    };
} T_CODEC_PAGE0_0x40_TYPE;

typedef union t_codec_page0_0x44_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t rsvd0: 32;                  // [31:0]
    };
} T_CODEC_PAGE0_0x44_TYPE;


typedef union t_codec_page0_0x48_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t rsvd0: 32;                  // [31:0]
    };
} T_CODEC_PAGE0_0x48_TYPE;


typedef union t_codec_page0_0x4c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t rsvd0: 32;                  // [31:0]
    };
} T_CODEC_PAGE0_0x4C_TYPE;


typedef union t_codec_page0_0x50_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t rsvd0: 32;                  // [31:0]
    };
} T_CODEC_PAGE0_0x50_TYPE;

typedef union t_codec_page0_0x54_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t rsvd0: 32;                  // [31:0]
    };
} T_CODEC_PAGE0_0x54_TYPE;

typedef union t_codec_page0_0x58_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t REG_MICBST1_RESERVE: 4;             // [3:0]
        uint32_t REG_MICBST2_RESERVE: 4;             // [7:4]
        uint32_t CKEN_MIC1: 1;                       // [8]
        uint32_t CKEN_MIC2: 1;                       // [9]
        uint32_t rsvd0: 2;                           // [11:10]
        uint32_t REG_VCMBUF_BYPASS: 1;               // [12]
        uint32_t VCMBUF_ISEL: 1;                     // [13]
        uint32_t VCMBUF_POW: 1;                      // [14]
        uint32_t rsvd1: 17;                           // [31:15]
    };
} T_CODEC_PAGE0_0x58_TYPE;

//--- end of page 0x00 ---

//=== start of page 0x01 ===
typedef union t_codec_page1_0x00_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t audio_ip_en               : 1;   //u( 1, 0f), start@0x00, [ 0: 0] used
        uint32_t daad_lpbk_en              : 1;   //u( 1, 0f), start@0x00, [ 1: 1] used
        uint32_t adda_lpbk_en              : 1;   //u( 1, 0f), start@0x00, [ 2: 2] used
        uint32_t ext_adda_en               : 1;   //u( 1, 0f), start@0x00, [ 3: 3] used
        uint32_t sys_clk_rate_sel          : 2;   //u( 2, 0f), start@0x00, [ 5: 4] used
        uint32_t rws_seq_en                : 2;   //u( 2, 0f), start@0x00, [ 7: 6] used
        uint32_t adc_0_eq_num_sel          : 2;   //u( 2, 0f), start@0x01, [ 9: 8] used
        uint32_t adc_1_eq_num_sel          : 2;   //u( 2, 0f), start@0x01, [11:10] used
        uint32_t adc_2_eq_num_sel          : 2;   //u( 2, 0f), start@0x01, [13:12] used
        uint32_t adc_3_eq_num_sel          : 2;   //u( 2, 0f), start@0x01, [15:14] used
        uint32_t adc_0_eq_in_sel           : 3;   //u( 3, 0f), start@0x02, [18:16] used
        uint32_t audio_dbg_sel             : 6;   //u( 6, 0f), start@0x02, [24:19] used
        uint32_t bit_temp_0x0100_19  : 7;   //u( 7, 0f)
    };
} T_CODEC_PAGE1_0x00_TYPE;

typedef union t_codec_page1_0x04_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t sel_bb_ck_depop           : 2;   //u( 2, 0f), start@0x04, [ 1: 0] used
        uint32_t bb_ck_depop_en            : 1;   //u( 1, 0f), start@0x04, [ 2: 2] used
        uint32_t ckx_micbias_en            : 1;   //u( 1, 0f), start@0x04, [ 3: 3] used
        uint32_t dre_hp_sel                : 1;   //u( 1, 0f), start@0x04, [ 4: 4] used
        uint32_t pdm_clk_double            : 1;   //u( 1, 0f), start@0x04, [ 5: 5] used
        uint32_t pdm_clk_sel               : 2;   //u( 2, 0f), start@0x04, [ 7: 6] used
        uint32_t pdm_ch_swap               : 2;   //u( 2, 0f), start@0x05, [ 9: 8] used
        uint32_t pdm_data_phase_sel        : 1;   //u( 1, 0f), start@0x05, [10:10] used
        uint32_t pdm_gain_shift_en         : 1;   //u( 1, 0f), start@0x05, [11:11] used
        uint32_t pdm_clk_inv_sel           : 1;   //u( 1, 0f), start@0x05, [12:12] used
        uint32_t i2s_data_rnd_en           : 1;   //u( 1, 0f), start@0x05, [13:13] used
        uint32_t audio_control_1_rsvd      : 4;   //u( 4, 0f), start@0x05, [17:14] used
        uint32_t bit_temp_0x0104_12  : 14;  //u(14, 0f)
    };
} T_CODEC_PAGE1_0x04_TYPE;

typedef union t_codec_page1_0x08_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t ad_0_en                   : 1;   //u( 1, 0f), start@0x08, [ 0: 0] used
        uint32_t ad_1_en                   : 1;   //u( 1, 0f), start@0x08, [ 1: 1] used
        uint32_t ad_2_en                   : 1;   //u( 1, 0f), start@0x08, [ 2: 2] used
        uint32_t ad_3_en                   : 1;   //u( 1, 0f), start@0x08, [ 3: 3] used
        uint32_t ad_4_en                   : 1;   //u( 1, 0f), start@0x08, [ 4: 4] used
        uint32_t ad_5_en                   : 1;   //u( 1, 0f), start@0x08, [ 5: 5] used
        uint32_t ad_6_en                   : 1;   //u( 1, 0f), start@0x08, [ 6: 6] used
        uint32_t rsvd0                     : 1;   //u( 1, 0f), start@0x08, [ 7: 7] used
        uint32_t ad_0_fifo_en              : 1;   //u( 1, 0f), start@0x09, [ 8: 8] used
        uint32_t ad_1_fifo_en              : 1;   //u( 1, 0f), start@0x09, [ 9: 9] used
        uint32_t ad_2_fifo_en              : 1;   //u( 1, 0f), start@0x09, [10:10] used
        uint32_t ad_3_fifo_en              : 1;   //u( 1, 0f), start@0x09, [11:11] used
        uint32_t ad_4_fifo_en              : 1;   //u( 1, 0f), start@0x09, [12:12] used
        uint32_t ad_5_fifo_en              : 1;   //u( 1, 0f), start@0x09, [13:13] used
        uint32_t ad_6_fifo_en              : 1;   //u( 1, 0f), start@0x09, [14:14] used
        uint32_t rsvd1                     : 1;   //u( 1, 0f), start@0x09, [15:15] used
        uint32_t ad_ana_0_en               : 1;   //u( 1, 0f), start@0x0a, [16:16] used
        uint32_t ad_ana_1_en               : 1;   //u( 1, 0f), start@0x0a, [17:17] used
        uint32_t ad_ana_2_en               : 1;   //u( 1, 0f), start@0x0a, [18:18] used
        uint32_t ad_ana_3_en               : 1;   //u( 1, 0f), start@0x0a, [19:19] used
        uint32_t ad_ana_4_en               : 1;   //u( 1, 0f), start@0x0a, [20:20] used
        uint32_t ad_ana_5_en               : 1;   //u( 1, 0f), start@0x0a, [21:21] used
        uint32_t ad_ana_6_en               : 1;   //u( 1, 0f), start@0x0a, [22:22] used
        uint32_t rsvd2                     : 1;   //u( 1, 0f), start@0x0a, [23:23] used
        uint32_t dmic_0_en                 : 1;   //u( 1, 0f), start@0x0b, [24:24] used
        uint32_t dmic_1_en                 : 1;   //u( 1, 0f), start@0x0b, [25:25] used
        uint32_t dmic_2_en                 : 1;   //u( 1, 0f), start@0x0b, [26:26] used
        uint32_t dmic_3_en                 : 1;   //u( 1, 0f), start@0x0b, [27:27] used
        uint32_t dmic_4_en                 : 1;   //u( 1, 0f), start@0x0b, [28:28] used
        uint32_t dmic_5_en                 : 1;   //u( 1, 0f), start@0x0b, [29:29] used
        uint32_t dmic_6_en                 : 1;   //u( 1, 0f), start@0x0b, [30:30] used
        uint32_t rsvd3                     : 1;   //u( 1, 0f), start@0x0b, [31:31] used
    };
} T_CODEC_PAGE1_0x08_TYPE;

typedef union t_codec_page1_0x0C_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t da_l_en                   : 1;   //u( 1, 0f), start@0x08, [ 0: 0] used
        uint32_t da_r_en                   : 1;   //u( 1, 0f), start@0x08, [ 1: 1] used
        uint32_t ad_2_en                   : 1;   //u( 1, 0f), start@0x08, [ 2: 2] used
        uint32_t rsvd0                     : 1;   //u( 1, 0f), start@0x08, [ 3: 3] used
        uint32_t mod_l_en                  : 1;   //u( 1, 0f), start@0x08, [ 4: 4] used
        uint32_t mod_r_en                  : 1;   //u( 1, 0f), start@0x08, [ 5: 5] used
        uint32_t rsvd1                     : 2;   //u( 2, 0f), start@0x08, [ 7: 6] used
        uint32_t da_ana_clk_en             : 1;   //u( 1, 0f), start@0x09, [ 8: 8] used
        uint32_t ad_ana_clk_en             : 1;   //u( 1, 0f), start@0x09, [ 9: 9] used
        uint32_t da_fifo_en                : 1;   //u( 1, 0f), start@0x09, [10:10] used
        uint32_t rsvd2                     : 1;   //u( 1, 0f), start@0x09, [11:11] used
        uint32_t da_l_eq_en                : 1;   //u( 1, 0f), start@0x09, [12:12] used
        uint32_t da_r_eq_en                : 1;   //u( 1, 0f), start@0x09, [13:13] used
        uint32_t rsvd3                     : 2;   //u( 2, 0f), start@0x09, [15:14] used
        uint32_t ad_0_eq_en                : 1;   //u( 1, 0f), start@0x0a, [16:16] used
        uint32_t ad_1_eq_en                : 1;   //u( 1, 0f), start@0x0a, [17:17] used
        uint32_t ad_2_eq_en                : 1;   //u( 1, 0f), start@0x0a, [18:18] used
        uint32_t ad_3_eq_en                : 1;   //u( 1, 0f), start@0x0a, [19:19] used
        uint32_t ad_4_eq_en                : 1;   //u( 1, 0f), start@0x0a, [20:20] used
        uint32_t ad_5_eq_en                : 1;   //u( 1, 0f), start@0x0a, [21:21] used
        uint32_t ad_6_eq_en                : 1;   //u( 1, 0f), start@0x0a, [22:22] used
        uint32_t rsvd4                     : 1;   //u( 1, 0f), start@0x0a, [23:23] used
        uint32_t st_l_en                   : 1;   //u( 1, 0f), start@0x0a, [14:14] used
        uint32_t st_r_en                   : 1;   //u( 1, 0f), start@0x0a, [25:25] used
        uint32_t st_ds_l_en                : 1;   //u( 1, 0f), start@0x0a, [26:26] used
        uint32_t st_ds_r_en                : 1;   //u( 1, 0f), start@0x0a, [27:27] used
        uint32_t rsvd5                     : 4;   //u( 4, 0f), start@0x0a, [31:28] used
    };
} T_CODEC_PAGE1_0x0C_TYPE;


typedef union t_codec_page1_0x10_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dmic1_clk_sel             : 3;   //u( 3, 0f), start@0x10, [ 2: 0] used
        uint32_t dmic1_clk_en              : 1;   //u( 1, 0f), start@0x10, [ 3: 3] used
        uint32_t dmic2_clk_sel             : 3;   //u( 3, 0f), start@0x10, [ 6: 4] used
        uint32_t dmic2_clk_en              : 1;   //u( 1, 0f), start@0x10, [ 7: 7] used
        uint32_t dmic3_clk_sel             : 3;   //u( 3, 0f), start@0x11, [10: 8] used
        uint32_t dmic3_clk_en              : 1;   //u( 1, 0f), start@0x11, [11:11] used
        uint32_t dmic2_latch_clk_sel       : 1;   //u( 1, 0f), start@0x11, [12:12] used
        uint32_t dmic3_latch_clk_sel       : 1;   //u( 1, 0f), start@0x11, [13:13] used
        uint32_t dmic4_latch_clk_sel       : 1;   //u( 1, 0f), start@0x11, [14:14] used
        uint32_t rsvd0                     : 1;   //u( 1, 0f), start@0x11, [15:15] used
        uint32_t dmic4_clk_sel             : 3;   //u( 3, 0f), start@0x11, [18:16] used
        uint32_t dmic4_clk_en              : 1;   //u( 1, 0f), start@0x11, [19:19] used
        uint32_t rsvd1                     : 12;  //[31:20]
    };
} T_CODEC_PAGE1_0x10_TYPE;

typedef union t_codec_page1_0x14_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t sample_rate_0             : 4;   //u( 4, 0f), start@0x14, [ 3: 0] used
        uint32_t sample_rate_1             : 4;   //u( 4, 0f), start@0x14, [ 7: 4] used
        uint32_t sample_rate_2             : 4;   //u( 4, 0f), start@0x15, [11: 8] used
        uint32_t sample_rate_3_ad          : 4;   //u( 4, 0f), start@0x15, [15:12] used
        uint32_t sample_rate_3_da          : 4;   //u( 4, 0f), start@0x16, [19:16] used
        uint32_t bit_temp_0x0114_14  : 12;  //u(12, 0f)
    };
} T_CODEC_PAGE1_0x14_TYPE;

typedef union t_codec_page1_0x18_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_fs_src_sel          : 2;   //u( 2, 0f), start@0x18, [ 1: 0] used
        uint32_t dac_r_fs_src_sel          : 2;   //u( 2, 0f), start@0x18, [ 3: 2] used
        uint32_t adc_0_fs_src_sel          : 2;   //u( 2, 0f), start@0x18, [ 5: 4] used
        uint32_t adc_1_fs_src_sel          : 2;   //u( 2, 0f), start@0x18, [ 7: 6] used
        uint32_t adc_2_fs_src_sel          : 2;   //u( 2, 0f), start@0x19, [ 9: 8] used
        uint32_t adc_3_fs_src_sel          : 2;   //u( 2, 0f), start@0x19, [11:10] used
        uint32_t adc_4_fs_src_sel          : 2;   //u( 2, 0f), start@0x19, [13:12] used
        uint32_t adc_5_fs_src_sel          : 2;   //u( 2, 0f), start@0x19, [15:14] used
        uint32_t adc_6_fs_src_sel          : 2;   //u( 2, 0f), start@0x19, [17:16] used
        uint32_t bit_temp_B0118_12         : 14;
    };
} T_CODEC_PAGE1_0x18_TYPE;

typedef union t_codec_page1_0x1c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_asrc_en             : 1;   //u( 1, 0f), start@0x1c, [ 0: 0] used
        uint32_t adc_1_asrc_en             : 1;   //u( 1, 0f), start@0x1c, [ 1: 1] used
        uint32_t adc_2_asrc_en             : 1;   //u( 1, 0f), start@0x1c, [ 2: 2] used
        uint32_t adc_3_asrc_en             : 1;   //u( 1, 0f), start@0x1c, [ 3: 3] used
        uint32_t adc_4_asrc_en             : 1;   //u( 1, 0f), start@0x1c, [ 4: 4] used
        uint32_t adc_5_asrc_en             : 1;   //u( 1, 0f), start@0x1c, [ 5: 5] used
        uint32_t dac_l_asrc_en             : 1;   //u( 1, 0f), start@0x1c, [ 6: 6] used
        uint32_t dac_r_asrc_en             : 1;   //u( 1, 0f), start@0x1c, [ 7: 7] used
        uint32_t dac_lr_align              : 1;   //u( 1, 0f), start@0x1d, [ 8: 8] used
        uint32_t da_ana_clk_sel            : 1;   //u( 1, 0f), start@0x1d, [ 9: 9] used
        uint32_t ad_ana_clk_sel            : 1;   //u( 1, 0f), start@0x1d, [10:10] used
        uint32_t adc_latch_phase           : 1;   //u( 1, 0f), start@0x1d, [11:11] used
        uint32_t ana_clk_phase_sel         : 1;   //u( 1, 0f), start@0x1d, [12:12] used
        uint32_t ad_ana_osr_double         : 1;   //u( 1, 0f), start@0x1d, [13:13] used
        uint32_t da_ana_data_swap          : 1;   //u( 1, 0f), start@0x1d, [14:14] used
        uint32_t bit_temp_0x011c_0f  : 1;   //u( 1, 0f)
        uint32_t ana_clk_rate_sel          : 2;   //u( 2, 0f), start@0x1e, [17:16] used
        uint32_t ad_lpf_clk_rate_sel       : 2;   //u( 2, 0f), start@0x1e, [19:18] used
        uint32_t adc_0_dmic_lpf_clk_sel    : 1;   //u( 2, 0f), start@0x1e, [20:20] used
        uint32_t adc_1_dmic_lpf_clk_sel    : 1;   //u( 2, 0f), start@0x1e, [21:21] used
        uint32_t adc_2_dmic_lpf_clk_sel    : 1;   //u( 2, 0f), start@0x1f, [22:22] used
        uint32_t adc_3_dmic_lpf_clk_sel    : 1;   //u( 2, 0f), start@0x1f, [23:23] used
        uint32_t adc_4_dmic_lpf_clk_sel    : 1;   //u( 2, 0f), start@0x1f, [24:24] used
        uint32_t adc_5_dmic_lpf_clk_sel    : 1;   //u( 2, 0f), start@0x1f, [25:25] used
        uint32_t adc_6_dmic_lpf_clk_sel    : 1;   //u( 2, 0f), start@0x1f, [26:26] used
        uint32_t bit_temp_0x011c_1b        : 5;   //u( 5, 0f)
    };
} T_CODEC_PAGE1_0x1C_TYPE;

typedef union t_codec_page1_0x20_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t asrc_rate_sel_tx_0        : 2;   //u( 2, 0f), start@0x20, [ 1: 0] used
        uint32_t asrc_gain_sel_tx_0        : 2;   //u( 2, 0f), start@0x20, [ 3: 2] used
        uint32_t asrc_auto_adjust_tx_0     : 1;   //u( 1, 0f), start@0x20, [ 4: 4] used
        uint32_t bit_temp_0x0120_05  : 3;   //u( 3, 0f)
        uint32_t asrc_sdm_inti_tx_0        : 24;  //u(24, 0f), start@0x21, [31: 8] used
    };
} T_CODEC_PAGE1_0x20_TYPE;

typedef union t_codec_page1_0x24_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t asrc_rate_sel_tx_1        : 2;   //u( 2, 0f), start@0x24, [ 1: 0] used
        uint32_t asrc_gain_sel_tx_1        : 2;   //u( 2, 0f), start@0x24, [ 3: 2] used
        uint32_t asrc_auto_adjust_tx_1     : 1;   //u( 1, 0f), start@0x24, [ 4: 4] used
        uint32_t bit_temp_0x0124_05  : 3;   //u( 3, 0f)
        uint32_t asrc_sdm_inti_tx_1        : 24;  //u(24, 0f), start@0x25, [31: 8] used
    };
} T_CODEC_PAGE1_0x24_TYPE;

typedef union t_codec_page1_0x28_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t asrc_rate_sel_rx_0        : 2;   //u( 2, 0f), start@0x28, [ 1: 0] used
        uint32_t asrc_gain_sel_rx_0        : 2;   //u( 2, 0f), start@0x28, [ 3: 2] used
        uint32_t asrc_auto_adjust_rx_0     : 1;   //u( 1, 0f), start@0x28, [ 4: 4] used
        uint32_t bit_temp_0x0128_05  : 3;   //u( 3, 0f)
        uint32_t asrc_sdm_inti_rx_0        : 24;  //u(24, 0f), start@0x29, [31: 8] used
    };
} T_CODEC_PAGE1_0x28_TYPE;

typedef union t_codec_page1_0x2c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t asrc_rate_sel_rx_1        : 2;   //u( 2, 0f), start@0x2c, [ 1: 0] used
        uint32_t asrc_gain_sel_rx_1        : 2;   //u( 2, 0f), start@0x2c, [ 3: 2] used
        uint32_t asrc_auto_adjust_rx_1     : 1;   //u( 1, 0f), start@0x2c, [ 4: 4] used
        uint32_t bit_temp_0x012c_05  : 3;   //u( 3, 0f)
        uint32_t asrc_sdm_inti_rx_1        : 24;  //u(24, 0f), start@0x2d, [31: 8] used
    };
} T_CODEC_PAGE1_0x2C_TYPE;

typedef union t_codec_page1_0x30_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t asrc_rate_sel_rx_2        : 2;   //u( 2, 0f), start@0x30, [ 1: 0] used
        uint32_t asrc_gain_sel_rx_2        : 2;   //u( 2, 0f), start@0x30, [ 3: 2] used
        uint32_t asrc_auto_adjust_rx_2     : 1;   //u( 1, 0f), start@0x30, [ 4: 4] used
        uint32_t bit_temp_0x0130_05  : 3;   //u( 3, 0f)
        uint32_t asrc_sdm_inti_rx_2        : 24;  //u(24, 0f), start@0x31, [31: 8] used
    };
} T_CODEC_PAGE1_0x30_TYPE;

typedef union t_codec_page1_0x34_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t asrc_rate_sel_tx_2        : 2;   //u( 2, 0f), start@0x34, [ 1: 0] used
        uint32_t asrc_gain_sel_tx_2        : 2;   //u( 2, 0f), start@0x34, [ 3: 2] used
        uint32_t asrc_auto_adjust_tx_2     : 1;   //u( 1, 0f), start@0x34, [ 4: 4] used
        uint32_t bit_temp_0x0134_05  : 3;   //u( 3, 0f)
        uint32_t asrc_sdm_inti_tx_2        : 24;  //u(24, 0f), start@0x35, [31: 8] used
    };
} T_CODEC_PAGE1_0x34_TYPE;

typedef union t_codec_page1_0x40_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t fs_frac_n_part_0          : 15;  //u(15, 0f), start@0x40, [14: 0] used
        uint32_t bit_temp_0x0140_0f  : 1;   //u( 1, 0f)
        uint32_t fs_frac_m_part_0          : 16;  //u(16, 0f), start@0x42, [31:16] used
    };
} T_CODEC_PAGE1_0x40_TYPE;

typedef union t_codec_page1_0x44_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t fs_integ_part_0           : 24;  //s(24, 0f), start@0x44, [23: 0] used
        uint32_t fs_update_0               : 1;   //u( 1, 0f), start@0x47, [24:24] used
        uint32_t fs_i2s_sync_mode_0        : 3;   //u( 3, 0f), start@0x47, [27:25] used
        uint32_t dual_rate_mode_0          : 1;   //u( 1, 0f), start@0x47, [28:28] used
        uint32_t qual_rate_mode_0          : 1;   //u( 1, 0f), start@0x47, [29:29] used
        uint32_t bit_temp_0x0144_1e  : 2;   //u( 2, 0f)
    };
} T_CODEC_PAGE1_0x44_TYPE;

typedef union t_codec_page1_0x48_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t i2s_0_rst_n_reg           : 1;   //u( 1, 0f), start@0x48, [ 0: 0] used
        uint32_t i2s_0_inv_sclk            : 1;   //u( 1, 0f), start@0x48, [ 1: 1] used
        uint32_t i2s_0_self_lpbk_en        : 1;   //u( 1, 0f), start@0x48, [ 2: 2] used
        uint32_t i2s_0_same_lrc_en         : 1;   //u( 1, 0f), start@0x48, [ 3: 3] used
        uint32_t i2s_0_tdm_mode_rx         : 2;   //u( 2, 0f), start@0x48, [ 5: 4] used
        uint32_t i2s_0_data_format_sel_tx  : 2;   //u( 2, 0f), start@0x48, [ 7: 6] used
        uint32_t i2s_0_data_format_sel_rx  : 2;   //u( 2, 0f), start@0x49, [ 9: 8] used
        uint32_t i2s_0_data_len_sel_tx     : 2;   //u( 2, 0f), start@0x49, [11:10] used
        uint32_t i2s_0_data_len_sel_rx     : 2;   //u( 2, 0f), start@0x49, [13:12] used
        uint32_t i2s_0_ch_len_sel_tx       : 2;   //u( 2, 0f), start@0x49, [15:14] used
        uint32_t i2s_0_ch_len_sel_rx       : 2;   //u( 2, 0f), start@0x4a, [17:16] used
        uint32_t i2s_0_data_ch_sel_tx      : 2;   //u( 2, 0f), start@0x4a, [19:18] used
        uint32_t bit_temp_0x0148_14  : 12;  //u(12, 0f)
    };
} T_CODEC_PAGE1_0x48_TYPE;

typedef union t_codec_page1_0x4c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t i2s_0_data_ch0_sel_rx     : 3;   //u( 3, 0f), start@0x4c, [ 2: 0] used
        uint32_t i2s_0_data_ch1_sel_rx     : 3;   //u( 3, 0f), start@0x4c, [ 5: 3] used
        uint32_t i2s_0_data_ch2_sel_rx     : 3;   //u( 3, 0f), start@0x4c, [ 8: 6] used
        uint32_t i2s_0_data_ch3_sel_rx     : 3;   //u( 3, 0f), start@0x4d, [11: 9] used
        uint32_t i2s_0_data_ch4_sel_rx     : 3;   //u( 3, 0f), start@0x4d, [14:12] used
        uint32_t i2s_0_data_ch5_sel_rx     : 3;   //u( 3, 0f), start@0x4d, [17:15] used
        uint32_t i2s_0_data_ch6_sel_rx     : 3;   //u( 3, 0f), start@0x4e, [20:18] used
        uint32_t i2s_0_data_ch7_sel_rx     : 3;   //u( 3, 0f), start@0x4e, [23:21] used
        uint32_t i2s_0_data_ch0_rx_disable : 1;   //u( 1, 0f), start@0x4f, [24:24] used
        uint32_t i2s_0_data_ch1_rx_disable : 1;   //u( 1, 0f), start@0x4f, [25:25] used
        uint32_t i2s_0_data_ch2_rx_disable : 1;   //u( 1, 0f), start@0x4f, [26:26] used
        uint32_t i2s_0_data_ch3_rx_disable : 1;   //u( 1, 0f), start@0x4f, [27:27] used
        uint32_t i2s_0_data_ch4_rx_disable : 1;   //u( 1, 0f), start@0x4f, [28:28] used
        uint32_t i2s_0_data_ch5_rx_disable : 1;   //u( 1, 0f), start@0x4f, [29:29] used
        uint32_t i2s_0_data_ch6_rx_disable : 1;   //u( 1, 0f), start@0x4f, [30:30] used
        uint32_t i2s_0_data_ch7_rx_disable : 1;   //u( 1, 0f), start@0x4f, [31:31] used
    };
} T_CODEC_PAGE1_0x4C_TYPE;

typedef union t_codec_page1_0x50_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t i2s_1_rst_n_reg           : 1;   //u( 1, 0f), start@0x50, [ 0: 0] used
        uint32_t i2s_1_inv_sclk            : 1;   //u( 1, 0f), start@0x50, [ 1: 1] used
        uint32_t i2s_1_self_lpbk_en        : 1;   //u( 1, 0f), start@0x50, [ 2: 2] used
        uint32_t i2s_1_same_lrc_en         : 1;   //u( 1, 0f), start@0x50, [ 3: 3] used
        uint32_t i2s_1_tdm_mode_rx         : 2;   //u( 2, 0f), start@0x50, [ 5: 4] used
        uint32_t i2s_1_data_format_sel_tx  : 2;   //u( 2, 0f), start@0x50, [ 7: 6] used
        uint32_t i2s_1_data_format_sel_rx  : 2;   //u( 2, 0f), start@0x51, [ 9: 8] used
        uint32_t i2s_1_data_len_sel_tx     : 2;   //u( 2, 0f), start@0x51, [11:10] used
        uint32_t i2s_1_data_len_sel_rx     : 2;   //u( 2, 0f), start@0x51, [13:12] used
        uint32_t i2s_1_ch_len_sel_tx       : 2;   //u( 2, 0f), start@0x51, [15:14] used
        uint32_t i2s_1_ch_len_sel_rx       : 2;   //u( 2, 0f), start@0x52, [17:16] used
        uint32_t i2s_1_data_ch_sel_tx      : 2;   //u( 2, 0f), start@0x52, [19:18] used
        uint32_t bit_temp_0x0150_14  : 12;  //u(12, 0f)
    };
} T_CODEC_PAGE1_0x50_TYPE;

typedef union t_codec_page1_0x54_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t i2s_1_data_ch0_sel_rx     : 3;   //u( 3, 0f), start@0x54, [ 2: 0] used
        uint32_t i2s_1_data_ch1_sel_rx     : 3;   //u( 3, 0f), start@0x54, [ 5: 3] used
        uint32_t i2s_1_data_ch2_sel_rx     : 3;   //u( 3, 0f), start@0x54, [ 8: 6] used
        uint32_t i2s_1_data_ch3_sel_rx     : 3;   //u( 3, 0f), start@0x55, [11: 9] used
        uint32_t i2s_1_data_ch4_sel_rx     : 3;   //u( 3, 0f), start@0x55, [14:12] used
        uint32_t i2s_1_data_ch5_sel_rx     : 3;   //u( 3, 0f), start@0x55, [17:15] used
        uint32_t i2s_1_data_ch6_sel_rx     : 3;   //u( 3, 0f), start@0x56, [20:18] used
        uint32_t i2s_1_data_ch7_sel_rx     : 3;   //u( 3, 0f), start@0x56, [23:21] used
        uint32_t i2s_1_data_ch0_rx_disable : 1;   //u( 1, 0f), start@0x57, [24:24] used
        uint32_t i2s_1_data_ch1_rx_disable : 1;   //u( 1, 0f), start@0x57, [25:25] used
        uint32_t i2s_1_data_ch2_rx_disable : 1;   //u( 1, 0f), start@0x57, [26:26] used
        uint32_t i2s_1_data_ch3_rx_disable : 1;   //u( 1, 0f), start@0x57, [27:27] used
        uint32_t i2s_1_data_ch4_rx_disable : 1;   //u( 1, 0f), start@0x57, [28:28] used
        uint32_t i2s_1_data_ch5_rx_disable : 1;   //u( 1, 0f), start@0x57, [29:29] used
        uint32_t i2s_1_data_ch6_rx_disable : 1;   //u( 1, 0f), start@0x57, [30:30] used
        uint32_t i2s_1_data_ch7_rx_disable : 1;   //u( 1, 0f), start@0x57, [31:31] used
    };
} T_CODEC_PAGE1_0x54_TYPE;

typedef union t_codec_page1_0x58_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t i2s_2_rst_n_reg           : 1;   //u( 1, 0f), start@0x58, [ 0: 0] used
        uint32_t i2s_2_inv_sclk            : 1;   //u( 1, 0f), start@0x58, [ 1: 1] used
        uint32_t i2s_2_self_lpbk_en        : 1;   //u( 1, 0f), start@0x58, [ 2: 2] used
        uint32_t i2s_2_same_lrc_en         : 1;   //u( 1, 0f), start@0x58, [ 3: 3] used
        uint32_t i2s_2_tdm_mode_rx         : 2;   //u( 2, 0f), start@0x58, [ 5: 4] used
        uint32_t i2s_2_data_format_sel_tx  : 2;   //u( 2, 0f), start@0x58, [ 7: 6] used
        uint32_t i2s_2_data_format_sel_rx  : 2;   //u( 2, 0f), start@0x59, [ 9: 8] used
        uint32_t i2s_2_data_len_sel_tx     : 2;   //u( 2, 0f), start@0x59, [11:10] used
        uint32_t i2s_2_data_len_sel_rx     : 2;   //u( 2, 0f), start@0x59, [13:12] used
        uint32_t i2s_2_ch_len_sel_tx       : 2;   //u( 2, 0f), start@0x59, [15:14] used
        uint32_t i2s_2_ch_len_sel_rx       : 2;   //u( 2, 0f), start@0x5a, [17:16] used
        uint32_t i2s_2_data_ch_sel_tx      : 2;   //u( 2, 0f), start@0x5a, [19:18] used
        uint32_t bit_temp_0x0158_14  : 12;  //u(12, 0f)
    };
} T_CODEC_PAGE1_0x58_TYPE;

typedef union t_codec_page1_0x5c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t i2s_2_data_ch0_sel_rx     : 3;   //u( 3, 0f), start@0x5c, [ 2: 0] used
        uint32_t i2s_2_data_ch1_sel_rx     : 3;   //u( 3, 0f), start@0x5c, [ 5: 3] used
        uint32_t i2s_2_data_ch2_sel_rx     : 3;   //u( 3, 0f), start@0x5c, [ 8: 6] used
        uint32_t i2s_2_data_ch3_sel_rx     : 3;   //u( 3, 0f), start@0x5d, [11: 9] used
        uint32_t i2s_2_data_ch4_sel_rx     : 3;   //u( 3, 0f), start@0x5d, [14:12] used
        uint32_t i2s_2_data_ch5_sel_rx     : 3;   //u( 3, 0f), start@0x5d, [17:15] used
        uint32_t i2s_2_data_ch6_sel_rx     : 3;   //u( 3, 0f), start@0x5e, [20:18] used
        uint32_t i2s_2_data_ch7_sel_rx     : 3;   //u( 3, 0f), start@0x5e, [23:21] used
        uint32_t i2s_2_data_ch0_rx_disable : 1;   //u( 1, 0f), start@0x5f, [24:24] used
        uint32_t i2s_2_data_ch1_rx_disable : 1;   //u( 1, 0f), start@0x5f, [25:25] used
        uint32_t i2s_2_data_ch2_rx_disable : 1;   //u( 1, 0f), start@0x5f, [26:26] used
        uint32_t i2s_2_data_ch3_rx_disable : 1;   //u( 1, 0f), start@0x5f, [27:27] used
        uint32_t i2s_2_data_ch4_rx_disable : 1;   //u( 1, 0f), start@0x5f, [28:28] used
        uint32_t i2s_2_data_ch5_rx_disable : 1;   //u( 1, 0f), start@0x5f, [29:29] used
        uint32_t i2s_2_data_ch6_rx_disable : 1;   //u( 1, 0f), start@0x5f, [30:30] used
        uint32_t i2s_2_data_ch7_rx_disable : 1;   //u( 1, 0f), start@0x5f, [31:31] used
    };
} T_CODEC_PAGE1_0x5C_TYPE;

typedef union t_codec_page1_0x60_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_i2s_src_sel         : 2;   //u( 2, 0f), start@0x60, [ 1: 0] used
        uint32_t adc_1_i2s_src_sel         : 2;   //u( 2, 0f), start@0x60, [ 3: 2] used
        uint32_t adc_2_i2s_src_sel         : 2;   //u( 2, 0f), start@0x60, [ 5: 4] used
        uint32_t adc_3_i2s_src_sel         : 2;   //u( 2, 0f), start@0x60, [ 7: 6] used
        uint32_t adc_4_i2s_src_sel         : 2;   //u( 2, 0f), start@0x61, [ 9: 8] used
        uint32_t adc_5_i2s_src_sel         : 2;   //u( 2, 0f), start@0x61, [11:10] used
        uint32_t adc_6_i2s_src_sel         : 2;   //u( 2, 0f), start@0x61, [13:12] used
        uint32_t bit_temp_0x0160_0e        : 2;   //u( 2, 0f)
        uint32_t dac_l_i2s_src_sel         : 2;   //u( 2, 0f), start@0x62, [17:16] used
        uint32_t dac_r_i2s_src_sel         : 2;   //u( 2, 0f), start@0x62, [19:18] used
        uint32_t bit_temp_0x0160_14  : 12;  //u(12, 0f)
    };
} T_CODEC_PAGE1_0x60_TYPE;

typedef union t_codec_page1_0x64_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_dmic_src_sel        : 3;   //u( 3, 0f), start@0x64, [ 2: 0] used
        uint32_t adc_0_dmic_lpf2nd_en      : 1;   //u( 1, 0f), start@0x64, [ 3: 3] used
        uint32_t adc_0_dmic_lpf1st_en      : 1;   //u( 1, 0f), start@0x64, [ 4: 4] used
        uint32_t adc_0_dmic_lpf1st_fc_sel  : 2;   //u( 2, 0f), start@0x64, [ 6: 5] used
        uint32_t adc_0_dmic_mix_mute       : 1;   //u( 1, 0f), start@0x64, [ 7: 7] used
        uint32_t adc_0_ad_src_sel          : 3;   //u( 3, 0f), start@0x65, [10: 8] used
        uint32_t adc_0_ad_lpf2nd_en        : 1;   //u( 1, 0f), start@0x65, [11:11] used
        uint32_t adc_0_ad_lpf1st_en        : 1;   //u( 1, 0f), start@0x65, [12:12] used
        uint32_t adc_0_ad_lpf1st_fc_sel    : 2;   //u( 2, 0f), start@0x65, [14:13] used
        uint32_t adc_0_ad_mix_mute         : 1;   //u( 1, 0f), start@0x65, [15:15] used
        uint32_t adc_0_ad_zdet_func        : 2;   //u( 2, 0f), start@0x66, [17:16] used
        uint32_t adc_0_ad_zdet_tout        : 2;   //u( 2, 0f), start@0x66, [19:18] used
        uint32_t adc_0_ad_mute             : 1;   //u( 1, 0f), start@0x66, [20:20] used
        uint32_t adc_0_biquad_hpf_en       : 1;   //u( 1, 0f), start@0x66, [21:21] used
        uint32_t adc_0_deci_src_sel        : 2;   //u( 2, 0f), start@0x66, [23:22] used
        uint32_t adc_0_dchpf_en            : 1;   //u( 1, 0f), start@0x67, [24:24] used
        uint32_t adc_0_dchpf_fc_sel        : 3;   //u( 3, 0f), start@0x67, [27:25] used
        uint32_t adc_0_dmic_lpf2nd_fc_sel  : 1;   //u( 1, 0f), start@0x66, [28:28] used
        uint32_t adc_0_ad_lpf2nd_fc_sel    : 1;   //u( 1, 0f), start@0x67, [29:29] used
        uint32_t bit_temp_0x0164_1E        : 2;    //u( 2, 0f)
    };
} T_CODEC_PAGE1_0x64_TYPE;

typedef union t_codec_page1_0x68_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_ad_gain             : 8;   //u( 8, 0f), start@0x68, [ 7: 0] used
        uint32_t adc_0_rsvd                : 3;   //u( 3, 0f), start@0x69, [11:9] used
        uint32_t adc_0_rptr_hold           : 4;   //u( 4, 0f), start@0x69, [15:12] used
        uint32_t adc_0_ds_rate             : 1;   //u( 1, 0f), start@0x69, [16:16] used
        uint32_t adc_0_depon_en            : 1;   //u( 1, 0f), start@0x69, [17:17] used
        uint32_t adc_0_depon_time_sel      : 2;   //u( 2, 0f), start@0x69, [18:19] used
        uint32_t adc_0_biquad_hpf_en       : 1;   //u( 1, 0f), start@0x69, [20:20] used
        uint32_t bit_temp_0x0168_15        : 11;  //u( 11, 0f)
    };
} T_CODEC_PAGE1_0x68_TYPE;

typedef union t_codec_page1_0x6c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_dmic_src_sel        : 3;   //u( 3, 0f), start@0x6c, [ 2: 0] used
        uint32_t adc_1_dmic_lpf2nd_en      : 1;   //u( 1, 0f), start@0x6c, [ 3: 3] used
        uint32_t adc_1_dmic_lpf1st_en      : 1;   //u( 1, 0f), start@0x6c, [ 4: 4] used
        uint32_t adc_1_dmic_lpf1st_fc_sel  : 2;   //u( 2, 0f), start@0x6c, [ 6: 5] used
        uint32_t adc_1_dmic_mix_mute       : 1;   //u( 1, 0f), start@0x6c, [ 7: 7] used
        uint32_t adc_1_ad_src_sel          : 3;   //u( 3, 0f), start@0x6d, [10: 8] used
        uint32_t adc_1_ad_lpf2nd_en        : 1;   //u( 1, 0f), start@0x6d, [11:11] used
        uint32_t adc_1_ad_lpf1st_en        : 1;   //u( 1, 0f), start@0x6d, [12:12] used
        uint32_t adc_1_ad_lpf1st_fc_sel    : 2;   //u( 2, 0f), start@0x6d, [14:13] used
        uint32_t adc_1_ad_mix_mute         : 1;   //u( 1, 0f), start@0x6d, [15:15] used
        uint32_t adc_1_ad_zdet_func        : 2;   //u( 2, 0f), start@0x6e, [17:16] used
        uint32_t adc_1_ad_zdet_tout        : 2;   //u( 2, 0f), start@0x6e, [19:18] used
        uint32_t adc_1_ad_mute             : 1;   //u( 1, 0f), start@0x6e, [20:20] used
        uint32_t adc_1_deci_src_sel        : 1;   //u( 1, 0f), start@0x6e, [23:21] used
        uint32_t adc_1_dchpf_en            : 1;   //u( 1, 0f), start@0x6f, [24:24] used
        uint32_t adc_1_dchpf_fc_sel        : 3;   //u( 3, 0f), start@0x6f, [27:25] used
        uint32_t adc_1_dmic_lpf2nd_fc_sel  : 1;   //u( 1, 0f), start@0x6f, [28:28] used
        uint32_t adc_1_ad_lpf2nd_fc_sel    : 1;   //u( 1, 0f), start@0x6f, [29:29] used
        uint32_t bit_temp_0x016c_1E  : 2;   //u( 2, 0f)
    };
} T_CODEC_PAGE1_0x6C_TYPE;

typedef union t_codec_page1_0x70_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_ad_gain             : 8;   //u( 8, 0f), start@0x70, [ 7: 0] used
        uint32_t adc_1_rsvd                : 3;   //u( 2, 0f), start@0x71, [11:9] used
        uint32_t adc_1_rptr_hold           : 4;   //u( 4, 0f), start@0x71, [15:12] used
        uint32_t adc_1_ds_rate             : 1;   //u( 1, 0f), start@0x72, [16:16] used
        uint32_t adc_1_depon_en            : 1;   //u( 1, 0f), start@0x72, [17:17] used
        uint32_t adc_1_depon_time_sel      : 2;   //u( 2, 0f), start@0x72, [19:18] used
        uint32_t adc_1_biquad_hpf_en       : 1;   //u( 1, 0f), start@0x72, [20:20] used
        uint32_t bit_temp_0x70_15          : 2;   //u( 11, 0f)
    };
} T_CODEC_PAGE1_0x70_TYPE;

typedef union t_codec_page1_0x74_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_dmic_src_sel        : 3;   //u( 3, 0f), start@0x74, [ 2: 0] used
        uint32_t adc_2_dmic_lpf2nd_en      : 1;   //u( 1, 0f), start@0x74, [ 3: 3] used
        uint32_t adc_2_dmic_lpf1st_en      : 1;   //u( 1, 0f), start@0x74, [ 4: 4] used
        uint32_t adc_2_dmic_lpf1st_fc_sel  : 2;   //u( 2, 0f), start@0x74, [ 6: 5] used
        uint32_t adc_2_dmic_mix_mute       : 1;   //u( 1, 0f), start@0x74, [ 7: 7] used
        uint32_t adc_2_ad_src_sel          : 3;   //u( 3, 0f), start@0x75, [10: 8] used
        uint32_t adc_2_ad_lpf2nd_en        : 1;   //u( 1, 0f), start@0x75, [11:11] used
        uint32_t adc_2_ad_lpf1st_en        : 1;   //u( 1, 0f), start@0x75, [12:12] used
        uint32_t adc_2_ad_lpf1st_fc_sel    : 2;   //u( 2, 0f), start@0x75, [14:13] used
        uint32_t adc_2_ad_mix_mute         : 1;   //u( 1, 0f), start@0x75, [15:15] used
        uint32_t adc_2_ad_zdet_func        : 2;   //u( 2, 0f), start@0x76, [17:16] used
        uint32_t adc_2_ad_zdet_tout        : 2;   //u( 2, 0f), start@0x76, [19:18] used
        uint32_t adc_2_ad_mute             : 1;   //u( 1, 0f), start@0x76, [20:20] used
        uint32_t adc_2_biquad_hpf_en       : 1;   //u( 1, 0f), start@0x76, [21:21] used
        uint32_t adc_2_deci_src_sel        : 2;   //u( 2, 0f), start@0x76, [23:22] used
        uint32_t adc_2_dchpf_en            : 1;   //u( 1, 0f), start@0x77, [24:24] used
        uint32_t adc_2_dchpf_fc_sel        : 3;   //u( 3, 0f), start@0x77, [27:25] used
        uint32_t adc_2_dmic_lpf2nd_fc_sel  : 1;   //u( 1, 0f), start@0x77, [28:28] used
        uint32_t adc_2_ad_lpf2nd_fc_sel    : 1;   //u( 1, 0f), start@0x77, [29:29] used
        uint32_t bit_temp_0x0174_1E  : 2;   //u( 2, 0f)
    };
} T_CODEC_PAGE1_0x74_TYPE;

typedef union t_codec_page1_0x78_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_ad_gain             : 8;   //u( 8, 0f), start@0x78, [ 7: 0] used
        uint32_t adc_2_rsvd                : 3;   //u( 2, 0f), start@0x79, [11:9] used
        uint32_t adc_2_rptr_hold           : 4;   //u( 4, 0f), start@0x79, [15:12] used
        uint32_t adc_2_ds_rate             : 1;   //u( 1, 0f), start@0x7a, [16:16] used
        uint32_t adc_2_depon_en            : 1;   //u( 1, 0f), start@0x7a, [17:17] used
        uint32_t adc_2_depon_time_sel      : 2;   //u( 2, 0f), start@0x7a, [19:18] used
        uint32_t adc_2_biquad_hpf_en       : 1;   //u( 1, 0f), start@0x7a, [20:20] used
        uint32_t bit_temp_0x78_15          : 2;   //u( 11, 0f)
    };
} T_CODEC_PAGE1_0x78_TYPE;

typedef union t_codec_page1_0x7c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_dmic_src_sel        : 3;   //u( 3, 0f), start@0x7c, [ 2: 0] used
        uint32_t adc_3_dmic_lpf2nd_en      : 1;   //u( 1, 0f), start@0x7c, [ 3: 3] used
        uint32_t adc_3_dmic_lpf1st_en      : 1;   //u( 1, 0f), start@0x7c, [ 4: 4] used
        uint32_t adc_3_dmic_lpf1st_fc_sel  : 2;   //u( 2, 0f), start@0x7c, [ 6: 5] used
        uint32_t adc_3_dmic_mix_mute       : 1;   //u( 1, 0f), start@0x7c, [ 7: 7] used
        uint32_t adc_3_ad_src_sel          : 3;   //u( 3, 0f), start@0x7d, [10: 8] used
        uint32_t adc_3_ad_lpf2nd_en        : 1;   //u( 1, 0f), start@0x7d, [11:11] used
        uint32_t adc_3_ad_lpf1st_en        : 1;   //u( 1, 0f), start@0x7d, [12:12] used
        uint32_t adc_3_ad_lpf1st_fc_sel    : 2;   //u( 2, 0f), start@0x7d, [14:13] used
        uint32_t adc_3_ad_mix_mute         : 1;   //u( 1, 0f), start@0x7d, [15:15] used
        uint32_t adc_3_ad_zdet_func        : 2;   //u( 2, 0f), start@0x7e, [17:16] used
        uint32_t adc_3_ad_zdet_tout        : 2;   //u( 2, 0f), start@0x7e, [19:18] used
        uint32_t adc_3_ad_mute             : 1;   //u( 1, 0f), start@0x7e, [20:20] used
        uint32_t adc_3_biquad_hpf_en       : 1;   //u( 1, 0f), start@0x7e, [21:21] used
        uint32_t adc_3_deci_src_sel        : 2;   //u( 2, 0f), start@0x7e, [23:22] used
        uint32_t adc_3_dchpf_en            : 1;   //u( 1, 0f), start@0x7f, [24:24] used
        uint32_t adc_3_dchpf_fc_sel        : 3;   //u( 3, 0f), start@0x7f, [27:25] used
        uint32_t adc_3_dmic_lpf2nd_fc_sel  : 1;   //u( 1, 0f), start@0x7f, [28:28] used
        uint32_t adc_3_ad_lpf2nd_fc_sel    : 1;   //u( 1, 0f), start@0x7f, [29:29] used
        uint32_t bit_temp_0x017C_1E  : 2;   //u( 2, 0f)
    };
} T_CODEC_PAGE1_0x7C_TYPE;

typedef union t_codec_page1_0x80_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_ad_gain             : 8;   //u( 8, 0f), start@0x80, [ 7: 0] used
        uint32_t adc_3_rsvd                : 3;   //u( 2, 0f), start@0x81, [11:9] used
        uint32_t adc_3_rptr_hold           : 4;   //u( 4, 0f), start@0x81, [15:12] used
        uint32_t adc_3_ds_rate             : 1;   //u( 1, 0f), start@0x82, [16:16] used
        uint32_t adc_3_depon_en            : 1;   //u( 1, 0f), start@0x82, [17:17] used
        uint32_t adc_3_depon_time_sel      : 2;   //u( 2, 0f), start@0x82, [19:18] used
        uint32_t adc_3_biquad_hpf_en       : 1;   //u( 1, 0f), start@0x82, [20:20] used
        uint32_t bit_temp_0x180_15          : 2;   //u( 11, 0f)
    };
} T_CODEC_PAGE1_0x80_TYPE;

typedef union t_codec_page1_0x84_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_dmic_src_sel        : 3;   //u( 3, 0f), start@0x84, [ 2: 0] used
        uint32_t adc_4_dmic_lpf2nd_en      : 1;   //u( 1, 0f), start@0x84, [ 3: 3] used
        uint32_t adc_4_dmic_lpf1st_en      : 1;   //u( 1, 0f), start@0x84, [ 4: 4] used
        uint32_t adc_4_dmic_lpf1st_fc_sel  : 2;   //u( 2, 0f), start@0x84, [ 6: 5] used
        uint32_t adc_4_dmic_mix_mute       : 1;   //u( 1, 0f), start@0x84, [ 7: 7] used
        uint32_t adc_4_ad_src_sel          : 3;   //u( 3, 0f), start@0x85, [10: 8] used
        uint32_t adc_4_ad_lpf2nd_en        : 1;   //u( 1, 0f), start@0x85, [11:11] used
        uint32_t adc_4_ad_lpf1st_en        : 1;   //u( 1, 0f), start@0x85, [12:12] used
        uint32_t adc_4_ad_lpf1st_fc_sel    : 2;   //u( 2, 0f), start@0x85, [14:13] used
        uint32_t adc_4_ad_mix_mute         : 1;   //u( 1, 0f), start@0x85, [15:15] used
        uint32_t adc_4_ad_zdet_func        : 2;   //u( 2, 0f), start@0x86, [17:16] used
        uint32_t adc_4_ad_zdet_tout        : 2;   //u( 2, 0f), start@0x86, [19:18] used
        uint32_t adc_4_ad_mute             : 1;   //u( 1, 0f), start@0x86, [20:20] used
        uint32_t adc_4_biquad_hpf_en       : 1;   //u( 1, 0f), start@0x86, [21:21] used
        uint32_t adc_4_deci_src_sel        : 2;   //u( 2, 0f), start@0x86, [23:22] used
        uint32_t adc_4_dchpf_en            : 1;   //u( 1, 0f), start@0x87, [24:24] used
        uint32_t adc_4_dchpf_fc_sel        : 3;   //u( 3, 0f), start@0x87, [27:25] used
        uint32_t adc_4_dmic_lpf2nd_fc_sel  : 1;   //u( 1, 0f), start@0x87, [28:28] used
        uint32_t adc_4_ad_lpf2nd_fc_sel    : 1;   //u( 1, 0f), start@0x87, [29:29] used
        uint32_t bit_temp_0x0184_1E  : 2;   //u( 2, 0f)
    };
} T_CODEC_PAGE1_0x84_TYPE;

typedef union t_codec_page1_0x88_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_ad_gain             : 8;   //u( 8, 0f), start@0x88, [ 7: 0] used
        uint32_t adc_4_rsvd                : 3;   //u( 2, 0f), start@0x89, [11:9] used
        uint32_t adc_4_rptr_hold           : 4;   //u( 4, 0f), start@0x89, [15:12] used
        uint32_t adc_4_ds_rate             : 1;   //u( 1, 0f), start@0x8a, [16:16] used
        uint32_t adc_4_depon_en            : 1;   //u( 1, 0f), start@0x8a, [17:17] used
        uint32_t adc_4_depon_time_sel      : 2;   //u( 2, 0f), start@0x8a, [19:18] used
        uint32_t adc_4_biquad_hpf_en       : 1;   //u( 1, 0f), start@0x8a, [20:20] used
        uint32_t bit_temp_0x188_15          : 2;   //u( 11, 0f)
    };
} T_CODEC_PAGE1_0x88_TYPE;

typedef union t_codec_page1_0x8c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_dmic_src_sel        : 3;   //u( 3, 0f), start@0x8c, [ 2: 0] used
        uint32_t adc_5_dmic_lpf2nd_en      : 1;   //u( 1, 0f), start@0x8c, [ 3: 3] used
        uint32_t adc_5_dmic_lpf1st_en      : 1;   //u( 1, 0f), start@0x8c, [ 4: 4] used
        uint32_t adc_5_dmic_lpf1st_fc_sel  : 2;   //u( 2, 0f), start@0x8c, [ 6: 5] used
        uint32_t adc_5_dmic_mix_mute       : 1;   //u( 1, 0f), start@0x8c, [ 7: 7] used
        uint32_t adc_5_ad_src_sel          : 3;   //u( 3, 0f), start@0x8d, [10: 8] used
        uint32_t adc_5_ad_lpf2nd_en        : 1;   //u( 1, 0f), start@0x8d, [11:11] used
        uint32_t adc_5_ad_lpf1st_en        : 1;   //u( 1, 0f), start@0x8d, [12:12] used
        uint32_t adc_5_ad_lpf1st_fc_sel    : 2;   //u( 2, 0f), start@0x8d, [14:13] used
        uint32_t adc_5_ad_mix_mute         : 1;   //u( 1, 0f), start@0x8d, [15:15] used
        uint32_t adc_5_ad_zdet_func        : 2;   //u( 2, 0f), start@0x8e, [17:16] used
        uint32_t adc_5_ad_zdet_tout        : 2;   //u( 2, 0f), start@0x8e, [19:18] used
        uint32_t adc_5_ad_mute             : 1;   //u( 1, 0f), start@0x8e, [20:20] used
        uint32_t adc_5_biquad_hpf_en       : 1;   //u( 1, 0f), start@0x8e, [21:21] used
        uint32_t adc_5_deci_src_sel        : 2;   //u( 2, 0f), start@0x8e, [23:22] used
        uint32_t adc_5_dchpf_en            : 1;   //u( 1, 0f), start@0x8f, [24:24] used
        uint32_t adc_5_dchpf_fc_sel        : 3;   //u( 3, 0f), start@0x8f, [27:25] used
        uint32_t adc_5_dmic_lpf2nd_fc_sel  : 1;   //u( 1, 0f), start@0x8f, [28:28] used
        uint32_t adc_5_ad_lpf2nd_fc_sel    : 1;   //u( 1, 0f), start@0x8f, [29:29] used
        uint32_t bit_temp_0x018C_1E  : 2;   //u( 2, 0f)
    };
} T_CODEC_PAGE1_0x8C_TYPE;

typedef union t_codec_page1_0x90_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_ad_gain             : 8;   //u( 8, 0f), start@0x90, [ 7: 0] used
        uint32_t adc_5_rsvd                : 3;   //u( 2, 0f), start@0x91, [11:9] used
        uint32_t adc_5_rptr_hold           : 4;   //u( 4, 0f), start@0x91, [15:12] used
        uint32_t adc_5_ds_rate             : 1;   //u( 1, 0f), start@0x92, [16:16] used
        uint32_t adc_5_depon_en            : 1;   //u( 1, 0f), start@0x92, [17:17] used
        uint32_t adc_5_depon_time_sel      : 2;   //u( 2, 0f), start@0x92, [19:18] used
        uint32_t adc_5_biquad_hpf_en       : 1;   //u( 1, 0f), start@0x92, [20:20] used
        uint32_t bit_temp_0x190_15         : 2;   //u( 11, 0f)
    };
} T_CODEC_PAGE1_0x90_TYPE;

typedef union t_codec_page1_0x94_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_da_gain             : 8;   //u( 8, 0f), start@0x94, [ 7: 0] used
        uint32_t bit_temp_0x0194_08  : 8;   //u( 8, 0f)
        uint32_t dac_l_da_src_sel          : 2;   //u( 2, 0f), start@0x96, [17:16] used
        uint32_t bit_temp_0x0194_12  : 2;   //u( 2, 0f)
        uint32_t dac_l_test_tone_en        : 1;   //u( 1, 0f), start@0x96, [20:20] used
        uint32_t dac_l_test_fc_sel         : 7;   //u( 7, 0f), start@0x96, [27:21] used
        uint32_t dac_l_test_gain_sel       : 4;   //u( 4, 0f), start@0x97, [31:28] used
    };
} T_CODEC_PAGE1_0x94_TYPE;

typedef union t_codec_page1_0x98_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_da_zdet_func        : 2;   //u( 2, 0f), start@0x98, [ 1: 0] used
        uint32_t dac_l_da_zdet_tout        : 2;   //u( 2, 0f), start@0x98, [ 3: 2] used
        uint32_t dac_l_da_mute             : 1;   //u( 1, 0f), start@0x98, [ 4: 4] used
        uint32_t dac_l_dahpf_en            : 1;   //u( 1, 0f), start@0x98, [ 5: 5] used
        uint32_t dac_l_da_dither_sel       : 2;   //u( 2, 0f), start@0x98, [ 7: 6] used
        uint32_t dac_l_dmix_mute_da        : 1;   //u( 1, 0f), start@0x99, [ 8: 8] used
        uint32_t dac_l_dmix_mute_sidetone  : 1;   //u( 1, 0f), start@0x99, [ 9: 9] used
        uint32_t dac_l_dmix_mute_dc        : 1;   //u( 1, 0f), start@0x99, [10:10] used
        uint32_t dac_l_music_mute_en       : 1;   //u( 1, 0f), start@0x99, [11:11] used
        uint32_t dac_l_anc_mute_en         : 1;   //u( 1, 0f), start@0x99, [12:12] used
        uint32_t dac_l_pdm_en              : 1;   //u( 1, 0f), start@0x99, [13:13] used
        uint32_t dac_l_sdm_extend_fb_en    : 1;   //u( 1, 0f), start@0x99, [14:14] used
        uint32_t dac_l_sdm_ef_en           : 1;   //u( 1, 0f), start@0x99, [15:15] used
        uint32_t dac_l_sdm_dither_sel      : 2;   //u( 2, 0f), start@0x9a, [17:16] used
        uint32_t dac_l_da_flt_type         : 2;   //u( 2, 0f), start@0x9a, [19:18] used
        uint32_t bit_temp_0x0198_14  : 1;   //u( 1, 0f)
        uint32_t dac_l_ob_tone_en          : 1;   //u( 1, 0f), start@0x9a, [21:21] used
        uint32_t dac_l_hpf_fc_sel          : 2;   //u( 2, 0f), start@0x9a, [23:22] used
        uint32_t bit_temp_0x0198_18  : 8;   //u( 8, 0f)
    };
} T_CODEC_PAGE1_0x98_TYPE;

typedef union t_codec_page1_0x9c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_dc_offset           : 16;  //u(16, 0f), start@0x9c, [15: 0] used
        uint32_t dac_l_ob_fc_sel           : 4;   //u( 4, 0f), start@0x9e, [19:16] used
        uint32_t dac_l_ob_gain             : 4;   //u( 4, 0f), start@0x9e, [23:20] used
        uint32_t bit_temp_0x019c_18  : 8;   //u( 8, 0f)
    };
} T_CODEC_PAGE1_0x9C_TYPE;

typedef union t_codec_page1_0xa0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_da_gain             : 8;   //u( 8, 0f), start@0xa0, [ 7: 0] used
        uint32_t bit_temp_0x01a0_08  : 8;   //u( 8, 0f)
        uint32_t dac_r_da_src_sel          : 2;   //u( 2, 0f), start@0xa2, [17:16] used
        uint32_t bit_temp_0x01a0_12  : 2;   //u( 2, 0f)
        uint32_t dac_r_test_tone_en        : 1;   //u( 1, 0f), start@0xa2, [20:20] used
        uint32_t dac_r_test_fc_sel         : 7;   //u( 7, 0f), start@0xa2, [27:21] used
        uint32_t dac_r_test_gain_sel       : 4;   //u( 4, 0f), start@0xa3, [31:28] used
    };
} T_CODEC_PAGE1_0xA0_TYPE;

typedef union t_codec_page1_0xa4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_da_zdet_func        : 2;   //u( 2, 0f), start@0xa4, [ 1: 0] used
        uint32_t dac_r_da_zdet_tout        : 2;   //u( 2, 0f), start@0xa4, [ 3: 2] used
        uint32_t dac_r_da_mute             : 1;   //u( 1, 0f), start@0xa4, [ 4: 4] used
        uint32_t dac_r_dahpf_en            : 1;   //u( 1, 0f), start@0xa4, [ 5: 5] used
        uint32_t dac_r_da_dither_sel       : 2;   //u( 2, 0f), start@0xa4, [ 7: 6] used
        uint32_t dac_r_dmix_mute_da        : 1;   //u( 1, 0f), start@0xa5, [ 8: 8] used
        uint32_t dac_r_dmix_mute_sidetone  : 1;   //u( 1, 0f), start@0xa5, [ 9: 9] used
        uint32_t dac_r_dmix_mute_dc        : 1;   //u( 1, 0f), start@0xa5, [10:10] used
        uint32_t dac_r_music_mute_en       : 1;   //u( 1, 0f), start@0xa5, [11:11] used
        uint32_t dac_r_anc_mute_en         : 1;   //u( 1, 0f), start@0xa5, [12:12] used
        uint32_t dac_r_pdm_en              : 1;   //u( 1, 0f), start@0xa5, [13:13] used
        uint32_t dac_r_sdm_extend_fb_en    : 1;   //u( 1, 0f), start@0xa5, [14:14] used
        uint32_t dac_r_sdm_ef_en           : 1;   //u( 1, 0f), start@0xa5, [15:15] used
        uint32_t dac_r_sdm_dither_sel      : 2;   //u( 2, 0f), start@0xa6, [17:16] used
        uint32_t dac_r_da_flt_type         : 2;   //u( 2, 0f), start@0xa6, [19:18] used
        uint32_t bit_temp_0x01a4_14  : 1;   //u( 1, 0f)
        uint32_t dac_r_ob_tone_en          : 1;   //u( 1, 0f), start@0xa6, [21:21] used
        uint32_t dac_r_hpf_fc_sel          : 2;   //u( 2, 0f), start@0xa6, [23:22] used
        uint32_t bit_temp_0x01a4_18  : 8;   //u( 8, 0f)
    };
} T_CODEC_PAGE1_0xA4_TYPE;

typedef union t_codec_page1_0xa8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_dc_offset           : 16;  //u(16, 0f), start@0xa8, [15: 0] used
        uint32_t dac_r_ob_fc_sel           : 4;   //u( 4, 0f), start@0xaa, [19:16] used
        uint32_t dac_r_ob_gain             : 4;   //u( 4, 0f), start@0xaa, [23:20] used
        uint32_t bit_temp_0x01a8_18  : 8;   //u( 8, 0f)
    };
} T_CODEC_PAGE1_0xA8_TYPE;

typedef union t_codec_page1_0xac_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_pdm_en                : 1;   //u( 1, 0f), start@0xac, [ 0: 0] used
        uint32_t adc_tone_en               : 1;   //u( 1, 0f), start@0xac, [ 1: 1] used
        uint32_t adc_pdm_control_rsvd      : 2;   //u( 2, 0f), start@0xac, [ 3: 2] used
        uint32_t adc_dither_sel            : 4;   //u( 4, 0f), start@0xac, [ 7: 4] used
        uint32_t adc_ob_fc_sel             : 4;   //u( 4, 0f), start@0xad, [11: 8] used
        uint32_t adc_ob_gain               : 4;   //u( 4, 0f), start@0xad, [15:12] used
        uint32_t word_temp_B01ac_1 : 8;
        uint32_t word_temp_B01ac_2 : 8;
    };
} T_CODEC_PAGE1_0xAC_TYPE;

typedef union t_codec_page1_0xb0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t sp_ad_fifo_align_en       : 1;   //u( 1, 0f), start@0xb0, [ 0: 0] used
        uint32_t sp_ad_align_mode          : 1;   //u( 1, 0f), start@0xb0, [ 1: 1] used
        uint32_t sp_ad_align_en            : 1;   //u( 1, 0f), start@0xb0, [ 2: 2] used
        uint32_t bit_temp_0x01b0_03  : 5;   //u( 5, 0f)
        uint32_t word_temp_B01b0_1 : 8;
        uint32_t word_temp_B01b0_2 : 8;
        uint32_t word_temp_B01b0_3 : 8;
    };
} T_CODEC_PAGE1_0xB0_TYPE;

typedef union t_codec_page1_0xb4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_align_ch_sel        : 3;   //u( 3, 0f), start@0xb4, [ 2: 0] used
        uint32_t adc_0_align_en            : 1;   //u( 1, 0f), start@0xb4, [ 3: 3] used
        uint32_t adc_1_align_ch_sel        : 3;   //u( 3, 0f), start@0xb4, [ 6: 4] used
        uint32_t adc_1_align_en            : 1;   //u( 1, 0f), start@0xb4, [ 7: 7] used
        uint32_t adc_2_align_ch_sel        : 3;   //u( 3, 0f), start@0xb5, [10: 8] used
        uint32_t adc_2_align_en            : 1;   //u( 1, 0f), start@0xb5, [11:11] used
        uint32_t adc_3_align_ch_sel        : 3;   //u( 3, 0f), start@0xb5, [14:12] used
        uint32_t adc_3_align_en            : 1;   //u( 1, 0f), start@0xb5, [15:15] used
        uint32_t adc_4_align_ch_sel        : 3;   //u( 3, 0f), start@0xb6, [18:16] used
        uint32_t adc_4_align_en            : 1;   //u( 1, 0f), start@0xb6, [19:19] used
        uint32_t adc_5_align_ch_sel        : 3;   //u( 3, 0f), start@0xb6, [22:20] used
        uint32_t adc_5_align_en            : 1;   //u( 1, 0f), start@0xb6, [23:23] used
        uint32_t adc_6_align_ch_sel        : 3;   //u( 3, 0f), start@0xb6, [26:24] used
        uint32_t adc_6_align_en            : 1;   //u( 1, 0f), start@0xb6, [27:27] used
        uint32_t bit_temp_0x01b4_1C        : 4;   //u( 4, 0f)
    };
} T_CODEC_PAGE1_0xB4_TYPE;

typedef union t_codec_page1_0xb8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_2_da_gain             : 8;   //u( 8, 0f), start@0xb8, [ 7: 0] used
        uint32_t bit_temp_0x01b8_08  : 8;   //u( 8, 0f)
        uint32_t dac_2_fs_src_sel          : 2;   //u( 2, 0f), start@0xba, [17:16] used
        uint32_t dac_2_i2s_src_sel         : 2;   //u( 2, 0f), start@0xba, [19:18] used
        uint32_t dac_2_asrc_en             : 1;   //u( 1, 0f), start@0xba, [20:20] used
        uint32_t bit_temp_0x01b8_15  : 11;  //u(11, 0f)
    };
} T_CODEC_PAGE1_0xB8_TYPE;

typedef union t_codec_page1_0xbc_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_2_da_zdet_func        : 2;   //u( 2, 0f), start@0xbc, [ 1: 0] used
        uint32_t dac_2_da_zdet_tout        : 2;   //u( 2, 0f), start@0xbc, [ 3: 2] used
        uint32_t dac_2_da_mute             : 1;   //u( 1, 0f), start@0xbc, [ 4: 4] used
        uint32_t dac_2_dahpf_en            : 1;   //u( 1, 0f), start@0xbc, [ 5: 5] used
        uint32_t dac_2_da_dither_sel       : 2;   //u( 2, 0f), start@0xbc, [ 7: 6] used
        uint32_t bit_temp_0x01bc_08  : 10;  //u(10, 0f)
        uint32_t dac_2_da_flt_type         : 2;   //u( 2, 0f), start@0xbe, [19:18] used
        uint32_t bit_temp_0x01bc_14  : 2;   //u( 2, 0f)
        uint32_t dac_2_hpf_fc_sel          : 2;   //u( 2, 0f), start@0xbe, [23:22] used
        uint32_t bit_temp_0x01bc_18  : 8;   //u( 8, 0f)
    };
} T_CODEC_PAGE1_0xBC_TYPE;

typedef union t_codec_page1_0xc0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t downlink_mix_control      : 4;   //u( 4, 0f), start@0xc0
        uint32_t bit_temp_0x00c0_04  : 4;
        uint32_t page_temp_0x01c0_1 : 8;
        uint32_t page_temp_0x01c0_2 : 8;
        uint32_t page_temp_0x01c0_3 : 8;
    };
} T_CODEC_PAGE1_0xC0_TYPE;

typedef union t_codec_page1_0xc4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_dmic_src_sel        : 3;   //u( 3, 0f), start@0xc4, [ 2: 0] used
        uint32_t adc_6_dmic_lpf2nd_en      : 1;   //u( 1, 0f), start@0xc4, [ 3: 3] used
        uint32_t adc_6_dmic_lpf1st_en      : 1;   //u( 1, 0f), start@0xc4, [ 4: 4] used
        uint32_t adc_6_dmic_lpf1st_fc_sel  : 2;   //u( 2, 0f), start@0xc4, [ 6: 5] used
        uint32_t adc_6_dmic_mix_mute       : 1;   //u( 1, 0f), start@0xc5, [ 7: 7] used
        uint32_t adc_6_ad_src_sel          : 3;   //u( 3, 0f), start@0xc5, [10: 8] used
        uint32_t adc_6_ad_lpf2nd_en        : 1;   //u( 1, 0f), start@0xc5, [11:11] used
        uint32_t adc_6_ad_lpf1st_en        : 1;   //u( 1, 0f), start@0xc5, [12:12] used
        uint32_t adc_6_ad_lpf1st_fc_sel    : 2;   //u( 2, 0f), start@0xc5, [14:13] used
        uint32_t adc_6_ad_mix_mute         : 1;   //u( 1, 0f), start@0xc5 [15:15] used
        uint32_t adc_6_ad_zdet_func        : 2;   //u( 2, 0f), start@0xc6, [17:16] used
        uint32_t adc_6_ad_zdet_tout        : 2;   //u( 2, 0f), start@0xc6, [19:18] used
        uint32_t adc_6_ad_mute             : 1;   //u( 1, 0f), start@0xc6, [20:20] used
        uint32_t adc_6_biquad_hpf_en       : 1;   //u( 1, 0f), start@0xc6, [21:21] used
        uint32_t adc_6_deci_src_sel        : 2;   //u( 2, 0f), start@0xc6, [23:22] used
        uint32_t adc_6_dchpf_en            : 1;   //u( 1, 0f), start@0xc7, [24:24] used
        uint32_t adc_6_dchpf_fc_sel        : 3;   //u( 3, 0f), start@0xc7, [27:25] used
        uint32_t adc_6_dmic_lpf2nd_fc_sel  : 1;   //u( 1, 0f), start@0xc7, [28:28] used
        uint32_t adc_6_ad_lpf2nd_fc_sel    : 1;   //u( 1, 0f), start@0xc7, [29:29] used
        uint32_t bit_temp_0x01C4_1E  : 2;   //u( 2, 0f)
    };
} T_CODEC_PAGE1_0xC4_TYPE;

typedef union t_codec_page1_0xc8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_ad_gain             : 8;   //u( 8, 0f), start@0xc8, [ 7: 0] used
        uint32_t adc_6_rsvd                : 3;   //u( 2, 0f), start@0xc9, [11:9] used
        uint32_t adc_6_rptr_hold           : 4;   //u( 4, 0f), start@0xca, [15:12] used
        uint32_t adc_6_ds_rate             : 1;   //u( 1, 0f), start@0xcb, [16:16] used
        uint32_t adc_6_depon_en            : 1;   //u( 1, 0f), start@0xcb, [17:17] used
        uint32_t adc_6_depon_time_sel      : 2;   //u( 2, 0f), start@0xcb, [19:18] used
        uint32_t adc_6_biquad_hpf_en       : 1;   //u( 1, 0f), start@0xcb [20:20] used
        uint32_t bit_temp_0x1C8_15         : 2;   //u( 11, 0f)
    };
} T_CODEC_PAGE1_0xC8_TYPE;

typedef union t_codec_page1_0xcc_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_asrc_en             : 1;   //u( 1, 0f), start@0xcc,  [ 0: 0] used
        uint32_t rsvd0                     : 31;  //u( 31, 0f), start@0xcc, [31:1] used

    };
} T_CODEC_PAGE1_0xCC_TYPE;
//--- end of page 0x01 ---

//=== start of page 0x02 ===
typedef union t_codec_page2_0x00_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_silence_det_en      : 1;   //u( 1, 0f), start@0x00, [ 0: 0] used
        uint32_t adc_0_silence_level_sel   : 3;   //u( 3, 0f), start@0x00, [ 3: 1] used
        uint32_t adc_0_silence_debounce_sel : 3;   //u( 3, 0f), start@0x00, [ 6: 4] used
        uint32_t bit_temp_0x0200_07  : 1;   //u( 1, 0f)
        uint32_t word_temp_B0200_1 : 8;
        uint32_t word_temp_B0200_2 : 8;
        uint32_t word_temp_B0200_3 : 8;
    };
} T_CODEC_PAGE2_0x00_TYPE;

typedef union t_codec_page2_0x04_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_silence_det_en      : 1;   //u( 1, 0f), start@0x04, [ 0: 0] used
        uint32_t adc_1_silence_level_sel   : 3;   //u( 3, 0f), start@0x04, [ 3: 1] used
        uint32_t adc_1_silence_debounce_sel : 3;   //u( 3, 0f), start@0x04, [ 6: 4] used
        uint32_t bit_temp_0x0204_07  : 1;   //u( 1, 0f)
        uint32_t word_temp_B0204_1 : 8;
        uint32_t word_temp_B0204_2 : 8;
        uint32_t word_temp_B0204_3 : 8;
    };
} T_CODEC_PAGE2_0x04_TYPE;

typedef union t_codec_page2_0x08_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_silence_det_en      : 1;   //u( 1, 0f), start@0x08, [ 0: 0] used
        uint32_t adc_2_silence_level_sel   : 3;   //u( 3, 0f), start@0x08, [ 3: 1] used
        uint32_t adc_2_silence_debounce_sel : 3;   //u( 3, 0f), start@0x08, [ 6: 4] used
        uint32_t bit_temp_0x0208_07  : 1;   //u( 1, 0f)
        uint32_t word_temp_B0208_1 : 8;
        uint32_t word_temp_B0208_2 : 8;
        uint32_t word_temp_B0208_3 : 8;
    };
} T_CODEC_PAGE2_0x08_TYPE;

typedef union t_codec_page2_0x0c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_silence_det_en      : 1;   //u( 1, 0f), start@0x0c, [ 0: 0] used
        uint32_t adc_3_silence_level_sel   : 3;   //u( 3, 0f), start@0x0c, [ 3: 1] used
        uint32_t adc_3_silence_debounce_sel : 3;   //u( 3, 0f), start@0x0c, [ 6: 4] used
        uint32_t bit_temp_0x020c_07  : 1;   //u( 1, 0f)
        uint32_t word_temp_B020c_1 : 8;
        uint32_t word_temp_B020c_2 : 8;
        uint32_t word_temp_B020c_3 : 8;
    };
} T_CODEC_PAGE2_0x0C_TYPE;

typedef union t_codec_page2_0x10_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_silence_det_en      : 1;   //u( 1, 0f), start@0x10, [ 0: 0] used
        uint32_t adc_4_silence_level_sel   : 3;   //u( 3, 0f), start@0x10, [ 3: 1] used
        uint32_t adc_4_silence_debounce_sel : 3;   //u( 3, 0f), start@0x10, [ 6: 4] used
        uint32_t bit_temp_0x0210_07  : 1;   //u( 1, 0f)
        uint32_t word_temp_B0210_1 : 8;
        uint32_t word_temp_B0210_2 : 8;
        uint32_t word_temp_B0210_3 : 8;
    };
} T_CODEC_PAGE2_0x10_TYPE;

typedef union t_codec_page2_0x14_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_silence_det_en      : 1;   //u( 1, 0f), start@0x14, [ 0: 0] used
        uint32_t adc_5_silence_level_sel   : 3;   //u( 3, 0f), start@0x14, [ 3: 1] used
        uint32_t adc_5_silence_debounce_sel : 3;   //u( 3, 0f), start@0x14, [ 6: 4] used
        uint32_t bit_temp_0x0214_07  : 1;   //u( 1, 0f)
        uint32_t word_temp_B0214_1 : 8;
        uint32_t word_temp_B0214_2 : 8;
        uint32_t word_temp_B0214_3 : 8;
    };
} T_CODEC_PAGE2_0x14_TYPE;

typedef union t_codec_page2_0x18_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_silence_det_en      : 1;   //u( 1, 0f), start@0x18, [ 0: 0] used
        uint32_t dac_l_silence_level_sel   : 3;   //u( 3, 0f), start@0x18, [ 3: 1] used
        uint32_t dac_l_silence_debounce_sel : 3;   //u( 3, 0f), start@0x18, [ 6: 4] used
        uint32_t bit_temp_0x0218_07  : 1;   //u( 1, 0f)
        uint32_t word_temp_B0218_1 : 8;
        uint32_t word_temp_B0218_2 : 8;
        uint32_t word_temp_B0218_3 : 8;
    };
} T_CODEC_PAGE2_0x18_TYPE;

typedef union t_codec_page2_0x1c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_silence_det_en      : 1;   //u( 1, 0f), start@0x1c, [ 0: 0] used
        uint32_t dac_r_silence_level_sel   : 3;   //u( 3, 0f), start@0x1c, [ 3: 1] used
        uint32_t dac_r_silence_debounce_sel : 3;   //u( 3, 0f), start@0x1c, [ 6: 4] used
        uint32_t bit_temp_0x021c_07  : 1;   //u( 1, 0f)
        uint32_t word_temp_B021c_1 : 8;
        uint32_t word_temp_B021c_2 : 8;
        uint32_t word_temp_B021c_3 : 8;
    };
} T_CODEC_PAGE2_0x1C_TYPE;

typedef union t_codec_page2_0x20_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_l_mic_src_sel          : 4;   //u( 4, 0f), start@0x20, [ 3: 0] used
        uint32_t st_l_hpf_en               : 1;   //u( 1, 0f), start@0x20, [ 4: 4] used
        uint32_t st_l_hpf_fc_sel           : 3;   //u( 3, 0f), start@0x20, [ 7: 5] used
        uint32_t st_l_vol_sel              : 8;   //u( 8, 0f), start@0x21, [15: 8] used
        uint32_t st_l_zdet_tout            : 2;   //u( 2, 0f), start@0x22, [17:16] used
        uint32_t st_l_zdet_func            : 2;   //u( 2, 0f), start@0x22, [19:18] used
        uint32_t st_l_boost_sel            : 1;   //u( 1, 0f), start@0x22, [20:20] used
        uint32_t bit_temp_0x0220_15  : 1;   //u( 1, 0f)
        uint32_t st_l_in_sel               : 2;   //u( 2, 0f), start@0x22, [23:22] used
        uint32_t bit_temp_0x0220_18  : 8;   //u( 8, 0f)
    };
} T_CODEC_PAGE2_0x20_TYPE;

typedef union t_codec_page2_0x24_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_r_mic_src_sel          : 4;   //u( 4, 0f), start@0x24, [ 3: 0] used
        uint32_t st_r_hpf_en               : 1;   //u( 1, 0f), start@0x24, [ 4: 4] used
        uint32_t st_r_hpf_fc_sel           : 3;   //u( 3, 0f), start@0x24, [ 7: 5] used
        uint32_t st_r_vol_sel              : 8;   //u( 8, 0f), start@0x25, [15: 8] used
        uint32_t st_r_zdet_tout            : 2;   //u( 2, 0f), start@0x26, [17:16] used
        uint32_t st_r_zdet_func            : 2;   //u( 2, 0f), start@0x26, [19:18] used
        uint32_t st_r_boost_sel            : 1;   //u( 1, 0f), start@0x26, [20:20] used
        uint32_t bit_temp_0x0224_15  : 1;   //u( 1, 0f)
        uint32_t st_r_in_sel               : 2;   //u( 2, 0f), start@0x26, [23:22] used
        uint32_t bit_temp_0x0224_18  : 8;   //u( 8, 0f)
    };
} T_CODEC_PAGE2_0x24_TYPE;

typedef union t_codec_page2_0x28_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_l_src_sel           : 4;   //u( 4, 0f), start@0x28, [ 3: 0] used
        uint32_t bit_temp_0x0228_04  : 4;   //u( 4, 0f)
        uint32_t st_ds_l_vol_sel           : 8;   //u( 8, 0f), start@0x29, [15: 8] used
        uint32_t st_ds_l_boost_sel         : 1;   //u( 1, 0f), start@0x2a, [16:16] used
        uint32_t st_ds_l_mute_zdet_en      : 1;   //u( 1, 0f), start@0x2a, [17:17] used
        uint32_t st_ds_l_zdet_tout         : 2;   //u( 2, 0f), start@0x2a, [19:18] used
        uint32_t st_ds_l_zdet_func         : 2;   //u( 2, 0f), start@0x2a, [21:20] used
        uint32_t st_ds_l_in_sel            : 2;   //u( 2, 0f), start@0x2a, [23:22] used
        uint32_t st_ds_l_0_mute_en         : 1;   //u( 1, 0f), start@0x2b, [24:24] used
        uint32_t st_ds_l_1_mute_en         : 1;   //u( 1, 0f), start@0x2b, [25:25] used
        uint32_t bit_temp_0x0228_1a  : 6;   //u( 6, 0f)
    };
} T_CODEC_PAGE2_0x28_TYPE;

typedef union t_codec_page2_0x2c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_r_src_sel           : 4;   //u( 4, 0f), start@0x2c, [ 3: 0] used
        uint32_t bit_temp_0x022c_04  : 4;   //u( 4, 0f)
        uint32_t st_ds_r_vol_sel           : 8;   //u( 8, 0f), start@0x2d, [15: 8] used
        uint32_t st_ds_r_boost_sel         : 1;   //u( 1, 0f), start@0x2e, [16:16] used
        uint32_t st_ds_r_mute_zdet_en      : 1;   //u( 1, 0f), start@0x2e, [17:17] used
        uint32_t st_ds_r_zdet_tout         : 2;   //u( 2, 0f), start@0x2e, [19:18] used
        uint32_t st_ds_r_zdet_func         : 2;   //u( 2, 0f), start@0x2e, [21:20] used
        uint32_t st_ds_r_in_sel            : 2;   //u( 2, 0f), start@0x2e, [23:22] used
        uint32_t st_ds_r_0_mute_en         : 1;   //u( 1, 0f), start@0x2f, [24:24] used
        uint32_t st_ds_r_1_mute_en         : 1;   //u( 1, 0f), start@0x2f, [25:25] used
        uint32_t bit_temp_0x022c_1a  : 6;   //u( 6, 0f)
    };
} T_CODEC_PAGE2_0x2C_TYPE;

typedef union t_codec_page2_0x30_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_l_biquad_en_0       : 1;   //u( 1, 0f), start@0x30, [ 0: 0] used
        uint32_t st_ds_l_biquad_en_1       : 1;   //u( 1, 0f), start@0x30, [ 1: 1] used
        uint32_t st_ds_l_biquad_en_2       : 1;   //u( 1, 0f), start@0x30, [ 2: 2] used
        uint32_t bit_temp_0x0230_03  : 5;   //u( 5, 0f)
        uint32_t word_temp_B0230_1 : 8;
        uint32_t word_temp_B0230_2 : 8;
        uint32_t word_temp_B0230_3 : 8;
    };
} T_CODEC_PAGE2_0x30_TYPE;

typedef union t_codec_page2_0x34_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_l_biquad_h0_0       : 29;  //s(29, 0f), start@0x34, [28: 0] used
        uint32_t bit_temp_0x0234_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x34_TYPE;

typedef union t_codec_page2_0x38_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_l_biquad_b1_0       : 29;  //s(29, 0f), start@0x38, [28: 0] used
        uint32_t bit_temp_0x0238_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x38_TYPE;

typedef union t_codec_page2_0x3c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_l_biquad_b2_0       : 29;  //s(29, 0f), start@0x3c, [28: 0] used
        uint32_t bit_temp_0x023c_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x3C_TYPE;

typedef union t_codec_page2_0x40_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_l_biquad_a1_0       : 29;  //s(29, 0f), start@0x40, [28: 0] used
        uint32_t bit_temp_0x0240_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x40_TYPE;

typedef union t_codec_page2_0x44_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_l_biquad_a2_0       : 29;  //s(29, 0f), start@0x44, [28: 0] used
        uint32_t bit_temp_0x0244_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x44_TYPE;

typedef union t_codec_page2_0x48_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_l_biquad_h0_1       : 29;  //s(29, 0f), start@0x48, [28: 0] used
        uint32_t bit_temp_0x0248_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x48_TYPE;

typedef union t_codec_page2_0x4c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_l_biquad_b1_1       : 29;  //s(29, 0f), start@0x4c, [28: 0] used
        uint32_t bit_temp_0x024c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x4C_TYPE;

typedef union t_codec_page2_0x50_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_l_biquad_b2_1       : 29;  //s(29, 0f), start@0x50, [28: 0] used
        uint32_t bit_temp_0x0250_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x50_TYPE;

typedef union t_codec_page2_0x54_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_l_biquad_a1_1       : 29;  //s(29, 0f), start@0x54, [28: 0] used
        uint32_t bit_temp_0x0254_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x54_TYPE;

typedef union t_codec_page2_0x58_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_l_biquad_a2_1       : 29;  //s(29, 0f), start@0x58, [28: 0] used
        uint32_t bit_temp_0x0258_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x58_TYPE;

typedef union t_codec_page2_0x5c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_l_biquad_h0_2       : 29;  //s(29, 0f), start@0x5c, [28: 0] used
        uint32_t bit_temp_0x025c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x5C_TYPE;

typedef union t_codec_page2_0x60_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_l_biquad_b1_2       : 29;  //s(29, 0f), start@0x60, [28: 0] used
        uint32_t bit_temp_0x0260_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x60_TYPE;

typedef union t_codec_page2_0x64_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_l_biquad_b2_2       : 29;  //s(29, 0f), start@0x64, [28: 0] used
        uint32_t bit_temp_0x0264_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x64_TYPE;

typedef union t_codec_page2_0x68_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_l_biquad_a1_2       : 29;  //s(29, 0f), start@0x68, [28: 0] used
        uint32_t bit_temp_0x0268_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x68_TYPE;

typedef union t_codec_page2_0x6c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_l_biquad_a2_2       : 29;  //s(29, 0f), start@0x6c, [28: 0] used
        uint32_t bit_temp_0x026c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x6C_TYPE;

typedef union t_codec_page2_0x70_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_r_biquad_en_0       : 1;   //u( 1, 0f), start@0x70, [ 0: 0] used
        uint32_t st_ds_r_biquad_en_1       : 1;   //u( 1, 0f), start@0x70, [ 1: 1] used
        uint32_t st_ds_r_biquad_en_2       : 1;   //u( 1, 0f), start@0x70, [ 2: 2] used
        uint32_t bit_temp_0x0270_03        : 5;   //u( 5, 0f)
        uint32_t word_temp_B0270_1 : 8;
        uint32_t word_temp_B0270_2 : 8;
        uint32_t word_temp_B0270_3 : 8;
    };
} T_CODEC_PAGE2_0x70_TYPE;

typedef union t_codec_page2_0x74_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_r_biquad_h0_0       : 29;  //s(29, 0f), start@0x74, [28: 0] used
        uint32_t bit_temp_0x0274_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x74_TYPE;

typedef union t_codec_page2_0x78_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_r_biquad_b1_0       : 29;  //s(29, 0f), start@0x78, [28: 0] used
        uint32_t bit_temp_0x0278_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x78_TYPE;

typedef union t_codec_page2_0x7c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_r_biquad_b2_0       : 29;  //s(29, 0f), start@0x7c, [28: 0] used
        uint32_t bit_temp_0x027c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x7C_TYPE;

typedef union t_codec_page2_0x80_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_r_biquad_a1_0       : 29;  //s(29, 0f), start@0x80, [28: 0] used
        uint32_t bit_temp_0x0280_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x80_TYPE;

typedef union t_codec_page2_0x84_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_r_biquad_a2_0       : 29;  //s(29, 0f), start@0x84, [28: 0] used
        uint32_t bit_temp_0x0284_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x84_TYPE;

typedef union t_codec_page2_0x88_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_r_biquad_h0_1       : 29;  //s(29, 0f), start@0x88, [28: 0] used
        uint32_t bit_temp_0x0288_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x88_TYPE;

typedef union t_codec_page2_0x8c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_r_biquad_b1_1       : 29;  //s(29, 0f), start@0x8c, [28: 0] used
        uint32_t bit_temp_0x028c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x8C_TYPE;

typedef union t_codec_page2_0x90_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_r_biquad_b2_1       : 29;  //s(29, 0f), start@0x90, [28: 0] used
        uint32_t bit_temp_0x0290_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x90_TYPE;

typedef union t_codec_page2_0x94_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_r_biquad_a1_1       : 29;  //s(29, 0f), start@0x94, [28: 0] used
        uint32_t bit_temp_0x0294_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x94_TYPE;

typedef union t_codec_page2_0x98_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_r_biquad_a2_1       : 29;  //s(29, 0f), start@0x98, [28: 0] used
        uint32_t bit_temp_0x0298_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x98_TYPE;

typedef union t_codec_page2_0x9c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_r_biquad_h0_2       : 29;  //s(29, 0f), start@0x9c, [28: 0] used
        uint32_t bit_temp_0x029c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0x9C_TYPE;

typedef union t_codec_page2_0xa0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_r_biquad_b1_2       : 29;  //s(29, 0f), start@0xa0, [28: 0] used
        uint32_t bit_temp_0x02a0_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0xA0_TYPE;

typedef union t_codec_page2_0xa4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_r_biquad_b2_2       : 29;  //s(29, 0f), start@0xa4, [28: 0] used
        uint32_t bit_temp_0x02a4_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0xA4_TYPE;

typedef union t_codec_page2_0xa8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_r_biquad_a1_2       : 29;  //s(29, 0f), start@0xa8, [28: 0] used
        uint32_t bit_temp_0x02a8_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0xA8_TYPE;

typedef union t_codec_page2_0xac_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t st_ds_r_biquad_a2_2       : 29;  //s(29, 0f), start@0xac, [28: 0] used
        uint32_t bit_temp_0x02ac_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE2_0xAC_TYPE;

typedef union t_codec_page2_0xb0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_silence_det_en      : 1;   //u( 1, 0f), start@0xb0, [ 0: 0] used
        uint32_t adc_6_silence_level_sel   : 3;   //u( 3, 0f), start@0xb0, [ 3: 1] used
        uint32_t adc_6_silence_debounce_sel : 3;   //u( 3, 0f), start@0xb0, [ 6: 4] used
        uint32_t bit_temp_0x02b0_07  : 1;   //u( 1, 0f)
        uint32_t word_temp_B02b0_1 : 8;
        uint32_t word_temp_B02b0_2 : 8;
        uint32_t word_temp_B02b0_3 : 8;
    };
} T_CODEC_PAGE2_0xB0_TYPE;



//--- end of page 0x02 ---

//=== start of page 0x03 ===
typedef union t_codec_page3_0x00_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_en_0         : 1;   //u( 1, 0f), start@0x00, [ 0: 0] used
        uint32_t dac_l_biquad_en_1         : 1;   //u( 1, 0f), start@0x00, [ 1: 1] used
        uint32_t dac_l_biquad_en_2         : 1;   //u( 1, 0f), start@0x00, [ 2: 2] used
        uint32_t dac_l_biquad_en_3         : 1;   //u( 1, 0f), start@0x00, [ 3: 3] used
        uint32_t dac_l_biquad_en_4         : 1;   //u( 1, 0f), start@0x00, [ 4: 4] used
        uint32_t dac_l_biquad_en_5         : 1;   //u( 1, 0f), start@0x00, [ 5: 5] used
        uint32_t dac_l_biquad_en_6         : 1;   //u( 1, 0f), start@0x00, [ 6: 6] used
        uint32_t dac_l_biquad_en_7         : 1;   //u( 1, 0f), start@0x00, [ 7: 7] used
        uint32_t dac_l_biquad_en_8         : 1;   //u( 1, 0f), start@0x01, [ 8: 8] used
        uint32_t dac_l_biquad_en_9         : 1;   //u( 1, 0f), start@0x01, [ 9: 9] used
        uint32_t bit_temp_0x0300_0a  : 6;   //u( 6, 0f)
        uint32_t word_temp_B0300_1 : 8;
        uint32_t word_temp_B0300_2 : 8;
    };
} T_CODEC_PAGE3_0x00_TYPE;

typedef union t_codec_page3_0x04_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_h0_0         : 29;  //s(29, 0f), start@0x04, [28: 0] used
        uint32_t bit_temp_0x0304_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x04_TYPE;

typedef union t_codec_page3_0x08_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b1_0         : 29;  //s(29, 0f), start@0x08, [28: 0] used
        uint32_t bit_temp_0x0308_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x08_TYPE;

typedef union t_codec_page3_0x0c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b2_0         : 29;  //s(29, 0f), start@0x0c, [28: 0] used
        uint32_t bit_temp_0x030c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x0C_TYPE;

typedef union t_codec_page3_0x10_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a1_0         : 29;  //s(29, 0f), start@0x10, [28: 0] used
        uint32_t bit_temp_0x0310_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x10_TYPE;

typedef union t_codec_page3_0x14_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a2_0         : 29;  //s(29, 0f), start@0x14, [28: 0] used
        uint32_t bit_temp_0x0314_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x14_TYPE;

typedef union t_codec_page3_0x18_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_h0_1         : 29;  //s(29, 0f), start@0x18, [28: 0] used
        uint32_t bit_temp_0x0318_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x18_TYPE;

typedef union t_codec_page3_0x1c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b1_1         : 29;  //s(29, 0f), start@0x1c, [28: 0] used
        uint32_t bit_temp_0x031c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x1C_TYPE;

typedef union t_codec_page3_0x20_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b2_1         : 29;  //s(29, 0f), start@0x20, [28: 0] used
        uint32_t bit_temp_0x0320_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x20_TYPE;

typedef union t_codec_page3_0x24_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a1_1         : 29;  //s(29, 0f), start@0x24, [28: 0] used
        uint32_t bit_temp_0x0324_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x24_TYPE;

typedef union t_codec_page3_0x28_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a2_1         : 29;  //s(29, 0f), start@0x28, [28: 0] used
        uint32_t bit_temp_0x0328_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x28_TYPE;

typedef union t_codec_page3_0x2c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_h0_2         : 29;  //s(29, 0f), start@0x2c, [28: 0] used
        uint32_t bit_temp_0x032c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x2C_TYPE;

typedef union t_codec_page3_0x30_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b1_2         : 29;  //s(29, 0f), start@0x30, [28: 0] used
        uint32_t bit_temp_0x0330_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x30_TYPE;

typedef union t_codec_page3_0x34_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b2_2         : 29;  //s(29, 0f), start@0x34, [28: 0] used
        uint32_t bit_temp_0x0334_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x34_TYPE;

typedef union t_codec_page3_0x38_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a1_2         : 29;  //s(29, 0f), start@0x38, [28: 0] used
        uint32_t bit_temp_0x0338_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x38_TYPE;

typedef union t_codec_page3_0x3c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a2_2         : 29;  //s(29, 0f), start@0x3c, [28: 0] used
        uint32_t bit_temp_0x033c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x3C_TYPE;

typedef union t_codec_page3_0x40_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_h0_3         : 29;  //s(29, 0f), start@0x40, [28: 0] used
        uint32_t bit_temp_0x0340_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x40_TYPE;

typedef union t_codec_page3_0x44_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b1_3         : 29;  //s(29, 0f), start@0x44, [28: 0] used
        uint32_t bit_temp_0x0344_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x44_TYPE;

typedef union t_codec_page3_0x48_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b2_3         : 29;  //s(29, 0f), start@0x48, [28: 0] used
        uint32_t bit_temp_0x0348_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x48_TYPE;

typedef union t_codec_page3_0x4c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a1_3         : 29;  //s(29, 0f), start@0x4c, [28: 0] used
        uint32_t bit_temp_0x034c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x4C_TYPE;

typedef union t_codec_page3_0x50_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a2_3         : 29;  //s(29, 0f), start@0x50, [28: 0] used
        uint32_t bit_temp_0x0350_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x50_TYPE;

typedef union t_codec_page3_0x54_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_h0_4         : 29;  //s(29, 0f), start@0x54, [28: 0] used
        uint32_t bit_temp_0x0354_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x54_TYPE;

typedef union t_codec_page3_0x58_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b1_4         : 29;  //s(29, 0f), start@0x58, [28: 0] used
        uint32_t bit_temp_0x0358_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x58_TYPE;

typedef union t_codec_page3_0x5c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b2_4         : 29;  //s(29, 0f), start@0x5c, [28: 0] used
        uint32_t bit_temp_0x035c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x5C_TYPE;

typedef union t_codec_page3_0x60_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a1_4         : 29;  //s(29, 0f), start@0x60, [28: 0] used
        uint32_t bit_temp_0x0360_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x60_TYPE;

typedef union t_codec_page3_0x64_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a2_4         : 29;  //s(29, 0f), start@0x64, [28: 0] used
        uint32_t bit_temp_0x0364_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x64_TYPE;

typedef union t_codec_page3_0x68_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_h0_5         : 29;  //s(29, 0f), start@0x68, [28: 0] used
        uint32_t bit_temp_0x0368_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x68_TYPE;

typedef union t_codec_page3_0x6c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b1_5         : 29;  //s(29, 0f), start@0x6c, [28: 0] used
        uint32_t bit_temp_0x036c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x6C_TYPE;

typedef union t_codec_page3_0x70_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b2_5         : 29;  //s(29, 0f), start@0x70, [28: 0] used
        uint32_t bit_temp_0x0370_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x70_TYPE;

typedef union t_codec_page3_0x74_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a1_5         : 29;  //s(29, 0f), start@0x74, [28: 0] used
        uint32_t bit_temp_0x0374_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x74_TYPE;

typedef union t_codec_page3_0x78_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a2_5         : 29;  //s(29, 0f), start@0x78, [28: 0] used
        uint32_t bit_temp_0x0378_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x78_TYPE;

typedef union t_codec_page3_0x7c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_h0_6         : 29;  //s(29, 0f), start@0x7c, [28: 0] used
        uint32_t bit_temp_0x037c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x7C_TYPE;

typedef union t_codec_page3_0x80_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b1_6         : 29;  //s(29, 0f), start@0x80, [28: 0] used
        uint32_t bit_temp_0x0380_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x80_TYPE;

typedef union t_codec_page3_0x84_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b2_6         : 29;  //s(29, 0f), start@0x84, [28: 0] used
        uint32_t bit_temp_0x0384_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x84_TYPE;

typedef union t_codec_page3_0x88_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a1_6         : 29;  //s(29, 0f), start@0x88, [28: 0] used
        uint32_t bit_temp_0x0388_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x88_TYPE;

typedef union t_codec_page3_0x8c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a2_6         : 29;  //s(29, 0f), start@0x8c, [28: 0] used
        uint32_t bit_temp_0x038c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x8C_TYPE;

typedef union t_codec_page3_0x90_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_h0_7         : 29;  //s(29, 0f), start@0x90, [28: 0] used
        uint32_t bit_temp_0x0390_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x90_TYPE;

typedef union t_codec_page3_0x94_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b1_7         : 29;  //s(29, 0f), start@0x94, [28: 0] used
        uint32_t bit_temp_0x0394_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x94_TYPE;

typedef union t_codec_page3_0x98_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b2_7         : 29;  //s(29, 0f), start@0x98, [28: 0] used
        uint32_t bit_temp_0x0398_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x98_TYPE;

typedef union t_codec_page3_0x9c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a1_7         : 29;  //s(29, 0f), start@0x9c, [28: 0] used
        uint32_t bit_temp_0x039c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0x9C_TYPE;

typedef union t_codec_page3_0xa0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a2_7         : 29;  //s(29, 0f), start@0xa0, [28: 0] used
        uint32_t bit_temp_0x03a0_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0xA0_TYPE;

typedef union t_codec_page3_0xa4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_h0_8         : 29;  //s(29, 0f), start@0xa4, [28: 0] used
        uint32_t bit_temp_0x03a4_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0xA4_TYPE;

typedef union t_codec_page3_0xa8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b1_8         : 29;  //s(29, 0f), start@0xa8, [28: 0] used
        uint32_t bit_temp_0x03a8_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0xA8_TYPE;

typedef union t_codec_page3_0xac_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b2_8         : 29;  //s(29, 0f), start@0xac, [28: 0] used
        uint32_t bit_temp_0x03ac_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0xAC_TYPE;

typedef union t_codec_page3_0xb0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a1_8         : 29;  //s(29, 0f), start@0xb0, [28: 0] used
        uint32_t bit_temp_0x03b0_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0xB0_TYPE;

typedef union t_codec_page3_0xb4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a2_8         : 29;  //s(29, 0f), start@0xb4, [28: 0] used
        uint32_t bit_temp_0x03b4_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0xB4_TYPE;

typedef union t_codec_page3_0xb8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_h0_9         : 29;  //s(29, 0f), start@0xb8, [28: 0] used
        uint32_t bit_temp_0x03b8_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0xB8_TYPE;

typedef union t_codec_page3_0xbc_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b1_9         : 29;  //s(29, 0f), start@0xbc, [28: 0] used
        uint32_t bit_temp_0x03bc_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0xBC_TYPE;

typedef union t_codec_page3_0xc0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_b2_9         : 29;  //s(29, 0f), start@0xc0, [28: 0] used
        uint32_t bit_temp_0x03c0_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0xC0_TYPE;

typedef union t_codec_page3_0xc4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a1_9         : 29;  //s(29, 0f), start@0xc4, [28: 0] used
        uint32_t bit_temp_0x03c4_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0xC4_TYPE;

typedef union t_codec_page3_0xc8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_l_biquad_a2_9         : 29;  //s(29, 0f), start@0xc8, [28: 0] used
        uint32_t bit_temp_0x03c8_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE3_0xC8_TYPE;

//--- end of page 0x03 ---

//=== start of page 0x04 ===
typedef union t_codec_page4_0x00_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_en_0         : 1;   //u( 1, 0f), start@0x00, [ 0: 0] used
        uint32_t dac_r_biquad_en_1         : 1;   //u( 1, 0f), start@0x00, [ 1: 1] used
        uint32_t dac_r_biquad_en_2         : 1;   //u( 1, 0f), start@0x00, [ 2: 2] used
        uint32_t dac_r_biquad_en_3         : 1;   //u( 1, 0f), start@0x00, [ 3: 3] used
        uint32_t dac_r_biquad_en_4         : 1;   //u( 1, 0f), start@0x00, [ 4: 4] used
        uint32_t dac_r_biquad_en_5         : 1;   //u( 1, 0f), start@0x00, [ 5: 5] used
        uint32_t dac_r_biquad_en_6         : 1;   //u( 1, 0f), start@0x00, [ 6: 6] used
        uint32_t dac_r_biquad_en_7         : 1;   //u( 1, 0f), start@0x00, [ 7: 7] used
        uint32_t dac_r_biquad_en_8         : 1;   //u( 1, 0f), start@0x01, [ 8: 8] used
        uint32_t dac_r_biquad_en_9         : 1;   //u( 1, 0f), start@0x01, [ 9: 9] used
        uint32_t bit_temp_0x0400_0a  : 6;   //u( 6, 0f)
        uint32_t word_temp_B0400_1 : 8;
        uint32_t word_temp_B0400_2 : 8;
    };
} T_CODEC_PAGE4_0x00_TYPE;

typedef union t_codec_page4_0x04_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_h0_0         : 29;  //s(29, 0f), start@0x04, [28: 0] used
        uint32_t bit_temp_0x0404_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x04_TYPE;

typedef union t_codec_page4_0x08_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b1_0         : 29;  //s(29, 0f), start@0x08, [28: 0] used
        uint32_t bit_temp_0x0408_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x08_TYPE;

typedef union t_codec_page4_0x0c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b2_0         : 29;  //s(29, 0f), start@0x0c, [28: 0] used
        uint32_t bit_temp_0x040c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x0C_TYPE;

typedef union t_codec_page4_0x10_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a1_0         : 29;  //s(29, 0f), start@0x10, [28: 0] used
        uint32_t bit_temp_0x0410_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x10_TYPE;

typedef union t_codec_page4_0x14_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a2_0         : 29;  //s(29, 0f), start@0x14, [28: 0] used
        uint32_t bit_temp_0x0414_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x14_TYPE;

typedef union t_codec_page4_0x18_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_h0_1         : 29;  //s(29, 0f), start@0x18, [28: 0] used
        uint32_t bit_temp_0x0418_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x18_TYPE;

typedef union t_codec_page4_0x1c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b1_1         : 29;  //s(29, 0f), start@0x1c, [28: 0] used
        uint32_t bit_temp_0x041c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x1C_TYPE;

typedef union t_codec_page4_0x20_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b2_1         : 29;  //s(29, 0f), start@0x20, [28: 0] used
        uint32_t bit_temp_0x0420_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x20_TYPE;

typedef union t_codec_page4_0x24_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a1_1         : 29;  //s(29, 0f), start@0x24, [28: 0] used
        uint32_t bit_temp_0x0424_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x24_TYPE;

typedef union t_codec_page4_0x28_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a2_1         : 29;  //s(29, 0f), start@0x28, [28: 0] used
        uint32_t bit_temp_0x0428_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x28_TYPE;

typedef union t_codec_page4_0x2c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_h0_2         : 29;  //s(29, 0f), start@0x2c, [28: 0] used
        uint32_t bit_temp_0x042c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x2C_TYPE;

typedef union t_codec_page4_0x30_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b1_2         : 29;  //s(29, 0f), start@0x30, [28: 0] used
        uint32_t bit_temp_0x0430_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x30_TYPE;

typedef union t_codec_page4_0x34_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b2_2         : 29;  //s(29, 0f), start@0x34, [28: 0] used
        uint32_t bit_temp_0x0434_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x34_TYPE;

typedef union t_codec_page4_0x38_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a1_2         : 29;  //s(29, 0f), start@0x38, [28: 0] used
        uint32_t bit_temp_0x0438_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x38_TYPE;

typedef union t_codec_page4_0x3c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a2_2         : 29;  //s(29, 0f), start@0x3c, [28: 0] used
        uint32_t bit_temp_0x043c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x3C_TYPE;

typedef union t_codec_page4_0x40_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_h0_3         : 29;  //s(29, 0f), start@0x40, [28: 0] used
        uint32_t bit_temp_0x0440_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x40_TYPE;

typedef union t_codec_page4_0x44_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b1_3         : 29;  //s(29, 0f), start@0x44, [28: 0] used
        uint32_t bit_temp_0x0444_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x44_TYPE;

typedef union t_codec_page4_0x48_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b2_3         : 29;  //s(29, 0f), start@0x48, [28: 0] used
        uint32_t bit_temp_0x0448_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x48_TYPE;

typedef union t_codec_page4_0x4c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a1_3         : 29;  //s(29, 0f), start@0x4c, [28: 0] used
        uint32_t bit_temp_0x044c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x4C_TYPE;

typedef union t_codec_page4_0x50_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a2_3         : 29;  //s(29, 0f), start@0x50, [28: 0] used
        uint32_t bit_temp_0x0450_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x50_TYPE;

typedef union t_codec_page4_0x54_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_h0_4         : 29;  //s(29, 0f), start@0x54, [28: 0] used
        uint32_t bit_temp_0x0454_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x54_TYPE;

typedef union t_codec_page4_0x58_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b1_4         : 29;  //s(29, 0f), start@0x58, [28: 0] used
        uint32_t bit_temp_0x0458_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x58_TYPE;

typedef union t_codec_page4_0x5c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b2_4         : 29;  //s(29, 0f), start@0x5c, [28: 0] used
        uint32_t bit_temp_0x045c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x5C_TYPE;

typedef union t_codec_page4_0x60_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a1_4         : 29;  //s(29, 0f), start@0x60, [28: 0] used
        uint32_t bit_temp_0x0460_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x60_TYPE;

typedef union t_codec_page4_0x64_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a2_4         : 29;  //s(29, 0f), start@0x64, [28: 0] used
        uint32_t bit_temp_0x0464_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x64_TYPE;

typedef union t_codec_page4_0x68_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_h0_5         : 29;  //s(29, 0f), start@0x68, [28: 0] used
        uint32_t bit_temp_0x0468_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x68_TYPE;

typedef union t_codec_page4_0x6c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b1_5         : 29;  //s(29, 0f), start@0x6c, [28: 0] used
        uint32_t bit_temp_0x046c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x6C_TYPE;

typedef union t_codec_page4_0x70_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b2_5         : 29;  //s(29, 0f), start@0x70, [28: 0] used
        uint32_t bit_temp_0x0470_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x70_TYPE;

typedef union t_codec_page4_0x74_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a1_5         : 29;  //s(29, 0f), start@0x74, [28: 0] used
        uint32_t bit_temp_0x0474_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x74_TYPE;

typedef union t_codec_page4_0x78_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a2_5         : 29;  //s(29, 0f), start@0x78, [28: 0] used
        uint32_t bit_temp_0x0478_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x78_TYPE;

typedef union t_codec_page4_0x7c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_h0_6         : 29;  //s(29, 0f), start@0x7c, [28: 0] used
        uint32_t bit_temp_0x047c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x7C_TYPE;

typedef union t_codec_page4_0x80_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b1_6         : 29;  //s(29, 0f), start@0x80, [28: 0] used
        uint32_t bit_temp_0x0480_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x80_TYPE;

typedef union t_codec_page4_0x84_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b2_6         : 29;  //s(29, 0f), start@0x84, [28: 0] used
        uint32_t bit_temp_0x0484_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x84_TYPE;

typedef union t_codec_page4_0x88_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a1_6         : 29;  //s(29, 0f), start@0x88, [28: 0] used
        uint32_t bit_temp_0x0488_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x88_TYPE;

typedef union t_codec_page4_0x8c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a2_6         : 29;  //s(29, 0f), start@0x8c, [28: 0] used
        uint32_t bit_temp_0x048c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x8C_TYPE;

typedef union t_codec_page4_0x90_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_h0_7         : 29;  //s(29, 0f), start@0x90, [28: 0] used
        uint32_t bit_temp_0x0490_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x90_TYPE;

typedef union t_codec_page4_0x94_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b1_7         : 29;  //s(29, 0f), start@0x94, [28: 0] used
        uint32_t bit_temp_0x0494_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x94_TYPE;

typedef union t_codec_page4_0x98_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b2_7         : 29;  //s(29, 0f), start@0x98, [28: 0] used
        uint32_t bit_temp_0x0498_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x98_TYPE;

typedef union t_codec_page4_0x9c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a1_7         : 29;  //s(29, 0f), start@0x9c, [28: 0] used
        uint32_t bit_temp_0x049c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0x9C_TYPE;

typedef union t_codec_page4_0xa0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a2_7         : 29;  //s(29, 0f), start@0xa0, [28: 0] used
        uint32_t bit_temp_0x04a0_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0xA0_TYPE;

typedef union t_codec_page4_0xa4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_h0_8         : 29;  //s(29, 0f), start@0xa4, [28: 0] used
        uint32_t bit_temp_0x04a4_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0xA4_TYPE;

typedef union t_codec_page4_0xa8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b1_8         : 29;  //s(29, 0f), start@0xa8, [28: 0] used
        uint32_t bit_temp_0x04a8_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0xA8_TYPE;

typedef union t_codec_page4_0xac_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b2_8         : 29;  //s(29, 0f), start@0xac, [28: 0] used
        uint32_t bit_temp_0x04ac_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0xAC_TYPE;

typedef union t_codec_page4_0xb0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a1_8         : 29;  //s(29, 0f), start@0xb0, [28: 0] used
        uint32_t bit_temp_0x04b0_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0xB0_TYPE;

typedef union t_codec_page4_0xb4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a2_8         : 29;  //s(29, 0f), start@0xb4, [28: 0] used
        uint32_t bit_temp_0x04b4_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0xB4_TYPE;

typedef union t_codec_page4_0xb8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_h0_9         : 29;  //s(29, 0f), start@0xb8, [28: 0] used
        uint32_t bit_temp_0x04b8_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0xB8_TYPE;

typedef union t_codec_page4_0xbc_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b1_9         : 29;  //s(29, 0f), start@0xbc, [28: 0] used
        uint32_t bit_temp_0x04bc_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0xBC_TYPE;

typedef union t_codec_page4_0xc0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_b2_9         : 29;  //s(29, 0f), start@0xc0, [28: 0] used
        uint32_t bit_temp_0x04c0_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0xC0_TYPE;

typedef union t_codec_page4_0xc4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a1_9         : 29;  //s(29, 0f), start@0xc4, [28: 0] used
        uint32_t bit_temp_0x04c4_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0xC4_TYPE;

typedef union t_codec_page4_0xc8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t dac_r_biquad_a2_9         : 29;  //s(29, 0f), start@0xc8, [28: 0] used
        uint32_t bit_temp_0x04c8_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE4_0xC8_TYPE;

//--- end of page 0x04 ---

//=== start of page 0x05 ===
typedef union t_codec_page5_0x00_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_en_0         : 1;   //u( 1, 0f), start@0x00, [ 0: 0] used
        uint32_t adc_0_biquad_en_1         : 1;   //u( 1, 0f), start@0x00, [ 1: 1] used
        uint32_t adc_0_biquad_en_2         : 1;   //u( 1, 0f), start@0x00, [ 2: 2] used
        uint32_t adc_0_biquad_en_3         : 1;   //u( 1, 0f), start@0x00, [ 3: 3] used
        uint32_t adc_0_biquad_en_4         : 1;   //u( 1, 0f), start@0x00, [ 4: 4] used
        uint32_t bit_temp_0x0500_05  : 3;   //u( 3, 0f)
        uint32_t word_temp_B0500_1 : 8;
        uint32_t word_temp_B0500_2 : 8;
        uint32_t word_temp_B0500_3 : 8;
    };
} T_CODEC_PAGE5_0x00_TYPE;

typedef union t_codec_page5_0x04_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_h0_0         : 29;  //s(29, 0f), start@0x04, [28: 0] used
        uint32_t bit_temp_0x0504_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x04_TYPE;

typedef union t_codec_page5_0x08_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_b1_0         : 29;  //s(29, 0f), start@0x08, [28: 0] used
        uint32_t bit_temp_0x0508_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x08_TYPE;

typedef union t_codec_page5_0x0c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_b2_0         : 29;  //s(29, 0f), start@0x0c, [28: 0] used
        uint32_t bit_temp_0x050c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x0C_TYPE;

typedef union t_codec_page5_0x10_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_a1_0         : 29;  //s(29, 0f), start@0x10, [28: 0] used
        uint32_t bit_temp_0x0510_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x10_TYPE;

typedef union t_codec_page5_0x14_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_a2_0         : 29;  //s(29, 0f), start@0x14, [28: 0] used
        uint32_t bit_temp_0x0514_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x14_TYPE;

typedef union t_codec_page5_0x18_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_h0_1         : 29;  //s(29, 0f), start@0x18, [28: 0] used
        uint32_t bit_temp_0x0518_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x18_TYPE;

typedef union t_codec_page5_0x1c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_b1_1         : 29;  //s(29, 0f), start@0x1c, [28: 0] used
        uint32_t bit_temp_0x051c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x1C_TYPE;

typedef union t_codec_page5_0x20_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_b2_1         : 29;  //s(29, 0f), start@0x20, [28: 0] used
        uint32_t bit_temp_0x0520_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x20_TYPE;

typedef union t_codec_page5_0x24_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_a1_1         : 29;  //s(29, 0f), start@0x24, [28: 0] used
        uint32_t bit_temp_0x0524_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x24_TYPE;

typedef union t_codec_page5_0x28_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_a2_1         : 29;  //s(29, 0f), start@0x28, [28: 0] used
        uint32_t bit_temp_0x0528_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x28_TYPE;

typedef union t_codec_page5_0x2c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_h0_2         : 29;  //s(29, 0f), start@0x2c, [28: 0] used
        uint32_t bit_temp_0x052c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x2C_TYPE;

typedef union t_codec_page5_0x30_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_b1_2         : 29;  //s(29, 0f), start@0x30, [28: 0] used
        uint32_t bit_temp_0x0530_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x30_TYPE;

typedef union t_codec_page5_0x34_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_b2_2         : 29;  //s(29, 0f), start@0x34, [28: 0] used
        uint32_t bit_temp_0x0534_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x34_TYPE;

typedef union t_codec_page5_0x38_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_a1_2         : 29;  //s(29, 0f), start@0x38, [28: 0] used
        uint32_t bit_temp_0x0538_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x38_TYPE;

typedef union t_codec_page5_0x3c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_a2_2         : 29;  //s(29, 0f), start@0x3c, [28: 0] used
        uint32_t bit_temp_0x053c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x3C_TYPE;

typedef union t_codec_page5_0x40_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_h0_3         : 29;  //s(29, 0f), start@0x40, [28: 0] used
        uint32_t bit_temp_0x0540_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x40_TYPE;

typedef union t_codec_page5_0x44_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_b1_3         : 29;  //s(29, 0f), start@0x44, [28: 0] used
        uint32_t bit_temp_0x0544_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x44_TYPE;

typedef union t_codec_page5_0x48_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_b2_3         : 29;  //s(29, 0f), start@0x48, [28: 0] used
        uint32_t bit_temp_0x0548_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x48_TYPE;

typedef union t_codec_page5_0x4c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_a1_3         : 29;  //s(29, 0f), start@0x4c, [28: 0] used
        uint32_t bit_temp_0x054c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x4C_TYPE;

typedef union t_codec_page5_0x50_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_a2_3         : 29;  //s(29, 0f), start@0x50, [28: 0] used
        uint32_t bit_temp_0x0550_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x50_TYPE;

typedef union t_codec_page5_0x54_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_h0_4         : 29;  //s(29, 0f), start@0x54, [28: 0] used
        uint32_t bit_temp_0x0554_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x54_TYPE;

typedef union t_codec_page5_0x58_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_b1_4         : 29;  //s(29, 0f), start@0x58, [28: 0] used
        uint32_t bit_temp_0x0558_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x58_TYPE;

typedef union t_codec_page5_0x5c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_b2_4         : 29;  //s(29, 0f), start@0x5c, [28: 0] used
        uint32_t bit_temp_0x055c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x5C_TYPE;

typedef union t_codec_page5_0x60_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_a1_4         : 29;  //s(29, 0f), start@0x60, [28: 0] used
        uint32_t bit_temp_0x0560_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x60_TYPE;

typedef union t_codec_page5_0x64_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_a2_4         : 29;  //s(29, 0f), start@0x64, [28: 0] used
        uint32_t bit_temp_0x0564_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x64_TYPE;

typedef union t_codec_page5_0x68_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_hpf_h0       : 29;  //s(29, 0f), start@0x68, [28: 0] used
        uint32_t bit_temp_0x0568_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x68_TYPE;

typedef union t_codec_page5_0x6c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_hpf_b1       : 29;  //s(29, 0f), start@0x6c, [28: 0] used
        uint32_t bit_temp_0x056c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x6C_TYPE;

typedef union t_codec_page5_0x70_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_hpf_b2       : 29;  //s(29, 0f), start@0x70, [28: 0] used
        uint32_t bit_temp_0x0570_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x70_TYPE;

typedef union t_codec_page5_0x74_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_hpf_a1       : 29;  //s(29, 0f), start@0x74, [28: 0] used
        uint32_t bit_temp_0x0574_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x74_TYPE;

typedef union t_codec_page5_0x78_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_biquad_hpf_a2       : 29;  //s(29, 0f), start@0x78, [28: 0] used
        uint32_t bit_temp_0x0578_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x78_TYPE;

typedef union t_codec_page5_0x7c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_en_0         : 1;   //u( 1, 0f), start@0x7c, [ 0: 0] used
        uint32_t adc_1_biquad_en_1         : 1;   //u( 1, 0f), start@0x7c, [ 1: 1] used
        uint32_t adc_1_biquad_en_2         : 1;   //u( 1, 0f), start@0x7c, [ 2: 2] used
        uint32_t adc_1_biquad_en_3         : 1;   //u( 1, 0f), start@0x7c, [ 3: 3] used
        uint32_t adc_1_biquad_en_4         : 1;   //u( 1, 0f), start@0x7c, [ 4: 4] used
        uint32_t bit_temp_0x057c_05  : 3;   //u( 3, 0f)
        uint32_t word_temp_B057c_1 : 8;
        uint32_t word_temp_B057c_2 : 8;
        uint32_t word_temp_B057c_3 : 8;
    };
} T_CODEC_PAGE5_0x7C_TYPE;

typedef union t_codec_page5_0x80_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_h0_0         : 29;  //s(29, 0f), start@0x80, [28: 0] used
        uint32_t bit_temp_0x0580_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x80_TYPE;

typedef union t_codec_page5_0x84_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_b1_0         : 29;  //s(29, 0f), start@0x84, [28: 0] used
        uint32_t bit_temp_0x0584_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x84_TYPE;

typedef union t_codec_page5_0x88_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_b2_0         : 29;  //s(29, 0f), start@0x88, [28: 0] used
        uint32_t bit_temp_0x0588_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x88_TYPE;

typedef union t_codec_page5_0x8c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_a1_0         : 29;  //s(29, 0f), start@0x8c, [28: 0] used
        uint32_t bit_temp_0x058c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x8C_TYPE;

typedef union t_codec_page5_0x90_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_a2_0         : 29;  //s(29, 0f), start@0x90, [28: 0] used
        uint32_t bit_temp_0x0590_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x90_TYPE;

typedef union t_codec_page5_0x94_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_h0_1         : 29;  //s(29, 0f), start@0x94, [28: 0] used
        uint32_t bit_temp_0x0594_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x94_TYPE;

typedef union t_codec_page5_0x98_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_b1_1         : 29;  //s(29, 0f), start@0x98, [28: 0] used
        uint32_t bit_temp_0x0598_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x98_TYPE;

typedef union t_codec_page5_0x9c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_b2_1         : 29;  //s(29, 0f), start@0x9c, [28: 0] used
        uint32_t bit_temp_0x059c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0x9C_TYPE;

typedef union t_codec_page5_0xa0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_a1_1         : 29;  //s(29, 0f), start@0xa0, [28: 0] used
        uint32_t bit_temp_0x05a0_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xA0_TYPE;

typedef union t_codec_page5_0xa4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_a2_1         : 29;  //s(29, 0f), start@0xa4, [28: 0] used
        uint32_t bit_temp_0x05a4_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xA4_TYPE;

typedef union t_codec_page5_0xa8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_h0_2         : 29;  //s(29, 0f), start@0xa8, [28: 0] used
        uint32_t bit_temp_0x05a8_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xA8_TYPE;

typedef union t_codec_page5_0xac_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_b1_2         : 29;  //s(29, 0f), start@0xac, [28: 0] used
        uint32_t bit_temp_0x05ac_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xAC_TYPE;

typedef union t_codec_page5_0xb0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_b2_2         : 29;  //s(29, 0f), start@0xb0, [28: 0] used
        uint32_t bit_temp_0x05b0_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xB0_TYPE;

typedef union t_codec_page5_0xb4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_a1_2         : 29;  //s(29, 0f), start@0xb4, [28: 0] used
        uint32_t bit_temp_0x05b4_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xB4_TYPE;

typedef union t_codec_page5_0xb8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_a2_2         : 29;  //s(29, 0f), start@0xb8, [28: 0] used
        uint32_t bit_temp_0x05b8_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xB8_TYPE;

typedef union t_codec_page5_0xbc_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_h0_3         : 29;  //s(29, 0f), start@0xbc, [28: 0] used
        uint32_t bit_temp_0x05bc_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xBC_TYPE;

typedef union t_codec_page5_0xc0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_b1_3         : 29;  //s(29, 0f), start@0xc0, [28: 0] used
        uint32_t bit_temp_0x05c0_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xC0_TYPE;

typedef union t_codec_page5_0xc4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_b2_3         : 29;  //s(29, 0f), start@0xc4, [28: 0] used
        uint32_t bit_temp_0x05c4_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xC4_TYPE;

typedef union t_codec_page5_0xc8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_a1_3         : 29;  //s(29, 0f), start@0xc8, [28: 0] used
        uint32_t bit_temp_0x05c8_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xC8_TYPE;

typedef union t_codec_page5_0xcc_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_a2_3         : 29;  //s(29, 0f), start@0xcc, [28: 0] used
        uint32_t bit_temp_0x05cc_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xCC_TYPE;

typedef union t_codec_page5_0xd0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_h0_4         : 29;  //s(29, 0f), start@0xd0, [28: 0] used
        uint32_t bit_temp_0x05d0_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xD0_TYPE;

typedef union t_codec_page5_0xd4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_b1_4         : 29;  //s(29, 0f), start@0xd4, [28: 0] used
        uint32_t bit_temp_0x05d4_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xD4_TYPE;

typedef union t_codec_page5_0xd8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_b2_4         : 29;  //s(29, 0f), start@0xd8, [28: 0] used
        uint32_t bit_temp_0x05d8_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xD8_TYPE;

typedef union t_codec_page5_0xdc_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_a1_4         : 29;  //s(29, 0f), start@0xdc, [28: 0] used
        uint32_t bit_temp_0x05dc_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xDC_TYPE;

typedef union t_codec_page5_0xe0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_a2_4         : 29;  //s(29, 0f), start@0xe0, [28: 0] used
        uint32_t bit_temp_0x05e0_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xE0_TYPE;

typedef union t_codec_page5_0xe4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_hpf_h0       : 29;  //s(29, 0f), start@0xe4, [28: 0] used
        uint32_t bit_temp_0x05e4_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xE4_TYPE;

typedef union t_codec_page5_0xe8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_hpf_b1       : 29;  //s(29, 0f), start@0xe8, [28: 0] used
        uint32_t bit_temp_0x05e8_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xE8_TYPE;

typedef union t_codec_page5_0xec_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_hpf_b2       : 29;  //s(29, 0f), start@0xec, [28: 0] used
        uint32_t bit_temp_0x05ec_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xEC_TYPE;

typedef union t_codec_page5_0xf0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_hpf_a1       : 29;  //s(29, 0f), start@0xf0, [28: 0] used
        uint32_t bit_temp_0x05f0_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xF0_TYPE;

typedef union t_codec_page5_0xf4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_biquad_hpf_a2       : 29;  //s(29, 0f), start@0xf4, [28: 0] used
        uint32_t bit_temp_0x05f4_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE5_0xF4_TYPE;

//--- end of page 0x05 ---

//=== start of page 0x06 ===
typedef union t_codec_page6_0x00_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_en_0         : 1;   //u( 1, 0f), start@0x00, [ 0: 0] used
        uint32_t adc_2_biquad_en_1         : 1;   //u( 1, 0f), start@0x00, [ 1: 1] used
        uint32_t adc_2_biquad_en_2         : 1;   //u( 1, 0f), start@0x00, [ 2: 2] used
        uint32_t adc_2_biquad_en_3         : 1;   //u( 1, 0f), start@0x00, [ 3: 3] used
        uint32_t adc_2_biquad_en_4         : 1;   //u( 1, 0f), start@0x00, [ 4: 4] used
        uint32_t bit_temp_0x0600_05  : 3;   //u( 3, 0f)
        uint32_t word_temp_B0600_1 : 8;
        uint32_t word_temp_B0600_2 : 8;
        uint32_t word_temp_B0600_3 : 8;
    };
} T_CODEC_PAGE6_0x00_TYPE;

typedef union t_codec_page6_0x04_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_h0_0         : 29;  //s(29, 0f), start@0x04, [28: 0] used
        uint32_t bit_temp_0x0604_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x04_TYPE;

typedef union t_codec_page6_0x08_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_b1_0         : 29;  //s(29, 0f), start@0x08, [28: 0] used
        uint32_t bit_temp_0x0608_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x08_TYPE;

typedef union t_codec_page6_0x0c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_b2_0         : 29;  //s(29, 0f), start@0x0c, [28: 0] used
        uint32_t bit_temp_0x060c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x0C_TYPE;

typedef union t_codec_page6_0x10_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_a1_0         : 29;  //s(29, 0f), start@0x10, [28: 0] used
        uint32_t bit_temp_0x0610_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x10_TYPE;

typedef union t_codec_page6_0x14_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_a2_0         : 29;  //s(29, 0f), start@0x14, [28: 0] used
        uint32_t bit_temp_0x0614_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x14_TYPE;

typedef union t_codec_page6_0x18_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_h0_1         : 29;  //s(29, 0f), start@0x18, [28: 0] used
        uint32_t bit_temp_0x0618_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x18_TYPE;

typedef union t_codec_page6_0x1c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_b1_1         : 29;  //s(29, 0f), start@0x1c, [28: 0] used
        uint32_t bit_temp_0x061c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x1C_TYPE;

typedef union t_codec_page6_0x20_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_b2_1         : 29;  //s(29, 0f), start@0x20, [28: 0] used
        uint32_t bit_temp_0x0620_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x20_TYPE;

typedef union t_codec_page6_0x24_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_a1_1         : 29;  //s(29, 0f), start@0x24, [28: 0] used
        uint32_t bit_temp_0x0624_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x24_TYPE;

typedef union t_codec_page6_0x28_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_a2_1         : 29;  //s(29, 0f), start@0x28, [28: 0] used
        uint32_t bit_temp_0x0628_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x28_TYPE;

typedef union t_codec_page6_0x2c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_h0_2         : 29;  //s(29, 0f), start@0x2c, [28: 0] used
        uint32_t bit_temp_0x062c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x2C_TYPE;

typedef union t_codec_page6_0x30_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_b1_2         : 29;  //s(29, 0f), start@0x30, [28: 0] used
        uint32_t bit_temp_0x0630_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x30_TYPE;

typedef union t_codec_page6_0x34_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_b2_2         : 29;  //s(29, 0f), start@0x34, [28: 0] used
        uint32_t bit_temp_0x0634_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x34_TYPE;

typedef union t_codec_page6_0x38_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_a1_2         : 29;  //s(29, 0f), start@0x38, [28: 0] used
        uint32_t bit_temp_0x0638_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x38_TYPE;

typedef union t_codec_page6_0x3c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_a2_2         : 29;  //s(29, 0f), start@0x3c, [28: 0] used
        uint32_t bit_temp_0x063c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x3C_TYPE;

typedef union t_codec_page6_0x40_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_h0_3         : 29;  //s(29, 0f), start@0x40, [28: 0] used
        uint32_t bit_temp_0x0640_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x40_TYPE;

typedef union t_codec_page6_0x44_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_b1_3         : 29;  //s(29, 0f), start@0x44, [28: 0] used
        uint32_t bit_temp_0x0644_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x44_TYPE;

typedef union t_codec_page6_0x48_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_b2_3         : 29;  //s(29, 0f), start@0x48, [28: 0] used
        uint32_t bit_temp_0x0648_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x48_TYPE;

typedef union t_codec_page6_0x4c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_a1_3         : 29;  //s(29, 0f), start@0x4c, [28: 0] used
        uint32_t bit_temp_0x064c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x4C_TYPE;

typedef union t_codec_page6_0x50_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_a2_3         : 29;  //s(29, 0f), start@0x50, [28: 0] used
        uint32_t bit_temp_0x0650_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x50_TYPE;

typedef union t_codec_page6_0x54_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_h0_4         : 29;  //s(29, 0f), start@0x54, [28: 0] used
        uint32_t bit_temp_0x0654_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x54_TYPE;

typedef union t_codec_page6_0x58_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_b1_4         : 29;  //s(29, 0f), start@0x58, [28: 0] used
        uint32_t bit_temp_0x0658_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x58_TYPE;

typedef union t_codec_page6_0x5c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_b2_4         : 29;  //s(29, 0f), start@0x5c, [28: 0] used
        uint32_t bit_temp_0x065c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x5C_TYPE;

typedef union t_codec_page6_0x60_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_a1_4         : 29;  //s(29, 0f), start@0x60, [28: 0] used
        uint32_t bit_temp_0x0660_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x60_TYPE;

typedef union t_codec_page6_0x64_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_a2_4         : 29;  //s(29, 0f), start@0x64, [28: 0] used
        uint32_t bit_temp_0x0664_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x64_TYPE;

typedef union t_codec_page6_0x68_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_hpf_h0       : 29;  //s(29, 0f), start@0x68, [28: 0] used
        uint32_t bit_temp_0x0668_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x68_TYPE;

typedef union t_codec_page6_0x6c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_hpf_b1       : 29;  //s(29, 0f), start@0x6c, [28: 0] used
        uint32_t bit_temp_0x066c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x6C_TYPE;

typedef union t_codec_page6_0x70_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_hpf_b2       : 29;  //s(29, 0f), start@0x70, [28: 0] used
        uint32_t bit_temp_0x0670_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x70_TYPE;

typedef union t_codec_page6_0x74_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_hpf_a1       : 29;  //s(29, 0f), start@0x74, [28: 0] used
        uint32_t bit_temp_0x0674_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x74_TYPE;

typedef union t_codec_page6_0x78_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_2_biquad_hpf_a2       : 29;  //s(29, 0f), start@0x78, [28: 0] used
        uint32_t bit_temp_0x0678_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x78_TYPE;

typedef union t_codec_page6_0x7c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_en_0         : 1;   //u( 1, 0f), start@0x7c, [ 0: 0] used
        uint32_t adc_3_biquad_en_1         : 1;   //u( 1, 0f), start@0x7c, [ 1: 1] used
        uint32_t adc_3_biquad_en_2         : 1;   //u( 1, 0f), start@0x7c, [ 2: 2] used
        uint32_t adc_3_biquad_en_3         : 1;   //u( 1, 0f), start@0x7c, [ 3: 3] used
        uint32_t adc_3_biquad_en_4         : 1;   //u( 1, 0f), start@0x7c, [ 4: 4] used
        uint32_t bit_temp_0x067c_05  : 3;   //u( 3, 0f)
        uint32_t word_temp_B067c_1 : 8;
        uint32_t word_temp_B067c_2 : 8;
        uint32_t word_temp_B067c_3 : 8;
    };
} T_CODEC_PAGE6_0x7C_TYPE;

typedef union t_codec_page6_0x80_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_h0_0         : 29;  //s(29, 0f), start@0x80, [28: 0] used
        uint32_t bit_temp_0x0680_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x80_TYPE;

typedef union t_codec_page6_0x84_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_b1_0         : 29;  //s(29, 0f), start@0x84, [28: 0] used
        uint32_t bit_temp_0x0684_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x84_TYPE;

typedef union t_codec_page6_0x88_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_b2_0         : 29;  //s(29, 0f), start@0x88, [28: 0] used
        uint32_t bit_temp_0x0688_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x88_TYPE;

typedef union t_codec_page6_0x8c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_a1_0         : 29;  //s(29, 0f), start@0x8c, [28: 0] used
        uint32_t bit_temp_0x068c_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x8C_TYPE;

typedef union t_codec_page6_0x90_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_a2_0         : 29;  //s(29, 0f), start@0x90, [28: 0] used
        uint32_t bit_temp_0x0690_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x90_TYPE;

typedef union t_codec_page6_0x94_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_h0_1         : 29;  //s(29, 0f), start@0x94, [28: 0] used
        uint32_t bit_temp_0x0694_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x94_TYPE;

typedef union t_codec_page6_0x98_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_b1_1         : 29;  //s(29, 0f), start@0x98, [28: 0] used
        uint32_t bit_temp_0x0698_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x98_TYPE;

typedef union t_codec_page6_0x9c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_b2_1         : 29;  //s(29, 0f), start@0x9c, [28: 0] used
        uint32_t bit_temp_0x069c_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0x9C_TYPE;

typedef union t_codec_page6_0xa0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_a1_1         : 29;  //s(29, 0f), start@0xa0, [28: 0] used
        uint32_t bit_temp_0x06a0_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xA0_TYPE;

typedef union t_codec_page6_0xa4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_a2_1         : 29;  //s(29, 0f), start@0xa4, [28: 0] used
        uint32_t bit_temp_0x06a4_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xA4_TYPE;

typedef union t_codec_page6_0xa8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_h0_2         : 29;  //s(29, 0f), start@0xa8, [28: 0] used
        uint32_t bit_temp_0x06a8_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xA8_TYPE;

typedef union t_codec_page6_0xac_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_b1_2         : 29;  //s(29, 0f), start@0xac, [28: 0] used
        uint32_t bit_temp_0x06ac_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xAC_TYPE;

typedef union t_codec_page6_0xb0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_b2_2         : 29;  //s(29, 0f), start@0xb0, [28: 0] used
        uint32_t bit_temp_0x06b0_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xB0_TYPE;

typedef union t_codec_page6_0xb4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_a1_2         : 29;  //s(29, 0f), start@0xb4, [28: 0] used
        uint32_t bit_temp_0x06b4_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xB4_TYPE;

typedef union t_codec_page6_0xb8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_a2_2         : 29;  //s(29, 0f), start@0xb8, [28: 0] used
        uint32_t bit_temp_0x06b8_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xB8_TYPE;

typedef union t_codec_page6_0xbc_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_h0_3         : 29;  //s(29, 0f), start@0xbc, [28: 0] used
        uint32_t bit_temp_0x06bc_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xBC_TYPE;

typedef union t_codec_page6_0xc0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_b1_3         : 29;  //s(29, 0f), start@0xc0, [28: 0] used
        uint32_t bit_temp_0x06c0_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xC0_TYPE;

typedef union t_codec_page6_0xc4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_b2_3         : 29;  //s(29, 0f), start@0xc4, [28: 0] used
        uint32_t bit_temp_0x06c4_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xC4_TYPE;

typedef union t_codec_page6_0xc8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_a1_3         : 29;  //s(29, 0f), start@0xc8, [28: 0] used
        uint32_t bit_temp_0x06c8_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xC8_TYPE;

typedef union t_codec_page6_0xcc_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_a2_3         : 29;  //s(29, 0f), start@0xcc, [28: 0] used
        uint32_t bit_temp_0x06cc_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xCC_TYPE;

typedef union t_codec_page6_0xd0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_h0_4         : 29;  //s(29, 0f), start@0xd0, [28: 0] used
        uint32_t bit_temp_0x06d0_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xD0_TYPE;

typedef union t_codec_page6_0xd4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_b1_4         : 29;  //s(29, 0f), start@0xd4, [28: 0] used
        uint32_t bit_temp_0x06d4_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xD4_TYPE;

typedef union t_codec_page6_0xd8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_b2_4         : 29;  //s(29, 0f), start@0xd8, [28: 0] used
        uint32_t bit_temp_0x06d8_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xD8_TYPE;

typedef union t_codec_page6_0xdc_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_a1_4         : 29;  //s(29, 0f), start@0xdc, [28: 0] used
        uint32_t bit_temp_0x06dc_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xDC_TYPE;

typedef union t_codec_page6_0xe0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_a2_4         : 29;  //s(29, 0f), start@0xe0, [28: 0] used
        uint32_t bit_temp_0x06e0_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xE0_TYPE;

typedef union t_codec_page6_0xe4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_hpf_h0       : 29;  //s(29, 0f), start@0xe4, [28: 0] used
        uint32_t bit_temp_0x06e4_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xE4_TYPE;

typedef union t_codec_page6_0xe8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_hpf_b1       : 29;  //s(29, 0f), start@0xe8, [28: 0] used
        uint32_t bit_temp_0x06e8_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xE8_TYPE;

typedef union t_codec_page6_0xec_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_hpf_b2       : 29;  //s(29, 0f), start@0xec, [28: 0] used
        uint32_t bit_temp_0x06ec_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xEC_TYPE;

typedef union t_codec_page6_0xf0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_hpf_a1       : 29;  //s(29, 0f), start@0xf0, [28: 0] used
        uint32_t bit_temp_0x06f0_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xF0_TYPE;

typedef union t_codec_page6_0xf4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_3_biquad_hpf_a2       : 29;  //s(29, 0f), start@0xf4, [28: 0] used
        uint32_t bit_temp_0x06f4_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE6_0xF4_TYPE;

//--- end of page 0x06 ---

//=== start of page 0x07 ===

typedef union t_codec_page7_0x00_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_en_0         : 1;   //u( 1, 0f), start@0x00, [ 0: 0] used
        uint32_t adc_4_biquad_en_1         : 1;   //u( 1, 0f), start@0x00, [ 1: 1] used
        uint32_t adc_4_biquad_en_2         : 1;   //u( 1, 0f), start@0x00, [ 2: 2] used
        uint32_t adc_4_biquad_en_3         : 1;   //u( 1, 0f), start@0x00, [ 3: 3] used
        uint32_t adc_4_biquad_en_4         : 1;   //u( 1, 0f), start@0x00, [ 4: 4] used
        uint32_t bit_temp_0x067c_05  : 3;   //u( 3, 0f)
        uint32_t word_temp_B067c_1 : 8;
        uint32_t word_temp_B067c_2 : 8;
        uint32_t word_temp_B067c_3 : 8;
    };
} T_CODEC_PAGE7_0x00_TYPE;


typedef union t_codec_page7_0x04_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_h0_0       : 29;  //s(29, 0f), start@0x04, [28: 0] used
        uint32_t bit_temp_0x0704_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x04_TYPE;

typedef union t_codec_page7_0x08_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_b1_0       : 29;  //s(29, 0f), start@0x08, [28: 0] used
        uint32_t bit_temp_0x0708_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x08_TYPE;

typedef union t_codec_page7_0x0c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_b2_0       : 29;  //s(29, 0f), start@0x0c, [28: 0] used
        uint32_t bit_temp_0x070c_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x0C_TYPE;

typedef union t_codec_page7_0x10_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_a1_0       : 29;  //s(29, 0f), start@0x10, [28: 0] used
        uint32_t bit_temp_0x0710_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x10_TYPE;

typedef union t_codec_page7_0x14_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_a2_0       : 29;  //s(29, 0f), start@0x14, [28: 0] used
        uint32_t bit_temp_0x0714_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x14_TYPE;

typedef union t_codec_page7_0x18_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_h0_1       : 29;  //s(29, 0f), start@0x18, [28: 0] used
        uint32_t bit_temp_0x0718_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x18_TYPE;

typedef union t_codec_page7_0x1c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_b1_1       : 29;  //s(29, 0f), start@0x1c, [28: 0] used
        uint32_t bit_temp_0x071c_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x1C_TYPE;

typedef union t_codec_page7_0x20_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_b2_1       : 29;  //s(29, 0f), start@0x20, [28: 0] used
        uint32_t bit_temp_0x0720_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x20_TYPE;

typedef union t_codec_page7_0x24_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_a1_1       : 29;  //s(29, 0f), start@0x24, [28: 0] used
        uint32_t bit_temp_0x0724_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x24_TYPE;

typedef union t_codec_page7_0x28_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_a2_1       : 29;  //s(29, 0f), start@0x28, [28: 0] used
        uint32_t bit_temp_0x0728_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x28_TYPE;

typedef union t_codec_page7_0x2c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_h0_2       : 29;  //s(29, 0f), start@0x2c, [28: 0] used
        uint32_t bit_temp_0x072c_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x2C_TYPE;

typedef union t_codec_page7_0x30_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_b1_2       : 29;  //s(29, 0f), start@0x30, [28: 0] used
        uint32_t bit_temp_0x0730_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x30_TYPE;

typedef union t_codec_page7_0x34_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_b2_2       : 29;  //s(29, 0f), start@0x34, [28: 0] used
        uint32_t bit_temp_0x0734_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x34_TYPE;

typedef union t_codec_page7_0x38_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_a1_2       : 29;  //s(29, 0f), start@0x38, [28: 0] used
        uint32_t bit_temp_0x0738_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x38_TYPE;

typedef union t_codec_page7_0x3c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_a2_2       : 29;  //s(29, 0f), start@0x3c, [28: 0] used
        uint32_t bit_temp_0x073c_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x3C_TYPE;

typedef union t_codec_page7_0x40_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_h0_3       : 29;  //s(29, 0f), start@0x40, [28: 0] used
        uint32_t bit_temp_0x0740_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x40_TYPE;

typedef union t_codec_page7_0x44_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_b1_3         : 29;  //s(29, 0f), start@0x44, [28: 0] used
        uint32_t bit_temp_0x0744_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x44_TYPE;

typedef union t_codec_page7_0x48_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_b2_3         : 29;  //s(29, 0f), start@0x48, [28: 0] used
        uint32_t bit_temp_0x0748_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x48_TYPE;

typedef union t_codec_page7_0x4c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_a1_3         : 29;  //s(29, 0f), start@0x4c, [28: 0] used
        uint32_t bit_temp_0x074c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x4C_TYPE;

typedef union t_codec_page7_0x50_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_a2_3         : 29;  //s(29, 0f), start@0x50, [28: 0] used
        uint32_t bit_temp_0x0750_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x50_TYPE;

typedef union t_codec_page7_0x54_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_h0_4         : 29;  //s(29, 0f), start@0x54, [28: 0] used
        uint32_t bit_temp_0x0754_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x54_TYPE;

typedef union t_codec_page7_0x58_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_b1_4         : 29;  //s(29, 0f), start@0x58, [28: 0] used
        uint32_t bit_temp_0x0758_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x58_TYPE;

typedef union t_codec_page7_0x5c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_b2_4         : 29;  //s(29, 0f), start@0x5c, [28: 0] used
        uint32_t bit_temp_0x075c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x5C_TYPE;

typedef union t_codec_page7_0x60_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_a1_4         : 29;  //s(29, 0f), start@0x60, [28: 0] used
        uint32_t bit_temp_0x0760_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x60_TYPE;

typedef union t_codec_page7_0x64_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_a2_4         : 29;  //s(29, 0f), start@0x64, [28: 0] used
        uint32_t bit_temp_0x0764_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x64_TYPE;

typedef union t_codec_page7_0x68_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_h0       : 29;  //s(29, 0f), start@0x68, [28: 0] used
        uint32_t bit_temp_0x0768_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x68_TYPE;

typedef union t_codec_page7_0x6c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_b1       : 29;  //s(29, 0f), start@0x6c, [28: 0] used
        uint32_t bit_temp_0x076c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x6C_TYPE;

typedef union t_codec_page7_0x70_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_b2       : 29;  //s(29, 0f), start@0x70, [28: 0] used
        uint32_t bit_temp_0x0770_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x70_TYPE;

typedef union t_codec_page7_0x74_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_a1       : 29;  //s(29, 0f), start@0x74, [28: 0] used
        uint32_t bit_temp_0x0774_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x74_TYPE;

typedef union t_codec_page7_0x78_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_a2       : 29;  //s(29, 0f), start@0x78, [28: 0] used
        uint32_t bit_temp_0x0778_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x78_TYPE;

typedef union t_codec_page7_0x7c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_en_0         : 1;   //u( 1, 0f), start@0x7c, [ 0: 0] used
        uint32_t adc_5_biquad_en_1         : 1;   //u( 1, 0f), start@0x7c, [ 1: 1] used
        uint32_t adc_5_biquad_en_2         : 1;   //u( 1, 0f), start@0x7c, [ 2: 2] used
        uint32_t adc_5_biquad_en_3         : 1;   //u( 1, 0f), start@0x7c, [ 3: 3] used
        uint32_t adc_5_biquad_en_4         : 1;   //u( 1, 0f), start@0x7c, [ 4: 4] used
        uint32_t bit_temp_0x077c_05  : 3;   //u( 3, 0f)
        uint32_t word_temp_B077c_1 : 8;
        uint32_t word_temp_B077c_2 : 8;
        uint32_t word_temp_B077c_3 : 8;
    };
} T_CODEC_PAGE7_0x7C_TYPE;

typedef union t_codec_page7_0x80_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_h0_0         : 29;  //s(29, 0f), start@0x80, [28: 0] used
        uint32_t bit_temp_0x0780_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x80_TYPE;

typedef union t_codec_page7_0x84_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_b1_0         : 29;  //s(29, 0f), start@0x84, [28: 0] used
        uint32_t bit_temp_0x0784_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x84_TYPE;

typedef union t_codec_page7_0x88_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_b2_0         : 29;  //s(29, 0f), start@0x88, [28: 0] used
        uint32_t bit_temp_0x0788_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x88_TYPE;

typedef union t_codec_page7_0x8c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_a1_0         : 29;  //s(29, 0f), start@0x8c, [28: 0] used
        uint32_t bit_temp_0x078c_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x8C_TYPE;

typedef union t_codec_page7_0x90_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_a2_0         : 29;  //s(29, 0f), start@0x90, [28: 0] used
        uint32_t bit_temp_0x0790_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x90_TYPE;

typedef union t_codec_page7_0x94_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_h0_1         : 29;  //s(29, 0f), start@0x94, [28: 0] used
        uint32_t bit_temp_0x0794_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x94_TYPE;

typedef union t_codec_page7_0x98_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_b1_1         : 29;  //s(29, 0f), start@0x98, [28: 0] used
        uint32_t bit_temp_0x0798_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x98_TYPE;

typedef union t_codec_page7_0x9c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_b2_1         : 29;  //s(29, 0f), start@0x9c, [28: 0] used
        uint32_t bit_temp_0x079c_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0x9C_TYPE;

typedef union t_codec_page7_0xa0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_a1_1         : 29;  //s(29, 0f), start@0xa0, [28: 0] used
        uint32_t bit_temp_0x07a0_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xA0_TYPE;

typedef union t_codec_page7_0xa4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_a2_1         : 29;  //s(29, 0f), start@0xa4, [28: 0] used
        uint32_t bit_temp_0x07a4_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xA4_TYPE;

typedef union t_codec_page7_0xa8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_h0_2         : 29;  //s(29, 0f), start@0xa8, [28: 0] used
        uint32_t bit_temp_0x07a8_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xA8_TYPE;

typedef union t_codec_page7_0xac_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_b1_2         : 29;  //s(29, 0f), start@0xac, [28: 0] used
        uint32_t bit_temp_0x07ac_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xAC_TYPE;

typedef union t_codec_page7_0xb0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_b2_2         : 29;  //s(29, 0f), start@0xb0, [28: 0] used
        uint32_t bit_temp_0x07b0_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xB0_TYPE;

typedef union t_codec_page7_0xb4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_a1_2         : 29;  //s(29, 0f), start@0xb4, [28: 0] used
        uint32_t bit_temp_0x07b4_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xB4_TYPE;

typedef union t_codec_page7_0xb8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_a2_2         : 29;  //s(29, 0f), start@0xb8, [28: 0] used
        uint32_t bit_temp_0x07b8_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xB8_TYPE;

typedef union t_codec_page7_0xbc_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_h0_3         : 29;  //s(29, 0f), start@0xbc, [28: 0] used
        uint32_t bit_temp_0x07bc_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xBC_TYPE;

typedef union t_codec_page7_0xc0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_b1_3         : 29;  //s(29, 0f), start@0xc0, [28: 0] used
        uint32_t bit_temp_0x07c0_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xC0_TYPE;

typedef union t_codec_page7_0xc4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_b2_3         : 29;  //s(29, 0f), start@0xc4, [28: 0] used
        uint32_t bit_temp_0x07c4_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xC4_TYPE;

typedef union t_codec_page7_0xc8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_a1_3         : 29;  //s(29, 0f), start@0xc8, [28: 0] used
        uint32_t bit_temp_0x07c8_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xC8_TYPE;

typedef union t_codec_page7_0xcc_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_a2_3         : 29;  //s(29, 0f), start@0xcc, [28: 0] used
        uint32_t bit_temp_0x07cc_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xCC_TYPE;

typedef union t_codec_page7_0xd0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_h0_4         : 29;  //s(29, 0f), start@0xd0, [28: 0] used
        uint32_t bit_temp_0x07d0_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xD0_TYPE;

typedef union t_codec_page7_0xd4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_b1_4         : 29;  //s(29, 0f), start@0xd4, [28: 0] used
        uint32_t bit_temp_0x07d4_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xD4_TYPE;

typedef union t_codec_page7_0xd8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_b2_4         : 29;  //s(29, 0f), start@0xd8, [28: 0] used
        uint32_t bit_temp_0x07d8_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xD8_TYPE;

typedef union t_codec_page7_0xdc_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_a1_4         : 29;  //s(29, 0f), start@0xdc, [28: 0] used
        uint32_t bit_temp_0x07dc_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xDC_TYPE;

typedef union t_codec_page7_0xe0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_a2_4         : 29;  //s(29, 0f), start@0xe0, [28: 0] used
        uint32_t bit_temp_0x07e0_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xE0_TYPE;

typedef union t_codec_page7_0xe4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_hpf_h0       : 29;  //s(29, 0f), start@0xe4, [28: 0] used
        uint32_t bit_temp_0x07e4_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xE4_TYPE;

typedef union t_codec_page7_0xe8_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_hpf_b1       : 29;  //s(29, 0f), start@0xe8, [28: 0] used
        uint32_t bit_temp_0x07e8_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xE8_TYPE;

typedef union t_codec_page7_0xec_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_hpf_b2       : 29;  //s(29, 0f), start@0xec, [28: 0] used
        uint32_t bit_temp_0x07ec_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xEC_TYPE;

typedef union t_codec_page7_0xf0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_hpf_a1       : 29;  //s(29, 0f), start@0xf0, [28: 0] used
        uint32_t bit_temp_0x07f0_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xF0_TYPE;

typedef union t_codec_page7_0xf4_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_5_biquad_hpf_a2       : 29;  //s(29, 0f), start@0xf4, [28: 0] used
        uint32_t bit_temp_0x07f4_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE7_0xF4_TYPE;

//--- end of page 0x07 ---

//=== start of page 0x08 ===

typedef union t_codec_page8_0x00_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_en_0         : 1;   //u( 1, 0f), start@0x00, [ 0: 0] used
        uint32_t adc_6_biquad_en_1         : 1;   //u( 1, 0f), start@0x00, [ 1: 1] used
        uint32_t adc_6_biquad_en_2         : 1;   //u( 1, 0f), start@0x00, [ 2: 2] used
        uint32_t adc_6_biquad_en_3         : 1;   //u( 1, 0f), start@0x00, [ 3: 3] used
        uint32_t adc_6_biquad_en_4         : 1;   //u( 1, 0f), start@0x00, [ 4: 4] used
        uint32_t bit_temp_0x087c_05  : 3;   //u( 3, 0f)
        uint32_t word_temp_B087c_1 : 8;
        uint32_t word_temp_B087c_2 : 8;
        uint32_t word_temp_B087c_3 : 8;
    };
} T_CODEC_PAGE8_0x00_TYPE;


typedef union t_codec_page8_0x04_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_h0_0       : 29;  //s(29, 0f), start@0x04, [28: 0] used
        uint32_t bit_temp_0x0804_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x04_TYPE;

typedef union t_codec_page8_0x08_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_b1_0       : 29;  //s(29, 0f), start@0x08, [28: 0] used
        uint32_t bit_temp_0x0808_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x08_TYPE;

typedef union t_codec_page8_0x0c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_b2_0       : 29;  //s(29, 0f), start@0x0c, [28: 0] used
        uint32_t bit_temp_0x080c_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x0C_TYPE;

typedef union t_codec_page8_0x10_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_a1_0       : 29;  //s(29, 0f), start@0x10, [28: 0] used
        uint32_t bit_temp_0x0810_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x10_TYPE;

typedef union t_codec_page8_0x14_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_a2_0       : 29;  //s(29, 0f), start@0x14, [28: 0] used
        uint32_t bit_temp_0x0814_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x14_TYPE;

typedef union t_codec_page8_0x18_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_h0_1       : 29;  //s(29, 0f), start@0x18, [28: 0] used
        uint32_t bit_temp_0x0818_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x18_TYPE;

typedef union t_codec_page8_0x1c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_b1_1       : 29;  //s(29, 0f), start@0x1c, [28: 0] used
        uint32_t bit_temp_0x081c_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x1C_TYPE;

typedef union t_codec_page8_0x20_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_8_biquad_hpf_b2_1       : 29;  //s(29, 0f), start@0x20, [28: 0] used
        uint32_t bit_temp_0x0820_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x20_TYPE;

typedef union t_codec_page8_0x24_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_a1_1       : 29;  //s(29, 0f), start@0x24, [28: 0] used
        uint32_t bit_temp_0x0824_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x24_TYPE;

typedef union t_codec_page8_0x28_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_a2_1       : 29;  //s(29, 0f), start@0x28, [28: 0] used
        uint32_t bit_temp_0x0828_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x28_TYPE;

typedef union t_codec_page8_0x2c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_h0_2       : 29;  //s(29, 0f), start@0x2c, [28: 0] used
        uint32_t bit_temp_0x082c_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x2C_TYPE;

typedef union t_codec_page8_0x30_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_b1_2       : 29;  //s(29, 0f), start@0x30, [28: 0] used
        uint32_t bit_temp_0x0830_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x30_TYPE;

typedef union t_codec_page8_0x34_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_b2_2       : 29;  //s(29, 0f), start@0x34, [28: 0] used
        uint32_t bit_temp_0x0834_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x34_TYPE;

typedef union t_codec_page8_0x38_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_a1_2       : 29;  //s(29, 0f), start@0x38, [28: 0] used
        uint32_t bit_temp_0x0838_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x38_TYPE;

typedef union t_codec_page8_0x3c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_a2_2       : 29;  //s(29, 0f), start@0x3c, [28: 0] used
        uint32_t bit_temp_0x083c_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x3C_TYPE;

typedef union t_codec_page8_0x40_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_h0_3       : 29;  //s(29, 0f), start@0x40, [28: 0] used
        uint32_t bit_temp_0x0840_1d  : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x40_TYPE;

typedef union t_codec_page8_0x44_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_b1_3         : 29;  //s(29, 0f), start@0x44, [28: 0] used
        uint32_t bit_temp_0x0844_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x44_TYPE;

typedef union t_codec_page8_0x48_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_b2_3         : 29;  //s(29, 0f), start@0x48, [28: 0] used
        uint32_t bit_temp_0x0848_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x48_TYPE;

typedef union t_codec_page8_0x4c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_a1_3         : 29;  //s(29, 0f), start@0x4c, [28: 0] used
        uint32_t bit_temp_0x084c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x4C_TYPE;

typedef union t_codec_page8_0x50_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_a2_3         : 29;  //s(29, 0f), start@0x50, [28: 0] used
        uint32_t bit_temp_0x0850_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x50_TYPE;

typedef union t_codec_page8_0x54_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_h0_4         : 29;  //s(29, 0f), start@0x54, [28: 0] used
        uint32_t bit_temp_0x0854_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x54_TYPE;

typedef union t_codec_page8_0x58_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_b1_4         : 29;  //s(29, 0f), start@0x58, [28: 0] used
        uint32_t bit_temp_0x0858_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x58_TYPE;

typedef union t_codec_page8_0x5c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_b2_4         : 29;  //s(29, 0f), start@0x5c, [28: 0] used
        uint32_t bit_temp_0x085c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x5C_TYPE;

typedef union t_codec_page8_0x60_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_a1_4         : 29;  //s(29, 0f), start@0x60, [28: 0] used
        uint32_t bit_temp_0x0860_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x60_TYPE;

typedef union t_codec_page8_0x64_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_a2_4         : 29;  //s(29, 0f), start@0x64, [28: 0] used
        uint32_t bit_temp_0x0864_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x64_TYPE;

typedef union t_codec_page8_0x68_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_h0       : 29;  //s(29, 0f), start@0x68, [28: 0] used
        uint32_t bit_temp_0x0868_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x68_TYPE;

typedef union t_codec_page8_0x6c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_b1       : 29;  //s(29, 0f), start@0x6c, [28: 0] used
        uint32_t bit_temp_0x086c_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x6C_TYPE;

typedef union t_codec_page8_0x70_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_b2       : 29;  //s(29, 0f), start@0x70, [28: 0] used
        uint32_t bit_temp_0x0870_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x70_TYPE;

typedef union t_codec_page8_0x74_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_6_biquad_hpf_a1       : 29;  //s(29, 0f), start@0x74, [28: 0] used
        uint32_t bit_temp_0x0874_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x74_TYPE;

typedef union t_codec_page8_0x78_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_4_biquad_hpf_a2       : 29;  //s(29, 0f), start@0x78, [28: 0] used
        uint32_t bit_temp_0x0878_1d        : 3;   //s( 3, 0f)
    };
} T_CODEC_PAGE8_0x78_TYPE;





typedef union t_codec_pagef_0x00_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t micbias_oc                : 1;   //u( 1, 0f), start@0x00, [ 0: 0] used
        uint32_t rsvd0                     : 31;  //u( 31, 0f), start@0x00, [ 31: 1] used
    };
} T_CODEC_PAGEF_0x00_TYPE;

typedef union t_codec_pagef_0x04_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_0_lpf_out_rd          : 19;   //u( 19, 0f), start@0x04, [ 4: 0] used
        uint32_t rsvd0                    : 13;
    };
} T_CODEC_PAGEF_0x04_TYPE;

typedef union t_codec_pagef_0x08_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_1_lpf_out_rd          : 19;   //u( 19, 0f), start@0x08, [ 4: 0] used
        uint32_t rsvd0                    : 13;
    };
} T_CODEC_PAGEF_0x08_TYPE;

typedef union t_codec_pagef_0x0c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t  adc_2_lpf_out_rd          : 19;   //u( 19, 0f), start@0x0c, [ 4: 0] used
        uint32_t rsvd0                    : 13;
    };
} T_CODEC_PAGEF_0x0C_TYPE;

typedef union t_codec_pagef_0x10_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t  adc_3_lpf_out_rd          : 19;   //u( 19, 0f), start@0x10, [ 4: 0] used
        uint32_t rsvd0                    : 13;
    };
} T_CODEC_PAGEF_0x10_TYPE;

typedef union t_codec_pagef_0x14_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t  adc_4_lpf_out_rd          : 19;   //u( 19, 0f), start@0x14, [ 4: 0] used
        uint32_t rsvd0                    : 13;
    };
} T_CODEC_PAGEF_0x14_TYPE;

typedef union t_codec_pagef_0x18_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t  adc_5_lpf_out_rd          : 19;   //u( 19, 0f), start@0x18, [ 4: 0] used
        uint32_t rsvd0                      : 13;
    };
} T_CODEC_PAGEF_0x18_TYPE;

typedef union t_codec_pagef_0x1c_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t  adc_6_lpf_out_rd          : 19;   //u( 19, 0f), start@0x1c, [ 4: 0] used
        uint32_t rsvd0                    : 13;
    };
} T_CODEC_PAGEF_0x1C_TYPE;

typedef union t_codec_pagef_0x20_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t  adc_7_lpf_out_rd          : 19;   //u( 19, 0f), start@0x20, [ 18: 0] used
        uint32_t rsvd0                    : 13;
    };
} T_CODEC_PAGEF_0x20_TYPE;

typedef union t_codec_pagef_0x24_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t  dac_l_silence_det_o               : 1;   //u( 1, 0f), start@0x24, [ 0: 0] used
        uint32_t  dac_l_silence_det_status          : 1;   //u( 1, 0f), start@0x24, [ 1: 1] used
        uint32_t  dac_r_silence_det_o               : 1;   //u( 1, 0f), start@0x24, [ 2: 2] used
        uint32_t  dac_r_silence_det_status          : 1;   //u( 1, 0f), start@0x24, [ 3: 3] used
        uint32_t  dac_0_silence_det_o               : 1;   //u( 1, 0f), start@0x24, [ 4: 4] used
        uint32_t  dac_0_silence_det_status          : 1;   //u( 1, 0f), start@0x24, [ 5: 5] used
        uint32_t  dac_1_silence_det_o               : 1;   //u( 1, 0f), start@0x24, [ 6: 6] used
        uint32_t  dac_1_silence_det_status          : 1;   //u( 1, 0f), start@0x24, [ 7: 7] used
        uint32_t  dac_2_silence_det_o               : 1;   //u( 1, 0f), start@0x25, [ 8: 8] used
        uint32_t  dac_2_silence_det_status          : 1;   //u( 1, 0f), start@0x25, [ 9: 9] used
        uint32_t  dac_3_silence_det_o               : 1;   //u( 1, 0f), start@0x25, [ 10: 10] used
        uint32_t  dac_3_silence_det_status          : 1;   //u( 1, 0f), start@0x25, [ 11: 11] used
        uint32_t  dac_4_silence_det_o               : 1;   //u( 1, 0f), start@0x25, [ 12: 12] used
        uint32_t  dac_4_silence_det_status          : 1;   //u( 1, 0f), start@0x25, [ 13: 13] used
        uint32_t  dac_5_silence_det_o               : 1;   //u( 1, 0f), start@0x25, [ 14: 14] used
        uint32_t  dac_5_silence_det_status          : 1;   //u( 1, 0f), start@0x25, [ 15: 15] used
        uint32_t  dac_6_silence_det_o               : 1;   //u( 1, 0f), start@0x26, [ 16: 16] used
        uint32_t  dac_6_silence_det_status          : 1;   //u( 1, 0f), start@0x26, [ 17: 17] used
        uint32_t rsvd0                              : 14;  //u( 1, 0f), start@0x26, [ 31: 18] used
    };
} T_CODEC_PAGEF_0x24_TYPE;


#define CODEC_REG_BASE              0x40400000UL
#define CODEC_PAGE0_BASE            0x40400000UL
#define CODEC_PAGE1_BASE            0x40400100UL
#define CODEC_PAGE2_BASE            0x40400200UL
#define CODEC_PAGE3_BASE            0x40400300UL
#define CODEC_PAGE4_BASE            0x40400400UL
#define CODEC_PAGE5_BASE            0x40400500UL
#define CODEC_PAGE6_BASE            0x40400600UL
#define CODEC_PAGE7_BASE            0x40400700UL
#define CODEC_PAGE8_BASE            0x40400800UL

#define CODEC_PAGEF_BASE            0x40200500UL//0x40400f00UL

#define CODEC_PAGE0                 ((CODEC_PAGE0_TypeDef           *) CODEC_PAGE0_BASE)
#define CODEC_PAGE1                 ((CODEC_PAGE1_TypeDef           *) CODEC_PAGE1_BASE)
#define CODEC_PAGE2                 ((CODEC_PAGE2_TypeDef           *) CODEC_PAGE2_BASE)
#define CODEC_PAGE3                 ((CODEC_PAGE3_TypeDef           *) CODEC_PAGE3_BASE)
#define CODEC_PAGE4                 ((CODEC_PAGE4_TypeDef           *) CODEC_PAGE4_BASE)
#define CODEC_PAGE5                 ((CODEC_PAGE5_TypeDef           *) CODEC_PAGE5_BASE)
#define CODEC_PAGE6                 ((CODEC_PAGE6_TypeDef           *) CODEC_PAGE6_BASE)
#define CODEC_PAGE7                 ((CODEC_PAGE7_TypeDef           *) CODEC_PAGE7_BASE)
#define CODEC_PAGE8                 ((CODEC_PAGE8_TypeDef           *) CODEC_PAGE8_BASE)

#define CODEC_PAGEF                 ((CODEC_PAGEF_TypeDef           *) CODEC_PAGEF_BASE)



#define codec_reg_read32(offset)           HAL_READ32(CODEC_REG_BASE, offset)
#define codec_reg_write32(offset, value)   HAL_WRITE32(CODEC_REG_BASE, offset, value)

#define CODEC_EQ_BIQUAD_OFFSET      0x200

/* codec reg */
/*
    because CODEC register must access by word
    in order to prevent misoperating,
    we use the similar write approach as fast aon registers
*/
#define CODEC_PAGE0_00              0x000
#define CODEC_PAGE0_04              0x004
#define CODEC_PAGE0_08              0x008
#define CODEC_PAGE0_0C              0x00C

#define CODEC_PAGE0_10              0x010
#define CODEC_PAGE0_14              0x014
#define CODEC_PAGE0_18              0x018
#define CODEC_PAGE0_1C              0x01C
#define CODEC_PAGE0_20              0x020
#define CODEC_PAGE0_24              0x024
#define CODEC_PAGE0_28              0x028
#define CODEC_PAGE0_2C              0x02C
#define CODEC_PAGE0_30              0x030
#define CODEC_PAGE0_34              0x034
#define CODEC_PAGE0_38              0x038
#define CODEC_PAGE0_3C              0x03C
#define CODEC_PAGE0_40              0x040
#define CODEC_PAGE0_44              0x044
#define CODEC_PAGE0_48              0x048
#define CODEC_PAGE0_4C              0x04C
#define CODEC_PAGE0_50              0x050
#define CODEC_PAGE0_54              0x054
#define CODEC_PAGE0_58              0x058

#define CODEC_PAGE1_00              0x100
#define CODEC_PAGE1_04              0x104
#define CODEC_PAGE1_08              0x108
#define CODEC_PAGE1_0C              0x10C
#define CODEC_PAGE1_10              0x110
#define CODEC_PAGE1_14              0x114
#define CODEC_PAGE1_18              0x118
#define CODEC_PAGE1_1C              0x11C
#define CODEC_PAGE1_20              0x120
#define CODEC_PAGE1_24              0x124
#define CODEC_PAGE1_28              0x128
#define CODEC_PAGE1_2C              0x12C
#define CODEC_PAGE1_30              0x130
#define CODEC_PAGE1_34              0x134
#define CODEC_PAGE1_38              0x138
#define CODEC_PAGE1_3C              0x13C
#define CODEC_PAGE1_40              0x140
#define CODEC_PAGE1_44              0x144
#define CODEC_PAGE1_48              0x148
#define CODEC_PAGE1_4C              0x14C
#define CODEC_PAGE1_50              0x150
#define CODEC_PAGE1_54              0x154
#define CODEC_PAGE1_58              0x158
#define CODEC_PAGE1_5C              0x15C
#define CODEC_PAGE1_60              0x160
#define CODEC_PAGE1_64              0x164
#define CODEC_PAGE1_68              0x168
#define CODEC_PAGE1_6C              0x16C
#define CODEC_PAGE1_70              0x170
#define CODEC_PAGE1_74              0x174
#define CODEC_PAGE1_78              0x178
#define CODEC_PAGE1_7C              0x17C
#define CODEC_PAGE1_80              0x180
#define CODEC_PAGE1_84              0x184
#define CODEC_PAGE1_88              0x188
#define CODEC_PAGE1_8C              0x18C
#define CODEC_PAGE1_90              0x190
#define CODEC_PAGE1_94              0x194
#define CODEC_PAGE1_98              0x198
#define CODEC_PAGE1_9C              0x19C
#define CODEC_PAGE1_A0              0x1A0
#define CODEC_PAGE1_A4              0x1A4
#define CODEC_PAGE1_A8              0x1A8
#define CODEC_PAGE1_AC              0x1AC
#define CODEC_PAGE1_B0              0x1B0
#define CODEC_PAGE1_B4              0x1B4
#define CODEC_PAGE1_B8              0x1B8
#define CODEC_PAGE1_BC              0x1BC
#define CODEC_PAGE1_C0              0x1C0
#define CODEC_PAGE1_C4              0x1C4
#define CODEC_PAGE1_C8              0x1C8
#define CODEC_PAGE1_CC              0x1CC
#define CODEC_PAGE1_D0              0x1D0
#define CODEC_PAGE1_D4              0x1D4
#define CODEC_PAGE1_D8              0x1D8
#define CODEC_PAGE1_DC              0x1DC
#define CODEC_PAGE1_E8              0x1E8
#define CODEC_PAGE1_E0              0x1E0
#define CODEC_PAGE1_E4              0x1E4
#define CODEC_PAGE1_EC              0x1EC
#define CODEC_PAGE1_F0              0x1F0
#define CODEC_PAGE1_F4              0x1F4

#define CODEC_PAGE2_00              0x200
#define CODEC_PAGE2_04              0x204
#define CODEC_PAGE2_08              0x208
#define CODEC_PAGE2_0C              0x20C
#define CODEC_PAGE2_10              0x210
#define CODEC_PAGE2_14              0x214
#define CODEC_PAGE2_18              0x218
#define CODEC_PAGE2_1C              0x21C
#define CODEC_PAGE2_20              0x220
#define CODEC_PAGE2_24              0x224
#define CODEC_PAGE2_28              0x228
#define CODEC_PAGE2_2C              0x22C
#define CODEC_PAGE2_30              0x230
#define CODEC_PAGE2_34              0x234
#define CODEC_PAGE2_38              0x238
#define CODEC_PAGE2_3C              0x23C
#define CODEC_PAGE2_40              0x240
#define CODEC_PAGE2_44              0x244
#define CODEC_PAGE2_48              0x248
#define CODEC_PAGE2_4C              0x24C
#define CODEC_PAGE2_50              0x250
#define CODEC_PAGE2_54              0x254
#define CODEC_PAGE2_58              0x258
#define CODEC_PAGE2_5C              0x25C
#define CODEC_PAGE2_60              0x260
#define CODEC_PAGE2_64              0x264
#define CODEC_PAGE2_68              0x268
#define CODEC_PAGE2_6C              0x26C
#define CODEC_PAGE2_70              0x270
#define CODEC_PAGE2_74              0x274
#define CODEC_PAGE2_78              0x278
#define CODEC_PAGE2_7C              0x27C
#define CODEC_PAGE2_80              0x280
#define CODEC_PAGE2_84              0x284
#define CODEC_PAGE2_88              0x288
#define CODEC_PAGE2_8C              0x28C
#define CODEC_PAGE2_90              0x290
#define CODEC_PAGE2_94              0x294
#define CODEC_PAGE2_98              0x298
#define CODEC_PAGE2_9C              0x29C
#define CODEC_PAGE2_A0              0x2A0
#define CODEC_PAGE2_A4              0x2A4
#define CODEC_PAGE2_A8              0x2A8
#define CODEC_PAGE2_AC              0x2AC
#define CODEC_PAGE2_B0              0x2B0

#define CODEC_PAGE3_00              0x300
#define CODEC_PAGE3_04              0x304
#define CODEC_PAGE3_08              0x308
#define CODEC_PAGE3_0C              0x30C
#define CODEC_PAGE3_10              0x310
#define CODEC_PAGE3_14              0x314
#define CODEC_PAGE3_18              0x318
#define CODEC_PAGE3_1C              0x31C
#define CODEC_PAGE3_20              0x320
#define CODEC_PAGE3_24              0x324
#define CODEC_PAGE3_28              0x328
#define CODEC_PAGE3_2C              0x32C
#define CODEC_PAGE3_30              0x330
#define CODEC_PAGE3_34              0x334
#define CODEC_PAGE3_38              0x338
#define CODEC_PAGE3_3C              0x33C
#define CODEC_PAGE3_40              0x340
#define CODEC_PAGE3_44              0x344
#define CODEC_PAGE3_48              0x348
#define CODEC_PAGE3_4C              0x34C
#define CODEC_PAGE3_50              0x350
#define CODEC_PAGE3_54              0x354
#define CODEC_PAGE3_58              0x358
#define CODEC_PAGE3_5C              0x35C
#define CODEC_PAGE3_60              0x360
#define CODEC_PAGE3_64              0x364
#define CODEC_PAGE3_68              0x368
#define CODEC_PAGE3_6C              0x36C
#define CODEC_PAGE3_70              0x370
#define CODEC_PAGE3_74              0x374
#define CODEC_PAGE3_78              0x378
#define CODEC_PAGE3_7C              0x37C
#define CODEC_PAGE3_80              0x380
#define CODEC_PAGE3_84              0x384
#define CODEC_PAGE3_88              0x388
#define CODEC_PAGE3_8C              0x38C
#define CODEC_PAGE3_90              0x390
#define CODEC_PAGE3_94              0x394
#define CODEC_PAGE3_98              0x398
#define CODEC_PAGE3_9C              0x39C
#define CODEC_PAGE3_A0              0x3A0
#define CODEC_PAGE3_A4              0x3A4
#define CODEC_PAGE3_A8              0x3A8
#define CODEC_PAGE3_AC              0x3AC
#define CODEC_PAGE3_B0              0x3B0
#define CODEC_PAGE3_B4              0x3B4
#define CODEC_PAGE3_B8              0x3B8
#define CODEC_PAGE3_BC              0x3BC
#define CODEC_PAGE3_C0              0x3C0
#define CODEC_PAGE3_C4              0x3C4
#define CODEC_PAGE3_C8              0x3C8

#define CODEC_PAGE4_00              0x400
#define CODEC_PAGE4_04              0x404
#define CODEC_PAGE4_08              0x408
#define CODEC_PAGE4_0C              0x40C
#define CODEC_PAGE4_10              0x410
#define CODEC_PAGE4_14              0x414
#define CODEC_PAGE4_18              0x418
#define CODEC_PAGE4_1C              0x41C
#define CODEC_PAGE4_20              0x420
#define CODEC_PAGE4_24              0x424
#define CODEC_PAGE4_28              0x428
#define CODEC_PAGE4_2C              0x42C
#define CODEC_PAGE4_30              0x430
#define CODEC_PAGE4_34              0x434
#define CODEC_PAGE4_38              0x438
#define CODEC_PAGE4_3C              0x43C
#define CODEC_PAGE4_40              0x440
#define CODEC_PAGE4_44              0x444
#define CODEC_PAGE4_48              0x448
#define CODEC_PAGE4_4C              0x44C
#define CODEC_PAGE4_50              0x450
#define CODEC_PAGE4_54              0x454
#define CODEC_PAGE4_58              0x458
#define CODEC_PAGE4_5C              0x45C
#define CODEC_PAGE4_60              0x460
#define CODEC_PAGE4_64              0x464
#define CODEC_PAGE4_68              0x468
#define CODEC_PAGE4_6C              0x46C
#define CODEC_PAGE4_70              0x470
#define CODEC_PAGE4_74              0x474
#define CODEC_PAGE4_78              0x478
#define CODEC_PAGE4_7C              0x47C
#define CODEC_PAGE4_80              0x480
#define CODEC_PAGE4_84              0x484
#define CODEC_PAGE4_88              0x488
#define CODEC_PAGE4_8C              0x48C
#define CODEC_PAGE4_90              0x490
#define CODEC_PAGE4_94              0x494
#define CODEC_PAGE4_98              0x498
#define CODEC_PAGE4_9C              0x49C
#define CODEC_PAGE4_A0              0x4A0
#define CODEC_PAGE4_A4              0x4A4
#define CODEC_PAGE4_A8              0x4A8
#define CODEC_PAGE4_AC              0x4AC
#define CODEC_PAGE4_B0              0x4B0
#define CODEC_PAGE4_B4              0x4B4
#define CODEC_PAGE4_B8              0x4B8
#define CODEC_PAGE4_BC              0x4BC
#define CODEC_PAGE4_C0              0x4C0
#define CODEC_PAGE4_C4              0x4C4
#define CODEC_PAGE4_C8              0x4C8

#define CODEC_PAGE5_00              0x500
#define CODEC_PAGE5_04              0x504
#define CODEC_PAGE5_08              0x508
#define CODEC_PAGE5_0C              0x50C
#define CODEC_PAGE5_10              0x510
#define CODEC_PAGE5_14              0x514
#define CODEC_PAGE5_18              0x518
#define CODEC_PAGE5_1C              0x51C
#define CODEC_PAGE5_20              0x520
#define CODEC_PAGE5_24              0x524
#define CODEC_PAGE5_28              0x528
#define CODEC_PAGE5_2C              0x52C
#define CODEC_PAGE5_30              0x530
#define CODEC_PAGE5_34              0x534
#define CODEC_PAGE5_38              0x538
#define CODEC_PAGE5_3C              0x53C
#define CODEC_PAGE5_40              0x540
#define CODEC_PAGE5_44              0x544
#define CODEC_PAGE5_48              0x548
#define CODEC_PAGE5_4C              0x54C
#define CODEC_PAGE5_50              0x550
#define CODEC_PAGE5_54              0x554
#define CODEC_PAGE5_58              0x558
#define CODEC_PAGE5_5C              0x55C
#define CODEC_PAGE5_60              0x560
#define CODEC_PAGE5_64              0x564
#define CODEC_PAGE5_68              0x568
#define CODEC_PAGE5_6C              0x56C
#define CODEC_PAGE5_70              0x570
#define CODEC_PAGE5_74              0x574
#define CODEC_PAGE5_78              0x578
#define CODEC_PAGE5_7C              0x57C
#define CODEC_PAGE5_80              0x580
#define CODEC_PAGE5_84              0x584
#define CODEC_PAGE5_88              0x588
#define CODEC_PAGE5_8C              0x58C
#define CODEC_PAGE5_90              0x590
#define CODEC_PAGE5_94              0x594
#define CODEC_PAGE5_98              0x598
#define CODEC_PAGE5_9C              0x59C
#define CODEC_PAGE5_A0              0x5A0
#define CODEC_PAGE5_A4              0x5A4
#define CODEC_PAGE5_A8              0x5A8
#define CODEC_PAGE5_AC              0x5AC
#define CODEC_PAGE5_B0              0x5B0
#define CODEC_PAGE5_B4              0x5B4
#define CODEC_PAGE5_B8              0x5B8
#define CODEC_PAGE5_BC              0x5BC
#define CODEC_PAGE5_C0              0x5C0
#define CODEC_PAGE5_C4              0x5C4
#define CODEC_PAGE5_C8              0x5C8
#define CODEC_PAGE5_CC              0x5CC
#define CODEC_PAGE5_D0              0x5D0
#define CODEC_PAGE5_D4              0x5D4
#define CODEC_PAGE5_D8              0x5D8
#define CODEC_PAGE5_DC              0x5DC
#define CODEC_PAGE5_E0              0x5E0
#define CODEC_PAGE5_E4              0x5E4
#define CODEC_PAGE5_E8              0x5E8
#define CODEC_PAGE5_EC              0x5EC
#define CODEC_PAGE5_F0              0x5F0
#define CODEC_PAGE5_F4              0x5F4

#define CODEC_PAGE6_00              0x600
#define CODEC_PAGE6_04              0x604
#define CODEC_PAGE6_08              0x608
#define CODEC_PAGE6_0C              0x60C
#define CODEC_PAGE6_10              0x610
#define CODEC_PAGE6_14              0x614
#define CODEC_PAGE6_18              0x618
#define CODEC_PAGE6_1C              0x61C
#define CODEC_PAGE6_20              0x620
#define CODEC_PAGE6_24              0x624
#define CODEC_PAGE6_28              0x628
#define CODEC_PAGE6_2C              0x62C
#define CODEC_PAGE6_30              0x630
#define CODEC_PAGE6_34              0x634
#define CODEC_PAGE6_38              0x638
#define CODEC_PAGE6_3C              0x63C
#define CODEC_PAGE6_40              0x640
#define CODEC_PAGE6_44              0x644
#define CODEC_PAGE6_48              0x648
#define CODEC_PAGE6_4C              0x64C
#define CODEC_PAGE6_50              0x650
#define CODEC_PAGE6_54              0x654
#define CODEC_PAGE6_58              0x658
#define CODEC_PAGE6_5C              0x65C
#define CODEC_PAGE6_60              0x660
#define CODEC_PAGE6_64              0x664
#define CODEC_PAGE6_68              0x668
#define CODEC_PAGE6_6C              0x66C
#define CODEC_PAGE6_70              0x670
#define CODEC_PAGE6_74              0x674
#define CODEC_PAGE6_78              0x678
#define CODEC_PAGE6_7C              0x67C
#define CODEC_PAGE6_80              0x680
#define CODEC_PAGE6_84              0x684
#define CODEC_PAGE6_88              0x688
#define CODEC_PAGE6_8C              0x68C
#define CODEC_PAGE6_90              0x690
#define CODEC_PAGE6_94              0x694
#define CODEC_PAGE6_98              0x698
#define CODEC_PAGE6_9C              0x69C
#define CODEC_PAGE6_A0              0x6A0
#define CODEC_PAGE6_A4              0x6A4
#define CODEC_PAGE6_A8              0x6A8
#define CODEC_PAGE6_AC              0x6AC
#define CODEC_PAGE6_B0              0x6B0
#define CODEC_PAGE6_B4              0x6B4
#define CODEC_PAGE6_B8              0x6B8
#define CODEC_PAGE6_BC              0x6BC
#define CODEC_PAGE6_C0              0x6C0
#define CODEC_PAGE6_C4              0x6C4
#define CODEC_PAGE6_C8              0x6C8
#define CODEC_PAGE6_CC              0x6CC
#define CODEC_PAGE6_D0              0x6D0
#define CODEC_PAGE6_D4              0x6D4
#define CODEC_PAGE6_D8              0x6D8
#define CODEC_PAGE6_DC              0x6DC
#define CODEC_PAGE6_E0              0x6E0
#define CODEC_PAGE6_E4              0x6E4
#define CODEC_PAGE6_E8              0x6E8
#define CODEC_PAGE6_EC              0x6EC
#define CODEC_PAGE6_F0              0x6F0
#define CODEC_PAGE6_F4              0x6F4

#define CODEC_PAGE7_00              0x700
#define CODEC_PAGE7_04              0x704
#define CODEC_PAGE7_08              0x708
#define CODEC_PAGE7_0C              0x70C
#define CODEC_PAGE7_10              0x710
#define CODEC_PAGE7_14              0x714
#define CODEC_PAGE7_18              0x718
#define CODEC_PAGE7_1C              0x71C
#define CODEC_PAGE7_20              0x720
#define CODEC_PAGE7_24              0x724
#define CODEC_PAGE7_28              0x728
#define CODEC_PAGE7_2C              0x72C
#define CODEC_PAGE7_30              0x730
#define CODEC_PAGE7_34              0x734
#define CODEC_PAGE7_38              0x738
#define CODEC_PAGE7_3C              0x73C
#define CODEC_PAGE7_40              0x740
#define CODEC_PAGE7_44              0x744
#define CODEC_PAGE7_48              0x748
#define CODEC_PAGE7_4C              0x74C
#define CODEC_PAGE7_50              0x750
#define CODEC_PAGE7_54              0x754
#define CODEC_PAGE7_58              0x758
#define CODEC_PAGE7_5C              0x75C
#define CODEC_PAGE7_60              0x760
#define CODEC_PAGE7_64              0x764
#define CODEC_PAGE7_68              0x768
#define CODEC_PAGE7_6C              0x76C
#define CODEC_PAGE7_70              0x770
#define CODEC_PAGE7_74              0x774
#define CODEC_PAGE7_78              0x778
#define CODEC_PAGE7_7C              0x77C
#define CODEC_PAGE7_80              0x780
#define CODEC_PAGE7_84              0x784
#define CODEC_PAGE7_88              0x788
#define CODEC_PAGE7_8C              0x78C
#define CODEC_PAGE7_90              0x790
#define CODEC_PAGE7_94              0x794
#define CODEC_PAGE7_98              0x798
#define CODEC_PAGE7_9C              0x79C
#define CODEC_PAGE7_A0              0x7A0
#define CODEC_PAGE7_A4              0x7A4
#define CODEC_PAGE7_A8              0x7A8
#define CODEC_PAGE7_AC              0x7AC
#define CODEC_PAGE7_B0              0x7B0
#define CODEC_PAGE7_B4              0x7B4
#define CODEC_PAGE7_B8              0x7B8
#define CODEC_PAGE7_BC              0x7BC
#define CODEC_PAGE7_C0              0x7C0
#define CODEC_PAGE7_C4              0x7C4
#define CODEC_PAGE7_C8              0x7C8
#define CODEC_PAGE7_CC              0x7CC
#define CODEC_PAGE7_D0              0x7D0
#define CODEC_PAGE7_D4              0x7D4
#define CODEC_PAGE7_D8              0x7D8
#define CODEC_PAGE7_DC              0x7DC
#define CODEC_PAGE7_E0              0x7E0
#define CODEC_PAGE7_E4              0x7E4
#define CODEC_PAGE7_E8              0x7E8
#define CODEC_PAGE7_EC              0x7EC
#define CODEC_PAGE7_F0              0x7F0
#define CODEC_PAGE7_F4              0x7F4

#define CODEC_PAGE8_00              0x800
#define CODEC_PAGE8_04              0x804
#define CODEC_PAGE8_08              0x808
#define CODEC_PAGE8_0C              0x80C
#define CODEC_PAGE8_10              0x810
#define CODEC_PAGE8_14              0x814
#define CODEC_PAGE8_18              0x818
#define CODEC_PAGE8_1C              0x81C
#define CODEC_PAGE8_20              0x820
#define CODEC_PAGE8_24              0x824
#define CODEC_PAGE8_28              0x828
#define CODEC_PAGE8_2C              0x82C
#define CODEC_PAGE8_30              0x830
#define CODEC_PAGE8_34              0x834
#define CODEC_PAGE8_38              0x838
#define CODEC_PAGE8_3C              0x83C
#define CODEC_PAGE8_40              0x840
#define CODEC_PAGE8_44              0x844
#define CODEC_PAGE8_48              0x848
#define CODEC_PAGE8_4C              0x84C
#define CODEC_PAGE8_50              0x850
#define CODEC_PAGE8_54              0x854
#define CODEC_PAGE8_58              0x858
#define CODEC_PAGE8_5C              0x85C
#define CODEC_PAGE8_60              0x860
#define CODEC_PAGE8_64              0x864
#define CODEC_PAGE8_68              0x868
#define CODEC_PAGE8_6C              0x86C
#define CODEC_PAGE8_70              0x870
#define CODEC_PAGE8_74              0x874
#define CODEC_PAGE8_78              0x878

#define CODEC_PAGEF_00              0xF00
#define CODEC_PAGEF_04              0xF04
#define CODEC_PAGEF_08              0xF08
#define CODEC_PAGEF_0C              0xF0C
#define CODEC_PAGEF_10              0xF10
#define CODEC_PAGEF_14              0xF14
#define CODEC_PAGEF_18              0xF18
#define CODEC_PAGEF_1C              0xF1C
#define CODEC_PAGEF_20              0xF20
#define CODEC_PAGEF_24              0xF24





typedef struct
{
    union
    {
        __IO uint32_t ANA_CR0;          /*!< 0x010 */
        T_CODEC_PAGE0_0x10_TYPE ana_cr0;
        T_CODEC_PAGE0_0x10_TYPE codec_0x010;

    } u_010;
    union
    {
        __IO uint32_t ANA_CR1;          /*!< 0x014 */
        T_CODEC_PAGE0_0x14_TYPE ana_cr1;
        T_CODEC_PAGE0_0x14_TYPE codec_0x014;

    } u_014;

    union
    {
        __IO uint32_t ANA_CR2;          /*!< 0x018 */
        T_CODEC_PAGE0_0x18_TYPE ana_cr2;
        T_CODEC_PAGE0_0x18_TYPE codec_0x018;

    } u_018;

    union
    {
        __IO uint32_t ANA_CR3;          /*!< 0x01C */
        T_CODEC_PAGE0_0x1C_TYPE ana_cr3;
        T_CODEC_PAGE0_0x1C_TYPE codec_0x01C;

    } u_01C;

    union
    {
        __IO uint32_t ANA_CR4;          /*!< 0x020 */
        T_CODEC_PAGE0_0x20_TYPE ana_cr4;
        T_CODEC_PAGE0_0x20_TYPE codec_0x020;

    } u_020;
    union
    {
        __IO uint32_t ANA_CR5;          /*!< 0x024 */
        T_CODEC_PAGE0_0x24_TYPE ana_cr5;
        T_CODEC_PAGE0_0x24_TYPE codec_0x024;

    } u_024;

    union
    {
        __IO uint32_t ANA_CR6;          /*!< 0x028 */
        T_CODEC_PAGE0_0x28_TYPE ana_cr6;
        T_CODEC_PAGE0_0x28_TYPE codec_0x028;

    } u_028;

    union
    {
        __IO uint32_t ANA_CR7;          /*!< 0x02C */
        T_CODEC_PAGE0_0x2C_TYPE ana_cr7;
        T_CODEC_PAGE0_0x2C_TYPE codec_0x02C;

    } u_02C;

} CODEC_AnalogTypeDef;



typedef union t_codec_adc_control_0_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_dmic_src_sel        : 3;   //u( 3, 0f), start@0x64, [ 2: 0] used
        uint32_t adc_dmic_lpf2nd_en      : 1;   //u( 1, 0f), start@0x64, [ 3: 3] used
        uint32_t adc_dmic_lpf1st_en      : 1;   //u( 1, 0f), start@0x64, [ 4: 4] used
        uint32_t adc_dmic_lpf1st_fc_sel  : 2;   //u( 2, 0f), start@0x64, [ 6: 5] used
        uint32_t adc_dmic_mix_mute       : 1;   //u( 1, 0f), start@0x64, [ 7: 7] used
        uint32_t adc_ad_src_sel          : 3;   //u( 3, 0f), start@0x65, [10: 8] used
        uint32_t adc_ad_lpf2nd_en        : 1;   //u( 1, 0f), start@0x65, [11:11] used
        uint32_t adc_ad_lpf1st_en        : 1;   //u( 1, 0f), start@0x65, [12:12] used
        uint32_t adc_ad_lpf1st_fc_sel    : 2;   //u( 2, 0f), start@0x65, [14:13] used
        uint32_t adc_ad_mix_mute         : 1;   //u( 1, 0f), start@0x65, [15:15] used
        uint32_t adc_ad_zdet_func        : 2;   //u( 2, 0f), start@0x66, [17:16] used
        uint32_t adc_ad_zdet_tout        : 2;   //u( 2, 0f), start@0x66, [19:18] used
        uint32_t adc_ad_mute             : 1;   //u( 1, 0f), start@0x66, [20:20] used
        uint32_t adc_biquad_hpf_en       : 1;   //u( 1, 0f), start@0x66, [21:21] used
        uint32_t adc_deci_src_sel        : 2;   //u( 2, 0f), start@0x66, [23:22] used
        uint32_t adc_dchpf_en            : 1;   //u( 1, 0f), start@0x67, [24:24] used
        uint32_t adc_dchpf_fc_sel        : 3;   //u( 3, 0f), start@0x67, [27:25] used
        uint32_t adc_dmic_lpf2nd_fc_sel  : 1;   //u( 1, 0f), start@0x66, [28:28] used
        uint32_t adc_ad_lpf2nd_fc_sel    : 1;   //u( 1, 0f), start@0x67, [29:29] used
        uint32_t bit_temp                : 2;    //u( 2, 0f)
    };
} CODEC_ADC_CONTROL_0_TYPE;


typedef union t_codec_adc_control_1_type
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t adc_ad_gain             : 8;   //u( 8, 0f), start@0x70, [ 7: 0] used
        uint32_t adc_rsvd                : 3;   //u( 2, 0f), start@0x71, [11:9] used
        uint32_t adc_rptr_hold           : 4;   //u( 4, 0f), start@0x71, [15:12] used
        uint32_t adc_ds_rate             : 1;   //u( 1, 0f), start@0x72, [16:16] used
        uint32_t adc_depon_en            : 1;   //u( 1, 0f), start@0x72, [17:17] used
        uint32_t adc_depon_time_sel      : 2;   //u( 2, 0f), start@0x72, [19:18] used
        uint32_t adc_biquad_hpf_en       : 1;   //u( 1, 0f), start@0x72, [20:20] used
        uint32_t bit_temp                : 2;   //u( 11, 0f)
    };
} CODEC_ADC_CONTROL_1_TYPE;


typedef struct
{
    __IO CODEC_ADC_CONTROL_0_TYPE adc_control_0;
    __IO CODEC_ADC_CONTROL_1_TYPE adc_control_1;
} CODEC_ADC_TypeDef;


typedef struct
{
    __IO uint32_t EQ_H0;            /*!< 0x40 */
    __IO uint32_t EQ_B1;            /*!< 0x44 */
    __IO uint32_t EQ_B2;            /*!< 0x48 */
    __IO uint32_t EQ_A1;            /*!< 0x4C */
    __IO uint32_t EQ_A2;            /*!< 0x50 */
} CODEC_EQTypeDef;



#define CODEC_ADC_REG_BASE                     0x40400164UL
#define CODEC_DAC_REG_BASE                     0x40400194UL

#define CODEC_ADC0_REG_BASE                    0x40400164UL
#define CODEC_ADC1_REG_BASE                    0x4040016CUL
#define CODEC_ADC2_REG_BASE                    0x40400174UL
#define CODEC_ADC3_REG_BASE                    0x4040017CUL
#define CODEC_ADC4_REG_BASE                    0x40400184UL
#define CODEC_ADC5_REG_BASE                    0x4040018CUL
#define CODEC_ADC6_REG_BASE                    0x404001B4UL

#define CODEC_DACL_REG_BASE                    0x40400194UL
#define CODEC_DACR_REG_BASE                    0x404001A0UL
#define CODEC_DAC2_REG_BASE                    0x404001C4UL

//#define CODEC_EQ1_REG_BASE                               0x40022040UL
//#define CODEC_EQ2_REG_BASE                               0x40022054UL
//#define CODEC_EQ3_REG_BASE                               0x40022068UL
//#define CODEC_EQ4_REG_BASE                               0x4002207CUL
//#define CODEC_EQ5_REG_BASE                                 0x40022090UL

#define CODEC_DAC_L_CR_REG_BASE                        0x40401300UL
#define CODEC_DAC_L_EQ0_REG_BASE                     0x40401304UL
#define CODEC_DAC_L_EQ1_REG_BASE                     0x40401318UL
#define CODEC_DAC_L_EQ2_REG_BASE               0x4040132CUL
#define CODEC_DAC_L_EQ3_REG_BASE                       0x40401340UL
#define CODEC_DAC_L_EQ4_REG_BASE                         0x40401354UL
#define CODEC_DAC_L_EQ5_REG_BASE                     0x40401368UL
#define CODEC_DAC_L_EQ6_REG_BASE                     0x4040137CUL
#define CODEC_DAC_L_EQ7_REG_BASE                     0x40401390UL
#define CODEC_DAC_L_EQ8_REG_BASE                     0x404013A4UL
#define CODEC_DAC_L_EQ9_REG_BASE                     0x404013B8UL


#define CODEC_DAC_R_CR_REG_BASE                        0x40401400UL
#define CODEC_DAC_R_EQ0_REG_BASE                     0x40401404UL
#define CODEC_DAC_R_EQ1_REG_BASE                     0x40401418UL
#define CODEC_DAC_R_EQ2_REG_BASE               0x4040142CUL
#define CODEC_DAC_R_EQ3_REG_BASE                       0x40401440UL
#define CODEC_DAC_R_EQ4_REG_BASE                         0x40401454UL
#define CODEC_DAC_R_EQ5_REG_BASE                     0x40401468UL
#define CODEC_DAC_R_EQ6_REG_BASE                     0x4040147CUL
#define CODEC_DAC_R_EQ7_REG_BASE                     0x40401490UL
#define CODEC_DAC_R_EQ8_REG_BASE                     0x404014A4UL
#define CODEC_DAC_R_EQ9_REG_BASE                     0x404014B8UL


#define CODEC_ADC_CH0_CR_REG_BASE                  0x40401500UL
#define CODEC_ADC_CH0_EQ0_REG_BASE                   0x40401504UL
#define CODEC_ADC_CH0_EQ1_REG_BASE                   0x40401518UL
#define CODEC_ADC_CH0_EQ2_REG_BASE                   0x4040152CUL
#define CODEC_ADC_CH0_EQ3_REG_BASE                   0x40401540UL
#define CODEC_ADC_CH0_EQ4_REG_BASE                   0x40401554UL
#define CODEC_ADC_CH0_HPF_REG_BASE                   0x40401568UL

#define CODEC_ADC_CH1_CR_REG_BASE                  0x4040157CUL
#define CODEC_ADC_CH1_EQ0_REG_BASE                   0x40401580UL
#define CODEC_ADC_CH1_EQ1_REG_BASE                   0x40401594UL
#define CODEC_ADC_CH1_EQ2_REG_BASE                   0x404015A8UL
#define CODEC_ADC_CH1_EQ3_REG_BASE                   0x404015BCUL
#define CODEC_ADC_CH1_EQ4_REG_BASE                   0x404015D0UL
#define CODEC_ADC_CH1_HPF_REG_BASE                   0x404015E4UL

#define CODEC_ADC_CH2_CR_REG_BASE                  0x40401600UL
#define CODEC_ADC_CH2_EQ0_REG_BASE                   0x40401604UL
#define CODEC_ADC_CH2_EQ1_REG_BASE                   0x40401618UL
#define CODEC_ADC_CH2_EQ2_REG_BASE                   0x4040162CUL
#define CODEC_ADC_CH2_EQ3_REG_BASE                   0x40401640UL
#define CODEC_ADC_CH2_EQ4_REG_BASE                   0x40401654UL
#define CODEC_ADC_CH2_HPF_REG_BASE                   0x40401668UL

#define CODEC_ADC_CH3_CR_REG_BASE                  0x4040167CUL
#define CODEC_ADC_CH3_EQ0_REG_BASE                   0x40401680UL
#define CODEC_ADC_CH3_EQ1_REG_BASE                   0x40401694UL
#define CODEC_ADC_CH3_EQ2_REG_BASE                   0x404016A8UL
#define CODEC_ADC_CH3_EQ3_REG_BASE                   0x404016BCUL
#define CODEC_ADC_CH3_EQ4_REG_BASE                   0x404016D0UL
#define CODEC_ADC_CH3_HPF_REG_BASE                   0x404017E4UL

#define CODEC_ADC_CH4_CR_REG_BASE                  0x40401700UL
#define CODEC_ADC_CH4_EQ0_REG_BASE                   0x40401704UL
#define CODEC_ADC_CH4_EQ1_REG_BASE                   0x40401718UL
#define CODEC_ADC_CH4_EQ2_REG_BASE                   0x4040172CUL
#define CODEC_ADC_CH4_EQ3_REG_BASE                   0x40401740UL
#define CODEC_ADC_CH4_EQ4_REG_BASE                   0x40401754UL
#define CODEC_ADC_CH4_HPF_REG_BASE                   0x40401768UL

#define CODEC_ADC_CH5_CR_REG_BASE                  0x4040177CUL
#define CODEC_ADC_CH5_EQ0_REG_BASE                   0x40401780UL
#define CODEC_ADC_CH5_EQ1_REG_BASE                   0x40401794UL
#define CODEC_ADC_CH5_EQ2_REG_BASE                   0x404017A8UL
#define CODEC_ADC_CH5_EQ3_REG_BASE                   0x404017BCUL
#define CODEC_ADC_CH5_EQ4_REG_BASE                   0x404017D0UL
#define CODEC_ADC_CH5_HPF_REG_BASE                   0x404017E4UL

#define CODEC_ADC_CH6_CR_REG_BASE                  0x40401800UL
#define CODEC_ADC_CH6_EQ0_REG_BASE                   0x40401804UL
#define CODEC_ADC_CH6_EQ1_REG_BASE                   0x40401818UL
#define CODEC_ADC_CH6_EQ2_REG_BASE                   0x4040182CUL
#define CODEC_ADC_CH6_EQ3_REG_BASE                   0x40401840UL
#define CODEC_ADC_CH6_EQ4_REG_BASE                   0x40401854UL
#define CODEC_ADC_CH6_HPF_REG_BASE                   0x40401868UL


#define CODEC_ADC0                            ((CODEC_ADC_TypeDef*) CODEC_ADC0_REG_BASE)
#define CODEC_ADC1                            ((CODEC_ADC_TypeDef*) CODEC_ADC1_REG_BASE)
#define CODEC_ADC2                            ((CODEC_ADC_TypeDef*) CODEC_ADC2_REG_BASE)
#define CODEC_ADC3                            ((CODEC_ADC_TypeDef*) CODEC_ADC3_REG_BASE)
#define CODEC_ADC4                            ((CODEC_ADC_TypeDef*) CODEC_ADC4_REG_BASE)
#define CODEC_ADC5                            ((CODEC_ADC_TypeDef*) CODEC_ADC5_REG_BASE)
#define CODEC_ADC6                            ((CODEC_ADC_TypeDef*) CODEC_ADC6_REG_BASE)
#define CODEC_ADC7                            ((CODEC_ADC_TypeDef*) CODEC_ADC7_REG_BASE)


#define CODEC_DAC_L_CR                    (*((volatile uint32_t *)CODEC_DAC_L_CR_REG_BASE))
#define CODEC_DAC_L_EQ0                   ((CODEC_EQTypeDef*) CODEC_DAC_L_EQ0_REG_BASE)
#define CODEC_DAC_L_EQ1                   ((CODEC_EQTypeDef*) CODEC_DAC_L_EQ1_REG_BASE)
#define CODEC_DAC_L_EQ2                   ((CODEC_EQTypeDef*) CODEC_DAC_L_EQ2_REG_BASE)
#define CODEC_DAC_L_EQ3                   ((CODEC_EQTypeDef*) CODEC_DAC_L_EQ3_REG_BASE)
#define CODEC_DAC_L_EQ4                   ((CODEC_EQTypeDef*) CODEC_DAC_L_EQ4_REG_BASE)
#define CODEC_DAC_L_EQ5                   ((CODEC_EQTypeDef*) CODEC_DAC_L_EQ5_REG_BASE)
#define CODEC_DAC_L_EQ6                   ((CODEC_EQTypeDef*) CODEC_DAC_L_EQ6_REG_BASE)
#define CODEC_DAC_L_EQ7                   ((CODEC_EQTypeDef*) CODEC_DAC_L_EQ7_REG_BASE)
#define CODEC_DAC_L_EQ8                   ((CODEC_EQTypeDef*) CODEC_DAC_L_EQ8_REG_BASE)
#define CODEC_DAC_L_EQ9                   ((CODEC_EQTypeDef*) CODEC_DAC_L_EQ9_REG_BASE)

#define CODEC_DAC_R_CR                    (*((volatile uint32_t *)CODEC_DAC_L_CR_REG_BASE))
#define CODEC_DAC_R_EQ0                   ((CODEC_EQTypeDef*) CODEC_DAC_R_EQ0_REG_BASE)
#define CODEC_DAC_R_EQ1                   ((CODEC_EQTypeDef*) CODEC_DAC_R_EQ1_REG_BASE)
#define CODEC_DAC_R_EQ2                   ((CODEC_EQTypeDef*) CODEC_DAC_R_EQ2_REG_BASE)
#define CODEC_DAC_R_EQ3                   ((CODEC_EQTypeDef*) CODEC_DAC_R_EQ3_REG_BASE)
#define CODEC_DAC_R_EQ4                   ((CODEC_EQTypeDef*) CODEC_DAC_R_EQ4_REG_BASE)
#define CODEC_DAC_R_EQ5                   ((CODEC_EQTypeDef*) CODEC_DAC_R_EQ5_REG_BASE)
#define CODEC_DAC_R_EQ6                   ((CODEC_EQTypeDef*) CODEC_DAC_R_EQ6_REG_BASE)
#define CODEC_DAC_R_EQ7                   ((CODEC_EQTypeDef*) CODEC_DAC_R_EQ7_REG_BASE)
#define CODEC_DAC_R_EQ8                   ((CODEC_EQTypeDef*) CODEC_DAC_R_EQ8_REG_BASE)
#define CODEC_DAC_R_EQ9                   ((CODEC_EQTypeDef*) CODEC_DAC_R_EQ9_REG_BASE)

#define CODEC_ADC_CH0_CR                   (*((volatile uint32_t *)CODEC_ADC_CH0_CR_REG_BASE))
#define CODEC_ADC_CH0_EQ0                  ((CODEC_EQTypeDef*) CODEC_ADC_CH0_EQ0_REG_BASE)
#define CODEC_ADC_CH0_EQ1                  ((CODEC_EQTypeDef*) CODEC_ADC_CH0_EQ1_REG_BASE)
#define CODEC_ADC_CH0_EQ2                  ((CODEC_EQTypeDef*) CODEC_ADC_CH0_EQ2_REG_BASE)
#define CODEC_ADC_CH0_EQ3                  ((CODEC_EQTypeDef*) CODEC_ADC_CH0_EQ3_REG_BASE)
#define CODEC_ADC_CH0_EQ4                  ((CODEC_EQTypeDef*) CODEC_ADC_CH0_EQ4_REG_BASE)
#define CODEC_ADC_CH0_HPF                  ((CODEC_EQTypeDef*) CODEC_ADC_CH0_HPF_REG_BASE)

#define CODEC_ADC_CH1_CR                   (*((volatile uint32_t *)CODEC_ADC_CH1_CR_REG_BASE))
#define CODEC_ADC_CH1_EQ0                  ((CODEC_EQTypeDef*) CODEC_ADC_CH1_EQ0_REG_BASE)
#define CODEC_ADC_CH1_EQ1                  ((CODEC_EQTypeDef*) CODEC_ADC_CH1_EQ1_REG_BASE)
#define CODEC_ADC_CH1_EQ2                  ((CODEC_EQTypeDef*) CODEC_ADC_CH1_EQ2_REG_BASE)
#define CODEC_ADC_CH1_EQ3                  ((CODEC_EQTypeDef*) CODEC_ADC_CH1_EQ3_REG_BASE)
#define CODEC_ADC_CH1_EQ4                  ((CODEC_EQTypeDef*) CODEC_ADC_CH1_EQ4_REG_BASE)
#define CODEC_ADC_CH1_HPF                  ((CODEC_EQTypeDef*) CODEC_ADC_CH1_HPF_REG_BASE)

#define CODEC_ADC_CH2_CR                   (*((volatile uint32_t *)CODEC_ADC_CH2_CR_REG_BASE))
#define CODEC_ADC_CH2_EQ0                  ((CODEC_EQTypeDef*) CODEC_ADC_CH2_EQ0_REG_BASE)
#define CODEC_ADC_CH2_EQ1                  ((CODEC_EQTypeDef*) CODEC_ADC_CH2_EQ1_REG_BASE)
#define CODEC_ADC_CH2_EQ2                  ((CODEC_EQTypeDef*) CODEC_ADC_CH2_EQ2_REG_BASE)
#define CODEC_ADC_CH2_EQ3                  ((CODEC_EQTypeDef*) CODEC_ADC_CH2_EQ3_REG_BASE)
#define CODEC_ADC_CH2_EQ4                  ((CODEC_EQTypeDef*) CODEC_ADC_CH2_EQ4_REG_BASE)
#define CODEC_ADC_CH2_HPF                  ((CODEC_EQTypeDef*) CODEC_ADC_CH2_HPF_REG_BASE)

#define CODEC_ADC_CH3_CR                   (*((volatile uint32_t *)CODEC_ADC_CH3_CR_REG_BASE))
#define CODEC_ADC_CH3_EQ0                  ((CODEC_EQTypeDef*) CODEC_ADC_CH3_EQ0_REG_BASE)
#define CODEC_ADC_CH3_EQ1                  ((CODEC_EQTypeDef*) CODEC_ADC_CH3_EQ1_REG_BASE)
#define CODEC_ADC_CH3_EQ2                  ((CODEC_EQTypeDef*) CODEC_ADC_CH3_EQ2_REG_BASE)
#define CODEC_ADC_CH3_EQ3                  ((CODEC_EQTypeDef*) CODEC_ADC_CH3_EQ3_REG_BASE)
#define CODEC_ADC_CH3_EQ4                  ((CODEC_EQTypeDef*) CODEC_ADC_CH3_EQ4_REG_BASE)
#define CODEC_ADC_CH3_HPF                  ((CODEC_EQTypeDef*) CODEC_ADC_CH3_HPF_REG_BASE)

#define CODEC_ADC_CH4_CR                   (*((volatile uint32_t *)CODEC_ADC_CH4_CR_REG_BASE))
#define CODEC_ADC_CH4_EQ0                  ((CODEC_EQTypeDef*) CODEC_ADC_CH4_EQ0_REG_BASE)
#define CODEC_ADC_CH4_EQ1                  ((CODEC_EQTypeDef*) CODEC_ADC_CH4_EQ1_REG_BASE)
#define CODEC_ADC_CH4_EQ2                  ((CODEC_EQTypeDef*) CODEC_ADC_CH4_EQ2_REG_BASE)
#define CODEC_ADC_CH4_EQ3                  ((CODEC_EQTypeDef*) CODEC_ADC_CH4_EQ3_REG_BASE)
#define CODEC_ADC_CH4_EQ4                  ((CODEC_EQTypeDef*) CODEC_ADC_CH4_EQ4_REG_BASE)
#define CODEC_ADC_CH4_HPF                  ((CODEC_EQTypeDef*) CODEC_ADC_CH4_HPF_REG_BASE)

#define CODEC_ADC_CH5_CR                   (*((volatile uint32_t *)CODEC_ADC_CH5_CR_REG_BASE))
#define CODEC_ADC_CH5_EQ0                  ((CODEC_EQTypeDef*) CODEC_ADC_CH5_EQ0_REG_BASE)
#define CODEC_ADC_CH5_EQ1                  ((CODEC_EQTypeDef*) CODEC_ADC_CH5_EQ1_REG_BASE)
#define CODEC_ADC_CH5_EQ2                  ((CODEC_EQTypeDef*) CODEC_ADC_CH5_EQ2_REG_BASE)
#define CODEC_ADC_CH5_EQ3                  ((CODEC_EQTypeDef*) CODEC_ADC_CH5_EQ3_REG_BASE)
#define CODEC_ADC_CH5_EQ4                  ((CODEC_EQTypeDef*) CODEC_ADC_CH5_EQ4_REG_BASE)
#define CODEC_ADC_CH5_HPF                  ((CODEC_EQTypeDef*) CODEC_ADC_CH5_HPF_REG_BASE)

#define CODEC_ADC_CH6_CR                   (*((volatile uint32_t *)CODEC_ADC_CH6_CR_REG_BASE))
#define CODEC_ADC_CH6_EQ0                  ((CODEC_EQTypeDef*) CODEC_ADC_CH6_EQ0_REG_BASE)
#define CODEC_ADC_CH6_EQ1                  ((CODEC_EQTypeDef*) CODEC_ADC_CH6_EQ1_REG_BASE)
#define CODEC_ADC_CH6_EQ2                  ((CODEC_EQTypeDef*) CODEC_ADC_CH6_EQ2_REG_BASE)
#define CODEC_ADC_CH6_EQ3                  ((CODEC_EQTypeDef*) CODEC_ADC_CH6_EQ3_REG_BASE)
#define CODEC_ADC_CH6_EQ4                  ((CODEC_EQTypeDef*) CODEC_ADC_CH6_EQ4_REG_BASE)
#define CODEC_ADC_CH6_HPF                  ((CODEC_EQTypeDef*) CODEC_ADC_CH6_HPF_REG_BASE)

#ifdef  __cplusplus
}
#endif /* __cplusplus */

#endif /* _CODEC_REG_H_ */

