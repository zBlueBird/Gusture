/**
*********************************************************************************************************
*               Copyright(c) 2021, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* \file     rtl_pinmux.h
* \brief    The header file of PAD and PINMUX driver.
* \details  This file provides all PAD and PINMUX firmware functions.
* \author   Yuan
* \date     2023-02-14
* \version  v2.0.0
* *********************************************************************************************************
*/


#ifndef RTL_PINMUX_H
#define RTL_PINMUX_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * \addtogroup  IO          Peripheral Drivers
 * \defgroup    PINMUX      PINMUX
 *
 * \brief       Manage the PINMUX peripheral functions.
 *
 * \ingroup     IO
 */

/*============================================================================*
 *                         Includes
 *============================================================================*/
#include "rtl876x.h"
#include "rtl876x_aon_reg.h"

/* ================================================================================ */
/* ================      Pinmux Registers Structures Section       ================ */
/* ================================================================================ */
/**
  * @brief Pinmux. (Pinmux)
  */
typedef struct                      /*!< Pinmux Structure */
{
    __IO uint32_t CFG[45];          /*!<  */
} PINMUX_TypeDef;

/* ================================================================================ */
/* ================               Pinmux Declaration               ================ */
/* ================================================================================ */
#define PINMUX                          ((PINMUX_TypeDef           *) PINMUX_REG_BASE)
#define PINMUX_CODEC                    ((PINMUX_TypeDef           *) PINMUX_CODEC_REG_BASE)
#define PINMUX_M0                       ((PINMUX_TypeDef           *) PINMUX_M0_REG_BASE)

/*============================================================================*
 *                         Constants
 *============================================================================*/
/**
 * \defgroup    PINMUX_Exported_Constants   PINMUX Exported Constants
 * \{
 * \ingroup     PINMUX
 */

/**
 * \cond
 * \brief Internal Macros
 * \{
 */
/* Pad Functions */
#define SHDN                        (BIT0)
#define Output_En                   (BIT1)
#define Output_Val                  (BIT2)
#define Pull_Resistance             (BIT5)
#define Pull_Direction              (BIT6)
#define Pull_En                     (BIT7)
#define WKPOL                       (BIT8)
#define WKEN                        (BIT9)
#define DEB                         (BIT10)
#define GATE                        (BIT13)
#define ANA_Mode                    (BIT10)

#define MAX_PIN_ADDR_NUM            (MAX_PIN_NUM/2+1)//pad num
#define MAX_PIN_REG_NUM             (TOTAL_PIN_NUM/4+1)//pinmux num
/**
 * \}
 * \endcond
 */

/**
 * \defgroup    Pin_Function_Number Pin Function Number
 * \ingroup     PINMUX_Exported_Constants
 * \{
 */

#define IDLE_MODE                   0

//km0 start
#define UART0_TX                    1
#define UART0_RX                    2
#define UART0_CTS                   3
#define UART0_RTS                   4
#define UART1_TX                    5
#define UART1_RX                    6
#define UART1_CTS                   7
#define UART1_RTS                   8

#define BT_COEX_I_0                 216
#define BT_COEX_I_1                 217
#define BT_COEX_I_2                 218
#define BT_COEX_I_3                 219
#define BT_COEX_O_0                 220
#define BT_COEX_O_1                 221
#define BT_COEX_O_2                 222
#define BT_COEX_O_3                 223
#define PTA_I2C_CLK_SLAVE           224
#define PTA_I2C_DAT_SLAVE           225
#define PTA_I2C_INT_OUT             226
#define EN_EXPA                     227
#define EN_EXLNA                    228
#define SEL_TPM_SW                  229
#define SEL_TPM_N_SW                230
#define ANT_SW0                     231
#define ANT_SW1                     232
#define ANT_SW2                     233
#define ANT_SW3                     234
#define ANT_SW4                     235
#define ANT_SW5                     236
#define phy_gpio_1                  237
#define phy_gpio_2                  238
#define slow_debug_mux_1            239
#define slow_debug_mux_2            240
#define km0_clk                     242
//km0 end

//VCORE2 & 4 (KM4/DSP/Peripheral IO) start
#define UART2_TX                    9
#define UART2_RX                    10
#define UART2_CTS                   11
#define UART2_RTS                   12
#define UART3_TX                    13
#define UART3_RX                    14
#define UART3_CTS                   15
#define UART3_RTS                   16
#define UART4_TX                    17
#define UART4_RX                    18
#define UART4_CTS                   19
#define UART4_RTS                   20
#define UART5_TX                    21
#define UART5_RX                    22
#define UART5_CTS                   23
#define UART5_RTS                   24
#define UART6_TX                    25
#define UART6_RX                    26
#define UART6_CTS                   27
#define UART6_RTS                   28
#define I2C0_CLK                    29
#define I2C0_DAT                    30
#define I2C1_CLK                    31
#define I2C1_DAT                    32
#define I2C2_CLK                    33
#define I2C2_DAT                    34
#define I2C3_CLK                    35
#define I2C3_DAT                    36
#define SPI0_CLK_MASTER             37
#define SPI0_MO_MASTER              38
#define SPI0_MI_MASTER              39
#define SPI0_CSN_0_MASTER           40
#define SPI0_CSN_1_MASTER           41
#define SPI0_CSN_2_MASTER           42
#define SPI0_CSN_0_SLAVE            43
#define SPI0_CLK_SLAVE              44
#define SPI0_SO_SLAVE               45
#define SPI0_SI_SLAVE               46
#define SPI1_CLK_MASTER             47
#define SPI1_MO_MASTER              48
#define SPI1_MI_MASTER              49
#define SPI1_CSN_0_MASTER           50
#define SPI1_CSN_1_MASTER           51
#define SPI1_CSN_2_MASTER           52
#define SPI2_CLK_MASTER             53
#define SPI2_MO_MASTER              54
#define SPI2_MI_MASTER              55
#define SPI2_CSN_0_MASTER           56
#define SPI2_CSN_1_MASTER           57
#define SPI2_CSN_2_MASTER           58
#define SPI3_CLK_MASTER             59
#define SPI3_MO_MASTER              60
#define SPI3_MI_MASTER              61
#define SPI3_CSN_0_MASTER           62
#define SPI3_CSN_1_MASTER           63
#define SPI3_CSN_2_MASTER           64
#define ENPWM0_P                    65
#define ENPWM0_N                    66
#define ENPWM1_P                    67
#define ENPWM1_N                    68
#define ENPWM2_P                    69
#define ENPWM2_N                    70
#define ENPWM3_P                    71
#define ENPWM3_N                    72
#define ENPWM4_P                    73
#define ENPWM4_N                    74
#define ENPWM5_P                    75
#define ENPWM5_N                    76
#define ENPWM6_P                    77
#define ENPWM6_N                    78
#define ENPWM7_P                    79
#define ENPWM7_N                    80
#define TIMERB_PWM0                 81
#define TIMERB_PWM1                 82
#define TIMERB_PWM2                 83
#define TIMERB_PWM3                 84

#define ISO7816_RST                 85
#define ISO7816_CLK                 86
#define ISO7816_IO                  87
#define ISO7816_VCC_EN              88
#define DWGPIO                      89
#define IRDA_TX                     90
#define IRDA_RX                     91
#define TIMERB_PWM0_P               92
#define TIMERB_PWM0_N               93
#define TIMERB_PWM1_P               94
#define TIMERB_PWM1_N               95
#define TIMERB_PWM2_P               96
#define TIMERB_PWM2_N               97
#define TIMERB_PWM3_P               98
#define TIMERB_PWM3_N               99
#define KEY_COL_0                   100
#define KEY_COL_1                   101
#define KEY_COL_2                   102
#define KEY_COL_3                   103
#define KEY_COL_4                   104
#define KEY_COL_5                   105
#define KEY_COL_6                   106
#define KEY_COL_7                   107
#define KEY_COL_8                   108
#define KEY_COL_9                   109
#define KEY_COL_10                  110
#define KEY_COL_11                  111
#define KEY_COL_12                  112
#define KEY_COL_13                  113
#define KEY_COL_14                  114
#define KEY_COL_15                  115
#define KEY_COL_16                  116
#define KEY_COL_17                  117
#define KEY_COL_18                  118
#define KEY_COL_19                  119
#define KEY_ROW_0                   120
#define KEY_ROW_1                   121
#define KEY_ROW_2                   122
#define KEY_ROW_3                   123
#define KEY_ROW_4                   124
#define KEY_ROW_5                   125
#define KEY_ROW_6                   126
#define KEY_ROW_7                   127
#define KEY_ROW_8                   128
#define KEY_ROW_9                   129
#define KEY_ROW_10                  130
#define KEY_ROW_11                  131
#define qdec_phase_a_x              132
#define qdec_phase_b_x              133
#define qdec_phase_a_y              134
#define qdec_phase_b_y              135
#define qdec_phase_a_z              136
#define qdec_phase_b_z              137

#define km4_clk_div_4               138
#define DSP_GPIO_OUT                139
#define DSP_JTCK                    140
#define DSP_JTDI                    141
#define DSP_JTDO                    142
#define DSP_JTMS                    143
#define DSP_JTRST                   144
#define dsp_clk_div_4               145
//#define DSP_TIE_GPIO_OUT            146
#define card_detect_n_0             147
#define biu_volt_reg_0              148
#define back_end_power_0            149
#define card_int_n_sdio_0           150
#define card_detect_n_1             151
#define biu_volt_reg_1              152
#define back_end_power_1            153
#define card_int_n_sdio_1           154

#define test_mode                   246
#define TRACECTRL                   247
#define TRACECLK                    248
#define TRACEDATA_0                 249
#define TRACEDATA_1                 250
#define TRACEDATA_2                 251
#define TRACEDATA_3                 252
//VCORE2&4 (KM4/DSP/Peripheral IO) end

//VCORE3 (Codec/SPORT/VAD) start
#define LRC_SPORT1                  157
#define BCLK_SPORT1                 158
#define ADCDAT_SPORT1               159
#define DACDAT_SPORT1               160

//#define SPDIF_TX                    161

#define DMIC1_CLK                   162
#define DMIC1_DAT                   163
#define LRC_I_CODEC_SLAVE           164
#define BCLK_I_CODEC_SLAVE          165
#define SDI_CODEC_SLAVE             166
#define SDO_CODEC_SLAVE             167
#define LRC_I_PCM                   168
#define BCLK_I_PCM                  169
#define SDI_PCM                     170
#define SDO_PCM                     171
#define LRC_SPORT0                  172
#define BCLK_SPORT0                 173
#define ADCDAT_SPORT0               174
#define DACDAT_SPORT0               175
#define MCLK_OUT                    176
#define DMIC2_CLK                   177
#define DMIC2_DAT                   178
#define DMIC3_CLK                   179
#define DMIC3_DAT                   180
#define LRC_SPORT2                  181
#define BCLK_SPORT2                 182
#define ADCDAT_SPORT2               183
#define DACDAT_SPORT2               184
#define LRC_SPORT3                  185
#define BCLK_SPORT3                 186
#define ADCDAT_SPORT3               187
#define DACDAT_SPORT3               188
#define MCLK_IN                     189
#define LRC_RX_CODEC_SLAVE          190
#define LRC_RX_SPORT0               191
#define LRC_RX_SPORT1               192
#define LRC_RX_SPORT2               193
#define LRC_RX_SPORT3               194

//#define SPDIF_RX                    195

#define PDM_DATA                    196
#define PDM_CLK                     197
#define I2S1_LRC_TX_SLAVE           198
#define I2S1_BCLK_SLAVE             199
#define I2S1_SDI_SLAVE              200
#define I2S1_SDO_SLAVE              201
#define I2S1_LRC_RX_SLAVE           202
#define I2S2_LRC_TX_SLAVE           203
#define I2S2_BCLK_SLAVE             204
#define I2S2_SDI_SLAVE              205
#define I2S2_SDO_SLAVE              206
#define I2S2_LRC_RX_SLAVE           207
#define DMIC4_CLK                   208
#define DMIC4_DAT                   209
//VCORE3 (Codec/SPORT/VAD) end

#define SWD_CLK                     253
#define SWD_DIO                     254
#define dig_debug                   255

/**
  * \brief   PAD_Aon_Mux PAD Aon Mux
  * \ingroup PINMUX_Exported_Constants
 */
#define RTC_IN_NONE         0x0000
#define RTC_IN_P0_1         0x0001
#define RTC_IN_P1_2         0x0002
#define RTC_IN_P2_0         0x0003
#define RTC_IN_P2_7         0x0004
#define RTC_IN_P4_7         0x0005
#define RTC_IN_P5_0         0x0006
#define RTC_IN_P8_6         0x0007
#define RTC_IN_P9_3         0x0008
#define RTC_IN_P10_6        0x0009
#define RTC_IN_P13_7        0x000A
#define RTC_IN_P14_7        0x000B
#define RTC_IN_P16_3        0x000C
#define RTC_IN_P20_5        0x000D

#define MCLK2_OUT_NONE      0x0A00
#define MCLK2_OUT_P0_1      0x0A01
#define MCLK2_OUT_P0_7      0x0A02
#define MCLK2_OUT_P1_2      0x0A03
#define MCLK2_OUT_P2_0      0x0A04
#define MCLK2_OUT_P2_7      0x0A05
#define MCLK2_OUT_P4_7      0x0A06
#define MCLK2_OUT_P5_0      0x0A07
#define MCLK2_OUT_P6_0      0x0A08
#define MCLK2_OUT_P8_6      0x0A09
#define MCLK2_OUT_P9_2      0x0A0A
#define MCLK2_OUT_P10_7     0x0A0B
#define MCLK2_OUT_P13_3     0x0A0C
#define MCLK2_OUT_P14_0     0x0A0D
#define MCLK2_OUT_P16_3     0x0A0E

#define QDPH0_IN_NONE       0x0E00
#define QDPH0_IN_P0_2       0x0E01
#define QDPH0_IN_P1_3       0x0E02
#define QDPH0_IN_P3_0       0x0E03
#define QDPH0_IN_P5_1       0x0E04
#define QDPH0_IN_P8_7       0x0E05
#define QDPH0_IN_P9_1       0x0E06
#define QDPH0_IN_P11_0      0x0E07
#define QDPH0_IN_P13_6      0x0E08
#define QDPH0_IN_P16_4      0x0E09
#define QDPH0_IN_P20_6      0x0E0A

#define QDPH1_IN_NONE       0x1200
#define QDPH1_IN_P0_3       0x1201
#define QDPH1_IN_P1_4       0x1202
#define QDPH1_IN_P3_1       0x1203
#define QDPH1_IN_P5_2       0x1204
#define QDPH1_IN_P9_0       0x1205
#define QDPH1_IN_P11_1      0x1206
#define QDPH1_IN_P13_5      0x1207
#define QDPH1_IN_P16_5      0x1208
#define QDPH1_IN_P18_0      0x1209
#define QDPH1_IN_P20_7      0x120A

#define TCKC_IN_NONE        0x1600
#define TCKC_IN_P5_3        0x1601
#define TCKC_IN_P19_5       0x1602

#define TMSC_IO_NONE        0x1800
#define TMSC_IO_P5_2        0x1801
#define TMSC_IO_P19_4       0x1802

#define TDI_IN_NONE         0x1C00
#define TDI_IN_P5_4         0x1C01
#define TDI_IN_P19_6        0x1C02

#define TDO_OUT_NONE        0x1E00
#define TDO_OUT_P5_5        0x1E01
#define TDO_OUT_P19_7       0x1E02
/** \} */
/** \} */

/**
  * \enum    PAD_Power_Mode PAD Power Mode
  * \ingroup PINMUX_Exported_Constants
 */
typedef enum _PAD_PWR_Mode
{
    PAD_NOT_PWRON,
    PAD_IS_PWRON = 1
} PAD_PWR_Mode;

/**
  * \enum    PAD_Output_Config PAD Output Config
  * \ingroup PINMUX_Exported_Constants
 */
typedef enum _PAD_OUTPUT_ENABLE_Mode
{
    PAD_OUT_DISABLE,
    PAD_OUT_ENABLE
} PAD_OUTPUT_ENABLE_Mode;

/**
  * \enum    PAD_Output_Value    PAD Output Value
  * \ingroup PINMUX_Exported_Constants
 */
typedef enum _PAD_OUTPUT_VAL
{
    PAD_OUT_LOW,
    PAD_OUT_HIGH
} PAD_OUTPUT_VAL;

/**
  * \enum    PAD_Driving_Current PAD Driving Current
  * \ingroup PINMUX_Exported_Constants
 */
typedef enum _PAD_DRIVING_CURRENT
{
    PAD_DRIVING_CURRENT_2_4mA,
    PAD_DRIVING_CURRENT_4_8mA = 2,
    PAD_DRIVING_CURRENT_6_12mA = 1,
    PAD_DRIVING_CURRENT_8_16mA = 3,
} PAD_DRIVING_CURRENT;

/**
  * \enum    PAD_Pull_Mode PAD Pull Mode
  * \ingroup PINMUX_Exported_Constants
 */
typedef enum _PAD_Pull_Mode
{
    PAD_PULL_DOWN,
    PAD_PULL_UP,
    PAD_PULL_NONE,
} PAD_Pull_Mode;

/**
  * \enum    PAD_Pull_Strength_Mode PAD Pull Strength Mode
  * \ingroup PINMUX_Exported_Constants
 */
typedef enum _PAD_Pull_Strength_Mode
{
    PAD_PULL_WEAK,
    PAD_PULL_STRONG,
} PAD_Pull_Strength_Mode;

/**
  * \enum    PAD_WAKEUP_DEBOUNCE_EN  PAD WakeUp Debounce enable
  * \ingroup PINMUX_Exported_Constants
 */
typedef enum _PAD_WAKEUP_DEBOUNCE_EN
{
    PAD_WAKEUP_DEB_DISABLE,
    PAD_WAKEUP_DEB_ENABLE
} PAD_WAKEUP_DEBOUNCE_EN;

/** \enum    PAD_WAKEUP_EN  PAD WakeUp enable
  * \ingroup PINMUX_Exported_Constants
  */
typedef enum _PAD_WAKEUP_EN
{
    PAD_WAKEUP_DISABLE,
    PAD_WAKEUP_ENABLE
} PAD_WAKEUP_EN;

/** \enum    PAD_Short_Pulse_WakeUp_EN PAD Short Pulse WakeUp EN
  * \ingroup PINMUX_Exported_Constants
  */
typedef enum _PAD_SHORT_PULSE_WAKEUP_EN
{
    PAD_SHORT_PULSE_WAKEUP_DISABLE,
    PAD_SHORT_PULSE_WAKEUP_ENABLE
} PAD_SHORT_PULSE_WAKEUP_EN;

/**
  * \enum    PAD_WakeUp_Polarity    PAD WakeUp Polarity
  * \ingroup PINMUX_Exported_Constants
 */
typedef enum _PAD_WAKEUP_POL_VAL
{
    PAD_WAKEUP_POL_HIGH,
    PAD_WAKEUP_POL_LOW
} PAD_WAKEUP_POL;

typedef enum _PAD_DEB_FREQ
{
    PAD_DEB_FREQ_32KHz,
    PAD_DEB_FREQ_16KHz,
    PAD_DEB_FREQ_8KHz = 3,
    PAD_DEB_FREQ_4KHz = 7,
    PAD_DEB_FREQ_2KHz = 15,
    PAD_DEB_FREQ_1KHz = 31,
    PAD_DEB_FREQ_500Hz = 63,
} PAD_DEB_FREQ;

/**
  * \enum    PAD_Mode PAD Mode
  * \ingroup PINMUX_Exported_Constants
 */
typedef enum _PAD_Mode
{
    PAD_SW_MODE,
    PAD_V1_PINMUX_MODE,     //Vcore1
    PAD_V2_V4_PINMUX_MODE,  //Vcore2&4
    PAD_V3_PINMUX_MODE,     //Vcore3
    PAD_PINMUX_MODE       = PAD_V2_V4_PINMUX_MODE,
} PAD_Mode;

/** \} */ /** End of group PINMUX_Exported_Constants */
/*============================================================================*
 *                         Functions
 *============================================================================*/
#define Pad_ControlSelectValue          Pad_SetControlMode
#define Pad_OutputEnableValue           Pad_Output_Cmd
#define Pad_OutputControlValue          Pad_SetOutputValue
#define Pad_PullEnableValue             Pad_Pull_Cmd
#define Pad_PullUpOrDownValue           Pad_SetPullMode
#define Pad_PullConfigValue             Pad_SetPullStrengthMode
#define Pad_PowerOrShutDownValue        Pad_Power_Cmd
#define Pad_DrivingCurrentControl       Pad_SetDrivingCurrent
#define Pad_WakeupEnableValue           Pad_Wakeup_Cmd
#define Pad_WakeupPolarityValue         Pad_SetWakeupPolarity
#define Pad_WKDebounceConfig            Pad_WakeupDebounce_Cmd
#define Pad_WakeupInterruptValue        Pad_GetWakeupINTStatus

/**
 * \defgroup    PINMUX_Exported_Functions Peripheral APIs
 * \ingroup     PINMUX
 * \{
 */

/**
 * \brief   Configure or reset all pins to idle mode.
 * \param   None.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_xxx_init(void)//XXX represents the name of the peripheral to be configured.
 * {
 *     Pinmux_Reset();
 * }
 * \endcode
 */
void Pinmux_Reset(void);

/**
 * \brief     Configure the specified pin to idle mode.
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_xxx_init(void)
 * {
 *     Pinmux_Deinit(P2_2);
 * }
 * \endcode
 */
void Pinmux_Deinit(uint8_t Pin_Num);
/**
  * @brief  Deinit the VCORE1 IO function of one pin.
  * @param  Pin_Num: pin number.
  *         This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
  * @retval None
   *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_xxx_init(void)
 * {
 *     Pinmux_V1_Deinit(P2_2);
 * }
  * \endcode
  */
void Pinmux_V1_Deinit(uint8_t Pin_Num);

/**
  * @brief  Deinit the VCORE3 IO function of one pin.
  * @param  Pin_Num: pin number.
  *         This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
  * @retval None
   *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_xxx_init(void)
 * {
 *     Pinmux_CODEC_Deinit(P2_2);
 * }
  * \endcode
  */
void Pinmux_CODEC_Deinit(uint8_t Pin_Num);

/**
 * \brief     Config the usage function of the selected pin.
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \param[in] Pin_Func: Use function of pin.
 *            This parameter This parameter refers to \ref Pin_Function_Number
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_uart_init(void)
 * {
 *     Pad_Config(P2_0, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE,
               PAD_OUT_HIGH);
 *     Pad_Config(P2_1, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE,
               PAD_OUT_HIGH);

 *     Pinmux_Config(P2_0, UART0_TX);
 *     Pinmux_Config(P2_1, UART0_RX);
 * }
 * \endcode
 */
void Pinmux_Config(uint8_t Pin_Num, uint8_t Pin_Func);
/**
 * \brief     Config the usage function of the selected pin.
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \param[in] Pin_Func: Use VCORE3 function of pin.
 *            This parameter This parameter refers to \ref Pin_Function_Number
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_uart_init(void)
 * {
 *     Pad_Config(P2_0, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE,
               PAD_OUT_HIGH);
 *     Pad_Config(P2_1, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE,
               PAD_OUT_HIGH);

 *     Pinmux_CODEC_Config(P2_0, UART0_TX);
 *     Pinmux_CODEC_Config(P2_1, UART0_RX);
 * }
 * \endcode
 */
void Pinmux_CODEC_Config(uint8_t Pin_Num, uint8_t Pin_Func);

/**
 * @brief  Config pin to VCORE1 domain dedicated mux.
 * @param  Pin_Num: pin number.
 *         This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * @param  Pin_Func: mean one IO function, please refer to rtl_pinmux.h "Pin_Function_Number" part.
 * @retval None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_uart_init(void)
 * {
 *     Pad_Config(P2_0, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE,
               PAD_OUT_HIGH);
 *     Pad_Config(P2_1, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_UP, PAD_OUT_DISABLE,
               PAD_OUT_HIGH);

 *     Pinmux_CODEC_Config(P2_0, DMIC1_CLK);
 *     Pinmux_CODEC_Config(P2_1, DMIC1_DAT);
 * }
 * \endcode
 */

void Pinmux_V1_Config(uint8_t Pin_Num, uint8_t Pin_Func);

/**
 * @brief  Config pin to AON domain dedicated mux.
 * @param  Func: AON domain dedicated mux, please refer to rtl_pinmux.h "PAD_Aon_Mux" part.
 * @retval None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_qdec_init(void)
 * {
 *     Pinmux_Aon_Config(QDPH0_IN_P0_2);
 * }
 * \endcode
 */
void Pinmux_Aon_Config(uint16_t Func);

/**
 * \brief     Configure the relevant operation mode,
 *            peripheral circuit and output level value in software mode of the specified pin
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \param[in] AON_PAD_Mode: Use software mode or pinmux mode.
 *            This parameter can be one of the following values:
 *            \arg PAD_SW_MODE: Use software mode.
 *            \arg PAD_PINMUX_MODE: Use pinmux mode.
 * \param[in] AON_PAD_PwrOn: Config power of pad.
 *            This parameter can be one of the following values:
 *            \arg PAD_NOT_PWRON: Shutdown power of pad.
 *            \arg PAD_IS_PWRON: Enable power of pad.
 * \param[in] AON_PAD_Pull: config pad pull mode.
 *            This parameter can be one of the following values:
 *            \arg PAD_PULL_NONE: No pull.
 *            \arg PAD_PULL_UP: Pull this pin up.
 *            \arg PAD_PULL_DOWN: Pull this pin down.
 * \param[in] AON_PAD_E: Config pad out put function.
 *            This parameter can be one of the following values:
 *            \arg PAD_OUT_DISABLE: Disable pin output.
 *            \arg PAD_OUT_ENABLE: Enable pad output.
 * \param[in] AON_PAD_O: Config pin output level.
 *            This parameter can be one of the following values:
 *            \arg PAD_OUT_LOW: Pad output low.
 *            \arg PAD_OUT_HIGH: Pad output high.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_adc_init(void)
 * {
 *     Pad_Config(P2_0, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
 *     Pad_Config(P2_1, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
 * }
 * \endcode
 */
void Pad_Config(uint8_t                 Pin_Num,
                PAD_Mode                AON_PAD_Mode,
                PAD_PWR_Mode            AON_PAD_PwrOn,
                PAD_Pull_Mode           AON_PAD_Pull,
                PAD_OUTPUT_ENABLE_Mode  AON_PAD_E,
                PAD_OUTPUT_VAL          AON_PAD_O);

/**
 * \brief     Configure the relevant operation mode,
 *            peripheral circuit and output level value in software mode of the specified pin
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_adc_init(void)
 * {
 *     Pad_Dedicated_Config(P2_2, Enable);
 * }
 * \endcode
 */
void Pad_Dedicated_Config(uint8_t Pin_Num, FunctionalState Status);

/**
 * \brief     Enable the function of the wake-up system of the specified pin.
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \param[in] Polarity: Polarity of wake-up system.
 *            This parameter can be the following:
 *            \arg PAD_WAKEUP_POL_HIGH: Use high level wakeup.
 *            \arg PAD_WAKEUP_POL_LOW: Use low level wakeup.
 * \param[in] DebounceEn: Enable delay function.
 *            \arg PAD_WK_DEBOUNCE_DISABLE: Disable delay function.
 *            \arg PAD_WK_DEBOUNCE_ENABLE: Enable delay function.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 * //IO enter dlps call back function.
 * void io_uart_dlps_enter(void)
 * {
 *     // Switch pad to software mode
 *     Pad_ControlSelectValue(P2_0, PAD_SW_MODE);//tx pin
 *     Pad_ControlSelectValue(P2_1, PAD_SW_MODE);//rx pin
 *
 *     System_WakeUpPinEnable(P2_1, PAD_WAKEUP_POL_LOW, PAD_WK_DEBOUNCE_DISABLE);
 * }
 * \endcode
 */
void System_WakeUpPinEnable(uint8_t Pin_Num, uint8_t Polarity, uint8_t DebounceEn);

/**
 * \brief     Disable the function of the wake-up system of the specified pin.
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 * #define UART_RX_PIN                P4_1
 *
 * //System interrupt handler function, for wakeup pin.
 * void System_Handler(void)
 * {
 *     if (System_WakeUpInterruptValue(UART_RX_PIN) == SET)
 *     {
 *         Pad_ClearWakeupINTPendingBit(UART_RX_PIN);
 *         System_WakeUpPinDisable(UART_RX_PIN);
 *         //Add user code here.
 *     }
 * }
 * \endcode
 */
void System_WakeUpPinDisable(uint8_t Pin_Num);

/**
 * \brief  Enable wake-up system of the specified pin.
 * \param  Pin_Num: Pin number to be configured.
 *         This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \param  PAD_WAKEUP_EN: wake-up system enable or disable
 *         \arg PAD_WAKEUP_DISABLE: Disable wakeup.
 *         \arg PAD_WAKEUP_DISABLE: Enable wakeup.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 *void System_WakeUpPinEnable(uint8_t Pin_Num, uint8_t Polarity, uint8_t DebounceEn)
 *{
 *    if(Pin_Num >= MAX_PIN_NUM)
 *    {
 *        return;
 *    }
 *
 *    Pad_SetWakeupPolarity(Pin_Num, Polarity);
 *    Pad_WakeupDebounce_Cmd(Pin_Num, DebounceEn);
 *    if (PAD_WAKEUP_DEB_ENABLE == DebounceEn)
 *    {
 *        System_Pad_WakeUp_Cmd(Pin_Num, PAD_WAKEUP_ENABLE);
 *    }
 *    Pad_Wakeup_Cmd(Pin_Num, ENABLE);
 *}
 * \endcode
 */
void System_Pad_WakeUp_Cmd(uint8_t Pin_Num, PAD_WAKEUP_EN Status);

/**
 * \brief     Get pin interrupt status.
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \return    Interrupt status.
 *            \retval 1: Pin wake up system.
 *            \retval 0: The pin does not wake up the system.
 *
 * <b>Example usage</b>
 * \code{.c}
 * #define UART_RX_PIN                P4_1
 *
 * //System interrupt handler function, for wakeup pin.
 * void System_Handler(void)
 * {
 *     if (System_WakeUpInterruptValue(UART_RX_PIN) == SET)
 *     {
 *         Pad_ClearWakeupINTPendingBit(UART_RX_PIN);
 *         System_WakeUpPinDisable(UART_RX_PIN);
 *         //Add user code here.
 *     }
 * }
 * \endcode
 */
uint8_t System_WakeUpInterruptValue(uint8_t Pin_Num);

/**
 * \brief     Config wak-up system debounce time.
 * \param[in] time: Debounce time,1ms~64ms.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_xxx_init(void)
 * {
 *     System_WakeUpDebounceTime(10);
 * }
 * \endcode
 */
void System_WakeUpDebounceTime(uint8_t Pin_Num, PAD_DEB_FREQ Frequency, uint8_t Count);

/**
  * @brief  Check debounce wake up status.
  * @note:  Call this API will clear the debunce wakeup status bit.
  * @param  None
  * @retval Debounce wakeup status
  */
uint8_t Pad_DebounceWakeupStatus(uint8_t Pin_Num);

/**
  * @brief  Get debounce wake up status.
  * @note:  Call this API will clear the debunce wakeup status bit.
  * @param  None
  * @retval Debounce wakeup status
  *
  *
  * <b>Example usage</b>
  * \code{.c}
  *
  * void board_xxx_init(void)
  * {
  *     uint8_t DebounceWakeupStatus = System_DebounceWakeupStatus;
  * }
  * \endcode
  */
uint8_t System_DebounceWakeupStatus(uint8_t Pin_Num);

/**
 * \brief     Set pin drivering current.
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \param[in] value: This parameter sets the pin drivering current.
 *            This parameter can be the following:
 *            \arg PAD_DRIVING_CURRENT_2_4mA: 1.8V~2mA, 3.3V~4mA.
 *            \arg PAD_DRIVING_CURRENT_4_8mA: 1.8V~4mA, 3.3V~8mA.
 *            \arg PAD_DRIVING_CURRENT_6_12mA: 1.8V~4mA, 3.3V~12mA.
 *            \arg PAD_DRIVING_CURRENT_8_16mA: 1.8V~4mA, 3.3V~16mA.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_xxx_init(void)
 * {
 *     Pad_SetDrivingCurrent(P2_0, PAD_DRIVING_CURRENT_2_4mA);
 * }
 * \endcode
 */
void Pad_SetDrivingCurrent(uint8_t Pin_Num, PAD_DRIVING_CURRENT Current);

/**
 * \brief     Set pin control mode.
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \param[in] value: This parameter sets the pin mode.
 *            This parameter can be the following:
 *            \arg PAD_SW_MODE: Software mode.
 *            \arg PAD_V1_PINMUX_MODE: V1 pinmux mode.
 *            \arg PAD_V2_V4_PINMUX_MODE: V2V4 Pinmux mode.
 *            \arg PAD_V3_PINMUX_MODE: V3 pinmux mode.
 *            \arg PAD_PINMUX_MODE: Default pinmux mode.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_xxx_init(void)
 * {
 *     Pad_SetControlMode(P2_0, PAD_SW_MODE);
 * }
 * \endcode
 */
void Pad_SetControlMode(uint8_t Pin_Num, PAD_Mode PAD_Mode);

/**
 * \brief     Enable or disable pad output mode.
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \param[in] value: This parameter sets whether the pin outputs the level in software mode.
 *            This parameter can be enumerated PAD_OUTPUT_ENABLE_Mod of the values:
 *            \arg PAD_OUT_DISABLE: Disable output.
 *            \arg PAD_OUT_ENABLE: Enable output.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void pad_demo(void)
 * {
 *     Pad_OutputEnableValue(P2_0, PAD_OUT_ENABLE);
 * }
 * \endcode
 */
void Pad_Output_Cmd(uint8_t Pin_Num, PAD_OUTPUT_ENABLE_Mode Status);

/**
 * \brief     Configure pad output level.
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \param[in] value: Config pin output level.
 *            This parameter can be one of the following values:
 *            \arg PAD_OUT_LOW: Pad output low.
 *            \arg PAD_OUT_HIGH: Pad output high.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_xxx_init(void)
 * {
 *     Pad_OutputControlValue(P2_0, PAD_OUT_HIGH);
 * }
 * \endcode
 */
void Pad_SetOutputValue(uint8_t Pin_Num, uint8_t value);

/**
 * \brief     Enable or disable pad pull-up / pull-down resistance function.
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \param[in] value: This parameter enable or disable the the pad pin pull-up/pull-down function.
 *            This parameter can be the following:
 *            \arg DISABLE: Disable pad pull-up / pull-down function.
 *            \arg ENABLE: Enable  pad pull-up / pull-down function.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_xxx_init(void)
 * {
 *     Pad_PullEnableValue(P2_0, ENABLE);
 * }
 * \endcode
 */
void Pad_Pull_Cmd(uint8_t Pin_Num, FunctionalState Status);

/**
 * \brief     Pad pull-up/pull-down resistance function selection.
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \param[in] value: This parameter sets whether the pin pull-up or pull-down.
 *            This parameter can be the following:
 *            \arg 0: Config pad pull-up function.
 *            \arg 1: Config  pad pull-down function.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_xxx_init(void)
 * {
 *     Pad_PullUpOrDownValue(P2_0, 1);
 * }
 * \endcode
 */
void Pad_SetPullMode(uint8_t Pin_Num, PAD_Pull_Mode PAD_Pull_Mode);

/**
 * \brief     Configure the strength of pull-up/pull-down resistance.
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \param[in] value: This parameter sets the strength of pull-up/pull-down resistance.
 *            This parameter can be the following:
 *            \arg PAD_WEAK_PULL: Resistance weak pull.
 *            \arg PAD_STRONG_PULL: Resistance strong pull.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_xxx_init(void)
 * {
 *     Pad_PullConfigValue(P2_0, PAD_STRONG_PULL);
 * }
 * \endcode
 */
void Pad_SetPullStrengthMode(uint8_t Pin_Num, PAD_Pull_Strength_Mode PAD_Pull_Strength_Mode);

/**
 * \brief     Set pin power mode.
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \param[in] value: This parameter sets the power supply mode of the pin,
 *                   and the value is enumeration PAD_PWR_Mode One of the values.
 *            \arg PAD_NOT_PWRON: Power off.
 *            \arg PAD_IS_PWRON: Power on.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_xxx_init(void)
 * {
 *     Pad_PowerOrShutDownValue(P2_0, PAD_NOT_PWRON);
 * }
 * \endcode
 */
void Pad_Power_Cmd(uint8_t Pin_Num, PAD_PWR_Mode PWR_Mode);

/**
 * \brief     Enable the function of the wake-up system of the specified pin.
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \param[in] value: Enable wake-up system function.
 *            \arg 0:Disable wake-up system function.
 *            \arg 1:Enable wake-up system function.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_xxx_init(void)
 * {
 *     Pad_WakeupEnableValue(P2_0, 1);
 * }
 * \endcode
 */
void Pad_Wakeup_Cmd(uint8_t Pin_Num, uint8_t value);

/**
 * \brief     Set polarity of wake-up system.
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \param[in] Polarity: Polarity of wake-up system.
 *            This parameter can be the following:
 *            \arg PAD_WAKEUP_POL_LOW:Use low level wakeup.
 *            \arg PAD_WAKEUP_POL_HIGH: Use high level wakeup.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_xxx_init(void)
 * {
 *     Pad_WakeupPolarityValue(P2_0, PAD_WAKEUP_POL_HIGH);
 * }
 * \endcode
 */
void Pad_SetWakeupPolarity(uint8_t Pin_Num, uint8_t value);

/**
 * \brief     Config pin delay function.
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \param[in] value: Enable delay function.
 *            \arg 0:Disable delay function.
 *            \arg 1:Enable delay function.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_xxx_init(void)
 * {
 *     Pad_WKDebounceConfig(P2_0, 1);
 * }
 * \endcode
 */
void Pad_WakeupDebounce_Cmd(uint8_t Pin_Num, uint8_t value);

/**
 * \brief     Get pin interrupt status, function is the same as \see system_WakeUpInterruptValue.
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \return    Interrupt status.
 *            \retval 0: The pin does not wake up the system.
 *            \retval 1: Pin wake up system.
 */
uint8_t Pad_GetWakeupINTStatus(uint8_t Pin_Num);

/**
 * \brief     Clear the interrupt pendign bit of the specified pin
 * \param[in] Pin_Num: Pin number to be configured.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_xxx_init(void)
 * {
 *     Pad_ClearWakeupINTPendingBit(P2_0);
 * }
 * \endcode
 */
void Pad_ClearWakeupINTPendingBit(uint8_t Pin_Num);

/**
 * \brief     Clear all wake up pin interrupt pending bit.
 * \param[in] Pin_Num: pin number.
 *            This parameter is from P0_0 to P20_7, please refer to rtl876x.h "Pin_Number" part.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void board_xxx_init(void)
 * {
 *     Pad_ClearAllWakeupINT();
 * }
 * \endcode
 */
void Pad_ClearAllWakeupINT(void);

/**
 * @brief Get aon wake up int.
 * @retun Wakeup intterupt.
 *        @retval bit0: aon pad wake up int
 *        @retval bit1: aon lpc0 wake up int
 *        @retval bit2: aon lpc1 wake up int
 *        @retval bit3: aon qdec wake up int
 *        @retval bit4: aon vadbuf wake up int
 *        @retval bit5: aon vad wake up int
 *        @retval bit6: aon usb wake up int
 *        @retval bit7: aon rtc wake up int
 *        @retval bit8: aon pf rtc wake up int
 */
uint32_t get_aon_wakeup_int(void);

/**
 * @brief Clear aon wake up int.
 * @retun none
 */
void clear_aon_wakeup_int(void);

/**
 * @brief Short pulse wakeup function.
 * @param Status: PAD_SHORT_PULSE_WAKEUP_DISABLE or PAD_SHORT_PULSE_WAKEUP_ENABLE.
 *        This parameter refer to PAD_SHORT_PULSE_WAKEUP_EN.
 * @retun None.
*/
void Pad_ShortPulseWakeUpCmd(PAD_SHORT_PULSE_WAKEUP_EN Status);


/** \} */ /* End of group PINMUX_Exported_Functions */

#ifdef __cplusplus
}
#endif

#endif /* RTL_PINMUX_H */

/******************* (C) COPYRIGHT 2021 Realtek Semiconductor *****END OF FILE****/

