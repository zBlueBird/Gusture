/**
*********************************************************************************************************
*               Copyright(c) 2020, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* \file     rtl_alias.h
* \brief    The header file of all peripherals internal alias.
* \details  To be compatible with the previous driver,create an alias file for the previous driver.
* \author   yuan
* \date     2020-06-19
* \version  v2.1.0
* *********************************************************************************************************
*/


#ifndef RTL_ALIAS_H
#define RTL_ALIAS_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * \cond        private
 * \brief       To be compatible with the previous driver.
 * \defgroup    GPIO abourt define Alias
 * \{
 */
#define GPIO_Mode_IN                GPIO_MODE_IN
#define GPIO_Mode_OUT               GPIO_MODE_OUT
#define GPIO_Mode_PushPull          GPIO_OUTPUT_PUSHPULL
#define GPIO_Mode_OpenDrain         GPIO_OUTPUT_OPENDRAIN
#define GPIO_INT_Trigger_LEVEL      GPIO_INT_TRIGGER_LEVEL
#define GPIO_INT_Trigger_EDGE       GPIO_INT_TRIGGER_EDGE

/**
 * \cond        private
 * \brief       To be compatible with the previous driver.
 * \defgroup    ADC_InitTypeDef_Alias ADC Init TypeDef Alias
 * \{
 */
#if 0
#define ADC_One_Shot_Mode           ADC_ONE_SHOT_MODE
#define schIndex                    ADC_SchIndex
#define bitmap                      ADC_Bitmap
#define adcSamplePeriod             ADC_SampleTime
#define PowerAlwaysOnEn             ADC_PowerAlwaysOnEn
#define dataWriteToFifo             ADC_DataWriteToFifo
#define timerTriggerEn              ADC_TimerTriggerEn
#endif
/**
 * \}
 * \endcond
 */

/**
 * \cond        private
 * \brief       To be compatible with the previous driver.
 * \defgroup    ADC_API_Alias ADC API Alias
 * \{
 */
#define ADC_ReadByScheduleIndex     ADC_ReadRawData
#define ADC_ReadFifoData            ADC_ReadFIFO
#define ADC_GetFifoData             ADC_ReadFIFOData
#define ADC_GetFifoLen              ADC_GetFIFODataLen
#define ADC_SchTableSet             ADC_BitMapConfig
#define ADC_PowerAlwaysOnCmd        ADC_ManualPowerOnCmd
#define ADC_FifoWriteCmd            ADC_WriteFIFOCmd
#define ADC_AnalogCircuitConfig     ADC_PowerSupplyConfig
#define ADC_GetIntFlagStatus        ADC_GetINTStatus
#define ADC_ClearFifo               ADC_ClearFIFO
#define ADC_GetIntStatus            ADC_GetAllFlagStatus

/**
 * \}
 * \endcond
 */

/**
 * \cond        private
 * \brief       To be compatible with the previous driver.
 * \defgroup    RTC_API_Alias RTC API Alias
 * \{
 */
#define RTC_SetComp                 RTC_SetCompValue
#define RTC_RunCmd                  RTC_Cmd
#define RTC_INT_CMP1                RTC_INT_COMP1

/**
 * \}
 * \endcond
 */

/**
 * \cond        private
 * \brief       To be compatible with the previous driver.
 * \defgroup    UART_InitTypeDef_Alias UART Init TypeDef Alias
 * \{
 */
#define ovsr_adj                    UART_OvsrAdj
#define div                         UART_Div
#define ovsr                        UART_Ovsr
#define wordLen                     UART_WordLen
#define parity                      UART_Parity
#define stopBits                    UART_StopBits
#define autoFlowCtrl                UART_HardwareFlowControl
#define txTriggerLevel              UART_TxThdLevel
#define rxTriggerLevel              UART_RxThdLevel
#define dmaEn                       UART_DmaEn
#define idle_time                   UART_IdleTime
#define TxWaterlevel                UART_TxWaterLevel
#define RxWaterlevel                UART_RxWaterLevel
#define TxDmaEn                     UART_TxDmaEn
#define RxDmaEn                     UART_RxDmaEn

#define UART_INT_LINE_STS           UART_INT_RX_LINE_STS
#define UART_INT_ID_RX_TMEOUT       UART_INT_ID_RX_DATA_TIMEOUT
#define UART_FLAG_THR_EMPTY         UART_FLAG_TX_FIFO_EMPTY
#define UART_FLAG_THR_TSR_EMPTY     UART_FLAG_TX_EMPTY
#define UART_FLAG_RX_DATA_RDY       UART_FLAG_RX_DATA_AVA

/**
 * \}
 * \endcond
 */

/**
 * \cond        private
 * \brief       To be compatible with the previous driver.
 * \defgroup    UART_API_Alias UART API Alias
 * \{
 */
#define UART_GetFlagState           UART_GetFlagStatus
#define UART_ChangeBaudRate         UART_SetBaudRate
#define UART_ChangeParams           UART_SetParams
#define UART_ClearTxFifo            UART_ClearTxFIFO
#define UART_ClearRxFifo            UART_ClearRxFIFO
#define UART_GetTxFIFOLen           UART_GetTxFIFODataLen
#define UART_GetRxFIFOLen           UART_GetRxFIFODataLen

/**
 * \}
 * \endcond
 */

/**
 * \cond        private
 * \brief       To be compatible with the previous driver.
 * \defgroup    QDEC_API_Alias QDEC API Alias
 * \{
 */
#define scanClockDiv                    QDEC_ScanClockDiv
#define debounceClockDiv                QDEC_DebounceClockDiv
#define axisConfigX                     QDEC_AxisConfigX
#define axisConfigY                     QDEC_AxisConfigY
#define axisConfigZ                     QDEC_AxisConfigZ
#define manualLoadInitPhase             QDEC_ManualLoadInitPhase
#define counterScaleX                   QDEC_CounterScaleX
#define counterScaleY                   QDEC_CounterScaleY
#define counterScaleZ                   QDEC_CounterScaleZ
#define debounceEnableX                 QDEC_DebounceEnableX
#define debounceEnableY                 QDEC_DebounceEnableY
#define debounceEnableZ                 QDEC_DebounceEnableZ
#define debounceTimeX                   QDEC_DebounceTimeX
#define debounceTimeY                   QDEC_DebounceTimeY
#define debounceTimeZ                   QDEC_DebounceTimeZ
#define initPhaseX                      QDEC_InitPhaseX
#define initPhaseY                      QDEC_InitPhaseY
#define initPhaseZ                      QDEC_InitPhaseZ
//#define Debounce_Enable                 ENABLE
//#define Debounce_Disable                DISABLE
//#define manualPhaseEnable               ENABLE
//#define manualPhaseDisable              DISABLE

/**
 * \}
 * \endcond
*/

/**
 * \cond        private
 * \brief       To be compatible with the previous driver.
 * \defgroup    I2C_InitTypeDef_Alias I2C Init TypeDef Alias
 * \{
 */
//#define I2C_Ack_Enable     ENABLE
//#define I2C_Ack_Disable    DISABLE
//#define I2C_STOP_ENABLE    ENABLE
//#define I2C_STOP_DISABLE   DISABLE

/**
 * \}
 * \endcond
 */

/**
 * \cond        private
 * \brief       To be compatible with the previous driver.
 * \defgroup    SPI_InitTypeDef_Alias SPI Init TypeDef Alias
 * \{
 */
//#define SPI_SWAP_ENABLE     ENABLE
//#define SPI_SWAP_DISABLE    DISABLE

/**
 * \}
 * \endcond
 */

/**
 * \cond        private
 * \brief       To be compatible with the previous driver.
 * \defgroup    KEYSCAN_InitTypeDef_Alias KEYSCAN Init TypeDef Alias
 * \{
 */
#define rowSize                            KEYSCAN_RowSize
#define colSize                            KEYSCAN_ColSize
#define scanInterval                       KEYSCAN_ScanInterval
#define debounceEn                         KEYSCAN_DebounceEn
#define scantimerEn                        KEYSCAN_ScantimerEn
#define detecttimerEn                      KEYSCAN_DetecttimerEn
#define detectMode                         KEYSCAN_DetectMode
#define fifoOvrCtrl                        KEYSCAN_FifoOvrCtrl
#define scanmode                           KEYSCAN_ScanMode
#define clockdiv                           KEYSCAN_ClockDiv
#define delayclk                           KEYSCAN_DelayClk
#define fifotriggerlevel                   KEYSCAN_FifoTriggerLevel
#define debouncecnt                        KEYSCAN_DebounceCnt
#define releasecnt                         KEYSCAN_ReleaseCnt
#define keylimit                           KEYSCAN_Keylimit
#define manual_sel                         KEYSCAN_ManualSel
//#define KeyScan_Debounce_Enable            ENABLE
//#define KeyScan_Debounce_Disable           DISABLE
//#define KeyScan_ScanInterval_Enable        ENABLE
//#define KeyScan_ScanInterval_Disable       DISABLE
//#define KeyScan_Release_Detect_Enable      ENABLE
//#define KeyScan_Release_Detect_Disable     DISABLE

/**
 * \}
 * \endcond
 */

/**
 * \cond        private
 * \brief       To be compatible with the previous driver.
 * \defgroup    TIM_InitTypeDef_Alias TIM Init TypeDef Alias
 * \{
 */
//#define PWM_ENABLE                   ENABLE
//#define PWM_DISABLE                  DISABLE
//#define DEADZONE_ENABLE              ENABLE
//#define DEADZONE_DISABLE             DISABLE
/**
 * \}
 * \endcond
 */

/**
 * \cond        private
 * \brief       To be compatible with the previous driver.
 * \defgroup    TIM_API_Alias TIM API Alias
 * \{
 */
#define TIM_GetOperationStatus      TIM_GetStatus
/**
 * \}
 * \endcond
 */

/**
 * \cond        private
 * \brief       To be compatible with the previous driver.
 * \defgroup    ENHTIM_InitTypeDef_Alias ENHTIM Init TypeDef Alias
 * \{
 */
//#define ENHTIM_PWM_ENABLE                  ENABLE
//#define ENHTIM_PWM_DISABLE                 DISABLE
//#define ENHTIM_PWM_DEADZONE_ENABLE         ENABLE
//#define ENHTIM_PWM_DEADZONE_DISABLE        DISABLE
//#define ENHTIM_LATCH_COUNT_ENABLE          ENABLE
//#define ENHTIM_LATCH_COUNT_DISABLE         DISABLE
//#define ENHTIM_DMA_ENABLE                  ENABLE
//#define ENHTIM_DMA_DISABLE                 DISABLE
/**
 * \}
 * \endcond
 */

#ifdef __cplusplus
}
#endif

#endif /* RTL_ALIAS_H */



/******************* (C) COPYRIGHT 2020 Realtek Semiconductor *****END OF FILE****/



