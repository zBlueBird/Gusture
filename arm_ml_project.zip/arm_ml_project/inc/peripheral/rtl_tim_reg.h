/**
**********************************************************************************************************
*               Copyright(c) 2023, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* @file     rtl_tim_reg.h
* @brief    TIMER_register_table
* @details
* @author   grace_ysn
* @date     2023.02.17
* @version  v1.0.0
*********************************************************************************************************
*/
#ifndef RTL_TIM_REG_H
#define RTL_TIM_REG_H

#include <stdint.h>
#include <stdbool.h>
#include "rtl876x.h"

#ifdef  __cplusplus
extern "C" {
#endif /* __cplusplus */

/*============================================================================*
 *                         TIMER Registers Memory Map
 *============================================================================*/
typedef struct
{
    __IO uint32_t TIMER_LOADCOUNT;        /*!< 0x00 */
    __I  uint32_t TIMER_CURRENTVALUE;     /*!< 0x04 */
    __IO uint32_t TIMER_CONTROLREG;       /*!< 0x08 */
    __I  uint32_t TIMER_EOI;              /*!< 0x0C */
    __I  uint32_t TIMER_INTSTATUS;        /*!< 0x10 */
} TIM_TypeDef;

typedef struct
{
    __IO uint32_t TIMER_B_PWM_WRAP_CFG;   /*!< 0x260 */
} PWM_TypeDef;
/*============================================================================*
 *                         TIMER Declaration
 *============================================================================*/
//#define TIMA_0             ((TIM_TypeDef *) TIMER_A0_REG_BASE)
//#define TIMA_1             ((TIM_TypeDef *) TIMER_A1_REG_BASE)
//#define TIMA_2             ((TIM_TypeDef *) TIMER_A2_REG_BASE)
#define TIMB_0             ((TIM_TypeDef *) TIMER_B0_REG_BASE)
#define TIMB_1             ((TIM_TypeDef *) TIMER_B1_REG_BASE)
#define TIMB_2             ((TIM_TypeDef *) TIMER_B2_REG_BASE)
#define TIMB_3             ((TIM_TypeDef *) TIMER_B3_REG_BASE)
#define PWMB_0             ((PWM_TypeDef *) TIMER_B0_PWM_REG_BASE)
#define PWMB_1             ((PWM_TypeDef *) TIMER_B1_PWM_REG_BASE)
#define PWMB_2             ((PWM_TypeDef *) TIMER_B2_PWM_REG_BASE)
#define PWMB_3             ((PWM_TypeDef *) TIMER_B3_PWM_REG_BASE)
#define TIMC_0             ((TIM_TypeDef *) TIMER_C0_REG_BASE)
#define TIMC_1             ((TIM_TypeDef *) TIMER_C1_REG_BASE)
#define TIMC_2             ((TIM_TypeDef *) TIMER_C2_REG_BASE)
#define TIMC_3             ((TIM_TypeDef *) TIMER_C3_REG_BASE)
#define TIMC_4             ((TIM_TypeDef *) TIMER_C4_REG_BASE)
#define TIMC_5             ((TIM_TypeDef *) TIMER_C5_REG_BASE)
//#define TIM0               TIMA_0
//#define TIM1               TIMA_1
//#define TIM2               TIMA_2
#define TIM3               TIMB_0
#define TIM4               TIMB_1
#define TIM5               TIMB_2
#define TIM6               TIMB_3
#define TIM7               TIMC_0
#define TIM8               TIMC_1
#define TIM9               TIMC_2
#define TIM10              TIMC_3
#define TIM11              TIMC_4
#define TIM12              TIMC_5

/*============================================================================*
 *                         TIMER Registers and Field Descriptions
 *============================================================================*/
/* 0x00
   31:0    R/W    TimerNLoadCount                     0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t TimerNLoadCount: 32;
    } b;
} TIMER_LOADCOUNT_t;



/* 0x04
   31:0    R      TimerNCurrentValue                  0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t TimerNCurrentValue: 32;
    } b;
} TIMER_CURRENTVALUE_t;



/* 0x08
   0       R/W    TimerEnable                         0x0
   1       R/W    TimerMode                           0x0
   2       R/W    TimerInterruptMask                  0x0
   3       R/W    TIMER_PWM                           0x0
   31:4    R      Reserved                            0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t TimerEnable: 1;
        __IO uint32_t TimerMode: 1;
        __IO uint32_t TimerInterruptMask: 1;
        __IO uint32_t TIMER_PWM: 1;
        __I uint32_t reserved_0: 28;
    } b;
} TIMER_CONTROLREG_t;



/* 0x0C
   0       R      TimerNEndofInterrupt                0x0
   31:1    R      Reserved                            0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t TimerNEndofInterrupt: 1;
        __I uint32_t reserved_0: 31;
    } b;
} TIMER_EOI_t;



/* 0x10
   0       R      TimerNInterruptStatus               0x0
   31:1    R      Reserved                            0x0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t TimerNInterruptStatus: 1;
        __I uint32_t reserved_0: 31;
    } b;
} TIMER_INTSTATUS_t;



/* 0x260
   7:0     R/W    timer_b_pwm_dead_zone_size        8'h0
   8       R/W    timer_b_pwm_emg_stop              1'h0
   9       R/W    timer_b_pwm_stop_state[0]         1'h0
   10      R/W    timer_b_pwm_stop_state[1]         1'h0
   11      R/W    timer_b_pwm_dummy_b11             1'h0
   12      R/W    timer_b_pwm_dead_zone_en          1'h0
   13      R/W    timer_b_pwm_pwm_pn_invserse_sel   1'h0
   14      R/W    timer_b_pwm_dummy_b14             1'h0
   15      R/W    timer_b_pwm_dummy_b15             1'h0
   31:16   R      RSVD                              16'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t timer_b_pwm_dead_zone_size: 8;
        __IO uint32_t timer_b_pwm_emg_stop: 1;
        __IO uint32_t timer_b_pwm_stop_state_0: 1;
        __IO uint32_t timer_b_pwm_stop_state_1: 1;
        __IO uint32_t timer_b_pwm_dummy_b11: 1;
        __IO uint32_t timer_b_pwm_dead_zone_en: 1;
        __IO uint32_t timer_b_pwm_pwm_pn_invserse_sel: 1;
        __IO uint32_t timer_b_pwm_dummy_b14: 1;
        __IO uint32_t timer_b_pwm_dummy_b15: 1;
        __I uint32_t reserved_0: 16;
    } b;
} TIMER_B_PWM_WRAP_CFG_t;



#ifdef  __cplusplus
}
#endif /* __cplusplus */
#endif /* RTL_TIM_REG_H */
