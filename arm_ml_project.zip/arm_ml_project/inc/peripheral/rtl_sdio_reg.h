#ifndef RTL_SDIO_REG_H
#define RTL_SDIO_REG_H

#include <stdint.h>
#include "rtl876x.h"

#ifdef  __cplusplus
extern "C" {
#endif

/*============================================================================*
 *                         SDIO Registers Memory Map
 *============================================================================*/
typedef struct
{
    __IO uint32_t CTRL;                   /*!< 0x00 */
    __IO uint32_t PWREN;                  /*!< 0x04 */
    __IO uint32_t CLKDIV;                 /*!< 0x08 */
    __IO uint32_t CLKSRC;                 /*!< 0x0C */
    __IO uint32_t CLKENA;                 /*!< 0x10 */
    __IO uint32_t TMOUT;                  /*!< 0x14 */
    __IO uint32_t CTYPE;                  /*!< 0x18 */
    __IO uint32_t BLKSIZ;                 /*!< 0x1C */
    __IO uint32_t BYTCNT;                 /*!< 0x20 */
    __IO uint32_t INTMASK;                /*!< 0x24 */
    __IO uint32_t CMDARG;                 /*!< 0x28 */
    __IO uint32_t CMD;                    /*!< 0x2C */
    __I  uint32_t RESP0;                  /*!< 0x30 */
    __I  uint32_t RESP1;                  /*!< 0x34 */
    __I  uint32_t RESP2;                  /*!< 0x38 */
    __I  uint32_t RESP3;                  /*!< 0x3C */
    __I  uint32_t MINTSTS;                /*!< 0x40 */
    __IO uint32_t RINTSTS;                /*!< 0x44 */
    __I  uint32_t STATUS;                 /*!< 0x48 */
    __IO uint32_t FIFOTH;                 /*!< 0x4C */
    __I  uint32_t CDETECT;                /*!< 0x50 */
    __I  uint32_t WRTPRT;                 /*!< 0x54 */
    __IO uint32_t GPIO;                   /*!< 0x58 */
    __I  uint32_t TCBCNT;                 /*!< 0x5C */
    __I  uint32_t TBBCNT;                 /*!< 0x60 */
    __IO uint32_t DEBNCE;                 /*!< 0x64 */
    __IO uint32_t USRID;                  /*!< 0x68 */
    __I  uint32_t VERID;                  /*!< 0x6C */
    __I  uint32_t HCON;                   /*!< 0x70 */
    __IO uint32_t UHS_REG;                /*!< 0x74 */
    __IO uint32_t RST_n;                  /*!< 0x78 */
    __I  uint32_t Reserved0;              /*!< 0x7C */
    __IO uint32_t BMOD;                   /*!< 0x80 */
    __O  uint32_t PLDMND;                 /*!< 0x84 */
    __IO uint32_t DBADDR;                 /*!< 0x88 */
    __IO uint32_t IDSTS;                  /*!< 0x8C */
    __IO uint32_t IDINTEN;                /*!< 0x90 */
    __I  uint32_t DSCADDR;                /*!< 0x94 */
    __I  uint32_t BUFADDR;                /*!< 0x98 */
    __I  uint8_t Reserved1[0x100 - 0x9C]; /*!< 0x9C */
    __IO uint32_t CardThrCtl;             /*!< 0x100 */
    __IO uint32_t Back_end_power;         /*!< 0x104 */
    __IO uint32_t UHS_REG_EXT;            /*!< 0x108 */
    __IO uint32_t EMMC_DDR_REG;           /*!< 0x10C */
    __IO uint32_t ENABLE_SHIFT;           /*!< 0x110 */
    __IO uint8_t Reserved2[0x100 - 0x14]; /*!< 0x114 */
    __IO uint32_t DATA;                   /*!< >=0x200 */
} SDIO_TypeDef;

/*============================================================================*
 *                         SDIO Declaration
 *============================================================================*/
#define SDIO0              ((SDIO_TypeDef *) SDIO_HOST0_CFG_REG_BASE)
#define SDIO1              ((SDIO_TypeDef *) SDIO_HOST1_CFG_REG_BASE)

/*============================================================================*
 *                         SDIO Registers and Field Descriptions
 *============================================================================*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t controller_reset: 1;
        uint32_t fifo_reset: 1;
        uint32_t dma_reset: 1;
        uint32_t Reserved0: 1;
        uint32_t int_enable: 1;
        uint32_t dma_enable: 1;
        uint32_t read_wait: 1;
        uint32_t send_irq_response: 1;
        uint32_t abort_read_data: 1;
        uint32_t send_ccsd: 1;
        uint32_t send_auto_stop_ccsd: 1;
        uint32_t ceata_device_interrupt_status: 1;

        uint32_t Reserved1: 4;
        uint32_t Card_voltage_a: 4;
        uint32_t Card_voltage_b: 4;

        uint32_t enable_OD_pullup: 1;
        uint32_t use_internal_dmac: 1;
        uint32_t Reserved2: 6;
    } b;
} CTRL_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t power_enable: 30;
        uint32_t Reserved: 2;
    } b;
} PWREN_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t clk_divider0: 8;
        uint32_t clk_divider1: 8;
        uint32_t clk_divider2: 8;
        uint32_t clk_divider3: 8;
    } b;
} CLKDIV_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t cclk_enable : 16;
        uint32_t cclk_low_power : 16;
    } b;
} CLKENA_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t response_timeout : 8;
        uint32_t data_timeout : 24;
    } b;
} TMOUT_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t card_width0 : 16;
        uint32_t card_width1 : 16;
    } b;
} CTYPE;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t block_size : 16;
        uint32_t Reserved : 16;
    } b;
} BLKSIZ_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t CardDetect: 1;
        uint32_t ResponseError: 1;
        uint32_t CommandDone: 1;
        uint32_t DataTransferOver: 1;

        uint32_t TransmitFifoDataRequest: 1;
        uint32_t ReceiveFifoDataRequest: 1;
        uint32_t ResponseCrcError: 1;
        uint32_t DataCrcError: 1;

        uint32_t ResponseTimeout: 1;
        uint32_t DataReadTimeout: 1;
        uint32_t DataStarvatioByHostTimeout_VoltSwitchInt: 1;
        uint32_t FifoUnderrunOverrunError: 1;

        uint32_t HardwareLockedWriteError: 1;
        uint32_t StartBitError_BusyClearInterrupt: 1;
        uint32_t AutoCommandDone: 1;
        uint32_t EndBitError_WriteNoCrc: 1;

        uint32_t sdio_int_mask: 16;
    } b;
} INTMASK_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t cmd_index: 6;

        uint32_t response_expect: 1;
        uint32_t response_length: 1;
        uint32_t check_response_crc: 1;
        uint32_t data_expected: 1;
        uint32_t read_write: 1;
        uint32_t transfer_mode: 1;
        uint32_t send_auto_stop: 1;
        uint32_t wait_prvdata_complete: 1;
        uint32_t stop_abort_cmd: 1;
        uint32_t send_initialization: 1;

        uint32_t card_number: 5;

        uint32_t update_clock_registers_only: 1;
        uint32_t read_ceata_device: 1;
        uint32_t ccs_expected: 1;
        uint32_t enable_boot: 1;
        uint32_t expect_boot_ack: 1;
        uint32_t disable_boot: 1;
        uint32_t boot_mode: 1;
        uint32_t volt_switch: 1;
        uint32_t use_hold_reg: 1;
        uint32_t Reserved: 1;
        uint32_t start_cmd: 1;
    } b;
} CMD_t;

#define READ_DATA 0
#define WRITE_DATA 1

#define BLOCK_TRANSFER 0
#define STREAM_TRANSFER 1

#define SHORT_RESPONSE 0
#define LONG_RESPONSE 1


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t CardDetect: 1;
        uint32_t ResponseError: 1;
        uint32_t CommandDone: 1;
        uint32_t DataTransferOver: 1;

        uint32_t TransmitFifoDataRequest: 1;
        uint32_t ReceiveFifoDataRequest: 1;
        uint32_t ResponseCrcError: 1;
        uint32_t DataCrcError: 1;

        uint32_t ResponseTimeout: 1;
        uint32_t DataReadTimeout: 1;
        uint32_t DataStarvatioByHostTimeout_VoltswitchInt: 1;
        uint32_t FifoUnderrunOverrunError: 1;

        uint32_t HardwareLockedWriteError: 1;
        uint32_t StartBitError_BusyClearInterrupt: 1;
        uint32_t AutoCommandDone: 1;
        uint32_t EndBitError_WriteNoCrc: 1;

        uint32_t sdio_interrupt: 16;
    } b;
} MINTSTS_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t CardDetect: 1;
        uint32_t ResponseError: 1;
        uint32_t CommandDone: 1;
        uint32_t DataTransferOver: 1;

        uint32_t TransmitFifoDataRequest: 1;
        uint32_t ReceiveFifoDataRequest: 1;
        uint32_t ResponseCrcError: 1;
        uint32_t DataCrcError: 1;

        uint32_t ResponseTimeout: 1;
        uint32_t DataReadTimeout: 1;
        uint32_t DataStarvatioByHostTimeout_VoltswitchInt: 1;
        uint32_t FifoUnderrunOverrunError: 1;

        uint32_t HardwareLockedWriteError: 1;
        uint32_t StartBitError_BusyClearInterrupt: 1;
        uint32_t AutoCommandDone: 1;
        uint32_t EndBitError_WriteNoCrc: 1;

        uint32_t sdio_interrupt: 16;
    } b;
} RINTSTS_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t fifo_rx_watermark: 1;
        uint32_t fifo_tx_watermark: 1;
        uint32_t fifo_empty: 1;
        uint32_t fifo_full: 1;

        uint32_t command_fsm_states: 4;

        uint32_t data_3_status: 1;
        uint32_t data_busy: 1;
        uint32_t data_state_mc_busy: 1;

        uint32_t response_index: 6;
        uint32_t fifo_count: 13;

        uint32_t dma_ack: 1;
        uint32_t dma_req: 1;
    } b;
} STATUS_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t TX_WMark: 12;
        uint32_t Reserved0: 4;
        uint32_t RX_WMark: 12;
        uint32_t DW_DMA_Multiple_Transaction_Size: 3;
        uint32_t Reserved1: 1;
    } b;
} FIFOTH_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t card_detect_n: 30;
        uint32_t Reserved: 2;
    } b;
} CDETECT_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t write_protect: 30;
        uint32_t Reserved: 2;
    } b;
} CDETECTWRTPRT_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t gpi: 8;
        uint32_t gpo: 16;
        uint32_t Reserved: 8;
    } b;
} GPIO_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t debounce_count: 24;
        uint32_t Reserved: 8;
    } b;
} DEBNCE_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t VOLT_REG: 16;
        uint32_t DDR_REG: 16;
    } b;
} UHS_REG_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t CARD_RESET: 16;
        uint32_t Reserved: 16;
    } b;
} RST_n_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t SWR: 1;
        uint32_t FB: 1;
        uint32_t DSL: 5;
        uint32_t DE: 1;
        uint32_t PBL: 3;
        uint32_t Reserved: 21;
    } b;
} BMOD_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t TI: 1;
        uint32_t RI: 1;
        uint32_t FBE: 1;
        uint32_t Reserved0: 1;
        uint32_t DU: 1;
        uint32_t CES: 1;

        uint32_t Reserved1: 2;
        uint32_t NIS: 1;
        uint32_t AIS: 1;
        uint32_t FBE_CODE: 3;
        uint32_t FSM: 4;
        uint32_t Reserved2: 5;
    } b;
} IDSTS_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t TI: 1;
        uint32_t RI: 1;
        uint32_t FBE: 1;
        uint32_t Reserved0: 1;
        uint32_t DU: 1;
        uint32_t CES: 1;

        uint32_t Reserved1: 2;
        uint32_t NI: 1;
        uint32_t AI: 1;
        uint32_t Reserved2: 12;
    } b;
} IDINTEN_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t CardRdThrEn: 1;
        uint32_t BsyClrIntEn: 1;
        uint32_t CardWrThrEn: 1;
        uint32_t Reserved0: 13;
        uint32_t CardThreshold: 12;
        uint32_t Reserved1: 4;
    } b;
} CardThrCtl_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t back_end_power: 16;
        uint32_t Reserved: 16;
    } b;
} Back_end_power_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t MMC_VOLT_REG: 16;
        uint32_t CLK_SMPL_PHASE_CTRL: 7;
        uint32_t CLK_DRV_PHASE_CTRL: 7;
        uint32_t EXT_CLK_MUX_CTRL: 2;
    } b;
} UHS_REG_EXT_t;


typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t HALF_START_BIT: 16;
        uint32_t Reserved: 15;
        uint32_t hs400_mode: 1;
    } b;
} EMMC_DDR_REG_t;

typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        uint32_t sdio1_ck_en: 1;
        uint32_t sdio1_func_en: 1;
        uint32_t r_sdio1_clk_src_en: 1;
        uint32_t r_sdio1_div_sel: 4;
        uint32_t r_sdio1_div_en: 1;
        uint32_t r_sdio1_mux_clk_cg_en: 1;
        uint32_t r_sdio1_clk_src_sel: 1;
        uint32_t rsv1: 6;

        uint32_t sdio0_ck_en: 1;
        uint32_t sdio0_func_en: 1;
        uint32_t r_sdio0_clk_src_en: 1;
        uint32_t r_sdio0_div_sel: 4;
        uint32_t r_sdio0_div_en: 1;
        uint32_t r_sdio0_mux_clk_cg_en: 1;
        uint32_t r_sdio0_clk_src_sel: 1;
        uint32_t rsv0: 6;
    } b;
} SdhCtl_t;
#define SDH_CTL_REG  (*(volatile uint32_t *)0x400e21e8)

typedef union
{
    uint32_t d32;
    struct
    {
        uint32_t r_sdh0_drv_dly_sel: 8;
        uint32_t r_sdh0_sample_dly_sel: 8;
        uint32_t r_sdh0_clk_sel_drv: 2;
        uint32_t r_sdh0_clk_sel_sample: 2;
        uint32_t r_sdh0_bypass_shift_drv: 1;
        uint32_t r_sdh0_bypass_shift_sample: 1;
        uint32_t r_sdh0_bypass_delay_drv: 1;
        uint32_t r_sdh0_bypass_delay_sample: 1;
        uint32_t r_sdh0_clk_out_dly_sel: 8;
    } b;
} Sdh0Phy0_t;
#define SDH0_PHY0_REG  (*(volatile uint32_t *)0x400e21eC)

#define CLKSRC_CLK_40M_VCORE4  0
#define CLKSRC_CKO1_PLL4_VCORE4  1


typedef struct
{
    struct
    {
        uint32_t Reserved0: 1;
        uint32_t DisableInterruptOnCompletion: 1;
        uint32_t LastDescriptor: 1;
        uint32_t FirstDescriptor: 1;
        uint32_t SecondAddressChained: 1;
        uint32_t EndOfRing: 1;
        uint32_t Reserved1: 24;
        uint32_t CardErrorSummary: 1;
        uint32_t OWN: 1;
    } DES0;
    struct
    {
        uint32_t Buffer1Size: 13;
        uint32_t Buffer2Size: 13;
        uint32_t Reserved: 6;
    } DES1;
    struct
    {
        uint32_t BufferAddressPointer1: 32;
    } DES2;
    struct
    {
        uint32_t BufferAddressPointer2: 32;
    } DES3;
} __attribute__((packed)) DmaDesc_t;

#define OWN_BY_DMA 1
#define OWN_BY_HOST 0



#ifdef  __cplusplus
}
#endif
#endif // RTL_SDIO_REG_H
