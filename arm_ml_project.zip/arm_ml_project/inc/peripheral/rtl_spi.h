/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* \file     rtl_spi.h
* \brief    The header file of the peripheral SPI driver.
* \details  This file provides all SPI firmware functions.
* \author   yuzhuo_liu
* \date     2023-02-14
* \version  v1.0
* *********************************************************************************************************
*/

#ifndef RTL_SPI_H
#define RTL_SPI_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * \addtogroup  IO          Peripheral Drivers
 * \defgroup    SPI         SPI
 *
 * \brief       Manage the SPI peripheral functions.
 *
 * \ingroup     IO
 */

/*============================================================================*
 *                         Includes
 *============================================================================*/
#include "rtl876x.h"
#include "rtl_spi_reg.h"
#include "rtl_alias.h"

/*============================================================================*
 *                         Constants
 *============================================================================*/
/**
 * \defgroup    SPI_Exported_Constants Macro Definitions
 *
 * \ingroup     SPI
 */
#define IS_SPI_ALL_PERIPH(PERIPH) (((PERIPH) == SPI0) || \
                                   ((PERIPH) == SPI1) || \
                                   ((PERIPH) == SPI2) || \
                                   ((PERIPH) == SPI3) || \
                                   ((PERIPH) == SPI0_SLAVE))
#define SPI_TX_FIFO_SIZE                   64
#define SPI_RX_FIFO_SIZE                   64
#define SPI0_SLAVE_TX_FIFO_SIZE            63

#define IS_SPI_CLOCK_SPEED(SPEED) (((SPEED) >= 0x01) && ((SPEED) <= 40000000))

/*============================================================================*
 *                         Types
 *============================================================================*/
/**
 * \defgroup    SPI_Data_Direction SPI Data Direction
 * \{
 * \ingroup     SPI_Exported_Constants
 */
typedef enum
{
    SPI_Direction_FullDuplex = 0x00,
    SPI_Direction_TxOnly     = 0x01,
    SPI_Direction_RxOnly     = 0x02,
    SPI_Direction_EEPROM     = 0x03,
} SPI_DATA_DIRECTION_T;
#define IS_SPI_DIRECTION_MODE(MODE) (((MODE) == SPI_Direction_FullDuplex) || \
                                     ((MODE) == SPI_Direction_RxOnly) || \
                                     ((MODE) == SPI_Direction_TxOnly) || \
                                     ((MODE) == SPI_Direction_EEPROM))
/** \} */

/**
 * \defgroup    SPI_Data_Size SPI Data Size
 * \{
 * \ingroup     SPI_Exported_Constants
 */
typedef enum
{
    SPI_DataSize_4b  = 0x03,
    SPI_DataSize_5b  = 0x04,
    SPI_DataSize_6b  = 0x05,
    SPI_DataSize_7b  = 0x06,
    SPI_DataSize_8b  = 0x07,
    SPI_DataSize_9b  = 0x08,
    SPI_DataSize_10b = 0x09,
    SPI_DataSize_11b = 0x0a,
    SPI_DataSize_12b = 0x0b,
    SPI_DataSize_13b = 0x0c,
    SPI_DataSize_14b = 0x0d,
    SPI_DataSize_15b = 0x0e,
    SPI_DataSize_16b = 0x0f,
    SPI_DataSize_17b = 0x10,
    SPI_DataSize_18b = 0x11,
    SPI_DataSize_19b = 0x12,
    SPI_DataSize_20b = 0x13,
    SPI_DataSize_21b = 0x14,
    SPI_DataSize_22b = 0x15,
    SPI_DataSize_23b = 0x16,
    SPI_DataSize_24b = 0x17,
    SPI_DataSize_25b = 0x18,
    SPI_DataSize_26b = 0x19,
    SPI_DataSize_27b = 0x1A,
    SPI_DataSize_28b = 0x1B,
    SPI_DataSize_29b = 0x1C,
    SPI_DataSize_30b = 0x1D,
    SPI_DataSize_31b = 0x1E,
    SPI_DataSize_32b = 0x1F,
} SPI_DATA_SIZE_T;
#define IS_SPI_DATASIZE(DATASIZE) (((DATASIZE) == SPI_DataSize_4b)  || \
                                   ((DATASIZE) == SPI_DataSize_5b)  || \
                                   ((DATASIZE) == SPI_DataSize_6b)  || \
                                   ((DATASIZE) == SPI_DataSize_7b)  || \
                                   ((DATASIZE) == SPI_DataSize_8b)  || \
                                   ((DATASIZE) == SPI_DataSize_9b)  || \
                                   ((DATASIZE) == SPI_DataSize_10b) || \
                                   ((DATASIZE) == SPI_DataSize_11b) || \
                                   ((DATASIZE) == SPI_DataSize_12b) || \
                                   ((DATASIZE) == SPI_DataSize_13b) || \
                                   ((DATASIZE) == SPI_DataSize_14b) || \
                                   ((DATASIZE) == SPI_DataSize_15b) || \
                                   ((DATASIZE) == SPI_DataSize_16b) || \
                                   ((DATASIZE) == SPI_DataSize_17b) || \
                                   ((DATASIZE) == SPI_DataSize_18b) || \
                                   ((DATASIZE) == SPI_DataSize_19b) || \
                                   ((DATASIZE) == SPI_DataSize_20b) || \
                                   ((DATASIZE) == SPI_DataSize_21b) || \
                                   ((DATASIZE) == SPI_DataSize_22b) || \
                                   ((DATASIZE) == SPI_DataSize_23b) || \
                                   ((DATASIZE) == SPI_DataSize_24b) || \
                                   ((DATASIZE) == SPI_DataSize_25b) || \
                                   ((DATASIZE) == SPI_DataSize_26b) || \
                                   ((DATASIZE) == SPI_DataSize_27b) || \
                                   ((DATASIZE) == SPI_DataSize_28b) || \
                                   ((DATASIZE) == SPI_DataSize_29b) || \
                                   ((DATASIZE) == SPI_DataSize_30b) || \
                                   ((DATASIZE) == SPI_DataSize_31b) || \
                                   ((DATASIZE) == SPI_DataSize_32b))
/** \} */

/**
 * \defgroup    SPI_Clock_Polarity SPI Clock Polarity
 * \{
 * \ingroup     SPI_Exported_Constants
 */
typedef enum
{
    SPI_CPOL_Low = 0x00,
    SPI_CPOL_High = 0x01,
} SPI_CLOCK_POLARITY_T;
#define IS_SPI_CPOL(CPOL) (((CPOL) == SPI_CPOL_Low) || \
                           ((CPOL) == SPI_CPOL_High))
/** \} */

/**
 * \defgroup    SPI_Clock_Phase SPI Clock Phase
 * \{
 * \ingroup     SPI_Exported_Constants
 */
typedef enum
{
    SPI_CPHA_1Edge = 0x00,
    SPI_CPHA_2Edge = 0x01,
} SPI_CLOCK_PHASE_T;
#define IS_SPI_CPHA(CPHA) (((CPHA) == SPI_CPHA_1Edge) || \
                           ((CPHA) == SPI_CPHA_2Edge))
/** \} */

/**
 * \defgroup    SPI_BaudRate_Prescaler SPI BaudRate Prescaler Value
 * \{
 * \ingroup     SPI_Exported_Constants
 */
#define SPI_BaudRatePrescaler_2      0x02
#define SPI_BaudRatePrescaler_4      0x04
#define SPI_BaudRatePrescaler_6      0x06
#define SPI_BaudRatePrescaler_8      0x08
#define SPI_BaudRatePrescaler_10     0x0A
#define SPI_BaudRatePrescaler_12     0x0C
#define SPI_BaudRatePrescaler_14     0x0E
#define SPI_BaudRatePrescaler_16     0x10
#define SPI_BaudRatePrescaler_32     0x20
#define SPI_BaudRatePrescaler_64     0x40
#define SPI_BaudRatePrescaler_128    0x80
#define SPI_BaudRatePrescaler_256    0x100
#define IS_SPI_BAUDRATE_PRESCALER(PRESCALER) ((PRESCALER) <= 0xFFFF)
/** \} */

/**
 * \defgroup    SPI_Swap_Enable SPI Swap Enable
 * \{
 * \ingroup     SPI_Exported_Constants
 */
#define IS_SPI_SWAPMODE(mode) (((mode) == DISABLE) || \
                               ((mode) == ENABLE))
/** \} */


/**
 * \defgroup    SPI_Frame_Format SPI Frame Format
 * \{
 * \ingroup     SPI_Exported_Constants
 */
typedef enum
{
    SPI_Frame_Motorola      = 0x00,
    SPI_Frame_TI_SSP        = 0x01,
    SPI_Frame_NS_MICROWIRE  = 0x02,
    SPI_Frame_Reserve       = 0x03,
} SPI_FRAME_FORMAT_T;
#define IS_SPI_FRAME_FORMAT(FRAME) (((FRAME) == SPI_Frame_Motorola) || \
                                    ((FRAME) == SPI_Frame_TI_SSP) || \
                                    ((FRAME) == SPI_Frame_NS_MICROWIRE) || \
                                    ((FRAME) == SPI_Frame_Reserve))
/** \} */

/**
 * \defgroup    SPI_GDMA_Transfer_Request SPI GDMA Transfer Request
 * \{
 * \ingroup     SPI_Exported_Constants
 */
typedef enum
{
    SPI_GDMAReq_Rx = 0x01,
    SPI_GDMAReq_Tx = 0x02,
} SPI_GDMA_TRANSFER_REQUESTS_T;
#define IS_SPI_GDMAREQ(GDMAREQ) (((GDMAREQ)  == SPI_GDMAReq_Rx) || \
                                 ((GDMAREQ) == SPI_GDMAReq_Tx))
/** \} */

/**
 * \defgroup    SPI_Flags_Definition SPI Flags Definition
 * \{
 * \ingroup     SPI_Exported_Constants
 */
#define SPI_FLAG_BUSY                   BIT0
#define SPI_FLAG_TFNF                   BIT1
#define SPI_FLAG_TFE                    BIT2
#define SPI_FLAG_RFNE                   BIT3
#define SPI_FLAG_RFF                    BIT4
#define SPI_FLAG_TXE                    BIT5
#define SPI_FLAG_DCOL                   BIT6
#define IS_SPI_GET_FLAG(FLAG)   (((FLAG) == SPI_FLAG_DCOL) || \
                                 ((FLAG) == SPI_FLAG_TXE) || \
                                 ((FLAG) == SPI_FLAG_RFF) || \
                                 ((FLAG) == SPI_FLAG_RFNE) || \
                                 ((FLAG) == SPI_FLAG_TFE) || \
                                 ((FLAG) == SPI_FLAG_TFNF) || \
                                 ((FLAG) == SPI_FLAG_BUSY))
/** \} */

/**
 * \defgroup    SPI_Interrupt_Definition SPI Interrupt Definition
 * \{
 * \ingroup     SPI_Exported_Constants
 */

#define SPI_INT_TXE                    BIT0
#define SPI_INT_TXO                    BIT1
#define SPI_INT_RXU                    BIT2
#define SPI_INT_RXO                    BIT3
#define SPI_INT_RXF                    BIT4
#define SPI_INT_MST                    BIT5  //only MASTER
#define SPI_INT_FAE                    BIT5  //only SLAVE
#define SPI_INT_TUF                    BIT6  //only SLAVE
#define SPI_INT_RIG                    BIT7  //only SLAVE
#define IS_SPI_CONFIG_IT(IT) (((IT) == SPI_INT_TXE) || \
                              ((IT) == SPI_INT_TXO) || \
                              ((IT) == SPI_INT_RXU) || \
                              ((IT) == SPI_INT_RXO) || \
                              ((IT) == SPI_INT_RXF) || \
                              ((IT) == SPI_INT_MST) || \
                              ((IT) == SPI_INT_FAE) || \
                              ((IT) == SPI_INT_TUF) || \
                              ((IT) == SPI_INT_RIG) )
/** \} */

/**
 * \defgroup    SPI_Exported_Types Init Params Struct
 *
 * \ingroup     SPI
 */

/**
 * \brief       SPI init structure definition.
 *
 * \ingroup     SPI_Exported_Types
 */

typedef struct
{
    SPI_DATA_DIRECTION_T SPI_Direction;        /*!< Specifies the SPI unidirectional
                                                    or bidirectional data mode. */

    uint32_t SPI_NDF;                          /*!< Specifies the trigger condition in EEPROM mode.
                                                    This parameter should be the value of the length of read data, from 1 to 65536. */

    SPI_DATA_SIZE_T SPI_DataSize;              /*!< Specifies the SPI data size. */

    SPI_CLOCK_POLARITY_T SPI_CPOL;             /*!< Specifies the serial clock steady state. */

    SPI_CLOCK_PHASE_T SPI_CPHA;                /*!< Specifies clock active edge for bit capture. */

    SPI_FRAME_FORMAT_T
    SPI_FrameFormat;        /*!< Specifies which serial protocol transfers the data. */

    uint32_t SPI_BaudRatePrescaler;            /*!< Specifies the speed of SCK clock.
                                                    SPI Clock Speed = clk source/SPI_ClkDIV
                                                    This parameter can be a value of \ref SPI_BaudRate_Prescaler.
                                                    \note The communication clock is derived from the master clock.
                                                    The slave clock does not need to be set. */

    FunctionalState SPI_SwapTxBitEn;           /*!< Specifies whether to swap SPI Tx data bit.
                                                    This parameter can be a value of ENABLE or DISABLE. */

    FunctionalState SPI_SwapRxBitEn;           /*!< Specifies whether to swap SPI Rx data bit.
                                                    This parameter can be a value of ENABLE or DISABLE. */

    FunctionalState SPI_SwapTxByteEn;          /*!< Specifies whether to swap SPI Tx data byte.
                                                    This parameter can be a value of ENABLE or DISABLE. */

    FunctionalState SPI_SwapRxByteEn;          /*!< Specifies whether to swap SPI Rx data byte.
                                                    This parameter can be a value of ENABLE or DISABLE. */

    FunctionalState SPI_ToggleEn;              /*!< Specifies whether to toggle when transfer done.
                                                    This parameter can be a value of ENABLE or DISABLE. */

    uint32_t SPI_TxThresholdLevel;             /*!< Specifies the transmit FIFO Threshold.
                                                    This parameter can be a value less than 64*/

    uint32_t SPI_RxThresholdLevel;             /*!< Specifies the receive FIFO Threshold.
                                                    This parameter can be a value less than 64*/

    FunctionalState SPI_TxDmaEn;               /*!< Specifies the Tx dma mode.
                                                    This parameter can be a value of ENABLE or DISABLE. */

    FunctionalState SPI_RxDmaEn;               /*!< Specifies the Rx dma mode.
                                                    This parameter can be a value of ENABLE or DISABLE. */

    uint8_t SPI_TxWaterlevel;                  /*!< Specifies the DMA tx water level.
                                                    The best value is SPI fifo depth - Tx GDMA MSize. */

    uint8_t SPI_RxWaterlevel;                  /*!< Specifies the DMA rx water level.
                                                    The best value is SPI Rx GDMA MSize. */
} SPI_InitTypeDef;

/*============================================================================*
 *                         Functions
 *============================================================================*/
/**
 * \defgroup    SPI_Exported_functions  Peripheral APIs
 * \{
 * \ingroup     SPI
 */

/**
 * \brief   Deinitializes the SPIx peripheral registers to their default reset values.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_spi_init(void)
 * {
 *     SPI_DeInit(SPI0);
 * }
 * \endcode
 */
void SPI_DeInit(SPI_TypeDef *SPIx);

/**
 * \brief   Initializes the SPIx peripheral according to the specified
 *          parameters in the SPI_InitStruct.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \param[in] SPI_InitStruct: Pointer to a SPI_InitTypeDef structure that
 *            contains the configuration information for the specified SPI peripheral.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_spi_init(void)
 * {
 *     RCC_PeriphClockCmd(APBPeriph_SPI0, APBPeriph_SPI0_CLOCK, ENABLE);

 *     SPI_InitTypeDef  SPI_InitStruct;
 *     SPI_StructInit(&SPI_InitStruct);
 *
 *     SPI_InitStruct.SPI_Direction   = SPI_Direction_EEPROM;
 *     SPI_InitStruct.SPI_DataSize    = SPI_DataSize_8b;
 *     SPI_InitStruct.SPI_CPOL        = SPI_CPOL_High;
 *     SPI_InitStruct.SPI_CPHA        = SPI_CPHA_2Edge;
 *     SPI_InitStruct.SPI_BaudRatePrescaler  = 100;
 *     SPI_InitStruct.SPI_RxThresholdLevel  = 1 - 1;
 *     SPI_InitStruct.SPI_NDF               = 1 - 1;
 *     SPI_InitStruct.SPI_FrameFormat = SPI_Frame_Motorola;
 *
 *     SPI_Init(SPI0, &SPI_InitStruct);
 * }
 * \endcode
 */
void SPI_Init(SPI_TypeDef *SPIx, SPI_InitTypeDef *SPI_InitStruct);

/**
 * \brief  Fills each SPI_InitStruct member with its default value.
 * \param[in]  SPI_InitStruct: Pointer to a SPI_InitTypeDef structure which will be initialized.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_spi_init(void)
 * {
 *
 *     RCC_PeriphClockCmd(APBPeriph_SPI0, APBPeriph_SPI0_CLOCK, ENABLE);

 *     SPI_InitTypeDef  SPI_InitStruct;
 *     SPI_StructInit(&SPI_InitStruct);
 *
 *     SPI_InitStruct.SPI_Direction   = SPI_Direction_EEPROM;
 *     SPI_InitStruct.SPI_DataSize    = SPI_DataSize_8b;
 *     SPI_InitStruct.SPI_CPOL        = SPI_CPOL_High;
 *     SPI_InitStruct.SPI_CPHA        = SPI_CPHA_2Edge;
 *     SPI_InitStruct.SPI_BaudRatePrescaler  = 100;
 *     SPI_InitStruct.SPI_RxThresholdLevel  = 1 - 1;
 *     SPI_InitStruct.SPI_NDF               = 1 - 1;
 *     SPI_InitStruct.SPI_FrameFormat = SPI_Frame_Motorola;
 *
 *     SPI_Init(SPI0, &SPI_InitStruct);
 * }
 * \endcode
 */
void SPI_StructInit(SPI_InitTypeDef *SPI_InitStruct);

/**
 * \brief  Enables or disables the selected SPI peripheral.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \param[in]  NewState: New state of the SPIx peripheral.
 *      This parameter can be: ENABLE or DISABLE.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_spi_init(void)
 * {
 *
 *     RCC_PeriphClockCmd(APBPeriph_SPI0, APBPeriph_SPI0_CLOCK, ENABLE);
 *
 *     SPI_InitTypeDef  SPI_InitStruct;
 *     SPI_StructInit(&SPI_InitStruct);
 *
 *     SPI_InitStruct.SPI_Direction   = SPI_Direction_EEPROM;
 *     SPI_InitStruct.SPI_DataSize    = SPI_DataSize_8b;
 *     SPI_InitStruct.SPI_CPOL        = SPI_CPOL_High;
 *     SPI_InitStruct.SPI_CPHA        = SPI_CPHA_2Edge;
 *     SPI_InitStruct.SPI_BaudRatePrescaler  = 100;
 *     SPI_InitStruct.SPI_RxThresholdLevel  = 1 - 1;
 *     SPI_InitStruct.SPI_NDF               = 1 - 1;
 *     SPI_InitStruct.SPI_FrameFormat = SPI_Frame_Motorola;
 *
 *     SPI_Init(SPI0, &SPI_InitStruct);
 *     SPI_Cmd(SPI0, ENABLE);
 * }
 * \endcode
 */
void SPI_Cmd(SPI_TypeDef *SPIx, FunctionalState NewState);

/**
 * \brief  Transmits a number of bytes through the SPIx peripheral.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \param[in] pBuf: Bytes to be transmitted.
 * \param[in] len: Byte length to be transmitted.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void spi_demo(void)
 * {
 *     uint8_t data_buf[] = {0x01,0x02,0x03};
 *     SPI_SendBuffer(SPI0, data_buf, sizeof(data_buf));
 * }
 * \endcode
 */
void SPI_SendBuffer(SPI_TypeDef *SPIx, uint8_t *pBuf, uint16_t len);

/**
  * \brief  Transmits a number of halfWords through the SPIx peripheral.
  * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
  * \param[in] pBuf: Halfwords to be transmitted.
  * \param[in] len: Halfwords length to be transmitted.
  * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void spi_demo(void)
 * {
 *     uint16_t data_buf[] = {0x0102,0x0203,0x0304};
 *     SPI_SendHalfWord(SPI0, data_buf, sizeof(data_buf)/sizeof(uint16_t));
 * }
 * \endcode
  */
void SPI_SendHalfWord(SPI_TypeDef *SPIx, uint16_t *pBuf, uint16_t len);

/**
 * \brief  Transmits a number of words through the SPIx peripheral.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \param[in] pBuf: Words to be transmitted.
 * \param[in] len: Word length to be transmitted.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void spi_demo(void)
 * {
 *     uint32_t data_buf[] = {0x01020304,0x02030405,0x03040506};
 *     SPI_SendWord(SPI0, data_buf, sizeof(data_buf)/sizeof(uint32_t));
 * }
 * \endcode
 */
void SPI_SendWord(SPI_TypeDef *SPIx, uint32_t *pBuf, uint16_t len);

/**
 * \brief  Enable or disable the specified SPI interrupt source.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \param[in] SPI_IT: Specifies the SPI interrupt source to be enabled or disabled.
 *      This parameter can be one of the following values:
 *      \arg SPI_INT_TXE: Transmit FIFO empty interrupt.
 *      \arg SPI_INT_TXO: Transmit FIFO overflow interrupt.
 *      \arg SPI_INT_RXU: Receive FIFO underflow interrupt.
 *      \arg SPI_INT_RXO: Receive FIFO overflow interrupt.
 *      \arg SPI_INT_RXF: Receive FIFO full interrupt.
 *      \arg SPI_INT_MST: Multi-Master Contention Interrupt.
 *      \arg SPI_INT_FAE: TX Frame Alignment interrupt.
 *      \arg SPI_INT_TUF: Transmit FIFO underflow interrupt.
 *      \arg SPI_INT_RIG: Rising edge detect interrupt.
 * \param[in] NewState: New state of the specified SPI interrupt source.
 *      This parameter can be: ENABLE or DISABLE.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void spi_demo(void)
 * {
 *     SPI_INTConfig(SPI0, SPI_INT_RXF, ENABLE);
 * }
 * \endcode
 */
void SPI_INTConfig(SPI_TypeDef *SPIx, uint8_t SPI_IT, FunctionalState NewState);

/**
 * \brief  Clear the specified SPI interrupt pending bit.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \param[in] SPI_IT: Specifies the SPI interrupt to clear.
 *      This parameter can be one of the following values:
 *      \arg SPI_INT_TXO: Transmit FIFO Overflow Interrupt.
 *      \arg SPI_INT_RXO: Receive FIFO Overflow Interrupt.
 *      \arg SPI_INT_RXU: Receive FIFO Underflow Interrupt.
 *      \arg SPI_INT_MST: Multi-Master Contention Interrupt.
 *      \arg SPI_INT_FAE: TX Frame Alignment Interrupt.
 *      \arg SPI_INT_TUF: Transmit FIFO Underflow Interrupt.
 *      \arg SPI_INT_RIG: Rising edge detect Interrupt.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void spi_demo(void)
 * {
 *     SPI_ClearINTPendingBit(SPI0, SPI_INT_RXF);
 * }
 * \endcode
 */
void SPI_ClearINTPendingBit(SPI_TypeDef *SPIx, uint16_t SPI_IT);

/**
 * \brief  Transmits a data through the SPIx peripheral.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \param[in] Data: Data to be transmitted.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void spi_demo(void)
 * {
 *     uint32_t data = 0x01020304;
 *     SPI_SendData(SPI0, data);
 * }
 * \endcode
 */
__STATIC_INLINE void SPI_SendData(SPI_TypeDef *SPIx, uint32_t Data)
{
    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(SPIx));

    SPIx->SPI_DR[0] = Data;
    while (!(SPIx->SPI_M_S_SR & SPI_FLAG_TFNF));
}

/**
 * \brief   Received data by the SPI peripheral.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \retval  The most recent received data.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void spi_demo(void)
 * {
 *     uint32_t data = SPI_ReceiveData(SPI0);
 * }
 * \endcode
 */
__STATIC_INLINE uint32_t SPI_ReceiveData(SPI_TypeDef *SPIx)
{
    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(SPIx));

    return (uint32_t)SPIx->SPI_DR[0];
}

/**
 * \brief   Get data length in Tx FIFO through the SPIx peripheral.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \return  Data length in Tx FIFO.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void spi_demo(void)
 * {
 *     uint8_t data_len = SPI_GetTxFIFOLen(SPI0);
 * }
 * \endcode
 */
__STATIC_INLINE uint8_t SPI_GetTxFIFOLen(SPI_TypeDef *SPIx)
{
    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(SPIx));

    SPI_TXFLR_t spi_0x20 = {.d32 = SPIx->SPI_TXFLR};
    return spi_0x20.b.txtfl;
}

/**
 * \brief   Get data length in Rx FIFO through the SPIx peripheral.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \return  Data length in Rx FIFO.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void spi_demo(void)
 * {
 *     uint8_t data_len = SPI_GetRxFIFOLen(SPI0);
 * }
 * \endcode
 */
__STATIC_INLINE uint8_t SPI_GetRxFIFOLen(SPI_TypeDef *SPIx)
{
    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(SPIx));

    SPI_RXFLR_t spi_0x24 = {.d32 = SPIx->SPI_RXFLR};
    return spi_0x24.b.rxtfl;
}

/**
 * \brief   Change SPI direction mode.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \param[in] dir: Value of direction mode.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void spi_demo(void)
 * {
 *     SPI_ChangeDirection(SPI0, SPI_Direction_EEPROM);
 * }
 * \endcode
 */
__STATIC_INLINE void SPI_ChangeDirection(SPI_TypeDef *SPIx, uint16_t dir)
{
    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(SPIx));
    assert_param(IS_SPI_DIRECTION_MODE(dir));

    /* Disable the selected SPI peripheral */
    SPI_SPIENR_t spi_0x08 = {.d32 = SPIx->SPI_SPIENR};
    spi_0x08.b.spi_en = 0;
    SPIx->SPI_SPIENR = spi_0x08.d32;

    /* Change SPI direction mode */
    SPI_M_CTRL0_t spi_0x00 = {.d32 = SPIx->SPI_M_S_CTRL0};
    spi_0x00.b.tmod = dir;
    SPIx->SPI_M_S_CTRL0 = spi_0x00.d32;

    /* Enable the selected SPI peripheral */
    spi_0x08.b.spi_en = 1;
    SPIx->SPI_SPIENR = spi_0x08.d32;
}

/**
 * \brief   Set read Data length only in EEPROM mode through the SPIx peripheral,which
            enables you to receive up to 64 KB of data in a continuous transfer.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \param[in] len: Length of read data which can be 1 to 65536.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void spi_demo(void)
 * {
 *     SPI_SetReadLen(SPI0, 100);
 * }
 * \endcode
 */
__STATIC_INLINE void SPI_SetReadLen(SPI_TypeDef *SPIx, uint16_t len)
{
    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(SPIx));

    /* Disable the selected SPI peripheral */
    SPI_SPIENR_t spi_0x08 = {.d32 = SPIx->SPI_SPIENR};
    spi_0x08.b.spi_en = 0;
    SPIx->SPI_SPIENR = spi_0x08.d32;

    /* Change SPI direction mode */
    SPI_M_CTRL1_t spi_0x04 = {.d32 = SPIx->SPI_M_CTRL1};
    spi_0x04.b.ndf = len - 1;
    SPIx->SPI_M_CTRL1 = spi_0x04.d32;

    /* Enable the selected SPI peripheral */
    spi_0x08.b.spi_en = 1;
    SPIx->SPI_SPIENR = spi_0x08.d32;
}

/**
 * \brief   Set cs number through the SPIx peripheral.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \param[in] number: Number can be 0 to 2.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void spi_demo(void)
 * {
 *     SPI_SetCSNumber(SPI1, 1);
 * }
 * \endcode
 */
__STATIC_INLINE void SPI_SetCSNumber(SPI_TypeDef *SPIx, uint8_t number)
{
    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(SPIx));

    /* set cs number */
    SPIx->SPI_M_SER = BIT(number);
}

/**
 * \brief  Check whether the specified SPI interrupt is set.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \param[in]  SPI_IT: Specifies the SPI interrupt to check.
 *      This parameter can be one of the following values:
 *      \arg SPI_INT_MST: Multi-Master Contention Interrupt.
 *      \arg SPI_INT_FAE: TX Frame Alignment Interrupt.
 *      \arg SPI_INT_RXF: Receive FIFO Full Interrupt.
 *      \arg SPI_INT_RXO: Receive FIFO Overflow Interrupt.
 *      \arg SPI_INT_RXU: Receive FIFO Underflow Interrupt.
 *      \arg SPI_INT_TXO: Transmit FIFO Overflow Interrupt .
 *      \arg SPI_INT_TXE: Transmit FIFO Empty Interrupt.
 * \return The new state of SPI_IT (SET or RESET).
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void spi_demo(void)
 * {
 *     ITStatus int_status = SPI_GetINTStatus(SPI0, SPI_INT_RXF);
 * }
 * \endcode
 */
__STATIC_INLINE ITStatus SPI_GetINTStatus(SPI_TypeDef *SPIx, uint32_t SPI_IT)
{
    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(SPIx));
    assert_param(IS_SPI_CONFIG_IT(SPI_IT));

    ITStatus bit_status = RESET;

    if ((SPIx->SPI_M_S_ISR & SPI_IT) != (uint32_t)RESET)
    {
        bit_status = SET;
    }

    /* Return the SPI_IT status */
    return  bit_status;
}

/**
 * \brief  Check whether the specified SPI flag is set.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \param[in]  SPI_FLAG: Specifies the SPI flag to check.
 *      This parameter can be one of the following values:
 *      \arg SPI_FLAG_DCOL: Data Collision Error flag.Set if it is actively transmitting in master mode when another master selects this device as a slave.
 *      \arg SPI_FLAG_TXE: Transmission error flag.Set if the transmit FIFO is empty when a transfer is started in slave mode.
 *      \arg SPI_FLAG_RFF: Receive FIFO full flag. Set if the receive FIFO is completely full.
 *      \arg SPI_FLAG_RFNE: Receive FIFO Not Empty flag.Set if receive FIFO is not empty.
 *      \arg SPI_FLAG_TFE: Transmit FIFO Empty flag.Set if transmit FIFO is empty.
 *      \arg SPI_FLAG_TFNF: Transmit FIFO Not Full flag.Set if transmit FIFO is not full.
 *      \arg SPI_FLAG_BUSY: SPI Busy flag.Set if it is actively transferring data.reset if it is idle or disabled.
 * \return The new state of SPI_FLAG (SET or RESET).
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void spi_demo(void)
 * {
 *     FlagStatus flag_status = SPI_GetFlagState(SPI0, SPI_FLAG_TXE);
 *
 * }
 * \endcode
 */
__STATIC_INLINE FlagStatus SPI_GetFlagState(SPI_TypeDef *SPIx, uint8_t SPI_FLAG)
{
    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(SPIx));
    assert_param(IS_SPI_GET_FLAG(SPI_FLAG));

    FlagStatus bitstatus = RESET;

    /* Check the status of the specified SPI flag */
    if ((SPIx->SPI_M_S_SR & SPI_FLAG) != (uint8_t)RESET)
    {
        /* SPI_FLAG is set */
        bitstatus = SET;
    }

    /* Return the SPI_FLAG status */
    return  bitstatus;
}

/**
 * \brief   Enables or disables the SPIx GDMA interface.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \param[in] SPI_GDMAReq: Specifies the SPI GDMA transfer request to be enabled or disabled.
 *      This parameter can be one of the following values:
 *      \arg SPI_GDMAReq_Tx: Tx buffer DMA transfer request.
 *      \arg SPI_GDMAReq_Rx: Rx buffer DMA transfer request.
 * \param[in]  NewState: New state of the selected SPI GDMA transfer request.
 *      This parameter can be: ENABLE or DISABLE.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void spi_demo(void)
 * {
 *     SPI_GDMACmd(SPI0, SPI_GDMAReq_Tx, ENABLE);
 * }
 * \endcode
 */
__STATIC_INLINE void SPI_GDMACmd(SPI_TypeDef *SPIx, SPI_GDMA_TRANSFER_REQUESTS_T SPI_GDMAReq,
                                 FunctionalState NewState)
{
    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(SPIx));
    assert_param(IS_FUNCTIONAL_STATE(NewState));
    assert_param(IS_SPI_GDMAREQ(SPI_GDMAReq));

    if (NewState != DISABLE)
    {
        /* Enable the selected SPI GDMA request */
        SPIx->SPI_DMACR |= SPI_GDMAReq;
    }
    else
    {
        /* Disable the selected SPI GDMA request */
        SPIx->SPI_DMACR &= (uint16_t)~(SPI_GDMAReq);
    }
}
/**
 * \brief  Change SPI speed daynamically.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \param[in]  precalser: Value of prescaler.
 *      This parameter can be one of the following values:
 *      \arg  SPI_BaudRatePrescaler_2
 *      \arg  SPI_BaudRatePrescaler_4
 *      \arg  SPI_BaudRatePrescaler_6
 *      \arg  SPI_BaudRatePrescaler_8
 *      \arg  SPI_BaudRatePrescaler_10
 *      \arg  SPI_BaudRatePrescaler_12
 *      \arg  SPI_BaudRatePrescaler_14
 *      \arg  SPI_BaudRatePrescaler_16
 *      \arg  SPI_BaudRatePrescaler_32
 *      \arg  SPI_BaudRatePrescaler_64
 *      \arg  SPI_BaudRatePrescaler_128
 *      \arg  SPI_BaudRatePrescaler_256
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void spi_demo(void)
 * {
 *     SPI_Change_CLK(SPI0, SPI_BaudRatePrescaler_2);
 * }
 * \endcode
 */
__STATIC_INLINE void SPI_Change_CLK(SPI_TypeDef *SPIx, uint32_t prescaler)
{
    /* Disable the selected SPI peripheral */
    SPI_SPIENR_t spi_0x08 = {.d32 = SPIx->SPI_SPIENR};
    spi_0x08.b.spi_en = 0;
    SPIx->SPI_SPIENR = spi_0x08.d32;

    /* Change SPI speed */
    SPI_M_BAUDR_t spi_0x14 = {.d32 = SPIx->SPI_M_BAUDR};
    spi_0x14.b.sckdv = prescaler & 0xFFFF;
    SPIx->SPI_M_BAUDR = spi_0x14.d32;

    /* Enable the selected SPI peripheral */
    spi_0x08.b.spi_en = 1;
    SPIx->SPI_SPIENR = spi_0x08.d32;
}

/**
 * \brief   Set SPI Rx sample delay.
 * \param[in] SPIx: Where x can be 0, 1, 2, 3 or 0_SLAVE to select the SPI peripheral.
 * \param[in] delay: This parameter can be 0 to 255.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void spi_demo(void)
 * {
 *     SPI_SetRxSampleDly(SPI0, 1);
 * }
 * \endcode
 */
__STATIC_INLINE void SPI_SetRxSampleDly(SPI_TypeDef *SPIx, uint32_t delay)
{
    /* Disable the selected SPI peripheral */
    SPI_SPIENR_t spi_0x08 = {.d32 = SPIx->SPI_SPIENR};
    spi_0x08.b.spi_en = 0;
    SPIx->SPI_SPIENR = spi_0x08.d32;

    /* Set SPI Rx sample delay */
    SPI_M_RSDR_t spi_0xf0 = {.d32 = SPIx->SPI_M_RSDR};
    spi_0xf0.b.rsd = delay & 0xFF;
    SPIx->SPI_M_RSDR = spi_0xf0.d32;

    /* Enable the selected SPI peripheral */
    spi_0x08.b.spi_en = 1;
    SPIx->SPI_SPIENR = spi_0x08.d32;
}

/** \} */ /* End of group SPI_Exported_Functions */

#ifdef __cplusplus
}
#endif

#endif /* RTL_SPI_H */


/******************* (C) COPYRIGHT 2015 Realtek Semiconductor Corporation *****END OF FILE****/

