/**
*********************************************************************************************************
*               Copyright(c) 2016, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      rtl876x_wdg.h
* @brief     header file of watch dog driver.
* @details
* @author    Lory_xu
* @date      2016-06-12
* @version   v1.0
* *********************************************************************************************************
*/

#ifndef _RTL876X_WDG_H_
#define _RTL876X_WDG_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "rtl876x.h"
#include "wdg.h"

/** @addtogroup WATCH_DOG Watch Dog
  * @brief Watch dog module
  * @{
  */


/*============================================================================*
 *                         Types
 *============================================================================*/


/** @defgroup WATCH_DOG_Types Watch Dog Exported Types
  * @{
  */


/**
 * wdg reset reason introduction:
 * 1.If you want to get reset reason from aon 0x15, deviding three types:
 *   a) HW reset: aon reg 0x15 is cleared to 0, magic pattern on ram will change
 *   b) SW RESET_ALL: aon reg 0x15 is cleared to 0,but magic pattern on ram not change
 *   c) SW RESET_ALL_EXCEPT_AON: obtain reset reason by reading aon reg 0x15 .
 * 2. Attention: don't use 0x1 as your reset reason when using RESET_ALL_EXCEPT_AON type! Because 0x1 is default value.
 */
typedef enum _SW_RESET_REASON
{
    RESET_REASON_HW                         = 0x0,  /* HW reset */
    RESET_REASON_WDG_TIMEOUT                = 0x1,
    RESET_REASON_BOOT_EFUSE_INVALID         = 0x2,
    RESET_REASON_BOOT_FLASH_INVALID         = 0x3,
    RESET_REASON_BOOT_RETRY_COUNT_LIMIT     = 0x4,
    RESET_REASON_HARD_FAULT                 = 0x5,
    RESET_REASON_FLASH_IOCTL                = 0x6,
    RESET_REASON_LOWER_STACK                = 0x7,
    RESET_REASON_PASSWORD_DEBUG             = 0x8,
    RESET_REASON_ENTER_FT_MODE              = 0x9,
    RESET_REASON_SWITCH_TO_HCI_MODE         = 0xA,
    RESET_REASON_SWITCH_TO_OTA_MODE         = 0xB,
    RESET_REASON_DFU_FW_RESET               = 0xC,
    RESET_REASON_DFU_UPDATE_IMG             = 0xD,
    RESET_REASON_DFU_UPDATE_IMG_FAIL        = 0xE,
    RESET_REASON_DFU_DISCONN_RSP            = 0xF,
    RESET_REASON_DFU_DISCONN_IND            = 0x10,
    RESET_REASON_ROM_DFU_OPCODE_SYSTEM_RESET = 0x11,
    RESET_REASON_DATATRANS_PATCH_ACTIVE     = 0x12,
    RESET_REASON_DATATRANS_SYSTEM_RESET     = 0x13,
    RESET_REASON_MP_RESET                   = 0x14,
    RESET_REASON_FEATURE_CHECK_FAIL         = 0x15,
    RESET_REASON_FLASH_LAYOUT_OVERFLOW      = 0x16,
    RESET_REASON_DFU_UPDATE_COMPRESSED_IMG  = 0x17,
    RESET_REASON_SECURITY_ONLY              = 0x18,

    //Compatible for Bee2 B-cut
    SW_RESET_APP_START              = 0xD0,
    SWITCH_HCI_MODE                 = 0xD1,
    SWITCH_TEST_MODE                = 0xD2,
    DFU_SWITCH_TO_OTA_MODE          = 0xD3,
    DFU_ACTIVE_RESET                = 0xD4,
    DFU_FAIL_RESET                  = 0xD5,
    DFU_TIMEOUT_RESET               = 0xD6,
    DFU_LINK_LOST_RESET             = 0xD7,
    HAL_WRAPPER_RESET               = 0xD8,
    SW_RESET_APP_END                = 0xFF,
} T_SW_RESET_REASON;

/** End of group WATCH_DOG_Exported_Types
  * @}
  */
#if defined (__ARM_FEATURE_CMSE) &&  (__ARM_FEATURE_CMSE == 3U)
typedef void (*APP_CB_WDG_RESET_TYPE)(T_WDG_MODE wdg_mode,
                                      T_SW_RESET_REASON reset_reason) __attribute__((cmse_nonsecure_call));
#else
typedef void (*APP_CB_WDG_RESET_TYPE)(T_WDG_MODE wdg_mode, T_SW_RESET_REASON reset_reason);
#endif
typedef bool (*BOOL_WDG_CB)(T_WDG_MODE wdg_mode, T_SW_RESET_REASON reset_reason);

/*============================================================================*
 *                         Functions
 *============================================================================*/

/** @defgroup WATCH_DOG_Exported_Functions Watch Dog Exported Functions
  * @{
  */

/**
   * @brief  Is watchdog enable.
     * @param  ms
     * @return  is watchdog enable or not
   */
bool is_WDG_Enable(void);

/**
   * @brief  Start Watchdog. This function will enable watchdog clock, set and start watchdog.
     * @param  ms
     * @param  wdg_mode @ref T_WDG_MODE
   */
bool WDG_Start(uint32_t ms, T_WDG_MODE  wdg_mode);

/**
   * @brief  Disable Watchdog.
   */
void WDG_Disable(void);

/**
   * @brief  Kick Watchdog to restart watchdog timer.
   */
void WDG_Kick(void);

/**
   * @brief  Watch Dog System Reset.
   * @param  wdg_mode @ref T_WDG_MODE
   */
void WDG_SystemReset(T_WDG_MODE wdg_mode, T_SW_RESET_REASON reset_reason);

/**
   * @brief  Clear KR0 Watchdog Interrupt.
   */
void WDG_KR0_WDT_Interrupt_Clear(void);

/**
   * @brief  Clear KM0 Watchdog Interrupt.
   */
void WDG_KM0_WDT_Interrupt_Clear(void);

/**
   * @brief  Clear DSP Watchdog Interrupt.
   */
void WDG_DSP_WDT_Interrupt_Clear(void);

/**
   * @brief  Start Watchdog in ROM. This function is called in Boot and DLPS exit restore flow.
   */
void WDG_Start_in_ROM(void);

/** @} */ /* End of group WATCH_DOG_Exported_Functions */
/** @} */ /* End of group WATCH_DOG */

#ifdef __cplusplus
}
#endif

#endif //_RTL876X_WDG_H_
