/**
*********************************************************************************************************
*               Copyright(c) 2022, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* \file     rtl_can.h
* \brief    The header file of the peripheral CAN driver.
* \details  This file provides all CAN firmware functions.
* \author   chenjie jin
* \date     2022-09-02
* \version  v0.0
* *********************************************************************************************************
*/

#ifndef _RTL_CAN_H_
#define _RTL_CAN_H_

#include "rtl876x.h"
#include "rtl_can_reg.h"

#ifdef __cplusplus
extern "C" {
#endif


/**
 * \addtogroup  IO          Peripheral Drivers
 * \defgroup    CAN         CAN
 *
 * \brief       Manage the CAN peripheral functions.
 *
 * \ingroup     IO
 */

/*============================================================================*
 *                         Defines
 *============================================================================*/
#define CAN_MESSAGE_BUFFER_MAX_CNT      16
#define CAN_MESSAGE_BUFFER_DEFAULT_LEN  20
#define CAN_MESSAGE_FIFO_START_ID       12
#define CAN_DEFAULT_ERR_WARN_TH         96
#define CAN_STAND_DATA_MAX_LEN          8
#define CAN_FD_DATA_MAX_LEN             64
#define CAN_STAND_FRAME_ID_MAX_VALUE    0x7FFUL
#define CAN_EXTEND_FRAME_ID_MAX_VALUE   0x3FFFFUL

/*============================================================================*
 *                         Register Defines
 *============================================================================*/

/* Peripheral: CAN */
/* Description: CAN register defines */

/* Register: CAN_STS -------------------------------------------------------*/
/* Description: CAN bus status. Offset: 0x04. */

/* CAN_STS[0] :CAN_BUS_ON_STATE. 0x1: bus on. 0x0: bus off */
#define CAN_BUS_ON_STATE_Pos                    (0UL)
#define CAN_BUS_ON_STATE_Msk                    (0x1UL << CAN_BUS_ON_STATE_Pos)

/* Register: CAN_INT_EN -------------------------------------------------------*/
/* Description: CAN interrupt control. Offset: 0x18. */

/* CAN_INT_EN[5] :CAN_RAM_MOVE_DONE_INT_EN. 0x1: enable. 0x0: disable */
#define CAN_RAM_MOVE_DONE_INT_EN_Pos            (5UL)
#define CAN_RAM_MOVE_DONE_INT_EN_Msk            (0x1UL << CAN_RAM_MOVE_DONE_INT_EN_Pos)
#define CAN_RAM_MOVE_DONE_INT_EN_CLR            (~CAN_RAM_MOVE_DONE_INT_EN_Msk)
/* CAN_INT_EN[4] :CAN_BUS_OFF_INT_EN. 0x1: enable. 0x0: disable */
#define CAN_BUS_OFF_INT_EN_Pos                  (4UL)
#define CAN_BUS_OFF_INT_EN_Msk                  (0x1UL << CAN_BUS_OFF_INT_EN_Pos)
#define CAN_BUS_OFF_INT_EN_CLR                  (~CAN_BUS_OFF_INT_EN_Msk)
/* CAN_INT_EN[3] :CAN_WAKE_UP_INT_EN. 0x1: enable. 0x0: disable */
#define CAN_WAKE_UP_INT_EN_Pos                  (3UL)
#define CAN_WAKE_UP_INT_EN_Msk                  (0x1UL << CAN_WAKE_UP_INT_EN_Pos)
#define CAN_WAKE_UP_INT_EN_CLR                  (~CAN_WAKE_UP_INT_EN_Msk)
/* CAN_INT_EN[2] :CAN_ERROR_INT_EN. 0x1: enable. 0x0: disable */
#define CAN_ERROR_INT_EN_Pos                    (2UL)
#define CAN_ERROR_INT_EN_Msk                    (0x1UL << CAN_ERROR_INT_EN_Pos)
#define CAN_ERROR_INT_EN_CLR                    (~CAN_ERROR_INT_EN_Msk)
/* CAN_INT_EN[1] :CAN_RX_INT_EN. 0x1: enable. 0x0: disable */
#define CAN_RX_INT_EN_Pos                       (1UL)
#define CAN_RX_INT_EN_Msk                       (0x1UL << CAN_RX_INT_EN_Pos)
#define CAN_RX_INT_EN_CLR                       (~CAN_RX_INT_EN_Msk)
/* CAN_INT_EN[0] :CAN_TX_INT_EN. 0x1: enable. 0x0: disable */
#define CAN_TX_INT_EN_Pos                       (0UL)
#define CAN_TX_INT_EN_Msk                       (0x1UL << CAN_TX_INT_EN_Pos)
#define CAN_TX_INT_EN_CLR                       (~CAN_TX_INT_EN_Msk)

/* Register: CAN_INT_FLAG -------------------------------------------------------*/
/* Description: CAN interrupt flags. Offset: 0x24. */

/* CAN_INT_FLAG[5] :CAN_RAM_MOVE_DONE_INT_FLAG. Write 1 to clear. */
#define CAN_RAM_MOVE_DONE_INT_FLAG_Pos            (5UL)
#define CAN_RAM_MOVE_DONE_INT_FLAG_Msk            (0x1UL << CAN_RAM_MOVE_DONE_INT_FLAG_Pos)
/* CAN_INT_FLAG[4] :CAN_BUS_OFF_INT_FLAG. Write 1 to clear. */
#define CAN_BUS_OFF_INT_FLAG_Pos                  (4UL)
#define CAN_BUS_OFF_INT_FLAG_Msk                  (0x1UL << CAN_BUS_OFF_INT_FLAG_Pos)
/* CAN_INT_EN[3] :CAN_WAKE_UP_INT_FLAG. Write 1 to clear. */
#define CAN_WAKE_UP_INT_FLAG_Pos                  (3UL)
#define CAN_WAKE_UP_INT_FLAG_Msk                  (0x1UL << CAN_WAKE_UP_INT_FLAG_Pos)
/* CAN_INT_EN[2] :CAN_ERROR_INT_FLAG. Write 1 to clear. */
#define CAN_ERROR_INT_FLAG_Pos                    (2UL)
#define CAN_ERROR_INT_FLAG_Msk                    (0x1UL << CAN_ERROR_INT_FLAG_Pos)
/* CAN_INT_EN[1] :CAN_RX_INT_FLAG. Write 1 to clear. */
#define CAN_RX_INT_FLAG_Pos                       (1UL)
#define CAN_RX_INT_FLAG_Msk                       (0x1UL << CAN_RX_INT_FLAG_Pos)
/* CAN_INT_EN[0] :CAN_TX_INT_FLAG. Write 1 to clear. */
#define CAN_TX_INT_FLAG_Pos                       (0UL)
#define CAN_TX_INT_FLAG_Msk                       (0x1UL << CAN_TX_INT_FLAG_Pos)

/* Register: CAN_ERR_STATUS -------------------------------------------------------*/
/* Description: CAN error status. Offset: 0x28. */

/* CAN_ERR_STATUS[9] :CAN_ERROR_RX. Write 1 to clear. */
#define CAN_ERROR_RX_Pos                        (9UL)
#define CAN_ERROR_RX_Msk                        (0x1UL << CAN_ERROR_RX_Pos)
/* CAN_ERR_STATUS[8] :CAN_ERROR_TX. Write 1 to clear. */
#define CAN_ERROR_TX_Pos                        (8UL)
#define CAN_ERROR_TX_Msk                        (0x1UL << CAN_ERROR_TX_Pos)
/* CAN_ERR_STATUS[5] :CAN_ERROR_ACK. Write 1 to clear. */
#define CAN_ERROR_ACK_Pos                       (5UL)
#define CAN_ERROR_ACK_Msk                       (0x1UL << CAN_ERROR_ACK_Pos)
/* CAN_ERR_STATUS[4] :CAN_ERROR_STUFF. Write 1 to clear. */
#define CAN_ERROR_STUFF_Pos                     (4UL)
#define CAN_ERROR_STUFF_Msk                     (0x1UL << CAN_ERROR_STUFF_Pos)
/* CAN_ERR_STATUS[3] :CAN_ERROR_CRC. Write 1 to clear. */
#define CAN_ERROR_CRC_Pos                       (3UL)
#define CAN_ERROR_CRC_Msk                       (0x1UL << CAN_ERROR_CRC_Pos)
/* CAN_ERR_STATUS[2] :CAN_ERROR_FORM. Write 1 to clear. */
#define CAN_ERROR_FORM_Pos                      (2UL)
#define CAN_ERROR_FORM_Msk                      (0x1UL << CAN_ERROR_FORM_Pos)
/* CAN_ERR_STATUS[1] :CAN_ERROR_BIT1. Write 1 to clear. */
#define CAN_ERROR_BIT1_Pos                      (1UL)
#define CAN_ERROR_BIT1_Msk                      (0x1UL << CAN_ERROR_BIT1_Pos)
/* CAN_ERR_STATUS[0] :CAN_ERROR_BIT0. Write 1 to clear. */
#define CAN_ERROR_BIT0_Pos                      (0UL)
#define CAN_ERROR_BIT0_Msk                      (0x1UL << CAN_ERROR_BIT0_Pos)


/*============================================================================*
 *                         Constants
 *============================================================================*/
#define CAN_STD_FRAME_ID_Pos                    (18UL)
#define CAN_STD_FRAME_ID_Msk                    (0x7FFUL << CAN_STD_FRAME_ID_Pos)

#define CAN_EXT_FRAME_ID_Pos                    (0UL)
#define CAN_EXT_FRAME_ID_Msk                    (0x3FFFFUL << CAN_EXT_FRAME_ID_Pos)

#define CAN_FRAME_ID_MASK_Pos                   (0UL)
#define CAN_FRAME_ID_MASK_Msk                   (0x1FFFFFFFUL << CAN_FRAME_ID_MASK_Pos)

#define CAN_RAM_ACC_DATA_Pos                    (11UL)
#define CAN_RAM_ACC_DATA_Msk                    (0xFFFFUL << CAN_RAM_ACC_DATA_Pos)

#define CAN_DLC_BYTES_0                         (0x0UL)
#define CAN_DLC_BYTES_1                         (0x1UL)
#define CAN_DLC_BYTES_2                         (0x2UL)
#define CAN_DLC_BYTES_3                         (0x3UL)
#define CAN_DLC_BYTES_4                         (0x4UL)
#define CAN_DLC_BYTES_5                         (0x5UL)
#define CAN_DLC_BYTES_6                         (0x6UL)
#define CAN_DLC_BYTES_7                         (0x7UL)
#define CAN_DLC_BYTES_8                         (0x8UL)
#define CAN_DLC_BYTES_12                        (0x9UL)
#define CAN_DLC_BYTES_16                        (0xAUL)
#define CAN_DLC_BYTES_20                        (0xBUL)
#define CAN_DLC_BYTES_24                        (0xCUL)
#define CAN_DLC_BYTES_32                        (0xDUL)
#define CAN_DLC_BYTES_48                        (0xEUL)
#define CAN_DLC_BYTES_64                        (0xFUL)

/**
 * \defgroup    CAN_Interrupt_Definition CAN Interrupt Definition
 * \{
 * \ingroup     CAN_Exported_Constants
 */
#define CAN_RAM_MOVE_DONE_INT                       ((uint32_t)CAN_RAM_MOVE_DONE_INT_EN_Msk)
#define CAN_BUS_OFF_INT                             ((uint32_t)CAN_BUS_OFF_INT_EN_Msk)
#define CAN_WAKE_UP_INT                             ((uint32_t)CAN_WAKE_UP_INT_EN_Msk)
#define CAN_ERROR_INT                               ((uint32_t)CAN_ERROR_INT_EN_Msk)
#define CAN_RX_INT                                  ((uint32_t)CAN_RX_INT_EN_Msk)
#define CAN_TX_INT                                  ((uint32_t)CAN_TX_INT_EN_Msk)
/** \} */

#define IS_CAN_INT_CONFIG(CONFIG)     (((CONFIG) == CAN_RAM_MOVE_DONE_INT)  || \
                                       ((CONFIG) == CAN_BUS_OFF_INT)        || \
                                       ((CONFIG) == CAN_WAKE_UP_INT)        || \
                                       ((CONFIG) == CAN_ERROR_INT)          || \
                                       ((CONFIG) == CAN_RX_INT)             || \
                                       ((CONFIG) == CAN_TX_INT))

/**
 * \defgroup    CAN_Interrupt_Flag CAN Interrupt Flag
 * \{
 * \ingroup     CAN_Exported_Constants
 */
#define CAN_RAM_MOVE_DONE_INT_FLAG                  ((uint32_t)CAN_RAM_MOVE_DONE_INT_FLAG_Msk)
#define CAN_BUS_OFF_INT_FLAG                        ((uint32_t)CAN_BUS_OFF_INT_FLAG_Msk)
#define CAN_WAKE_UP_INT_FLAG                        ((uint32_t)CAN_WAKE_UP_INT_FLAG_Msk)
#define CAN_ERROR_INT_FLAG                          ((uint32_t)CAN_ERROR_INT_FLAG_Msk)
#define CAN_RX_INT_FLAG                             ((uint32_t)CAN_RX_INT_FLAG_Msk)
#define CAN_TX_INT_FLAG                             ((uint32_t)CAN_TX_INT_FLAG_Msk)
/** \} */

#define IS_CAN_INT_FLAG(FLAG)         (((CONFIG) == CAN_RAM_MOVE_DONE_INT_FLAG) || \
                                       ((CONFIG) == CAN_BUS_OFF_INT_FLAG)       || \
                                       ((CONFIG) == CAN_WAKE_UP_INT_FLAG)       || \
                                       ((CONFIG) == CAN_ERROR_INT_FLAG)         || \
                                       ((CONFIG) == CAN_RX_INT_FLAG)            || \
                                       ((CONFIG) == CAN_TX_INT_FLAG))

#define CAN_ERROR_RX                                ((uint32_t)CAN_ERROR_RX_Msk)
#define CAN_ERROR_TX                                ((uint32_t)CAN_ERROR_TX_Msk)
#define CAN_ERROR_ACK                               ((uint32_t)CAN_ERROR_ACK_Msk)
#define CAN_ERROR_STUFF                             ((uint32_t)CAN_ERROR_STUFF_Msk)
#define CAN_ERROR_CRC                               ((uint32_t)CAN_ERROR_CRC_Msk)
#define CAN_ERROR_FORM                              ((uint32_t)CAN_ERROR_FORM_Msk)
#define CAN_ERROR_BIT1                              ((uint32_t)CAN_ERROR_BIT1_Msk)
#define CAN_ERROR_BIT0                              ((uint32_t)CAN_ERROR_BIT0_Msk)

#define IS_CAN_ERROR_STATUS(STATUS)   (((STATUS) == CAN_ERROR_RX)   || \
                                       ((STATUS) == CAN_ERROR_TX)   || \
                                       ((STATUS) == CAN_ERROR_ACK)  || \
                                       ((STATUS) == CAN_ERROR_CRC)  || \
                                       ((STATUS) == CAN_ERROR_FORM) || \
                                       ((STATUS) == CAN_ERROR_BIT1) || \
                                       ((STATUS) == CAN_ERROR_BIT0))

/*============================================================================*
 *                         Types
 *============================================================================*/
/**
 * \defgroup    CAN_Exported_Types  Init Params Struct
 *
 * \ingroup     CAN
 */
typedef struct
{
    uint8_t CAN_FdEn;
    uint8_t CAN_AutoReTxEn;
    uint8_t CAN_RxFifoEn;
    uint8_t CAN_RxDmaEn;
    uint8_t CAN_TriSampleEn;
    uint8_t CAN_FdCrcMode;
    uint8_t CAN_TestModeSel;
    uint16_t CAN_ErrorWarnThd;
    CAN_0x0C_TYPE_t CAN_BitTiming;
    CAN_0x10_TYPE_t CAN_FdBitTiming;
    CAN_0x14_TYPE_t CAN_FdSspCal;
    CAN_0x40_TYPE_t CAN_TimeStamp;
} CAN_InitTypeDef;

typedef enum t_can_fd_crc_mode_sel
{
    CAN_FD_ISO_CRC,
    CAN_FD_NON_ISO_CRC,
} CAN_FD_CRC_MODE_SEL_T;

typedef enum t_can_bus_state_sel
{
    CAN_BUS_STATE_OFF,
    CAN_BUS_STATE_ON,
} CAN_BUS_STATE_SEL_T;

typedef enum t_can_ram_state_sel
{
    CAN_RAM_STATE_IDLE,
    CAN_RAM_STATE_EXCHANGING,
} CAN_RAM_STATE_SEL_T;

typedef enum t_can_test_mode_sel
{
    CAN_TEST_MODE_NONE,
    CAN_TEST_MODE_LOOP_BACK,
    CAN_TEST_MODE_SILENCE,
} CAN_TEST_MODE_SEL_T;

typedef enum t_can_rtr_sel
{
    CAN_RTR_DATA_FRAME = 0,
    CAN_RTR_REMOTE_FRAME = 1,
} CAN_RTR_SEL_T;

typedef enum t_can_ide_sel
{
    CAN_IDE_STANDARD_FORMAT = 0,
    CAN_IDE_EXTEND_FORMAT = 1,
} CAN_IDE_SEL_T;

typedef enum t_can_edl_sel
{
    CAN_EDL_STARDARD_FRAME = 0,
    CAN_EDL_FD_FRAME = 1,
} CAN_EDL_SEL_T;

typedef enum t_can_brs_sel
{
    CAN_BRS_NO_SWITCH_BIT_TIMING = 0,
    CAN_BRS_SWITCH_BIT_TIMING = 1,
} CAN_BRS_SEL_T;

typedef enum t_can_data_frame_sel
{
    CAN_INVALID_DATA_FRAME, /* invalide data frame */
    CAN_STD_DATA_FRAME,     /* standard data frame */
    CAN_EXT_DATA_FRAME,     /* extend data frame */
    CAN_STD_REMOTE_FRAME,   /* standard remote frame */
    CAN_EXT_REMOTE_FRAME,   /* extend remote frame */
    CAN_FD_STD_DATA_FRAME,  /* FD standard data frame */
    CAN_FD_EXT_DATA_FRAME,  /* FD extend data frame */
} CAN_DATA_FRAME_SEL_T;

typedef enum t_can_tx_frame_error
{
    CAN_NO_ERR = 0,         /* no error */
    CAN_MSG_ID_ERR = 1,     /* can message id error */
    CAN_ID_ERR = 2,         /* can frame id error */
    CAN_DATA_LEN_ERR = 3,   /* can frame data length error */
    CAN_TYPE_ERR = 4,       /* can frame type error */
    CAN_RAM_STATE_ERR = 5,  /* can frame ram status error */
    CAN_TIMEOUT_ERR = 6,    /* can timeout error */
} CAN_ERROR_T;

typedef struct
{
    uint8_t msg_buf_id;
    uint8_t frame_brs_bit;
    uint8_t auto_reply_bit;
    CAN_DATA_FRAME_SEL_T frame_type;
    uint16_t standard_frame_id;
    uint32_t extend_frame_id;
} CAN_TxFrameTypeDef;

typedef struct
{
    uint8_t msg_buf_id;
    uint8_t rx_dma_en;
    uint8_t frame_rtr_mask; /* can frame RTR mask, 1 means don't care, 0 means the bit should match */
    uint8_t frame_ide_mask; /* can frame IDE mask, 1 means don't care, 0 means the bit should match */
    uint32_t frame_id_mask; /* can frame ID mask, 1 means the ID bit in CAN_RAM_ARB don't care, 0 means the bit should match. */
    uint8_t frame_rtr_bit;  /* can frame RTR bit, determine DATA or REMOTE frame */
    uint8_t frame_ide_bit;  /* can frame IDE bit, determine standard or extend format */
    uint8_t auto_reply_bit;
    uint16_t standard_frame_id;
    uint32_t extend_frame_id;
} CAN_RxFrameTypeDef;

typedef struct
{
    uint8_t rtr_mask;
    uint8_t ide_mask;
    uint8_t id_mask;
    uint8_t esi_bit;
    uint8_t auto_reply_bit;
    uint8_t rxtx_bit;
    uint8_t rx_lost_bit;
    uint8_t data_length;
    uint8_t rx_dma_en;
    CAN_BRS_SEL_T brs_bit;
    CAN_EDL_SEL_T edl_bit;
    CAN_RTR_SEL_T rtr_bit;
    CAN_IDE_SEL_T ide_bit;
    uint16_t rx_timestamp;
    uint16_t standard_frame_id;
    uint32_t extend_frame_id;
} CAN_MsgBufInfoTypeDef;

typedef struct
{
    uint8_t fifo_msg_lvl;
    uint8_t fifo_msg_overflow;
    uint8_t fifo_msg_empty;
    uint8_t fifo_msg_full;
} CAN_FifoStatusTypeDef;

typedef struct
{
    CAN_0x340_TYPE_t can_ram_arb;
    CAN_0x348_TYPE_t can_ram_cs;
    uint8_t rx_dma_data[CAN_FD_DATA_MAX_LEN];
} CAN_RxDmaDataTypeDef;


/*============================================================================*
 *                         Functions
 *============================================================================*/
/**
 * \defgroup    CAN_Exported_Functions Peripheral APIs
 * \{
 * \ingroup     CAN
 */

/**
 * rtl_can.h
 * \brief   Deinitializes the CAN peripheral registers to their default values.
 * \param   None.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void can_driver_init(void)
 * {
 *     CAN_DeInit();
 * }
 * \endcode
 */
void CAN_DeInit(void);

/**
 * rtl_can.h
 * \brief   Initializes the CAN peripheral according to the specified
 *          parameters in the CAN_InitStruct
 * \param[in] CAN_InitStruct: Pointer to a CAN_InitTypeDef structure that
 *            contains the configuration information for the specified CAN peripheral
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void can_driver_init(void)
 * {
 *     RCC_PeriphClockCmd(APBPeriph_CAN, APBPeriph_CAN_CLOCK, ENABLE);
 *
 *     CAN_InitTypeDef init_struct;
 *
 *     CAN_StructInit(&init_struct);
 *     init_struct.CAN_AutoReTxEn = DISABLE;
 *     init_struct.CAN_BitTiming.can_brp = 7;
 *     init_struct.CAN_BitTiming.can_sjw = 3;
 *     init_struct.CAN_BitTiming.can_tseg1 = 4;
 *     init_struct.CAN_BitTiming.can_tseg2 = 3;
 *
 *     init_struct.CAN_FdEn = ENABLE;
 *     init_struct.CAN_FdBitTiming.can_fd_brp = 4;
 *     init_struct.CAN_FdBitTiming.can_fd_sjw = 3;
 *     init_struct.CAN_FdBitTiming.can_fd_tseg1 = 4;
 *     init_struct.CAN_FdBitTiming.can_fd_tseg2 = 4;
 *     init_struct.CAN_FdSspCal.can_fd_ssp_auto = ENABLE;
 *     init_struct.CAN_FdSspCal.can_fd_ssp_dco = 0;
 *     init_struct.CAN_FdSspCal.can_fd_ssp_min = 0;
 *     init_struct.CAN_FdSspCal.can_fd_ssp = 0;
 *
 *     CAN_Init(&init_struct);
 *     CAN_Cmd(ENABLE);
 * }
 * \endcode
 */
void CAN_Init(CAN_InitTypeDef *CAN_InitStruct);

/**
 * rtl_can.h
 * \brief   Fills each CAN_InitStruct member with its default value.
 * \param[in] CAN_InitStruct: Pointer to an CAN_InitTypeDef structure which will be initialized.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void can_driver_init(void)
 * {
 *     RCC_PeriphClockCmd(APBPeriph_CAN, APBPeriph_CAN_CLOCK, ENABLE);
 *
 *     CAN_InitTypeDef init_struct;
 *
 *     CAN_StructInit(&init_struct);
 *     init_struct.CAN_AutoReTxEn = DISABLE;
 *     init_struct.CAN_BitTiming.can_brp = 7;
 *     init_struct.CAN_BitTiming.can_sjw = 3;
 *     init_struct.CAN_BitTiming.can_tseg1 = 4;
 *     init_struct.CAN_BitTiming.can_tseg2 = 3;
 *
 *     init_struct.CAN_FdEn = ENABLE;
 *     init_struct.CAN_FdBitTiming.can_fd_brp = 4;
 *     init_struct.CAN_FdBitTiming.can_fd_sjw = 3;
 *     init_struct.CAN_FdBitTiming.can_fd_tseg1 = 4;
 *     init_struct.CAN_FdBitTiming.can_fd_tseg2 = 4;
 *     init_struct.CAN_FdSspCal.can_fd_ssp_auto = ENABLE;
 *     init_struct.CAN_FdSspCal.can_fd_ssp_dco = 0;
 *     init_struct.CAN_FdSspCal.can_fd_ssp_min = 0;
 *     init_struct.CAN_FdSspCal.can_fd_ssp = 0;
 *
 *     CAN_Init(&init_struct);
 *     CAN_Cmd(ENABLE);
 * }
 * \endcode
 */
void CAN_StructInit(CAN_InitTypeDef *CAN_InitStruct);

/**
 * rtl_can.h
 * \brief   Enable or disable the selected CAN mode.
 * \param[in] NewState: New state of the operation mode.
 *      This parameter can be: ENABLE or DISABLE.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void can_driver_init(void)
 * {
 *     RCC_PeriphClockCmd(APBPeriph_CAN, APBPeriph_CAN_CLOCK, ENABLE);
 *
 *     CAN_InitTypeDef init_struct;
 *
 *     CAN_StructInit(&init_struct);
 *     init_struct.CAN_AutoReTxEn = DISABLE;
 *     init_struct.CAN_BitTiming.can_brp = 7;
 *     init_struct.CAN_BitTiming.can_sjw = 3;
 *     init_struct.CAN_BitTiming.can_tseg1 = 4;
 *     init_struct.CAN_BitTiming.can_tseg2 = 3;
 *
 *     init_struct.CAN_FdEn = ENABLE;
 *     init_struct.CAN_FdBitTiming.can_fd_brp = 4;
 *     init_struct.CAN_FdBitTiming.can_fd_sjw = 3;
 *     init_struct.CAN_FdBitTiming.can_fd_tseg1 = 4;
 *     init_struct.CAN_FdBitTiming.can_fd_tseg2 = 4;
 *     init_struct.CAN_FdSspCal.can_fd_ssp_auto = ENABLE;
 *     init_struct.CAN_FdSspCal.can_fd_ssp_dco = 0;
 *     init_struct.CAN_FdSspCal.can_fd_ssp_min = 0;
 *     init_struct.CAN_FdSspCal.can_fd_ssp = 0;
 *
 *     CAN_Init(&init_struct);
 *     CAN_Cmd(ENABLE);
 * }
 * \endcode
 */
void CAN_Cmd(FunctionalState NewState);

/**
 * rtl_can.h
 * \brief   Enable or disable the specified CAN interrupt source.
 * \param[in] CAN_INT: Specifies the I2S interrupt source to be enable or disable.
 *      This parameter can be the following values:
 *      \arg CAN_RAM_MOVE_DONE_INT: data move from register to CAN IP internal RAM finished interupt.
 *      \arg CAN_BUS_OFF_INT: bus off interrupt.
 *      \arg CAN_WAKE_UP_INT: wakeup interrupt.
 *      \arg CAN_ERROR_INT: error interrupt.
 *      \arg CAN_RX_INT: RX interrupt.
 *      \arg CAN_TX_INT: TX interrupt.
 * \param[in]  NewState: New state of the specified CAN interrupt.
 *      This parameter can be: ENABLE or DISABLE.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void can_driver_init(void)
 * {
 *     CAN_INTConfig((CAN_RAM_MOVE_DONE_INT | CAN_BUS_OFF_INT | CAN_WAKE_UP_INT |
 *                      CAN_ERROR_INT | CAN_RX_INT | CAN_TX_INT), ENABLE);
 * }
 * \endcode
 */
void CAN_INTConfig(uint32_t CAN_INT, FunctionalState newState);

/**
 * rtl_can.h
 * \brief   Get the specified CAN interrupt status.
 * \param[in] CAN_INT: the specified I2S interrupt.
 *     This parameter can be one of the following values:
 *     \arg CAN_RAM_MOVE_DONE_INT_FLAG: ram move done interrupt flag.
 *     \arg CAN_BUS_OFF_INT_FLAG: bus off interrupt flag.
 *     \arg CAN_WAKE_UP_INT_FLAG: wakeup interrupt flag.
 *     \arg CAN_ERROR_INT_FLAG: error interrupt flag.
 *     \arg CAN_RX_INT_FLAG: RX interrupt flag.
 *     \arg CAN_TX_INT: Clear TX interrupt flag.
 * \retval The new state of CAN_INT (SET or RESET).
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void CAN_Handler(void)
 * {
 *     if (SET == CAN_GetINTStatus(CAN_RAM_MOVE_DONE_INT_FLAG))
 *  {
 *      DBG_DIRECT("[CAN] CAN_Handler CAN_RAM_MOVE_DONE_INT_FLAG");
 *      CAN_ClearINTPendingBit(CAN_RAM_MOVE_DONE_INT_FLAG);
 *  }
 * }
 * \endcode
 */
ITStatus CAN_GetINTStatus(uint32_t CAN_INT);

/**
 * rtl_can.h
 * \brief  Clear the CAN interrupt pending bit.
 * \param[in] CAN_CLEAR_INT: Specifies the interrupt pending bit to clear.
 *      This parameter can be any combination of the following values:
 *      \arg CAN_RAM_MOVE_DONE_INT_FLAG: ram move done interrupt flag.
 *      \arg CAN_BUS_OFF_INT_FLAG: bus off interrupt flag.
 *      \arg CAN_WAKE_UP_INT_FLAG: wakeup interrupt flag.
 *      \arg CAN_ERROR_INT_FLAG: error interrupt flag.
 *      \arg CAN_RX_INT_FLAG: RX interrupt flag.
 *      \arg CAN_TX_INT: Clear TX interrupt flag.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void CAN_Handler(void)
 * {
 *     if (SET == CAN_GetINTStatus(CAN_RAM_MOVE_DONE_INT_FLAG))
 *     {
 *      DBG_DIRECT("[CAN] CAN_Handler CAN_RAM_MOVE_DONE_INT_FLAG");
 *      CAN_ClearINTPendingBit(CAN_RAM_MOVE_DONE_INT_FLAG);
 *     }
 * }
 * \endcode
 */
void CAN_ClearINTPendingBit(uint32_t CAN_CLEAR_INT);

/**
 * rtl_can.h
 * \brief  Gets the specified CAN error status.
 * \param[in]  CAN_ERR_STAT: the specified CAN error.
 *     This parameter can be one of the following values:
 *     \arg CAN_ERROR_RX: can rx error flag
 *     \arg CAN_ERROR_TX: can tx error flag
 *     \arg CAN_ERROR_ACK: latest error is ack error
 *     \arg CAN_ERROR_STUFF: latest error is stuff error
 *     \arg CAN_ERROR_CRC: latest error is crc error
 *     \arg CAN_ERROR_FORM: latest error is form error
 *     \arg CAN_ERROR_BIT1: latest error is bit1 error, tx=1 but rx=0
 *     \arg CAN_ERROR_BIT0: latest error is bit0 error, tx=0 but rx=1
 * \retval The new state of CAN_INT (SET or RESET).
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void CAN_Handler(void)
 * {
 *     if (SET == CAN_GetErrorStatus(CAN_ERROR_TX))
 *     {
 *          DBG_DIRECT("[CAN] CAN_ERROR_TX");
 *          CAN_CLearErrorStatus(CAN_ERROR_TX);
 *     }
 * }
 * \endcode
 */
FlagStatus CAN_GetErrorStatus(uint32_t CAN_ERR_STAT);

/**
 * rtl_can.h
 * \brief  Clears the specified CAN error status.
 * \param[in]  CAN_ERR_STAT: the specified CAN error.
 *     This parameter can be one of the following values:
 *     \arg CAN_ERROR_RX: can rx error flag
 *     \arg CAN_ERROR_TX: can tx error flag
 *     \arg CAN_ERROR_ACK: latest error is ack error
 *     \arg CAN_ERROR_STUFF: latest error is stuff error
 *     \arg CAN_ERROR_CRC: latest error is crc error
 *     \arg CAN_ERROR_FORM: latest error is form error
 *     \arg CAN_ERROR_BIT1: latest error is bit1 error, tx=1 but rx=0
 *     \arg CAN_ERROR_BIT0: latest error is bit0 error, tx=0 but rx=1
 * \retval None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void CAN_Handler(void)
 * {
 *     if (SET == CAN_GetErrorStatus(CAN_ERROR_TX))
 *     {
 *          DBG_DIRECT("[CAN] CAN_ERROR_TX");
 *          CAN_CLearErrorStatus(CAN_ERROR_TX);
 *     }
 * }
 * \endcode
 */
void CAN_CLearErrorStatus(uint32_t CAN_ERR_STAT);

/**
 * rtl_can.h
 * \brief  Sets the CAN message buffer Tx mode.
 * \param[in]  p_tx_frame_params: the CAN frame parameter.
 * \param[in]  p_frame_data: the specified CAN data.
 * \param[in]  data_len: the length of CAN data to be sent.
 * \retval the state of set buffer.
 */
CAN_ERROR_T CAN_SetMsgBufTxMode(CAN_TxFrameTypeDef *p_tx_frame_params, uint8_t *p_frame_data,
                                uint8_t data_len);

/**
 * rtl_can.h
 * \brief  Sets the CAN message buffer Rx mode.
 * \param[in]  p_rx_frame_params: the CAN frame parameter.
 * \retval the state of set buffer.
 */
CAN_ERROR_T CAN_SetMsgBufRxMode(CAN_RxFrameTypeDef *p_rx_frame_params);

/**
 * rtl_can.h
 * \brief  Gets message buffer infomation.
 * \param[in]  msg_buf_id: message buffer id.
 * \param[in]  p_mb_info.
 * \retval the state of set buffer.
 */
CAN_ERROR_T CAN_GetMsgBufInfo(uint8_t msg_buf_id, CAN_MsgBufInfoTypeDef *p_mb_info);

/**
 * rtl_can.h
 * \brief  Gets RAM data.
 * \param[in]  data_len: the length of RAM data.
 * \param[in]  p_data.
 * \retval the state of set buffer.
 */
CAN_ERROR_T CAN_GetRamData(uint8_t data_len, uint8_t *p_data);

/**
 * rtl_can.h
 * \brief  Gets RAM data.
 * \param[in]  rtr_bit.
 * \param[in]  ide_bit.
 * \param[in]  edl_bit.
 * \retval the frame of CAN data.
 */
CAN_DATA_FRAME_SEL_T CAN_CheckFrameType(uint8_t rtr_bit, uint8_t ide_bit, uint8_t edl_bit);

/**
 * rtl_can.h
 * \brief  Config message buffer tx interrupt.
 * \param[in]  message_buffer_index: CAN message buffer index.
 * \param[in]  newState: the tx state of message buffer.
 * \retval None.
 */
void CAN_MBTxINTConfig(uint8_t message_buffer_index, FunctionalState newState);

/**
 * rtl_can.h
 * \brief  Config message buffer rx interrupt.
 * \param[in]  message_buffer_index: CAN message buffer index.
 * \param[in]  newState: the rx state of message buffer.
 * \retval None.
 */
void CAN_MBRxINTConfig(uint8_t message_buffer_index, FunctionalState newState);

/**
 * rtl_can.h
 * \brief  Gets CAN FIFO status.
 * \param[in]  CAN_FifoStatus: the status of CAN FIFO.
 * \retval None.
 */
void CAN_GetFifoStatus(CAN_FifoStatusTypeDef *CAN_FifoStatus);

/**
 * rtl_can.h
 * \brief  Sets tx message trigger by timestamp timer.
 * \param[in]  newState: the state of tx trigger.
 * \param[in]  trigger_timestamp_begin: end of trigger time.
 * \param[in]  close_offset: start of trigger time.
 * \retval None.
 */
void CAN_TxTriggerConfig(FunctionalState newState, uint16_t trigger_timestamp_begin,
                         uint16_t close_offset);


__STATIC_INLINE uint32_t CAN_GetBusState(void)
{
    return ((CAN->u_04.BITS_04.b.bus_on_state) ? CAN_BUS_STATE_ON : CAN_BUS_STATE_OFF);
}

__STATIC_INLINE uint32_t CAN_GetRamState(void)
{
    return ((CAN_RAM->u_34C.BITS_34C.b.can_ram_start) ? CAN_RAM_STATE_EXCHANGING : CAN_RAM_STATE_IDLE);
}

__STATIC_INLINE FlagStatus CAN_GetMBnTxDoneFlag(uint8_t message_buffer_index)
{
    return (CAN->u_38.BITS_38.b.can_tx_done & (1UL << message_buffer_index)) ? SET : RESET;
}

__STATIC_INLINE void CAN_ClearMBnTxDoneFlag(uint8_t message_buffer_index)
{
    CAN->u_38.BITS_38.b.can_tx_done |= (1UL << message_buffer_index);
}

__STATIC_INLINE FlagStatus CAN_GetMBnTxErrorFlag(uint8_t message_buffer_index)
{
    return (CAN->u_34.BITS_34.b.can_tx_error_flag & (1UL << message_buffer_index)) ? SET : RESET;
}

__STATIC_INLINE void CAN_ClearMBnTxErrorFlag(uint8_t message_buffer_index)
{
    CAN->u_34.BITS_34.b.can_tx_error_flag |= (1UL << message_buffer_index);
}

__STATIC_INLINE FlagStatus CAN_GetMBnStatusTxFinishFlag(uint8_t message_buffer_index)
{
    return (((CAN_0x100_0x13C_TYPE_t *)(CAN_MB_STS + 4 * message_buffer_index))->b.can_msg_tx_done);
}

__STATIC_INLINE FlagStatus CAN_GetMBnStatusTxReqFlag(uint8_t message_buffer_index)
{
    return (((CAN_0x100_0x13C_TYPE_t *)(CAN_MB_STS + 4 * message_buffer_index))->b.can_msg_tx_req);
}

__STATIC_INLINE FlagStatus CAN_GetMBnRxDoneFlag(uint8_t message_buffer_index)
{
    return (CAN->u_3C.BITS_3C.b.can_rx_done & (1UL << message_buffer_index)) ? SET : RESET;
}

__STATIC_INLINE void CAN_ClearMBnRxDoneFlag(uint8_t message_buffer_index)
{
    CAN->u_3C.BITS_3C.b.can_rx_done |= (1UL << message_buffer_index);
}

__STATIC_INLINE FlagStatus CAN_GetMBnStatusRxValidFlag(uint8_t message_buffer_index)
{
    return (((CAN_0x100_0x13C_TYPE_t *)(CAN_MB_STS + 4 * message_buffer_index))->b.can_msg_rx_vld);
}

__STATIC_INLINE FlagStatus CAN_GetMBnStatusRxReadyFlag(uint8_t message_buffer_index)
{
    return (((CAN_0x100_0x13C_TYPE_t *)(CAN_MB_STS + 4 * message_buffer_index))->b.can_msg_rx_rdy);
}

__STATIC_INLINE void CAN_TimeStampConfig(FunctionalState newState)
{
    CAN->u_40.BITS_40.b.can_time_stamp_en = newState;
}

__STATIC_INLINE uint16_t CAN_GetTimeStampCount(void)
{
    return (CAN->u_40.BITS_40.b.can_time_stamp);
}

__STATIC_INLINE uint32_t CAN_GetRxDmaMsize(void)
{
    return (CAN->u_48.BITS_48.b.can_rxdma_msize);
}

__STATIC_INLINE FlagStatus CAN_GetMBnRxDmaEnFlag(uint8_t message_buffer_index)
{
    return ((((CAN_0x200_0x23C_TYPE_t *)(CAN_MB_CTRL + (4 *
                                                        message_buffer_index)))->b.can_msg_rxdma_en));
}

__STATIC_INLINE void CAN_SetMBnRxDmaEnFlag(uint8_t message_buffer_index, FunctionalState newState)
{
    ((CAN_0x200_0x23C_TYPE_t *)(CAN_MB_CTRL + (4 * message_buffer_index)))->b.can_msg_rxdma_en =
        newState;
}
/** \} */ /* End of Group CAN_Exported_Functions */

#ifdef __cplusplus
}
#endif

#endif /* _RTL_CAN_H_ */
/******************* (C) COPYRIGHT 2020 Realtek Semiconductor *****END OF FILE****/
