/**
*********************************************************************************************************
*               Copyright(c) 2016, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* \file     rtl_aon_qdec.h
* \brief    The header file of the peripheral AON_QDECODER driver.
* \details  This file provides all AON_QDECODER firmware functions.
* \author   grace yan
* \date     2023-02-20
* \version  v1.1
* *********************************************************************************************************
*/


#ifndef RTL_AON_QDEC_H
#define RTL_AON_QDEC_H

#ifdef __cplusplus
extern "C" {
#endif


/**
 * \addtogroup  IO          Peripheral Drivers
 * \defgroup    AON QDEC    AON QDEC
 *
 * \brief       Manage the AON QDEC peripheral functions.
 *
 * \ingroup     IO
 */

/*============================================================================*
 *                         Includes
 *============================================================================*/
#include "rtl876x.h"
#include "rtl_alias.h"
#include "rtl_aon_qdec_reg.h"

/*============================================================================*
 *                         Constants
 *============================================================================*/

/**
 * \defgroup    AON_QDEC_Exported_Constants     Macro Definitions
 *
 * \ingroup     AON_QDEC
 */

#define IS_AON_QDEC_PERIPH(PERIPH) ((PERIPH) == AON_QDEC)

/** \defgroup   AON_QDEC_Axis                AON_QDEC Axis
 * \{
 * \ingroup     AON_QDEC_Exported_Types
 */

#define AON_QDEC_AXIS_X                             BIT0
/** \} */

/*============================================================================*
 *                         Types
 *============================================================================*/

/** \defgroup   AON_QDEC_Axis_counter_Scale     AON_QDEC Axis Counter
 * \{
 * \ingroup     AON_QDEC_Exported_Types
 */
typedef enum
{
    CounterScale_1_Phase = 0x00,
    CounterScale_2_Phase = 0x01,
} CNT_SCALE_PHASE_T;
#define IS_CNT_SCALE_PHASE_TYPE(TYPE) ((TYPE) <= 0x01)

/** \defgroup   AON_QDEC_Init_Phase          AON_QDEC Init Phase
 * \{
 * \ingroup     AON_QDEC_Exported_Types
 */
typedef enum
{
    phaseMode0 = 0x00,                              //phase 00
    phaseMode1 = 0x01,                              //phase 01
    phaseMode2 = 0x02,                              //phase 10
    phaseMode3 = 0x03,                              //phase 11
} PHSAE_MODE_T;
#define IS_PHSAE_MODE_TYPE(TYPE) ((TYPE) <= 0x03)
/** \} */

/** \defgroup   AON_QDEC_Axis_Direction      AON_QDEC Axis Direction
 * \{
 * \ingroup     AON_QDEC_Exported_Types
 */
#define AON_QDEC_AXIS_DIR_DOWN    0x00
#define AON_QDEC_AXIS_DIR_UP      0x01
#define IS_AON_QDEC_AXIS_DIR_TYPE(TYPE) ((TYPE) <= 0x01)
/** \} */

/** \defgroup   AON_QDEC_Interrupts_Definition  AON_QDEC Interrupts Definition
 * \{
 * \ingroup     AON_QDEC_Exported_Constants
 */
#define AON_QDEC_X_INT_NEW_DATA                     BIT0//get New data and state change
#define AON_QDEC_X_INT_ILLEAGE                      BIT1//illeage

/** \} */

#define IS_AON_QDEC_INT_CONFIG(CONFIG) (((CONFIG) == AON_QDEC_X_INT_NEW_DATA) || ((CONFIG) == AON_QDEC_X_INT_ILLEAGE))

/** \defgroup   AON_QDEC_Interrupts_Mask     AON_QDEC Interrupts Mask
 * \{
 * \ingroup     AON_QDEC_Exported_Constants
 */
#define AON_QDEC_X_INT_MASK                         BIT24
#define AON_QDEC_X_WAKE_AON_MASK                    BIT23
#define AON_QDEC_X_CT_INT_MASK                      BIT8//get New data and state change
#define AON_QDEC_X_ILLEAGE_INT_MASK                 BIT7//illeage

/** \} */

#define IS_AON_QDEC_INT_MASK_CONFIG(CONFIG) (((CONFIG) == AON_QDEC_X_CT_INT_MASK) || ((CONFIG) == AON_QDEC_X_ILLEAGE_INT_MASK))

/** \defgroup   AON_QDEC_Clr_Flag            AON_QDEC Clr Flag
 * \{
 * \ingroup     AON_QDEC_Exported_Types
 */
#define AON_QDEC_CLR_ILLEGAL_CT_X                   BIT5
#define AON_QDEC_CLR_ILLEGAL_INT_X                  BIT4
#define AON_QDEC_CLR_UNDERFLOW_X                    BIT3
#define AON_QDEC_CLR_OVERFLOW_X                     BIT2
#define AON_QDEC_CLR_NEW_CT_X                       BIT1
#define AON_QDEC_CLR_ACC_CT_X                       BIT0

/** \} */

#define IS_AON_QDEC_INT_CLR_CONFIG(CONFIG) (((CONFIG) == AON_QDEC_CLR_ACC_CT_X) ||  ((CONFIG) == AON_QDEC_CLR_ILLEGAL_INT_X)\
                                            || ((CONFIG) == AON_QDEC_CLR_UNDERFLOW_X) ||((CONFIG) == AON_QDEC_CLR_OVERFLOW_X)\
                                            || ((CONFIG) == AON_QDEC_CLR_NEW_CT_X))

/** \defgroup   AON_QDEC_Flag                AON_QDEC Flag
 * \{
 * \ingroup     AON_QDEC_Exported_Types
 */

#define AON_QDEC_FLAG_NEW_CT_STATUS_X               BIT0
#define AON_QDEC_FLAG_OVERFLOW_X                    BIT1
#define AON_QDEC_FLAG_UNDERFLOW_X                   BIT2
#define AON_QDEC_FLAG_ILLEGAL_STATUS_X              BIT4

/** \} */

#define IS_AON_QDEC_CLR_INT_STATUS(INT) (((INT) == AON_QDEC_FLAG_ILLEGAL_STATUS_X) || ((INT) == AON_QDEC_FLAG_NEW_CT_STATUS_X)\
                                         || ((INT) == AON_QDEC_FLAG_OVERFLOW_X) || ((INT) == AON_QDEC_FLAG_UNDERFLOW_X)\
                                         || ((INT) == AON_QDEC_FLAG_AUTO_STATUS_X))

/** \defgroup   AON_QDEC_Immediate_Number_definition     AON_QDEC Immediate Number definition
 * \{
 * \ingroup     AON_QDEC_Exported_Types
 */
#define AON_QDEC_0X04_CNT_DIR           BIT20
#define AON_QDEC_0X00_AXIS_EN           BIT31

/**
 * \defgroup    AON_QDEC_Exported_Types Init Params Struct
 *
 * \ingroup     AON QDEC
 */

/**
 * \brief       Qdecoder init structure definition.
 *
 * \ingroup     AON_QDEC_Exported_Types
 */
typedef struct
{
    FunctionalState QDEC_AxisConfigX;          /*!< Specifies the axis X function.
                                                   This parameter can be a value of ENABLE or DISABLE */
    FunctionalState QDEC_ManualLoadInitPhase;  /*!< Specifies manual-load Initphase function .
                                                   This parameter can be a value of ENABLE or DISABLE */
    CNT_SCALE_PHASE_T QDEC_CounterScaleX;      /*!< Specifies the axis X conter scale. */
    FunctionalState QDEC_DebounceEnableX;      /*!< Specifies the axis X debounce.
                                                   This parameter can be a value of ENABLE or DISABLE */
    uint16_t QDEC_DebounceTimeX;               /*!< Specifies the axis X debounce time. */
    PHSAE_MODE_T QDEC_InitPhaseX;              /*!< Specifies the axis X function. */
} AON_QDEC_InitTypeDef;

/*============================================================================*
 *                         Functions
 *============================================================================*/

/**
 * \defgroup    AON_QDEC_Exported_Functions Peripheral APIs
 * \{
 * \ingroup     AON_QDEC
 */

/**
 * \brief   Initializes the AON Qdecoder peripheral according to the specified
 *          parameters in the AON_QDEC_InitStruct
 * \param[in]  AON_QDECx: Selected AON Qdecoder peripheral.
 * \param[in]  AON_QDEC_InitStruct: Pointer to a AON_QDEC_InitStruct structure that
 *                              contains the configuration information for the specified AON Qdecoder peripheral
 * \return None.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_aon_qdec_init(void)
 * {
 *
 *     AON_QDEC_InitTypeDef AON_QDEC_InitStruct;
 *     AON_QDEC_StructInit(&AON_QDEC_InitStruct);
 *     AON_QDEC_InitStruct.axisConfigX       = ENABLE;
 *     AON_QDEC_InitStruct.debounceEnableX   = Debounce_Enable;
 *     AON_QDEC_Init(AON_QDEC, &AON_QDEC_InitStruct);
 *
 *     AON_QDEC_Cmd(AON_QDEC, AON_QDEC_AXIS_X, ENABLE);
 * }
 * \endcode
 */
void AON_QDEC_Init(AON_QDEC_TypeDef *AON_QDECx, AON_QDEC_InitTypeDef *AON_QDEC_InitStruct);

/**
 * \brief  Fills each AON_QDEC_InitStruct member with its default value.
 * \param[in]  AON_QDEC_InitStruct: Pointer to an AON_QDEC_InitStruct structure which will be initialized.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_aon_qdec_init(void)
 * {
 *
 *     AON_QDEC_InitTypeDef AON_QDEC_InitStruct;
 *     AON_QDEC_StructInit(&AON_QDEC_InitStruct);
 *     AON_QDEC_InitStruct.axisConfigX       = ENABLE;
 *     AON_QDEC_InitStruct.debounceEnableX   = Debounce_Enable;
 *     AON_QDEC_Init(AON_QDEC, &AON_QDEC_InitStruct);
 *
 *     AON_QDEC_Cmd(AON_QDEC, AON_QDEC_AXIS_X, ENABLE);
 * }
 * \endcode
 */
void AON_QDEC_StructInit(AON_QDEC_InitTypeDef *AON_QDEC_InitStruct);

/**
 * \brief  Enables or disables the specified AON Qdecoder interrupt source.
 * \param[in]  AON_QDECx: Selected AON Qdecoder peripheral.
 * \param[in]  AON_QDEC_IT: Specifies the AON QDECODER interrupts sources to be enabled or disabled.
 *      This parameter parameter can be one of the following values:
 *      \arg  AON_QDEC_X_INT_NEW_DATA: The counter interrupt for X axis.
 *      \arg  AON_QDEC_X_INT_ILLEAGE: The illegal interrupt for X axis.
 * \param[in]  NewState: New state of the specified QDECODER interrupt.
 *      This parameter parameter can be: ENABLE or DISABLE.
 * \return None.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_aon_qdec_init(void)
 * {
 *     AON_QDEC_INTConfig(AON_QDEC, AON_QDEC_X_INT_NEW_DATA, ENABLE);
 * }
 * \endcode
 */
void AON_QDEC_INTConfig(AON_QDEC_TypeDef *AON_QDECx, uint32_t AON_QDEC_IT,
                        FunctionalState NewState);

/**
 * \brief  Check whether the specified AON Qdecoder flag is set.
 * \param[in]  AON_QDECx: Selected AON Qdecoder peripheral.
 * \param[in]  AON_QDEC_FLAG: Specifies the flag to check.
 *      This parameter can be one of the following values:
 *      \arg AON_QDEC_FLAG_NEW_CT_STATUS_X: Status of the counter interrupt for X axis.
 *      \arg AON_QDEC_FLAG_ILLEGAL_STATUS_X: Status of the illegal interrupt for X axis.
 *      \arg AON_QDEC_FLAG_OVERFLOW_X: The overflow flag for x-axis accumulation counter.
 *      \arg AON_QDEC_FLAG_UNDERFLOW_X: The underflow flag for x-axis accumulation counter.
 * \retval The new state of AON_QDEC_FLAG (SET or RESET).
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void aon_qdec_demo(void)
 * {
 *     FlagStatus flag_status = AON_QDEC_GetFlagState(AON_QDEC, AON_QDEC_FLAG_NEW_CT_STATUS_X);
 * }
 * \endcode
 */
FlagStatus AON_QDEC_GetFlagState(AON_QDEC_TypeDef *AON_QDECx, uint32_t AON_QDEC_FLAG);

/**
 * \brief  Enables or disables mask the specified AON Qdecoder axis interrupts.
 * \param[in]  AON_QDECx: Selected AON Qdecoder peripheral.
 * \param[in]  AON_QDEC_AXIS: Specifies the AON Qdecoder axis.
 *      This parameter can be one or logical OR of the following values:
 *      \arg  AON_QDEC_X_CT_INT_MASK: The x-axis counter interrupt mask.
 *      \arg  AON_QDEC_X_ILLEAGE_INT_MASK: The x-axis illegal interrupt mask.
 * \param[in]  NewState: New state of the specified AON Qdecoder interrupts mask.
 *      This parameter can be: ENABLE or DISABLE.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void aon_qdec_demo(void)
 * {
 *
 *     AON_QDEC_INTMask(AON_QDEC, AON_QDEC_X_CT_INT_MASK, ENABLE);
 *
 * }
 * \endcode
 */
void AON_QDEC_INTMask(AON_QDEC_TypeDef *AON_QDECx, uint32_t AON_QDEC_AXIS,
                      FunctionalState NewState);

/**
 * \brief  Enable or disable the selected AON Qdecoder axis x.
 * \param[in]  AON_QDECx: Selected AON Qdecoder peripheral.
 * \param[in]  AON_QDEC_AXIS: Specifies the AON Qdecoder axis.
 *      This parameter can be one of the following values:
 *      \arg  AON_QDEC_AXIS_X: The AON qdecoder X axis.
 * \param[in]  NewState: New state of the selected AON Qdecoder axis.
 *      This parameter can be : ENABLE or DISABLE.
 * \retturn The count of the axis.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void aon_qdec_demo(void)
 * {
 *     AON_QDEC_Cmd(AON_QDEC, AON_QDEC_AXIS_X, ENABLE);
 * }
 * \endcode
 */
void AON_QDEC_Cmd(AON_QDEC_TypeDef *AON_QDECx, uint32_t AON_QDEC_AXIS,
                  FunctionalState NewState);

/**
 * \brief   Clear AON Qdecoder interrupt pending bit.
 * \param[in]  AON_QDECx: Selected AON Qdecoder peripheral.
 * \param[in]  AON_QDEC_FLAG: Specifies the flag to clear.
 *      This parameter parameter can be one of the following values:
 *      \arg  AON_QDEC_CLR_OVERFLOW_X: The overflow flag for x-axis accumulation counter.
 *      \arg  AON_QDEC_CLR_ILLEGAL_INT_X: The illegal interrupt for X axis.
 *      \arg  AON_QDEC_CLR_UNDERFLOW_X: The underflow flag for x-axis accumulation counter.
 *      \arg  AON_QDEC_CLR_NEW_CT_X: The counter interrupt for X axis.
 * \return  None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void aon_qdec_demo(void)
 * {
 *     AON_QDEC_ClearINTPendingBit(AON_QDEC, AON_QDEC_CLR_OVERFLOW_X);
 * }
 * \endcode
 */

void AON_QDEC_ClearINTPendingBit(AON_QDEC_TypeDef *AON_QDECx, uint32_t AON_QDEC_CLR_INT);
/**
 * \brief  Get AON Qdecoder Axis(x/y/z) direction.
 * \param[in]  AON_QDECx: Selected AON Qdecoder peripheral.
 * \param[in]  AON_QDEC_AXIS: Specifies the AON Qdecoder axis.
 *      This parameter parameter can be one of the following values:
 *      \arg  AON_QDEC_AXIS_X: The AON qdecoder X axis.
 * \return The direction of the axis.
 *      This parameter parameter can be one of the following values:
 *     \retval AON_QDEC_AXIS_DIR_UP: The axis is rolling up.
 *     \retval AON_QDEC_AXIS_DIR_DOWN: The axis is rolling down.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void aon_qdec_demo(void)
 * {
 *     uint16_t dir = AON_QDEC_GetAxisDirection(AON_QDEC, AON_QDEC_AXIS_X);
 * }
 * \endcode
 */
__STATIC_INLINE uint16_t AON_QDEC_GetAxisDirection(AON_QDEC_TypeDef *AON_QDECx,
                                                   uint32_t AON_QDEC_AXIS)
{
    /* Check the parameters */
    assert_param(IS_AON_QDEC_PERIPH(AON_QDECx));
    assert_param(IS_AON_QDEC_AXIS_DIR(AON_QDEC_AXIS));

    return ((*((volatile uint32_t *)(&AON_QDECx->AON_QDEC_SR_X)) & (1 << 20)) == AON_QDEC_0X04_CNT_DIR);
}

/**
 * \brief  Get AON Qdecoder Axis(x/y/z) count.
 * \param[in]  AON_QDECx: Selected AON Qdecoder peripheral.
 * \param[in]  AON_QDEC_AXIS: Specifies the AON Qdecoder axis.
 *      This parameter parameter can be one of the following values:
 *      \arg  AON_QDEC_AXIS_X: The AON qdecoder X axis.
 * \return The count of the axis.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void aon_qdec_demo(void)
 * {
 *     uint16_t counter = AON_QDEC_GetAxisCount(AON_QDEC, AON_QDEC_AXIS_X);
 * }
 * \endcode
 */
__STATIC_INLINE uint16_t AON_QDEC_GetAxisCount(AON_QDEC_TypeDef *AON_QDECx,
                                               uint32_t AON_QDEC_AXIS)
{
    /* Check the parameters */
    assert_param(IS_AON_QDEC_PERIPH(AON_QDECx));
    assert_param(IS_AON_QDEC_AXIS_DIR(AON_QDEC_AXIS));

    return ((uint16_t)(*((volatile uint32_t *)(&AON_QDECx->AON_QDEC_SR_X))));
}

/**
 * \brief  Pause or resume AON Qdecoder Axis x.
 * \param[in]  AON_QDECx: Selected AON Qdecoder peripheral.
 * \param[in]  AON_QDEC_AXIS: Specifies the AON Qdecoder axis.
 *      This parameter parameter can be one of the following values:
 *      \arg  AON_QDEC_AXIS_X: The AON qdecoder X axis.

 * \param[in]  NewState: New state of the specified AON Qdecoder Axis.
 *      This parameter parameter can be one of the following values:
 *      \arg  ENABLE: Pause.
 *      \arg  DISABLE: Resume.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void aon_qdec_demo(void)
 * {
 *     AON_QDEC_CounterPauseCmd(AON_QDEC, AON_QDEC_AXIS_X, ENABLE);
 * }
 * \endcode
 */
__STATIC_INLINE void AON_QDEC_CounterPauseCmd(AON_QDEC_TypeDef *AON_QDECx,
                                              uint32_t AON_QDEC_AXIS,
                                              FunctionalState NewState)
{
    /* Check the parameters */
    assert_param(IS_AON_QDEC_PERIPH(AON_QDECx));
    assert_param(IS_AON_QDEC_AXIS_DIR(AON_QDEC_AXIS));

    AON_QDEC_CONFIG_t aon_qdec_0x00 = {.d32 = AON_QDECx->AON_QDEC_CONFIG};
    aon_qdec_0x00.b.x_cnt_pause = NewState;
    AON_QDECx->AON_QDEC_CONFIG = aon_qdec_0x00.d32;
}

/** \} */ /* End of group AON_QDEC_Exported_Functions */

#ifdef __cplusplus
}
#endif

#endif /* RTL_AON_QDEC_H */


/******************* (C) COPYRIGHT 2016 Realtek Semiconductor *****END OF FILE****/

