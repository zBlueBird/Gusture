/**
*****************************************************************************************
*     Copyright(c) 2017, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
  * @file    aon_wdg.h
  * @brief   This file provides api wrapper for bbpro compatibility..
  * @author  sandy_jiang
  * @date    2018-11-29
  * @version v1.0
  * *************************************************************************************
   * @attention
   * <h2><center>&copy; COPYRIGHT 2017 Realtek Semiconductor Corporation</center></h2>
   * *************************************************************************************
  */

/*============================================================================*
 *               Define to prevent recursive inclusion
 *============================================================================*/
#ifndef __AON_WDG_H_
#define __AON_WDG_H_


/*============================================================================*
 *                               Header Files
*============================================================================*/
#include <stdint.h>
#include <stdbool.h>
#include "rtl876x_wdg.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
   * @brief  Start AON Watchdog.
     * @param  ms
       * @param  wdg_mode @ref T_WDG_MODE valid value: RESET_ALL and RESET_ALL_EXCEPT_AON
   */
bool aon_wdg_start(uint32_t t_ms, T_WDG_MODE mode);

/**
   * @brief  Disable AON Watchdog.
   */
void aon_wdg_disable(void);

/**
   * @brief  Kick AON Watchdog to restart watchdog timer.
   */
void aon_wdg_kick(void);

#ifdef __cplusplus
}
#endif

#endif
