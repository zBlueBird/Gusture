#ifndef RTL_LPC_REG_H
#define RTL_LPC_REG_H

#include <stdint.h>
#include <stdbool.h>
#include "rtl876x.h"

#ifdef  __cplusplus
extern "C" {
#endif /* __cplusplus */

/*============================================================================*
 *                         LPC Registers Memory Map
 *============================================================================*/
typedef struct
{
    __IO uint32_t LPC_CR0;        /*!< 0x00 */
    __IO uint32_t LPC_SR;         /*!< 0x04 */
} LPC_TypeDef;

/*============================================================================*
 *                         LPC Declaration
 *============================================================================*/
#define LPC0               ((LPC_TypeDef *) LPC_REG_BASE)
#define LPC1               ((LPC_TypeDef *) LPC1_REG_BASE)

/*============================================================================*
 *                         LPC Registers and Field Descriptions
 *============================================================================*/
/* 0x00
    7:0     R/W    lpcomp_deb_cnt             8'b0
    10:8    R/W    lpcomp_deb_div             3'b0
    11      R/W    lpcomp_deb_en              1'b0
    12      R/W    lpcomp_hys_en              1'b0
    13      R/W    lpcomp_single_output_en    1'b0
    14      W1C    rsvd                       1'b0
    15      R/W    rsvd                       1'b0
    16      R/W    lpcomp_ie                  1'b0
    17      R/W    lpcomp_src_int_en          1'b0
    18      R/W    lpcomp_src_aon_int_en      1'b0
    19      R/W    lpcomp_deb_sel             1'b0
    30:20   R/W    lpc_cr0_dummy              11'b0
    31      R/W    lpc_cr1_dummy              1'b0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t lpcomp0_deb_cnt: 8;
        __IO uint32_t lpcomp0_deb_div: 3;
        __IO uint32_t lpcomp0_deb_en: 1;
        __IO uint32_t lpcomp0_hys_en: 1;
        __IO uint32_t lpcomp0_single_output_en: 1;
        __IO uint32_t reserved_1: 1;
        __IO uint32_t reserved_0: 1;
        __IO uint32_t lpcomp0_ie: 1;
        __IO uint32_t lpcomp0_src_int_en: 1;
        __IO uint32_t lpcomp0_src_aon_int_en: 1;
        __IO uint32_t lpcomp0_deb_sel: 1;
        __IO uint32_t lpc0_cr0_dummy: 11;
        __IO uint32_t lpc0_cr1_dummy: 1;
    } b;
} LPC_CR0_t;

/* 0x04
    0       R      lpcomp0_flag                1'b0
    1       R      lpcomp0_out_aon_flag        1'b0
    31:2    R/W    lpc0_sr_Dummy               30'b0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t lpcomp_flag: 1;
        __I uint32_t lpcomp_out_aon_flag: 1;
        __IO uint32_t lpc_sr_Dummy: 30;
    } b;
} LPC_SR_t;
/*============================================================================*
 *                         Types
 *============================================================================*/
#ifdef  __cplusplus
}
#endif /* __cplusplus */
#endif /* RTL_ADC_24BIT_REG_H */
