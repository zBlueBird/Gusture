/**
*********************************************************************************************************
*               Copyright(c) 2023, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* \file     rtl_lpc.h
* \brief    The header file of the peripheral LPC driver.
* \details  This file provides all LPC firmware functions.
* \author   echo
* \date     2023-01-09
* \version  v1.0.0
* *********************************************************************************************************
*/

#ifndef _RTL_LPC_H_
#define _RTL_LPC_H_
#ifdef __cplusplus
extern "C" {
#endif

/**
 * \addtogroup  IO          Peripheral Drivers
 * \defgroup    LPC         LPC
 *
 * \brief       Manage the LPC peripheral functions.
 *
 * \ingroup     IO
 */

/*============================================================================*
 *                         Includes
 *============================================================================*/
#include "rtl876x.h"
#include "rtl876x_aon_reg.h"
#include "rtl_lpc_reg.h"

/*============================================================================*
 *                         Types
 *============================================================================*/
/**
 * \defgroup    LPC_Channel LPC Channel
 * \{
 * \ingroup     LPC_Exported_constants
 */
typedef enum
{
    LPC_CHANNEL_ADC0,
    LPC_CHANNEL_ADC1,
    LPC_CHANNEL_ADC2,
    LPC_CHANNEL_ADC3,
    LPC_CHANNEL_VD33,
    LPC_CHANNEL_ADC4,
    LPC_CHANNEL_ADC5,
    LPC_CHANNEL_ADC6,
    LPC_CHANNEL_ADC7,
    LPC_CHANNEL_VD18,
} LPC_CHANNEL_SEL_T;
/** \} */
#define IS_LPC_CHANNEL(CHANNEL) (((CHANNEL) == LPC_CHANNEL_ADC0) || \
                                 ((CHANNEL) == LPC_CHANNEL_ADC1) || \
                                 ((CHANNEL) == LPC_CHANNEL_ADC2) || \
                                 ((CHANNEL) == LPC_CHANNEL_ADC3) || \
                                 ((CHANNEL) == LPC_CHANNEL_ADC4) || \
                                 ((CHANNEL) == LPC_CHANNEL_ADC5) || \
                                 ((CHANNEL) == LPC_CHANNEL_ADC6) || \
                                 ((CHANNEL) == LPC_CHANNEL_ADC7) || \
                                 ((CHANNEL) == LPC_CHANNEL_ADC5) || \
                                 ((CHANNEL) == LPC_CHANNEL_ADC6) || \   ((CHANNEL) == LPC_CHANNEL_VD18))
/** \defgroup   LPC_Edge    LPC Edge
 * \{
 * \ingroup     LPC_Exported_constants
 */
typedef enum
{
    LPC_Vin_Below_Vth,
    LPC_Vin_Over_Vth,
} LPC_EDGE_T;
/** \} */
#define IS_LPC_EDGE(EDGE) (((EDGE) == LPC_Vin_Below_Vth) || \
                           ((EDGE) == LPC_Vin_Over_Vth))
/** \defgroup   LPC_Mode    LPC Mode
 * \{
 * \ingroup     LPC_Exported_constants
 */
typedef enum
{
    LPC_BYPASS_MODE,
    LPC_DIVIDE_MODE,
} LPC_MODE_T;
/** \} */
#define IS_LPC_MODE(MODE) (((MODE) == LPC_BYPASS_MODE) || \
                           ((MODE) == LPC_DIVIDE_MODE))
/** \defgroup   LPC_Debounce_Div   LPC Debounce Div
 * \{
 * \ingroup     LPC_Exported_constants
 */
typedef enum
{
    LPC_DEBOUNCE_DIV_1,
    LPC_DEBOUNCE_DIV_2,
    LPC_DEBOUNCE_DIV_4,
    LPC_DEBOUNCE_DIV_8,
    LPC_DEBOUNCE_DIV_16,
    LPC_DEBOUNCE_DIV_32,
    LPC_DEBOUNCE_DIV_40,
    LPC_DEBOUNCE_DIV_64,
} LPC_DEB_DIV_T;
/** \} */
#define IS_LPC_DEB_DIV(DIV) (((DIV) == LPC_DEBOUNCE_DIV_1) || \
                             ((DIV) == LPC_DEBOUNCE_DIV_2) || \
                             ((DIV) == LPC_DEBOUNCE_DIV_4) || \
                             ((DIV) == LPC_DEBOUNCE_DIV_8) || \
                             ((DIV) == LPC_DEBOUNCE_DIV_16) || \
                             ((DIV) == LPC_DEBOUNCE_DIV_32) || \
                             ((DIV) == LPC_DEBOUNCE_DIV_40) || \
                             ((DIV) == LPC_DEBOUNCE_DIV_64))
/** \defgroup   LPC_Trgger_Mode    LPC Trigger Mode
 * \{
 * \ingroup     LPC_Exported_constants
 */
typedef enum
{
    LPC_SINGLE_OUTPUT,
    LPC_DUAL_OUTPUT,
} LPC_TRIGGER_MODE_T;
/** \} */
#define IS_LPC_TRIGGER_MODE(MODE) (((MODE) == LPC_SINGLE_OUTPUT) || \
                                   ((MODE) == LPC_DUAL_OUTPUT))

///** \defgroup   LPC_Threshold_Bypass   LPC Threshold_Bypass
// * \{
// * \ingroup     LPC_Exported_constants
// */
//typedef enum
//{
//    LPC_30_mV   = 0x0000,
//    LPC_55_mV   = 0x0001,
//    LPC_80_mV   = 0x0002,
//    LPC_105_mV  = 0x0003,
//    LPC_130_mV  = 0x0004,
//    LPC_155_mV  = 0x0005,
//    LPC_180_mV  = 0x0006,
//    LPC_205_mV  = 0x0007,
//    LPC_230_mV  = 0x0008,
//    LPC_255_mV  = 0x0009,
//    LPC_280_mV  = 0x000a,
//    LPC_305_mV  = 0x000b,
//    LPC_330_mV  = 0x000c,
//    LPC_355_mV  = 0x000d,
//    LPC_380_mV  = 0x000e,
//    LPC_405_mV  = 0x000f,
//    LPC_430_mV  = 0x0010,
//    LPC_455_mV  = 0x0011,
//    LPC_480_mV  = 0x0012,
//    LPC_505_mV  = 0x0013,
//    LPC_530_mV  = 0x0014,
//    LPC_555_mV  = 0x0015,
//    LPC_580_mV  = 0x0016,
//    LPC_605_mV  = 0x0017,
//    LPC_630_mV  = 0x0018,
//    LPC_655_mV  = 0x0019,
//    LPC_680_mV  = 0x001a,
//    LPC_705_mV  = 0x001b,
//    LPC_730_mV  = 0x001c,
//    LPC_755_mV  = 0x001d,
//    LPC_780_mV  = 0x001e,
//    LPC_805_mV  = 0x001f,
//} LPC_THRDSHOD_T;
///** \} */

/** \defgroup   LPC_Threshold_Bypass   LPC Threshold_Bypass
 * \{
 * \ingroup     LPC_Exported_constants
 */

#define    LPC_30_mV    0x0000
#define    LPC_55_mV    0x0001
#define    LPC_80_mV    0x0002
#define    LPC_105_mV   0x0003
#define    LPC_130_mV   0x0004
#define    LPC_155_mV   0x0005
#define    LPC_180_mV   0x0006
#define    LPC_205_mV   0x0007
#define    LPC_230_mV   0x0008
#define    LPC_255_mV   0x0009
#define    LPC_280_mV   0x000a
#define    LPC_305_mV   0x000b
#define    LPC_330_mV   0x000c
#define    LPC_355_mV   0x000d
#define    LPC_380_mV   0x000e
#define    LPC_405_mV   0x000f
#define    LPC_430_mV   0x0010
#define    LPC_455_mV   0x0011
#define    LPC_480_mV   0x0012
#define    LPC_505_mV   0x0013
#define    LPC_530_mV   0x0014
#define    LPC_555_mV   0x0015
#define    LPC_580_mV   0x0016
#define    LPC_605_mV   0x0017
#define    LPC_630_mV   0x0018
#define    LPC_655_mV   0x0019
#define    LPC_680_mV   0x001a
#define    LPC_705_mV   0x001b
#define    LPC_730_mV   0x001c
#define    LPC_755_mV   0x001d
#define    LPC_780_mV   0x001e
#define    LPC_805_mV   0x001f
/** \} */

/** \defgroup   LPC_Threshold_Divide   LPC Threshold_Divide
 * \{
 * \ingroup     LPC_Exported_constants
 */

#define    LPC_128_mV    0x0000
#define    LPC_235_mV    0x0001
#define    LPC_342_mV    0x0002
#define    LPC_489_mV   0x0003
#define    LPC_556_mV   0x0004
#define    LPC_662_mV   0x0005
#define    LPC_769_mV   0x0006
#define    LPC_876_mV   0x0007
#define    LPC_983_mV   0x0008
#define    LPC_1090_mV   0x0009
#define    LPC_1197_mV   0x000a
#define    LPC_1303_mV   0x000b
#define    LPC_1410_mV   0x000c
#define    LPC_1517_mV   0x000d
#define    LPC_1624_mV   0x000e
#define    LPC_1731_mV   0x000f
#define    LPC_1838_mV   0x0010
#define    LPC_1944_mV   0x0011
#define    LPC_2051_mV   0x0012
#define    LPC_2158_mV   0x0013
#define    LPC_2265_mV   0x0014
#define    LPC_2372_mV   0x0015
#define    LPC_2479_mV   0x0016
#define    LPC_2585_mV   0x0017
#define    LPC_2692_mV   0x0018
#define    LPC_2900_mV   0x0019
#define    LPC_2906_mV   0x001a
#define    LPC_3012_mV   0x001b
#define    LPC_3120_mV   0x001c
#define    LPC_3226_mV   0x001d
#define    LPC_3333_mV   0x001e
#define    LPC_3440_mV   0x001f
/** \} */

#define IS_LPC_THRESHOLD(THRESHOLD) ((THRESHOLD) <= 0x1F)


/**
 * \brief       LPC init structure definition
 *
 * \ingroup     LPC_Exported_Types
 */
typedef struct
{

    LPC_CHANNEL_SEL_T LPC_Channel;     /*!< Specifies the input pin.*/
    LPC_MODE_T LPC_Mode;               /*!< Specifies the LPC mode.*/
    LPC_EDGE_T LPC_Edge;               /*!< Specifies the comparator output edge. */
    uint8_t LPC_Threshold;             /*!< Specifies the threshold value of comparator voltage.
                                             This parameter can be a value of  \ref LPC_Threshold_Bypass or  \ref LPC_Threshold_Divide*/
    uint8_t LPC_ThresholdL;            /*!< Specifies the threshold value of comparator voltage. */
    FunctionalState LPC_DebouncEn;     /*!< Specifies the LPC Debounce. */
    LPC_DEB_DIV_T LPC_DebouncDiv;      /*!< Specifies the LPC Debounce Divider. */
    uint32_t LPC_DebouncCnt;           /*!< Set lpcomp debounce time debounce . debounce time=(LPC_CLK/(reg_lpcomp0_deb_cnt+1)). LPC_DebouncCnt <=255*/
    LPC_TRIGGER_MODE_T
    LPC_TrigerMode; /*!< Specifies the LPC0 triger mode selection.0:single op output,1:dual op hysteresis */
} LPC_InitTypeDef;

/*============================================================================*
 *                         Constants
 *============================================================================*/


/** \defgroup   LPC_Interrupts_Definition   LPC Interrupts Definition
 * \{
 * \ingroup     LPC_Exported_constants
 */
#define LPC_INT_LPCOMP                 (BIT17)
#define LPC_INT_LPCOMP_AON             (BIT18)
/** \} */

#define IS_LPC_CONFIG_INT(INT) ((INT) == LPC_INT_LPCOMP )
#define IS_LPC_STATUS_INT(INT) ((INT) == LPC_INT_LPCOMP )
#define IS_LPC_CLEAR_INT(INT) ((INT) ==  LPC_INT_LPCOMP )

/** \defgroup   LPC_Flags_Definition    LPC Flags Definition
 * \{
 * \ingroup     LPC_Exported_constants
 */
#define LPC_FLAG_LPCOMP                     (BIT0)
#define LPC_FLAG_LPCOMP_AON                 (BIT1)

/** \} */

#define IS_LPC_FLAG(FLAG) (((FLAG) == LPC_FLAG_LPCOMP_AON) || \
                           ((FLAG) == LPC_FLAG_LPCOMP))
#define IS_LPC_CLEAR_FLAG(FLAG) ((FLAG) == LPC_FLAG_LPCOMP)


/*============================================================================*
 *                         Functions
 *============================================================================*/

/**
 * \defgroup    LPC_Exported_Functions  Peripheral APIs
 * \{
 * \ingroup     LPC
 */

/**
  * @brief  Reset LPC.
  * @param  LPCx: where x can be 0 to 1  to select the LPC Channel.
  * @return None
  */
void LPC_DeInit(LPC_TypeDef *LPCx);

/**
 * \brief   Initializes LPC peripheral according to
 *          the specified parameters in LPC_InitStruct.
 * \param[in] LPCx: where x can be 0 to 1  to select the LPC Channel.
 * \param[in] LPC_InitStruct: Pointer to a LPC_InitTypeDef structure that contains
 *                            the configuration information for the specified LPC peripheral.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_lpc_init(void)
 * {
 *     LPC_InitTypeDef LPC_InitStruct;
 *
 *     LPC_StructInit(&LPC_InitStruct);
 *     LPC_InitStruct.LPC_Channel   = LPC_CAPTURE_CHANNEL;
 *     LPC_InitStruct.LPC_Edge      = LPC_VOLTAGE_DETECT_EDGE;
 *     LPC_InitStruct.LPC_Threshold = LPC_VOLTAGE_DETECT_THRESHOLD;
 *     LPC_Init(LPC0,&LPC_InitStruct);
 *     LPC_Cmd(LPC0,ENABLE);
 *
 *     LPC_INTConfig(LPC_INT_LPCOMP, ENABLE);
 *
 *     NVIC_InitTypeDef NVIC_InitStruct;
 *     NVIC_InitStruct.NVIC_IRQChannel = LPC_IRQn;
 *     NVIC_InitStruct.NVIC_IRQChannelPriority = 2;
 *     NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
 *     NVIC_Init(&NVIC_InitStruct);

 *     LPC_NvCmd(LPC0,ENABLE);
 * }
 * \endcode
 */
void LPC_Init(LPC_TypeDef *LPCx, LPC_InitTypeDef *LPC_InitStruct);

/**
 * \brief  Fills each LPC_InitStruct member with its default value.
 * \param[in]  LPCx: where x can be 0 to 1  to select the LPC Channel.
 * \param[in]  LPC_InitStruct : Pointer to a LPC_InitTypeDef structure which will be initialized.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_lpc_init(void)
 * {
 *     LPC_InitTypeDef LPC_InitStruct;
 *
 *     LPC_StructInit(&LPC_InitStruct);
 *     LPC_InitStruct.LPC_Channel   = LPC_CAPTURE_CHANNEL;
 *     LPC_InitStruct.LPC_Edge      = LPC_VOLTAGE_DETECT_EDGE;
 *     LPC_InitStruct.LPC_Threshold = LPC_VOLTAGE_DETECT_THRESHOLD;
 *     LPC_Init(LPC0,&LPC_InitStruct);
 * }
 * \endcode
 */
void LPC_StructInit(LPC_InitTypeDef *LPC_InitStruct);

/**
 * \brief  Enables or disables LPC peripheral.
 * \param[in]  LPCx: where x can be 0 to 1  to select the LPC Channel.
 * \param[in]  NewState: New state of LPC peripheral.
 *      This parameter can be: ENABLE or DISABLE.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_lpc_init(void)
 * {
 *     LPC_InitTypeDef LPC_InitStruct;
 *
 *     LPC_StructInit(&LPC_InitStruct);
 *     LPC_InitStruct.LPC_Channel   = LPC_CAPTURE_CHANNEL;
 *     LPC_InitStruct.LPC_Edge      = LPC_VOLTAGE_DETECT_EDGE;
 *     LPC_InitStruct.LPC_Threshold = LPC_VOLTAGE_DETECT_THRESHOLD;
 *     LPC_Init(LPC0, &LPC_InitStruct);
 *     LPC_Cmd(LPC0,ENABLE);
 * }
 * \endcode
 */
void LPC_Cmd(LPC_TypeDef *LPCx, FunctionalState NewState);

/**
 * \brief  Enables or disables the specified LPC interrupts.
 * \param[in] LPCx: where x can be 0 to 1  to select the LPC Channel.
 * \param[in] LPC_INT: Specifies the LPC interrupt source to be enabled or disabled.
 *      This parameter can be one of the following values:
  *     @arg LPC_INT_LPCOMP: voltage detection interrupt.
  *     @arg LPC_INT_LPCOMP_AON: wakeup voltage detection interrupt.
 * \param[in]  NewState: New state of the specified LPC interrupt.
 *      This parameter can be: ENABLE or DISABLE.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_lpc_init(void)
 * {
 *     LPC_InitTypeDef LPC_InitStruct;
 *
 *     LPC_StructInit(&LPC_InitStruct);
 *     LPC_InitStruct.LPC_Channel   = LPC_CAPTURE_CHANNEL;
 *     LPC_InitStruct.LPC_Edge      = LPC_VOLTAGE_DETECT_EDGE;
 *     LPC_InitStruct.LPC_Threshold = LPC_VOLTAGE_DETECT_THRESHOLD;
 *     LPC_Init(&LPC_InitStruct);
 *     LPC_Cmd(LPC0,ENABLE);
 *
 *     LPC_INTConfig(LPC0,LPC_INT_LPCOMP, ENABLE);
 *
 *     NVIC_InitTypeDef NVIC_InitStruct;
 *     NVIC_InitStruct.NVIC_IRQChannel = LPC0_IRQn;
 *     NVIC_InitStruct.NVIC_IRQChannelPriority = 2;
 *     NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
 *     NVIC_Init(&NVIC_InitStruct);

 *     LPC_NvCmd(LPC0,ENABLE);
 * }
 * \endcode
 */
void LPC_INTConfig(LPC_TypeDef *LPCx, uint32_t LPC_INT, FunctionalState NewState);



/**
 * \brief     Enable wakeup signal to power sequence.
 * \param[in] LPCx: where x can be 0 to 1  to select the LPC Channel.
 * \param[in] NewState: Enable or disable LPC wakeup signal to power sequence.
 *            This parameter can be: ENABLE or DISABLE..
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_lpc_init(void)
 * {
 *     LPC_InitTypeDef LPC_InitStruct;
 *
 *     LPC_StructInit(&LPC_InitStruct);
 *     LPC_InitStruct.LPC_Channel   = LPC_CAPTURE_CHANNEL;
 *     LPC_InitStruct.LPC_Edge      = LPC_VOLTAGE_DETECT_EDGE;
 *     LPC_InitStruct.LPC_Threshold = LPC_VOLTAGE_DETECT_THRESHOLD;
 *     LPC_Init(LPC0,&LPC_InitStruct);
 *     LPC_Cmd(LPC0,ENABLE);
 *
 *     LPC_INTConfig(LPC0, LPC_INT_LPCOMP, ENABLE);
 *     LPC_INTCmd(LPC0,ENABLE);
 *     LPC_WKCmd(LPC0,ENABLE);
 *
 *     NVIC_InitTypeDef NVIC_InitStruct;
 *     NVIC_InitStruct.NVIC_IRQChannel = RTC_IRQn;
 *     NVIC_InitStruct.NVIC_IRQChannelPriority = 2;
 *     NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
 *     NVIC_Init(&NVIC_InitStruct);
 * }
 * \endcode
 */
void LPC_WKCmd(LPC_TypeDef *LPCx, FunctionalState NewState);

/**
  * @brief  Checks whether the specified LPC interrupt is set or not.
 * \param[in] LPCx: where x can be 0 to 1  to select the LPC Channel.
  * @param  LPC_FLAG: specifies the LPC interrupt to check.
  *     This parameter can be one of the following values:
  *     @arg LPC_INT_LPCOMP: voltage detection interrupt.
  *     @arg LPC_INT_LPCOMP_AON: wakeup voltage detection interrupt.
  * @retval The new state of SPI_IT (SET or RESET).
  */
FlagStatus LPC_GetFlagStatus(LPC_TypeDef *LPCx, uint32_t LPC_FLAG);

/**
  * @brief  Clear the specified LPC flag.
 * \param[in] LPCx: where x can be 0 to 1  to select the LPC Channel.
  * @param  LPC_FLAG: specifies the LPC flag to clear.
  *   This parameter can be one of the following values:
  *     @arg LPC_FLAG_LPCOMP: LPC NVIC flag.
  * @retval None
  */
void LPC_ClearFlag(LPC_TypeDef *LPCx, uint32_t LPC_FLAG);

/**
 * \brief  Checks whether the specified LPC interrupt is set or not.

 * \param[in]  LPC_INT: specifies the LPC interrupt to check.
 *   This parameter can be one of the following values:
  *     @arg LPC_INT_LPCOMP: voltage detection interrupt.
  *     @arg LPC_INT_LPCOMP_AON: wakeup voltage detection interrupt.
 * \return  The new state of SPI_IT (SET or RESET).
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * #define LPC_CAPTURE_PIN                 P2_3
 * #define LPC_CAPTURE_CHANNEL             LPC_CAPTURE_PIN - P2_0

 * #define LPC_VOLTAGE_DETECT_EDGE         LPC_Vin_Over_Vth;
 * #define LPC_VOLTAGE_DETECT_THRESHOLD    LPC_2400_mV;
 * #define LPC_COMP_VALUE                  0x0A//A LPC comparator interrupt occurs every ten times
 *
 * void board_lpc_init(void)
 * {
 *     Pad_Config(LPC_CAPTURE_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE,
 *                PAD_OUT_HIGH);
 *     Pinmux_Config(LPC_CAPTURE_PIN, IDLE_MODE);
 * }
 *
 * void driver_lpc_init(void)
 * {
 *     LPC_InitTypeDef LPC_InitStruct;
 *
 *     LPC_StructInit(&LPC_InitStruct);
 *     LPC_InitStruct.LPC_Channel   = LPC_CAPTURE_CHANNEL;
 *     LPC_InitStruct.LPC_Edge      = LPC_VOLTAGE_DETECT_EDGE;
 *     LPC_InitStruct.LPC_Threshold = LPC_VOLTAGE_DETECT_THRESHOLD;
 *     LPC_Init(LPC0,&LPC_InitStruct);
 *     LPC_Cmd(LPC0,ENABLE);
 *
 *     LPC_INTConfig(LPC_INT_LPCOMP, ENABLE);
 *
 *     NVIC_InitTypeDef NVIC_InitStruct;
 *     NVIC_InitStruct.NVIC_IRQChannel = LPC0_IRQn;
 *     NVIC_InitStruct.NVIC_IRQChannelPriority = 2;
 *     NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
 *     NVIC_Init(&NVIC_InitStruct);

 *     LPC_NvCmd(ENABLE);
 * }
 *
 * void lpc_demo(void)
 * {
 *     board_lpc_init();
 *     driver_lpc_init();
 * }
 *
 * void LPCOMP_Handler(void)
 * {
 *     if (LPC_GetINTStatus(LPC_INT_LPCOMP) == SET)
 *     {
 *         LPC_ClearINTPendingBit(LPC_INT_LPCOMP);
 *     }
 * }
 * \endcode
 */
ITStatus LPC_GetINTStatus(LPC_TypeDef *LPCx, uint32_t LPC_INT);

/** \} */ /* End of group LPC_Exported_Functions */

#ifdef __cplusplus
}
#endif

#endif /* _RTL_LPC_H_ */



/******************* (C) COPYRIGHT 2020 Realtek Semiconductor Corporation *****END OF FILE****/

