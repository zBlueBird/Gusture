/**
*********************************************************************************************************
*               Copyright(c) 2020, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* \file     rtl_rtc.h
* \brief    The header file of the peripheral RTC driver.
* \details  This file provides all RTC firmware functions.
* \author   grace_yan
* \date     2023-01-16
* \version  v2.1.0
* *********************************************************************************************************
*/

#ifndef RTL_RTC_H
#define RTL_RTC_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * \addtogroup  IO          Peripheral Drivers
 * \defgroup    RTC         RTC
 *
 * \brief       Manage the RTC peripheral functions.
 *
 * \ingroup     IO
 */

/*============================================================================*
 *                         Includes
 *============================================================================*/
#include "rtl876x.h"
#include "rtl_rtc_reg.h"

/*============================================================================*
 *                         Constants
 *============================================================================*/
/**
 * \defgroup    RTC_Exported_Constants Macro Definitions
 *
 * \ingroup     RTC
 */


/*============================================================================*
 *                         Types
 *============================================================================*/
/**
 * \defgroup    RTC_Comp_Definition RTC Comparator Definition
 * \{
 * \ingroup     RTC_Exported_Constants
 */
typedef enum
{
    RTC_COMP0 = 0x00,
    RTC_COMP1 = 0x01,
    RTC_COMP2 = 0x02,
    RTC_COMP3 = 0x03,
} RTC_COMP_INDEX_T;

#define IS_RTC_COMP(COMP) (((COMP) == RTC_COMP0) || \
                           ((COMP) == RTC_COMP1) || \
                           ((COMP) == RTC_COMP2) || \
                           ((COMP) == RTC_COMP3))
/** \} */

/**
 * \defgroup    RTC_CompGT_Definition RTC ComparatorGT Definition
 * \{
 * \ingroup     RTC_Exported_Constants
 */
typedef enum
{
    RTC_COMP0GT = 0x0,
    RTC_COMP1GT = 0x1,
    RTC_COMP2GT = 0x2,
    RTC_COMP3GT = 0x3,
} RTC_COMPGT_INDEX_T;
#define IS_RTC_COMPGT(COMP) (((COMP) == RTC_COMP0GT) || \
                             ((COMP) == RTC_COMP1GT) || \
                             ((COMP) == RTC_COMP2GT) || \
                             ((COMP) == RTC_COMP3GT))
/** \} */

/**
 * \defgroup    RTC_Interrupts_Definition RTC Interrupts Definition
 * \{
 * \ingroup     RTC_Exported_Constants
 */
#define RTC_INT_TICK           BIT8
#define RTC_INT_OVF            BIT9
#define RTC_INT_PRE_COMP       BIT10
#define RTC_INT_PRE_COMP3      BIT11
#define RTC_INT_COMP0          BIT16
#define RTC_INT_COMP1          BIT17
#define RTC_INT_COMP2          BIT18
#define RTC_INT_COMP3          BIT19

#define IS_RTC_INT(INT) (((INT) == RTC_INT_TICK) || \
                         ((INT) == RTC_INT_OVF) || \
                         ((INT) == RTC_INT_COMP0) || \
                         ((INT) == RTC_INT_COMP1) || \
                         ((INT) == RTC_INT_COMP2) || \
                         ((INT) == RTC_INT_COMP3) || \
                         ((INT) == RTC_INT_PRE_COMP) || \
                         ((INT) == RTC_INT_PRE_COMP3))
/** \} */

/**
 * \defgroup    RTC_Wakeup_Definition RTC Wakeup Definition
 * \{
 * \ingroup     RTC_Exported_Constants
 */
#define RTC_WK_COMP0GT         BIT12
#define RTC_WK_COMP1GT         BIT13
#define RTC_WK_COMP2GT         BIT14
#define RTC_WK_COMP3GT         BIT15
#define RTC_WK_COMP0           BIT20
#define RTC_WK_COMP1           BIT21
#define RTC_WK_COMP2           BIT22
#define RTC_WK_COMP3           BIT23

#define IS_RTC_WK(WK) (((WK) == RTC_WK_COMP0) || \
                       ((WK) == RTC_WK_COMP1) || \
                       ((WK) == RTC_WK_COMP2) || \
                       ((WK) == RTC_WK_COMP3) || \
                       ((WK) == RTC_WK_COMP0GT) || \
                       ((WK) == RTC_WK_COMP1GT) || \
                       ((WK) == RTC_WK_COMP2GT) || \
                       ((WK) == RTC_WK_COMP3GT))
/** \} */

/**
 * \defgroup    RTC_Int_Clear_Definition RTC Int Clear Definition
 * \{
 * \ingroup     RTC_Exported_Constants
 */
#define RTC_COMP3_CLR               (RTC_INT_COMP3     >> 8)
#define RTC_COMP2_CLR               (RTC_INT_COMP2     >> 8)
#define RTC_COMP1_CLR               (RTC_INT_COMP1     >> 8)
#define RTC_COMP0_CLR               (RTC_INT_COMP0     >> 8)
#define RTC_PRE_COMP3_CLR           (RTC_INT_PRE_COMP3 >> 8)
#define RTC_PRE_COMP_CLR            (RTC_INT_PRE_COMP  >> 8)
#define RTC_OVERFLOW_CLR            (RTC_INT_OVF       >> 8)
#define RTC_TICK_CLR                (RTC_INT_TICK      >> 8)

#define RTC_ALL_INT_CLR             (RTC_PRE_COMP3_CLR | RTC_PRE_COMP_CLR | \
                                     RTC_COMP3_CLR | RTC_COMP2_CLR | \
                                     RTC_COMP1_CLR | RTC_COMP0_CLR | \
                                     RTC_OVERFLOW_CLR | RTC_TICK_CLR)
/** \} */

/**
 * \defgroup    RTC_WK_Clear_Definition RTC WK Clear Definition
 * \{
 * \ingroup     RTC_Exported_Constants
 */
#define RTC_COMP3_WK_CLR            (RTC_WK_COMP3   >> 8)
#define RTC_COMP2_WK_CLR            (RTC_WK_COMP2   >> 8)
#define RTC_COMP1_WK_CLR            (RTC_WK_COMP1   >> 8)
#define RTC_COMP0_WK_CLR            (RTC_WK_COMP0   >> 8)
#define RTC_COMP3GT_CLR             (RTC_WK_COMP3GT >> 8)
#define RTC_COMP2GT_CLR             (RTC_WK_COMP2GT >> 8)
#define RTC_COMP1GT_CLR             (RTC_WK_COMP1GT >> 8)
#define RTC_COMP0GT_CLR             (RTC_WK_COMP0GT >> 8)

#define RTC_ALL_WAKEUP_CLR          (RTC_COMP3_WK_CLR | RTC_COMP2_WK_CLR | \
                                     RTC_COMP1_WK_CLR | RTC_COMP0_WK_CLR | \
                                     RTC_COMP3GT_CLR | RTC_COMP2GT_CLR | \
                                     RTC_COMP1GT_CLR | RTC_COMP0GT_CLR)
/** \} */

/*============================================================================*
 *                         Functions
 *============================================================================*/

/**
 * \defgroup    RTC_Exported_Functions Peripheral APIs
 * \{
 * \ingroup     RTC
 */

/**
 * \brief     Deinitializes the RTC peripheral registers to their default reset values(turn off clock).
 * \param[in] None.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void driver_rtc_init(void)
 * {
 *     RTC_DeInit();
 * }
 * \endcode
 */
void RTC_DeInit(void);

/**
 * \brief     Set RTC prescaler value.
 * \param[in] value: The prescaler value to be set.Should be no more than 12 bits!
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * #define RTC_PRESCALER_VALUE     49
 * #define RTC_COMP_INDEX          RTC_COMP3
 * #define RTC_COMP_INDEX_INT      RTC_INT_COMP3
 * #define RTC_COMP_VALUE          (1000)
 *
 * void driver_rtc_init(void)
 * {
 *     RTC_DeInit();
 *
 *     RTC_SetPrescaler(RTC_PRESCALER_VALUE);
 *     RTC_SetCompValue(RTC_COMP_INDEX, RTC_COMP_VALUE);
 *
 *     RTC_MaskINTConfig(RTC_COMP_INDEX_INT, DISABLE);
 *     RTC_INTConfig(RTC_COMP_INDEX_INT, ENABLE);
 *
 *     RTC_NvCmd(ENABLE);
 *     RTC_Cmd(ENABLE);
 * }
 * \endcode
 */
void RTC_SetPrescaler(uint16_t value);

/**
 * \brief     Start or stop RTC peripheral.
 * \param[in] NewState: New state of RTC peripheral.
 *            This parameter can be one of the following values:
 *            \arg ENABLE: Start RTC.
 *            \arg DISABLE: Stop RTC.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * #define RTC_PRESCALER_VALUE     49
 * #define RTC_COMP_INDEX          RTC_COMP3
 * #define RTC_COMP_INDEX_INT      RTC_INT_COMP3
 * #define RTC_COMP_VALUE          (1000)
 *
 * void driver_rtc_init(void)
 * {
 *     RTC_DeInit();
 *
 *     RTC_SetPrescaler(RTC_PRESCALER_VALUE);
 *     RTC_SetCompValue(RTC_COMP_INDEX, RTC_COMP_VALUE);
 *
 *     RTC_MaskINTConfig(RTC_COMP_INDEX_INT, DISABLE);
 *     RTC_INTConfig(RTC_COMP_INDEX_INT, ENABLE);
 *
 *     RTC_NvCmd(ENABLE);
 *     RTC_Cmd(ENABLE);
 * }
 * \endcode
 */
void RTC_Cmd(FunctionalState NewState);

/**
 * \brief     Enable or disable the specified RTC interrupt source.
 * \param[in] RTC_INT: Specifies the RTC interrupt source which to be enabled or disabled.
 *            This parameter can be any combination of the following values:
 *            \arg RTC_INT_TICK: Tick interrupt source.
 *            \arg RTC_INT_OVF: counter overflow interrupt
 *            \arg RTC_INT_COMP0: Compare 0 interrupt source.
 *            \arg RTC_INT_COMP1: Compare 1 interrupt source.
 *            \arg RTC_INT_COMP2: Compare 2 interrupt source.
 *            \arg RTC_INT_COMP3: Compare 3 interrupt source.
 *            \arg RTC_INT_PRE_COMP: Prescale compare interrupt source.
 *            \arg RTC_INT_PRE_COMP3: Prescale & compare 3 interrupt source.
 * \param[in] NewState: New state of the specified RTC interrupt.
 *            This parameter can be: ENABLE or DISABLE.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * #define RTC_PRESCALER_VALUE     49
 * #define RTC_COMP_INDEX          RTC_COMP3
 * #define RTC_COMP_INDEX_INT      RTC_INT_COMP3
 * #define RTC_COMP_VALUE          (1000)
 *
 * void driver_rtc_init(void)
 * {
 *     RTC_DeInit();
 *
 *     RTC_SetPrescaler(RTC_PRESCALER_VALUE);
 *     RTC_SetCompValue(RTC_COMP_INDEX, RTC_COMP_VALUE);
 *
 *     RTC_MaskINTConfig(RTC_COMP_INDEX_INT, DISABLE);
 *     RTC_INTConfig(RTC_COMP_INDEX_INT, ENABLE);
 *
 *     RTC_NvCmd(ENABLE);
 *     RTC_Cmd(ENABLE);
 * }
 * \endcode
 */
void RTC_INTConfig(uint32_t RTC_INT, FunctionalState NewState);

/**
 * \brief  Enable or disable the specified RTC wakeup function.
 * \param  RTC_WK: specifies the RTC wakeup function to be enabled or disabled.
 *         This parameter can be any combination of the following values:
 *         \arg RTC_WK_TICK: tick wakeup function
 *         \arg RTC_WK_OVF: tick wakeup function
 *         \arg RTC_WK_PRE_CMP: prescale compare wakeup function
 *         \arg RTC_WK_PRE_CMP3: prescale & compare 3 wakeup function
 *         \arg RTC_WK_COMP0GT: compare 0 gt wakeup function
 *         \arg RTC_WK_COMP1GT: compare 1 gt wakeup function
 *         \arg RTC_WK_COMP2GT: compare 2 gt wakeup function
 *         \arg RTC_WK_COMP3GT: compare 3 gt wakeup function
 *         \arg RTC_WK_CMP0: compare 0 wakeup function
 *         \arg RTC_WK_CMP1: compare 1 wakeup function
 *         \arg RTC_WK_CMP2: compare 2 wakeup function
 *         \arg RTC_WK_CMP3: compare 3 wakeup function
 * \param  NewState: new state of the specified RTC wakeup function.
 *         This parameter can be: ENABLE or DISABLE.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * #define RTC_PRESCALER_VALUE     49
 * #define RTC_COMP_INDEX          RTC_COMP3
 * #define RTC_COMP_INDEX_INT      RTC_INT_COMP3
 * #define RTC_COMP_VALUE          (1000)
 *
 * void driver_rtc_init(void)
 * {
 *     RTC_DeInit();
 *
 *     RTC_SetPrescaler(RTC_PRESCALER_VALUE);
 *     RTC_SetCompValue(RTC_COMP_INDEX, RTC_COMP_VALUE);
 *
 *     RTC_MaskINTConfig(RTC_COMP_INDEX_INT, DISABLE);
 *     RTC_INTConfig(RTC_COMP_INDEX_INT, ENABLE);
 *
 *     RTC_NvCmd(ENABLE);
 *     RTC_Cmd(ENABLE);
 * }
 * \endcode
 */
void RTC_WKConfig(uint32_t RTC_WK, FunctionalState NewState);

/**
 * \brief     Enable RTC interrupt signal to CPU NVIC.
 * \param[in] NewState: Enable or disable RTC interrupt signal to MCU.
 *            This parameter can be: ENABLE or DISABLE..
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * #define RTC_PRESCALER_VALUE     49
 * #define RTC_COMP_INDEX          RTC_COMP3
 * #define RTC_COMP_INDEX_INT      RTC_INT_COMP3
 * #define RTC_COMP_VALUE          (1000)
 *
 * void driver_rtc_init(void)
 * {
 *     RTC_DeInit();
 *
 *     RTC_SetPrescaler(RTC_PRESCALER_VALUE);
 *     RTC_SetCompValue(RTC_COMP_INDEX, RTC_COMP_VALUE);
 *
 *     RTC_MaskINTConfig(RTC_COMP_INDEX_INT, DISABLE);
 *     RTC_INTConfig(RTC_COMP_INDEX_INT, ENABLE);
 *
 *     RTC_NvCmd(ENABLE);
 *     RTC_Cmd(ENABLE);
 * }
 * \endcode
 */
void RTC_NvCmd(FunctionalState NewState);

/**
 * \brief     Enable or disable system wake up function of RTC.
 * \param[in] NewState: new state of the wake up function.
 *            This parameter can be: ENABLE or DISABLE.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void rtc_demo(void)
 * {
 *     RTC_SystemWakeupConfig(ENABLE);
 * }
 * \endcode
 */
void RTC_SystemWakeupConfig(FunctionalState NewState);

/**
 * \brief     Reset counter value of RTC.
 * \param[in] None.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void rtc_demo(void)
 * {
 *     RTC_ResetCounter();
 *     RTC_Cmd(ENABLE);
 * }
 * \endcode
 */
void RTC_ResetCounter(void);

/**
 * \brief     Reset prescaler counter value of RTC.
 * \param[in] None.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void rtc_demo(void)
 * {
 *     RTC_ResetPrescalerCounter();
 *     RTC_Cmd(ENABLE);
 * }
 * \endcode
 */
void RTC_ResetPrescalerCounter(void);

/**
 * \brief  Check whether the specified RTC interrupt is set.
  * \param[in]  RTC_INT: Specifies the RTC interrupt source to be enabled or disabled.
 *   This parameter can be any combination of the following values:
 *            \arg RTC_INT_TICK: RTC tick interrupt source.
 *            \arg RTC_INT_COMP0: Compare 0 interrupt source.
 *            \arg RTC_INT_COMP1: Compare 1 interrupt source.
 *            \arg RTC_INT_COMP2: Compare 2 interrupt source.
 *            \arg RTC_INT_COMP3: Compare 3 interrupt source.
 *            \arg RTC_INT_PRE_COMP: Prescale compare interrupt source.
 *            \arg RTC_INT_PRE_COMP3: Prescale & compare 3 interrupt source.
 * \return The new state of RTC_INT (SET or RESET).
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void rtc_demo(void)
 * {
 *     ITStatus int_status = RTC_GetINTStatus(RTC_INT_COMP0);
 * }
 * \endcode
 */
ITStatus RTC_GetINTStatus(uint32_t RTC_INT);

/**
 * \brief     Clear the interrupt pending bits of RTC.
 * \param[in] RTC_INT: specifies the RTC interrupt flag to clear.
 *            This parameter can be any combination of the following values:
 *            \arg RTC_INT_TICK: RTC tick interrupt source.
 *            \arg RTC_INT_OVF: RTC counter overflow interrupt source.
 *            \arg RTC_INT_COMP0: Compare 0 interrupt source.
 *            \arg RTC_INT_COMP1: Compare 1 interrupt source.
 *            \arg RTC_INT_COMP2: Compare 2 interrupt source.
 *            \arg RTC_INT_COMP3: Compare 3 interrupt source.
 *            \arg RTC_INT_PRE_COMP: Prescale compare interrupt source.
 *            \arg RTC_INT_PRE_COMP3: Prescale & compare 3 interrupt source.
 * \return None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void rtc_demo(void)
 * {
 *     RTC_ClearINTPendingBit(RTC_INT_COMP0);
 * }
 * \endcode
 */
void RTC_ClearINTPendingBit(uint32_t RTC_INT);

/**
  * \brief  Checks whether the specified RTC wakeup state is set or not.
  * \param  RTC_WK: specifies the RTC interrupt source to be enabled or disabled.
  *         This parameter can be any combination of the following values:
  *         \arg RTC_WK_TICK: tick wakeup function
  *         \arg RTC_WK_OVF: tick wakeup function
  *         \arg RTC_WK_PRE_CMP: prescale compare wakeup function
  *         \arg RTC_WK_PRE_CMP3: prescale & compare 3 wakeup function
  *         \arg RTC_WK_COMP0GT: compare 0 gt wakeup function
  *         \arg RTC_WK_COMP1GT: compare 1 gt wakeup function
  *         \arg RTC_WK_COMP2GT: compare 2 gt wakeup function
  *         \arg RTC_WK_COMP3GT: compare 3 gt wakeup function
  *         \arg RTC_WK_CMP0: compare 0 wakeup function
  *         \arg RTC_WK_CMP1: compare 1 wakeup function
  *         \arg RTC_WK_CMP2: compare 2 wakeup function
  *         \arg RTC_WK_CMP3: compare 3 wakeup function
  * \return The new state of RTC_INT (SET or RESET).
  */
ITStatus RTC_GetWakeupStatus(uint32_t RTC_WK);

/**
  * \brief  Clear the wakeup status bits of RTC.
  * \param  RTC_WK: specifies the RTC wakeup flag to clear.
  *         This parameter can be any combination of the following values:
  *         \arg RTC_WK_TICK: tick wakeup function
  *         \arg RTC_WK_OVF: tick wakeup function
  *         \arg RTC_WK_PRE_CMP: prescale compare wakeup function
  *         \arg RTC_WK_PRE_CMP3: prescale & compare 3 wakeup function
  *         \arg RTC_WK_COMP0GT: compare 0 gt wakeup function
  *         \arg RTC_WK_COMP1GT: compare 1 gt wakeup function
  *         \arg RTC_WK_COMP2GT: compare 2 gt wakeup function
  *         \arg RTC_WK_COMP3GT: compare 3 gt wakeup function
  *         \arg RTC_WK_CMP0: compare 0 wakeup function
  *         \arg RTC_WK_CMP1: compare 1 wakeup function
  *         \arg RTC_WK_CMP2: compare 2 wakeup function
  *         \arg RTC_WK_CMP3: compare 3 wakeup function
  * \return None.
  */
void RTC_ClearWakeupStatusBit(uint32_t RTC_WK);

/**
 * \brief     Clear the interrupt pending bit of the select comparator of RTC.
 * \param[in] index: the comparator number.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void rtc_demo(void)
 * {
 *     RTC_ClearCompINT(0);
 * }
 * \endcode
 */
void RTC_ClearCompINT(RTC_COMP_INDEX_T index);

/**
 * \brief     Clear the overflow interrupt pending bit of RTC.
 * \param[in] None.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void rtc_demo(void)
 * {
 *     RTC_ClearOverFlowINT();
 * }
 * \endcode
 */
void RTC_ClearOverFlowINT(void);

/**
 * \brief     Clear the tick interrupt pending bit of RTC.
 * \param[in] None.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void rtc_demo(void)
 * {
 *     RTC_ClearTickINT();
 * }
 * \endcode
 */
void RTC_ClearTickINT(void);

/**
 * \brief     Set RTC comparator value.
 * \param[in] index: The comparator number,can be 0 ~ 3.
 * \param[in] value: The comparator value to be set.Should be no more than 24 bits!
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * #define RTC_PRESCALER_VALUE     49
 * #define RTC_COMP_INDEX          RTC_COMP3
 * #define RTC_COMP_INDEX_INT      RTC_INT_COMP3
 * #define RTC_COMP_VALUE          (1000)
 *
 * void driver_rtc_init(void)
 * {
 *     RTC_DeInit();
 *
 *     RTC_SetPrescaler(RTC_PRESCALER_VALUE);
 *     RTC_SetCompValue(RTC_COMP_INDEX, RTC_COMP_VALUE);
 *
 *     RTC_MaskINTConfig(RTC_COMP_INDEX_INT, DISABLE);
 *     RTC_INTConfig(RTC_COMP_INDEX_INT, ENABLE);
 *
 *     RTC_NvCmd(ENABLE);
 *     RTC_Cmd(ENABLE);
 * }
 * \endcode
 */
__STATIC_INLINE void RTC_SetCompValue(RTC_COMP_INDEX_T index, uint32_t value)
{
    /* Check the parameters */
    assert_param(IS_RTC_COMP(index));

    *(&(RTC->RTC_COMP_0) + index) = (value & 0xFFFFFFFF);
}

/**
 * \brief     Set RTC comparator GT value.
 * \param[in] index: The comparator gt number, can be 0 ~ 3.
 * \param[in] value: The comparator value to be set.
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * #define RTC_PRESCALER_VALUE     49
 * #define RTC_COMP_INDEX          RTC_COMP3
 * #define RTC_COMP_INDEX_INT      RTC_INT_COMP3
 * #define RTC_COMP_VALUE          (1000)
 *
 * void driver_rtc_init(void)
 * {
 *     RTC_DeInit();
 *
 *     RTC_SetPrescaler(RTC_PRESCALER_VALUE);
 *     RTC_SetCompValue(RTC_COMP_INDEX, RTC_COMP_VALUE);
 *
 *     RTC_MaskINTConfig(RTC_COMP_INDEX_INT, DISABLE);
 *     RTC_INTConfig(RTC_COMP_INDEX_INT, ENABLE);
 *
 *     RTC_NvCmd(ENABLE);
 *     RTC_Cmd(ENABLE);
 * }
 * \endcode
 */
__STATIC_INLINE void RTC_SetCompGTValue(RTC_COMPGT_INDEX_T index, uint32_t value)
{
    /* Check the parameters */
    assert_param(IS_RTC_COMPGT(index));

    *(&(RTC->RTC_COMP0_GT) + index) = (value & 0xFFFFFFFF);
}

/**
 * \brief     Set RTC prescaler comparator value.
 * \param[in] value: The comparator value to be set.Should be no more than 12 bits!
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * #define RTC_PRESCALER_VALUE     (3200 - 1)//max 4095
 * #define RTC_PRECOMP_VALUE       (320)//max 4095
 * #define RTC_COMP3_VALUE         (10)
 *
 * void driver_rtc_init(void)
 * {
 *     RTC_DeInit();
 *
 *     RTC_SetPrescaler(RTC_PRESCALER_VALUE);
 *     RTC_SetPreCompValue(RTC_PRECOMP_VALUE);
 *     RTC_SetCompValue(RTC_COMP3, RTC_COMP3_VALUE);
 *
 *     RTC_MaskINTConfig(RTC_INT_PRE_COMP3, DISABLE);
 *     RTC_INTConfig(RTC_INT_PRE_COMP3, ENABLE);
 *
 *     RTC_NvCmd(ENABLE);
 *     RTC_Cmd(ENABLE);
 * }
 * \endcode
 */
__STATIC_INLINE void RTC_SetPreCompValue(uint32_t value)
{
    RTC->RTC_PRESCALE_CMP0 = (value & 0xFFF);
}

/**
 * \brief     Get counter value of RTC.
 * \param[in] None.
 * \return    The counter value.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void rtc_demo(void)
 * {
 *     uitn32_t counter = RTC_GetCounter();
 * }
 * \endcode
 */
__STATIC_INLINE uint32_t RTC_GetCounter(void)
{
    return RTC->RTC_CNT0;
}

/**
 * \brief     Get prescaler counter value of RTC.
 * \param[in] None.
 * \return    The prescaler counter value.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void rtc_demo(void)
 * {
 *     uitn32_t pre_counter = RTC_GetPreCounter();
 * }
 * \endcode
 */
__STATIC_INLINE uint32_t RTC_GetPreCounter(void)
{
    return RTC->RTC_PRESCALE_CNT0;
}

/**
 * \brief     Get RTC comparator value.
 * \param[in] index: The comparator number.
 * \return    The comparator value.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void rtc_demo(void)
 * {
 *     uint32_t data = RTC_GetCompValue(RTC_COMP0);
 * }
 * \endcode
 */
__STATIC_INLINE uint32_t RTC_GetCompValue(RTC_COMP_INDEX_T index)
{
    return *(&(RTC->RTC_COMP_0) + index);
}

/**
 * \brief     Get RTC comparator gt value.
 * \param[in] index: The comparator number 0~3.
 * \return    The comparator value.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void rtc_demo(void)
 * {
 *     uitn32_t data = RTC_GetCompGTValue(0);
 * }
 * \endcode
 */
__STATIC_INLINE uint32_t RTC_GetCompGTValue(RTC_COMPGT_INDEX_T index)
{
    return *(&(RTC->RTC_COMP0_GT) + index);
}

/**
 * \brief     Get RTC prescaler comparator value.
 * \param[in] None.
 * \return    The prescaler comparator value.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void rtc_demo(void)
 * {
 *     uitn32_t data = RTC_GetPreCompValue();
 * }
 * \endcode
 */
__STATIC_INLINE uint32_t RTC_GetPreCompValue(void)
{
    return RTC->RTC_PRESCALE_CMP0;
}

/**
 * \brief     Write backup register for store time information.
 * \param[in] value: valuer=write to back up reister
 * \return    None.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void rtc_demo(void)
 * {
 *     RTC_WriteBackupReg(0x01020304);
 * }
 * \endcode
 */
//void RTC_WriteBackupReg(uint32_t value);
__STATIC_INLINE void RTC_WriteBackupReg(uint32_t value)
{
//    RTC_WriteReg((uint32_t)(&(RTC->RTC_BACKUP_REG)), value);
    (RTC->RTC_BACKUP_REG) = value;
}

/**
 * \brief     Read backup register.
 * \param[in] None.
 * \return    Register value.
 *
 * <b>Example usage</b>
 * \code{.c}
 *
 * void rtc_demo(void)
 * {
 *     uint32_t reg_data = RTC_ReadBackupReg();
 * }
 * \endcode
 */
//uint32_t RTC_ReadBackupReg(void);
__STATIC_INLINE uint32_t RTC_ReadBackupReg(void)
{
    return (RTC->RTC_BACKUP_REG);
}

/** \} */ /* End of group RTC_Exported_Functions */

#ifdef __cplusplus
}
#endif

#endif /* RTL_RTC_H */


/******************* (C) COPYRIGHT 2020 Realtek Semiconductor *****END OF FILE****/

