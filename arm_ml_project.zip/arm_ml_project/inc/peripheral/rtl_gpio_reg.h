#ifndef RTL_GPIO_REG_H
#define RTL_GPIO_REG_H

#include <stdint.h>
#include <stdbool.h>
#include "rtl876x.h"

#ifdef  __cplusplus
extern "C" {
#endif /* __cplusplus */

/*============================================================================*
 *                         GPIO Registers Memory Map
 *============================================================================*/
typedef struct
{
    __IO uint32_t GPIO_DR;              /*!< 0x00 */
    __IO uint32_t GPIO_DDR;             /*!< 0x04 */
    uint32_t RSVD[10];
    __IO uint32_t GPIO_INT_EN;          /*!< 0x30 */
    __IO uint32_t GPIO_INT_MASK;        /*!< 0x34 */
    __IO uint32_t GPIO_INT_LV;          /*!< 0x38 */
    __IO uint32_t GPIO_INT_POL;         /*!< 0x3C */
    __I  uint32_t GPIO_INT_STS;         /*!< 0x40 */
    __I  uint32_t GPIO_INT_RAW_STS;     /*!< 0x44 */
    uint32_t RSVD1;
    __O  uint32_t GPIO_INT_CLR;         /*!< 0x4C */
    __IO uint32_t GPIO_EXT;             /*!< 0x50 */
    uint32_t RSVD2[3];
    __IO uint32_t GPIO_LS_SYNC;         /*!< 0x60 */
    uint32_t RSVD3[2];
} GPIO_TypeDef;

typedef struct
{
    __IO uint32_t GPIO_DEB_CLK_CTL_0;   /*!< 0x00 */
    __IO uint32_t GPIO_DEB_CLK_CTL_1;   /*!< 0x04 */
    __IO uint32_t GPIO_DEB_CLK_CTL_2;   /*!< 0x08 */
    __IO uint32_t GPIO_DEB_CLK_CTL_3;   /*!< 0x0C */
    __IO uint32_t GPIO_DEB_FUN_CTL;     /*!< 0x10 */
} GPIO_Debounce_TypeDef;

/*============================================================================*
 *                         GPIO Declaration
 *============================================================================*/
#define GPIO               ((GPIO_TypeDef          *) GPIOA_REG_BASE)
#define GPIOA              ((GPIO_TypeDef          *) GPIOA_REG_BASE)
#define GPIOB              ((GPIO_TypeDef          *) GPIOB_REG_BASE)
#define GPIOC              ((GPIO_TypeDef          *) GPIOC_REG_BASE)
#define GPIOD              ((GPIO_TypeDef          *) GPIOD_REG_BASE)
#define GPIOA_DEB          ((GPIO_Debounce_TypeDef *) GPIOA_DEB_REG_BASE)
#define GPIOB_DEB          ((GPIO_Debounce_TypeDef *) GPIOB_DEB_REG_BASE)
#define GPIOC_DEB          ((GPIO_Debounce_TypeDef *) GPIOC_DEB_REG_BASE)
#define GPIOD_DEB          ((GPIO_Debounce_TypeDef *) GPIOD_DEB_REG_BASE)

/*============================================================================*
 *                         GPIO Registers and Field Descriptions
 *============================================================================*/
/* 0x00
   31:0    R/W    gpio_swporta_dr         32'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t gpio_swporta_dr: 32;
    } b;
} GPIO_DR_t;



/* 0x04
   31:0    R/W    gpio_swporta_ddr        32'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t gpio_swporta_ddr: 32;
    } b;
} GPIO_DDR_t;


/* 0x30
   31:0    R/W    gpio_inten              32'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t gpio_inten: 32;
    } b;
} GPIO_INT_EN_t;



/* 0x34
   31:0    R/W    gpio_intmask            32'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t gpio_intmask: 32;
    } b;
} GPIO_INT_MASK_t;



/* 0x38
   31:0    R/W    gpio_inttype_level      32'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t gpio_inttype_level: 32;
    } b;
} GPIO_INT_LV_t;



/* 0x3C
   31:0    R/W    gpio_interrupt_polarity 32'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t gpio_interrupt_polarity: 32;
    } b;
} GPIO_INT_POL_t;



/* 0x40
   31:0    R      gpio_intstatus          32'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t gpio_intstatus: 32;
    } b;
} GPIO_INT_STS_t;


/* 0x44
   31:0    R      gpio_raw_intstatus      32'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __I uint32_t gpio_raw_intstatus: 32;
    } b;
} GPIO_INT_RAW_STS_t;


/* 0x4C
   31:0    W      gpio_porta_eoi          32'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __O uint32_t gpio_porta_eoi: 32;
    } b;
} GPIO_INT_CLR_t;



/* 0x50
   31:0    R/W    gpio_external_porta     32'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t gpio_external_porta: 32;
    } b;
} GPIO_EXT_t;



/* 0x60
   0       R/W    gpio_ls_sync            1'h0
   31:1    R/W    reserved                31'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t gpio_ls_sync: 1;
        __IO uint32_t reserved: 31;
    } b;
} GPIO_LS_SYNC_t;

/* 0x00
   7:0     R/W    GPIO_G0_CNT_LIMIT      8'h1
   8       R/W    GPIO_G0_DEB_CLK_SEL    1'h0
   11:9    R/W    GPIO_G0_DEB_CLK_DIV    3'h0
   12      R/W    GPIO_G0_DEB_CNT_EN     1'b0
   15:13   R/W    DUMMY                  3'h0
   23:16   R/W    GPIO_G1_CNT_LIMIT      8'h1
   24      R/W    GPIO_G1_DEB_CLK_SEL    1'h0
   27:25   R/W    GPIO_G1_DEB_CLK_DIV    3'h0
   28      R/W    GPIO_G1_DEB_CNT_EN     1'b0
   31:29   R/W    DUMMY                  2'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t GPIO_G0_CNT_LIMIT: 8;
        __IO uint32_t GPIO_G0_DEB_CLK_SEL: 1;
        __IO uint32_t GPIO_G0_DEB_CLK_DIV: 3;
        __IO uint32_t GPIO_G0_DEB_CNT_EN: 1;
        __IO uint32_t reserved_1: 3;
        __IO uint32_t GPIO_G1_CNT_LIMIT: 8;
        __IO uint32_t GPIO_G1_DEB_CLK_SEL: 1;
        __IO uint32_t GPIO_G1_DEB_CLK_DIV: 3;
        __IO uint32_t GPIO_G1_DEB_CNT_EN: 1;
        __IO uint32_t reserved_0: 3;
    } b;
} GPIO_DEB_CLK_CTL_0_t;



/* 0x04
   7:0     R/W    GPIO_G2_CNT_LIMIT      8'h1
   8       R/W    GPIO_G2_DEB_CLK_SEL    1'h0
   11:9    R/W    GPIO_G2_DEB_CLK_DIV    3'h0
   12      R/W    GPIO_G2_DEB_CNT_EN     1'b0
   15:13   R/W    DUMMY                   3'h0
   23:16   R/W    GPIO_G3_CNT_LIMIT      8'h1
   24      R/W    GPIO_G3_DEB_CLK_SEL    1'h0
   27:25   R/W    GPIO_G3_DEB_CLK_DIV    3'h0
   28      R/W    GPIO_G3_DEB_CNT_EN     1'b0
   31:29   R/W    DUMMY                   2'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t GPIO_G2_CNT_LIMIT: 8;
        __IO uint32_t GPIO_G2_DEB_CLK_SEL: 1;
        __IO uint32_t GPIO_G2_DEB_CLK_DIV: 3;
        __IO uint32_t GPIO_G2_DEB_CNT_EN: 1;
        __IO uint32_t reserved_1: 3;
        __IO uint32_t GPIO_G3_CNT_LIMIT: 8;
        __IO uint32_t GPIO_G3_DEB_CLK_SEL: 1;
        __IO uint32_t GPIO_G3_DEB_CLK_DIV: 3;
        __IO uint32_t GPIO_G3_DEB_CNT_EN: 1;
        __IO uint32_t reserved_0: 3;
    } b;
} GPIO_DEB_CLK_CTL_1_t;



/* 0x08
   7:0     R/W    GPIO_G4_CNT_LIMIT      8'h1
   8       R/W    GPIO_G4_DEB_CLK_SEL    1'h0
   11:9    R/W    GPIO_G4_DEB_CLK_DIV    3'h0
   12      R/W    GPIO_G4_DEB_CNT_EN     1'b0
   15:13   R/W    DUMMY                   3'h0
   23:16   R/W    GPIO_G5_CNT_LIMIT      8'h1
   24      R/W    GPIO_G5_DEB_CLK_SEL    1'h0
   27:25   R/W    GPIO_G5_DEB_CLK_DIV    3'h0
   28      R/W    GPIO_G5_DEB_CNT_EN     1'b0
   31:29   R/W    DUMMY                   2'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t GPIO_G4_CNT_LIMIT: 8;
        __IO uint32_t GPIO_G4_DEB_CLK_SEL: 1;
        __IO uint32_t GPIO_G4_DEB_CLK_DIV: 3;
        __IO uint32_t GPIO_G4_DEB_CNT_EN: 1;
        __IO uint32_t reserved_1: 3;
        __IO uint32_t GPIO_G5_CNT_LIMIT: 8;
        __IO uint32_t GPIO_G5_DEB_CLK_SEL: 1;
        __IO uint32_t GPIO_G5_DEB_CLK_DIV: 3;
        __IO uint32_t GPIO_G5_DEB_CNT_EN: 1;
        __IO uint32_t reserved_0: 3;
    } b;
} GPIO_DEB_CLK_CTL_2_t;



/* 0x0C
   7:0     R/W    GPIO_G6_CNT_LIMIT      8'h1
   8       R/W    GPIO_G6_DEB_CLK_SEL    1'h0
   11:9    R/W    GPIO_G6_DEB_CLK_DIV    3'h0
   12      R/W    GPIO_G6_DEB_CNT_EN     1'b0
   15:13   R/W    DUMMY                   3'h0
   23:16   R/W    GPIO_G7_CNT_LIMIT      8'h1
   24      R/W    GPIO_G7_DEB_CLK_SEL    1'h0
   27:25   R/W    GPIO_G7_DEB_CLK_DIV    3'h0
   28      R/W    GPIO_G7_DEB_CNT_EN     1'b0
   31:29   R/W    DUMMY                   2'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t GPIO_G6_CNT_LIMIT: 8;
        __IO uint32_t GPIO_G6_DEB_CLK_SEL: 1;
        __IO uint32_t GPIO_G6_DEB_CLK_DIV: 3;
        __IO uint32_t GPIO_G6_DEB_CNT_EN: 1;
        __IO uint32_t reserved_1: 3;
        __IO uint32_t GPIO_G7_CNT_LIMIT: 8;
        __IO uint32_t GPIO_G7_DEB_CLK_SEL: 1;
        __IO uint32_t GPIO_G7_DEB_CLK_DIV: 3;
        __IO uint32_t GPIO_G7_DEB_CNT_EN: 1;
        __IO uint32_t reserved_0: 3;
    } b;
} GPIO_DEB_CLK_CTL_3_t;



/* 0x10
   31:0    R/W    GPIO_x_DEB_FUNC_EN     32'h0
*/
typedef union
{
    uint32_t d32;
    uint8_t d8[4];
    struct
    {
        __IO uint32_t GPIO_x_DEB_FUNC_EN: 32;
    } b;
} GPIO_DEB_FUN_CTL_t;

#ifdef  __cplusplus
}
#endif /* __cplusplus */
#endif /* RTL_GPIO_REG_H */
