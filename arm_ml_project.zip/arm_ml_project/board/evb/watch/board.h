/**
*********************************************************************************************************
*               Copyright(c) 2015, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      board.h
* @brief
* @details
* @author
* @date
* @version
* *********************************************************************************************************
*/


#ifndef _BOARD_H_
#define _BOARD_H_

#ifdef __cplusplus
extern "C" {
#endif


/* if use user define dlps enter/dlps exit callback function */
#define USE_USER_DEFINE_DLPS_EXIT_CB      1
#define USE_USER_DEFINE_DLPS_ENTER_CB     1

/* if use any peripherals below, #define it 1 */

#define USE_ADC_DLPS                1
#define USE_I2C0_DLPS               1
#define USE_I2C1_DLPS               1
#define USE_IR_DLPS                 0
#define USE_KEYSCAN_DLPS            0
#define USE_QDECODER_DLPS           0
#define USE_UART0_DLPS              1
#define USE_UART1_DLPS              0
#define USE_UART4_DLPS              1
#define USE_UART5_DLPS              1
#define USE_TIMB_DLPS               1
#define USE_SPI0_DLPS               0
#define USE_SPI1_DLPS               1

/* do not modify USE_IO_DRIVER_DLPS macro */
#define USE_IO_DRIVER_DLPS          (USE_ADC_DLPS \
                                     | USE_I2C0_DLPS | USE_I2C1_DLPS \
                                     | USE_IR_DLPS \
                                     | USE_KEYSCAN_DLPS \
                                     | USE_QDECODER_DLPS \
                                     | USE_UART0_DLPS | USE_UART1_DLPS | USE_UART4_DLPS | USE_UART5_DLPS \
                                     | USE_TIMB_DLPS \
                                     | USE_USER_DEFINE_DLPS_ENTER_CB \
                                     | USE_USER_DEFINE_DLPS_EXIT_CB)

#define SHELL_UART_TX P2_3
#define SHELL_UART_RX P2_4


#ifdef __cplusplus
}
#endif

#endif  /* _BOARD_H_ */

