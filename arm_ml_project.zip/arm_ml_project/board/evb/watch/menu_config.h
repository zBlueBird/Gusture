
#ifndef __MENU_CONFIG_H__
#define __MENU_CONFIG_H__
// <<< Use Configuration Wizard in Context Menu >>>\n
/* Automatically generated file; DO NOT EDIT. */
/* Menu Configuration */

// <c> RTL8772F_DEVICE
#define CONFIG_REALTEK_8772F_DEVICE
// </c>


// <h> SOC Hardware Drivers
// <q> RTK_3WIRE_SPI_ENABLED - 3WIRE_SPI peripheral driver
//==========================================================
#define CONFIG_REALTEK_3WIRE_SPI 1

// <q> RTK_ADC_24BIT_ENABLED - ADC_24BIT peripheral driver
//==========================================================
#define CONFIG_REALTEK_ADC_24BIT 0

// <q> RTK_ADC_ENABLED - ADC peripheral driver
//==========================================================
#define CONFIG_REALTEK_ADC 0

// <q> RTK_AON_QDEC_ENABLED - AON_QDEC peripheral driver
//==========================================================
#define CONFIG_REALTEK_AON_QDEC 0

// <q> RTK_CAN_ENABLED - CAN peripheral driver
//==========================================================
#define CONFIG_REALTEK_CAN 0

// <q> RTK_CODEC_ENABLED - CODEC peripheral driver
//==========================================================
#define CONFIG_REALTEK_CODEC 1

// <q> RTK_ENH_TIMER_ENABLED - ENH_TIMER peripheral driver
//==========================================================
#define CONFIG_REALTEK_ENH_TIMER 0

// <q> RTK_GDMA_ENABLED - GDMA peripheral driver
//==========================================================
#define CONFIG_REALTEK_GDMA 1

// <q> RTK_GMAC_ENABLED - GMAC peripheral driver
//==========================================================
#define CONFIG_REALTEK_GMAC 0

// <q> RTK_GPIO_ENABLED - GPIO peripheral driver
//==========================================================
#define CONFIG_REALTEK_GPIO 1

// <q> RTK_I2C_ENABLED - I2C peripheral driver
//==========================================================
#define CONFIG_REALTEK_I2C 1

// <q> RTK_I2S_ENABLED - I2S peripheral driver
//==========================================================
#define CONFIG_REALTEK_I2S 0

// <q> RTK_IO_DLPS_ENABLED - IO_DLPS peripheral driver
//==========================================================
#define CONFIG_REALTEK_IO_DLPS 1

// <q> RTK_IR_ENABLED - IR peripheral driver
//==========================================================
#define CONFIG_REALTEK_IR 0

// <q> RTK_ISO7816_ENABLED - ISO7816 peripheral driver
//==========================================================
#define CONFIG_REALTEK_ISO7816 0

// <q> RTK_KEYSCAN_ENABLED - KEYSCAN peripheral driver
//==========================================================
#define CONFIG_REALTEK_KEYSCAN 0

// <q> RTK_LCDC_ENABLED - LCDC peripheral driver
//==========================================================
#define CONFIG_REALTEK_LCDC 1

// <q> RTK_LCDC_DBIB_ENABLED - LCDC_DBIB peripheral driver
//==========================================================
#define CONFIG_REALTEK_LCDC_DBIB 0

// <q> RTK_LCDC_DBIC_ENABLED - LCDC_DBIC peripheral driver
//==========================================================
#define CONFIG_REALTEK_LCDC_DBIC 1

// <q> RTK_LCDC_DSI_ENABLED - LCDC_DSI peripheral driver
//==========================================================
#define CONFIG_REALTEK_LCDC_DSI 0

// <q> RTK_LCDC_EDPI_ENABLED - LCDC_EDPI peripheral driver
//==========================================================
#define CONFIG_REALTEK_LCDC_EDPI 0

// <q> RTK_LPC_ENABLED - LPC peripheral driver
//==========================================================
#define CONFIG_REALTEK_LPC 0

// <q> RTK_PPE_ENABLED - PPE peripheral driver
//==========================================================
#define CONFIG_REALTEK_PPE 1

// <q> RTK_RAMLESS_QSPI_ENABLED - RAMLESS_QSPI peripheral driver
//==========================================================
#define CONFIG_REALTEK_RAMLESS_QSPI 0

// <q> RTK_RTC_ENABLED - RTC peripheral driver
//==========================================================
#define CONFIG_REALTEK_RTC 1

// <q> RTK_IMDC_ENABLED - IMDC peripheral driver
//==========================================================
#define CONFIG_REALTEK_IMDC 1

// <q> RTK_SPI_ENABLED - SPI peripheral driver
//==========================================================
#define CONFIG_REALTEK_SPI 0

// <q> RTK_HWTIMER_ENABLED - HWTIMER peripheral driver
//==========================================================
#define CONFIG_REALTEK_HWTIMER 0

// <q> RTK_UART_ENABLED - UART peripheral driver
//==========================================================
#define CONFIG_REALTEK_UART 0

// <q> RTK_SEGCOM_ENABLED - SEGCOM peripheral driver
//==========================================================
#define CONFIG_REALTEK_SEGCOM 0

// </h> SOC Hardware Drivers


// <e> Bluetooth
// <e> BLE_OTA_ENABLED
#define CONFIG_REALTEK_BLE_OTA 1
#if (CONFIG_REALTEK_BLE_OTA == 1)
// <q> SILENT_OTA
// <i> Transmit images while application running
#define CONFIG_REALTEK_SILENT_OTA 1
// <q> NORMAL_OTA
// <i> Enter dfu mode to transmit images
#define CONFIG_REALTEK_NORMAL_OTA 1
// <q> DFU_SERVICE
// <i> Enter dfu mode to transmit images
#define CONFIG_REALTEK_DFU_SERVICE 1
// <q> OTA_SERVICE
// <i> Enter dfu mode to transmit images
#define CONFIG_REALTEK_OTA_SERVICE 1
#endif
// </e>
// </e>



// <h> Wearable Hal config

// <q> CONFIG_REALTEK_BLE_COMPONENTS - BLE Components enalbe
//==========================================================
#define CONFIG_REALTEK_BLE_COMPONENTS 1

// <q> RTK_BR_TASK - BR task enalbe
//==========================================================
#define CONFIG_REALTEK_BR_TASK 1

// <q> RTK_BR_PROFILE_SDP - BR SDP Profile enalbe
//==========================================================
#define CONFIG_REALTEK_BR_PROFILE_SDP 1

// <q> RTK_BR_PROFILE_SPP - BR SPP Profile enalbe
//==========================================================
#define CONFIG_REALTEK_BR_PROFILE_SPP 1

// <q> RTK_BR_PROFILE_A2DP - BR A2DP Profile enalbe
//==========================================================
#define CONFIG_REALTEK_BR_PROFILE_A2DP 1

// <q> RTK_ACRCP_PROFILE_A2DP - BR ACRCP Profile enalbe
//==========================================================
#define CONFIG_REALTEK_BR_PROFILE_AVRCP 1

// <q> RTK_BR_PROFILE_PBAP - BR PBAP Profile enalbe
//==========================================================
#define CONFIG_REALTEK_BR_PROFILE_PBAP 1

// <q> RTK_BR_PROFILE_HFP - BR HFP Profile enalbe
//==========================================================
#define CONFIG_REALTEK_BR_PROFILE_HFP 1

// <q> RTK_MODULE_LOCAL_PLAYBACK - local playback enalbe
//==========================================================
#define CONFIG_REALTEK_MODULE_LOCAL_PLAYBACK 1

// <q> RTK_BLE_TASK - BLE task enalbe
//==========================================================
#define CONFIG_REALTEK_BLE_TASK 1

// <q> RTK_FLASH_ENABLED - FLASH peripheral driver
//==========================================================
#define CONFIG_REALTEK_BSP_FLASH 1

// <q> RTK_MODULE_USING_DATABASE - DATA BASE ENABLE
//==========================================================
#define CONFIG_REALTEK_MODULE_DATABASE 1

// <q> RTK_GPIO_ENABLED - GPIO peripheral driver
//==========================================================
#define CONFIG_REALTEK_BSP_GPIO 1

// <q> RTK_HAL_UART - UART peripheral driver
//==========================================================
#define CONFIG_REALTEK_BSP_UART 1

// <q> RTK_PIN_ENABLED - pin peripheral driver
//==========================================================
#define CONFIG_REALTEK_BSP_PIN 1

// <q> RTK_DLPS_ENABLED - DLPS config
//==========================================================
#define CONFIG_REALTEK_BSP_DLPS 1


// <q> RTK_I2C_ENABLED - I2C peripheral driver
//==========================================================
#define CONFIG_REALTEK_BSP_I2C 1

// <q> RTK_RTC_ENABLED - RTC peripheral driver
//==========================================================
#define CONFIG_REALTEK_BSP_ONCHIP_RTC 1

// <q> RTK_ADC_ENABLED - ADC peripheral driver
//==========================================================
#define CONFIG_REALTEK_BSP_ADC 0

// <q> RTK_LCD_ENABLED - LCD peripheral driver
//==========================================================
#define CONFIG_REALTEK_BSP_LCD 1

// <q> RTK_SH8601A_454454_MIPI_CMD_ENABLED - SH8601A_454454_MIPI_CMD peripheral driver
//==========================================================
#define CONFIG_REALTEK_SH8601A_454454_MIPI_CMD 1

// <q> RTK_LETTER_SHELL_ENABLED - LETTER SHELL peripheral driver
//==========================================================
#define CONFIG_REALTEK_LETTER_SHELL 1

// <q> RTK_TOUCH_ENABLED - TOUCH peripheral driver
//==========================================================
#define CONFIG_REALTEK_BSP_TOUCH 1

// <q> RTK_816S_ENABLED - 816s driver
//==========================================================
#define CONFIG_REALTEK_BSP_TOUCH_816S_8772F 1

// <q> RTK_KEY_BUTTON_ENABLED - KEY BUTTON peripheral driver
//==========================================================
#define CONFIG_REALTEK_BSP_KEY_BUTTON 1


// </h> Wearable Hal config



// <h> HoneyGUI Framework Config

// <e> HoneyGUI Enable RTK Real GUI
#define CONFIG_REALTEK_BUILD_GUI     1

#if (CONFIG_REALTEK_BUILD_GUI == 1)

// <c> RTK GUI Demo
// #define CONFIG_REALTEK_BUILD_GUI_DEMO
// </c>

// <c> RTK GUI Demo 368 448
//#define CONFIG_REALTEK_BUILD_GUI_448_368_DEMO
// </c>

// <c> RTK GUI Demo 454 454
#define CONFIG_REALTEK_BUILD_GUI_454_454_DEMO
// </c>


// <c> RTK GUI Demo 320 384
// #define CONFIG_REALTEK_BUILD_GUI_320_384_DEMO
// </c>

// <c> RTK GUI Use OS Heap
#define CONFIG_REALTEK_BUILD_GUI_OS_HEAP
// </c>

// <c> RTK GUI Font Enable STB
#define CONFIG_REALTEK_BUILD_GUI_FONT_STB
// </c>

// <c> RTK GUI Font Enable FREETYPE
//#define CONFIG_REALTEK_BUILD_GUI_FONT_FREETYPE
// </c>

// <c> RTK GUI Font Enable RTK MEM
#define CONFIG_REALTEK_BUILD_GUI_FONT_RTK_MEM
// </c>

// <c> RTK GUI Font Enable TTF SVG
//#define CONFIG_REALTEK_BUILD_GUI_FONT_TTF_SVG
// </c>

// <c> RTK GUI Enable VGLITE GPU
#define CONFIG_REALTEK_BUILD_VG_LITE
// </c>

// <c> RTK GUI Enable PPE1.0
//#define CONFIG_REALTEK_BUILD_PPE
// </c>


// <c> RTK GUI Enable SasA
//#define CONFIG_REALTEK_BUILD_SCRIPT_AS_A_APP
// </c>

// <c> RTK GUI Enable Painter Engine only enable for Bee3Pro and simulation
// #define CONFIG_REALTEK_BUILD_PAINTER_ENGINE
// </c>

#endif

// </e>

// <e> HoneyGUI Enable LVGL
#define CONFIG_REALTEK_BUILD_LVGL_GUI     0

#if (CONFIG_REALTEK_BUILD_LVGL_GUI == 1)

// <c> HoneyGUI Enable LVGL EXAMPLES
//#define CONFIG_REALTEK_BUILD_LVGL_EXAMPLES
// </c>

// <c> HoneyGUI Enable LVGL RLOTTIE
//#define BUILD_USING_LVGL_RLOTTIE
// </c>

#endif

// </e>


// </h>

// <<< end of configuration section >>>
#endif//__MENU_CONFIG_H__
