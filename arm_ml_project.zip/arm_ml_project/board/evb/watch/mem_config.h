/**
*****************************************************************************************
*     Copyright(c) 2017, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
  * @file    mem_config.h
  * @brief   Memory Configuration
  * @date    2022.1.28
  * @version v1.0
  * *************************************************************************************
   * @attention
   * <h2><center>&copy; COPYRIGHT 2017 Realtek Semiconductor Corporation</center></h2>
   * *************************************************************************************
  */

/*============================================================================*
 *               Define to prevent recursive inclusion
 *============================================================================*/
#ifndef __MEM_CONFIG__
#define __MEM_CONFIG__

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup MEM_CONFIG Memory Configure
  * @brief Memory configuration for user application
  * @{
  */
// Build Bank Configure
#define BUILD_BANK              0   //Bank0 as default

//Enable RAM Code
#define FEATURE_RAM_CODE        0

/** @brief encrypt app or not */
#define FEATURE_ENCRYPTION      0

//Use Cache RAM to run RAM Code
#define FEATURE_CACHE_RAM_CODE  0

/*============================================================================*
  *                            Memory layout
  *============================================================================*/
#define SPIC0_ADDR            0x04000000
#define SPIC0_SIZE            (64*1024*1024)
#define SPIC1_ADDR            0x08000000
#define SPIC1_SIZE            (64*1024*1024)
#define SPIC2_ADDR            0x0C000000
#define SPIC2_SIZE            (64*1024*1024)
#define SPIC3_ADDR            0x10000000
#define SPIC3_SIZE            (256*1024*1024)

#define ITCM1_ADDR            0x00400000
#define ITCM1_SIZE            (256*1024)

#define DTCM0_ADDR            0x00440000
#define DTCM0_SIZE            (128*1024)

#define DTCM1_ADDR            0x00460000
#define DTCM1_SIZE            (128*1024)

#define BUFFER_RAM_ADDR       0x009C0000
#define BUFFER_RAM_SIZE       (64*1024)

#define VECTOR_TABLE_ITEMS     (297)

/*============================================================================*
  *                       Non Secure Ext Data SRAM layout
  *============================================================================*/
/*SHARE_DSP_RAM_SIZE can only be set 0KB, 256KB, 512KB, 640KB, 896KB, or 1296KB.*/
#define SHARE_DSP_RAM_SIZE              (0*1024)
#define EXT_DATA_SRAM_GLOBAL_SIZE       (64*1024)

/* --------------------The following macros should not be modified!------------------------- */
#define DATA_SRAM_ADDR                  0x00500000
#define DATA_SRAM_SIZE                  (3*1024*1024 + SHARE_DSP_RAM_SIZE)

#define EXT_DATA_SRAM_GLOBAL_ADDR       DATA_SRAM_ADDR
#define EXT_DATA_SRAM_HEAP_ADDR         (EXT_DATA_SRAM_GLOBAL_ADDR + EXT_DATA_SRAM_GLOBAL_SIZE)
#define EXT_DATA_SRAM_HEAP_SIZE         (DATA_SRAM_SIZE - EXT_DATA_SRAM_GLOBAL_SIZE)

/*============================================================================*
  *                                 Non Secure RAM(ITCM1) layout
  *============================================================================*/
/* RAM(ITCM1):          Bee3Pro size: 256K
example:
   1) non-secure app:        256K
*/
#define NS_ITCM1_APP_ADDR               ITCM1_ADDR
#define NS_ITCM1_APP_SIZE               ITCM1_SIZE

/*============================================================================*
  *                                 Non Secure RAM(DTCM0) layout
  *============================================================================*/
/* Data RAM(DTCM0):          Bee3Pro size: 128K
example:
   1) non-secure rom:        6K
   2) main stack:            4K
   3) non-secure patch       16K
   4) non-secure upperstack  8K
   5) non-secure APP global: 32K
   6) non-secure heap        62K + 64K
*/
#define NS_RAM_DTCM1_SIZE               (64*1024)

#define NS_RAM_UPPERSTACK_SIZE          (8*1024)
#define NS_RAM_APP_SIZE                 (32*1024)

/* --------------------The following macros should not be modified!------------------------- */
#define NS_RAM_ROM_GLOBAL_SIZE          (6*1024)
#define NS_RAM_MAIN_STACK_SIZE          (4*1024)
#define NS_RAM_PATCH_SIZE               (16*1024)

#define NS_RAM_START_ADDR                DTCM0_ADDR
#define NS_RAM_TOTAL_SIZE                (DTCM0_SIZE + NS_RAM_DTCM1_SIZE)

#define NS_RAM_ROM_GLOBAL_ADDR           NS_RAM_START_ADDR
#define NS_RAM_MAIN_STACK_START_ADDR     (NS_RAM_ROM_GLOBAL_ADDR + NS_RAM_ROM_GLOBAL_SIZE)
#define NS_RAM_PATCH_ADDR                (NS_RAM_MAIN_STACK_START_ADDR + NS_RAM_MAIN_STACK_SIZE)
#define NS_RAM_UPPERSTACK_ADDR           (NS_RAM_PATCH_ADDR + NS_RAM_PATCH_SIZE)
#define NS_RAM_APP_ADDR                  (NS_RAM_UPPERSTACK_ADDR + NS_RAM_UPPERSTACK_SIZE)
#define NS_HEAP_ADDR                     (NS_RAM_APP_ADDR + NS_RAM_APP_SIZE)
#define NS_HEAP_SIZE                     (NS_RAM_START_ADDR + NS_RAM_TOTAL_SIZE - NS_HEAP_ADDR)

#define NS_RAM_VECTOR_ADDR               (NS_RAM_ROM_GLOBAL_ADDR)
#define NS_RAM_VECTOR_SIZE               (VECTOR_TABLE_ITEMS*4)
/*============================================================================*
  *                                   Secure RAM(DTCM1) layout
  *============================================================================*/
/* Data RAM(DTCM1):          Bee3Pro size: 128K - 64K(NS)
example:
   1) secure app global:     4K
   2) secure heap:           22K
   3) secure patch global:   16K
   4) boot patch global:     8K
   5) main stack:            4K
   6) secure rom global:     9.5K
   7) mbedtls global:        0.5K
*/
/** @brief  data ram start address */
/** @brief  Global size of rom variable in data ram */
#define S_RAM_APP_SIZE                 (4*1024)

/* --------------------The following macros should not be modified!------------------------- */
#define S_RAM_SECURE_PATCH_SIZE        (16*1024)
#define S_RAM_BOOT_PATCH_SIZE          (8*1024)
#define S_RAM_MAIN_STACK_SIZE          (4*1024)
#define S_RAM_ROM_GLOBAL_SIZE          (9*1024 + 512)
#define MBEDTLS_GLOBAL_SIZE            (512)

#define S_RAM_START_ADDR                (DTCM1_ADDR + NS_RAM_DTCM1_SIZE)
#define S_RAM_TOTAL_SIZE                (DTCM1_SIZE - NS_RAM_DTCM1_SIZE)

#define MBEDTLS_GLOBAL_ADDR             (S_RAM_START_ADDR + S_RAM_TOTAL_SIZE - MBEDTLS_GLOBAL_SIZE)
#define S_RAM_ROM_GLOBAL_ADDR           (MBEDTLS_GLOBAL_ADDR - S_RAM_ROM_GLOBAL_SIZE)
#define S_RAM_MAIN_STACK_START_ADDR     (S_RAM_ROM_GLOBAL_ADDR - S_RAM_MAIN_STACK_SIZE)
#define S_RAM_BOOT_PATCH_ADDR           (S_RAM_MAIN_STACK_START_ADDR - S_RAM_BOOT_PATCH_SIZE)
#define S_RAM_SECURE_PATCH_ADDR         (S_RAM_BOOT_PATCH_ADDR - S_RAM_SECURE_PATCH_SIZE)

#define S_RAM_APP_ADDR                  (S_RAM_START_ADDR)
#define S_HEAP_ADDR                     (S_RAM_START_ADDR + S_RAM_APP_SIZE)
#define S_HEAP_SIZE                     (S_RAM_SECURE_PATCH_ADDR - S_HEAP_ADDR)

/** @} */ /* End of group MEM_CONFIG_Exported_Constents */



#ifdef __cplusplus
}
#endif


/** @} */ /* End of group MEM_CONFIG */

#endif

