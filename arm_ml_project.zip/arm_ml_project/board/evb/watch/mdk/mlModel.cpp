#if 1
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/micro/tflite_bridge/micro_error_reporter.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/schema/schema_generated.h"
#include "tensorflow/lite/c/common.h"
#include "tensorflow/lite/micro/all_ops_resolver.h"
#include "tensorflow/lite/micro/kernels/micro_ops.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/schema/schema_generated.h"

extern "C" {void RunModel(int8_t* input_data);}

// Include your model data. Replace this with the header file for your model.
//#include "model.h"
// Define the number of elements in the input tensor
#define INPUT_SIZE 96*96
using MyOpResolver = tflite::MicroMutableOpResolver<10>;
// Replace this with your model's input and output tensor sizes
const int tensor_arena_size = 10 * 1024;
uint8_t tensor_arena[tensor_arena_size] __attribute__ ((aligned(16)));
//const tflite::Model* g_model = ::tflite::GetModel((void*)(uint32_t)0x0C000000);
void RunModel(int8_t* input_data) {
	tflite::MicroErrorReporter micro_error_reporter;
	tflite::ErrorReporter* error_reporter = &micro_error_reporter;
	const tflite::Model* model = ::tflite::GetModel((void*)(uint32_t)0x04500000);
	MyOpResolver op_resolver;
	// Register your model's operations here
//	MicroInterpreter(const Model* model, const MicroOpResolver& op_resolver,
//                   uint8_t* tensor_arena, size_t tensor_arena_size,
//                   MicroResourceVariables* resource_variables = nullptr,
//                   MicroProfilerInterface* profiler = nullptr);
				   
	tflite::MicroInterpreter interpreter(model, op_resolver, tensor_arena, tensor_arena_size, nullptr, nullptr);
	interpreter.AllocateTensors();
	TfLiteTensor* input = interpreter.input(0);
	// Add checks for input tensor properties here if needed
	// Copy image data to model's input tensor
	for (int i = 0; i < INPUT_SIZE; ++i) {
	input->data.int8[i] = input_data[i];
	}
	TfLiteStatus invoke_status = interpreter.Invoke();
	// Add checks for successful inference here if needed
	TfLiteTensor* output = interpreter.output(0);
	// Add checks for output tensor properties here if needed
	// Process your output value here
	// For example, SSD models typically produce an array of bounding boxes
	int num_elements = 1;
    for (int i = 0; i < output->dims->size; i++) {
        num_elements *= output->dims->data[i];
    }

    // ???????
    switch (output->type) {
        case kTfLiteFloat32: {
            float* output_data = output->data.f;
            for (int i = 0; i < num_elements; i++) {
                error_reporter->Report("Output[%d]: %f", i, output_data[i]);
            }
            break;
        }
        case kTfLiteInt8: {
            int8_t* output_data = output->data.int8;
            for (int i = 0; i < num_elements; i++) {
                error_reporter->Report("Output[%d]: %d", i, output_data[i]);
            }
            break;
        }
        case kTfLiteUInt8: {
            uint8_t* output_data = output->data.uint8;
            for (int i = 0; i < num_elements; i++) {
                error_reporter->Report("Output[%d]: %u", i, output_data[i]);
            }
            break;
        }
        default: {
            error_reporter->Report("Unsupported tensor type: %d", output->type);
            break;
        }
    }
	
	//DBG_DIRECT("output->type %d", output->type);
}
#endif
